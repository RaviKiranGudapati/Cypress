# ======================================Change Log ====================================

# Date - 21 Nov 2022

1. Cypress 10.4.0 In Use
2. Cypress-grep reference - https://www.npmjs.com/package/cypress-grep
3. Cypress-grep plugin was aded for tagging tests and running test by referring tags
   Specific Group Tests Using Cypress-grep - "npx cypress run --env grepTags="<Tags separated by space>",grepFilterSpecs=true --headed"
4. cypress-mochawesome-reporter plugin was added for generating HTML report
5. mocha-junit-reporter plugin was added for generating Junit report
6. cypress-multi-reporters plugin was added to support both reports - cypress-mochawesome-reporter and mocha-junit-reporter
7. cypress-mochawesome-reporter internally uses mocha-junit-reporter generated individual Junit style reports.
   cypress-mochawesome-reporter merges all Junit reports and consolidates all Junit reports to HTML report when all tests are executed on single machine.
8. Configuration to generate reports are configured in cypress.config.ts file
9. Custom command - cGroupAsStep was added to group set of cypress calls into a batch and step information to come on test runner logs.
