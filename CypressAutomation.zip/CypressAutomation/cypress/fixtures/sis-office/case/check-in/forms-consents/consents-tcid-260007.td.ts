import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const td_consents_sc260007 = {
  ConsentsModel: [
    {
      ConsentName: `ConsentTemp260007_1`,
      EditConsentDescription: [' Edit Consent Random Text 1'],
      Physician: 'Sign',
      AddendumConsentDescription: [
        ' Addendum Random Text 1',
        ' Addendum Random Text 2',
      ],
    },
  ],

  PatientCase: {
    PatientDetails: {
      PatientFirstName: 'Pfnamesc260007',
      DOB: `01/01/2008`,
      MiddleInitial: 'Joe',
      LastName: 'Plnamesc260007',
      Gender: 'Male',
      Suffix: 'Mr.',
      Address1: '14, Victoria Avenue',
      ZipCode: '12345-6789',
    },

    CaseDetails: {
      OperatingRoom: `Org4Room_4`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `01:15`,
      EndTime: `01:40`,
      CleanUpTime: '20',
      ReferringPhysician: `sis Physician, Dr`,
      AppointmentType: `Gem_General4`,
      CaseNotes: `Case Notes`,
      CptCodeInfo: [
        {
          CPTCodeAndDescription: '00120',
          ModifiedProcDescription: 'ModifiedProcDescription',
          Physician: 'sis Gem_user10, Dr',
          Laterality: 'Left',
          PreOpDiagCode: 'L89.000',
        },
      ],
    },
  },
};
