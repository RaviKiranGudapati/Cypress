import { CommonUtils } from "../../../support/common-core-libs/framework/common-utils";

export const td_consents_physicians_tcid_262596 = {
  PatientCase: {
    PatientDetails: {
      PatientFirstName: 'Pfnamesc262596',
      DOB: `01/01/2008`,
      MiddleInitial: 'Kumar',
      LastName: 'Plnamesc262596',
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    CaseDetails: {
      OperatingRoom: `GemOrg6Room1`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `03:00:00`,
      EndTime: `03:15`,
      CleanUpTime: '20',
      ReferringPhysician: `sis Physician, Dr`,
      AppointmentType: `Gem_General6`,
      CaseNotes: `Case Notes`,
    },
  },
  CptCodeInfo: {
    CPTCodeAndDescription: '00120',
    ModifiedProcDescription: 'ModifiedProcDescription',
    Physician: 'sis Gem_user10, Dr',
    Laterality: 'Left',
    PreOpDiagCode: 'L89.000',
  },
  Consents: [
    {
      ConsentName: 'Consent_Anesthesia',
      PerformingPhysician: ['Phy2097_NonUser4', 'Gem_user10'],
    },
    {
      ConsentName: 'Consent_Anesthesia',
      PerformingPhysician: ['Gem_user11', 'Physician'],
    },
    {
      ConsentName: 'Consent_Anesthesia',
      PerformingPhysician: [
        'Phy2097_NonUser4',
        'Gem_user10',
        'Gem_user11',
        'Physician',
      ],
    },
    {
      ConsentName: 'Consent_262596',
    },
  ],
};
