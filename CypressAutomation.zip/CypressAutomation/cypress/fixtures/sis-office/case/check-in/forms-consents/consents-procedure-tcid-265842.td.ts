import { CommonUtils } from "../../../../../support/common-core-libs/framework/common-utils";

export const td_consents_procedure_sc265842 = {
  ConsentsModel: [
    {
      ConsentName: `ConsentsOne_265842`,
      Procedures: [
        'Right APPLICATION CAST FIGURE-OF-8',
        'Right METATARSECTOMY',
      ],
      ProcedureDisplay: [
        'CPT Description',
        'Modified Procedure Description',
        'Modified Procedure Description + CPT Description',
      ],
    },
    {
      ConsentName: `ConsentsTwo_265842`,
      Procedures: ['Right METATARSECTOMY'],
    },
  ],
  PatientCase: [
    {
      PatientDetails: {
        PatientFirstName: 'PFTestConsTC_265842_1',
        DOB: `01/01/2008`,
        MiddleInitial: 'Joe',
        LastName: 'PLTestConsTC_265842_1',
        Gender: 'Male',
        Suffix: 'Mr.',
        Address1: '14, Victoria Avenue',
        ZipCode: '12345-6789',
      },
      CaseDetails: {
        OperatingRoom: `Org9RoomPT_2`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:15`,
        EndTime: `05:30`,
        AppointmentType: `Gem_Laser9`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '29049',
            ModifiedProcDescription:
              'This is a test modified procedure description4',
            Physician: 'sis Physician, Dr',
            Laterality: 'Right',
          },
          {
            CPTCodeAndDescription: '28140',
            ModifiedProcDescription:
              'This is a test modified procedure description1',
            Physician: 'sis Physician, Dr',
            Laterality: 'Right',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: 'PFTestConsTC_265842_2',
        LastName: 'PLTestConsTC_265842_2',
      },
      CaseDetails: {
        OperatingRoom: `Org9RoomPT_2`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:15`,
        EndTime: `05:30`,
        AppointmentType: `Gem_Laser9`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '28140',
            ModifiedProcDescription: '28140; METATARSECTOMY',
            Physician: 'sis Physician, Dr',
            Laterality: 'Right',
          },
        ],
      },
    },
  ],
  FeeScheduleInfo: {
    ProcedureName: ['28140'],
  },
  Operative: {
    AdmissionTime: '08:15',
    Room: 'Gemuser22_Room2',
    IncisionStartTime: '09:00',
  },
};

