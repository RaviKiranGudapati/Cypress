import {
  CommonUtils,
  StringType,
} from "../../../support/common-core-libs/framework/common-utils";

export const td_enterprise_config_contracts_tcid_270425 = {
  TransactionCodes: [
    {
      TransactionCodeOne: CommonUtils.concatenate(
        'TCode270425_One',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Type: 'Write-Off',
    },
    {
      TransactionCodeTwo: CommonUtils.concatenate(
        'TCode270425_Two',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Type: 'Write-Off',
    },
  ],
  Contracts: [
    {
      /**
       * string of length 89
       */
      ContractName:
        'abcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijlsdgfkja',
      /**
       * string of lenght 550
       */
      Notes: `abcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefg
      hijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijlsdgfkjaabcdefghijabcdefghijabcdefghijabcdefg
      hijabcdefghijabcdefghijabcdefghijabcdefghijlsdgfkjaabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghi
      jabcdefghijabcdefghijlsdgfkjaabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijl
      sdgfkjaabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijlsdgfkja`,
    },
    {
      /**
       * string of length 80
       */
      ContractName:
        'abcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghijabcdefghij',
    },
    {
      ContractName: CommonUtils.concatenate(
        'NewContOne270425_1',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Notes: 'New notes',
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: '% of Billed Charges',
    },
    {
      ContractName: CommonUtils.concatenate(
        'NewContTwo270425_2',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Notes: 'New notes',
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: '% of Billed Charges',
    },
    {
      ContractName: CommonUtils.concatenate(
        'NewContThree270425_3',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Notes: 'New notes',
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: '% of Billed Charges',
    },
    {
      ContractName: CommonUtils.concatenate(
        'NewContFour270425_4',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Notes: 'New notes',
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: '% of Billed Charges',
    },
  ],
  FeeSchedules: [
    {
      CptProcedure: '00100',
      StatusDropDownValue: 'Billable',
      Amount: '3000',
    },
    {
      CptProcedure: '55000',
      StatusDropDownValue: 'Billable',
      Amount: '4000',
    },
  ],
  ProcedureDetailsInReviewEdit: [
    {
      CptHcpsc: '00100',
      StandardFee: '$3,000.00',
      Type: '% of Billed Charges',
      Details: '50%',
      AllowedAmount: '$1,500.00',
      Exempt: 'No',
    },

    {
      CptHcpsc: '55000',
      StandardFee: '$4,000.00',
      Type: '% of Billed Charges',
      Details: '10%',
      AllowedAmount: '$400.00',
      Exempt: 'No',
    },
  ],
};
