export const td_enterprise_config_discount_tcid_267489 = {
  Discount: {
    DiscountNames: ['35% of DiscountA', '65% of DiscountB', '75% of DiscountC'],
    DiscountPercentage: ['35.00', '65.00', '80.00', '75.00'],
    TransactionCodeDropdownValues: [
      'Select Item',
      'Sharing WriteOff One',
      'Sharing WriteOff Two',
      'Sharing WriteOff Three',
    ],
  },
};
