export const td_cbo_views_cbo_management_tcid_270826 = {
  UserManagement: [
    {
      User: 'Gem_user11',
      TabName: 'Facilities',
    },
    {
      User: '',
      TabName: 'CBO Details',
    },
  ],
  AddOnFeatures: {
    FeatureName: 'CBO Centralized Views',
  },
  CBOManagement: [
    {
      CBOEntity: 'CBOEntityUS270061_1',
      Acronym: 'Acro1',
      FacilitiesIncluded: [
        'Gem_Org001',
        'Gem_Org002',
        'Gem_Org003',
        'Gem_Org011',
      ],
    },
    {
      CBOEntity: 'CBOEntityUS270061_2',
      Acronym: 'Acro2',
      FacilitiesIncluded: [
        'Gem_Org002',
        'Gem_Org003',
        'Gem_Org004',
        'Gem_Org011',
      ],
    },
  ],
  CBODetails: [
    {
      CBOEntity: ['CBOEntityUS270061_1', 'CBOEntityUS270061_2'],
    },
    {
      CBOEntity: ['CBOEntityUS270061_2'],
    },
  ],
};
