export const td_enterprise_configuration_tcid_265133 = {
  UserDetails: [
    {
      FirstName: 'First265133',
      LastName: 'User265133',
      EMail: 'Firstuser265133@sisfirst.com',
    },
    {
      EMail: 'First@',
    },
    {
      EMail: 'Test@sisfirst.com',
    },
  ],
};
