import {
  CommonUtils,
  StringType,
} from '../../../support/common-core-libs/framework/common-utils';

export const td_enterprise_config_contracts_tcid_270398 = {
  TransactionCodeName: [
    CommonUtils.concatenate(
      'TCodeOne_270398',
      CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
    ),
    CommonUtils.concatenate(
      'TCodeTwo_270398',
      CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
    ),
  ],
  Contracts: [
    {
      ContractName: CommonUtils.concatenate(
        'Contract270398_One',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: 'Grouper',
      AdjustmentTime: 'At Charge Posting',
      Notes: 'New notes',
    },
    {
      ContractName: CommonUtils.concatenate(
        'Contract270398_Two',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      ContractType: 'Contract Fee Schedule',
      PercentageOfAllowed: '30.00',
      AdjustmentTime: 'At Charge Posting',
    },
    {
      ContractName: CommonUtils.concatenate(
        'Contract270398_Three',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      ContractType: '% of Billed Charges',
      PercentageOfAllowed: '50.00',
      AdjustmentTime: 'At Charge Posting',
    },
    {
      ContractName: CommonUtils.concatenate(
        'Contract270398_Four',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      ContractType: '% of Billed Charges',
      PercentageOfAllowed: '50.00',
      AdjustmentTime: 'At Charge Posting',
    },
  ],
  FeeSchedules: [
    {
      CptProcedure: '22206',
      StatusDropDownValue: 'Billable',
      Amount: '4000',
    },
    {
      CptProcedure: '22207',
      StatusDropDownValue: 'Billable',
      Amount: '6000',
    },
  ],
  ProcedureDetailsInReviewEdit: [
    {
      CptHcpsc: '22206',
      StandardFee: '$4,000.00',
      Type: 'Grouper',
      Details: '0',
      AllowedAmount: '$12,345.00',
      Exempt: 'No',
    },
    {
      CptHcpsc: '22207',
      StandardFee: '$6,000.00',
      Type: 'Grouper',
      Details: '1',
      AllowedAmount: '$20.00',
      Exempt: 'No',
    },
    {
      CptHcpsc: '22206',
      StandardFee: '$4,000.00',
      Type: 'Contract Allowable',
      Details: '30%',
      ImportedAmt: '',
      AllowedAmount: '',
      Exempt: 'No',
    },
    {
      CptHcpsc: '22207',
      StandardFee: '$6,000.00',
      Type: 'Contract Allowable',
      ImportedAmt: '',
      Details: '30%',
      AllowedAmount: '',
      Exempt: 'No',
    },
    {
      CptHcpsc: '22206',
      StandardFee: '$4,000.00',
      Type: '% of Billed Charges',
      Details: '50%',
      AllowedAmount: '$2,000.00',
      Exempt: 'No',
    },
    {
      CptHcpsc: '22207',
      StandardFee: '$6,000.00',
      Type: '% of Billed Charges',
      Details: '50%',
      AllowedAmount: '$3,000.00',
      Exempt: 'No',
    },
  ],
  FeeGroups: [
    {
      Index: '0',
      Reimbursement: '12345',
    },
    {
      Index: '1',
      Reimbursement: '20',
    },
  ],
};
