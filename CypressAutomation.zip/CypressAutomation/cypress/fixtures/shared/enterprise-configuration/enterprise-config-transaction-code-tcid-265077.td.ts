export const td_enterprise_config_transaction_code_tcid_265077 = {
  TransactionCode: {
    TransactionCodeName: [
      'Transaction Code A',
      'TransactionTransactionTransactionTransactionTransactionTransactionTransactionTransaction',
      'TransactionTransactionTransactionTransactionTransactionTransactionTransactionTra',
      'Transaction Code B',
    ],
  },
};
