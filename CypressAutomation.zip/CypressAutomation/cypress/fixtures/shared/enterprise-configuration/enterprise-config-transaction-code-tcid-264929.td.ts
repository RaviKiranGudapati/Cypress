import {
  CommonUtils,
  StringType,
} from "../../../support/common-core-libs/framework/common-utils";

export const td_enterprise_config_transaction_code_tcid_264929 = {
  TransactionCode: {
    TransactionCodeName:
      'Transaction Code' +
      CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
  },
};
