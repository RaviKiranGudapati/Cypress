import { CommonUtils } from "../../../support/common-core-libs/framework/common-utils";

export const td_surgery_board_recovery = {
  PatientCase: [
    {
      PatientDetails: {
        PatientFirstName: `NotArrived273785_1`,
        LastName: `NotArrived273785_1`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room1`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `18:30`,
        EndTime: `19:00`,
        AppointmentType: `Gem_Eye5`,
        AnesthesiaType: `Anesth_sc1531`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22220; OSTEOTOMY SPINE W/DSC ANT APPR 1 VRT SGM CRV',
            ModifiedProcDescription:
              'OSTEOTOMY SPINE W/DSC ANT APPR 1 VRT SGM CRV',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `Arrived273785_2`,
        LastName: `Arrived273785_2`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room1`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `18:30`,
        EndTime: `19:00`,
        AppointmentType: `Gem_General5`,
        AnesthesiaType: `Block_2027`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '23931; INCISION&DRAINAGE UPPER ARM/ELBOW BURSA',
            ModifiedProcDescription: 'INCISION&DRAINAGE UPPER ARM/ELBOW BURSA',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `TArriveTick273785_3`,
        LastName: `TArriveTick273785_3`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room10`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `19:00`,
        EndTime: `19:30`,
        AppointmentType: `Gem_Pain5`,
        AnesthesiaType: `Block-Bier2027`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22206; OSTEOTOMY SPINE POSTERIOR 3 COLUMN THORACIC',
            ModifiedProcDescription:
              'OSTEOTOMY SPINE POSTERIOR 3 COLUMN THORACIC',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `PreOp273785_4`,
        LastName: `PreOp273785_4`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room10`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `19:00`,
        EndTime: `19:30`,
        AppointmentType: `Gem_GI5`,
        AnesthesiaType: `BlockBier2027`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22214; OSTEOTOMY SPINE PST/PSTLAT APPR 1 VRT SGM LMBR',
            ModifiedProcDescription:
              'OSTEOTOMY SPINE PST/PSTLAT APPR 1 VRT SGM LMBR',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `TPreoOpTick273785_5`,
        LastName: `TPreoOpTick273785_5`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room2`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `19:00`,
        EndTime: `19:30`,
        AppointmentType: `Gem_Pain5`,
        AnesthesiaType: `General_2027`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22220; OSTEOTOMY SPINE W/DSC ANT APPR 1 VRT SGM CRV',
            ModifiedProcDescription:
              'OSTEOTOMY SPINE W/DSC ANT APPR 1 VRT SGM CRV',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `Operative273785_6`,
        LastName: `Operative273785_6`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room3`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `19:00`,
        EndTime: `19:30`,
        AppointmentType: `Gem_Laser5`,
        AnesthesiaType: `Local_2027`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '23450; CAPSULORRHAPHY ANTERIOR PUTTI-PLATT/MAGNUSON',
            ModifiedProcDescription:
              'CAPSULORRHAPHY ANTERIOR PUTTI-PLATT/MAGNUSON',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `Recovery273785_7`,
        LastName: `Recovery273785_7`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room4`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `19:00`,
        EndTime: `19:30`,
        AppointmentType: `Gem_GI5`,
        AnesthesiaType: `Anesth_sc1531`,

        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22216; OSTEOT SPI PST/PSTLAT APPR 1 VRT SGM EA VRT SGM',
            ModifiedProcDescription:
              'OSTEOT SPI PST/PSTLAT APPR 1 VRT SGM EA VRT SGM',
            Physician: 'sis Physician, Dr',
          },
          {
            CPTCodeAndDescription: '00142; ANESTHESIA EYE LENS SURGERY',
            ModifiedProcDescription: 'ANESTHESIA EYE LENS SURGERY',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `Discharged273785_8`,
        LastName: `Discharged273785_8`,
      },
      CaseDetails: {
        OperatingRoom: `GemOrg5Room5`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `19:00`,
        EndTime: `19:30`,
        AppointmentType: `Gem_General5`,
        AnesthesiaType: `General_2027`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22216; OSTEOT SPI PST/PSTLAT APPR 1 VRT SGM EA VRT SGM',
            ModifiedProcDescription:
              'OSTEOT SPI PST/PSTLAT APPR 1 VRT SGM EA VRT SGM',
            Physician: 'sis Physician, Dr',
          },
          {
            CPTCodeAndDescription: '00142; ANESTHESIA EYE LENS SURGERY',
            ModifiedProcDescription: 'ANESTHESIA EYE LENS SURGERY',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
  ],
  RecoveryInfo: {
    AdmissionTime: `19:30`,
    Room: `Room1591`,
    DischargeTime: `19:35`,
  },
  DepartmentInfo: [
    {
      // Pat-4 Pre-Op
      AdmissionTime: '19:10',
    },
    {
      // Pat-5 Pre-op with Room
      AdmissionTime: '19:12',
      Room: 'Room0128',
    },
    {
      // Pat-6 Operative
      AdmissionTime: '19:14',
      Room: 'GemOrg5Room1',
    },
    {
      // Pat-7 Recovery
      AdmissionTime: '19:16',
      Room: 'Room0067',
    },
  ],
  SurgeryBoardTrackerInfo: [
    {
      SchedOR: 'GemOrg5Room1',
      Patient: 'NoNo',
      Procedure: 'Right OSTEOTOMY SPINE W/DSC ANT APPR 1 VRT SGM CRV',
      SchedStartTime: '18:30',
      SchedEndTime: '19:00',
      Surgeon: 'Physician, sis , Dr',
      Location: 'NOT ARRIVED',
    },
    {
      SchedOR: 'GemOrg5Room1',
      Patient: 'ArAr',
      Procedure: 'Right INCISION&amp;DRAINAGE UPPER ARM/ELBOW BURSA',
      SchedStartTime: '18:30',
      SchedEndTime: '19:00',
      AnesthesiaType: 'Block_2027',
      Surgeon: 'Physician, sis , Dr',
      Location: 'ARRIVED',
    },
    {
      SchedOR: 'GemOrg5Room10',
      Patient: 'TATA',
      Procedure: 'Right OSTEOTOMY SPINE POSTERIOR 3 COLUMN THORACIC',
      AnesthesiaType: 'Block-Bier2027',
      SchedStartTime: '19:00',
      SchedEndTime: '19:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'ARRIVED ✓',
    },
    {
      SchedOR: 'GemOrg5Room10',
      Patient: 'PrPr',
      Procedure: 'Right OSTEOTOMY SPINE PST/PSTLAT APPR 1 VRT SGM LMBR',
      SchedStartTime: '19:00',
      SchedEndTime: '19:30',
      AnesthesiaType: 'BlockBier2027',
      Surgeon: 'Physician, sis , Dr',
      Location: 'PRE-OP',
    },
    {
      SchedOR: 'GemOrg5Room2',
      Patient: 'TPTP',
      SchedStartTime: '19:00',
      SchedEndTime: '19:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'PRE-OP ✓',
    },
    {
      SchedOR: 'GemOrg5Room3',
      Patient: 'OpOp',
      SchedStartTime: '19:00',
      SchedEndTime: '19:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'OR',
    },
    {
      SchedOR: 'GemOrg5Room4',
      Patient: 'ReRe',
      Procedure:
        'Right ANESTHESIA EYE LENS SURGERY, Right OSTEOT SPI PST/PSTLAT APPR 1 VRT SGM EA VRT SGM',
      SchedStartTime: '19:00',
      SchedEndTime: '19:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'RECOVERY',
    },
    {
      SchedOR: 'GemOrg5Room5',
      Patient: 'DiDi',
      Procedure:
        'Right ANESTHESIA EYE LENS SURGERY, Right OSTEOT SPI PST/PSTLAT APPR 1 VRT SGM EA VRT SGM',
      SchedStartTime: '19:00',
      SchedEndTime: '19:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'DISCHARGED',
    },
  ],
};
