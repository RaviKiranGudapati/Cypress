import {
  CommonUtils,
  StringType,
} from '../../../support/common-core-libs/framework/common-utils';

export const td_Outbound_CCDA_tcid_266530 = {
  PatientInfo: {
    PatientFirstName: 'PfnameCCDA266530',
    LastName: 'PlnameCCDA266530',
  },
  DictionaryInfo: [
    {
      DictionaryName: 'Ethnicity',
      Item: 'Hispanic',
    },
    {
      DictionaryName: 'Race',
      Item:
        'Race' + CommonUtils.generateUniqueString(3, StringType.ALPHANUMERIC),
    },
    {
      DictionaryName: 'Language',
      Item:
        'NewLang' +
        CommonUtils.generateUniqueString(3, StringType.ALPHANUMERIC),
    },
    {
      DictionaryName: 'Tobacco Use',
      Item:
        '2-4 times per day' +
        CommonUtils.generateUniqueString(2, StringType.NUMERIC),
    },
    {
      DictionaryName: 'Recreational Drug Use',
      Item: 'RDrug ' + CommonUtils.generateUniqueString(2, StringType.NUMERIC),
    },
    {
      DictionaryName: 'Tobacco Use',
      Item:
        'Current Smoker' +
        CommonUtils.generateUniqueString(2, StringType.NUMERIC),
    },
  ],
  PreAdQxInfo: {
    WorklistName: 'PreAdmitQx266530',
    Tobacco: 'Heavy Smoker',
    Alcohol: 'Once per day',
    DrugUse:
      'Once per week ' +
      CommonUtils.generateUniqueString(2, StringType.NUMERIC),
  },
};
