import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

export const td_surgery_board_phase = {
  PatientCase: [
    {
      PatientDetails: {
        PatientFirstName: `NotArrived273786_1`,
        LastName: `NotArrived273786_1`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_1`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:00`,
        EndTime: `09:30`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22010; I&D DEEP ABSCESS PST SPINE CRV THRC/CERVICOTHR',
            ModifiedProcDescription:
              'I&D DEEP ABSCESS PST SPINE CRV THRC/CERVICOTHR',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `Arrived273786_2`,
        LastName: `Arrived273786_2`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_1`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:30`,
        EndTime: `10:00`,
        AppointmentType: `Gem_GeneralPh001`,
        AnesthesiaType: `Generalsc1995`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '22010; I&D DEEP ABSCESS PST SPINE CRV THRC/CERVICOTHR',
            ModifiedProcDescription:
              'I&D DEEP ABSCESS PST SPINE CRV THRC/CERVICOTHR',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `TArriveTick273786_3`,
        LastName: `TArriveTick273786_3`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_10`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:00`,
        EndTime: `09:30`,
        AppointmentType: `Gem_GeneralPh001`,
        AnesthesiaType: `Generalsc1995`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '23931; INCISION&DRAINAGE UPPER ARM/ELBOW BURSA',
            ModifiedProcDescription: 'INCISION&DRAINAGE UPPER ARM/ELBOW BURSA',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `PreOp273786_4`,
        LastName: `PreOp273786_4`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_10`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:30`,
        EndTime: `10:00`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription:
              '23931; INCISION&DRAINAGE UPPER ARM/ELBOW BURSA',
            ModifiedProcDescription: 'INCISION&DRAINAGE UPPER ARM/ELBOW BURSA',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `TPreoOpTick273786_5`,
        LastName: `TPreoOpTick273786_5`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_11`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:00`,
        EndTime: `09:30`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '25695; OPEN TREATMENT LUNATE DISLOCATION',
            ModifiedProcDescription: 'OPEN TREATMENT LUNATE DISLOCATION',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `Operative273786_6`,
        LastName: `Operative273786_6`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_11`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:30`,
        EndTime: `10:00`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '25695; OPEN TREATMENT LUNATE DISLOCATION',
            ModifiedProcDescription: 'OPEN TREATMENT LUNATE DISLOCATION',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `1PhaseOne273786_7`,
        LastName: `1PhaseOne273786_7`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_12`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:00`,
        EndTime: `09:30`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '27120; ACETABULOPLASTY',
            ModifiedProcDescription: 'ACETABULOPLASTY',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `2PhaseTwo273786_8`,
        LastName: `2PhaseTwo273786_8`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_12`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:30`,
        EndTime: `10:00`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '27120; ACETABULOPLASTY',
            ModifiedProcDescription: 'ACETABULOPLASTY',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `3PhaseThree273786_9`,
        LastName: `3PhaseThree273786_9`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_13`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:00`,
        EndTime: `09:30`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '28192; REMOVAL FOREIGN BODY FOOT DEEP',
            ModifiedProcDescription: 'REMOVAL FOREIGN BODY FOOT DEEP',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: `Discharged273786_10`,
        LastName: `Discharged273786_10`,
      },
      CaseDetails: {
        OperatingRoom: `OrgP1_RoomNo_13`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `09:30`,
        EndTime: `10:00`,
        AppointmentType: `Gem_GeneralPh001`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '28192; REMOVAL FOREIGN BODY FOOT DEEP',
            ModifiedProcDescription: 'REMOVAL FOREIGN BODY FOOT DEEP',
            Physician: 'sis Physician, Dr',
          },
        ],
      },
    },
  ],
  RecoveryInfo: {
    AdmissionTime: `10:00`,
    Room: `Room1591`,
    DischargeTime: `19:35`,
  },
  DepartmentInfo: [
    {
      // Pat-4 Pre-Op
      AdmissionTime: '19:10',
    },
    {
      // Pat-5 Pre-op with Room
      AdmissionTime: '19:12',
      Room: 'FASCRoom1',
    },
    {
      // Pat-6 Operative
      AdmissionTime: '19:14',
      Room: 'OrgP1_RoomNo_1',
    },
    {
      // Pat-7 phase-1
      AdmissionTime: '19:16',
      Room: 'Room0216',
    },
    {
      // Pat-8 phase-2
      AdmissionTime: '19:18',
      Room: 'Room0241',
    },
    {
      // Pat-9 phase-3
      AdmissionTime: '19:20',
      Room: 'Room0324',
    },
  ],
  SurgeryBoardTrackerInfo: [
    {
      SchedOR: 'OrgP1_RoomNo_1',
      Patient: 'NoNo',
      Procedure: 'Right I&amp;D DEEP ABSCESS PST SPINE CRV THRC/CERVICOTHR',
      SchedStartTime: '09:00',
      SchedEndTime: '09:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'NOT ARRIVED',
    },
    {
      SchedOR: 'OrgP1_RoomNo_1',
      Patient: 'ArAr',
      Procedure: 'Right I&amp;D DEEP ABSCESS PST SPINE CRV THRC/CERVICOTHR',
      AnesthesiaType: `Generalsc1995`,
      SchedStartTime: '09:30',
      SchedEndTime: '10:00',
      Surgeon: 'Physician, sis , Dr',
      Location: 'ARRIVED',
    },
    {
      SchedOR: 'OrgP1_RoomNo_10',
      Patient: 'TATA',
      Procedure: 'Right INCISION&amp;DRAINAGE UPPER ARM/ELBOW BURSA',
      SchedStartTime: '09:00',
      SchedEndTime: '09:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'ARRIVED ✓',
    },
    {
      SchedOR: 'OrgP1_RoomNo_10',
      Patient: 'PrPr',
      Procedure: 'Right INCISION&amp;DRAINAGE UPPER ARM/ELBOW BURSA',
      SchedStartTime: '09:30',
      SchedEndTime: '10:00',
      Surgeon: 'Physician, sis , Dr',
      Location: 'PRE-OP',
    },
    {
      SchedOR: 'OrgP1_RoomNo_11',
      Patient: 'TPTP',
      SchedStartTime: '09:00',
      SchedEndTime: '09:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'PRE-OP ✓',
    },
    {
      SchedOR: 'OrgP1_RoomNo_11',
      Patient: 'OpOp',
      SchedStartTime: '09:30',
      SchedEndTime: '10:00',
      Surgeon: 'Physician, sis , Dr',
      Location: 'OR',
    },
    {
      SchedOR: 'OrgP1_RoomNo_12',
      Patient: '1P1P',
      SchedStartTime: '09:00',
      SchedEndTime: '09:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'PHASE 1',
    },
    {
      SchedOR: 'OrgP1_RoomNo_12',
      Patient: '2P2P',
      SchedStartTime: '09:30',
      SchedEndTime: '10:00',
      Surgeon: 'Physician, sis , Dr',
      Location: 'PHASE 2',
    },
    {
      SchedOR: 'OrgP1_RoomNo_13',
      Patient: '3P3P',
      Procedure: 'Right REMOVAL FOREIGN BODY FOOT DEEP',
      SchedStartTime: '09:00',
      SchedEndTime: '09:30',
      Surgeon: 'Physician, sis , Dr',
      Location: 'PHASE 3',
    },
    {
      SchedOR: 'OrgP1_RoomNo_13',
      Patient: '3P3P',
      Procedure: 'Right REMOVAL FOREIGN BODY FOOT DEEP',
      SchedStartTime: '09:30',
      SchedEndTime: '10:00',
      Surgeon: 'Physician, sis , Dr',
      Location: 'DISCHARGED',
    },
  ],
};
