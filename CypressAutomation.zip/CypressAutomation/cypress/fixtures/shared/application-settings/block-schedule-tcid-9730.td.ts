import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

export const td_block_schedule_tcid_9730 = {
  BlockInfos: {
    CreateBlock: {
      Block_Name: ['Block9730', 'Block9730_1', 'Block9730_2'],
      Physician: ['sis Gem_user10, Dr'],
      Room: ['GemOrg6Room1'],
      Specialty: 'General',
      Start_Time: ['10:30', '15:30'],
      End_Time: ['11:30', '16:30'],
      Recur_Every: '1',
      WeeksOn: ['Monday', 'Friday'],
      WeeksOn1: [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday',
      ],
      WeeksOn2: ['Sunday', 'Tuesday'],
      MonthsOn: ['First', 'Second', 'Third', 'Fourth', 'Fifth', 'Last'],
      Start_Date: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      End_Date: CommonUtils.getAfterDate_mmddyyyy(30).replace(/[/]/g, ''),
      RecurEvery: ['999', '99', '15', '6'],
    },
  },
};
