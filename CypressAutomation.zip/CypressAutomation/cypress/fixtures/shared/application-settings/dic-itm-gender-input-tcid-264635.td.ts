export const td_dic_itm_gender_input_tcid_264635 = {
  DictionaryInfo: {
    Dictionary: ['Gender Identity', 'Alcohol Use'],
    ShowInactive: ['Yes', 'No'],
    DictionaryItem: [
      'Female',
      'Male',
      'Nonbinary',
      'Transgender Male',
      'Transgender Female',
      'Gender Identity Test',
      'Formulary Test',
      'New Item Test',
      'New Item1 Test',
      'New Item2 Test',
    ],
    ActiveButton: ['Yes', 'No'],
    ItemCount: ['5', '8', '9'],
    ShownCount: ['5', '6', '8'],
  },
};
