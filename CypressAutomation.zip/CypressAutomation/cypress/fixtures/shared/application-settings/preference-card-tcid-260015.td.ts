import { HelperText } from '../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

export const td_preference_card_tcid_260015 = {
  PreferenceCardInfo: {
    CopyPreferenceCardName: 'Copy of Preference Card1',
    AddPreferenceCard: 'Preference Card1',
    CaseSpecialty: ['General', 'Pain', 'GI', 'Laser'],
    AppointmentType: ['Gem_Eye5', 'Gem_General5'],
    Physician: ['sis Gem_user11, Dr', 'sis Gem_user10, Dr'],
    AnesthesiaType: ['Anesth_sc1531', 'Block-Bier2027'],
    CPTTrademark: HelperText.disclaimer_text_cpt,
    Procedures: ['64569', '10060'],
    Duration: [9999, 999, 888],
    CleanUpTime: [999, 99, 88],
    PhysicianPreferences: [
      'Hi-Physician Preferences text must present here.',
      'Hi-Physician Preferences2 text must present here2.',
    ],
    MinutesText: 'Mins.',
    DurationText: 'Mins.',
  },
  PatientCase: {
    PatientDetails: {
      PatientFirstName: 'Pfnamesc1950_5',
      DOB: `01/01/2005`,
      MiddleInitial: 'Kumar',
      LastName: 'Plnamesc1950_5',
      Gender: 'Male',
      Suffix: 'Mr',
    },
    CaseDetails: {
      OperatingRoom: `GemOrg5Room1`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `09:00`,
      EndTime: `09:30`,
      ReferringPhysician: `sis Gem_user10, Dr`,
      AppointmentType: `Gem_General5`,
      CptCodeInfo: [
        {
          CPTCodeAndDescription: '23000',
          Physician: 'sis Physician, Dr',
          Laterality: 'Left',
        },
      ],
      PreferenceCards: [
        {
          Physician: 'sis Gem_user10, Dr',
          AvailablePreferenceCards: ['Preference Card1'],
        },
      ],
    },
  },
};
