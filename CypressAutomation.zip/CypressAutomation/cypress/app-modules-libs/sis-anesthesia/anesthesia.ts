import { CoreCssClasses } from '../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../support/common-core-libs/application/sis-office-desktop';
import {
  DoneOrCancel,
  ShouldMethods,
} from '../../support/common-core-libs/application/common-core';

import {
  Consents,
  PatientDetails,
} from '../../test-data-models/sis-office/case/patient-case.model';
import { Medication } from '../../test-data-models/sis-office/trackers/inv-reconciliation.model';

import { OR_ANESTHESIA_DESKTOP } from './or/anesthesia.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../support/common-core-libs/application/or/sis-office-desktop.or';

import SISAnesthesiaDesktopApi from './api/anesthesia.api';
import { AnesthesiaCaseLabels } from './enums/anesthesia.enum';

export default class SISAnesthesiaDesktop extends SISOfficeDesktop {
  private sisAnesthesiaApi = new SISAnesthesiaDesktopApi();

  /**
   * @details - Click on labels like Consents. Orders etc available in patient case block
   * @param patientDetails - To provide the patient details
   * @param label - To provide the anesthesia labels
   * @APIs are available - Not Implemented
   */
  selectPatientCaseOption(
    patientDetails: PatientDetails,
    label: AnesthesiaCaseLabels
  ) {
    const patientName = `${patientDetails.LastName}, ${patientDetails.PatientFirstName}`;
    //TODO : Need to Implement API
    cy.cClick(selectorFactory.anesthesiaCaseOptions(patientName, label), label);
  }

  /**
   * @details Search and select the case from global search bar
   * @param patientRec as parameter passed in the function
   * @APIs are available -  Implemented Completely
   * @author - chandrika
   */
  selectPatientInSearchBox(patientRec: PatientDetails) {
    const interceptCollection =
      this.sisAnesthesiaApi.interceptSelectPatientAnesthesiaApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.SEARCH_BY_NAME_MRN_DOB[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.SEARCH_BY_NAME_MRN_DOB[0],
      CommonUtils.getStringByLen(patientRec.PatientFirstName!)
    );
    const patientName = `${patientRec.LastName}, ${patientRec.PatientFirstName}`;
    cy.cGet(OR_ANESTHESIA_DESKTOP.SEARCH_PATIENT[1]).within(() => {
      cy.cClick(
        selectorFactory.getSearchResults(patientName),
        patientName,
        false,
        false,
        { force: true }
      );
    });
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Select pre and post-op tab
   * @param tabName as parameter passed in the function
   * @APIs are available - Implemented completely
   * @author - chandrika
   */
  clickPreAndPostOpTab(tabName: string) {
    let interceptCollections =
      this.sisAnesthesiaApi.interceptClickPreAndPostOpTabApi();
    cy.shouldBeEnabled(selectorFactory.getSpanText(tabName));
    cy.cIntercept(interceptCollections);
    cy.cClick(selectorFactory.getSpanText(tabName), tabName, false, true);
    cy.cWaitApis(interceptCollections);
  }

  /**
   * @details Select icons in pre and post-op tab
   * @param icon - Pass icon as Pre-Op Exam, Consents
   * @APIs are available - Implemented completely
   * @author - chandrika
   */
  clickPreAndPostOpIcons(icon: string = AnesthesiaCaseLabels.consents) {
    const interceptCollection =
      this.sisAnesthesiaApi.interceptClickPreAndPostOpTabApi();
    const preAndPostIcon =
      icon === AnesthesiaCaseLabels.consents
        ? OR_ANESTHESIA_DESKTOP.CONSENTS.CONSENTS[0]
        : OR_ANESTHESIA_DESKTOP.PRE_OP_EXAM.SUB_HEADER[0];

    cy.shouldBeEnabled(selectorFactory.getSpanText(preAndPostIcon));
    cy.cClick(selectorFactory.getSpanText(preAndPostIcon), icon, false, true);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on Performing Physician Dropdown and select Physicians and close dropdown in consents
   * @param consent - using PerformingPhysician from Consents Model
   * @APIs are not available
   */
  selectConsentPerformingPhysicians(consent: Consents) {
    this.selectValueFromDropdown(
      OR_ANESTHESIA_DESKTOP.CONSENTS.EDIT_CONSENTS_POPUP
        .PERFORMING_PHYSICIAN[1],
      OR_ANESTHESIA_DESKTOP.CONSENTS.EDIT_CONSENTS_POPUP
        .PERFORMING_PHYSICIAN[0],
      CoreCssClasses.MultiSelect.loc_ui_multiselect_item,
      consent.PerformingPhysician!,
      true
    );
  }

  /**
   * @details - Verify selected Performing Physician Dropdown in consents
   * @param consent - using PerformingPhysician from Consents Model
   * @APIs are not available
   */
  verifyPerformingPhysicians(consent: Consents) {
    consent.PerformingPhysician!.forEach((val: string) => {
      cy.cIsVisible(selectorFactory.physiciansAnesthesiaConsents(val), val);
    });
  }

  /**
   * @details - Click on Edit Consents Done Button
   * @APIs are available - Not Implemented
   */
  clickEditConsentDone() {
    //TODO : Need to Implement API
    cy.cClick(
      OR_ANESTHESIA_DESKTOP.CONSENTS.EDIT_CONSENTS_POPUP.DONE[1],
      OR_ANESTHESIA_DESKTOP.CONSENTS.EDIT_CONSENTS_POPUP.DONE[0]
    );
  }

  /**
   * @details - Click on Edit Consents Sign Button
   * @param signee - Physician, Ansthesiologist etc
   * APIs are available - Not Implemented
   */
  clickPhysicianSignConsent(signee: string) {
    //TODO : Need to Implement API
    cy.cClick(
      selectorFactory.signAnesthesiaConsents(signee),
      OR_ANESTHESIA_DESKTOP.CONSENTS.CONSENTS[0]
    );
  }

  /**
   * @details - Select the consent from list to edit
   * @param  consentName - To provide the consent name for selection
   * @APIs are available - Implemented completely
   * @author - chandrika
   **/
  selectCaseConsent(consentName: string) {
    const interceptCollections =
      this.sisAnesthesiaApi.interceptSelectCaseConsentApi();
    cy.cIntercept(interceptCollections);
    cy.cClick(selectorFactory.getTdText(consentName), consentName, false, true);
    cy.cWaitApis(interceptCollections);
  }

  /**
   * @details - Navigating to nursing desktop
   * @param selector - User Settings, Application Settings, Reports etc
   * @Author - Vamshi
   */
  selectAnesthesiaInUserMenuDropdown(selector: string) {
    let interceptCollections =
      this.sisAnesthesiaApi.interceptNavigatingAnesthesiaApi();
    cy.cIntercept(interceptCollections);
    this.selectOptionInUserMenuDropdown(selector);
    cy.cWaitApis(interceptCollections);
  }

  /**
   * @details - Search and Select Anesthesia Plan
   * @param planName - Pass Anesthesia Plan Name
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectAnesthesiaPlan(planName: string) {
    cy.shouldBeEnabled(OR_ANESTHESIA_DESKTOP.PRE_OP_EXAM.ANESTHESIA_PLAN[1]);
    cy.cClick(
      OR_ANESTHESIA_DESKTOP.PRE_OP_EXAM.ANESTHESIA_PLAN[1],
      OR_ANESTHESIA_DESKTOP.PRE_OP_EXAM.ANESTHESIA_PLAN[1],
      false,
      true
    );
    cy.cClick(selectorFactory.getSpanText(planName), planName, false, true);
  }

  /**
   * @details - Close Pre and Post Op Slide Out Tab
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  closePreOpSlideOut() {
    const interceptCollection =
      this.sisAnesthesiaApi.interceptClosePreOpSlideOut();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ANESTHESIA_DESKTOP.PRE_POSTOP_TAB.CROSS_ICON[1],
      OR_ANESTHESIA_DESKTOP.PRE_POSTOP_TAB.CROSS_ICON[1],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Administer Medication in Anesthesia
   * @param medicationInfo - Pass Medication as Model for reference
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  administerMedication(medicationInfo: Medication) {
    const interceptCollection =
      this.sisAnesthesiaApi.interceptAdministerMedication();
    cy.cNotExist(
      OR_ANESTHESIA_DESKTOP.PRE_OP_EXAM.SUB_HEADER[0],
      OR_ANESTHESIA_DESKTOP.PRE_OP_EXAM.SUB_HEADER[0]
    );
    cy.shouldBeEnabled(
      selectorFactory.getButtonLabel(
        OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.SUB_HEADER[0]
      )
    ).then(() => {
      cy.shouldBeEnabled(
        selectorFactory.getButtonSpanText(
          OR_ANESTHESIA_DESKTOP.START_RECORDING[0]
        )
      );
      /**
       * Waiting for Anesthesia Graph Locator to attach to DOM
       */
      cy.get(OR_ANESTHESIA_DESKTOP.ANESTHESIA_GRAPH[1], {
        timeout: Cypress.config('defaultCommandTimeout'),
      })
        .first()
        .should(ShouldMethods.visible);
      cy.cClick(
        OR_ANESTHESIA_DESKTOP.PATIENT_SEARCH_ICON[1],
        OR_ANESTHESIA_DESKTOP.PATIENT_SEARCH_ICON[1],
        false,
        true
      );
      cy.cClick(
        selectorFactory.getSpanText(OR_ANESTHESIA_DESKTOP.MAIN_GRAPH[0]),
        OR_ANESTHESIA_DESKTOP.MAIN_GRAPH[0],
        false,
        true
      );
      cy.cClick(
        OR_ANESTHESIA_DESKTOP.PATIENT_SEARCH_ICON[1],
        OR_ANESTHESIA_DESKTOP.PATIENT_SEARCH_ICON[1],
        false,
        true
      );
    });
    cy.contains(medicationInfo.Medication!)
      .scrollIntoView()
      .click({ force: true });
    cy.cIsVisible(
      selectorFactory.getH3Text(
        OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.SUB_HEADER[0]
      ),
      OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.SUB_HEADER[0]
    );
    cy.cIsEnabled(
      selectorFactory.getButtonLabel(
        OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.NOW[0]
      ),
      OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.NOW[0]
    );
    cy.cClick(
      selectorFactory.getButtonLabel(
        OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.NOW[0]
      ),
      OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.NOW[0]
    );

    if (
      CommonUtils.isDefinedAndNotEmpty(medicationInfo.SisChartsMedication?.Dose)
    ) {
      cy.cType(
        OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.DOSE[1],
        OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.DOSE[0],
        medicationInfo.SisChartsMedication?.Dose,
        false,
        true
      );
    }
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getButtonLabel(DoneOrCancel.done),
      DoneOrCancel.done
    );
    cy.cWaitApis(interceptCollection);
    cy.cNotExist(
      selectorFactory.getH3Text(
        OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.SUB_HEADER[0]
      ),
      OR_ANESTHESIA_DESKTOP.MEDICATION_EVENT.SUB_HEADER[0]
    );
    cy.cIsVisible(medicationInfo.Medication!, medicationInfo.Medication!, true);

    if (
      CommonUtils.isDefinedAndNotEmpty(medicationInfo.SisChartsMedication?.Dose)
    ) {
      cy.cIsVisible(
        medicationInfo.SisChartsMedication!.Dose!.toString(),
        medicationInfo.Medication!,
        true
      );
    }
  }

  /**
   * @details - Add Medication in Anesthesia
   * @param medicationInfo - Pass Medication as Model for reference
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  addAnesthesiaMedication(medicationInfo: Medication) {
    const interceptCollection =
      this.sisAnesthesiaApi.interceptAnesthesiaMedication();
    const interceptCollectionDone =
      this.sisAnesthesiaApi.interceptDoneAdministerMedication();
    cy.shouldBeEnabled(
      selectorFactory.getButtonLabel(
        OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.SUB_HEADER[0]
      )
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getButtonLabel(
        OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.SUB_HEADER[0]
      ),
      OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.SUB_HEADER[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(
      OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.SEARCH_MEDICATIONS[1]
    );
    cy.cType(
      OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.SEARCH_MEDICATIONS[1],
      OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.SEARCH_MEDICATIONS[0],
      medicationInfo.FormularyMedication?.MedicationTemplateName!,
      false,
      true
    );
    cy.cGet(
      selectorFactory.getSpanText(
        medicationInfo.FormularyMedication?.MedicationTemplateName!
      ),
      medicationInfo.FormularyMedication?.MedicationTemplateName!
    )
      .first()
      .should(ShouldMethods.visible)
      .click();
    cy.shouldBeEnabled(selectorFactory.getSpanText(medicationInfo.Medication!));

    if (
      CommonUtils.isDefinedAndNotEmpty(medicationInfo.SisChartsMedication?.Dose)
    ) {
      cy.cType(
        OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.DOSE[1],
        OR_ANESTHESIA_DESKTOP.ADD_MEDICATION.DOSE[0],
        medicationInfo.SisChartsMedication?.Dose!,
        false,
        true
      );
    }
    cy.cIntercept(interceptCollectionDone);
    cy.cClick(
      selectorFactory.getButtonLabel(DoneOrCancel.done),
      DoneOrCancel.done
    );
    cy.cWaitApis(interceptCollectionDone);
    cy.cNotExist(
      selectorFactory.getButtonLabel(DoneOrCancel.done),
      DoneOrCancel.done
    );
    cy.cIsVisible(medicationInfo.Medication!, medicationInfo.Medication!, true);

    if (
      CommonUtils.isDefinedAndNotEmpty(medicationInfo.SisChartsMedication?.Dose)
    ) {
      cy.cIsVisible(
        medicationInfo.SisChartsMedication!.Dose!.toString(),
        medicationInfo.Medication!,
        true
      );
    }
  }
}
