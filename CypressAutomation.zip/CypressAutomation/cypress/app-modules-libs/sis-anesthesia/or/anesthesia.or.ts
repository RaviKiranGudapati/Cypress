import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

export const OR_ANESTHESIA_DESKTOP = {
  SEARCH_PATIENT: ['Search Patient', 'body .search-patient'],
  CONSENTS: {
    CONSENTS: ['Consents'],
    EDIT_CONSENTS_POPUP: {
      PERFORMING_PHYSICIAN: [
        'Performing Physician',
        CommonUtils.concatenate(
          '.physician-data #msItems ',
          CoreCssClasses.MultiSelect.loc_ui_multiselect
        ),
      ],
      DONE: ['Done', '.consent-preview #btnDone'],
      ANESTHESIOLOGIST: ['Anesthesiologist'],
      PHYSICIAN: ['Physician'],
    },
  },
  PRE_POSTOP_TAB: {
    PRE_AND_POSTOP: ['Pre & Post-Op'],
    CROSS_ICON: ['Cross Icon', '.pre-post-op-slider .close-btn-position'],
  },
  PRE_OP_EXAM: {
    SUB_HEADER: ['Pre-Op Exam'],
    ANESTHESIA_PLAN: ['Anesthesia Plan', '#anes_plan'],
  },
  MEDICATION_EVENT: {
    SUB_HEADER: ['Add Medication Administration'],
    NOW: ['Now'],
    DOSE: ['Dose', '#administerDose'],
  },
  IV_FLUIDS: {
    SUB_HEADER: ['IV Fluids'],
  },
  ADD_MEDICATION: {
    SUB_HEADER: ['Add Medication'],
    SEARCH_MEDICATIONS: [
      'Search Available Medications',
      'input[placeholder=" Search"]',
    ],
    DOSE: ['Dose', '.dose-field input'],
  },
  START_RECORDING: ['Start Recording'],
  ANESTHESIA_GRAPH: [
    'Graph',
    '.vitalsgraph svg g[clipPathUnits="userSpaceOnUse"]',
  ],
  PATIENT_SEARCH_ICON: ['Patient Search Icon', '#icon-patient-search'],
  MAIN_GRAPH: ['Main Graph'],
};
