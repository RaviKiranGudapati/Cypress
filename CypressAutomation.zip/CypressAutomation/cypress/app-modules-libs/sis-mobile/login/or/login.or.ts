import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_SIS_MOBILE_LOGIN = {
  LOGIN: {
    LOGIN_WEB_TITLE: 'SIS-Charts',
    USER_NAME: ['Username', `[name='username']`],
    PASSWORD: ['Password', `[name='password']`],
    SIGN_IN: ['Sign In', 'button.confirm-btn'],
  },
  LOGOUT: {
    LOGOUT: ['Logout'],
    LOGOUT_CAPS: ['LOGOUT'],
    INFO_ICON: [
      'Info Icon',
      CommonUtils.concatenate(
        '.physician-header ',
        CoreCssClasses.Icon.loc_user_icon
      ),
    ],
    CONFIRM_DIALOG: ['Confirm Dialog', 'body .ui-confirmdialog'],
  },
};
