/* enum values */
export enum trackers {
  or_board_tracker = 'OR Board Tracker',
  pre_op_pacu_board_tracker = 'Pre-Op/PACU Board Tracker',
  waiting_room_board_tracker = 'Waiting Room Board Tracker',
  surgery_board_tracker = 'Surgery Board Tracker',
}
