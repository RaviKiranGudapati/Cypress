import { SubRoutes, WaitMethods } from "../../../support/common-core-libs/application/constants/sub-routes.constants";
import { ApiEndpoint } from "../../../support/common-core-libs/framework/api-endpoint";

export default class TrackingBoardApi {
    /**
     * @details - After clicking on launch
     * @author Divya
     */
    interceptClickLaunch(): ApiEndpoint[] {
        return [
          new ApiEndpoint(
            WaitMethods.get,
            SubRoutes.get_surgery_board_view,
            'SurgeryBoardView',
            200
          ),
        ];
    }
}