import { SubRoutes, WaitMethods } from "../../../support/common-core-libs/application/constants/sub-routes.constants";
import { ApiEndpoint } from "../../../support/common-core-libs/framework/api-endpoint";

export default class SurgeryBoardApi {
  /**
   * @details - After clicking on gear icon
   * @author Divya
   */
  interceptClickGear(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.column_list,
        'ColumnList',
        200
      ),
    ];
  }

  /**
   * @details - After clicking on done button
   * @author Divya
   */
  interceptDoneInBoardSettings(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.surgery_board_tracker,
        'SurgeryBoard',
        200
      ),
    ];
  }
}