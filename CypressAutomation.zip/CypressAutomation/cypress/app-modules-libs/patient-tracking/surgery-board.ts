import {
  CommonClassAttributes,
  CommonGetLocators,
  ShouldMethods,
  ShowOrHide,
} from '../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../support/common-core-libs/framework/selector-factory';

import { SurgeryBoardTracker } from '../../test-data-models/shared/application-settings/patient-tracking.model';

import { OR_SURGERY_BOARD } from './or/surgery-board.or';

import SurgeryBoardApi from './api/surgery-board.api';

export class SurgeryBoard {
  private surgeryBoardApi = new SurgeryBoardApi();
  /**
   * @details -To select the tracker in patient tracking board list
   * @param surgeryBoardDetails - Surgery board fields are used from model to validate
   * @API API's are not available
   * @author Divya
   */
  verifyColumnValuesByPatient(surgeryBoardDetails: SurgeryBoardTracker) {
    cy.cGet(OR_SURGERY_BOARD.PATIENT_ROW[1]).each(($row) => {
      if ($row.text().includes(surgeryBoardDetails.Patient ?? '')) {
        cy.wrap($row).within(() => {
          for (const [key, value] of Object.entries(surgeryBoardDetails)) {
            if (CommonUtils.isNotEmptyAndUndefined(value)) {
              switch (key) {
                case OR_SURGERY_BOARD.SCHED_OR[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(0)
                    .should(
                      ShouldMethods.class,
                      OR_SURGERY_BOARD.SCHEDULED_OR[0]
                    )
                    .find(CommonGetLocators.span)
                    .should(ShouldMethods.contain, surgeryBoardDetails.SchedOR);
                  break;

                case OR_SURGERY_BOARD.PATIENT[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(1)
                    .should(ShouldMethods.class, OR_SURGERY_BOARD.PATIENT[0])
                    .find(CommonGetLocators.span)
                    .should(ShouldMethods.contain, surgeryBoardDetails.Patient);
                  break;

                case OR_SURGERY_BOARD.PROCEDURE[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(2)
                    .should(ShouldMethods.class, OR_SURGERY_BOARD.PROCEDURE[0])
                    .find(CommonGetLocators.span)
                    .should(($text) => {
                      expect($text.text().trim()).to.contain(
                        surgeryBoardDetails.Procedure
                      );
                    });
                  break;

                case OR_SURGERY_BOARD.ANESTHESIA_TYPE[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(3)
                    .should(
                      ShouldMethods.class,
                      OR_SURGERY_BOARD.ANESTHESIA_TYPE[0]
                    )
                    .find(CommonGetLocators.span)
                    .should(
                      ShouldMethods.contain,
                      surgeryBoardDetails.AnesthesiaType
                    );
                  break;

                case OR_SURGERY_BOARD.SCHED_START_TIME[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(4)
                    .should(
                      ShouldMethods.class,
                      OR_SURGERY_BOARD.SCHEDULED_START[0]
                    )
                    .find(CommonGetLocators.span)
                    .should(
                      ShouldMethods.contain,
                      surgeryBoardDetails.SchedStartTime
                    );
                  break;

                case OR_SURGERY_BOARD.SCHED_END_TIME[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(5)
                    .should(
                      ShouldMethods.class,
                      OR_SURGERY_BOARD.SCHEDULED_END[0]
                    )
                    .find(CommonGetLocators.span)
                    .should(
                      ShouldMethods.contain,
                      surgeryBoardDetails.SchedEndTime
                    );
                  break;

                case OR_SURGERY_BOARD.ARRIVAL_TIME[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(6)
                    .should(
                      ShouldMethods.class,
                      OR_SURGERY_BOARD.ARRIVAL_TIME[0]
                    )
                    .find(CommonGetLocators.span)
                    .should(
                      ShouldMethods.contain,
                      surgeryBoardDetails.ArrivalTime
                    );
                  break;

                case OR_SURGERY_BOARD.SURGEON[0]:
                  cy.cGet(CommonGetLocators.td)
                    .eq(7)
                    .should(ShouldMethods.class, OR_SURGERY_BOARD.SURGEON[0])
                    .find(CommonGetLocators.span)
                    .should(ShouldMethods.contain, surgeryBoardDetails.Surgeon);
                  break;

                case OR_SURGERY_BOARD.LOCATION[0]:
                  const locationValue =
                    surgeryBoardDetails.Location?.split('✓').at(0);
                  cy.cGet(CommonGetLocators.td)
                    .eq(8)
                    .should(ShouldMethods.class, OR_SURGERY_BOARD.LOCATION[0])
                    .as('Location')
                    .find(CommonGetLocators.span)
                    .should(ShouldMethods.contain_text, locationValue);
                  if (surgeryBoardDetails.Location?.endsWith('✓')) {
                    cy.cGet('@Location')
                      .find(CommonGetLocators.i)
                      .should(
                        ShouldMethods.class,
                        CommonClassAttributes.fa_check
                      );
                  }
                  break;

                default:
                  break;
              }
            }
          }
        });
      }
    });
  }

  /**
   * @details -To click gear icon in patient tracking board
   * @API - API's are available - Implemented Completely
   * @author Divya
   */
  clickGearIcon() {
    const interceptCollection = this.surgeryBoardApi.interceptClickGear();
    cy.cIntercept(interceptCollection);
    cy.cGet(OR_SURGERY_BOARD.END_BLOCK[1])
      .find(OR_SURGERY_BOARD.GEAR_ICON[1])
      .click();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details -To click on toggle in board settings only for discharged and unarrived cases
   * @param name - Based on name click on the toggle
   * @param showHide - To click on show or hide toggle
   * @API - API's are not available
   * @author Divya
   */
  clickToggleInBoardSettings(name: string, showHide: string = ShowOrHide.show) {
      cy.cGet(selectorFactory.getAttrHeaderText(name))
        .find(OR_SURGERY_BOARD.BOARD_SETTINGS.TOGGLE[1])
        .within(($switch) => {
          cy.wrap($switch)
            .find(selectorFactory.getDivText(showHide))
            .then(($ele) => {
              if (!$ele.hasClass(CommonClassAttributes.selected)) {
                cy.wrap($ele).click();
              }
            });
        });
  }

  /**
   * @details -To click on Done button in board settings
   * @API -  API's are available - Implemented Completely
   * @author Divya
   */
  clickDoneInBoardSettings() {
    const interceptCollection =
      this.surgeryBoardApi.interceptDoneInBoardSettings();
    cy.cIntercept(interceptCollection);
    cy.cClick(OR_SURGERY_BOARD.BOARD_SETTINGS.DONE[1], '');
    cy.cWaitApis(interceptCollection);
  }
}
