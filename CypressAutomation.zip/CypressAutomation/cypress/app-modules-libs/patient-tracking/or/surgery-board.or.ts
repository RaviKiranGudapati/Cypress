import { CommonGetLocators } from '../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

export const OR_SURGERY_BOARD = {
  PATIENT_ROW: ['Row', CommonUtils.concatenate('.ui-table-wrapper .ui-table-tbody ',CommonGetLocators.tr)],
  SCHED_OR: ['SchedOR'],
  PATIENT: ['Patient'],
  PROCEDURE: ['Procedure'],
  ANESTHESIA_TYPE: ['AnesthesiaType'],
  SCHEDULED_START: ['ScheduledStart'],
  SCHEDULED_END: ['ScheduledEnd'],
  ARRIVAL_TIME: ['ArrivalTime'],
  SURGEON: ['Surgeon'],
  LOCATION: ['Location'],
  SCHEDULED_OR: ['ScheduledOR'],
  SCHED_START_TIME: ['SchedStartTime'],
  SCHED_END_TIME: ['SchedEndTime'],
  END_BLOCK: ['End Block', '.endBlock'],
  GEAR_ICON: ['Gear Icon', CoreCssClasses.Icon.loc_fa_fa_gear],
  BOARD_SETTINGS: {
    TOGGLE: ['Toggle Switch', '.dualswitch'],
    DONE: ['Done', '[data-test-id="btnDone"]'],
  },
};
