import { ShouldMethods } from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

import { OR_LOGIN } from '../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_PHYSICIAN_DESKTOP } from './or/physician-desktop.or';
import { OR_SIS_CHARTS_DESKTOP } from '../../../support/common-core-libs/application/or/sis-charts-desktop.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { PatientDetails } from '../../../test-data-models/sis-office/case/patient-case.model';

import { SISPhysicianDesktopApi } from './api/physician-desktop.api';

class SISPhysicianDesktop extends SISOfficeDesktop {
  private sisPhysicianDesktop = new SISPhysicianDesktopApi();

  /**
   * @details - select Patient from Patient List
   * @param patientDetails - To provide the patientDetails as model reference
   * @APIs are available - Not Implemented
   */
  selectPatientFromPatientList(patientDetails: PatientDetails) {
    cy.cGet(OR_SIS_CHARTS_DESKTOP.SCHEDULE_TYPE.PATIENT_DATA[1]).within(() => {
      const plName = patientDetails.LastName;
      //TODO : Need to Implement API
      cy.cClick(selectorFactory.getSpanText(plName!), plName!);
    });
  }

  /**
   * @details - select Patient from Incomplete Tracker
   * @param patientName - To provide the patient name while using the function
   * @APIs are available - Not Implemented
   */
  selectIncompleteTrackerPatientConsents(patientName: string) {
    //TODO : Need to Implement API
    cy.cClick(
      selectorFactory.incompleteTrackerConsents(patientName),
      patientName
    );
  }

  /**
   * @details - Verify the procedures in Text area for consents
   * @param consentName - To provide the consents name
   * @param procedureNames - To provide the procedure names
   * @APIs are not available
   */
  verifyProceduresInConsentsTab(consentName: string, procedureNames: string) {
    cy.cGet(selectorFactory.getH4Text(consentName))
      .parents(
        OR_PHYSICIAN_DESKTOP.CASE_CONSENTS.CONSENTS_POPUP.CONSENTS_CONTAINER[1]
      )
      .within(() => {
        cy.cGet(
          OR_PHYSICIAN_DESKTOP.CASE_CONSENTS.CONSENTS_POPUP
            .PROCEDURES_TEXTAREA[1]
        ).should(ShouldMethods.value, procedureNames);
      });
  }

  /**
   * @details - logout the application
   * @APIs are available - Not Implemented
   */
  logout() {
    this.selectOptionInUserMenuDropdown(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.LOGOUT[0]
    );
    //TODO : Need to Implement API
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.LOGOUT_CONFIRMATION.YES[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.LOGOUT_CONFIRMATION.YES[0],
      false,
      true
    );
    this.pageTitle.should(ShouldMethods.eq, OR_LOGIN.LOGIN.LOGIN_WEB_TITLE);
  }

  /**
   * @details - Click on consents from My Tasks in Physician Desktop
   * @APIs are available - Not Implemented
   */
  clickConsentsTask() {
    //TODO : Need to Implement API
    cy.cClick(
      OR_PHYSICIAN_DESKTOP.MY_TASKS.CONSENTS[1],
      OR_PHYSICIAN_DESKTOP.MY_TASKS.CONSENTS[0]
    );
  }

  /**
   * @details - Click on consents from My Tasks in Physician Desktop
   * @param consent - To provide the consents name as argument
   * @param isDisplayed - To check the consent as displayed
   * @APIs are not available
   */
  verifyConsentsName(consent: string, isDisplayed: boolean = true) {
    cy.cIsVisible(
      selectorFactory.getH4Text(consent),
      consent,
      false,
      isDisplayed
    );
  }

  /**
   * @details - Select tasks in My Tasks
   * @param  task - To pass different module to navigate across My tasks
   * @author - Madhu Kiran
   */
  selectTaskInMyTasksInPhysicianDesktop(task: string) {
    let interceptCollection: ApiEndpoint[] = [];
    switch (task) {
      case OR_PHYSICIAN_DESKTOP.MY_TASKS.CONSENTS[0]:
        interceptCollection =
          this.sisPhysicianDesktop.interceptSelectTaskInMyTak();
        break;
      case OR_PHYSICIAN_DESKTOP.MY_TASKS.ATTACHMENTS[0]:
        //TODO: check Intercepts
        break;
      case OR_PHYSICIAN_DESKTOP.MY_TASKS.IMAGES[0]:
        //TODO: check Intercepts
        break;
      case OR_PHYSICIAN_DESKTOP.MY_TASKS.H_P[0]:
        //TODO: check Intercepts
        break;
      case OR_PHYSICIAN_DESKTOP.MY_TASKS.ORDERS[0]:
        //TODO: check Intercepts
        break;
      case OR_PHYSICIAN_DESKTOP.MY_TASKS.DISCHARGE_INSTRUCTIONS[0]:
        //TODO: check Intercepts
        break;
      case OR_PHYSICIAN_DESKTOP.MY_TASKS.OP_NOTES[0]:
        //TODO: check Intercepts
        break;
      default:
        break;
    }
    cy.cIntercept(interceptCollection);
    cy.cClick(task, task, true, false, { force: true });
    cy.cWaitApis(interceptCollection);
  }
}
export default SISPhysicianDesktop;
