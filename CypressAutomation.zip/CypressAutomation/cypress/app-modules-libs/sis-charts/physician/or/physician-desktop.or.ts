import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_PHYSICIAN_DESKTOP = {
  CASE_CONSENTS: {
    CONSENTS_POPUP: {
      PERFORMING_PHYSICIAN: [
        'Performing Physician',
        CommonUtils.concatenate(
          '#btn_csi_sp_consent ',
          CoreCssClasses.DropDown.loc_fa_dropdown_arrow
        ),
      ],
      PROCEDURES_TEXTAREA: [
        'Procedures Text Area',
        `textarea[placeholder="Enter Procedure"]`,
      ],
      CONSENTS_CONTAINER: ['Consents Container', '.phy-consents-container'],
      DONE: ['Done'],
    },
  },

  MY_TASKS: {
    ATTACHMENTS: ['Attachments'],
    IMAGES: ['Images'],
    CONSENTS: ['Consents', '#Consents_link_2'],
    H_P: ['H & P'],
    ORDERS: ['Orders'],
    DISCHARGE_INSTRUCTIONS: ['Discharge Instructions'],
    OP_NOTES: ['Op Notes'],
  },
};
