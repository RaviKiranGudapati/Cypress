export const OR_INSTRUCTIONS = {
    PRE_ADMIT: {
      SUB_HEADER: ['PRE-ADMIT'],
      PANEL: ['Panel', '.panel'],
      INSTRUCTIONS: {
        SUB_HEADER: ['Instructions'],
        WORKLIST_ICON: ['WorkList Icon', `li[ng-if*='Worklist']`],
        WORKLIST_POPUP: [
          'Worklist Pop-up',
          `.load-worklist-modal .worklist-checklist`,
        ],
        EDIT_TEXT: ['Edit Text', `.documentsRow input`],
        ERROR_MESSAGE: ['Error Message', `.error-message`],
        OVERRIDE_WORKLIST_POPUP: [
          'Override Current Worklist',
          '.user-prompt-error',
        ],
        PRE_ADMIT_INSTRUCTIONS_WORKLISTS: [`Pre-Admit Instructions Worklists`],
      },
    },
  };
  