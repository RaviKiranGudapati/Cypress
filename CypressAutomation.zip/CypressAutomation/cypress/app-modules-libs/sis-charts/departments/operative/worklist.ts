import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';
import { Operative } from '../../../../test-data-models/sis-charts/operative.model';

import { OR_RECOVERY } from '../recovery/or/recovery.or';
import { OR_OPERATIVE } from './or/operative.or';

import WorklistApi from './api/worklist.api';

class OperativeWorkList {
  private worklistApi = new WorklistApi();

  /**
   * @details - To verify the procedure details under Case Details section
   * @param procedureData
   * @API - API's are not available
   */
  verifyProcedureDetails(procedureData: string) {
    cy.cHasValue(
      OR_OPERATIVE.WORK_LIST.CASE_DETAILS.PROCEDURE[1],
      OR_OPERATIVE.WORK_LIST.CASE_DETAILS.PROCEDURE[0],
      procedureData
    );
  }

  /**
   * @details Click on Enter-In Out Time button
   * @API - API's are available and Implemented Completely
   * @author - Arushi
   */
  clickEnterInOutTime() {
    const interceptCollection =
      this.worklistApi.interceptClickAddInOrOutButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_RECOVERY.RECOVERY.ENTER_IN_OUT_BUTTON[1],
      OR_RECOVERY.RECOVERY.ENTER_IN_OUT_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Enter Admission Time
   * @param operative
   * @API - API's are available and Implemented Completely
   * @author - Dharani
   */
  enterAdmissionTime(operative: Operative) {
    const interceptCollection =
      this.worklistApi.interceptEnterAdmissionTimeApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.ADMISSION_TIME[1],
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.ADMISSION_TIME[0],
      operative.AdmissionTime ?? ''
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Select room value from dropdown
   * @param operative
   * @API - API's are available and Implemented Completely
   * @author - Dharani
   */
  clickRoomDropdown(operative: Operative) {
    const interceptCollection =
      this.worklistApi.interceptSelectRoomDropdownApi();
    cy.cClick(
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.ROOM_DROP_DOWN[1],
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.ROOM_DROP_DOWN[0],
      false,
      true
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getSpanText(operative.Room!),
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.ROOM_DROP_DOWN[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details click on Operative Time Out button
   * @API - API's are available and Implemented Completely
   * @author - Dharani
   */
  clickOperativeTimeOut() {
    const interceptCollection =
      this.worklistApi.interceptClickOperativeTimeOutApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getButtonText(
        OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TIME_OUT_POPUP
          .SUB_HEADER[0]
      ),
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TIME_OUT_POPUP
        .SUB_HEADER[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details click on sign button in operative time out popup
   * @API - API's are available and Implemented Completely
   * @author - Dharani
   */
  clickSignInOperativeTimeOut() {
    const interceptCollection =
      this.worklistApi.interceptClickSignInOperativeTimeoutApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TIME_OUT_POPUP.SIGN[1],
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TIME_OUT_POPUP.SIGN[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details click on Done button in Operative Time Out Popup
   * @API - API's are available and Implemented Completely
   * @author - Dharani
   */
  clickDoneInOperativeTimeOut() {
    const interceptCollection =
      this.worklistApi.interceptClickDoneInOperativeTimeoutApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TIME_OUT_POPUP.DONE[1],
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TIME_OUT_POPUP.DONE[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Enter Incision Start Time
   * @param operative
   * @API - API's Not Required
   */
  enterIncisionStartTime(operative: Operative) {
    cy.cType(
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_INCISION_START_TIME[1],
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_INCISION_START_TIME[0],
      operative.IncisionStartTime ?? ''
    );
  }

  /**
   * @details Click on Transfer button
   * @API - API's are available and Implemented Completely
   * @author - Dharani
   */
  clickTransfer() {
    const interceptCollection = this.worklistApi.interceptClickTransferApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TRANSFER[1],
      OR_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP.OPERATIVE_TRANSFER[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }
}
export default OperativeWorkList;
