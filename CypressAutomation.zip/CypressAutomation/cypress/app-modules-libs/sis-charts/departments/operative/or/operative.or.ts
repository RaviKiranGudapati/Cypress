import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const OR_OPERATIVE = {
  OPERATIVE_PANEL: ['Operative', '#Operative'],
  WORK_LIST: {
    OPERATIVE_WORK_LISTS: ['Operative Worklists', '.load-worklist-modal'],
    CASE_DETAILS: {
      PROCEDURE: ['Procedure', '#ta_P_'],
    },
  },
  ENTER_IN_OUT_TIME_POP_UP: {
    ADMISSION_TIME: ['Admission Time', '#operative_admission_time_showtime'],
    ADMISSION_TIME_NOW_BUTTON: ['Now', '#ope_admission_time_btn'],
    ROOM_DROP_DOWN: [
      'Room',
      CommonUtils.concatenate(
        '#ope_room_select #ssDiv_ ',
        CoreCssClasses.DropDown.loc_fa_dropdown_angle_down
      ),
    ],
    OPERATIVE_TIME_OUT_POPUP: {
      SUB_HEADER: ['Operative Time Out'],
      SIGN: ['Sign', '#attachment_sign1_btn'],
      DONE: ['Done', '#attachment_doneorwait_btn'],
    },
    OPERATIVE_INCISION_START_TIME: [
      'Incision Start Time',
      `input[id='operative_Incision Start_showtime']`,
    ],
    OPERATIVE_TRANSFER: ['Transfer', '#oto_transfer_btn'],
  },
};
