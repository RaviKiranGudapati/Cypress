import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import SISChartsDesktop from '../../../../support/common-core-libs/application/sis-charts-desktop';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';

import { CommonDepartmentInformation } from '../../../../test-data-models/sis-charts/sis-charts-department-model';

import { OR_OPERATIVE } from './or/operative.or';

import { NursingDept } from '../../facesheet/enums/charts-cover-facesheet.enum';

/* instance variables */
const sisChartsDesktop = new SISChartsDesktop();

export default class OperativeDepartment {
  /**
   * @details - To enter admission time
   * @param deptInfo - Using AdmissionTime and Room in CommonDepartmentInformation
   * @API - API's are not available
   * @author Divya
   */
  enterAdmissionTimeRoom(deptInfo: CommonDepartmentInformation) {
    sisChartsDesktop.clickEnterInOutTIme();
    sisChartsDesktop.enterAdmissionTime(
      NursingDept.operative,
      deptInfo.AdmissionTime!
    );
    if (deptInfo.Room != undefined) {
      sisChartsDesktop.selectRoom(NursingDept.operative, deptInfo.Room!);
    }
  }
}
