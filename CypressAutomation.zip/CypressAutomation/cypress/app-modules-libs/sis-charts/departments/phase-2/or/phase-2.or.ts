import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const OR_PHASE2 = {
  PHASE2_PANEL: ['Phase 2', '#phase2-tmp'],
  ENTER_IN_OUT_TIME_POP_UP: {
    ADMISSION_TIME: ['Admission Time', '#phase2-tmp #_showtime'],
    ROOM_DROPDOWN: [
      'Room',
      CommonUtils.concatenate(
        '#phase2-tmp #aocp2_room_select ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
  },
};
