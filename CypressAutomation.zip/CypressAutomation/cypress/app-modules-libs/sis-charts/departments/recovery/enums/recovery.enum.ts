export enum DischargeCaseStatus {
    performed = 'Performed',
    partially_performed_billable = 'Partially Performed/Billable',
    partially_performed_non_billable = 'Partially Performed/Non-Billable',
  }