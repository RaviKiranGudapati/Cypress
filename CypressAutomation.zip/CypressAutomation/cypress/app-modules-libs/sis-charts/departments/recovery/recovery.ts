import SISChartsDesktop from '../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../support/common-core-libs/application/sis-office-desktop';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

import {
  CommonDepartmentInformation,
  Recovery,
} from '../../../../test-data-models/sis-charts/sis-charts-department-model';

import { NursingDept } from '../../facesheet/enums/charts-cover-facesheet.enum';

import { OR_RECOVERY } from './or/recovery.or';

import RecoveryDepartmentApi from './api/recovery.api';
import { DischargeCaseStatus } from './enums/recovery.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();

/* const values */
const dischargedTo = 'Admitted as an inpatient to this hospital.';

export default class RecoveryDepartment {
  constructor(private recoveryInfo: Recovery) {}
  private recoveryDepartment = new RecoveryDepartmentApi();
  private orRecovery = OR_RECOVERY.RECOVERY.RECOVERY_ENTER_IN_OUT_POPUP;

  /**
   * @details Discharge the Patient Case in Recovery Department
   * @param caseStatus - pass discharge status
   * @API - API's are available - Implemented completely
   * @author - chandrika
   */
  dischargePatientInOutsideFacility(
    caseStatus: string = DischargeCaseStatus.performed
  ) {
    const interceptEnterInAndOutTimeApiCollection =
      this.recoveryDepartment.interceptEnterInAndOutTimeApi();
    cy.cIntercept(interceptEnterInAndOutTimeApiCollection);

    sisChartsDesktop.clickEnterInOutTIme();
    cy.cWaitApis(interceptEnterInAndOutTimeApiCollection);

    const interceptEnterTimeApiCollection =
      this.recoveryDepartment.interceptEnterTimeApi();
    cy.cIntercept(interceptEnterTimeApiCollection);
    cy.cType(
      this.orRecovery.ADMISSION_TIME[1],
      this.orRecovery.ADMISSION_TIME[0],
      this.recoveryInfo.AdmissionTime
    );
    cy.cGet(OR_RECOVERY.RECOVERY.HEADER[1]).click();
    cy.cWaitApis(interceptEnterTimeApiCollection);
    //Need to ask for the tab functionality
    if (this.recoveryInfo.Room) {
      const interceptRoomApiCollection =
        this.recoveryDepartment.interceptRoomApi();
      cy.cIntercept(interceptRoomApiCollection);
      cy.cClick(
        this.orRecovery.ROOM_DROPDOWN[1],
        this.orRecovery.ROOM_DROPDOWN[0]
      );
      cy.cGet(this.orRecovery.ROOM_NAME[1])
        .contains(this.recoveryInfo.Room!)
        .click({ force: true });
      cy.cWaitApis(interceptRoomApiCollection);
    }

    const interceptTransferApiCollection =
      this.recoveryDepartment.interceptTransferApi();
    cy.cIntercept(interceptTransferApiCollection);
    cy.cClick(
      this.orRecovery.TRANSFER_BUTTON[1],
      this.orRecovery.TRANSFER_BUTTON[0],
      false,
      true
    );
    cy.cWaitApis(interceptTransferApiCollection);
    this.caseDischarge(caseStatus);
  }

  /**
   * @details - To enter admission time and select room in Recovery
   * @param deptInfo - Using AdmissionTime and Room in CommonDepartmentInformation
   * @API - API's are not available
   * @author -Divya
   */
  enterAdmissionTimeRoom(deptInfo: CommonDepartmentInformation) {
    sisChartsDesktop.clickEnterInOutTIme();
    sisChartsDesktop.enterAdmissionTime(
      NursingDept.recovery,
      deptInfo.AdmissionTime!
    );
    if (deptInfo.Room != undefined) {
      sisChartsDesktop.selectRoom(NursingDept.recovery, deptInfo.Room!);
    }
  }

  /**
   * @details To discharge the case from patient hands off popup
   * @param caseStatus - pass discharge status
   * @API - API's are available - Implemented completely
   * @author - Praveen
   */
  caseDischarge(caseStatus: string = DischargeCaseStatus.performed) {
    cy.cClick(
      this.orRecovery.TRANSFER_POPUP.DISCHARGE_NOW_BUTTON[1],
      this.orRecovery.TRANSFER_POPUP.DISCHARGE_NOW_BUTTON[0],
      false,
      true
    );

    cy.cClick(
      this.orRecovery.TRANSFER_POPUP.DISCHARGED_TO[1],
      this.orRecovery.TRANSFER_POPUP.DISCHARGED_TO[0],
      false,
      true
    );

    cy.cClick(
      selectorFactory.getSpanText(dischargedTo),
      dischargedTo,
      false,
      true,
      { force: true }
    );

    cy.cType(
      this.orRecovery.TRANSFER_POPUP.DISCHARGE_TIME[1],
      this.orRecovery.TRANSFER_POPUP.DISCHARGE_TIME[0],
      this.recoveryInfo.DischargeTime
    );

    if (
      caseStatus == DischargeCaseStatus.partially_performed_billable ||
      caseStatus == DischargeCaseStatus.partially_performed_non_billable
    ) {
      cy.cClick(
        OR_RECOVERY.RECOVERY.RECOVERY_ENTER_IN_OUT_POPUP.TRANSFER_POPUP
          .CASE_STATUS[1],
        OR_RECOVERY.RECOVERY.RECOVERY_ENTER_IN_OUT_POPUP.TRANSFER_POPUP
          .CASE_STATUS[0],
        false,
        true
      );
      cy.shouldBeEnabled(selectorFactory.getSpanText(caseStatus));
      cy.cClick(
        selectorFactory.getSpanText(caseStatus),
        caseStatus,
        false,
        true
      );
    }

    const interceptCollection = this.recoveryDepartment.interceptDoneApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.orRecovery.TRANSFER_POPUP.DONE_BUTTON[1],
      this.orRecovery.TRANSFER_POPUP.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);

    sisOfficeDesktop.selectSisLogo();
  }
}
