export enum PrintToggleButtons {
    VIEW = 'button_id',
    LAYOUT = 'layout_id',
    PAGE_BREAK = 'pageBreak_id',
    REMOVE_PATIENT_INFO = 'removePatientInfo_id',
    INCLUDE_ESTIMATED_REVENUE = 'includeEstimatedRevenue_id',
  }