import {
  CommonClassAttributes,
  FilterMethods,
  InvokeAttributes,
  ShouldMethods,
  YesOrNo,
} from '../../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

import { AppColors } from '../../../../support/common-core-libs/application/constants/app-colors.constants';

import { OR_CHARTS_SCHEDULE_PRINT } from './or/charts-schedule-print.or';

import { PrintToggleButtons } from './enums/charts-schedule-print.enum';

class ChartsSchedulePrint {
  /**
   * @details - Selecting print options in sis charts print pop up
   * @param - option
   * @API - API's are available - Not Implemented
   */
  selectPreviewOptionInPrintPopup(option: string) {
    cy.cClick(selectorFactory.getSpanText(option), option);
    cy.cClick(
      selectorFactory.getSpanText(OR_CHARTS_SCHEDULE_PRINT.PREVIEW[0]),
      OR_CHARTS_SCHEDULE_PRINT.PREVIEW[0]
    );
  }

  /**
   * @details -To select toggle physician/Room
   * @param - option
   * @API - API's are not available
   */
  selectViewButton(option: string) {
    const color = ChartsSchedulePrint.getColor(PrintToggleButtons.VIEW);
    if (
      option.toUpperCase() ===
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.VIEW.PHYSICIAN[0]
    ) {
      if (!(color === AppColors.component_enabled_toggle_button_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.VIEW.TOGGLE_BUTTON[1],
          option
        );
      }
    } else if (
      option.toUpperCase() ===
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.VIEW.ROOM[0]
    ) {
      if (!(color === AppColors.component_enabled_toggle_button_not_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.VIEW.TOGGLE_BUTTON[1],
          option
        );
      }
    }
  }

  /**
   * @details -To select toggle portrait/landscape
   * @param - option
   * @API - API's are available - Not Implemented
   */
  selectLayoutButton(option: string) {
    const color = ChartsSchedulePrint.getColor(PrintToggleButtons.LAYOUT);

    if (
      option.toUpperCase() ===
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.LAYOUT.PORTRAIT[0]
    ) {
      if (!(color === AppColors.component_enabled_toggle_button_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.LAYOUT.TOGGLE_BUTTON[1],
          option
        );
      }
    } else if (
      option.toUpperCase() ===
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.LAYOUT.LANDSCAPE[0]
    ) {
      if (!(color === AppColors.component_enabled_toggle_button_not_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.LAYOUT.TOGGLE_BUTTON[1],
          option
        );
      }
    }
  }

  /**
   * @details -To select toggle page break
   * @param - option
   * @API - API's are available - Not Implemented
   */
  selectPageBreakButton(option: string) {
    const color = ChartsSchedulePrint.getColor(PrintToggleButtons.PAGE_BREAK);
    if (option.toUpperCase() === YesOrNo.yes) {
      if (!(color === AppColors.component_enabled_toggle_button_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.PAGE_BREAK
            .TOGGLE_BUTTON[1],
          option
        );
      }
    } else if (option.toUpperCase() === YesOrNo.no) {
      if (!(color === AppColors.component_enabled_toggle_button_not_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.PAGE_BREAK
            .TOGGLE_BUTTON[1],
          option
        );
      }
    }
  }

  /**
   * @details -To select toggle yes/No in remove patient info button
   * @param - option
   * @API - API's are available - Not Implemented
   */
  selectRemovePatientInfoButton(option: string) {
    const color = ChartsSchedulePrint.getColor(PrintToggleButtons.LAYOUT);
    if (option.toUpperCase() === YesOrNo.yes) {
      if (!(color === AppColors.component_enabled_toggle_button_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.REMOVE_PATIENT_INFO
            .TOGGLE_BUTTON[1],
          option
        );
      }
    } else if (option.toUpperCase() === YesOrNo.no) {
      if (!(color === AppColors.component_enabled_toggle_button_not_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.REMOVE_PATIENT_INFO
            .TOGGLE_BUTTON[1],
          option
        );
      }
    }
  }

  /**
   * @details -To select include estimate revenue button in schedule grid
   * @param - option
   * @API - Function depricated
   */
  selectIncludeEstimateRevenueButton(option: string) {
    const color = ChartsSchedulePrint.getColor(PrintToggleButtons.LAYOUT);
    if (option.toUpperCase() === YesOrNo.yes) {
      if (!(color === AppColors.component_enabled_toggle_button_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.INCLUDE_ESTIMATED_REVENUE
            .TOGGLE_BUTTON[1],
          option
        );
      }
    } else if (option.toUpperCase() === YesOrNo.no) {
      if (!(color === AppColors.component_enabled_toggle_button_not_selected)) {
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.INCLUDE_ESTIMATED_REVENUE
            .TOGGLE_BUTTON[1],
          option
        );
      }
    }
  }

  /**
   * @details - Verify Group by default option as physician
   * @API - API's are not available
   */
  verifyGroupByDefaultOptionAsPhysician() {
    cy.cGet(
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.GROUP_BY[1],
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.GROUP_BY[0]
    ).then(($text) => {
      cy.wrap($text).should(
        ShouldMethods.contain,
        OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.VIEW.PHYSICIAN[0]
      );
    });
  }

  /**
   * @details -Close print preview
   * @API - API's are available - Not Implemented
   */
  ClosePrintPreview() {
    cy.cClick(
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.CLOSE_ICON[1],
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.CLOSE_ICON[0]
    );
  }

  /**
   * @details -Verify refresh  button
   * @param  isDisabled - To pass the argument for check the refresh button
   * @API - API's are  not available
   */
  verifyRefreshButton(IsDisabled: boolean) {
    if (IsDisabled) {
      cy.cGet(
        OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.REFRESH_BUTTON[1]
      ).should(
        ShouldMethods.attribute,
        CommonClassAttributes.disabled,
        CommonClassAttributes.disabled
      );
    } else {
      cy.cIsEnabled(
        OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.REFRESH_BUTTON[1],
        OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.REFRESH_BUTTON[0],
        false,
        true
      );
    }
  }

  static getColor(button: PrintToggleButtons) {
    const labelTag = document.getElementsByClassName(
      CommonClassAttributes.on_off_switch
    );
    let pillBox, color;
    for (let i = 0; i < labelTag.length; i++) {
      if (
        labelTag[i].attributes.getNamedItem(CommonClassAttributes.for)
          ?.nodeValue === button
      ) {
        pillBox = labelTag[i].firstElementChild!;
        color = window
          .getComputedStyle(pillBox, FilterMethods.before)
          .getPropertyValue(InvokeAttributes.backgroundColor);
      }
    }
    return color;
  }
}
export default ChartsSchedulePrint;