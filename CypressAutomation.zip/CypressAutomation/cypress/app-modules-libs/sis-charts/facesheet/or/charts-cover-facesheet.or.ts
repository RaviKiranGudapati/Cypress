import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_CHARTS_COVER_FACE_SHEET = {
  DEPARTMENTS: {
    LIST: ['Deaprtment List', 'div.department-div'],
    PRE_OPERATIVE: [
      'Pre-Operative',
      CommonUtils.concatenate(
        'div.department-',
        selectorFactory.getDivText('Pre-Operative')
      ),
    ],
    OPERATIVE: [
      'Operative',
      CommonUtils.concatenate(
        'div.department-',
        selectorFactory.getDivText('Operative')
      ),
    ],
    RECOVERY: [
      'Recovery',
      CommonUtils.concatenate(
        'div.department-',
        selectorFactory.getDivText('Recovery')
      ),
    ],
    CONSENTS: ['Consents', '#cdetails_consents_icon'],
    PHASE1: [
      'Phase 1',
      CommonUtils.concatenate(
        'div.department-',
        selectorFactory.getDivText('Phase 1')
      ),
    ],
    PHASE2: [
      'Phase 2',
      CommonUtils.concatenate(
        'div.department-',
        selectorFactory.getDivText('Phase 2')
      ),
    ],
    PHASE3: [
      'Phase 3',
      CommonUtils.concatenate(
        'div.department-',
        selectorFactory.getDivText('Phase 3')
      ),
    ],
  },
  MY_TASKS: {
    DOCUMENTS: ['Document', selectorFactory.getDivText('DOCUMENTS')],
    PHYSICIAN: ['Physician', selectorFactory.getDivText('PHYSICIAN')],
    PRE_ADMIT: [
      'Pre-Admit',
      CommonUtils.concatenate(
        '.moduleTitle ',
        selectorFactory.getDivText('PRE-ADMIT')
      ),
    ],
    PRE_OP: [
      'Pre-Op',
      CommonUtils.concatenate(
        '.moduleTitle ',
        selectorFactory.getDivText('PRE-OP')
      ),
    ],
    OPERATIVE: ['Operative', selectorFactory.getDivText('OPERATIVE')],
    RECOVERY: ['Recovery', selectorFactory.getDivText('RECOVERY')],
    POST_OP_QX: ['Post-Op Qx', selectorFactory.getDivText('POST-OP QX')],
    ADD_WORKLIST_ICON: [
      'Add Worklist Icon',
      CommonUtils.concatenate(
        CoreCssClasses.ClassPrefix.loc_fa_fa,
        '-list-alt'
      ),
    ],
    QUESTIONNAIRE: ['Questionnaire', 'div.progress-bar-incomplete'],
    WORKLIST_POPUP: ['Worklist', 'div.load-worklist-modal'],
    ALL_WORKLISTS: [
      'All Worklists',
      selectorFactory.getLabelText('All Worklists'),
    ],
    CURRENT_SPECIALTY_WORKLISTS: [
      'Current Specialty Worklists',
      selectorFactory.getLabelText('Current Specialty Worklists'),
    ],
    QUESTIONNAIRE_PROGRESS: [
      'Questionnarie',
      '#worklistDocumentationHeader .progress',
    ],
    QUESTIONNAIRE_PRINT_ICON: ['Print Icon', '[id*="pcp_print_icon"]'],
    CONTACT_LOG: ['Contact Log', '.button-cont'],
    OPERATIVE_CONSENT: {
      CONSENTS: {
        CONSENTS_HEADER: ['Consents', '.consents-task > .title'],
        CONSENT_NAME: ['Consent Name', `table [title='Consent Name']`],
        WORKLIST: {
          WORKLIST_PANEL_LABEL: [
            'WORKLIST',
            CommonUtils.concatenate(
              '.selectedPanel ',
              selectorFactory.getSpanText('Worklist')
            ),
          ],
          PROGRESS_LOADER: [
            'Progress Loader',
            'div[class*="flex-grow progress"]',
          ],
          ADD_WORKLIST_ICON: ['Worklist icon', 'li[ng-click*="getWorklist"] i'],
          WORKLIST_SEARCH: ['Worklist search', '.worklist-search'],
          SUPPLIES: {
            SUPPLIES_SEARCH: [
              'Search by name or inv #',
              'tr[ng-repeat-start*="supplies"] [class*="external-inventory"] input',
            ],
          },
          IMPLANTS: {
            IMPLANT_IOS_SEARCH: [
              'Search by name or inv #',
              'div[class*="implant-ios"] input',
            ],
            IMPLANT_FREE_TEXT_ICON: [
              'Free Text',
              'div[class*="implant-ios"] i',
            ],
            MANUFACTURER_IOS_SEARCH: [
              'Search by name or inv #',
              'div[class*="manufacturer-ios"] input',
            ],
            MANUFACTURER_FREE_TEXT_ICON: [
              'Free Text',
              'div[class*="manufacturer-ios"] i',
            ],
            QUANTITY: ['Quantity', 'input[placeholder="Quantity"]'],
            SIZE: ['Size', 'input[placeholder="Size"]'],
          },
        },
      },
    },
    PRE_ADMIT_QX: {
      ALCOHOL: ['Alcohol', '#ssDiv_alcohol_ div.dropdown-btn'],
      TOBACCO: ['Tobacco', '#ssDiv_tobacco_ div.dropdown-btn'],
      DRUG_USE: ['Drug Use', '#btn_drug_ span'],
      DRUG_USE_ITEMS: ['List Items', '[drop-down-id="drug_"] li'],
      ADD_NOTES: ['Add Notes', '#a_anl_'],
    },
    ADD: {
      ADD_NEW_ITEM: ['Add New Item', '.add-item'],
      ADD_WINDOW: ['Add Window', '.modal-body.add-popup'],
      ADD_ITEM_ALCOHOL: ['Add Alcohol', `[dictionary-item-id='ssd_alcohol_']`],
      ADD_ITEM_TOBACCO: ['Add Tobacco', `[dictionary-item-id='ssd_tobacco_']`],
      ADD_ITEM_DRUG_USE: ['Add Drug Use', `[dictionary-item-id='a_drug_']`],
      ITEM: ['Item', '#txt_'],
      CANCEL: ['Cancel', '#btnCancel_'],
      SAVE: ['Save', '#btnSave_'],
    },
    OPERATIVE_SUPPLIES: {
      OPERATIVE: [
        'Operative',
        CommonUtils.concatenate(
          CommonGetLocators.th,
          '[class*="current"] ',
          selectorFactory.getDivText('Operative')
        ),
      ],
      WORKLIST: {
        PROGRESS_LOADER: [
          'Progress Loader',
          CommonUtils.concatenate(
            CommonGetLocators.div,
            '[class*="flex-grow progress"]'
          ),
        ],
        ADD_WORKLIST_ICON: [
          'Worklist icon',
          CommonUtils.concatenate(
            CommonGetLocators.li,
            '[ng-click*="getWorklist"] ',
            CommonGetLocators.i
          ),
        ],
        WORKLIST_SEARCH: ['Worklist search', '.worklist-search'],
        SUPPLIES: {
          SUPPLIES_SEARCH: [
            'Search by name or inv #',
            CommonUtils.concatenate(
              CommonGetLocators.tr,
              '[ng-repeat-start*="supplies"] [class*="external-inventory"] ',
              CommonGetLocators.input
            ),
          ],
        },
        IMPLANTS: {
          IMPLANT_IOS_SEARCH: [
            'Search by name or inv #',
            CommonUtils.concatenate(
              CommonGetLocators.div,
              '[class*="implant-ios"] ',
              CommonGetLocators.input
            ),
          ],
          IMPLANT_FREE_TEXT_ICON: [
            'Free Text',
            CommonUtils.concatenate(
              CommonGetLocators.div,
              '[class*="implant-ios"] ',
              CommonGetLocators.i
            ),
          ],
          MANUFACTURER_IOS_SEARCH: [
            'Search by name or inv #',
            CommonUtils.concatenate(
              CommonGetLocators.div,
              '[class*="manufacturer-ios"] ',
              CommonGetLocators.input
            ),
          ],
          MANUFACTURER_FREE_TEXT_ICON: [
            'Free Text',
            CommonUtils.concatenate(
              CommonGetLocators.div,
              '[class*="manufacturer-ios"] ',
              CommonGetLocators.i
            ),
          ],
          QUANTITY: [
            'Quantity',
            CommonUtils.concatenate(
              CommonGetLocators.input,
              '[placeholder="Quantity"]'
            ),
          ],
          SIZE: [
            'Size',
            CommonUtils.concatenate(
              CommonGetLocators.input,
              '[placeholder="Size"]'
            ),
          ],
        },
      },
    },
    ORDERS: {
      SUB_HEADER: ['Orders'],
      ADD_MEDICATION: ['Add Medication', '#btn_add_medi_order'],
      ACKNOWLEDGE: [
        'Acknowledge',
        selectorFactory.getButtonText('Acknowledge'),
      ],
      ADMINISTER: [
        'Administer',
        CommonUtils.concatenate(
          'primary-button ',
          selectorFactory.getButtonText('Administer')
        ),
      ],
      NOW: ['Now', selectorFactory.getButtonText('Now')],
      DOSE: ['Dose', `decimal-text-box[place-holder-text="Dose"] input`],
      DONE: ['Done', selectorFactory.getButtonText('Done')],
    },
    PENCIL_ICON: [
      'Pencil Icon',
      CommonUtils.concatenate(CommonGetLocators.i, '[class*="pencil"]'),
    ],
    SIGN_BUTTON: [
      'sign button ',
      CommonUtils.concatenate(CommonGetLocators.button, '[class*="sign"]'),
    ],
    OVERRIDE_BUTTON: [
      'override button',
      CommonUtils.concatenate(
        CommonGetLocators.button,
        '[data-test-id*="override"]'
      ),
    ],
    FACESHEET_HOME_BUTTON: ['Facesheet Home Button', '#facesheet-home-button'],
    CASE_DETAILS_SIGN: ['Sign', '#cdetails_unsign_icon'],
    CASE_DETAILS_UNSIGN: ['UnSign', '#cdetails_sign_icon'],
    UN_SIGN_DEPARTMENT: ['Un-Sign Department'],
    WORKLIST: {
      SUPPLY_INFO_TOOLTIP: [
        'Supply Info Tooltip',
        CommonUtils.concatenate(
          CommonGetLocators.i,
          '[data-test-id*="supply-info-tooltip"]'
        ),
      ],
      IMPLANT_INFO_TOOLTIP: [
        'Implant Info Tooltip',
        CommonUtils.concatenate(
          CommonGetLocators.i,
          '[data-test-id*="implant-info-tooltip"]'
        ),
      ],
    },
  },

  TABS: {
    SURGICAL_CASES: ['Surgical Cases'],
    CHART_ATTACHMENTS: ['Chart Attachments'],
  },
  PROCEDURE_TEXT: [
    'Procedure Text',
    'span[ng-if*=CaseDetails] .truncate-text-div',
  ],
  CASE_HEADER: ['Case Header', '.list-caseheader li'],
  TOOL_TIP: ['Tool Tip Result', '.tooltip-result'],
  SIDEBAR: {
    HOME_MEDICATIONS: [
      'Home Medications',
      selectorFactory.getSpanText('Home Medications'),
    ],
  },
  ENTER_IN_TIME: ['Enter In Time'],
  ENTER_IN_TIME_NOW: ['Now', '#preop_time_btn'],
};
