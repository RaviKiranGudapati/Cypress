import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_MY_TASK_FACE_SHEET } from './or/mytask-facesheet.or';

import { MyTaskFaceSheetApi } from './api/mytask-facesheet.api';

/* const values */
const departments = ['PHYSICIAN', 'OPERATIVE'];

/**
 * Class for MyTaskFaceSheet
 */
export class MyTaskFaceSheet {
  private myTaskFaceSheetApi = new MyTaskFaceSheetApi();
  

  /**
   * @details - Select Department In Mytask
   * @param department to select department in mytask
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  selectDepartmentInMytask(department: string) {
    const interceptFunctions = {
      [departments[0]]: this.myTaskFaceSheetApi.interceptOrderTask,
      [departments[1]]: this.myTaskFaceSheetApi.interceptWorklistTask,
    };
    const interceptCollection = interceptFunctions[department]
      ? interceptFunctions[department]()
      : [];
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.selectDepartmentMytask(department),
      OR_MY_TASK_FACE_SHEET.DEPARTMENT[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select task panel under Department In Mytask
   * @param task to select task under Department In Mytask
   * @API - API's are available - Partially Implemented
   * @author - Madhu Kiran
   */
  selectTaskPanelInDepartment(task: string) {
    const interceptFunctions = {
      [OR_MY_TASK_FACE_SHEET.OP_NOTES[0]]:
        this.myTaskFaceSheetApi.interceptOpNotesTask,
    };
    const interceptCollection = interceptFunctions[task]
      ? interceptFunctions[task]()
      : [];
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getTaskPanelInDepartment(task),
      OR_MY_TASK_FACE_SHEET.TASKS[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To Close Pop up In Mytask
   */
  closePopup() {
    cy.cClick(
      OR_MY_TASK_FACE_SHEET.CLOSE_POPUP[1],
      OR_MY_TASK_FACE_SHEET.CLOSE_POPUP[0]
    );
  }

  /**
   * @details - Select Op Notes in Physician Department
   * @param opNotes to add opNotes
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  selectOpNotes(opNotes: string) {
    const interceptCollection = this.myTaskFaceSheetApi.interceptSelectOpNote();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getSpanClassText(opNotes),
      OR_MY_TASK_FACE_SHEET.OP_NOTES[0]
    ),
      cy.cWaitApis(interceptCollection);
  }

  /**
   * @details -Click Add button to Add Op Notes Physician Department
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickOnAddOpNotes() {
    const interceptCollection = this.myTaskFaceSheetApi.interceptAddOpNotes();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_MY_TASK_FACE_SHEET.ADD_OPNOTES[1],
      OR_MY_TASK_FACE_SHEET.ADD_OPNOTES[0],
      false,
      false,
      {
        force: true,
      }
    );
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(OR_MY_TASK_FACE_SHEET.ADD_NEW_OPNOTES_POPUP[1]);
  }

  /**
   * @details - To Select Physician in adding OpNotes
   * @param - name to select Physician
   */
  selectPhysicianInAddOpNotes(name: string) {
    cy.cClick(
      OR_MY_TASK_FACE_SHEET.SELECT_PHYSICIAN[1],
      OR_MY_TASK_FACE_SHEET.SELECT_PHYSICIAN[0]
    );
    cy.cClick(
      selectorFactory.selectPhysicianInAddOpNotes(name),
      OR_MY_TASK_FACE_SHEET.SELECT_PHYSICIAN[0]
    );
  }

  /**
   * @details - Click on Sign Departments
   */
  signDepartment() {
    cy.cClick(
      OR_MY_TASK_FACE_SHEET.PENCIL_ICON[1],
      OR_MY_TASK_FACE_SHEET.PENCIL_ICON[0]
    );
    cy.cClick(
      OR_MY_TASK_FACE_SHEET.SIGN_BUTTON[1],
      OR_MY_TASK_FACE_SHEET.SIGN_BUTTON[0]
    );
    cy.cClick(
      OR_MY_TASK_FACE_SHEET.OVERRIDE_BUTTON[1],
      OR_MY_TASK_FACE_SHEET.OVERRIDE_BUTTON[0]
    );
  }
}