/**Revision History
 *Narasimha: 31-03-2023 : Corrected Wrong reference of import from DoneOrCancel
 */
import {
  InvokeAttributes,
  YesOrNo,
  DoneOrCancel,
  ShouldMethods,
  TriggerAttributes,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';
import { InvokeMethods } from '../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { WorklistSuppliesInstruments } from '../../../test-data-models/sis-charts/charts-cover.model';
import { Supplies } from '../../../test-data-models/shared/application-settings/application-settings.model';
import {
  Implant,
  Medication,
} from '../../../test-data-models/sis-office/trackers/inv-reconciliation.model';

import { OR_SCHEDULE_GRID } from '../../sis-office/case-creation/or/schedule-grid.or';
import { OR_CHARTS_COVER_FACE_SHEET } from './or/charts-cover-facesheet.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_INVENTORY_RECONCILIATION } from '../../sis-office/trackers/or/inv-reconciliation.or';
import { OR_NURSING_CONFIGURATION } from '../../shared/application-settings/or/nursing-configuration.or';
import { FreeText, IosTextItem, SupplyHeaders } from '../../shared/application-settings/enums/nursing-configuration.enum';
import { MyTasks, NursingDept } from './enums/charts-cover-facesheet.enum';

import NursingConfiguration from '../../shared/application-settings/nursing-configuration';

import ChartsCoverFaceSheetApi from './api/charts-cover-facesheet.api';

/* const values */
const addImplant = 'Add Implant / Prosthetic';
const enterInTime = 'Enter In/Out Time';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfiguration = new NursingConfiguration();

export default class ChartsCoverFaceSheet {
  constructor() {}
  private chartsCoverFaceSheetApi = new ChartsCoverFaceSheetApi();

  /**
   * @detail - To select the department from the facesheet page
   * @param option
   * @author -Arushi
   * @Api Apis are available and partially implemented
   */
  selectDepartment(option: NursingDept) {
    let interceptCollection: ApiEndpoint[] = [];
    switch (option) {
      case NursingDept.recovery:
        interceptCollection =
          this.chartsCoverFaceSheetApi.interceptRecoveryApi();
        cy.cIntercept(interceptCollection);
        cy.cGet(OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.RECOVERY[1])
          .first()
          .click();
        cy.cWaitApis(interceptCollection);
        break;
      case NursingDept.pre_operative:
        interceptCollection =
          this.chartsCoverFaceSheetApi.interceptConsentApi();
        cy.cIntercept(interceptCollection);
        cy.cClick(
          OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.PRE_OPERATIVE[1],
          option
        );
        cy.cWaitApis(interceptCollection);
        break;
      case NursingDept.operative:
        interceptCollection =
          this.chartsCoverFaceSheetApi.interceptOperativeApi();
        cy.cIntercept(interceptCollection);
        cy.cGet(OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.LIST[1]).eq(1).click();
        cy.cWaitApis(interceptCollection);
        break;
      case NursingDept.consents:
        cy.shouldBeEnabled(
          OR_CHARTS_COVER_FACE_SHEET.SIDEBAR.HOME_MEDICATIONS[1]
        );
        cy.shouldBeEnabled(
          selectorFactory.getSpanText(
            OR_CHARTS_COVER_FACE_SHEET.TABS.SURGICAL_CASES[0]
          )
        );
        cy.shouldBeEnabled(
          selectorFactory.getSpanText(
            OR_CHARTS_COVER_FACE_SHEET.TABS.CHART_ATTACHMENTS[0]
          )
        );
        cy.shouldBeEnabled(OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.CONSENTS[1]);
        interceptCollection =
          this.chartsCoverFaceSheetApi.interceptConsentApi();
        cy.cIntercept(interceptCollection);
        cy.cGet(OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.CONSENTS[1]).click();
        cy.cWaitApis(interceptCollection);
        break;
      case NursingDept.phase1:
        interceptCollection =
          this.chartsCoverFaceSheetApi.interceptPhase1DeptApi();
        cy.cIntercept(interceptCollection);
        cy.cClick(OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.PHASE1[1], option);
        cy.cWaitApis(interceptCollection);
        break;
      case NursingDept.phase2:
        interceptCollection =
          this.chartsCoverFaceSheetApi.interceptPhase2DeptApi();
        cy.cIntercept(interceptCollection);
        cy.cClick(OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.PHASE2[1], option);
        cy.cWaitApis(interceptCollection);
        break;
      case NursingDept.phase3:
        interceptCollection =
          this.chartsCoverFaceSheetApi.interceptPhase2DeptApi();
        cy.cClick(OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.PHASE3[1], option);
        cy.cWaitApis(interceptCollection);
        break;
      default:
        cy.cClick(option, option);
        //TODO: Need to add intercept wait
        break;
    }
  }

  /**
   * @detail - To click on the yes,no, or n/a option question for supplies
   * @param option
   * @Api are available and not implemented
   */
  clickSuppliesQuestionStatus(option: string) {
    cy.cClick(selectorFactory.getSuppliesButton(option), option, false, true);
  }

  /**
   * @detail - To add supplies in operative worklist
   * @param supplies
   * @Api are available and not implemented
   */
  addSuppliesInWorklist(supplies: WorklistSuppliesInstruments) {
    const interceptCollection =
      this.chartsCoverFaceSheetApi.interceptSearchSupplyWorklistApi();
    supplies.Supplies.forEach((val) => {
      cy.cIntercept(interceptCollection);
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .SUPPLIES.SUPPLIES_SEARCH[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .SUPPLIES.SUPPLIES_SEARCH[0],
        val
      );
      cy.cWaitApis(interceptCollection);

      cy.cWaitForElementToDisappear(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.ICON_IN_PROGRESS[1],
        OR_SCHEDULE_GRID.LOADING_SPINNER[0]
      );
      cy.cClick(selectorFactory.getImplantSearchResult(val), val);
      cy.cClick(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .WORKLIST_PANEL_LABEL[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .WORKLIST_PANEL_LABEL[0]
      );
    });
  }

  /**
   * @detail - To click on the yes,no, or n/a option question for implants
   * @param supplies
   * @Api are available and not implemented
   */
  clickImplantsQuestionStatus(option: string) {
    cy.cClick(selectorFactory.getImplantsButton(option), option, false, true);
  }

  /**
   * @detail - To add implants in operative worklist
   * @param implants
   * @Api are available and not implemented
   */
  addImplantsInWorklist(implants: Implant[]) {
    implants.forEach((val) => {
      cy.cClick(selectorFactory.getButtonText(addImplant), addImplant);
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.IMPLANT_IOS_SEARCH[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.IMPLANT_IOS_SEARCH[0],
        val.Implant!
      );
      cy.cWaitForElementToDisappear(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.ICON_IN_PROGRESS[1],
        OR_SCHEDULE_GRID.LOADING_SPINNER[0],
        15000
      );
      cy.cClick(selectorFactory.getSpanText(val.Implant!), val.Implant!);
      cy.cClick(
        selectorFactory.getSpanText(val.Manufacturer!),
        val.Manufacturer!
      );
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.QUANTITY[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.QUANTITY[0],
        val.Quantity!
      );
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.SIZE[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.SIZE[0],
        val.Size!
      );
      cy.cClick(selectorFactory.getButtonText(DoneOrCancel.done), val.Implant!);
    });
  }

  /**
   * @detail - To add free text implants in operative worklist
   * @param implants - As model reference to add the implants in worklist
   * @Api are available and not implemented
   */
  addFreeTextImplant(implants: Implant[]) {
    implants.forEach((val) => {
      cy.cClick(selectorFactory.getButtonText(addImplant), addImplant);
      cy.cClick(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.IMPLANT_FREE_TEXT_ICON[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.IMPLANT_FREE_TEXT_ICON[0]
      );
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.IMPLANT_IOS_SEARCH[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.IMPLANT_IOS_SEARCH[0],
        val.FreeTextImplant!
      );
      cy.cClick(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.MANUFACTURER_FREE_TEXT_ICON[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.MANUFACTURER_FREE_TEXT_ICON[0]
      );
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.MANUFACTURER_IOS_SEARCH[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.MANUFACTURER_IOS_SEARCH[0],
        val.FreeTextManufacturer!
      );
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.QUANTITY[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.QUANTITY[0],
        val.Quantity!
      );
      cy.cType(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.SIZE[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
          .IMPLANTS.SIZE[0],
        val.Size!
      );
      cy.cClick(
        selectorFactory.getButtonText(DoneOrCancel.done),
        val.FreeTextImplant!
      );
    });
  }

  /**
   * @detail - To add free text implants in operative worklist
   * @param value
   * @Api are available and not implemented
   */
  addOperativeWorklist(value: string) {
    cy.cWaitForElementToBeAttached(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .PROGRESS_LOADER[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .PROGRESS_LOADER[0]
    );
    const interceptWorklistIconCollection =
      this.chartsCoverFaceSheetApi.interceptWorklistIcon();
    cy.cIntercept(interceptWorklistIconCollection);
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .ADD_WORKLIST_ICON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .ADD_WORKLIST_ICON[0],
      false,
      true
    );
    cy.cWaitApis(interceptWorklistIconCollection);
    cy.cType(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .WORKLIST_SEARCH[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .WORKLIST_SEARCH[0],
      value
    );
    cy.cClick(selectorFactory.getSpanText(value), value);
    const interceptSelectWorklistCollection =
      this.chartsCoverFaceSheetApi.interceptSelectWorklist();
    cy.cIntercept(interceptSelectWorklistCollection);
    cy.cClick(selectorFactory.overwriteWorklist(YesOrNo.yes), YesOrNo.yes);
    cy.cWaitApis(interceptSelectWorklistCollection);
    cy.cWaitForElementToDisappear(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .WORKLIST_SEARCH[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS.WORKLIST
        .WORKLIST_SEARCH[0],
      2000
    );
  }

  /**
   * @details - Select Tasks under Facesheet > My Tasks
   * @param department  - Option to be selected in My Tasks
   * @Api are available and not implemented
   */
  selectMyTasks(department: MyTasks) {
    const myTasksProperties = {
      [MyTasks.documents]: OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.DOCUMENTS[1],

      [MyTasks.physician]: OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PHYSICIAN[1],

      [MyTasks.pre_admit]: OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT[1],

      [MyTasks.pre_op]: OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_OP[1],

      [MyTasks.operative]: OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE[1],

      [MyTasks.recovery]: OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.RECOVERY[1],

      [MyTasks.post_op_qx]: OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.POST_OP_QX[1],
    };
    cy.cClick(myTasksProperties[department], department);
  }

  /**
   * @details - Add work list in My Tasks
   * @param  listType - All Work lists or Current specialty Work lists
   * @param qxName - Work list name
   * @Api APIs are available -Implemented Completely
   */
  addWorkList(listType: string, qxName: string) {
    const interceptCollection = this.chartsCoverFaceSheetApi.addedWorklistApi();
    this.clickAddWorkListIcon(listType);
    cy.cIntercept(interceptCollection);
    cy.cClick(qxName, listType, true, true, { force: true });
    cy.cNotExist(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click Add work list Icon in Pre-Admit and Post-op Qx under Facesheet->My Tasks
   * @param type - Worklist type to be selected
   * @Api are available and not implemented
   */
  clickAddWorkListIcon(type: string) {
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD_WORKLIST_ICON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD_WORKLIST_ICON[0],
      false,
      true,
      { force: true }
    );
    cy.cIsVisible(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ALL_WORKLISTS[0],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ALL_WORKLISTS[0],
      true
    );

    if (type == OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ALL_WORKLISTS[0]) {
      const interceptCollection =
        this.chartsCoverFaceSheetApi.addWorklistTemplateAllApi();
      cy.cIntercept(interceptCollection);
      cy.cClick(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ALL_WORKLISTS[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ALL_WORKLISTS[0]
      );
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cClick(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CURRENT_SPECIALTY_WORKLISTS[1],
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CURRENT_SPECIALTY_WORKLISTS[0]
      );
    }
  }

  /**
   * @details - To get dropdown locators in Alcohol, tobacco and Drug use Panel
   * @param fieldName - dropdown field name
   * @Api are available and not implemented
   */
  getDropdownLocInPreAdQx(fieldName: string) {
    const fields = {
      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[1],

      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ALCOHOL[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ALCOHOL[1],

      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE[1],
    };
    return fields[fieldName];
  }

  /**
   * @details - Select dropdown items in Alcohol, tobacco and Drug use Panel
   * @param fieldName - dropdown field name
   * @param value - dropdown value to be selected
   * @Api are available and not implemented
   */
  selectValInPreAdQxDropdown(fieldName: string, value: string) {
    cy.cIsVisible(fieldName, fieldName, true);
    cy.cGet(
      selectorFactory.getQuestionnaireDropdown(fieldName.toLowerCase()),
      fieldName
    ).click({ force: true });
    if (
      fieldName === OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE[0]
    ) {
      cy.cGet(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE_ITEMS[1]
      )
        .contains(value)
        .click();
    } else {
      cy.cClick(value, fieldName, true);
    }
  }

  /**
   * @details - Verify displayed items in Alcohol, tobacco and Drug use Panel
   * @param fieldName -  dropdown field name
   * @param value - dropdown value to be verified
   * @Api are not  available
   */
  verifyDisplayedValInPreAdQxDropdown(fieldName: string, value: string) {
    const loc = this.getDropdownLocInPreAdQx(fieldName);
    cy.cGet(loc)
      .invoke(InvokeMethods.text)
      .then(($val) => {
        expect($val).to.contains(value);
      });
  }

  /**
   * @details - To add new Dictionary items in Alcohol, tobacco and Drug use Panel
   * @param fieldName - Dictionary name
   * @param itemName - Dictionary item name to be added
   * @Api are available and not implemented
   */
  addNewItemInDictionary(fieldName: string, itemName: string) {
    const dictName = {
      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.ADD_ITEM_TOBACCO[1],

      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ALCOHOL[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.ADD_ITEM_ALCOHOL[1],

      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.ADD_ITEM_DRUG_USE[1],
    };

    let loc = this.getDropdownLocInPreAdQx(fieldName);
    cy.cClick(loc, fieldName, false, true, { force: true });
    cy.cClick(
      dictName[fieldName],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.ADD_NEW_ITEM[0],
      false,
      true
    );

    cy.cType(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.ITEM[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.ITEM[0],
      itemName
    );
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.SAVE[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD.SAVE[0]
    );
  }

  /**
   * @details - To Wait till questionnaire loads
   * @Api are available and not implemented
   */
  waitToLoadQuestionnaire() {
    cy.cIsVisible(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE[0]
    );
    cy.cIsVisible(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ALCOHOL[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ALCOHOL[0]
    );
    cy.cIsVisible(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0]
    );
    cy.cIsVisible(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE[0],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE[0],
      true
    );
    cy.cIsVisible(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ADD_NOTES[0],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ADD_NOTES[0],
      true
    );
  }

  /**
   * @details - To Wait till all the contents of departments load when clicked
   * @param content - Content name to be loaded
   * @Api are available and not implemented
   */
  waitToLoadContents(content: string) {
    const contentName = {
      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS
        .CONSENTS_HEADER[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS
          .CONSENTS_HEADER[1],

      [OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE[0]]:
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE[1],
    };
    cy.cIsVisible(contentName[content], content);
  }

  /**
   * @details  Verify procedure data in face sheet
   * @param value
   * @Api are not available
   */
  verifyProcedureInFaceSheet(value: string) {
    cy.cGet(OR_CHARTS_COVER_FACE_SHEET.PROCEDURE_TEXT[1])
      .invoke(InvokeMethods.attribute, InvokeAttributes.name)
      .then(($procedureValue) => {
        expect($procedureValue).to.contains(value);
      });
  }

  /**
   * @details verify procedure data in case details header
   * @param procedureData
   * @Api are not available
   */
  verifyProcedureInCaseHeader(procedureData: string) {
    cy.cGet(OR_CHARTS_COVER_FACE_SHEET.CASE_HEADER[1])
      .first()
      .within(($listValues) => {
        cy.wrap($listValues)
          .cGet(OR_CHARTS_COVER_FACE_SHEET.TOOL_TIP[1])
          .within(($data) => {
            expect($data.text()).to.contains(procedureData);
          });
      });
  }

  /**
   * @details Click on Face Sheet tabs in Charts
   * @param tabName
   * @Api are available and not implemented
   */
  clickFaceSheetTab(tabName: string) {
    cy.cClick(selectorFactory.getSpanText(tabName), tabName, false, true);
  }

  /**
   * @details - To verify fields in nursing desktop questioners page
   */
  assertPreAdmitQuestionnaires() {
    const questioners = [
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE_PROGRESS[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE_PRINT_ICON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CONTACT_LOG[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ADD_WORKLIST_ICON[1],
    ];
    questioners.forEach((questioner) => {
      cy.shouldBeEnabled(questioner);
    });
  }

  /**
   * @detail - Select Task panel in Department
   * @param taskPanel - To Select Task in respective Department
   * @API - API's are available and Partially Implemented
   * @author - Sai Swarup
   */
  selectDepartmentTaskPanel(taskPanel: string) {
    const interceptCollection =
      this.chartsCoverFaceSheetApi.interceptOrderInDepartment();
    cy.shouldBeEnabled(selectorFactory.getDepartmentTaskPanel(taskPanel));

    if (taskPanel == OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]) {
      cy.cIntercept(interceptCollection);
    }
    cy.cClick(
      selectorFactory.getDepartmentTaskPanel(taskPanel),
      taskPanel,
      false,
      true
    );

    if (taskPanel == OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]) {
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - Add Free Text Supplies in Worklist in Department
   * @param supplyInfo - Supply Details like Supply Name, Used, Wasted, Defective Value
   * @param supplyHeader - Supply Header like Free Text Item
   * @API - API's are not available
   * @author - Sai Swarup
   */
  addFreeTextSuppliesInWorkList(supplyInfo: Supplies, supplyHeader: string) {
    const sisChartSupply = supplyInfo.SisChartsSupply!;
    let supplyKeyDetails: number;

    if (supplyHeader == FreeText.free_text_item) {
      nursingConfiguration.preferenceCardFreeTextSupply(supplyInfo.SupplyName!);
    }

    if (supplyHeader == IosTextItem.ios_text_item) {
      nursingConfiguration.preferenceCardSupply(supplyInfo.SupplyName!);
    }
    Object.entries(sisChartSupply).forEach((entry) => {
      const [key, value] = entry;

      if (CommonUtils.isDefinedAndNotEmpty(value)) {
        supplyKeyDetails =
          key === SupplyHeaders.used ? 0 : key === SupplyHeaders.wasted ? 1 : 2;
        nursingConfiguration.preferenceCardSupplyQuantity(
          supplyKeyDetails,
          value
        );
      }
    });

    if (CommonUtils.isDefinedAndNotEmpty(supplyInfo.Notes!)) {
      nursingConfiguration.preferenceCardSupplyNotes(supplyInfo.Notes!);
    }
    sisOfficeDesktop.clickPatientSearchIcon();
  }

  /**
   * @detail - Verify Add Medication Button in Orders Tab
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyAddMedicationBtn() {
    cy.shouldBeEnabled(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ADD_MEDICATION[1]
    );
    cy.cIsVisible(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ADD_MEDICATION[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ADD_MEDICATION[0]
    );
    cy.cIsEnabled(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ADD_MEDICATION[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ADD_MEDICATION[0]
    );
  }

  /**
   * @detail - Click on Sign Department Pencil Icon and Select Sign Option and Select Override option
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  signDepartment() {
    const interceptCollectionPencil =
      this.chartsCoverFaceSheetApi.interceptSignDepartmentPencilIcon();
    const interceptCollectionSign =
      this.chartsCoverFaceSheetApi.interceptSignButton();
    cy.cIntercept(interceptCollectionPencil);
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PENCIL_ICON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PENCIL_ICON[0]
    );
    cy.cWaitApis(interceptCollectionPencil);
    cy.shouldBeEnabled(OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.SIGN_BUTTON[1]);
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.SIGN_BUTTON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.SIGN_BUTTON[0]
    );
    cy.shouldBeEnabled(OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OVERRIDE_BUTTON[1]);
    cy.cIntercept(interceptCollectionSign);
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OVERRIDE_BUTTON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OVERRIDE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollectionSign);
    cy.cNotExist(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OVERRIDE_BUTTON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OVERRIDE_BUTTON[0]
    );
  }

  /**
   * @detail - Click on Patient Face sheet Home Icon
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  clickFaceSheetIcon() {
    const interceptCollection =
      this.chartsCoverFaceSheetApi.interceptFacesheetIcon();
    cy.shouldBeEnabled(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.FACESHEET_HOME_BUTTON[1]
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.FACESHEET_HOME_BUTTON[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.FACESHEET_HOME_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - Click on Pencil Icon to sign or unsign the patient case in Face sheet
   * @param signUnSign - To Pass Sign or Un-Sign option
   * @param option - To Pass Yes or No
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  caseDetailsSignUnSign(signUnSign: string, option: string) {
    const interceptCollection =
      this.chartsCoverFaceSheetApi.interceptCaseDetailsUnsignApi();
    const caseSignOption =
      signUnSign === OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0]
        ? OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[1]
        : OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_UNSIGN[1];

    cy.shouldBeEnabled(caseSignOption);
    cy.cClick(caseSignOption, signUnSign);
    cy.shouldBeEnabled(selectorFactory.getButtonText(option));

    if (option == YesOrNo.yes) {
      cy.cIntercept(interceptCollection);
      cy.cClick(selectorFactory.getButtonText(option), option);
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cClick(selectorFactory.getButtonText(option), option);
    }
    cy.cNotExist(selectorFactory.getButtonText(option), option);
  }

  /**
   * @detail - Click on Un-Sign Department Button
   * @param option - To Pass Yes or No
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  unSignDepartment(option: string) {
    const interceptCollection =
      this.chartsCoverFaceSheetApi.interceptUnsignDepartmentApi();
    cy.shouldBeEnabled(
      selectorFactory.getButtonText(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.UN_SIGN_DEPARTMENT[0]
      )
    );
    cy.cClick(
      selectorFactory.getButtonText(
        OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.UN_SIGN_DEPARTMENT[0]
      ),
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.UN_SIGN_DEPARTMENT[1]
    );
    cy.shouldBeEnabled(selectorFactory.getButtonText(option));

    if (option == YesOrNo.yes) {
      cy.cIntercept(interceptCollection);
      cy.cClick(selectorFactory.getButtonText(option), option);
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cClick(selectorFactory.getButtonText(option), option);
    }
  }

  /**
   * @details - Verify Original IOS Text Description after converting From Free Text to IOS Inventory Implant or Supply
   * @param inventoryType - passing supply or implant as an header
   * @param freeTextName - passing free text supply or implant name
   * @param iosInventoryName - passing ios inventory supply or implant name
   * @param rowSequence - passing implant or supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyOriginalIosTextDescription(
    inventoryType: string,
    freeTextName: string,
    iosInventoryName: string,
    rowSequence: number = 0
  ) {
    const freeTextToolTip =
      inventoryType ===
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .SUPPLIES_TABLE.SUPPLIES[0]
        ? OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST.SUPPLY_INFO_TOOLTIP[1]
        : OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST.IMPLANT_INFO_TOOLTIP[1];

    cy.cGet(selectorFactory.getSpanText(freeTextName))
      .eq(rowSequence)
      .prev(freeTextToolTip)
      .should(ShouldMethods.visible)
      .trigger(TriggerAttributes.mouseover);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_custom_tooltip_text, {
      timeout: Cypress.config('defaultCommandTimeout'),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_custom_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(
        ShouldMethods.text,
        selectorFactory.getChartsOriginalIosTextDescription(iosInventoryName)
      );
    cy.cGet(selectorFactory.getSpanText(freeTextName))
      .eq(rowSequence)
      .prev(freeTextToolTip)
      .trigger(TriggerAttributes.mouseout);
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_custom_tooltip_text,
      CoreCssClasses.ToolTipText.loc_custom_tooltip_text
    );
  }

  /**
   * @details - Verify Implant Information in Operative Department
   * @param implantInfo - Implant Details like Implant Name, Manufacturer, Quantity, Size, Lot, Serial, Expiration, Reference, Notes
   * @param rowSequence - To Pass Implant Row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyImplantInOperative(implantInfo: Implant, rowSequence: number = 0) {
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[1]
    );
    this.selectImplant(implantInfo.Implant!, rowSequence);
    this.verifyImplantOrProstheticInfo(implantInfo);
    nursingConfiguration.clickAddImplantProstheticDoneBtn();
  }

  /**
   * @detail - Click Implant Hyperlink in Operative Department
   * @param implantName - To Pass Implant Name
   * @param rowSequence - To Pass Implant Row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectImplant(implantName: string, rowSequence: number = 0) {
    const implantHyperLink = CommonUtils.concatenate(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.CLICK_SUPPLY_ITEM[1],
      ' ',
      selectorFactory.getSpanText(implantName)
    );

    cy.cGet(implantHyperLink).eq(rowSequence).click();
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.NOTES[1]
    );
  }

  /**
   * @details - Verify Information Implant And Prosthetic Popup
   * @param impRecord - passing implant name, manufacturer name, quantity, size, lot, serial, expiration, reference, notes
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyImplantOrProstheticInfo(impRecord: Implant) {
    const prostheticPopupObject =
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC;
    const selectorImplant = prostheticPopupObject.IMPLANT[1];
    const logicalNameImplant = prostheticPopupObject.IMPLANT[0];
    const selectorManufacturer = prostheticPopupObject.MANUFACTURER[1];
    const logicalNameManufacturer = prostheticPopupObject.MANUFACTURER[0];
    const selectorQty = prostheticPopupObject.QUANTITY[1];
    const logicalNameQty = prostheticPopupObject.QUANTITY[0];
    const selectorSize = prostheticPopupObject.SIZE[1];
    const logicalNameSize = prostheticPopupObject.SIZE[0];
    const selectorLot = prostheticPopupObject.LOT_NO[1];
    const logicalNameLot = prostheticPopupObject.LOT_NO[0];
    const selectorSerial = prostheticPopupObject.SERIAL_NO[1];
    const logicalNameSerial = prostheticPopupObject.SERIAL_NO[0];
    const selectorExpiration = prostheticPopupObject.EXPIRATION[1];
    const logicalNameExpiration = prostheticPopupObject.EXPIRATION[0];
    const selectorReference = prostheticPopupObject.REFERENCE_NO[1];
    const logicalNameLReference = prostheticPopupObject.REFERENCE_NO[0];
    const selectorNotes = prostheticPopupObject.NOTES[1];
    const logicalNameNotes = prostheticPopupObject.NOTES[0];

    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.ADD_IMPLANT_OR_PROSTHETIC_POPUP[1]
    ).within(() => {
      // verify Implant Name
      cy.cHasValue(selectorImplant, logicalNameImplant, impRecord.Implant!);

      // verify Manufacturer Name
      cy.cHasValue(
        selectorManufacturer,
        logicalNameManufacturer,
        impRecord.Manufacturer!
      );

      // verify Quantity
      cy.cHasValue(selectorQty, logicalNameQty, impRecord.Used);

      // verify Size
      cy.cHasValue(selectorSize, logicalNameSize, impRecord.Size);

      // verify lot
      cy.cHasValue(selectorLot, logicalNameLot, impRecord.Lot);

      // verify serial
      cy.cHasValue(selectorSerial, logicalNameSerial, impRecord.Serial);

      // verify Expiration
      cy.cHasValue(
        selectorExpiration,
        logicalNameExpiration,
        impRecord.Expiration
      );

      // verify Reference
      cy.cHasValue(
        selectorReference,
        logicalNameLReference,
        impRecord.Reference
      );

      // verify Notes
      cy.cHasValue(selectorNotes, logicalNameNotes, impRecord.Notes);
    });
  }

  /**
   * @details - Update Used Quantity for Implant in Operative Department
   * @param usedQuantity - To Pass Used Quantity for Implant
   * @API - API's are not available
   * @author - Sai Swarup
   */
  updateImplantUsedQuantity(usedQuantity: number) {
    cy.cType(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.QUANTITY[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.QUANTITY[1],
      usedQuantity
    );
  }

  /**
   * @details - Select Supply in Worklist
   * @param supplyName - To Pass Supply Name
   * @param rowSequence - To Pass Supply Row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectSupply(supplyName: string, rowSequence: number = 0) {
    cy.shouldBeEnabled(selectorFactory.getSpanText(supplyName));
    cy.cGet(selectorFactory.getSpanText(supplyName), supplyName)
      .eq(rowSequence)
      .should(ShouldMethods.visible)
      .click();
  }

  /**
   * @details - Update Used Quantity for Supply in Operative Department
   * @param index - To pass Index for Supply Quantity
   * @param usedQuantity - To Pass Used Quantity for Supply
   * @API - API's are not available
   * @author - Sai Swarup
   */
  updateSupplyUsedQuantity(index: number, usedQuantity: number) {
    nursingConfiguration.preferenceCardSupplyQuantity(index, usedQuantity);
    sisOfficeDesktop.clickPatientSearchIcon();
  }

  /**
   * @details - Verify Supply Information in Worklist
   * @param supplyInfo - To Pass Supply Name, Used, Wasted, Defective and Notes
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifySupplyInfo(supplyInfo: Supplies) {
    const supplyDetails = supplyInfo.SisChartsSupply!;
    const supplyHeaderDetails = new Map<string, string>([
      [SupplyHeaders.pulled, SupplyHeaders.pulled],
      [SupplyHeaders.used, SupplyHeaders.used],
      [SupplyHeaders.wasted, SupplyHeaders.wasted],
      [SupplyHeaders.defective, SupplyHeaders.defective],
    ]);

    cy.cHasText(
      selectorFactory.getSpanText(supplyInfo.SupplyName!),
      supplyInfo.SupplyName!,
      supplyInfo.SupplyName!
    );
    Object.entries(supplyDetails).forEach((entry) => {
      const [key, value] = entry;
      const supplyHeader = supplyHeaderDetails.get(key);

      if (supplyHeader) {
        cy.cHasText(
          selectorFactory.getSupplyDetailsCharts(
            supplyInfo.SupplyName!,
            supplyHeader
          ),
          supplyInfo.SupplyName!,
          value
        );
      }
    });
  }

  /**
   * @details - Click on Acknowledge Button in Orders Tab with respect to Department
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  departmentOrdersAcknowledgeBtn() {
    const interceptCollection =
      this.chartsCoverFaceSheetApi.interceptDepartmentOrders();
    cy.cIsEnabled(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ACKNOWLEDGE[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ACKNOWLEDGE[0]
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ACKNOWLEDGE[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ACKNOWLEDGE[0],
      false,
      true
    );
  }

  /**
   * @details - Administer Medication in Orders Tab
   * @param medicationInfo - Pass Medication as a Model for reference
   * @API - API's are available and Yet to be Implemented
   * @author - Sai Swarup
   */
  departmentOrdersAdministerMedication(medicationInfo: Medication) {
    const medicationAdminister = CommonUtils.concatenate(
      selectorFactory.getDivText(medicationInfo.Medication!),
      ' ',
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ADMINISTER[1]
    );

    cy.shouldBeEnabled(medicationAdminister);
    cy.cClick(medicationAdminister, medicationInfo.Medication!, false, true);
    cy.shouldBeEnabled(OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.DOSE[1]);
    cy.cType(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.DOSE[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.DOSE[0],
      medicationInfo.SisChartsMedication?.Dose,
      false,
      true
    );

    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.DONE[1],
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.DONE[0],
      false,
      true
    );

    cy.shouldBeEnabled(
      OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.ADMINISTER[1]
    );
  }

  /**
   * @details - Add Pre-Operative time as Now
   * @Api are available and not implemented
   * @author - Madhu Kiran
   */
  addTimePreOperativeNow() {
    cy.cClick(
      selectorFactory.getSpanText(enterInTime),
      OR_CHARTS_COVER_FACE_SHEET.ENTER_IN_TIME[0]
    );
    cy.cClick(
      OR_CHARTS_COVER_FACE_SHEET.ENTER_IN_TIME_NOW[1],
      OR_CHARTS_COVER_FACE_SHEET.ENTER_IN_TIME_NOW[0]
    );
  }
}
