import { Application } from '../../../support/common-core-libs/application/common-core';

import Login from '../../shared/login/login';

export default class SISCompleteLogin extends Login {
  constructor() {
    super(Application.sis_complete);
  }
}
