export const OR_LOGIN = {
  LOGIN: {
    LOGIN_WEB_TITLE: 'SIS Complete - Login',
    USER_NAME: ['User Name', '#username'],
    PASSWORD: ['Password', '#password'],
    LOGIN_BUTTON: ['Login', '#LoginButton'],
    LOGIN_SUCCESSFUL_WEB_TITLE: 'SIS Office - Desktop',
  },
  LOGIN_LOCATION: {
    LOGIN_LOCATION_WINDOW: ['Select Login Location'],
  },
};
