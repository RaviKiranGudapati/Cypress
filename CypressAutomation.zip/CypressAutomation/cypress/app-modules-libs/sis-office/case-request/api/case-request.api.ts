import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export class CaseRequestApis {
  /**
   * @details - The api calls related to on selecting the deny items from dropdown
   * @Author Praveen
   */
  interceptDenyDictionaryApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_request_get_pending_count,
        'CaseRequestPendingCount',
        200
      ),
    ];
  }

  /**
   * @details - The api calls related to on click Deny button
   * @Author Praveen
   */
  interceptDenyButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(WaitMethods.get, SubRoutes.dictionary, 'Dictionary', 200),
    ];
  }
}
