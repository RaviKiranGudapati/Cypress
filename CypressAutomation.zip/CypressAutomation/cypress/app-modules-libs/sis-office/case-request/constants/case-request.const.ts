/* const values */
export const caseRequestLabels = [
    'Date of Service',
    'Start Time',
    'End Time',
    'Duration',
    'Referring Physician',
    'Anesthesia Type',
  ];
  export const caseRequestNoteLabels = ['Case Notes', 'Equipment'];
  export const procedureRequestLabels = [
    '',
    'CPT® Code and Description',
    'Mod Proc',
    'Physician',
    'Laterality',
    'Pre-Op Dx Codes',
  ];
  export const patientInfoLabels = [
    'Last Name',
    'First Name',
    'Middle',
    'Suffix',
    'Sex',
    'Gender Identity',
    'Pronouns',
    'DOB',
    'Marital Status',
    'SSN',
    'Preferred Name',
  ];
  
  export const patientAddressInfoLabels = [
    'Address1',
    'Address2',
    'City',
    'State',
    'Zip Code',
    'County',
    'Primary',
    'Secondary',
    'Email',
  ];
  
  export const primaryInsuranceLabels = [
    'Insurance Name',
    'Insured Last Name',
    'Insured First Name',
    'Relationship to Subscriber',
    'Subscriber ID',
    'Group Name',
    'Group Number',
    'Phone Number',
    '',
  ];
  
  export const primaryGuarantorLabels = [
    'Last Name',
    'First Name',
    'DOB',
    'Phone Number',
    'Relationship to Patient',
    'Address 1',
    'Address 2',
    'City',
    'State',
    'Zip Code',
  ];
  