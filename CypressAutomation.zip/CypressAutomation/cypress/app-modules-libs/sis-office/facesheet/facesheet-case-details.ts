import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_PATIENT_CASE_CREATION } from '../case-creation/or/create-case.or';
import { OR_SCHEDULE_GRID } from '../case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FacesheetCaseDetailsApis } from './api/facesheet-case-details.api';


/* const values */
const index = 1;

export class CasesDetailsFaceSheet {
  /* instance variables */
  private facesheetCaseDetailsApis = new FacesheetCaseDetailsApis();

  // Object Repositories For Case details
  private orCaseDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS;

  /**
   * @details - Verify CPT code Description in case details table
   * @param - Passing description to verify CPTCode And Description
   * @API -API's are not available
   */
  verifyCptCodeAndDescription(description: string) {
    cy.cIncludeText(
      this.orCaseDetails.CPT_LABEL[1],
      this.orCaseDetails.CPT_LABEL[0],
      description
    );
  }

  /**
   * @details - Verify operating room in case details tab
   * @param - Passing room name to verify Operating Room
   *  @API-API's are not available
   */
  verifyOperatingRoom(room: string) {
    cy.cIncludeText(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .OPERATING_ROOM[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .OPERATING_ROOM[0],
      room
    );
  }

  /**
   * @details - Verify Date Of Service in case details tab
   * @param - Passing date to verify date of service
   * @API - API's are not available
   */
  verifyDateOfService(date: String) {
    cy.cHasValue(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .DATE_OF_SERVICE[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .DATE_OF_SERVICE[0],
      date
    );
  }

  /**
   * @details - Click On Anesthesia DropDown in case details tab
   * @param - Passing anesthesia type to select
   * @API - API's are not available
   */
  clickOnAnesthesiaDropDown(anesthesia: string) {
    cy.cSelectDropdown(
      this.orCaseDetails.ANESTHESIA_TYPE[1],
      this.orCaseDetails.ANESTHESIA_TYPE[0],
      anesthesia
    );
  }

  /**
   * @details - Verify Anesthesia Type in case details tab
   * @param - Passing anesthesia type to verify
   * @API - API's are not available
   */
  verifyAnesthesiaType(anesthesia: string) {
    cy.cIncludeText(
      selectorFactory.getSpanClassText(
        anesthesia
      ),
      this.orCaseDetails.ANESTHESIA_TYPE[0],
      anesthesia
    );
  }

  /**
   * @details - Verify Appointment Type in case details tab
   * @param - Passing appointment type to verify
   * @API - API's are not available
   */
  verifyAppointmentType(appointment: string) {
    cy.cIncludeText(
      selectorFactory.getSpanClassText(
        appointment
      ),
      this.orCaseDetails.APPOINTMENT_TYPE[0],
      appointment
    );
  }

  /**
   * @details - Verify Star Time And End Time in case details tab
   * @param - Passing locLogicalName and value to Start time and End time to verify
   * @API - API's are not available
   */
  verifyStartTimeAndEndTime(locLogicalName: string, value: string) {
    let locator: string = '';
    locLogicalName == this.orCaseDetails.START_TIME[0]
      ? (locator = this.orCaseDetails.START_TIME[1])
      : (locator = this.orCaseDetails.END_TIME[1]);
    cy.cHasValue(locator, locLogicalName, value);
  }

  /**
   * @details - Verify Patient in Operating Room InScheduleGrid by passing Name,Date of service,start time and end time
   * @param - Passing lastName,startTime,endTime and DOS to verify in schedule grid
   * @API - API's are not available
   */
  verifyPatientInOperatingRoomInScheduleGrid(
    lastName: string,
    startTime: string,
    endTime: string,
    DOS: string
  ) {
    cy.cIncludeText(
      selectorFactory.blockTitleInBlockSchedule(index, lastName),
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.SEARCH_PATIENT_INPUT[0],
      lastName
    );

    cy.cHasText(
      selectorFactory.getScheduleGridTime(startTime),
      OR_SCHEDULE_GRID.SCHEDULE_TIME[0],
      startTime
    );
    cy.cHasText(
      selectorFactory.getScheduleGridTime(endTime),
      OR_SCHEDULE_GRID.SCHEDULE_TIME[0],
      endTime
    );
    cy.cIncludeText(
      OR_SCHEDULE_GRID.DATE_OF_SERVICE[1],
      OR_SCHEDULE_GRID.DATE_OF_SERVICE[0],
      DOS
    );
  }

  /**
   * @details - Verify Warning Msg Operating Room Case Details Tab
   * @param - Passing warningMessage to verify Room
   * @API - API's are available -Implemented
   * @author - Spoorthy
   */
  verifyWarningMsgOperatingRoom(warningMessage: string) {
    const interceptCollection =
      this.facesheetCaseDetailsApis.interceptClearOperatingRoomApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.orCaseDetails.CLEAR_OPERATING_ROOM[1],
      this.orCaseDetails.CLEAR_OPERATING_ROOM[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cIncludeText(
      this.orCaseDetails.DATE_WARNING_MESSAGE[1],
      this.orCaseDetails.DATE_WARNING_MESSAGE[0],
      warningMessage
    );
  }

  /**
   * @details - clear time
   * @param - Passing locator
   * @API - API's are not available
   */
  clearTime(locator: string) {
    cy.cClear(locator);
  }

  /**
   * @details - verify Warning Msg Start Time Is Greater in Case Details Tab
   * @param - Passing warningMessage,flag to verify
   * @API - API's are not available
   */
  verifyTimeWarningMsg(warningMessage: string, flag: boolean = true) {
    flag
      ? cy.cIncludeText(
          this.orCaseDetails.TIME_WARNING_MESSAGE[1],
          this.orCaseDetails.TIME_WARNING_MESSAGE[0],
          warningMessage
        )
      : cy.cNotExist(
          this.orCaseDetails.TIME_WARNING_MESSAGE[1],
          this.orCaseDetails.TIME_WARNING_MESSAGE[0]
        );
  }

  /**
   * @details - click on update button in the case details
   * @API - API's are available -  Implemented Completely
   * @author - Praveen
   */
  clickUpdateButtonInCaseDetails() {
    const interceptCollection =
      this.facesheetCaseDetailsApis.interceptUpdateButtonCaseDetailsApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.UPDATE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.UPDATE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To click on the label names for deselection of cursor after entered the data in fields under Case Details in My Tasks.
   * @Param To specify the label names of case details page while using this method. Eg: End Time, Start Time..etc.,
   * @author Praveen
   * @API - API's are not available
   */
  clickCaseDetailLabels(labelName: string) {
    cy.cClick(selectorFactory.getLabelText(labelName), labelName);
  }
}
