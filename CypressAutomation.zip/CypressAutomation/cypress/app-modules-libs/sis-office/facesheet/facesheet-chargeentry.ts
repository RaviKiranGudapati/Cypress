import {
  Application,
  CommonClassAttributes,
  ExpandOrCollapse,
  InvokeMethods,
  ShouldMethods,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { Charges } from '../../../test-data-models/sis-office/trackers/combined-coding.model';
import { Cpt } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_CHARGE_ENTRY } from '../trackers/or/charge-entry.or';
import { OR_COMBINED_CODING } from '../trackers/or/combined-coding.or';
import { OR_FACESHEET_CASE_PAGE } from './or/facesheet-cases.or';
import { OR_FACE_SHEET_CHARGE_ENTRY } from './or/facesheet-chargentry.or';

import { FacesheetChargeEntryApis } from './api/facesheet-chargeentry.api';
import { NursingConfigurationApis } from '../../shared/application-settings/api/nursing-configuration.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

export default class FaceSheetChargeEntry {
  /* instance variables */
  private facesheetChargeEntryApis = new FacesheetChargeEntryApis();
  private nursingConfigApis = new NursingConfigurationApis();

  /**
   * @details To add the new procedure in Charge Entry page under My Tasks
   * @param cptData as model reference name to pass it in the function
   * @API - API's are available - Implemented Completely
   */
  addProcedure(cptData: Cpt) {
    const interceptAddProcedureApiCollection =
      this.facesheetChargeEntryApis.interceptAddProcedureApi();
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.ADD_PROCEDURE[1],
      OR_FACE_SHEET_CHARGE_ENTRY.ADD_PROCEDURE[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.PROCEDURE_SEARCH[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PROCEDURE_SEARCH[0],
      false,
      true
    );
    cy.cIntercept(interceptAddProcedureApiCollection);
    cy.cType(
      OR_FACE_SHEET_CHARGE_ENTRY.PROCEDURE_SEARCH[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PROCEDURE_SEARCH[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptAddProcedureApiCollection);
    cy.cIsVisible(
      selectorFactory.getBText(cptData.CPTCodeAndDescription),
      cptData.CPTCodeAndDescription
    );
    const interceptSelectProcedureButtonApiCollection =
      this.facesheetChargeEntryApis.interceptSelectProcedureButtonApi();
    cy.cIntercept(interceptSelectProcedureButtonApiCollection);
    cy.cSelectListItem(
      OR_FACE_SHEET_CHARGE_ENTRY.PROCEDURE_SELECTION[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PROCEDURE_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptSelectProcedureButtonApiCollection);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To verify the balance and Amount for the charge
   * @param - value as parameter inside the function
   * @API - API's are not available
   */
  verifyBalanceAndAmount(value: string) {
    cy.cHasText(
      selectorFactory.getSpanText(OR_FACE_SHEET_CHARGE_ENTRY.BALANCE[0]),
      OR_FACE_SHEET_CHARGE_ENTRY.BALANCE[0],
      OR_FACE_SHEET_CHARGE_ENTRY.BALANCE[0]
    );
    cy.cHasText(
      OR_FACE_SHEET_CHARGE_ENTRY.AMOUNT_LABEL[1],
      OR_FACE_SHEET_CHARGE_ENTRY.AMOUNT_LABEL[0],
      OR_FACE_SHEET_CHARGE_ENTRY.AMOUNT_LABEL[0]
    );
    cy.cIncludeText(
      selectorFactory.getLabelText(value),
      OR_FACE_SHEET_CHARGE_ENTRY.BALANCE_AMOUNT[0],
      value
    );
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[1])
      .invoke(InvokeMethods.value)
      .then(($amountValue) => {
        expect($amountValue).to.include(value);
      });
  }

  /**
   * @details - To delete the specific CPT Charge in My Tasks - Charge Entry
   * @param - cptData as model reference passed it as parameter.
   * @API - API's are available - Not Implemented
   */
  deleteCharge(cptData: Cpt) {
    /**
     * @Issue: sometimes trash icon is not completely loaded before that it is trying to click
     * @Resolution: we have added the mouseover and timeout and then click on the trash icon
     */
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.CPT_CHARGE_ROW[1]).each(($cptRows) => {
      if ($cptRows.text().includes(cptData.CPTCodeAndDescription)) {
        cy.wrap($cptRows)
          .first()
          .within(() => {
            /**
             * @Issue: Not able to mouse hover on trash icon for particular charge in charge entry page.
             * @Resolution: Mouse hover on the entire charge at initial time, Secondly, mouse hover on the trash icon and perform the click operation.
             */
            /** Added the force true inside of click to click on the hidden element of trash icon. To check on the multiple runs in dashboard based on updated code.*/
            cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.TRASH_ICON[1]).click({
              force: true,
            });
          });
      }
    });
    cy.cGet(selectorFactory.getSpanText(YesOrNo.yes)).eq(1).click();
  }

  /**
   * @details To add the new add Supplies in Charge Entry page under My Tasks
   * @param cptData as model reference name to pass it in the function
   * @API - API's are available and Implemented Completely
   * @author - Harsh Ranjan
   */
  addSupplies(cptData: Cpt) {
    const interceptCollection =
      this.facesheetChargeEntryApis.interceptSearchSupplyButtonApi();
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.ADD_SUPPLIES[1],
      OR_FACE_SHEET_CHARGE_ENTRY.ADD_SUPPLIES[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_FACE_SHEET_CHARGE_ENTRY.SEARCH_SUPPLIES[1],
      OR_FACE_SHEET_CHARGE_ENTRY.SEARCH_SUPPLIES[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(
      selectorFactory.getBText(cptData.CPTCodeAndDescription),
      cptData.CPTCodeAndDescription
    );
    cy.cIntercept(interceptCollection);
    cy.cSelectListItem(
      OR_FACE_SHEET_CHARGE_ENTRY.SUPPLIES_SELECTION[1],
      OR_FACE_SHEET_CHARGE_ENTRY.SUPPLIES_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Click On Auto sort button
   * @api API's are available Implemented Completely
   * @author - Harsh Ranjan
   */
  clickOnAutoSort() {
    const interceptCollection =
      this.facesheetChargeEntryApis.interceptAutoSortApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.AUTO_SORT[1],
      OR_FACE_SHEET_CHARGE_ENTRY.AUTO_SORT[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
    /**
     * @Issue: Sometimes API is completing before checking the status and it is causing the failure
     * @Resolution: Added should  click of the label
     */
    cy.cClick(
      selectorFactory.getSpanText(OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
  }

  /**
   * @details To enter charge amount for charges
   * @param - amount
   * @API - API's are not available
   */
  enterChargeAmount(amount: string) {
    this.clickAmountLabel();
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[0],
      false,
      true
    );
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[1])
      .clear({ force: true })
      .focus();
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[0],
      false,
      true
    );
    cy.cType(
      OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_FACE_SHEET_CHARGE_ENTRY.CHARGE_AMOUNT[0],
      amount
    );
  }

  /**
   * @details To enter write-off for charges
   * @param amount
   * @API - API's are not available
   */
  enterWriteoff(amount: string) {
    cy.cType(
      OR_FACE_SHEET_CHARGE_ENTRY.WRITE_OFF[1],
      OR_FACE_SHEET_CHARGE_ENTRY.WRITE_OFF[0],
      amount
    );
  }

  /**
   * @details To  verify the Auto sort button is enabled or disabled
   * @param flag - to pass true or false
   * @API - API's are not available
   */
  verifyOnAutoSortButton(flag: boolean = true) {
    if (flag) {
      cy.cIsEnabled(
        OR_FACE_SHEET_CHARGE_ENTRY.AUTO_SORT[1],
        OR_FACE_SHEET_CHARGE_ENTRY.AUTO_SORT[0]
      );
    } else {
      cy.cHasClass(
        OR_FACE_SHEET_CHARGE_ENTRY.AUTO_SORT[1],
        OR_FACE_SHEET_CHARGE_ENTRY.AUTO_SORT[0],
        CommonClassAttributes.disabled,
        false,
        false
      );
    }
  }

  /**
   * @details To verify auto sort functionality
   * @param dataValues
   * @API - API's are not available
   * // To remove \n in between text so we using replace method so that it will display the text without \n
   */
  autoSort(dataValues: string[]) {
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.CPT_ROW[1])
      .should(ShouldMethods.visible)
      .each(function ($ele, index) {
        let expectedCpt = $ele.text();
        expect(expectedCpt.replace(/\n/g, '').trim()).to.contain(
          dataValues[index]
        );
      });
  }

  /**
   * @details To enter debit amount for charges
   * @param  index and amount
   * @API - API's are not available
   */
  enterDebitAmount(amount: string) {
    cy.cType(
      OR_FACE_SHEET_CHARGE_ENTRY.DEBIT_AMOUNT[1],
      OR_FACE_SHEET_CHARGE_ENTRY.DEBIT_AMOUNT[0],
      amount
    );
  }

  /**
   * @details To add write-off clicking on plus icon
   * @API - API's are not available
   */
  clickOnPlus() {
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.PLUS_ICON[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PLUS_ICON[0],
      false,
      true
    );
  }

  /**
   * @details Selecting period and batch for charges under my task charge entry
   * @param value
   * @param chargesInfo
   *  @Api - API's are not available
   */
  selectPeriodAndBatchForCharge(value: number, chargesInfo: Charges) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(
      selectorFactory.getStrongText(
        OR_CHARGE_ENTRY.CHARGE_ENTRY.REFERRING_PHYSICIAN[0]
      )
    ).click();
    cy.cGet(selectorFactory.selectPeriod(value), '').click({ force: true });
    cy.cClick(
      selectorFactory.getDropdownValues(chargesInfo.Period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(selectorFactory.selectBatch(value), '')
      .should(ShouldMethods.exist)
      .click({ force: true });
    cy.cClick(
      selectorFactory.getDropdownValues(chargesInfo.Batch),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details To verify Ready for bill text in Charge entry
   * @API - API's are not available
   */
  verifyReadyForBill() {
    cy.cIsVisible(
      OR_FACE_SHEET_CHARGE_ENTRY.READY_BILL[1],
      OR_FACE_SHEET_CHARGE_ENTRY.READY_BILL[0]
    );
  }

  /**
   * @details To drag and drop charges in charge entry
   * @param startCharge
   * @param dropCharge
   * @API - API's are available - Implemented Completely
   * @author - Harsh Ranjan
   */
  dragAndDropCharges(startCharge: string, dropCharge: string) {
    const interceptCollection =
      this.facesheetChargeEntryApis.interceptDragAndDropApi();
    cy.cIntercept(interceptCollection);
    cy.dragAndDrop(
      selectorFactory.dragAndDrop(startCharge),
      selectorFactory.dragAndDrop(dropCharge)
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To enter Modifier drop down search bar
   * @param - value
   * @API - API's are not available
   */
  enterModifierDropdownSearchBar(value: Charges) {
    // This Assertion is added because the modifier dropdown is in the top of the page and unable to click properly
    this.assertModifierInChargeEntry();
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_1[1],
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_1[0]
    );
    cy.cClick(
      selectorFactory.getStrongText(
        OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_DROPDOWN[0]
      ),
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_DROPDOWN[1]
    );
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_DROPDOWN[1],
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_DROPDOWN[0]
    ).then(() => {
      cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_SEARCH_BOX[1]).type(
        value.Modifier!
      );
    });
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_VALUE[1],
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_VALUE[0]
    );
  }

  /**
   * Verifying write off of an expanded procedure
   * @param - modifier1
   * @API - API's are not available
   */
  verifyModifier(modifier1: string) {
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_DROPDOWN[1]).should(
      ShouldMethods.contain_text,
      modifier1
    );
  }

  /**
   * Verifying balance amount of an expanded procedure code
   * @param - value
   * @API - API's are not available
   */
  updateUnit(value: Charges) {
    cy.cType(
      OR_FACE_SHEET_CHARGE_ENTRY.UPDATE_UNITS[1],
      OR_FACE_SHEET_CHARGE_ENTRY.UPDATE_UNITS[0],
      value.Units
    );
  }

  /**
   * Verifying write Off is not present
   * @API - API's are not available
   */
  verifyNoChargeResults() {
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.NO_RESULTS[1]).should(
      ShouldMethods.contain_text,
      OR_FACE_SHEET_CHARGE_ENTRY.NO_RESULTS[0]
    );
  }

  /**
   * @details - searching for contract and clicking on review/edit
   * @param revenueCode
   * @API - API's are not available
   */
  selectRevenueCode(revenueCode: string) {
    // Added remove mask wrapper to select and click on the dropdown
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.REVENUE_CODE[1],
      OR_FACE_SHEET_CHARGE_ENTRY.REVENUE_CODE[0]
    );
    cy.cClick(
      selectorFactory.getDropdownValues(revenueCode),
      OR_FACE_SHEET_CHARGE_ENTRY.REVENUE_CODE[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    // Added remove mask wrapper because it will help to once this action complete it will click on the other fields
  }

  /**
   * @details - To drag and drop specific CPT Charge in My Tasks - Charge Entry
   * @param - amount
   * @API - API's are not available
   */
  verifyDebitAmount(amount: string) {
    cy.cHasValue(
      OR_FACE_SHEET_CHARGE_ENTRY.DEBIT_AMOUNT[1],
      OR_FACE_SHEET_CHARGE_ENTRY.DEBIT_AMOUNT[0],
      amount
    );
  }

  /**
   * Click balance header of an expanded procedure code
   * @API - API's are not available
   */
  clickBalanceLabel() {
    cy.cClick(
      selectorFactory.getSpanText(OR_FACE_SHEET_CHARGE_ENTRY.BALANCE_AMOUNT[0]),
      OR_FACE_SHEET_CHARGE_ENTRY.BALANCE_AMOUNT[0]
    );
  }

  /**
   * @details - clicking on Contracts
   * @param count as parameters inside the function
   * @API - API's are not available
   */
  performItems(count: number) {
    for (let i = 0; i <= count; i++) {
      cy.cClick(
        OR_FACE_SHEET_CHARGE_ENTRY.PERFORMED_ITEMS[1],
        OR_FACE_SHEET_CHARGE_ENTRY.PERFORMED_ITEMS[0]
      );
    }
  }

  /**
   * @details - clicking on Contracts
   * @param count as parameters inside the function
   * @API - API's are not available
   */
  performActionOnContracts(count: number) {
    for (let i = 0; i <= count; i++) {
      cy.cClick(
        OR_FACE_SHEET_CHARGE_ENTRY.CONTRACTS_TITLE[1],
        OR_FACE_SHEET_CHARGE_ENTRY.CONTRACTS_TITLE[0]
      );
    }
  }

  /**
   * @details - verify amount in charge entry after updating unit value
   * @param  value
   * @param index
   * @API - API's are not available
   */
  verifyAmount(value: string, index: number) {
    cy.cGet(selectorFactory.verifyingAmountInChargeEntry(index)).should(
      ShouldMethods.value,
      value
    );
  }

  /**
   * @details - verifying performed Items label
   * @API - API's are not available
   */
  verifyPerformItems() {
    cy.cIsVisible(
      OR_FACE_SHEET_CHARGE_ENTRY.PERFORMED_ITEMS[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PERFORMED_ITEMS[0]
    );
  }

  /**
   * @details - verifying performed Items label
   * @API - API's are available - Implemented Completely
   * @author - Harsh Ranjan
   */
  clickUpdateButton() {
    const interceptCollection =
      this.facesheetChargeEntryApis.interceptUpdateBtnApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.UPDATE[1],
      OR_FACE_SHEET_CHARGE_ENTRY.UPDATE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To enter HCPCS of the supply
   * @param - cptData
   * @API - API's are not available
   */
  enterHcpcs(cptData: Cpt) {
    cy.cType(
      OR_FACE_SHEET_CHARGE_ENTRY.HCPCS[1],
      OR_FACE_SHEET_CHARGE_ENTRY.HCPCS[0],
      cptData.HCPCS
    );
  }

  /**
   * Verifying write off of an expanded procedure
   * @param - writeOffAmount
   * @API - API's are not available
   */
  validateWriteOff(writeOffAmount: string) {
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.WRITEOFF_AMOUNT[1])
      .scrollIntoView()
      .should(ShouldMethods.contain_text, writeOffAmount);
  }

  /**
   * Verifying balance amount of an expanded procedure code
   * @param - balanceAmount
   * @API - API's are not available
   */
  verifyBalance(balanceAmount: string) {
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.BALANCE_AMOUNT[1]).should(
      ShouldMethods.contain_text,
      balanceAmount
    );
  }

  /**
   * Click Amount header of an expanded procedure code
   * @API -  API's are not available
   */
  clickAmountLabel() {
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.AMOUNT_LABEL[1],
      OR_FACE_SHEET_CHARGE_ENTRY.AMOUNT_LABEL[0]
    );
  }

  /**
   * Click Diagnosis Codes header of an expanded procedure code
   * @API -  API's are not available
   */
  clickDiagnosisCodesLabel() {
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.AMOUNT_LABEL[1],
      OR_FACE_SHEET_CHARGE_ENTRY.AMOUNT_LABEL[0]
    );
  }

  /**
   * @details To verify Generate bill as checked
   * @param cpt as param to check procedure bill is checked
   * @API -  API's are not available
   * @author Madhu Kiran
   */
  verifyGenerateBillAsChecked(cpt: string) {
    cy.cIsVisible(
      selectorFactory.getGenerateBillAsChecked(cpt),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.GENERATE_BILL[0]
    );
  }

  /**
   * @details To select Review Edit
   * @APIs are Available - Implemented Completely
   */
  selectReviewEdit() {
    const interceptCollection =
      this.nursingConfigApis.interceptProcedureSearchContract();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.REVIEW_EDIT[1],
      OR_FACE_SHEET_CHARGE_ENTRY.REVIEW_EDIT[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   *@detail - assertionToLoadFaceSheetChargeEntry method can be used immediately after selecting charge entry in face-sheet my task
   *@API -  API's are not available
   */
  assertToLoadFaceSheetChargeEntry() {
    const itemsToCheck = [
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_BUTTON[1],
      OR_COMBINED_CODING.READY_FOR_BILL_NO[1],
    ];
    const itemsToClick = [
      OR_FACE_SHEET_CHARGE_ENTRY.PERFORMED_ITEMS[1],
      CoreCssClasses.Text.loc_label_text,
    ];
    itemsToClick.forEach((itemsToClick) =>
      cy.cClick(itemsToClick, OR_FACESHEET_CASE_PAGE.NOTES.NOTES_BUTTON[0])
    );

    itemsToCheck.forEach((itemsToCheck) => cy.shouldBeEnabled(itemsToCheck));
  }

  /**
   * @detail - assertionToLoadPerformedItems method can be used immediately after clicking on procedure plus icon in face-sheet charge entry
   * @API -  API's are not available
   */
  assertPerformedItem() {
    const itemsToCheck = [
      OR_FACE_SHEET_CHARGE_ENTRY.PERIOD_DROPDOWN_ICON[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PHYSICIAN_DROPDOWN_ICON[1],
      OR_FACE_SHEET_CHARGE_ENTRY.BATCH_DROPDOWN_ICON[1],
      OR_FACE_SHEET_CHARGE_ENTRY.REVENUE_CODE_DROPDOWN_ICON[1],
    ];
    itemsToCheck.forEach((itemsToCheck) => cy.shouldBeEnabled(itemsToCheck));
  }

  /**
   * @details : There are two possible scenarios for expanding or collapsing procedure code based on the index in the facesheet chargeEntry.
   * The first scenario involves collapsing the code without making an API call,
   * while the second scenario involves triggering an API call when saving the data.
   * @param : state (expand or collapse)
   * @param : index (index of expand/collapse icon that we want to click)
   * @APIs are Available - Implemented Completely
   */
  performExpandCollapseForSaving(state: string, index: number = 0) {
    const interceptCollection =
      this.facesheetChargeEntryApis.interceptSavePerformedProcedureApi();
    if (state == ExpandOrCollapse.expand) {
      sisOfficeDesktop.performAction(state, index);
    } else {
      cy.cIntercept(interceptCollection);
      sisOfficeDesktop.performAction(state, index);
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - Assertion method for modifier
   * @APIs are Not Available
   */
  assertModifierInChargeEntry() {
    const modifiers = [
      OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_DROPDOWN[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PERIOD_DROPDOWN_ICON[1],
      OR_FACE_SHEET_CHARGE_ENTRY.BATCH_DROPDOWN_ICON[1],
    ];

    modifiers.forEach((modifier) => {
      cy.shouldBeEnabled(modifier);
    });
  }

  /**
   * @details - Verify the diagnosis code added to the charge
   * @param  value as diagnosis code should be provided as the parameter
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyDiagnosisCode(value: string) {
    cy.cIsVisible(selectorFactory.getDiagnosisCode(value), value);
  }

  /**
   * @details - To Verify CPT procedure added to the case
   * @param value as cpt should be provided as the parameter
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyCPTProcedure(value: string) {
    cy.cIsVisible(selectorFactory.getProcedureInChargeEntry(value), value);
  }
}
