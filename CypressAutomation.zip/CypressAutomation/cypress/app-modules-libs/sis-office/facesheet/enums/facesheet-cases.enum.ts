/* enum values*/
export enum FaceSheetOptions {
  CASE_DETAILS = 'Case Details',
  PAYER_DETAILS = 'Payer',
  FINANCIAL_CLEARANCE = 'Financial Clearance',
  ATTACHMENTS = 'Attachments',
  FORMS_AND_CONSENTS = 'Forms & Consents',
  INVENTORY = 'Inventory',
  CODING = 'Coding',
  CHARGE_ENTRY = 'Charge',
  TRANSACTIONS = 'Transactions',
}
