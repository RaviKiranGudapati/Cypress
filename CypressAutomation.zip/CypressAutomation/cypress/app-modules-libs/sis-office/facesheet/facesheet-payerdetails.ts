import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FacesheetPayerDetailsApis } from './api/facesheet-payerdetails.api';

/**
 * Class for payer details tab in Facesheet
 */
export default class PayerDetailsFaceSheet {
  /* instance variables */
  private facesheetPayerDetails = new FacesheetPayerDetailsApis();
  

  /**
   * @details - click on update button in the payer details
   * @API - API's are available - Implemented Completely
   * @author - Praveen
   */
  clickUpdateButtonInPayerDetails() {
    const interceptCollection =
      this.facesheetPayerDetails.interceptUpdateButtonPayerDetailsApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.UPDATE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.UPDATE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }
}
