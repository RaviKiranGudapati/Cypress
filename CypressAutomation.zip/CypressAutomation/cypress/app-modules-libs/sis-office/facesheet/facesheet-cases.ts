import { InvokeMethods } from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

import { td_case_header_tcid_261978 } from '../../../fixtures/sis-office/facesheet/case-header-tcid-261978.td';

import { PatientCase } from '../../../test-data-models/sis-office/case/patient-case.model';
import {
  PatientDummyDetails,
  PrintPreview,
} from '../../../test-data-models/sis-office/case/print-preview.model';

import { OR_CHARGE_ENTRY } from '../trackers/or/charge-entry.or';
import { OR_FACESHEET_CASE_PAGE } from './or/facesheet-cases.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_FACESHEET_LEDGER_TAB } from './or/facesheet-ledger.or';
import { OR_TRANSACTION } from './or/facesheet-transactions.or';

import { FaceSheetOptions } from './enums/facesheet-cases.enum';

import { FacesheetCasesApis } from './api/facesheet-cases.api';

const fields = [
  'Appeal Letters',
  'Case Consents',
  'Op Notes',
  'Implant Log',
  'Patient Demographics Form',
  'Patient Estimate',
  'Patient Labels',
  'Pick List',
];

export default class FaceSheetCases {
  /* instance variables */
  private facesheetCases = new FacesheetCasesApis();

  constructor(private patientCase?: PatientCase) {}

  get PatientCaseModel(): PatientCase {
    return this.patientCase!;
  }

  /**
   * @details - Selecting Case option in Face sheet Cases
   * @param CaseOption - Case Details/Transactions/Coding
   * @API - API's are available - Implemented
   * @Author - Praveen
   */
  //TODO: This method must be in Facesheet-cases.ts page will be moved as part of cleanup activity
  faceSheetSelectCaseOption(CaseOption: string) {
    let interceptCollection: ApiEndpoint[] = [];
    switch (CaseOption) {
      case FaceSheetOptions.TRANSACTIONS:
        interceptCollection =
          this.facesheetCases.interceptTransactionsCaseOptionsApi();
        break;
      case FaceSheetOptions.CASE_DETAILS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetCaseDetailsApi();
        break;
      case FaceSheetOptions.PAYER_DETAILS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetPayerDetailsApi();
        break;
      case FaceSheetOptions.FORMS_AND_CONSENTS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetFormsAndConsentApi();
        break;
      // As api calls are same for both Attachment and Financial Clearance
      // using same intercept method for attachment option
      case FaceSheetOptions.ATTACHMENTS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetFinancialApi();
        break;
      case FaceSheetOptions.INVENTORY:
        interceptCollection =
          this.facesheetCases.interceptFacesheetInventoryApi();
        break;
      case FaceSheetOptions.CHARGE_ENTRY:
        interceptCollection =
          this.facesheetCases.interceptFacesheetChargeEntryApi();
        break;
      case FaceSheetOptions.CODING:
        interceptCollection = this.facesheetCases.interceptFacesheetCodingApi();
        break;
      case FaceSheetOptions.FINANCIAL_CLEARANCE:
        interceptCollection =
          this.facesheetCases.interceptFacesheetFinancialApi();
        break;
      default:
        break;
    }

    cy.cIntercept(interceptCollection);
    cy.cGet(OR_TRANSACTION.CHARGES.FACE_SHEET_CASE_DETAILS_BLOCK[1]).then(
      ($val) => {
        if ($val.find(OR_TRANSACTION.CHARGES.PLUS_ICON[1]).length > 0) {
          cy.cClick(
            OR_TRANSACTION.CHARGES.PLUS_ICON[1],
            OR_TRANSACTION.CHARGES.PLUS_ICON[0]
          );
          cy.cClick(selectorFactory.getSpanText(CaseOption), CaseOption);
        } else {
          cy.cClick(selectorFactory.getSpanText(CaseOption), CaseOption);
        }
      }
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify case header details in  My Tasks and Schedule grid trackers
   * @param - options refers case status
   *  @API - API calls are not available
   */
  verifyCaseHeader(options: string) {
    this.verifyDOS();
    this.selectCaseStatus(options);
    this.verifyProcedureDetails();
  }

  /**
   * @details - verify patient case procedures details in case header under My Task
   * @API - API calls are not available
   */
  verifyProcedureDetails() {
    cy.cGet(
      `${OR_FACESHEET_CASE_PAGE.CASE_HEADER} ${selectorFactory.getSpanText(
        td_case_header_tcid_261978.CaseHeaderDetails[0].ProcDetails![0]
      )}`
    ).then(($text) => {
      const expectedString = $text.text().split(',', 3);
      td_case_header_tcid_261978.CaseHeaderDetails[0].ProcDetails!.forEach(
        ($value, index) => {
          if (index === 2) {
            const expectedString1 = expectedString[index].split(
              td_case_header_tcid_261978.PatientCase[0].CaseDetails
                .CptCodeInfo[1].CPTCodeAndDescription,
              1
            );
            expect(expectedString1[0].trim()).to.contains(
              td_case_header_tcid_261978.CaseHeaderDetails[0].ProcDetails![
                index
              ]
            );
          } else {
            expect(expectedString[index].trim()).to.contains(
              td_case_header_tcid_261978.CaseHeaderDetails[0].ProcDetails![
                index
              ]
            );
          }
        }
      );
    });
  }

  /**
   * @details - verify patient DOS details in case header under My Task
   * @API - API calls are not available
   */
  verifyDOS() {
    cy.cGet(
      `${OR_FACESHEET_CASE_PAGE.CASE_HEADER} ${selectorFactory.getSpanText(
        td_case_header_tcid_261978.CaseHeaderDetails[0].DOS!
      )}`
    ).then(($text) => {
      expect($text.text().trim()).to.contain(
        td_case_header_tcid_261978.CaseHeaderDetails[0].DOS
      );
    });
  }

  /**
   * @details - verify the primary insurance dropdown on payer details in the my tasks
   *  @API - API calls are not available
   */
  verifyPrimaryInsurance(option: string) {
    cy.cIsVisible(
      selectorFactory.primaryInsurance(option),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PRIMARY_INSURANCE_CLEAR[0]
    );
  }

  /**
   * @details - verify the case status
   * @param  value as parameter using in the function
   * @API - API calls are not available
   */
  verifyCaseStatus(value: string) {
    cy.cGet(OR_FACESHEET_CASE_PAGE.CASE_STATUS[1]).then((status) => {
      expect(status.text()).to.eq(value);
    });
  }

  /**
   *  @details - To verify the facesheet title
   *  @param - titleName as string argument passed inside of function
   * @API - API calls are not available
   */
  verifyFacesheetTitle(titleName: string) {
    cy.cGet(OR_FACESHEET_CASE_PAGE.FACE_SHEET_TITLE[1])
      .invoke(InvokeMethods.text)
      .then(($title) => {
        expect($title.replace(/\n/g, '').trim()).to.contains(titleName);
      });
  }

  /**
   * @details - verify patient MRN details in case header under My Task
   * @param - MRN refers patient mrn value from facesheet page
   * @API - API calls are not available
   */
  verifyMRN(mrn: any) {
    cy.cIsVisible(
      OR_FACESHEET_CASE_PAGE.CASE_HEADER_MRN[1],
      OR_FACESHEET_CASE_PAGE.CASE_HEADER_MRN[0]
    );
    cy.cGet(OR_FACESHEET_CASE_PAGE.CASE_HEADER_MRN[1]).then(($text) => {
      expect($text.text().trim()).to.contain(mrn);
    });
  }

  /**
   * @details - verify patient case status details in case header under My Task
   * @param - option refers the CaseStatusOptions
   * @API - API calls are not available
   */
  selectCaseStatus(option: string) {
    cy.cGet(
      `${OR_FACESHEET_CASE_PAGE.CASE_HEADER} ${selectorFactory.getSpanText(
        option
      )}`
    ).then(($text) => {
      expect($text.text().trim()).to.contain(option);
    });
  }

  /**
   * @details - Select MRN path in facesheet page
   * @API - API calls are not available
   */
  selectMRNPath() {
    cy.cIsVisible(OR_FACESHEET_CASE_PAGE.MRN[1], OR_FACESHEET_CASE_PAGE.MRN[0]);
    cy.cIsVisible(
      OR_FACESHEET_CASE_PAGE.NOTES_BUTTON[1],
      OR_FACESHEET_CASE_PAGE.NOTES_BUTTON[0]
    );
    return cy.cGet(OR_FACESHEET_CASE_PAGE.MRN[1]);
  }

  /**
   * @details - ClickOnNotesButton
   * @API - API calls are available - Implemented
   * @Author - Praveen
   */
  clickNotesButton() {
    const interceptCollection =
      this.facesheetCases.interceptFacesheetNotesApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_BUTTON[1],
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_BUTTON[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Add Notes in Notes Popup Opened
   * @param - notes
   * @API - API calls are available - Implemented
   * @Author - Praveen
   */
  addNotes(notes: string) {
    const interceptCollection =
      this.facesheetCases.interceptFacesheetSaveNotesApi();
    cy.cClick(
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[1],
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[0],
      false,
      true
    );
    cy.cType(
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[1],
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[0],
      notes,
      false,
      true
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getSpanText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
      ),
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cNotExist(
      OR_FACESHEET_CASE_PAGE.NOTES.DIALOG_BOX[1],
      OR_FACESHEET_CASE_PAGE.NOTES.DIALOG_BOX[0]
    );
  }

  /**
   * @details - Verify the Notes Added in My Tasks
   * @param notes
   * @API - API calls are not available
   */
  verifyAddedNotes(notes: string) {
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.NOTES.ADDED_NOTES[1],
      OR_FACESHEET_CASE_PAGE.NOTES.ADDED_NOTES[0],
      notes
    );
    cy.cClick(
      selectorFactory.getSpanText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
      ),
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
  }

  /**
   * @details - To verify the primary procedure panel in consents
   * @param procedure
   * @API - API calls are not available
   */
  verifyPrimaryProcedure(procedure: string) {
    cy.cGet(
      OR_FACESHEET_CASE_PAGE.FORMS_AND_CONSENTS.PRIMARY_PROCEDURE_PANEL[1]
    )
      .invoke(InvokeMethods.text)
      .then((value) => {
        expect(value).to.contains(procedure);
      });
  }

  /**
   * @details - Click on done in add notes in facesheet
   * @API - API calls are available - Implemented
   * @Author - Praveen
   */
  addNotesDone() {
    const interceptCollection =
      this.facesheetCases.interceptFacesheetSaveNotesApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getSpanText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
      ),
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify print window in print popup
   * @API - API calls are not available
   */
  verifyPrintWindow() {
    cy.cIsVisible(
      OR_FACESHEET_CASE_PAGE.PRINT[1],
      OR_FACESHEET_CASE_PAGE.PRINT[0]
    );
  }

  /**
   * @details - Select options in print popup
   * @param - option
   * @API - API calls are not available
   */
  selectOptionInPrintPopup(option: string) {
    cy.cGet(selectorFactory.getDataTestId(option)).dblclick();
  }

  /**
   * @details - Select options in print popup and click on Print Preview
   * @param - option
   * @API - API calls are available - Implemented
   * @Author - Praveen
   */
  selectOptionsInPrintPopupClickPreview(option: string) {
    const interceptCollection = this.facesheetCases.interceptPreviewApi();
    fields.forEach((field) => {
      cy.shouldBeEnabled(selectorFactory.getDataTestId(field));
    });
    cy.shouldBeEnabled(OR_FACESHEET_LEDGER_TAB.ALLOCATION.CLOSE_ICON[1]);
    cy.shouldBeEnabled(selectorFactory.getDataTestId(option));

    if (option == OR_FACESHEET_CASE_PAGE.APPEAL_LETTERS[0]) {
      cy.cIntercept(interceptCollection);
      cy.cClick(
        selectorFactory.getSpanText(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
        ),
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
      );
      cy.cWaitApis(interceptCollection);
    }
    // Added to rendering issue clicking double time
    this.selectOptionInPrintPopup(option);

    if (option == OR_FACESHEET_CASE_PAGE.PATIENT_LABELS[0]) {
      const interceptCollection =
        this.facesheetCases.interceptPreviewPatientLabelApi();
      cy.cIntercept(interceptCollection);
      cy.cClick(
        OR_FACESHEET_CASE_PAGE.PREVIEW_BUTTON[1],
        OR_FACESHEET_CASE_PAGE.PREVIEW_BUTTON[0]
      );
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cIntercept(interceptCollection);
      cy.cClick(
        OR_FACESHEET_CASE_PAGE.PREVIEW_BUTTON[1],
        OR_FACESHEET_CASE_PAGE.PREVIEW_BUTTON[0]
      );
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - Verify preview options in  print preview window
   * @API - API calls are not available
   */
  verifyPreviewOptionsInFacesheet() {
    cy.cIsVisible(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[0]
    );
    cy.cIsVisible(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_ROW[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_ROW[0]
    );
    cy.cIsVisible(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_COLUMN[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_COLUMN[0]
    );
  }

  /**
   * @details - Verify preview values in print preview window
   * @param - printRec
   * @API - API calls are not available
   */
  verifyPreviewValuesFacesheet(printRec: PrintPreview) {
    cy.cHasValue(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[0],
      printRec.LabelPerPatient
    );
    cy.cHasValue(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_ROW[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_ROW[0],
      printRec.BeginRow
    );
    cy.cHasValue(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_COLUMN[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_COLUMN[0],
      printRec.BeginColumn
    );
  }

  /**
   * @details - Enter values in print preview window
   * @param - printRec
   * @API - API calls are available - Implemented
   * @Author - Praveen
   */
  enterValuesInPreview(printRec: PrintPreview) {
    const interceptCollection =
      this.facesheetCases.interceptPreviewPatientLabelApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[0],
      printRec.LabelPerPatient
    );
    cy.cWaitApis(interceptCollection);
    cy.cType(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_ROW[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_ROW[0],
      printRec.BeginRow
    );

    cy.cType(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_COLUMN[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_COLUMN[0],
      printRec.BeginColumn
    );
  }

  /**
   * @details - Click on preview window title in print popup
   * @API - API calls are not available
   */
  clickOnPreviewInPrint() {
    cy.cClick(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PREVIEW[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PREVIEW[1],
      false,
      false,
      { force: true }
    );
  }

  /**
   * @details - Clear values in print popup
   * @API - API calls are available - Implemented
   * @Author - Praveen
   */
  clearValuesInPreview() {
    const interceptCollection =
      this.facesheetCases.interceptPreviewPatientLabelApi();
    cy.cIntercept(interceptCollection);
    cy.cClear(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[1]
    );
    cy.cWaitApis(interceptCollection);
    cy.cClear(OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_ROW[1]);
    cy.cClear(OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.BEGIN_COLUMN[1]);
  }

  /**
   * @details - Verify patient demographics form
   * @API - API calls are not available
   */
  verifyPatientDemographicsForm() {
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PREVIEW[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PREVIEW[0],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PREVIEW[0]
    );
  }

  /**
   * @details - Verify dummy patient details in preview popup
   * @param - patient
   * @API - API calls are not available
   */
  verifyDummyPatientDetails(patient: PatientDummyDetails) {
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_NAME[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_NAME[0],
      patient.PatientName!
    );
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[0],
      patient.DOB!
    );
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[0],
      patient.DOS!
    );
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[0],
      patient.MRN!
    );
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[0],
      patient.Gender!
    );
    cy.cIncludeText(
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[1],
      OR_FACESHEET_CASE_PAGE.PATIENT_LABELS_POPUP.PATIENT_DETAILS[0],
      patient.Physician!
    );
  }

  /**
   * @details - To verify print preview model open on clicking print preview
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyPrintPreviewOpen() {
    cy.cIsVisible(
      OR_FACESHEET_CASE_PAGE.PRINT_PREVIEW_MODEL.PREVIEW_TEXT[1],
      OR_FACESHEET_CASE_PAGE.PRINT_PREVIEW_MODEL.PREVIEW_TEXT[0]
    );
  }

  /**
   * @details - To close the print preview model
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  closePrintPreviewModel() {
    cy.cClick(
      OR_FACESHEET_CASE_PAGE.PRINT_PREVIEW_MODEL.CLOSE_ICON[1],
      OR_FACESHEET_CASE_PAGE.PRINT_PREVIEW_MODEL.CLOSE_ICON[0]
    );
  }

  /**
   * @details - Selecting Case option in Face sheet Cases
   * @param caseOption - Case Details/Transactions/Coding
   * @param  cptDescription -to select Case option based on cpt
   * @API - API's are available - Implemented
   * @author - Madhu Kiran
   */
  //TODO: This method must be in Facesheet-cases.ts page will be moved as part of cleanup activity
  faceSheetSelectCaseOptionBaseCptDescription(
    caseOption: string,
    cptDescription: string
  ) {
    let interceptCollection: ApiEndpoint[] = [];
    switch (caseOption) {
      case FaceSheetOptions.TRANSACTIONS:
        interceptCollection =
          this.facesheetCases.interceptTransactionsCaseOptionsApi();
        break;
      case FaceSheetOptions.CASE_DETAILS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetCaseDetailsApi();
        break;
      case FaceSheetOptions.PAYER_DETAILS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetPayerDetailsApi();
        break;
      case FaceSheetOptions.FORMS_AND_CONSENTS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetFormsAndConsentApi();
        break;
      // As api calls are same for both Attachment and Financial Clearance
      // using same intercept method for attachment option
      case FaceSheetOptions.ATTACHMENTS:
        interceptCollection =
          this.facesheetCases.interceptFacesheetFinancialApi();
        break;
      case FaceSheetOptions.INVENTORY:
        interceptCollection =
          this.facesheetCases.interceptFacesheetInventoryApi();
        break;
      case FaceSheetOptions.CHARGE_ENTRY:
        interceptCollection =
          this.facesheetCases.interceptFacesheetChargeEntryApi();
        break;
      case FaceSheetOptions.CODING:
        interceptCollection = this.facesheetCases.interceptFacesheetCodingApi();
        break;
      case FaceSheetOptions.FINANCIAL_CLEARANCE:
        interceptCollection =
          this.facesheetCases.interceptFacesheetFinancialApi();
        break;
      default:
        break;
    }
    cy.cIntercept(interceptCollection);
    cy.cGet(selectorFactory.getSpanText(cptDescription))
      .parents(OR_FACESHEET_CASE_PAGE.SIS_CASE[1])
      .find(selectorFactory.getSpanText(caseOption))
      .click();
    cy.cWaitApis(interceptCollection);
  }
}
