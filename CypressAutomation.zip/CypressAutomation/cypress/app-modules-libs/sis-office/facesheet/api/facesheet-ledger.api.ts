import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class FacesheetLedgerApis {
  /**
   * @details -  Intercepts for add Unassigned Payment
   * @author - Madhu Kiran
   */
  interceptAddUnassignedPaymentApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_procedure_dos_by_Patient,
        'GetAllCaseProcedureDOSbyPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_responsible_parties,
        'GetPatientResponsibleParties',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.check_and_create_pg,
        'CheckAndCreatePG',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_details,
        'GetAllCaseDetails',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Done Allocation Unassigned Payment
   * @author - Madhu Kiran
   */
  interceptDoneAllocationUnassignedPayment(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.save_payment_transactions,
        'SavePaymentTransactions ',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facesheet_ledger_model_by_patient,
        'GetFaceSheetLedgerModelByPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.unassigned_payment,
        'UnassignedPayment',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Allocate Unassigned Payment
   * @author - Madhu Kiran
   */
  interceptAllocateUnassignedPayment(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
    ];
  }

  /**
   * @details - APIs while click on the ledger tab in Facesheet.
   * @author - Madhu Kiran
   */
  interceptLedgerTabSelection(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.unassigned_payment,
        'UnassignedPayment',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_charge_complex,
        'CaseToChargeComplex',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_data,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_procedure,
        'AllCaseProcedure',
        200
      ),
    ];
  }

  /**
   * @details - APIs while click for Done Add UnassignedPayment
   * @author - Madhu Kiran
   */
  interceptDoneAddUnassignedPayment(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.unassigned_payment,
        'UnassignedPayment',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for View Edit Unassigned Payment
   * @author - Madhu Kiran
   */
  interceptViewEditeUnassignedPayment(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_procedure,
        'GetAllCaseProcedureDOSbyPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_responsible_parties,
        'GetPatientResponsibleParties',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_details,
        'GetAllCaseDetails',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Delete Unassigned Payment
   * @author - Madhu Kiran
   */
  interceptDeleteUnassignedPayment(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.delete,
        SubRoutes.delete_unassigned_payment,
        'DeleteUnassignedPayment',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_charge_complex,
        'GetFaceSheetLedgerModelByPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.unassigned_payment,
        'UnassignedPayment',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Billing History
   * @author - Madhu Kiran
   */
  interceptForBillingHistory(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_statements_config,
        'PatientStatementsConfig',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_billing_with_history_for_patient,
        'GetBillingWithHistoryForPatient',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Notes
   * @author - Madhu Kiran
   */
  interceptForNotes(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Claim Status
   * @author - Madhu Kiran
   */
  interceptForClaimStatus(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_billing_with_history_for_patient,
        'GetBillingWithHistoryForPatient',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Bill Selected charges Yes or NO
   * @author - Madhu Kiran
   */
  interceptForBillSelectedChargeYesOrNo(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_patient_statement_details,
        'GetPatientStatementDetails',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on billed checkbox
   * @author - Nikitan
   */
  interceptForBilledCheckbox(): ApiEndpoint[] {
    return [
      new ApiEndpoint(WaitMethods.post, SubRoutes.charge_unbill, 'UnBill', 200),
    ];
  }

  /**
   * @details - Intercept for clicking on Bill Selected Insurance Charge button in Billing History
   * @author - Nikitan
   */
  interceptForBillSelectedInsuranceCharge(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.bill_insurance_carrier,
        'BillInsurance',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for getting patient charges in Ledger screen
   * @author - Nikitan
   */
  interceptForLedgerCharges(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.facesheet_ledger,
        'LedgerCharge',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on Print Selected Insurance Charge from Billing history
   * @author - Nikitan
   */
  interceptForPrintInsuranceCharge(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.print_insurance_charge,
        'PrintInsurance',
        200
      ),
    ];
  }
}
