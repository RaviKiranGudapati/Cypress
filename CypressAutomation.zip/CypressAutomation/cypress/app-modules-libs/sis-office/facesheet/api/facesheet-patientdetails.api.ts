import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class FacesheetPatientDetailsApis {
  /**
    @details - This method intercepts the patient details API and selects the patient details tab in sis-office face-sheet.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptPatientDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_data,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'PatientGuarantor',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_security,
        'Security',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the Insurance Add button API and click on the  Insurance coverage add button in patient details tab in sis-office face-sheet.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptInsuranceAddButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_carriers,
        'GetInsuranceCarriers',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_current_facility_addresses,
        'CurrentFacilityAddresses',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the Insurance carrier dropdown value API and select the  Insurance carrier dropdown value  in insurance coverage pop-up in patient details tab in sis-office face-sheet.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptInsuranceCarrierDropdownApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_plan,
        'InsurancePlan',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance,
        'Insurance',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the Guarantor Add button API and click on the  Guarantor add button in patient details tab in sis-office face-sheet.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptGuarantorAddButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_current_facility_addresses,
        'CurrentFacilityAddresses',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the patient first name API and click on the patient first name label after editing the name in patient details tab in sis-office face-sheet.
    @author - Harsh Ranjan
  */
  interceptEditFirstNameApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.create_patient,
        'CreatePatient',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the case tab API and selects the case tab in sis-office face-sheet.
    @author - Harsh Ranjan
  */
  interceptCaseTabApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facesheet_list,
        'FacesheetList',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the Financial Clearance tab API and selects the Financial Clearance Tab in my task in sis-office face-sheet.
    @author - Harsh Ranjan
  */
  interceptFinancialClearanceApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_account_data,
        'UserAccountData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_mpi_patient_self_pay_verification_by_case_summary_id,
        'MpiPatientSelfPay',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_faceSheet_ledger_aging_by_case,
        'FacesheetLedgerAgingByCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_security_lock,
        'PostSecurityLock',
        200
      ),
    ];
  }
}
