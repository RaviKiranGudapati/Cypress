import { CommonGetLocators } from '../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { PatientDetails } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_PATIENT_CASE_CREATION } from '../case-creation/or/create-case.or';
import { OR_FACESHEET_PATIENT_DETAILS_TAB } from './or/facesheet-patientdetails.or';

import { FacesheetPatientDetailsApis } from './api/facesheet-patientdetails.api';

/**
 * Class for patient details tab in Facesheet
 */
export default class PatientDetailsFaceSheet {
  /* instance variables */
  private facesheetPatientDetails = new FacesheetPatientDetailsApis();

  private orPatientDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS;

  /**
   * @details - Click on patient details tab
   * @APIs are available - Implemented Completely
   * @author - Harsh Ranjan
   */
  clickOnPatientDetailsTab() {
    const interceptCollection =
      this.facesheetPatientDetails.interceptPatientDetailsApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_DETAILS_TAB[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_DETAILS_TAB[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Edit First name in patient details tab but the name should not be updated as the user has not the permission to edit or modify.
   * @param name
   * @APIs are available - Implemented Completely
   * @Author Harsh
   */
  editFirstNameInPatientDetailsTabViewOnly(name: string) {
    cy.cClick(
      OR_FACESHEET_PATIENT_DETAILS_TAB.EDIT_FIRST_NAME[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.EDIT_FIRST_NAME[0]
    );
    cy.cType(
      OR_FACESHEET_PATIENT_DETAILS_TAB.EDIT_FIRST_NAME[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.EDIT_FIRST_NAME[0],
      name
    );
    cy.cClick(
      OR_FACESHEET_PATIENT_DETAILS_TAB.FIRST_NAME_LABEL[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.FIRST_NAME_LABEL[0]
    );
  }

  /**
   * @details - Click on case tab in Facesheet
   * @APIs are available - Implemented Completely
   * @Author Harsh
   */
  clickOnCasesTab() {
    const interceptCollection =
      this.facesheetPatientDetails.interceptCaseTabApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_PATIENT_DETAILS_TAB.CASES_TAB[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.CASES_TAB[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verify patient name in Patient details tab
   * @param PatientFirstName - Patient first name
   * @APIs are not available
   */
  verifyPatientNameInPatientDetailsTab(PatientFirstName: string) {
    cy.cHasValue(
      OR_FACESHEET_PATIENT_DETAILS_TAB.EDIT_FIRST_NAME[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.EDIT_FIRST_NAME[0],
      PatientFirstName
    );
  }

  /**
   * @details - Select Financial clearance in Facesheet
   * @APIs are available - Implemented Completely
   * @Author Harsh
   */
  selectLockedFinancialClearance() {
    const interceptCollection =
      this.facesheetPatientDetails.interceptFinancialClearanceApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_PATIENT_DETAILS_TAB.FINANCIAL_CLEARANCE[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.FINANCIAL_CLEARANCE[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @APIs are not available
   */
  waitForPdToLoad() {
    cy.cIsVisible(
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_TITLE[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_TITLE[0]
    );
  }

  /**
   * @details - Verify lock message in Facesheet
   * @param - lockMessage
   * @APIs are not available
   */
  verifyLockMessageInFacesheetOptions(lockMessage: any) {
    cy.cIsVisible(
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_LOCK_MESSAGE_FACESHEET[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_LOCK_MESSAGE_FACESHEET[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_LOCK_MESSAGE_FACESHEET[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.PATIENT_LOCK_MESSAGE_FACESHEET[0],
      lockMessage
    );
  }

  /**
   * @details - Verify dropdown field values displayed in Patient details tab
   * @param fieldName - Dropdown field name
   * @param dropdownVal - Value from dropdown
   * @APIs are not available
   */
  verifyDisplayedValPatientDetailsTab(fieldName: string, dropdownVal: string) {
    const fields = {
      [OR_FACESHEET_PATIENT_DETAILS_TAB.RACE[0]]:
        OR_FACESHEET_PATIENT_DETAILS_TAB.RACE[0],
      [OR_FACESHEET_PATIENT_DETAILS_TAB.ETHNICITY[0]]:
        OR_FACESHEET_PATIENT_DETAILS_TAB.ETHNICITY[0],
      [OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
        .PRIMARY_LANGUAGE[0]]:
        OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
          .PRIMARY_LANGUAGE[0],
    };
    const field = fields[fieldName];
    cy.cIsVisible(dropdownVal, field, true);
  }

  /**
   * @details - Click on add in patient details tab in facesheet
   * @APIs are available - Implemented Completely
   * @author - Harsh Ranjan
   */
  clickAddInsurance() {
    const interceptCollection =
      this.facesheetPatientDetails.interceptInsuranceAddButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_PATIENT_DETAILS_TAB.ADD_INSURANCE[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.ADD_INSURANCE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select the value in Insurance Carrier dropdown
   * @APIs are available - Implemented Completely
   * @author - Harsh Ranjan
   */
  selectInsuranceCarrierDropdownValue() {
    const interceptCollection =
      this.facesheetPatientDetails.interceptInsuranceCarrierDropdownApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_PATIENT_DETAILS_TAB.INSURANCE_CARRIER_DROPDOWN_VALUE[1],
      OR_FACESHEET_PATIENT_DETAILS_TAB.INSURANCE_CARRIER_DROPDOWN_VALUE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on add in patient details tab in facesheet
   * @APIs are not available
   */
  assertionsForPatientDetailsLoad() {
    cy.shouldBeEnabled(OR_FACESHEET_PATIENT_DETAILS_TAB.ADD_INSURANCE[1]);
    cy.shouldBeEnabled(OR_FACESHEET_PATIENT_DETAILS_TAB.ADD_GUARANTORS[1]);
    cy.cClick(
      selectorFactory.getLabelText('Insurance Coverage'),
      selectorFactory.getLabelText('Insurance Coverage')
    );
  }

  /**
   * @details - verify patient name in Patient details tab
   * @param PatientDetails -Using patient details model to verify address details
   * @API -API's are not available
   * @author Arpitha
   */
  verifyPatientAddressInPatientDetailsTab(patientDetails: PatientDetails) {
    cy.cHasValue(
      OR_FACESHEET_PATIENT_DETAILS_TAB.CITY[1],
      '',
      patientDetails.City
    );
    cy.cHasValue(
      CommonUtils.concatenate(
        this.orPatientDetails.ZIP_CODE[1],
        ' ',
        CommonGetLocators.input
      ),
      '',
      patientDetails.ZipCode
    );
    cy.cHasText(
      CommonUtils.concatenate(
        this.orPatientDetails.STATE[1],
        ' ',
        selectorFactory.getSpanText(patientDetails.State!)
      ),
      '',
      patientDetails.State ?? ''
    );
    cy.cHasValue(
      OR_FACESHEET_PATIENT_DETAILS_TAB.COUNTY[1],
      '',
      patientDetails.County
    );
  }
}
