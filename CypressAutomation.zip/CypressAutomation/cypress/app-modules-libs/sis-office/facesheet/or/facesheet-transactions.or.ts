import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../support/common-core-libs/application/or/sis-office-desktop.or';

export const OR_TRANSACTION = {
  TRANSACTION_POPUP: [
    'Popup Titlebar',
    CommonUtils.concatenate(
      'div',
      CoreCssClasses.ClassPrefix.loc_ui,
      '- dialog - titlebar'
    ),
  ],
  CHARGES: {
    CLAIM_STATUS: ['Claim Status', '#claimHistoryBtn'],
    NOTES: ['Notes', '.button-area #notesBtn'],
    CPT_HCPCS: ['CPT/HCPCS', ''],
    PHYSICIAN: ['Physician'],
    INFO_ICON: ['Auto Action', ''],
    SENT_TO_WAYSTAR_ICON: [
      'Sent To Waystar',
      CommonUtils.concatenate('i', CoreCssClasses.Button.loc_fa_circle_o),
    ],
    BILLED_CHECK_BOX: ['Bill Checkbox', '.p-checkbox-checked'],
    BILLED_CHECK_BOX_CHECKED: ['checked'],
    PAYMENTS: [
      'Payments',
      CommonUtils.concatenate(CoreCssClasses.ClassPrefix.loc_fa_fa, '-money'),
    ],
    WRITE_OFFS: [
      'Write-Offs',
      CommonUtils.concatenate(CoreCssClasses.ClassPrefix.loc_fa_fa, '-pencil'),
    ],
    DEBITS: [
      'Debits',
      CommonUtils.concatenate(CoreCssClasses.ClassPrefix.loc_fa_fa, '-dollar'),
    ],
    TRANSFERS: [
      'Transfers',
      CommonUtils.concatenate(CoreCssClasses.ClassPrefix.loc_fa_fa, '-tran'),
    ],
    ALLOCATION: ['Allocation'],
    WARNING_TEXT: ['Warning Text', '*[class^="warning-text"]'],

    PLUS_ICON: ['Plus Icon', CoreCssClasses.Icon.loc_expand_icon()],
    CHARGE_PANEL: [
      'Charge Panel',
      CommonUtils.concatenate('.', CoreCssClasses.Panel.loc_p_panel, '-header'),
    ],
    TRANSACTION_DETAILS: [
      'Transaction Details',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_panel,
        '[id*="pnlTransactionDetails"]'
      ),
    ],
    FACE_SHEET_CASE_DETAILS_BLOCK: [
      'Face Sheet Case Details Block',
      'div[class*=case-details-block]',
    ],
    SYSTEM_BILLED_ICON: ['System Billed Icon', '.fa.fa-info-circle'],
    TRANSACTIONS: [
      'Transactions',
      CommonUtils.concatenate(
        '[id^=pnlTransactionDetails] ',
        CoreCssClasses.Panel.loc_p_panel_content
      ),
    ],
    TRANSACTION_LINE: ['Transaction Line', '.transaction-details-data'],
  },

  CHARGES_DEBITS_AND_WRITE_OFF: {
    PERIOD: [
      'Period',
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[1],
    ],
    BATCH: [
      'Batch',
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[1],
    ],
    TRANS_DATE: ['Transaction Date', '#calTransactionDate input'],
    AMOUNT: ['Debit Amount', '#numericInput'],
    DEBIT_TRANS_CODE: [
      'Debit Transaction Code',
      '#debitTransactionCodeDropdown',
    ],
    WRITEOFF_TRANS_CODE: [
      'Write-Off Transaction Code',
      '#writeOffTransactionCodeDropdown',
    ],
    GROUP_CODE: ['Group Code', '#writeOffGroupCodeDropdown'],
    REASON_CODE: ['Reason Code', '#writeOffReasonCodeDropdown'],
    REMARK_CODE: ['Remark Code', '#writeOffRemarkCodeDropdown'],
    DEBIT_CASE_DETAILS: [
      'Debit Case Details',
      '[class*="case-details-header"] div',
    ],
    DEBIT_DIALOGUE_CONTENT: [
      'Debit UI Dialogue Content',
      CommonUtils.concatenate(
        CoreCssClasses.ClassPrefix.loc_ui,
        '-dialog-content'
      ),
    ],
    TRANSFER_TO_NEXT_PARTY: [
      'Transfer to the next party',
      '#sbTransferToTheNextParty',
    ],
  },
  TRANSACTION_DETAILS_DATA: [
    'Transaction Details Data',
    'div.transaction-details-data',
  ],
  TRANSACTION_CONTEXT_MENU: ['Context Menu', `[id^='transactionsContextMenu']`],
  CHARGE_COLUMNS: ['Charge Columns', '.cursorHoverMoveIcon > div'],
  BALANCE_DUE_LEDGER: ['Balance Due', '.balance-due-col'],
  CHARGE_ROWS: ['Charge Rows', 'body p-header'],
  NO_CHARGES_TEXT: [
    'No Charges are found.',
    CommonUtils.concatenate(
      'p-header div[class*=',
      CoreCssClasses.Panel.loc_p_panel,
      '-title]'
    ),
  ],

  CHARGES_PAYMENTS: {
    TRANSACTION_DATE: ['Transaction Date', '#transactionDate input'],
    RECEIVED_FROM: ['Received From', '#paymentReceivedFrom'],
    PAYMENT_PANEL: ['', `#paymentsScrollpanel sis-payment`],
    TRANSACTION_TYPE: [
      'TransactionType',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        `[id *= 'TranType']`
      ),
    ],
    AMOUNT: [
      'Amount',
      CommonUtils.concatenate(
        CoreCssClasses.Toggle.loc_p_toggleable_content,
        " sis-numeric-input[id*='Amount'] #numericInput"
      ),
    ],
    TRANSACTION_CODE: [
      'TransactionCode',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        `[id*='TranCode']`
      ),
    ],
    GROUP_CODE: [
      'GroupCode',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        `[id*='GroupCode']`
      ),
    ],
    REASON_CODE: [
      'ReasonCode',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        `[id*='ReasonType']`
      ),
    ],
    REMARK_CODE: [
      'RemarkCode',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        `[id*='RemarkType']`
      ),
    ],
    TRANSFER_TO: [
      'TransferTo',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        `[id*='TranTo']`
      ),
    ],
    DONE: ['Done', '#btnPaymentsDone'],
    TOTALS_BOTTOM_BAR: [
      'Totals bottom bar',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_footer,
        ` div[class*='totals-bottom-bar']`
      ),
    ],
    PAYMENT_SECTION: ['Payments Section', '.payment-container'],
    PAYMENT_CPT_HEADER: [
      'Payments CPT Header',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_header,
        ` div div[class*=colH]`
      ),
    ],
    TRANSACTION_TYPE_DROPDOWN_ITEMS: [
      'Dropdown Items',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown_item_tag,
        ' li'
      ),
    ],
    TRASH_ICON: ['Trash ICon', '#icon10trash'],
  },
  CHARGES_TRANSFER: {
    NEXT_RESPONSIBLE_PARTY: [
      'Next Responsible Party',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        '#nextRespParty'
      ),
    ],
    TRANSFER_TRANSACTION_CODE: [
      'Transfer Transaction Code',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_sis_single_select_dropdown,
        '#transactionCode'
      ),
    ],
  },
  CPTCDT_CODE: [
    'CPT CDT code',
    CoreCssClasses.Dialog.loc_dialog_footer,
    ' sis-cpt-copy-right',
  ],
  VIEW_EDIT: [
    'view edit option',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_p_dropdown_list,
      '> :nth-child(1)',
      '>',
      CoreCssClasses.DropDown.loc_p_dropdown_link,
      '>',
      CoreCssClasses.DropDown.loc_dropdown_list
    ),
  ],

  CLAIM_STATUS: {
    CHARGE_ROWS: [
      'Claim Status Charge Rows',
      '#claim-status-history-table tbody > tr',
    ],
    INFO_ICON: [
      'i Icon',
      CommonUtils.concatenate('i', CoreCssClasses.Button.loc_fa_info_circle),
    ],
  },

  DELETE_POPUP: {
    YES_BUTTON: ['Yes', '#btnConfirmYes'],
  },
  ALLOCATION_CORRECTION_POP_UP: {
    MODEL_HEADER: [
      'Allocation Correction',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_component,
        ' > ',
        CoreCssClasses.Dialog.loc_dialog_header
      ),
    ],
    PERIOD: ['Period', '#periodDropdown'],
    BATCH: ['Batch', '#batchDropdown'],
    SECOND_ROW: [
      'Transaction Date, Transaction Code, Allocation Amount, Received From',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_component,
        ' .col-md-3.text-default'
      ),
    ],
    NEW_ALLOCATION_AMOUNT: ['New Allocation Amount', '#numericInput'],
    NEW_BALANCE: ['New Balance', '.col-md-2.newbalance'],
    NOTES: ['Notes', '#correction_notes'],
    DONE: ['Done', '[role=dialog] .button-prime.p-button.p-component'],
    CHARGES_TABLE: [
      'charge table',
      '[id^=pnlTransactionDetails] .transaction-details-header',
    ],
    CORRECTION_CODE: ['Correction Code', '#correctionTransactionCodeDropdown'],
  },
  WAY_STAR_ICON: ['Way star icon'],
  VIEW_DELETE_CORRECTION: [
    'View/Edit Delete Correction',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_p_dropdown_list,
      ' ',
      CommonGetLocators.li,
      ' '
    ),
  ],
  CHARGE_CORRECTION_POPUP_HEADER_TEXT: ['Charge Correction'],
  UNASSIGNED_PAYMENT: {
    PERIOD_IS_CLOSED_WARNING_MESSAGE: [
      'Period is closed.',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        ' ',
        CoreCssClasses.Text.loc_period_is_closed
      ),
    ],
    BATCH_IS_CLOSED_WARNING_MESSAGE: [
      'Batch is closed.',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        ' ',
        CoreCssClasses.Text.loc_batch_is_batch
      ),
    ],
  },
};
