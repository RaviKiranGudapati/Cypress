import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_FACESHEET_PATIENT_DETAILS_TAB = {
  PATIENT_DETAILS_TAB: ['Patient details tab', '#PatientDetails'],
  SEX: ['Sex', '[data-test-id="sBtnGender"]'],
  PREFERREDNAME: ['Preferred Name', '[data-test-id="txtAlias"]'],
  GENDER: ['Gender Identity', '[data-test-id="genderIdentityDropdown"] span'],
  EDIT_FIRST_NAME: ['Edit Patient First Name', '#txtFirstName'],
  FIRST_NAME_LABEL: [
    'Patient First Name',
    selectorFactory.getLabelText('Patient First Name'),
  ],
  CASES_TAB: ['Cases Tab', 'a#Cases'],
  FINANCIAL_CLEARANCE: ['Financial Clearance', '#selfpay-verification'],
  PATIENT_TITLE: ['Patient Title', '#notesBtn'],
  PATIENT_LOCK_MESSAGE_FACESHEET: [
    'lockmessage',
    CommonUtils.concatenate(
      '.title  > ',
      CoreCssClasses.Label.loc_custom_tooltip,
      ' > ',
      CoreCssClasses.Text.loc_limittext_holder,
      ' > ',
      CoreCssClasses.Text.loc_limittext_container
    ),
  ],
  RACE: ['Race', '#raceDropdown span'],
  ETHNICITY: ['Ethnicity', '#ethnicityDropdown span'],
  LANGUAGE: ['Language', '#languageDropdown span'],
  ADD_INSURANCE: ['Add Insurance', '#btnAddInsuranceCoverage'],
  INSURANCE_CARRIER_DROPDOWN_VALUE: [
    'Insurance Carrier Value',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_p_dropdown_items,
      ' div ',
      CoreCssClasses.Text.loc_limittext_holder
    ),
  ],
  ADD_GUARANTORS: ['Add', '[data-test-id="btnAddGuarantors"]'],
  LAST_NAME: ['Last Name', '#txtLastName'],
  CITY: ['City', '#txtCity'],
  COUNTY: ['County', '#txtCounty'],
};
