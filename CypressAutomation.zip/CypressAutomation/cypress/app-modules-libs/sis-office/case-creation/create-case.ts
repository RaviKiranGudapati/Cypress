import {
  Application,
  CommonClassAttributes,
  CommonGetLocators,
  FilterMethods,
  InvokeAttributes,
  TriggerAttributes,
  InvokeMethods,
  ShouldMethods,
  YesOrNo,
  CommonTypeValues,
} from '../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { AppColors } from '../../../support/common-core-libs/application/constants/app-colors.constants';
import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import { ILocatorValue } from '../../../test-data-models/core/locator.model';
import { AmountDue } from '../../../test-data-models/sis-office/trackers/fin-clearance.model';
import {
  AdditionalClaimInformation,
  BillingDetails,
  CaseDetails,
  Cpt,
  Guarantor,
  InsuranceCoverage,
  PatientCase,
  PatientDetails,
  PreferenceCard,
} from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_PATIENT_CASE_CREATION } from './or/create-case.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { HelperText } from '../../shared/application-settings/enums/enterprise-configuration.enum';
import {
  newPatientLabelValues,
  insurancePopupLabels,
  caseDetailsLabels,
} from './constants/create-case.const';
import {
  CreateCaseOptions,
  PrimaryGuarantorCheckIn,
} from './enums/create-case.enum';

import { CaseCreationApis } from './api/case-creation.api';

/* const values */
const create = 'CREATE';
const numForty = '40';
const numOne = '1';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const orInsuranceCoverage =
  OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
    .INSURANCE_COVERAGE;

/**
 * Class for Create Case
 */
export default class CreateCase {
  /* instance variables */
  private createCaseApis = new CaseCreationApis();

  // Object Repositories For Case Creation with New Patient
  private orCreateCase = OR_PATIENT_CASE_CREATION.CREATE_A_CASE;
  private orPatientDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS;
  private orCaseDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS;
  private orBillingDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS;
  private orNewPatient =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CREATE_NEW_PATIENT;

  private orAdditionalClaimInfo =
    this.orBillingDetails.ADDITIONAL_CLAIM_INFORMATION;
  private orSisOffice = OR_SIS_OFFICE_DESKTOP.SIS_OFFICE;

  // Object Repositories For CheckIn a created patient
  private orPatientCheckIn = OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN;
  private orPayment = this.orPatientCheckIn.PAYMENT;

  /**
   * @details - Self Initialization For NewPatientInfo, cptData
   * @details - Page Initialization For commonLayoutPage
   * @param patientInfo
   */
  constructor(private patientCaseInfo?: PatientCase) {}

  get patientCaseModel(): PatientCase | undefined {
    return this.patientCaseInfo;
  }

  /**
   * @details - Creating a New patient, if already exists, you can use existing or create with same data
   * @param  patientDetails - object which has all required data for creating new patient
   * @API - API's are available - Implemented Completely
   */

  createNewPatient(patientDetails: PatientDetails) {
    const interceptCollection =
      this.createCaseApis.interceptClickOnDoneButtonApis();
    cy.cClick(
      this.orCreateCase.NEW_PATIENT_BUTTON[1],
      this.orCreateCase.NEW_PATIENT_BUTTON[0]
    );

    patientDetails.PatientFirstName &&
      cy.cType(
        this.orNewPatient.PATIENT_FIRST_NAME[1],
        this.orNewPatient.PATIENT_FIRST_NAME[0],
        patientDetails.PatientFirstName
      );

    patientDetails.LastName &&
      cy.cType(
        this.orNewPatient.LAST_NAME[1],
        this.orNewPatient.LAST_NAME[0],
        patientDetails.LastName
      );

    patientDetails.DOB &&
      cy.cType(
        this.orNewPatient.DOB[1],
        this.orNewPatient.DOB[0],
        patientDetails.DOB
      );

    patientDetails.MiddleInitial &&
      cy.cType(
        this.orNewPatient.MIDDLE_INITIAL[1],
        this.orNewPatient.MIDDLE_INITIAL[0],
        patientDetails.MiddleInitial
      );

    patientDetails.Suffix &&
      cy.cType(
        this.orNewPatient.SUFFIX[1],
        this.orNewPatient.SUFFIX[0],
        patientDetails.Suffix
      );

    cy.cClickAndWaitApis(this.orNewPatient.DONE_BUTTON[1], interceptCollection);

    let PatientFound = this.orNewPatient.PATIENT_MATCH_FOUND[1];
    cy.cGet(CommonGetLocators.body).then(($body) => {
      if ($body.find(PatientFound).length > 0) {
        if (
          patientDetails.UseSelectedOrCreateNew ||
          patientDetails.UseSelectedOrCreateNew === 'USE'
        ) {
          cy.cClick(
            this.orNewPatient.SELECT_PATIENT_CHECKBOX[1],
            this.orNewPatient.SELECT_PATIENT_CHECKBOX[0]
          );
          cy.cClick(
            this.orNewPatient.USE_SELECTED_BUTTON[1],
            this.orNewPatient.USE_SELECTED_BUTTON[0]
          );
        } else if (patientDetails.UseSelectedOrCreateNew === create) {
          cy.cClick(
            this.orNewPatient.CREATE_NEW_PATIENT_BTN[1],
            this.orNewPatient.CREATE_NEW_PATIENT_BTN[0]
          );
        }
      }
    });
  }

  /**
   * @details - Searching for patient, if not exists, you can create a New Patient
   * @param  patientDetails - object which has all required data for creating new patient
   * @API - API's are available -  Implemented Completely
   */
  searchAndSelectOrCreatePatient(patientDetails: PatientDetails) {
    const interceptCollection =
      this.createCaseApis.interceptSelectPatientInPatientSearchResult();
    this.clickCreateACaseTab();
    const SearchText = CommonUtils.getStringByLen(
      patientDetails.PatientFirstName!
    );
    cy.cType(
      this.orCreateCase.SEARCH_PATIENT_INPUT[1],
      this.orCreateCase.SEARCH_PATIENT_INPUT[0],
      SearchText
    );
    /**
     * @Issue: Sometimes the API is completing before the search completes which is causing the api fail
     * @Resolution: we have added the should be enabled method for the search result
     */
    const patientName = `${patientDetails.LastName}, ${patientDetails.PatientFirstName}`;
    cy.cGet(this.orCreateCase.SEARCH_PATIENT_RESULT[1]).each(($element) => {
      cy.shouldBeEnabled(selectorFactory.getDivText(patientName));
      if ($element.text().indexOf(patientName) > -1) {
        cy.cIntercept(interceptCollection);
        cy.wrap($element)
          .first()
          .within(() => {
            $element
              .find(selectorFactory.getDivText(patientName))
              .get(0)
              .click();
            cy.cWaitApis(interceptCollection);
          });
        return false;
      }
    });
    cy.cGet(OR_PATIENT_CASE_CREATION.L_CREATE_CASE[1]).then(($body) => {
      if (
        $body
          .find(this.orCreateCase.NEW_PATIENT_BUTTON[1])
          .is(FilterMethods.visible)
      ) {
        this.clickCreateACaseTab();
        this.createNewPatient(patientDetails);
      }
    });
  }

  /**
   * @details - Selecting Gender in Patient details tab
   * @param gender - male/female
   * @API - API's are not available
   */
  selectGender(gender: string) {
    let selector = selectorFactory.getSpanText(gender);
    let logicalName = this.orPatientDetails.GENDER[0];
    cy.cClick(selector, logicalName);
  }

  /**
   * @details - enter DOB date in Patient Details tab
   * @param date - dob
   * @API - API's are not available
   */
  enterDOB(date: string) {
    const selector = this.orPatientDetails.DOB[1];
    const logicalName = this.orPatientDetails.DOB[0];
    cy.cType(selector, logicalName, date).blur();
  }

  /**
   * @details - click Previous Button available in My tasks Footer
   * @API - API's are available - Implement for individual tabs
   */
  previous() {
    cy.cClick(
      this.orCreateCase.MY_TASKS.FOOTER_BUTTONS.PREVIOUS_BUTTON[1],
      this.orCreateCase.MY_TASKS.FOOTER_BUTTONS.PREVIOUS_BUTTON[0]
    );
  }

  /**
   * @details - click Next Button available in My tasks Footer
   * @API -API's are available - Implement for individual tabs
   */
  next() {
    cy.cClick(
      this.orCreateCase.MY_TASKS.FOOTER_BUTTONS.NEXT_BUTTON[1],
      this.orCreateCase.MY_TASKS.FOOTER_BUTTONS.NEXT_BUTTON[0]
    );
  }

  /**
   * @details - click Done Button available in My tasks Footer
   * @API - API's are available - Implemented Completely
   */
  clickDoneFooterButton() {
    const interceptCollection =
      this.createCaseApis.interceptDoneButtonInMyTaskFooter();
    cy.cClickAndWaitApis(
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS.DONE_BUTTON[1],
      interceptCollection,
      false,
      false,
      {force: true}  // Added force true due to element is not clicking sometimes done button is not clicking
    );
  }

  /**
   * @details - click New Patient Button available in My tasks
   * @API - API's are not available
   */
  clickNewPatientButton() {
    cy.cClick(
      this.orCreateCase.NEW_PATIENT_BUTTON[1],
      this.orCreateCase.NEW_PATIENT_BUTTON[0]
    );
  }

  /**
   * @details - click New Patient Done Button available in My tasks
   * @API - API's are available - Implemented Completely
   */
  clickDoneButton() {
    cy.cClick(
      this.orNewPatient.DONE_BUTTON[1],
      this.orNewPatient.DONE_BUTTON[0]
    );
  }

  /**
   * @details - click Done Button available in Check In Footer
   * @API - API's are available - Implemented Completely
   */
  clickCheckInDone() {
    const interceptCollection =
      this.createCaseApis.interceptForDoneButtonCheckIn();
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClickAndWaitApis(
      this.orCreateCase.CHECK_IN.FOOTER_BUTTONS.DONE_BUTTON[1],
      interceptCollection
    );
  }

  /**
   * @details - click New Patient Button available in Patient Details for Case Requests
   * @API - API's are not available
   */
  clickNewPatientButtonForCaseRequest() {
    cy.cClick(
      this.orCreateCase.MY_TASKS.CASE_REQUEST_NEW_PATIENT[1],
      this.orCreateCase.MY_TASKS.CASE_REQUEST_NEW_PATIENT[0]
    );
  }

  /**
   * @details - select insurance patient details tab
   * @param insuranceCoverage
   * @API - API's are available - Implemented Completely
   */
  addInsuranceCoverage(insuranceCoverage: InsuranceCoverage) {
    this.clickInsuranceAddButton();
    this.selectInsuranceCarrier(insuranceCoverage);
    cy.cSelectDropdown(
      orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[1],
      orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[0],
      insuranceCoverage.RelationshipToSubscriber
    );
    if (insuranceCoverage.RelationshipToSubscriber === CreateCaseOptions.Self) {
      this.enterSubscriberID(insuranceCoverage);
    } else {
      insuranceCoverage.FirstName &&
        cy.cType(
          this.orPatientDetails.INSURANCE_COVERAGE.FIRST_NAME[1],
          this.orPatientDetails.INSURANCE_COVERAGE.FIRST_NAME[0],
          insuranceCoverage.FirstName
        );
      insuranceCoverage.LastName &&
        cy.cType(
          this.orPatientDetails.INSURANCE_COVERAGE.LAST_NAME[1],
          this.orPatientDetails.INSURANCE_COVERAGE.LAST_NAME[0],
          insuranceCoverage.LastName
        );
      insuranceCoverage.GroupName &&
        cy.cType(
          orInsuranceCoverage.GROUP_NAME[1],
          orInsuranceCoverage.GROUP_NAME[0],
          insuranceCoverage.GroupName
        );
      insuranceCoverage.GroupNumber &&
        cy.cType(
          orInsuranceCoverage.GROUP_NUMBER[1],
          orInsuranceCoverage.GROUP_NUMBER[0],
          insuranceCoverage.GroupNumber
        );
      insuranceCoverage.EffectiveFrom &&
        cy.cType(
          orInsuranceCoverage.EFFECTIVE_FROM[1],
          orInsuranceCoverage.EFFECTIVE_FROM[0],
          insuranceCoverage.EffectiveFrom
        );
      insuranceCoverage.EffectiveTo &&
        cy.cType(
          orInsuranceCoverage.EFFECTIVE_TO[1],
          orInsuranceCoverage.EFFECTIVE_TO[0],
          insuranceCoverage.EffectiveTo
        );
      this.enterSubscriberID(insuranceCoverage);
    }
    this.clickDoneInInsuranceCoverage();
  }

  /**
   * @details - edit existing Insurance in patient details tab
   * @param insuranceCoverage
   * @API - API's are available - Implemented Completely
   */
  editInsuranceCoverage(insuranceCoverage: InsuranceCoverage) {
    const interceptCollection =
      this.createCaseApis.interceptEditInsuranceDone();
    const insuranceCoverageCollection =
      returnInsuranceLocatorValues(insuranceCoverage);
    insuranceCoverageCollection.forEach((obj: ILocatorValue) => {
      obj.value && cy.cType(obj.locator, '', obj.value);
    });
    cy.cClickAndWaitApis(
      orInsuranceCoverage.DONE_BUTTON[1],
      interceptCollection,
      false,
      true
    );
  }

  /**
   * @details - verify existing Insurance in patient details tab
   * @param insuranceCoverage passed to verify existing Insurance
   * @API - API's are not available
   * @author Bindhu
   */
  verifyInsuranceCoverage(insuranceCoverage: InsuranceCoverage) {
    cy.cGet(orInsuranceCoverage.INSURANCE_POPUP[1])
      .first()
      .within(() => {
        // moved all locator objects to separate function, as it has many locator values and it is also re-used.
        const insuranceCoverageCollection =
          returnInsuranceLocatorValues(insuranceCoverage);

        insuranceCoverageCollection.forEach((obj: ILocatorValue) => {
          obj.value && cy.cHasValue(obj.locator, '', obj.value);
        });
      });
  }

  /**
   * @details - Method to hover on Insurance and verify Trash Icon visibility
   * @param - insuranceName - to pass particular insurance name
   * @API - API's are not available
   */
  verifyInsuranceTrashIcon(insuranceName: string) {
    cy.cGet(orInsuranceCoverage.INSURANCE_COVERAGE_ACTIVE_ROW[1]).each(
      ($element) => {
        if ($element.text().indexOf(insuranceName) > -1) {
          cy.wrap($element)
            .first()
            .within(() => {
              cy.cGet(this.orSisOffice.TRASH_ICON[1])
                .invoke(
                  InvokeMethods.css,
                  InvokeAttributes.visibility,
                  CommonClassAttributes.visible
                )
                .invoke(InvokeMethods.show)
                .should(ShouldMethods.visible);
            });
          return false;
        }
      }
    );
  }

  /**
   * @details - Method to delete the insurance
   * @param - index - to pass index to delete the insurance
   * @API - API's are available - Implemented Completely
   */
  deleteInsurance(index: number) {
    const interceptCollection =
      this.createCaseApis.interceptDeleteInsuranceApis();
    cy.cGet(this.orSisOffice.TRASH_ICON[1])
      .eq(index)
      .invoke(
        InvokeMethods.css,
        InvokeAttributes.visibility,
        CommonClassAttributes.visible
      )
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible)
      .click();
    cy.cClickAndWaitApis(
      orInsuranceCoverage.DELETE_POPUP_YES[1],
      interceptCollection,
      false,
      true
    );
  }

  /**
   * @details - select Room in Case Details tab
   * @param room name to select room
   * @API - API's are not available
   */
  selectRoom(room: string) {
    cy.cSelectDropdown(
      this.orCaseDetails.OPERATING_ROOM[1],
      this.orCaseDetails.OPERATING_ROOM[0],
      room
    );
  }

  /**
   * @details - select Gender Identity
   * @param genderIdentity to select gender
   * @API - API's are not available
   */
  selectGenderIdentity(genderIdentity: string) {
    cy.cSelectDropdown(
      this.orPatientDetails.GENDER_IDENTITY[1],
      this.orPatientDetails.GENDER_IDENTITY[0],
      genderIdentity
    );
  }

  /**
   * @details - select Pronouns
   * @param proNouns to select Pronouns
   * @API - API's are not available
   */
  selectPronouns(proNouns: string[]) {
    cy.cClick(
      this.orPatientDetails.PRONOUNS[1],
      this.orPatientDetails.PRONOUNS[0]
    );
    const valueArray: string[] = proNouns;
    valueArray.forEach((val) => {
      cy.cGet(this.orPatientDetails.PRONOUNS_VALUE[1]).contains(val).click({
        force: true,
      });
    });
    cy.cClick(
      this.orPatientDetails.PRONOUNS[1],
      this.orPatientDetails.PRONOUNS[0],
      false,
      false,
      {
        force: true,
      }
    );
  }

  /**
   * @details - select Room in Case Details tab
   * @API - API's are available - Implemented Completely
   */
  clearRoom() {
    const interceptCollection = this.createCaseApis.interceptClearRoom();
    cy.cClickAndWaitApis(
      this.orCaseDetails.CLEAR_OPERATING_ROOM[1],
      interceptCollection
    );
  }

  /**
   * @details - enter DOS date in Case Details tab
   * @param date to select date in calender
   * @API - API's are available - But triggered after moving to next field
   */
  enterDateOfService(date: string) {
    cy.cType(
      this.orCaseDetails.DATE_OF_SERVICE[1],
      this.orCaseDetails.DATE_OF_SERVICE[0],
      date,
      false,
      true
    );
  }

  /**
   * @details - enter Start Time for case tile in Case Details tab
   * @param time to enter Start Time
   * @API - API's are available - But triggered after moving to next field
   * @author Bindhu
   */
  enterStartTime(time: string) {
    cy.cGet(this.orCaseDetails.START_TIME[1]).type(time);
  }

  /**
   * @details - enter End Time for case tile in Case Details tab
   * @param - passing time to enter end time
   * @API - API's are available - But triggered after moving to next field
   * @author Bindhu
   */
  enterEndTime(time: string) {
    cy.cGet(this.orCaseDetails.END_TIME[1]).type(time);
  }

  /**
   * @details - Enter Clean up Time Case Details Tab
   * @param - passing time to enter clean up time
   * @API - API's are available - But triggered after moving to next field
   */
  enterCleanupTime(time: string) {
    cy.cType(
      this.orCaseDetails.CLEANUP_TIME[1],
      this.orCaseDetails.CLEANUP_TIME[0],
      time
    );
  }

  /**
   * @details - select AppointmentType in Case Details tab
   * @param appointmentType - type of appointment
   * @API - API's are not available
   */
  selectAppointmentType(appointmentType: string) {
    cy.cClick(
      this.orCaseDetails.APPOINTMENT_TYPE[1],
      this.orCaseDetails.APPOINTMENT_TYPE[0]
    );
    cy.cClick(selectorFactory.getSpanText(appointmentType), appointmentType);
  }

  /**
   * @details - enter CPT code, Modified description, Physician, Laterality and Pre-Op Diagnosis Code in Case Details tab
   * @param cptData - procedure data
   * @API - API's are available - Implemented Completely
   */
  enterCPTRowData(cptData: Cpt) {
    const interceptCollection = this.createCaseApis.interceptEnterCptCode();
    // Added shouldBeEnabled assertion before the type of the procedure
    cy.shouldBeEnabled(this.orCaseDetails.CPT_CODE_DESCRIPTION[1]);
    cy.cIntercept(interceptCollection);
    cptData.CPTCodeAndDescription &&
      // Checking CPT Code and Description is present for the following block of code
      (cy.cType(
        this.orCaseDetails.CPT_CODE_DESCRIPTION[1],
        this.orCaseDetails.CPT_CODE_DESCRIPTION[0],
        cptData.CPTCodeAndDescription
      ),
      cy.cWaitApis(interceptCollection),
      cy.cIsVisible(
        this.orCaseDetails.CPT_CODE_SELECTION[1],
        this.orCaseDetails.CPT_CODE_SELECTION[1]
      ),
      cy.cSelectListItem(
        this.orCaseDetails.CPT_CODE_SELECTION[1],
        this.orCaseDetails.CPT_CODE_SELECTION[0],
        cptData.CPTCodeAndDescription
      ));
    cptData.ModifiedProcDescription &&
      cy.cType(
        this.orCaseDetails.MODIFIED_PROC_DESCRIPTION[1],
        this.orCaseDetails.MODIFIED_PROC_DESCRIPTION[0],
        cptData.ModifiedProcDescription
      );
    cptData.Physician &&
      cy.cSelectDropdown(
        this.orCaseDetails.PHYSICIAN[1],
        this.orCaseDetails.PHYSICIAN[0],
        cptData.Physician
      );
    cptData.Laterality &&
      cy.cSelectDropdown(
        this.orCaseDetails.LATERALITY[1],
        this.orCaseDetails.LATERALITY[0],
        cptData.Laterality
      );
    cptData.PreOpDiagCode &&
      cy.cType(
        this.orCaseDetails.PRE_OP_DIAGNOSIS_CODE[1],
        this.orCaseDetails.PRE_OP_DIAGNOSIS_CODE[0],
        cptData.PreOpDiagCode
      );
  }

  /**
   * @details - select preference card in case details
   * @param preferenceCardData - object with physician, procedures etc
   * @API - API's are available - Implemented Completely
   */
  selectPreferenceCard(preferenceCardData: PreferenceCard) {
    const interceptCollection =
      this.createCaseApis.interceptAddPreferenceCardApi();
    cy.cClick(
      this.orCaseDetails.ADD_PREFERENCE_CARD.ADD_BUTTON[1],
      this.orCaseDetails.ADD_PREFERENCE_CARD.ADD_BUTTON[0]
    );
    cy.cIntercept(interceptCollection);
    if (CommonUtils.isNotEmptyAndUndefined(preferenceCardData.Physician)) {
      cy.cSelectDropdown(
        this.orCaseDetails.ADD_PREFERENCE_CARD.PHYSICIAN[1],
        this.orCaseDetails.ADD_PREFERENCE_CARD.PHYSICIAN[0],
        preferenceCardData.Physician
      );
    }

    preferenceCardData.AvailablePreferenceCards.forEach((preferenceCard) => {
      cy.cSelectListItem(
        this.orCaseDetails.ADD_PREFERENCE_CARD
          .PREFERENCE_CARD_LIST_ITEM_SELECTION[1],
        this.orCaseDetails.ADD_PREFERENCE_CARD
          .PREFERENCE_CARD_LIST_ITEM_SELECTION[0],
        preferenceCard
      );
      cy.cIsVisible(
        selectorFactory.selectedPrefCard(preferenceCard),
        this.orCaseDetails.ADD_PREFERENCE_CARD.SELECTED_PREFERENCE_CARD[0],
        false
      );
    });
    preferenceCardData.Procedures &&
      preferenceCardData.Procedures.forEach((element) => {
        cy.cSelectListItem(
          this.orCaseDetails.ADD_PREFERENCE_CARD
            .PROCEDURE_LIST_ITEM_SELECTION[1],
          this.orCaseDetails.ADD_PREFERENCE_CARD
            .PROCEDURE_LIST_ITEM_SELECTION[0],
          element
        );
        cy.cIsVisible(
          CommonUtils.concatenate(
            selectorFactory.getSpanText(element),
            ' ~ ',
            this.orCaseDetails.ADD_PREFERENCE_CARD.CHECK_MARK[1]
          ),
          this.orCaseDetails.ADD_PREFERENCE_CARD.CHECK_MARK[0]
        );
      });
    this.clickDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select primary insurance option
   * @param primaryInsurance
   * @API - API's are not available
   */
  enterPrimaryInsurance(primaryInsurance: string) {
    cy.shouldBeEnabled(this.orBillingDetails.PRIMARY_INSURANCE[1]);
    cy.cSelectDropdown(
      this.orBillingDetails.PRIMARY_INSURANCE[1],
      this.orBillingDetails.PRIMARY_INSURANCE[0],
      primaryInsurance
    );
  }

  /**
   * @details - select secondary insurance option
   * @param secondaryInsurance
   * @API - API's are not available
   */
  enterSecondaryInsurance(secondaryInsurance: string) {
    cy.shouldBeEnabled(this.orBillingDetails.SECONDARY_INSURANCE[1]);
    cy.cSelectDropdown(
      this.orBillingDetails.SECONDARY_INSURANCE[1],
      this.orBillingDetails.SECONDARY_INSURANCE[0],
      secondaryInsurance
    );
  }

  /**
   * @details - select yes or no option
   * @param option
   * @API - API's are available - Implemented Completely
   */
  selectYesOrNoButton(option: string) {
    const interceptCollection: ApiEndpoint[] =
      option == YesOrNo.yes
        ? this.createCaseApis.interceptSecondaryGuarantorYes()
        : this.createCaseApis.interceptSecondaryGuarantorNo();
    cy.cClickAndWaitApis(
      selectorFactory.selectSecondGuarantor(option),
      interceptCollection
    );
  }

  /**
   * @details - select Tertiary insurance option
   * @param tertiaryInsurance
   * @API - API's are not available
   */
  enterTertiaryInsurance(tertiaryInsurance: string) {
    cy.shouldBeEnabled(this.orBillingDetails.TERTIARY_INSURANCE[1]);
    cy.cSelectDropdown(
      this.orBillingDetails.TERTIARY_INSURANCE[1],
      this.orBillingDetails.TERTIARY_INSURANCE[0],
      tertiaryInsurance
    );
  }

  /**
   * @details - select worker compensation option
   * @param workerCompensationOption
   * @API - API's are not available
   */
  selectWorkerCompensation(workerCompensationOption: string) {
    cy.cClick(
      selectorFactory.selectWorkerCompensation(workerCompensationOption),
      this.orBillingDetails.WORKER_COMPENSATION[0]
    );
  }

  /**
   * @details - select additional claim information
   * @param additionalClaimInformation
   * @API - API's are not available
   */
  selectAdditionalClaimInformation(
    additionalClaimInformation: AdditionalClaimInformation
  ) {
    additionalClaimInformation.PatientConditionDueTo &&
      cy.cSelectDropdown(
        this.orAdditionalClaimInfo.PATIENT_CONDITION_DUE_TO[1],
        this.orAdditionalClaimInfo.PATIENT_CONDITION_DUE_TO[0],
        additionalClaimInformation.PatientConditionDueTo!
      );

    additionalClaimInformation.AccidentDate &&
      cy.cType(
        this.orAdditionalClaimInfo.ACCIDENT_DATE[1],
        this.orAdditionalClaimInfo.ACCIDENT_DATE[0],
        additionalClaimInformation.AccidentDate
      );

    additionalClaimInformation.AccidentState &&
      cy.cSelectDropdown(
        this.orAdditionalClaimInfo.ACCIDENT_STATE[1],
        this.orAdditionalClaimInfo.ACCIDENT_STATE[0],
        additionalClaimInformation.AccidentState!
      );
  }

  /**
   * @details - select primary guarantor option
   * @param primaryGuarantorOption,
   * @param area - primary guarantor
   * @API - API's are available - Implemented Completely
   */
  selectPrimaryGuarantor(
    primaryGuarantorOption: string | Guarantor,
    area: string
  ) {
    let loc = '';
    if (area == this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR[0])
      loc = this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR[1];
    else if (area == PrimaryGuarantorCheckIn.PrimaryGuarantor)
      loc = this.orPatientCheckIn.PRIMARY_GUARANTOR[1];
    this.selectGuarantorOption(primaryGuarantorOption, loc, area);
  }

  /**
   * @details - select secondary guarantor option
   * @param secondaryGuarantorOptionButton
   * @param secondaryGuarantorOption
   * @API - API's are available - Implemented Completely
   */
  selectSecondaryGuarantor(
    secondaryGuarantorOption: string | Guarantor,
    secondaryGuarantorOptionButton: YesOrNo
  ) {
    this.selectYesOrNoButton(secondaryGuarantorOptionButton);
    if (
      secondaryGuarantorOptionButton &&
      secondaryGuarantorOptionButton === YesOrNo.yes
    ) {
      this.selectGuarantorOption(
        secondaryGuarantorOption,
        this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR[1],
        this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR[0]
      );
    }
  }

  /**
   * @details - select guarantor dropdown option
   * @param guarantorOption
   * @param selector
   * @param selectorLogicalName
   * @API - API's are available - Implemented Completely
   */
  selectGuarantorOption(
    guarantorOption: string | Guarantor,
    selector: string,
    selectorLogicalName: string
  ) {
    const interceptCollection = this.createCaseApis.interceptSelectGuarantor();
    let primaryGuarantorSelectionOption: string;

    if (typeof guarantorOption === CreateCaseOptions.String) {
      primaryGuarantorSelectionOption = guarantorOption as string;
    } else {
      primaryGuarantorSelectionOption = CreateCaseOptions.AddNewGuarantor;
    }
    cy.cIntercept(interceptCollection);
    cy.cSelectDropdown(
      selector,
      selectorLogicalName,
      primaryGuarantorSelectionOption
    );
    cy.cWaitApis(interceptCollection);

    if (typeof guarantorOption != CreateCaseOptions.String) {
      this.selectAddGuarantor(guarantorOption as Guarantor);
    }
  }

  /**
   * @details - select add new guarantor option
   * @param addGuarantor
   * @API - API's are available - Implemented Completely
   */
  selectAddGuarantor(addGuarantor: Guarantor) {
    const interceptCollection =
      this.createCaseApis.interceptGuarantorPopUpDoneButtonApis();
    for (const [key, value] of Object.entries(addGuarantor)) {
      if (CommonUtils.isNotEmptyAndUndefined(value)) {
        switch (key) {
          case CreateCaseOptions.FirstName:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.FIRST_NAME[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.FIRST_NAME[0],
              addGuarantor.FirstName
            );
            break;

          case CreateCaseOptions.LastName:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.LAST_NAME[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.LAST_NAME[0],
              addGuarantor.LastName
            );
            break;

          case CreateCaseOptions.DOB:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.DOB[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.DOB[0],
              addGuarantor.DOB
            );
            break;

          case CreateCaseOptions.Gender:
            let genderLocator =
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.GENDER[1] +
              ' ' +
              selectorFactory.getSpanText(addGuarantor.Gender!);
            cy.cClick(genderLocator, addGuarantor.Gender!);
            break;

          case CreateCaseOptions.RelationshipToPatient:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR
                .RELATIONSHIP_TO_PATIENT[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR
                .RELATIONSHIP_TO_PATIENT[0],
              addGuarantor.RelationshipToPatient!
            );
            break;

          case CreateCaseOptions.PrimaryPhone:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.PRIMARY_PHONE[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.PRIMARY_PHONE[0],
              addGuarantor.PrimaryPhone!
            );
            break;

          case CreateCaseOptions.Address1:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ADDRESS1[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ADDRESS1[0],
              addGuarantor.Address1!
            );
            break;

          case CreateCaseOptions.Address2:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ADDRESS2[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ADDRESS2[0],
              addGuarantor.Address2!
            );
            break;

          case CreateCaseOptions.City:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.CITY[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.CITY[0],
              addGuarantor.City!
            );
            break;

          case CreateCaseOptions.State:
            cy.cSelectDropdown(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.STATE_DROPDOWN[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.STATE_DROPDOWN[0],
              addGuarantor.State!
            );
            break;

          case CreateCaseOptions.Country:
            cy.cSelectDropdown(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR
                .COUNTRY_DROPDOWN[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR
                .COUNTRY_DROPDOWN[0],
              addGuarantor.Country!
            );
            break;

          case CreateCaseOptions.ZipCode:
            this.enterInputText(
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ZIP_CODE[1],
              this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ZIP_CODE[0],
              addGuarantor.ZipCode!
            );
            break;
          default:
            break;
        }
      }
    }
    cy.cClickAndWaitApis(
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.DONE_BUTTON[1],
      interceptCollection
    );
  }

  /**
   * 0@details - enter input text for new guarantor
   * @param selector
   * @param selectorLogicalName
   * @param optionValue
   * @API - API's are not available
   */
  enterInputText(
    selector: string,
    selectorLogicalName: string,
    optionValue: string
  ) {
    cy.cType(selector, selectorLogicalName, optionValue);
  }

  /**
   * @details - To enter addAddress1 in Patient details
   * @param addressValue To enter addAddress1
   * @API - API's are not available
   */
  addAddress1(addressValue: string) {
    cy.cType(
      this.orPatientDetails.ADDRESS1[1],
      this.orPatientDetails.ADDRESS1[0],
      addressValue
    );
  }

  /**
   * @details - To enter zip Code in Patient details
   * @param zipCodeValue
   * @API - API's are not available
   */
  addZipCode(zipCodeValue: string) {
    cy.cGet(this.orPatientDetails.ZIP_CODE[1]).type(zipCodeValue);
  }

  /**
   * @details - Enter Address fields in Patient Details
   * @param - patientDetails - to pass Patient Details model
   * @API - API's are not available
   * @author Bindhu
   */
  enterPatientDetailsAddressFields(patientDetails: PatientDetails) {
    patientDetails.Address1 &&
      cy.cType(
        this.orPatientDetails.ADDRESS1[1],
        this.orPatientDetails.ADDRESS1[0],
        patientDetails.Address1
      );
    patientDetails.Address2 &&
      cy.cType(
        this.orPatientDetails.ADDRESS2[1],
        this.orPatientDetails.ADDRESS2[0],
        patientDetails.Address2
      );
    patientDetails.City &&
      cy.cType(
        this.orPatientDetails.CITY[1],
        this.orPatientDetails.CITY[0],
        patientDetails.City
      );
    patientDetails.ZipCode &&
      cy.cType(
        this.orPatientDetails.ZIP_CODE[1],
        this.orPatientDetails.ZIP_CODE[0],
        patientDetails.ZipCode
      );
    patientDetails.State &&
      cy.cSelectDropdown(
        this.orPatientDetails.STATE[1],
        this.orPatientDetails.STATE[0],
        patientDetails.State
      );
  }

  /**
   * @details - To enter Patient Details in create new patient
   * @param patientInfo -to enter details create new patient
   * @API - API's are available - Implemented Completely
   */
  enterPatientDetails(patientInfo: PatientDetails) {
    this.selectGender(patientInfo.Gender!);
    this.enterDOB(patientInfo.DOB!);
    if (
      patientInfo.InsuranceCoverage &&
      typeof patientInfo.InsuranceCoverage != 'string'
    ) {
      patientInfo.InsuranceCoverage.forEach((insuranceCoverage) => {
        this.addInsuranceCoverage(insuranceCoverage);
      });
    }

    this.clickNextInPatientDetails();
  }

  /**
   * @details - to enter all details in Case Details
   * @param caseDetailsInfo - passed to enter all details in Case Details
   * @API - API's are available - Implemented Completely
   */
  enterCaseDetails(caseDetailsInfo: CaseDetails) {
    this.selectRoom(caseDetailsInfo.OperatingRoom ?? '');
    this.enterDateOfService(caseDetailsInfo.DateOfService ?? '');
    this.enterStartTime(caseDetailsInfo.StartTime ?? '');
    this.enterEndTime(caseDetailsInfo.EndTime ?? '');
    this.selectAppointmentType(caseDetailsInfo.AppointmentType ?? '');

    caseDetailsInfo.CptCodeInfo.forEach((cptData) => {
      this.clickPlusIconProcedureDetails();
      this.enterCPTRowData(cptData);
    });

    if (
      caseDetailsInfo.PreferenceCards &&
      typeof caseDetailsInfo.PreferenceCards != 'string'
    ) {
      caseDetailsInfo.PreferenceCards.forEach((preferenceCardData) => {
        this.selectPreferenceCard(preferenceCardData);
      });
    }

    this.clickNextInCaseDetails();
  }

  /**
   *@details - To enter details in BillingDetails
   * @param billingDetailsInfo - passed to enter BillingDetails
   * @API - API's are not available
   */
  enterBillingDetails(billingDetailsInfo: BillingDetails) {
    billingDetailsInfo.PrimaryInsurance &&
      this.enterPrimaryInsurance(billingDetailsInfo.PrimaryInsurance);
    billingDetailsInfo.SecondaryInsurance &&
      this.enterSecondaryInsurance(billingDetailsInfo.SecondaryInsurance);
    billingDetailsInfo.TertiaryInsurance &&
      this.enterTertiaryInsurance(billingDetailsInfo.TertiaryInsurance);

    billingDetailsInfo.WorkersCompensation === YesOrNo.yes &&
      billingDetailsInfo.AdditionalClaimInformation &&
      this.selectAdditionalClaimInformation(
        billingDetailsInfo.AdditionalClaimInformation
      );

    billingDetailsInfo.PrimaryGuarantor &&
      this.selectPrimaryGuarantor(
        billingDetailsInfo.PrimaryGuarantor,
        this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR[0]
      );
    billingDetailsInfo.SecondaryGuarantor &&
      this.selectSecondaryGuarantor(
        billingDetailsInfo.SecondaryGuarantor,
        billingDetailsInfo.SecondaryGuarantorOption!
      );
  }

  /**
   * @details - to create new Patient
   * @API - API's are available - Implemented Completely
   */
  createCase() {
    // Create A Patient
    this.patientCaseInfo!.PatientDetails &&
      this.enterPatientDetails(this.patientCaseInfo!.PatientDetails!);

    this.patientCaseInfo!.CaseDetails &&
      // Create Case Details
      this.enterCaseDetails(this.patientCaseInfo!.CaseDetails!);

    // Create Billing Details If Provided
    this.patientCaseInfo!.BillingDetails &&
      this.enterBillingDetails(this.patientCaseInfo!.BillingDetails);
    sisOfficeDesktop.clickDoneButton();
  }

  /**
   * @details To verify the No Search Results found text in Procedure search field.
   * @param procedure
   * @API - API's are not available
   */
  verifyNoResultsText(procedure: string) {
    cy.cGet(this.orCaseDetails.PROCEDURE_ITEMS[1]).then(($searchVal) => {
      if (
        $searchVal.text().trim().includes(AppErrorMessages.no_results_found)
      ) {
        expect($searchVal.text().trim()).to.equal(
          AppErrorMessages.no_results_found
        );
        cy.cClick(
          this.orCaseDetails.PROCEDURE_ITEMS[1],
          AppErrorMessages.no_results_found
        );
      } else {
        cy.cGet(this.orCaseDetails.CPT_CODE_SELECTION[1])
          .first()
          .within(() => {
            cy.cIsVisible(selectorFactory.getBText(procedure), procedure);
            cy.cClick(selectorFactory.getBText(procedure), procedure);
          });
      }
    });
  }

  /**
   * @details To verify the CDT Codes from the Search Results found text from Procedure field
   * @param cptData - to pass Cpt Model
   * @API - API's are not available
   */
  verifyCDTCode(cptData: Cpt) {
    this.selectGender(CreateCaseOptions.Male);
    this.clickNextInPatientDetails();
    cy.cIsVisible(
      this.orCaseDetails.CPT_CODE_DESCRIPTION[1],
      this.orCaseDetails.CPT_CODE_DESCRIPTION[0]
    );
    cy.cIsEnabled(
      this.orCaseDetails.CPT_CODE_DESCRIPTION[1],
      this.orCaseDetails.CPT_CODE_DESCRIPTION[0]
    );
    this.enterDateOfService(CommonUtils.getTodayDate());
    cy.cClick(
      this.orCaseDetails.CPT_CODE_DESCRIPTION[1],
      this.orCaseDetails.CPT_CODE_DESCRIPTION[0],
      false,
      true
    );
    cy.cType(
      this.orCaseDetails.CPT_CODE_DESCRIPTION[1],
      this.orCaseDetails.CPT_CODE_DESCRIPTION[0],
      cptData.CPTCodeAndDescription
    );
    this.verifyNoResultsText(cptData.CPTCodeAndDescription);
    cy.cRemoveMaskWrapper(Application.office);
    this.clickCaseCross();
    this.clickLossData();
  }

  /**
   * @details To verify the CDT Code in Procedure Search field.
   * @param index
   * @param cptCode
   * @API - API's are not available
   */
  verifyAddedCptCodeInCptTable(index: number, cptCode: string) {
    cy.cIncludeText(
      selectorFactory.cptCodeInTable(index),
      this.orCaseDetails.CPT_CODE_DESCRIPTION[0],
      cptCode
    );
  }

  /**
   *  @details - To  verify Warning Banner
   *  @API - API's are not available
   */
  verifyWarningBanner() {
    cy.cNotExist(
      this.orCaseDetails.WARNING_BANNER[1],
      this.orCaseDetails.WARNING_BANNER[0]
    );
  }

  /**
   * @details - To Edit equipment quantity
   * @param index - to select particular equipment
   * @param quantity - to pass quantity of equipment
   * @API - API's are available - Implemented Completed
   */
  enterEquipmentUsed(index: number, quantity: number) {
    const interceptCollection = this.createCaseApis.interceptEquipmentApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      selectorFactory.usedEquipmentInCreateCase(index),
      this.orCaseDetails.ADD_EQUIPMENT.EQUIP_QTY_USED[0],
      quantity
    );
    this.clickEquipment();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify the existence of Preference card or Equipment in the respective preference card table or Equipment Table in Case Details Tab
   * @param name - It can be either Equipment or preference card name
   * @param flag - to pass true (default value) or false
   * @API - API's are not available
   */
  verifyEquipmentOrPreferenceCard(name: string, flag: boolean = true) {
    if (flag) {
      cy.cIsVisible(selectorFactory.getSpanText(name), name);
    } else {
      cy.cNotExist(selectorFactory.getSpanText(name), name);
    }
  }

  /**
   * @details - to verify Case Details Warning Banner
   * @API - API's are not available
   */
  verifyCaseDetailsWarningBanner(warningMessage: string) {
    cy.cIncludeText(
      this.orCaseDetails.WARNING_BANNER[1],
      this.orCaseDetails.WARNING_BANNER[0],
      warningMessage
    );
  }

  /**
   * @details - To Add Equipment in Case details
   * @param equip - passed as param to select equipment
   * @API - API's are available - Implemented Completely
   */
  addEquipment(equip: string) {
    cy.cClick(
      this.orCaseDetails.ADD_EQUIPMENT.ADD_BUTTON[1],
      this.orCaseDetails.ADD_EQUIPMENT.ADD_BUTTON[0]
    );
    // Added shouldBeEnabled method before selecting the dropdown
    cy.shouldBeEnabled(this.orCaseDetails.ADD_EQUIPMENT.EQUIP_NAME_DROPDOWN[1]);
    cy.cSelectDropdown(
      this.orCaseDetails.ADD_EQUIPMENT.EQUIP_NAME_DROPDOWN[1],
      this.orCaseDetails.ADD_EQUIPMENT.EQUIP_NAME_DROPDOWN[0],
      equip
    );
    /** Added if condition based on the POPUP/window
     *  if the popup appears it wont wait for the API
     *  else it will wait for the API collection */
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (
        body.find(
          this.orCaseDetails.ADD_EQUIPMENT.DUPLICATE_EQUIPMENT_POPUP
            .DUPLICATE_MESSAGE[1]
        ).length > 0
      ) {
      } else {
      }
    });
  }

  /**
   * @details - to add equipment in case details
   * @API - API's are not available
   */
  clickEquipment() {
    cy.cClick(
      this.orCaseDetails.ADD_EQUIPMENT.EQUIPMENT_HEADER[1],
      this.orCaseDetails.ADD_EQUIPMENT.EQUIPMENT_HEADER[0]
    );
  }

  /**
   * @details - to delete equipment in case details
   * @API - API's are not available
   */
  deleteEquipment(equip: string) {
    cy.cGet(this.orCaseDetails.ADD_EQUIPMENT.EQUIPMENT_ROW[1]).each(
      (element) => {
        if (element.text().indexOf(equip) > -1) {
          cy.wrap(element)
            .first()
            .within(() => {
              element
                .find(this.orCaseDetails.ADD_EQUIPMENT.EQUIPMENT_TRASH_ICON[1])
                .trigger(TriggerAttributes.focus)
                .trigger(TriggerAttributes.click);
            });
          return false;
        }
      }
    );
    cy.cIsVisible(
      this.orCaseDetails.ADD_EQUIPMENT.DELETE_EQUIPMENT_POPUP
        .DELETE_EQUIPMENT[1],
      this.orCaseDetails.ADD_EQUIPMENT.DELETE_EQUIPMENT_POPUP
        .DELETE_EQUIPMENT[0]
    );
    cy.cClick(
      this.orCaseDetails.ADD_EQUIPMENT.DELETE_EQUIPMENT_POPUP.YES_BUTTON[1],
      this.orCaseDetails.ADD_EQUIPMENT.DELETE_EQUIPMENT_POPUP.YES_BUTTON[0]
    );
  }

  /**
   * @details - To  verify Duplicate Equipment Popup And Close
   * @API - API's are available - Implemented Completely
   */
  verifyDuplicateEquipmentPopupAndClose(message: string) {
    const interceptCollection = this.createCaseApis.interceptEquipmentApi();
    cy.cIsVisible(
      this.orCaseDetails.ADD_EQUIPMENT.DUPLICATE_EQUIPMENT_POPUP
        .DUPLICATE_EQUIPMENT[1],
      this.orCaseDetails.ADD_EQUIPMENT.DUPLICATE_EQUIPMENT_POPUP
        .DUPLICATE_EQUIPMENT[0]
    );
    cy.cIncludeText(
      this.orCaseDetails.ADD_EQUIPMENT.DUPLICATE_EQUIPMENT_POPUP
        .DUPLICATE_MESSAGE[1],
      this.orCaseDetails.ADD_EQUIPMENT.DUPLICATE_EQUIPMENT_POPUP
        .DUPLICATE_MESSAGE[0],
      message
    );
    cy.cClickAndWaitApis(
      this.orCaseDetails.ADD_EQUIPMENT.DUPLICATE_EQUIPMENT_POPUP.OK_BUTTON[1],
      interceptCollection
    );
  }

  /**
   * @details - To Delete Added Preference card in Case details
   * @param prefCard - passed as param to Delete Preference card
   * @API - API's are not available
   */
  deletePreferenceCard(prefCard: string) {
    cy.cGet(
      this.orCaseDetails.PREFERENCE_CARD_TABLE.PREFERENCE_CARD_ROW[1]
    ).each(($element) => {
      if ($element.text().indexOf(prefCard) > -1) {
        cy.wrap($element)
          .first()
          .within(() => {
            $element
              .find(
                this.orCaseDetails.PREFERENCE_CARD_TABLE
                  .PREFERENCE_CARD_TRASH_ICON[1]
              )
              .trigger(TriggerAttributes.focus)
              .trigger(TriggerAttributes.click);
          });
        return false;
      }
    });
    cy.cIsVisible(
      this.orCaseDetails.PREFERENCE_CARD_TABLE.DELETE_PREFERENCE_CARD_POPUP
        .DELETE_PREFERENCE_CARD[1],
      this.orCaseDetails.PREFERENCE_CARD_TABLE.DELETE_PREFERENCE_CARD_POPUP
        .DELETE_PREFERENCE_CARD[0]
    );
    cy.cClick(
      this.orCaseDetails.PREFERENCE_CARD_TABLE.DELETE_PREFERENCE_CARD_POPUP
        .YES_BUTTON[1],
      this.orCaseDetails.PREFERENCE_CARD_TABLE.DELETE_PREFERENCE_CARD_POPUP
        .YES_BUTTON[0]
    );
  }

  /**
   * @details - select Billing and payment option
   * @API - API's are available - Implemented completely
   * @author - chandrika
   */
  selectBillingAndPayment() {
    const interceptCollection =
      this.createCaseApis.interceptBillingAndPaymentsApi();
    cy.cClickAndWaitApis(
      selectorFactory.getSpanText(
        this.orPatientCheckIn.BILLING_AND_PAYMENTS.BILLING_AND_PAYMENTS_TAB[0]
      ),
      interceptCollection
    );
  }

  /**
   * @details - Removing  insurance for the selected procedure
   * @API - API's are not available
   */
  removeInsurance(type: string) {
    const insuranceMap = new Map<string, string>();
    insuranceMap.set(
      this.orBillingDetails.PRIMARY_INSURANCE[0],
      this.orBillingDetails.PRIMARY_INSURANCE_CLEAR[1]
    );

    insuranceMap.set(
      this.orBillingDetails.SECONDARY_INSURANCE[0],
      this.orBillingDetails.SECONDARY_INSURANCE_CLEAR[1]
    );
    cy.cClick(insuranceMap.get(type)!, type);
  }

  /**
   * @details - select drop down values in Payment fields of billing & payment
   * @API - API's are not available
   */
  paymentSelectDropdownValue(type: string, valueToSelect: String) {
    const paymentMap = new Map<string, string>();
    paymentMap.set(this.orPayment.PERIOD[0], this.orPayment.PERIOD[1]);

    paymentMap.set(this.orPayment.BATCH[0], this.orPayment.BATCH[1]);

    cy.cSelectDropdown(paymentMap.get(type)!, type, valueToSelect);
  }

  /**
   * @details - Enter amount collected in payment
   * @param amount - to enter in the amount collected field
   * @API - API's are not available
   */
  enterAmountCollected(amount: number) {
    cy.cType(
      this.orPayment.AMOUNT_COLLECTED[1],
      this.orPayment.AMOUNT_COLLECTED[0],
      amount
    );
  }

  /**
   * @details - Enter amount due in payment
   * @param amount - to enter in the amount due field
   * @API - API's are not available
   */
  enterAmountDue(amount: number) {
    cy.cType(
      this.orPayment.AMOUNT_DUE[1],
      this.orPayment.AMOUNT_DUE[0],
      amount
    );
  }

  /**
   * @details - Enter data in Payment Details
   * @param payment - to pass AmountDue model
   * @API - API's are not available
   */
  paymentDetails(payment: AmountDue) {
    // Amount due field is optional,so if user will provide data,it will be entered else it will continue to the next steps

    if (payment.AmountDue ?? '' == undefined) {
      this.enterAmountDue(payment.AmountDue);
    }
    this.enterAmountCollected(payment.AmountCollected);
    this.paymentSelectDropdownValue(this.orPayment.PERIOD[0], payment.Period!);
    this.paymentSelectDropdownValue(this.orPayment.BATCH[0], payment.Batch!);
  }

  /**
   * @details - Click Print in Payment Details and click close icon
   * @API - API's are available - Implemented completely
   * @author - chandrika
   */
  printReceipt() {
    const interceptCollection = this.createCaseApis.interceptPrintReceiptApi();
    cy.cClickAndWaitApis(
      this.orPayment.PRINT_RECEIPT[1],
      interceptCollection,
      false,
      false,
      { force: true }
    );
    cy.cClick(this.orPayment.CLOSE[1], this.orPayment.CLOSE[0]);
  }

  /**
   * @details - Click on Patient Details
   * @API - API's are not available
   */
  selectPatientDetails() {
    cy.cClick(
      selectorFactory.getSpanText(
        this.orPatientCheckIn.PATIENT_DETAILS.PATIENT_DETAILS_TAB[0]
      ),
      this.orPatientCheckIn.PATIENT_DETAILS.PATIENT_DETAILS_TAB[0]
    );
  }

  /**
   * @details - Verify Deposit Amount Field Value
   * @param amountDue - to verify amount in amount due field
   * @API - API's are not available
   */
  verifyAmountDue(amountDue: string) {
    cy.cHasValue(
      this.orPayment.AMOUNT_DUE[1],
      this.orPayment.AMOUNT_DUE[0],
      amountDue
    );
  }

  /**
   * @details - to verify Additional Claim Info Is Expanded
   * @API - API's are not available
   */
  verifyAdditionalClaimInfoIsExpanded(flag: boolean = true) {
    if (flag) {
      cy.cHasAttribute(
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO[1],
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO[0],
        InvokeAttributes.class,
        CommonClassAttributes.down
      );
    } else {
      cy.cHasAttribute(
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO[1],
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO[0],
        InvokeAttributes.class,
        CommonClassAttributes.up
      );
    }
  }

  /**
   * @details - verify the next day is disabled in calendar
   * @API - API's are not available
   */
  verifyNextDayIsDisabled() {
    const tomorrowDate = new Date(CommonUtils.getNextDay()).getDate();
    if (tomorrowDate == 1) {
      cy.cGet(selectorFactory.calendarDateNextMonth(tomorrowDate))
        .last()
        .invoke(InvokeMethods.attribute, InvokeAttributes.class)
        .should(ShouldMethods.include, CommonClassAttributes.disabled);
    } else {
      cy.cHasAttribute(
        selectorFactory.calendarDate(tomorrowDate),
        selectorFactory.calendarDate(tomorrowDate),
        InvokeAttributes.class,
        CommonClassAttributes.disabled
      );
    }
  }

  /**
   * @details - verify the amount due is editable
   * @param - flag - to pass true (default value) or false
   * @API - API's are not available
   */
  verifyAmountDueIsEditable(flag: boolean = true) {
    if (flag) {
      cy.cHasAttribute(
        this.orPayment.AMOUNT_DUE[1],
        this.orPayment.AMOUNT_DUE[0],
        InvokeAttributes.class,
        CommonClassAttributes.valid
      );
    } else {
      cy.cHasAttribute(
        this.orPayment.AMOUNT_DUE[1],
        this.orPayment.AMOUNT_DUE[0],
        InvokeAttributes.class,
        CommonClassAttributes.filled
      );
    }
  }

  /**
   * @details - to click on Accident Date Calendar in Additional Claim Information
   * @API - API's are not available
   */
  clickOnAccidentDateCalendar() {
    cy.cClick(
      this.orPatientCheckIn.ACCIDENT_DATE_CALENDAR[1],
      this.orPatientCheckIn.ACCIDENT_DATE_CALENDAR[0]
    );
  }

  /**
   * @details - verify additional claim check mark
   * @param - flag - to pass true (default value) or false
   * @API - API's are not available
   */
  verifyAdditionalClaimCheckMark(flag: boolean = true) {
    if (flag) {
      cy.cIsVisible(
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO_CHECK_MARK[1],
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO_CHECK_MARK[0]
      );
    } else {
      cy.cNotExist(
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO_CHECK_MARK[1],
        this.orPatientCheckIn.ADDITIONAL_CLAIM_INFO_CHECK_MARK[0]
      );
    }
  }

  /**
   * @details - Click On Create a Case Tab in Schedule Grid
   * @API - API's are available - Implemented Completely
   * @author - chandrika
   */
  clickCreateACaseTab() {
    const interceptCollection = this.createCaseApis.interceptCreateCaseTabApi();
    // Added the selectTracker method to avoid the white screen issue
    sisOfficeDesktop.selectTracker(
      this.orSisOffice.NAVIGATION.SCHEDULE_TYPE.SCHEDULE_GRID[0]
    );
    cy.cClickAndWaitApis(
      this.orCreateCase.CREATE_A_CASE_TAB[1],
      interceptCollection
    );
  }

  /**
   * @details - Entering the Patient First Name in the New patient window
   * @param - patientDetails - to pass PatientDetails model
   * @API - API's are not available
   */
  enterPatientFirstName(patientDetails: PatientDetails) {
    cy.cType(
      this.orNewPatient.PATIENT_FIRST_NAME[1],
      this.orNewPatient.PATIENT_FIRST_NAME[0],
      patientDetails.PatientFirstName
    );
  }

  /**
   * @details - Entering the Patient Last Name in the New patient window
   * @param - patientDetails
   * @param - patientDetails - to pass PatientDetails model
   * @API - API's are not available
   */
  enterPatientLastName(patientDetails: PatientDetails) {
    cy.cType(
      this.orNewPatient.LAST_NAME[1],
      this.orNewPatient.LAST_NAME[0],
      patientDetails.LastName
    );
  }

  /**
   * @details - Entering the Patient Pronouns
   * @param - patientDetails
   * @API - API's are not available
   */
  enterPreferredName(patientDetails: PatientDetails) {
    cy.cType(
      this.orPatientDetails.PREFERRED_NAME[1],
      this.orPatientDetails.PREFERRED_NAME[0],
      patientDetails.PreferredName
    );
  }

  /**
   * @details - Verifying the Labels in the New patient window
   * @API - API's are not available
   */
  verifyNewPatientLabel() {
    newPatientLabelValues.forEach((label) => {
      cy.cGet(selectorFactory.getSpanText(label)).should(ShouldMethods.visible);
    });
  }

  /**
   * @details - verify the new patient done button is enabled
   * @API - API's are not available
   */
  verifyNewPatientDoneButtonEnabled() {
    cy.cIsEnabled(
      this.orNewPatient.DONE_BUTTON[1],
      this.orNewPatient.DONE_BUTTON[0]
    );
  }

  /**
   * @details - click the new patient cross button
   * @API - API's are not available
   */
  clickPatientCross() {
    cy.cClick(this.orSisOffice.CLOSE_ICON[1], this.orSisOffice.CLOSE_ICON[0]);
  }

  /**
   * @details - click the case cross button
   * @API - API's are not available
   */
  clickCaseCross() {
    /**
     * Added a verification step to verify the cross icon and has in enable state
     */
    cy.shouldBeEnabled(this.orNewPatient.CASE_CROSS[1]);
    cy.cClick(this.orNewPatient.CASE_CROSS[1], this.orNewPatient.CASE_CROSS[0]);
  }

  /**
   * @details - click the new patient cross button
   * @API - API's are available - Implemented completely
   * @author - chandrika
   */
  clickLossData() {
    const interceptCollection = this.createCaseApis.interceptLossDataApi();
    cy.cClickAndWaitApis(
      this.orNewPatient.LOSS_OF_DATA[1],
      interceptCollection
    );
  }

  /**
   * @details - verify the MRN and External MRN after the new case creation
   * @API - API's are not available
   */
  verifyMRNExternalMRN() {
    cy.cIsEnabled(
      this.orPatientDetails.MRN[1],
      this.orPatientDetails.MRN[0],
      false,
      false
    );
    cy.cIsEnabled(
      this.orPatientDetails.EXTERNAL_MRN[1],
      this.orPatientDetails.EXTERNAL_MRN[0],
      false,
      false
    );
  }

  /**
   * @details - Click on the Insurance Add button in the new case
   * @API - API's are available - Implemented Completely
   */
  clickInsuranceAddButton() {
    const interceptCollection =
      this.createCaseApis.interceptInsuranceAddButtonApis();
    cy.cClickAndWaitApis(
      orInsuranceCoverage.ADD_BUTTON[1],
      interceptCollection
    );

    /**
     * Added a verification to verify the dropdown icon after clicking on add button
     */
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN[1],
        ' ',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      )
    );
  }

  /**
   * @details -verify active Male/Female in sex toggles.
   * @param - sex
   * @API - API's are not available
   */
  verifyActiveSex(sex: string) {
    cy.cHasClass(
      selectorFactory.toggle(sex),
      sex,
      CommonClassAttributes.phighlight
    );
  }

  /**
   * @details - Verify the all the labels and Icons in Insurance Model of case
   * @API - API's are not available
   */
  verifyTitlesIconsInsuranceModel() {
    cy.cIncludeText(
      orInsuranceCoverage.TITLE[1],
      orInsuranceCoverage.TITLE[0],
      orInsuranceCoverage.TITLE[0]
    );
    cy.cIsVisible(
      this.orSisOffice.CLOSE_ICON[1],
      this.orSisOffice.CLOSE_ICON[0]
    );
    // Verify carrier dropdown labels in insurance coverage pop up
    cy.cGet(orInsuranceCoverage.DROPDOWN_LABELS[1])
      .eq(0)
      .then(($ele) => {
        const txt = $ele.text();
        expect(txt).to.equal(
          orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[0]
        );
      });
    cy.cGet(orInsuranceCoverage.DROPDOWN_LABELS[1])
      .eq(1)
      .then(($ele) => {
        const txt = $ele.text();
        expect(txt).to.equal(orInsuranceCoverage.INSURANCE_PLAN[0]);
      });
    cy.cGet(orInsuranceCoverage.DROPDOWN_LABELS[1])
      .eq(2)
      .then(($ele) => {
        const txt = $ele.text();
        expect(txt).to.equal(orInsuranceCoverage.CLAIM_OFFICE[0]);
      });
    cy.cHasText(
      orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[1],
      orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[0],
      this.orSisOffice.DROPDOWN_VALUES.SELECT_ITEM
    );
    cy.cHasText(
      orInsuranceCoverage.INSURANCE_PLAN[1],
      orInsuranceCoverage.INSURANCE_PLAN[0],
      this.orSisOffice.DROPDOWN_VALUES.NO_ITEM_SELECT
    );
    insurancePopupLabels.forEach((label) => {
      cy.cGet(selectorFactory.getLabelText(label)).should(
        ShouldMethods.visible
      );
    });
    cy.cHasAttribute(
      orInsuranceCoverage.MIDDLE_INITIAL[1],
      orInsuranceCoverage.MIDDLE_INITIAL[0],
      CommonClassAttributes.maxlength,
      numOne
    );
  }

  /**
   * @details - Enter the Insurance First Name in the Insurance Model
   * @API - API's are not available
   */
  enterInsuranceFirstName(insuranceCoverage: InsuranceCoverage) {
    cy.cGet(orInsuranceCoverage.INSURANCE_POPUP[1])
      .first()
      .within(() => {
        cy.cType(
          orInsuranceCoverage.FIRST_NAME[1],
          orInsuranceCoverage.FIRST_NAME[0],
          insuranceCoverage.FirstName
        );
      });
  }

  /**
   * @details - Verify the Insurance First Name in the Insurance Model
   * @param - insuranceCoverage - Pass InsuranceCoverage Model to verify patient first name
   * @API - API's are not available
   */
  verifyInsuranceFirstName(insuranceCoverage: InsuranceCoverage) {
    cy.cGet(orInsuranceCoverage.INSURANCE_POPUP[1])
      .first()
      .within(() => {
        cy.cHasValue(
          orInsuranceCoverage.FIRST_NAME[1],
          orInsuranceCoverage.FIRST_NAME[0],
          insuranceCoverage.FirstName!
        );
      });
  }

  /**
   * @details - Enter the Insurance Last Name in the Insurance Model
   * @param - insuranceCoverage - Pass InsuranceCoverage Model to enter patient last name
   * @API - API's are not available
   */
  enterInsuranceLastName(insuranceCoverage: InsuranceCoverage) {
    cy.cGet(orInsuranceCoverage.INSURANCE_POPUP[1])
      .first()
      .within(() => {
        cy.cType(
          orInsuranceCoverage.LAST_NAME[1],
          orInsuranceCoverage.LAST_NAME[0],
          insuranceCoverage.LastName
        );
      });
  }

  /**
   * @details - Verify the Insurance Last Name in the Insurance Model
   * @param - insuranceCoverage - Pass InsuranceCoverage Model to verify patient last name
   * @API - API's are not available
   */
  verifyInsuranceLastName(insuranceCoverage: InsuranceCoverage) {
    cy.cGet(orInsuranceCoverage.INSURANCE_POPUP[1])
      .first()
      .within(() => {
        cy.cHasValue(
          orInsuranceCoverage.LAST_NAME[1],
          orInsuranceCoverage.LAST_NAME[0],
          insuranceCoverage.LastName!
        );
      });
  }

  /**
   * @details - Enter the Insurance Middle Initial in the Insurance Model
   * @param - insuranceCoverage - Pass InsuranceCoverage Model to enter patient middle initial
   * @API - API's are not available
   */
  enterInsuranceMiddleInitial(insuranceCoverage: InsuranceCoverage) {
    cy.cType(
      orInsuranceCoverage.MIDDLE_INITIAL[1],
      orInsuranceCoverage.LAST_NAME[0],
      insuranceCoverage.MI
    );
  }

  /**
   * @details - Clearing the Insurance First Name and Last Name in the Insurance Model
   * @API - API's are not available
   */
  clearInsuranceFirstLastName() {
    cy.cGet(orInsuranceCoverage.INSURANCE_POPUP[1])
      .first()
      .within(() => {
        cy.cClear(orInsuranceCoverage.FIRST_NAME[1]);
        cy.cClear(orInsuranceCoverage.LAST_NAME[1]);
      });
  }

  /**
   * @details - verify the warning message for the Insurance First and Last Name in the Insurance Model
   * @API - API's are not available
   */
  verifyWarningMsgInsuranceFirstLastName(presence: boolean = true) {
    if (presence) {
      cy.cGet(orInsuranceCoverage.INSURANCE_WARNING[1])
        .eq(0)
        .should(ShouldMethods.visible)
        .should(
          ShouldMethods.include_text,
          AppErrorMessages.required_first_name
        );
      cy.cGet(orInsuranceCoverage.INSURANCE_WARNING[1])
        .eq(1)
        .should(ShouldMethods.visible)
        .should(
          ShouldMethods.include_text,
          AppErrorMessages.required_last_name
        );
    } else {
      cy.cNotExist(
        orInsuranceCoverage.INSURANCE_WARNING[1],
        orInsuranceCoverage.INSURANCE_WARNING[0]
      );
    }
  }

  /**
   * @details - Verify the Insurance Gender values in the Insurance Model
   * @API - API's are not available
   */
  verifyInsuranceGender() {
    cy.cGet(orInsuranceCoverage.GENDER_PARENT[1])
      .eq(0)
      .invoke(InvokeMethods.attribute, InvokeAttributes.aria_label)
      .should(ShouldMethods.include, CreateCaseOptions.Male);
    cy.cGet(orInsuranceCoverage.GENDER_PARENT[1])
      .eq(1)
      .invoke(InvokeMethods.attribute, InvokeAttributes.aria_label)
      .should(ShouldMethods.include, CreateCaseOptions.Female);
  }

  /**
   * @details - Select the Insurance Gender in the Insurance Model
   * @API - API's are not available
   */
  selectInsuranceGender(insuranceCoverage: InsuranceCoverage) {
    let gender = 1;
    if (insuranceCoverage.Gender === 'Male') {
      gender = 0;
    }
    cy.cGet(orInsuranceCoverage.GENDER_PARENT[1]).eq(gender).click();
  }

  /**
   * @details - Verify Selected Insurance Gender in the Insurance Model
   * @API - API's are not available
   */
  verifySelectedInsuranceGender(insuranceCoverage: InsuranceCoverage) {
    let gender = 1;
    if (insuranceCoverage.Gender === 'Male') {
      gender = 0;
    }
    cy.cGet(orInsuranceCoverage.GENDER_PARENT[1])
      .eq(gender)
      .should(ShouldMethods.css, InvokeAttributes.backgroundColor)
      .and(
        ShouldMethods.colored,
        AppColors.component_enabled_toggle_button_selected
      );
  }

  /**
   * @details - Verify the Insurance DOB in the Insurance Model
   * @API - API's are not available
   */
  verifyInsuranceDOB() {
    cy.cIncludeText(
      orInsuranceCoverage.DOB_LABEL[1],
      orInsuranceCoverage.DOB[0],
      orInsuranceCoverage.DOB[0]
    );
  }

  /**
   * @details - Verify the Placeholder Insurance DOB in the Insurance Model
   * @API - API's are not available
   */
  verifyPlaceholderInsuranceDOB(insuranceCoverage: InsuranceCoverage) {
    cy.cHasAttribute(
      orInsuranceCoverage.DOB[1],
      orInsuranceCoverage.DOB[0],
      CommonClassAttributes.placeholder,
      insuranceCoverage.DOB
    );
  }

  /**
   * @details - Verify the Insurance DOB is filled in the Insurance Model
   * @API - API's are not available
   */
  verifyInsuranceDOBFilled() {
    cy.cHasClass(
      orInsuranceCoverage.DOB[1],
      orInsuranceCoverage.DOB[0],
      CommonClassAttributes.filled,
      false,
      false
    );
  }

  /**
   * @details - Enter the Insurance DOB in the Insurance Model
   * @API - API's are not available
   */
  enterInsuranceDOB(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.DOB &&
      cy.cType(
        orInsuranceCoverage.DOB[1],
        orInsuranceCoverage.DOB[0],
        insuranceCoverage.DOB
      );
  }

  /**
   * @details - Verify the Insurance Subscriber ID in the Insurance Model
   * @API - API's are not available
   */
  verifySubscriberID(insuranceCoverage: InsuranceCoverage) {
    cy.cHasAttribute(
      orInsuranceCoverage.SUBSCRIBER_ID[1],
      orInsuranceCoverage.SUBSCRIBER_ID[0],
      CommonClassAttributes.maxlength,
      insuranceCoverage.SubscriberID
    );
  }

  /**
   * @details - Enter the Insurance Subscriber ID in the Insurance Model
   * @API - API's are not available
   */
  enterSubscriberID(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.SubscriberID &&
      cy.cType(
        orInsuranceCoverage.SUBSCRIBER_ID[1],
        orInsuranceCoverage.SUBSCRIBER_ID[0],
        insuranceCoverage.SubscriberID
      );
  }

  /**
   * @details - Enter the Insurance Group Number in the Insurance Model
   * @API - API's are not available
   */
  enterGroupNumber(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.GroupName &&
      cy.cType(
        orInsuranceCoverage.GROUP_NAME[1],
        orInsuranceCoverage.GROUP_NAME[0],
        insuranceCoverage.GroupName
      );
  }

  /**
   * @details - Enter the Insurance Group Name in the Insurance Model
   * @API - API's are not available
   */
  enterGroupName(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.GroupNumber &&
      cy.cType(
        orInsuranceCoverage.GROUP_NUMBER[1],
        orInsuranceCoverage.GROUP_NUMBER[0],
        insuranceCoverage.GroupNumber
      );
  }

  /**
   * @details - Enter the Insurance Employer in the Insurance Model
   * @API - API's are not available
   */
  enterEmployer(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.Employer &&
      cy.cType(
        orInsuranceCoverage.EMPLOYER[1],
        orInsuranceCoverage.EMPLOYER[0],
        insuranceCoverage.Employer
      );
  }

  /**
   * @details - Verify the Insurance DateFormat EffectiveFrom in the Insurance Model
   * @API - API's are not available
   */
  verifyDateFormatEffectiveFrom(insuranceCoverage: InsuranceCoverage) {
    cy.cHasAttribute(
      orInsuranceCoverage.EFFECTIVE_FROM[1],
      orInsuranceCoverage.EFFECTIVE_FROM[0],
      CommonClassAttributes.placeholder,
      insuranceCoverage.EffectiveFrom
    );
  }

  /**
   * @details - Verify the Insurance DateFormat EffectiveTo in the Insurance Model
   * @API - API's are not available
   */
  verifyDateFormatEffectiveTo(insuranceCoverage: InsuranceCoverage) {
    cy.cHasAttribute(
      orInsuranceCoverage.EFFECTIVE_TO[1],
      orInsuranceCoverage.EFFECTIVE_TO[0],
      CommonClassAttributes.placeholder,
      insuranceCoverage.EffectiveTo
    );
  }

  /**
   * @details - Enter the Insurance EffectiveFrom in the Insurance Model
   * @API - API's are not available
   */
  enterEffectiveFrom(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.EffectiveFrom &&
      cy.cType(
        orInsuranceCoverage.EFFECTIVE_FROM[1],
        orInsuranceCoverage.EFFECTIVE_FROM[0],
        insuranceCoverage.EffectiveFrom
      );
  }

  /**
   * @details - Enter the Insurance EffectiveTo in the Insurance Model
   * @API - API's are not available
   */
  enterEffectiveTo(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.EffectiveTo &&
      cy.cType(
        orInsuranceCoverage.EFFECTIVE_TO[1],
        orInsuranceCoverage.EFFECTIVE_TO[0],
        insuranceCoverage.EffectiveTo
      );
  }

  /**
   * @details - Clear the Insurance EffectiveFrom field in the Insurance Model
   * @API - API's are not available
   */
  clearEffectiveFrom() {
    cy.cClear(orInsuranceCoverage.EFFECTIVE_FROM[1]);
  }

  /**
   * @details - Clear the Insurance EffectiveTo field in the Insurance Model
   * @API - API's are not available
   */
  clearEffectiveTo() {
    cy.cClear(orInsuranceCoverage.EFFECTIVE_TO[1]);
  }

  /**
   * @details - Click the Insurance EffectiveFrom field in the Insurance Model
   * @API - API's are not available
   */
  clickEffectiveFrom() {
    cy.cClick(
      orInsuranceCoverage.EFFECTIVE_FROM[1],
      orInsuranceCoverage.EFFECTIVE_FROM[0]
    );
  }

  /**
   * @details - Click the Insurance EffectiveTo field in the Insurance Model
   * @API - API's are not available
   */
  clickEffectiveTo() {
    cy.cClick(
      orInsuranceCoverage.EFFECTIVE_TO[1],
      orInsuranceCoverage.EFFECTIVE_TO[0]
    );
  }

  /**
   * @details - Verify the Insurance EffectiveFrom field is filled in the Insurance Model
   * @API - API's are not available
   */
  verifyEffectiveFromFilled() {
    cy.cHasClass(
      orInsuranceCoverage.EFFECTIVE_FROM[1],
      orInsuranceCoverage.EFFECTIVE_FROM[0],
      CommonClassAttributes.filled,
      false,
      false
    );
  }

  /**
   * @details - Verify the Insurance EffectiveTo field is filled in the Insurance Model
   * @API - API's are not available
   */
  verifyEffectiveToFilled() {
    cy.cHasClass(
      orInsuranceCoverage.EFFECTIVE_TO[1],
      orInsuranceCoverage.EFFECTIVE_TO[0],
      CommonClassAttributes.filled,
      false,
      false
    );
  }

  /**
   * @details - Verify the Insurance RelationshipToSubscriber Label in the Insurance Model
   * @API - API's are not available
   */
  verifyRelationshipToSubscriberLabel() {
    cy.cGet(orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_LABEL[1])
      .eq(3)
      .then(($ele) => {
        const txt = $ele.text();
        expect(txt).to.equal(
          orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_LABEL[0]
        );
      });
  }

  /**
   * @details - Verify the Insurance RelationshipToSubscriber default Dropdown value in the Insurance Model
   * @API - API's are not available
   */
  verifyRelationshipToSubscriberDefaultValue() {
    cy.cHasText(
      orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[1],
      orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[0],
      this.orSisOffice.DROPDOWN_VALUES.SELECT_ITEM
    );
  }

  /**
   * @details - click the Insurance RelationshipToSubscriber Dropdown in the Insurance Model
   * @API - API's are not available
   */
  clickRelationshipToSubscriberDropdown() {
    cy.cClick(
      orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[1],
      orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[0]
    );
  }

  /**
   * @details - Verify the Insurance Address Fields in the Insurance Model
   * @API - API's are not available
   */
  verifyInsuranceAddressFields() {
    const selectors = [
      orInsuranceCoverage.ADDRESS1,
      orInsuranceCoverage.ADDRESS2,
      orInsuranceCoverage.CITY,
      orInsuranceCoverage.EMAIL,
      orInsuranceCoverage.PRIMARY_PHONE,
    ];
    selectors.forEach((locator) => {
      cy.cIsVisible(locator[1], locator[0]);
    });
    cy.cGet(orInsuranceCoverage.CITY[1])
      .invoke(InvokeMethods.attribute, CommonClassAttributes.maxlength)
      .should(CommonClassAttributes.equal, numForty);
  }

  /**
   * @details - click the Insurance state dropdown in the Insurance Model
   * @API - API's are not available
   */
  clickStateDropdown() {
    cy.cClick(
      orInsuranceCoverage.STATE_DROPDOWN[1],
      orInsuranceCoverage.STATE_DROPDOWN[0]
    );
  }

  /**
   * @details - Enter the Insurance Address fields in the Insurance Model
   * @API - API's are not available
   */
  enterAddressFields(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.Address1 &&
      cy.cType(
        this.orPatientDetails.INSURANCE_COVERAGE.ADDRESS1[1],
        this.orPatientDetails.INSURANCE_COVERAGE.ADDRESS1[0],
        insuranceCoverage.Address1
      );
    insuranceCoverage.Address2 &&
      cy.cType(
        this.orPatientDetails.INSURANCE_COVERAGE.ADDRESS2[1],
        this.orPatientDetails.INSURANCE_COVERAGE.ADDRESS2[0],
        insuranceCoverage.Address2
      );
    insuranceCoverage.City &&
      cy.cType(
        this.orPatientDetails.INSURANCE_COVERAGE.CITY[1],
        this.orPatientDetails.INSURANCE_COVERAGE.CITY[0],
        insuranceCoverage.City
      );
    insuranceCoverage.State &&
      cy.cSelectDropdown(
        this.orPatientDetails.INSURANCE_COVERAGE.STATE_DROPDOWN[1],
        this.orPatientDetails.INSURANCE_COVERAGE.STATE_DROPDOWN[0],
        insuranceCoverage.State
      );
    insuranceCoverage.ZipCode &&
      cy.cType(
        this.orPatientDetails.INSURANCE_COVERAGE.ZIP_CODE[1],
        this.orPatientDetails.INSURANCE_COVERAGE.ZIP_CODE[0],
        insuranceCoverage.ZipCode
      );
  }

  /**
   * @details - Enter the Insurance Phone field in the Insurance Model
   * @API - API's are not available
   */
  enterPhoneNumber(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.PrimaryPhone &&
      cy.cType(
        orInsuranceCoverage.PRIMARY_PHONE[1],
        orInsuranceCoverage.PRIMARY_PHONE[0],
        insuranceCoverage.PrimaryPhone
      );
  }

  /**
   * @details - Verify the Insurance Phone field is filled in the Insurance Model
   * @API - API's are not available
   */
  verifyPhoneNumberFilled() {
    cy.cHasClass(
      orInsuranceCoverage.PRIMARY_PHONE[1],
      orInsuranceCoverage.PRIMARY_PHONE[0],
      CommonClassAttributes.filled,
      false,
      false
    );
  }

  /**
   *  @details - To  verify State DropDown Values
   *  @API - API's are not available
   */
  verifyStateDropDownValues(dataValues: any) {
    cy.cClick(
      orInsuranceCoverage.STATE_DROPDOWN[1],
      orInsuranceCoverage.STATE_DROPDOWN[0]
    );
    dataValues.forEach((dataVal: string) => {
      cy.cType(
        orInsuranceCoverage.STATE_DROPDOWN_SEARCH_AREA[1],
        orInsuranceCoverage.STATE_DROPDOWN_SEARCH_AREA[0],
        dataVal
      );
      cy.cGet(orInsuranceCoverage.STATE_DROPDOWN_VALS_LIST[1]).then(($ele) => {
        const resultText = $ele.text();
        expect(resultText.trim()).to.contain(dataVal);
      });
    });

    cy.cClick(
      orInsuranceCoverage.STATE_DROPDOWN[1],
      orInsuranceCoverage.STATE_DROPDOWN[0]
    );
  }

  /**
   *  @details - To  verify County DropDown Values
   * @API - API's are not available
   */
  verifyCountyDropDownValues(dataValues: any) {
    /**
     * @Issue: Sometime before enabling the button trying to clicking and search for the values
     * @Resolution: we have added the should be enabled method for the dropdown
     * @API - API's are not available
     */
    cy.shouldBeEnabled(
      this.orPatientDetails.INSURANCE_COVERAGE.COUNTRY_DROPDOWN[1]
    );
    cy.cClick(
      this.orPatientDetails.INSURANCE_COVERAGE.COUNTRY_DROPDOWN[1],
      this.orPatientDetails.INSURANCE_COVERAGE.COUNTRY_DROPDOWN[0]
    );
    cy.cGet(CoreCssClasses.DropDown.loc_dropdown_item).each(function (
      $ele,
      index,
      list
    ) {
      const expectedCountryName = $ele.text();
      expect(expectedCountryName.trim()).to.contain(dataValues[index]);
    });
    cy.cClick(
      this.orPatientDetails.INSURANCE_COVERAGE.COUNTRY_DROPDOWN[1],
      this.orPatientDetails.INSURANCE_COVERAGE.COUNTRY_DROPDOWN[0]
    );
  }

  /**
   * @details - To verify Labels In Insurance Pop Up
   * @API - API's are not available
   * @author Bindhu
   */
  verifyLabelsInInsurancePopUp() {
    insurancePopupLabels.forEach((label) => {
      cy.cGet(selectorFactory.getLabelText(label)).should(
        ShouldMethods.visible
      );
    });
  }

  /**
   * @details - click the Insurance Email in the Insurance Model
   * @API - API's are not available
   */
  clickEmail() {
    cy.cClick(orInsuranceCoverage.EMAIL[1], orInsuranceCoverage.EMAIL[0]);
  }

  /**
   * @details - click the Insurance Carrier Dropdown in the Insurance
   * @API - API's are not available
   */
  clickInsuranceCarrierDropdown() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[1],
      orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[0],
      false,
      true
    );
  }

  /**
   * @details - Enter the value in Insurance Carrier dropdown search bar in the Insurance Model
   * @API - API's are not available
   */
  enterInsuranceCarrierDropdownSearchBar(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.InsuranceCarrier &&
      cy.cType(
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_SEARCHBAR[1],
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_SEARCHBAR[0],
        insuranceCoverage.InsuranceCarrier
      );
  }

  /**
   * @details - select the value in Insurance Carrier dropdown value in the Insurance Model
   * @API - API's are available - Implemented completely
   * @author - chandrika
   */
  selectInsuranceCarrierDropdownValue() {
    const interceptCollection =
      this.createCaseApis.interceptSelectInsuranceDropdownValueApi();
    cy.cClickAndWaitApis(
      orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_VALUE[1],
      interceptCollection
    );
  }

  /**
   * @details - click and select the Insurance Carrier Dropdown in the Insurance Model
   * @API - API's are available - Implemented completely
   * @author - chandrika
   */
  clickAndSelectInsuranceCarrierDropdown(insuranceCoverage: InsuranceCoverage) {
    const interceptCollection =
      this.createCaseApis.interceptSelectInsuranceDropdownValueApi();
    cy.cIntercept(interceptCollection);
    insuranceCoverage.InsuranceCarrier &&
      cy.cSelectDropdown(
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[1],
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[0],
        insuranceCoverage.InsuranceCarrier
      );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click and select the Insurance RelationshipToSubscriber Dropdown in the Insurance Model
   * @API - API's are not available
   */
  clickSelectRelationshipToSubscriberDropdown(
    insuranceCoverage: InsuranceCoverage
  ) {
    /**
     * Added a verification step to verify the insurance dropdown icon
     */
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN[1],
        ' ',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      )
    );
    insuranceCoverage.RelationshipToSubscriber &&
      cy.cSelectDropdown(
        orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[1],
        orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[0],
        insuranceCoverage.RelationshipToSubscriber
      );
  }

  /**
   * @details - click and select the Insurance Carrier Dropdown in the Insurance Model
   * @API - API's are available - Implemented completely
   * @author - chandrika
   */
  selectInsuranceCarrier(insuranceCoverage: InsuranceCoverage) {
    const interceptCollection =
      this.createCaseApis.interceptSelectInsuranceDropdownValueApi();
    cy.cIntercept(interceptCollection);
    insuranceCoverage.InsuranceCarrier &&
      cy.cSelectDropdown(
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[1],
        orInsuranceCoverage.INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER[0],
        insuranceCoverage.InsuranceCarrier
      );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click and select the Insurance RelationshipToSubscriber Dropdown in the Insurance Model
   *@API - API's are not available
   */
  selectRelationshipToSubscriber(insuranceCoverage: InsuranceCoverage) {
    insuranceCoverage.RelationshipToSubscriber &&
      cy.cSelectDropdown(
        orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[1],
        orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN[0],
        insuranceCoverage.RelationshipToSubscriber
      );
  }

  /**
   * @details - click and select the Insurance RelationshipToSubscriber Dropdown in the Insurance Model
   * @param - flag - To pass true or false
   * @API - API's are not available
   */
  verifyInsuranceDone(flag: boolean = true) {
    cy.cIsEnabled(
      orInsuranceCoverage.DONE_BUTTON[1],
      orInsuranceCoverage.DONE_BUTTON[0],
      false,
      flag
    );
  }

  /**
   * @details - click and select the Insurance RelationshipToSubscriber Dropdown in the Insurance Model
   * @API - API's are available - Implemented Completely
   */
  clickInsuranceDoneButton() {
    const interceptCollection =
      this.createCaseApis.interceptClickOnInsuranceDoneButtonApis();
    cy.cClickAndWaitApis(
      orInsuranceCoverage.DONE_BUTTON[1],
      interceptCollection,
      false,
      true
    );
  }

  /**
   * @details - Verify the count of insurances available in the Insurance Model
   * @API - API's are not available
   */
  verifyCountOfInsurances(expectedCount: number) {
    cy.cGet(orInsuranceCoverage.INSURANCE_COVERAGE_ACTIVE_ROW[1]).should(
      ShouldMethods.length,
      expectedCount
    );
  }

  /**
   * @details - Verify the Case Details Labels in the Case Creation
   * @API - API's are not available
   * @author Bindhu
   */
  verifyCaseDetailsLabels() {
    const labels = [
      {
        logicalName: this.orCaseDetails.START_TIME[0],
        locator: this.orCaseDetails.START_TIME[1],
      },
    ];
    labels.forEach((obj) => {
      cy.cIsVisible(obj.locator, obj.logicalName);
    });
    caseDetailsLabels.forEach((label) => {
      cy.cIncludeText(
        this.orSisOffice.LABEL_CLASS.LOC_CONTROL_LABEL,
        label,
        label
      );
    });
    this.verifyDefaultTextInPreferenceCard();
    const selectors = [
      this.orCaseDetails.ADD_PREFERENCE_CARD.ADD_BUTTON,
      this.orCaseDetails.ADD_EQUIPMENT.ADD_BUTTON,
    ];
    selectors.forEach((locator) => {
      cy.cIsVisible(locator[1], locator[0]);
    });
  }

  /**
   * @details - Verify the Default text in Preference Card in the Case Creation
   * @API - API's are not available
   * @author Bindhu
   */
  verifyDefaultTextInPreferenceCard() {
    cy.cIncludeText(
      this.orSisOffice.LABEL_CLASS.LOC_CONTROL_LABEL,
      this.orCaseDetails.PREFERENCE_CARD_LABEL[0],
      CreateCaseOptions.PREFERENCE_CARD_TEXT
    );
  }

  /**
   * @details - Verify the Warning Message of Start and EndTime for Case Details Labels in the Case Creation
   * @API - API's are not available
   */
  verifyWarningMsgStartEndTime() {
    cy.cClick(
      this.orCaseDetails.START_TIME[1],
      this.orCaseDetails.START_TIME[0]
    );
    cy.cClick(this.orCaseDetails.END_TIME[1], this.orCaseDetails.END_TIME[0]);
    cy.cIncludeText(
      this.orCaseDetails.WARNING_MESSAGE[1],
      this.orCaseDetails.WARNING_MESSAGE[0],
      AppErrorMessages.required_start_end_times
    );
  }

  /**
   * @details - Verify the Warning Message of DOS for Case Details Labels in the Case Creation
   * @API - API's are not available
   */
  verifyWarningMsgDOS() {
    cy.cClear(this.orCaseDetails.DATE_OF_SERVICE[1]);
    cy.cIncludeText(
      this.orCaseDetails.DATE_WARNING_MESSAGE[1],
      this.orCaseDetails.DATE_WARNING_MESSAGE[0],
      AppErrorMessages.required_date_of_service
    );
  }

  /**
   * @details - Verify the Procedure section Details labels for Case Details Labels in the Case Creation
   * @API - API's are not available
   * @author Bindhu
   */
  verifyProcedureDetailsCaseDetailsLabel() {
    const labels = [
      {
        logicalName: this.orCaseDetails.CPT_LABEL[0],
        locator: this.orCaseDetails.CPT_LABEL[1],
      },
      {
        logicalName: this.orCaseDetails.Modified_PROC_LABEL[0],
        locator: this.orCaseDetails.Modified_PROC_LABEL[1],
      },
      {
        logicalName: this.orCaseDetails.LATERALITY_LABEL[0],
        locator: this.orCaseDetails.LATERALITY_LABEL[1],
      },
      {
        logicalName: this.orCaseDetails.PHYSICIAN_LABEL[0],
        locator: this.orCaseDetails.PHYSICIAN_LABEL[1],
      },
      {
        logicalName: this.orCaseDetails.PRE_OP_LABEL[0],
        locator: this.orCaseDetails.PRE_OP_LABEL[1],
      },
    ];
    labels.forEach((obj) => {
      cy.cIncludeText(obj.locator, '', obj.logicalName);
    });
  }

  /**
   * @details - Click on Plus Icon in the Procedure section of Case Details Labels in the Case Creation
   * @API - API's are available - Not Implemented
   * TO DO - Apis are present but unstable, hence not implemented
   */
  clickPlusIconProcedureDetails() {
    cy.cClick(
      this.orCaseDetails.GREEN_PLUS_ICON[1],
      this.orCaseDetails.GREEN_PLUS_ICON[0]
    );
  }

  /**
   * @details - Click on Placeholders of CPT and Pre-op in the Procedure section of Case Details Labels in the Case Creation
   * @API - API's are not available
   */
  verifyPlaceholderCPTPreOp() {
    cy.cHasAttribute(
      this.orCaseDetails.CPT_LABEL_TEXT[1],
      this.orCaseDetails.CPT_LABEL_TEXT[0],
      CommonClassAttributes.placeholder,
      CreateCaseOptions.Search_Procedure
    );
    cy.cHasAttribute(
      this.orCaseDetails.PRE_OP_LABEL_TEXT[1],
      this.orCaseDetails.PRE_OP_LABEL_TEXT[0],
      CommonClassAttributes.placeholder,
      CreateCaseOptions.Search_Items
    );
  }

  /**
   * @details - Verify the Copy Right at the bottom in the Case Creation
   * @API - API's are not available
   */
  verifyCopyRight() {
    cy.cIncludeText(
      this.orCaseDetails.COPY_RIGHT[1],
      this.orCaseDetails.COPY_RIGHT[0],
      HelperText.disclaimer_text_cpt
    );
  }

  /**
   * @details - click the Billing Details tab in the Case Creation
   * @API - API's are available - Not Implemented
   */
  clickBillingDetails() {
    cy.cClick(
      this.orBillingDetails.BILLING_DETAILS_BUTTON[1],
      this.orBillingDetails.BILLING_DETAILS_BUTTON[0]
    );
  }

  /**
   * @details - click the Primary Guarantor Dropdown of Billing Details tab in the Case Creation
   * @API - API's are available - Not Implemented
   */
  clickPrimaryGuarantorDropdown() {
    cy.cClick(
      this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR[1],
      this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR[0]
    );
  }

  /**
   * @details - select the Primary Guarantor Dropdown value of Billing Details tab in the Case Creation
   * @API - API's are available - Implemented Completed
   */
  selectPrimaryGuarantorDropdownValue() {
    const interceptCollection = this.createCaseApis.interceptAddNewGuarantor();
    cy.cClickAndWaitApis(
      this.orBillingDetails.GUARANTORS.ADD_NEW_GUARANTOR[1],
      interceptCollection
    );
  }

  /**
   * @details - select the Primary Guarantor Dropdown value of Billing Details tab in the Case Creation
   * @API - API's are available - Not Implemented
   */
  selectPrimaryGuarantorDropdownSelfValue() {
    cy.cClick(
      selectorFactory.getSpanText(this.orSisOffice.DROPDOWN_VALUES.SELF),
      this.orSisOffice.DROPDOWN_VALUES.SELF
    );
  }

  /**
   * @details - Verify the Guarantor Labels in popup window of Billing Details tab in the Case Creation
   * @API - API's are not available
   */
  verifyGuarantorPopupLabels() {
    cy.cIncludeText(
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR_POPUP[1],
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR_POPUP[0],
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR_POPUP[0]
    );
    const selectors = [
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.FIRST_NAME,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.LAST_NAME,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.GENDER_MALE,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.DOB,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.RELATIONSHIP_TO_PATIENT,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.PRIMARY_PHONE,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ADDRESS1,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ADDRESS2,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.CITY,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.STATE_DROPDOWN,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.ZIP_CODE,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.COUNTRY_DROPDOWN,
      this.orBillingDetails.GUARANTORS.ADD_GUARANTOR.DONE_BUTTON,
    ];
    selectors.forEach((locator) => {
      cy.cIsVisible(locator[1], locator[0]);
    });
  }

  /**
   * @details - Click the close button of Guarantor popup window of Billing Details tab in the Case Creation
   * @API - API's are not available
   */
  clickAddGuarantorPopupClose() {
    cy.cClick(this.orSisOffice.CLOSE_ICON[1], this.orSisOffice.CLOSE_ICON[0]);
  }

  /**
   * @details - Select the dropdown values of secondary Guarantor dropdown of Billing Details tab in the Case Creation
   * @API - API's are available-Implemented completely
   * @Author -Spoorthy
   */
  selectSecondaryGuarantorDropdownValue(option: string) {
    var interceptCollection: ApiEndpoint[] = [];
    switch (option) {
      case CreateCaseOptions.AddNewGuarantor:
        interceptCollection =
          this.createCaseApis.interceptSecondaryGuarantorDropdownApi();
        cy.cIntercept(interceptCollection);
        cy.cSelectDropdown(
          this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR[1],
          this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR[0],
          CreateCaseOptions.AddNewGuarantor
        );
        cy.cWaitApis(interceptCollection);
        break;
      case this.orSisOffice.DROPDOWN_VALUES.SELF:
        interceptCollection =
          this.createCaseApis.interceptSecondaryGuarantorApi();
        cy.cIntercept(interceptCollection);
        cy.cSelectDropdown(
          this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR[1],
          this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR[0],
          this.orSisOffice.DROPDOWN_VALUES.SELF
        );
        cy.cWaitApis(interceptCollection);
        break;
      default:
        break;
    }
  }

  /**
   * @details - Verify the Secondary Guarantor Fields is disabled of Billing Details tab in the Case Creation
   * @API - API's are not available
   */
  verifySecondaryGuarantorFields() {
    cy.cHasClass(
      this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR_FIELD[1],
      this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR_FIELD[0],
      CommonClassAttributes.disabled,
      false,
      false
    );
  }

  /**
   * @details - Click on the patient Details tab in the edit Case
   * @API - API's are not available
   */
  verifyPatientDetails() {
    cy.cIsVisible(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS
        .PATIENT_DETAILS_RADIO_BUTTON[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS
        .PATIENT_DETAILS_RADIO_BUTTON[0]
    );
  }

  /**
   * @details - Click on the patient Details tab in the edit Case
   * @API - API's are available Implemented completely
   * @Author -Spoorthy
   */
  clickPatientDetails() {
    const interceptCollection =
      this.createCaseApis.interceptSelectPatientDetailsInEditApi();
    cy.cClickAndWaitApis(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS
        .PATIENT_DETAILS_RADIO_BUTTON[1],
      interceptCollection,
      false,
      true
    );
  }

  /**
   * @details - Verify the Insurance Data Table
   * @API - API's are not available
   */
  verifyInsuranceDataTable() {
    cy.cIsVisible(
      orInsuranceCoverage.INSURANCE_COVERAGE_DATA_TABLE[1],
      orInsuranceCoverage.INSURANCE_COVERAGE_DATA_TABLE[0]
    );
  }

  /**
   * @details - Verify the Insurance Name in the Insurance Data Table
   * @API - API's are not available
   */
  verifyInsuranceNameInTable(insuranceCoverage: InsuranceCoverage) {
    cy.cIncludeText(
      orInsuranceCoverage.INSURANCE_COVERAGE_ACTIVE_ROW[1],
      orInsuranceCoverage.INSURANCE_COVERAGE_ACTIVE_ROW[0],
      insuranceCoverage.InsuranceCarrier +
        ', ' +
        insuranceCoverage.InsurancePlan
    );
  }

  /**
   * @details - Click Existing Insurance in the Insurance Data Table
   * @API - API's are available -Not using this method
   */
  clickExistingInsurance(index: number) {
    cy.cGet(orInsuranceCoverage.INSURANCE_COVERAGE_ACTIVE_ROW[1])
      .eq(index)
      .should(ShouldMethods.visible)
      .click({ force: true });
  }

  /**
   * @details - Click Existing Insurance in the Insurance Data Table
   * @API - API's are available Implemented completely
   * @Author -Spoorthy
   */
  clickExistingInsuranceName(insuranceName: string) {
    const interceptCollection =
      this.createCaseApis.interceptExistingInsuranceNameApi();
    cy.shouldBeEnabled(selectorFactory.elementTable(insuranceName));
    cy.cClickAndWaitApis(
      selectorFactory.elementTable(insuranceName),
      interceptCollection,
      false,
      true
    );
  }

  /**
   * @details - Verify the bubble above the patient page title will check off as complete
   * @API - API's are not available
   */
  verifyCheckMarkPatientDetails() {
    cy.cHasAttribute(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS
        .PATIENT_DETAILS_RADIO_BUTTON[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS
        .PATIENT_DETAILS_RADIO_BUTTON[0],
      InvokeAttributes.class,
      CommonClassAttributes.check
    );
  }

  /**
   * @details - Verify the dropdown values of the insurance dropdowns
   * @API - API's are not available
   */
  verifyDropdownValues(characterLength: any, dataValues: any) {
    let unsortedItems = new Array();
    cy.cGet(orInsuranceCoverage.INSURANCE_LIST[0])
      .should(ShouldMethods.length, characterLength)
      .each(($el) => {
        unsortedItems.push($el.attr(InvokeAttributes.aria_label));
      })
      .then(() => {
        expect(unsortedItems).to.deep.equal(dataValues);
        unsortedItems.splice(0, unsortedItems.length);
      });
  }

  /**
   * @details - Click on the Case Details Tab while creating patient
   * @API - API's are available- Implemented completely
   * @Author -Spoorthy
   */
  clickOnCaseDetailsTab() {
    const interceptCollection =
      this.createCaseApis.interceptClickOnCasesDetailsApi();
    cy.cClickAndWaitApis(
      this.orCreateCase.MY_TASKS.CASE_DETAILS_TAB[1],
      interceptCollection
    );
  }

  /**
   * @details - Click on the Patient Details Tab
   * @API - API's are available-Implemented Completely
   * Already added api in clickNextInPatientDetails()
   */
  clickOnPatientDetailsTab() {
    cy.cClick(
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS_TAB[1],
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS_TAB[0]
    );
  }

  /**
   * @details - Click on the Billing Details Tab
   * @API - API's are available - Implemented Completely
   * Already added api in clickNextInCaseDetails()
   */
  clickOnBillingDetailsTab() {
    cy.cClick(
      this.orCreateCase.MY_TASKS.BILLING_DETAILS_TAB[1],
      this.orCreateCase.MY_TASKS.BILLING_DETAILS_TAB[0]
    );
  }

  /**
   * @details - Click on the BlockLabel in Case Details
   * @API - API's are not available
   */
  clickOnBlockLabel() {
    cy.cClick(
      this.orCreateCase.MY_TASKS.CASE_DETAILS.BLOCK[1],
      this.orCreateCase.MY_TASKS.CASE_DETAILS.BLOCK[0]
    );
  }

  /**
   *
   * @param color - Verify the color of the tick mark when Case Details is selected
   * @API - API's are not available
   */
  verifyCaseDetailsTabIsHighlighted(color: string) {
    cy.cGet(this.orCreateCase.MY_TASKS.CASE_DETAILS_TAB[1])
      .should(ShouldMethods.css, InvokeAttributes.color)
      .and(ShouldMethods.colored, color);
  }

  /**
   * @details - verify the state of done button in footer in CheckIn
   * @param isEnable
   * @API - API's are not available
   */
  verifyDoneButtonStateInFooterInCheckIn(isEnable: boolean = true) {
    this.orPatientCheckIn.FOOTER_BUTTONS.DONE_BUTTON[1],
      this.orPatientCheckIn.FOOTER_BUTTONS.DONE_BUTTON[0],
      false,
      isEnable;
  }

  /**
   * @details - verify the color of the Done Button in footer in CheckIn
   * @param color
   * @API - API's are not available
   */
  verifyColorOfDoneButtonInFooterInCheckIn(color: string) {
    cy.cHasBackgroundColor(
      this.orPatientCheckIn.FOOTER_BUTTONS.DONE_BUTTON[1],
      this.orPatientCheckIn.FOOTER_BUTTONS.DONE_BUTTON[0],
      color
    );
  }

  /**
   * @details - To click on the Patient Details Tab in CheckIn
   * @API - API's are available - Implemented Completely
   */
  clickOnPatientDetailsTabInCheckIn() {
    cy.cClick(
      selectorFactory.getSpanText(
        this.orPatientCheckIn.PATIENT_DETAILS.PATIENT_DETAILS_TAB[0]
      ),
      this.orPatientCheckIn.PATIENT_DETAILS.PATIENT_DETAILS_TAB[0]
    );
  }

  /**
   * @details - To click on the FormsAndConsents Tab in CheckIn
   * @API - API's are available - Implemented completely
   */
  clickOnFormsAndConsentsTabInCheckIn() {
    const interceptCollection =
      this.createCaseApis.interceptSelectFormsAndConsentsApi();
    cy.cClickAndWaitApis(
      selectorFactory.getSpanText(
        this.orPatientCheckIn.FORMS_AND_CONSENTS.FORMS_AND_CONSENTS_TAB[0]
      ),
      interceptCollection
    );
  }

  /**
   * @details - To click on the Attachments Tab in CheckIn
   * @API - API's are available- Implemented completely
   * @Author -Spoorthy
   */
  clickOnAttachmentsTabInCheckIn() {
    const interceptCollection =
      this.createCaseApis.interceptAttachmentInCheckInApi();
    cy.cClickAndWaitApis(
      selectorFactory.getSpanText(
        this.orPatientCheckIn.ATTACHMENTS.ATTACHMENTS_TAB[0]
      ),
      interceptCollection
    );
  }

  /**
   * @details - Enter the DOB in Patient Details Tab in CheckIn
   * @param time
   * @API - API's are not available
   */
  enterDobInPatientDetailsInCheckIn(time: string) {
    cy.cType(
      this.orPatientCheckIn.PATIENT_DETAILS.DOB[1],
      this.orPatientCheckIn.PATIENT_DETAILS.DOB[0],
      time
    );
  }

  /**
   * @details - Click on the DOB Text in Patient Details in CheckIn
   * @API - API's are not available
   */
  clickOnDobTextInPatientDetailsInCheckIn() {
    cy.cClick(
      this.orPatientCheckIn.PATIENT_DETAILS.DOB_TEXT[1],
      this.orPatientCheckIn.PATIENT_DETAILS.DOB[0]
    );
  }

  /**
   * @details - To click on the cross icon in My Tasks and say yes or no
   * @param close
   * @API - API's are not available
   */
  crossIconInMyTasksYesOrNo(close: boolean = true) {
    cy.cClick(
      this.orCreateCase.MY_TASKS.CROSS_ICON[0],
      this.orCreateCase.MY_TASKS.CROSS_ICON[0]
    );
    close
      ? cy.cClick(
          this.orCreateCase.MY_TASKS.LOSS_OF_DATA_WARNING_YES[1],
          this.orCreateCase.MY_TASKS.LOSS_OF_DATA_WARNING_YES[0]
        )
      : cy.cClick(
          this.orCreateCase.MY_TASKS.LOSS_OF_DATA_WARNING_NO[1],
          this.orCreateCase.MY_TASKS.LOSS_OF_DATA_WARNING_NO[0]
        );
  }

  /**
   * @details - To verify cpt code
   * @param index passed to select particular row
   * @param cptCode passed to select cpt code
   * @API - API's are not available
   */
  verifyCptCode(index: number, cptCode: string) {
    cy.cIncludeText(
      selectorFactory.cptCodeInTable(index),
      this.orCaseDetails.CPT_CODE_DESCRIPTION[0],
      cptCode
    );
  }

  /**
   * @details - Click on the Relationship To Subscriber Dropdown and Change the option from one value to other.
   * @API - API's are not available
   */
  clickOnSelectedValueInRelationshipToSubscriberDropdown(
    insuranceCoverage: InsuranceCoverage
  ) {
    cy.cRemoveMaskWrapper(Application.office);
    insuranceCoverage.RelationshipToSubscriber &&
      cy.cSelectDropdown(
        orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_SELECTED_DROPDOWN[1],
        orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_SELECTED_DROPDOWN[0],
        insuranceCoverage.RelationshipToSubscriber
      );
  }

  /**
   * @details - To verify the first name and last name fields are disable state in Insurance popup
   * @API - API's are not available
   */
  verifyInsurerNamesIsDisabled(option: string) {
    let selector: string = '';

    switch (option) {
      case CreateCaseOptions.FirstName:
        selector = orInsuranceCoverage.FIRST_NAME[1];
        break;
      case CreateCaseOptions.LastName:
        selector = orInsuranceCoverage.LAST_NAME[1];
        break;
      default:
        break;
    }
    cy.cGet(selector).should(
      ShouldMethods.attribute,
      CommonClassAttributes.disabled,
      CommonClassAttributes.disabled
    );
  }

  /**
   * @details - verify Insurance popup is closed
   * @API - API's are not available
   */
  verifyInsurancePopupClosed() {
    cy.cNotExist(orInsuranceCoverage.TITLE[1], orInsuranceCoverage.TITLE[0]);
  }

  /**
   * @details - verifying the selected value in the relationship to subscriber dropdown
   * @API - API's are not available
   */
  verifySelectedValueInRelationshipToSubscriber(selectedValue: string) {
    cy.cGet(orInsuranceCoverage.RELATIONSHIP_TO_SUBSCRIBER_SELECTED_VALUE[1])
      .invoke(InvokeMethods.text)
      .then(($val) => {
        expect($val).to.contains(selectedValue);
      });
  }

  /**
   * @details - verify the state of done button
   * @param isEnable
   * @API - API's are not available
   */
  verifyDoneButtonStateInFooter(isEnable: boolean = true) {
    cy.cIsEnabled(
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS.DONE_BUTTON[1],
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS.DONE_BUTTON[0],
      false,
      isEnable
    );
  }

  /**
   * @details - Verify block utilization in case details tab
   * @API - API's are not available
   */
  verifyPresenceOfBlockUtilization(value: string, flag: boolean = true) {
    let loc = selectorFactory.blockUtilization(value);
    if (flag) {
      cy.cIsVisible(loc, value);
    } else {
      cy.cNotExist(loc, value);
    }
  }

  /**
   * @details - verify the color of done button in footer
   * @param color
   * @API - API's are not available
   */
  verifyTheColorOfDoneButtonInFooter(color: string) {
    cy.cHasBackgroundColor(
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS.DONE_BUTTON[1],
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS.DONE_BUTTON[0],
      color
    );
  }

  /**
   * @details - Verify the Secondary Guarantor Fields is disabled of Billing Details tab in the Case Creation
   * @API - API's are not available
   */
  verifyPrimaryGuarantorFields() {
    cy.cIsEnabled(
      this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR_FIRST_NAME[1],
      this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR_FIRST_NAME[0],
      false,
      false
    );
  }

  /**
   * @details - click the Secondary Guarantor state Field of Billing Details tab in the Case Creation
   * @API - API's are available Implemented completely
   * @Author -Spoorthy
   */
  secondaryGuarantorState(addGuarantor: Guarantor) {
    const interceptCollection =
      this.createCaseApis.interceptSecondaryGuarantorApi();
    cy.cIntercept(interceptCollection);
    cy.cSelectDropdown(
      this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR_STATE[1],
      this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR_STATE[0],
      addGuarantor.State!
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click the Secondary Guarantor state Field of Billing Details tab in the Case Creation
   * @API - API's are not available
   */
  verifySecondaryGuarantorState(addGuarantor: Guarantor) {
    cy.cIsVisible(
      selectorFactory.secondaryGuarantorState(addGuarantor.State!),
      this.orBillingDetails.GUARANTORS.SECONDARY_GUARANTOR_STATE[0]
    );
  }

  /**
   * @details - verify create case and add new patient button is not available
   * @API - API's are not available
   */
  verifyCreateCaseNotVisible() {
    cy.cNotExist(
      this.orCreateCase.CREATE_A_CASE_TAB[1],
      this.orCreateCase.CREATE_A_CASE_TAB[0]
    );
    cy.cNotExist(
      this.orCreateCase.NEW_PATIENT_BUTTON[1],
      this.orCreateCase.NEW_PATIENT_BUTTON[0]
    );
  }

  /**
   * @details - verify patient lock message in Patient details tab
   * @API - API's are not available
   */
  verifyPatientLockMessage(lockMessage: any) {
    cy.cIncludeText(
      this.orPatientCheckIn.PATIENT_LOCK_MESSAGE[1],
      this.orPatientCheckIn.PATIENT_LOCK_MESSAGE[0],
      lockMessage,
      false,
      true
    );
  }

  /**
   * @details - Click on Billing details
   * @API - API's are available - Not Implemented
   */
  clickOnBillingDetails() {
    cy.cClick(
      this.orBillingDetails.BILLING_DETAILS_BUTTON[1],
      this.orBillingDetails.BILLING_DETAILS_BUTTON[0]
    );
  }

  /**
   * @details - select methodOfPayment in Billing & Payment tab
   * @param methodOfPayment
   * @API - API's are not available
   */
  selectMethodOfPayment(methodOfPayment: string) {
    cy.shouldBeEnabled(this.orPayment.METHOD_OF_PAYMENT[1]);
    cy.cClick(
      this.orPayment.METHOD_OF_PAYMENT[1],
      this.orPayment.METHOD_OF_PAYMENT[0]
    );
    cy.cClick(selectorFactory.getSpanText(methodOfPayment), methodOfPayment);
  }

  /**
   * @details - select transactionCode in Billing & Payment tab
   * @param transactionCode
   * @API - API's are not available
   */
  selectTransactionCode(transactionCode: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      this.orPayment.TRANSACTION_CODE[1],
      this.orPayment.TRANSACTION_CODE[0]
    );
    cy.cClick(selectorFactory.getSpanText(transactionCode), transactionCode);
  }

  /**
   * @details - clear amount collected and amount Due in Billings & Payment
   * @API - API's are not available
   */
  clearAmountDueCollected() {
    cy.cClear(this.orPayment.AMOUNT_COLLECTED[1]);
    cy.cClear(this.orPayment.AMOUNT_DUE[1]);
  }

  /**
   * @details - For verification of tool tip message in patient details in faceSheet and create case
   * @param loc
   * @param logicalName
   * @param message
   * @API - API's are not available
   */
  verifyToolTipMessage(loc: string, logicalName: string, message: string) {
    cy.cHasAttribute(loc, logicalName, InvokeAttributes.p_tool_tip, message);
  }

  /**
   * @details - verify label name in patient details page
   * @param - labelName as patient labels
   * @API - API's are not available
   */
  verifyLabelsInPatientDetails(labelName: string) {
    const labels = [
      {
        logicalName: this.orPatientDetails.SEX_LABEL[0],
        locator: this.orPatientDetails.SEX_LABEL[1],
      },
      {
        logicalName: this.orPatientDetails.GENDER_IDENTITY_LABEL[0],
        locator: this.orPatientDetails.GENDER_IDENTITY_LABEL[1],
      },
      {
        logicalName: this.orPatientDetails.PRONOUNS_LABEL[0],
        locator: this.orPatientDetails.PRONOUNS_LABEL[1],
      },
      {
        logicalName: this.orPatientDetails.PREFERRED_NAME_LABEL[0],
        locator: this.orPatientDetails.PREFERRED_NAME_LABEL[1],
      },
    ];

    const selectedLabel = labels.find((item) => item.logicalName === labelName);

    if (selectedLabel) {
      cy.cIsVisible(selectedLabel.locator, labelName);
    }
  }

  /**
   * @details - verify selected text in patient details page
   * @param - labelName,labelValue
   * @API - API's are not available
   */
  verifySelectedTextInPatientDetails(labelName: string, labelValue: string) {
    const details = [
      {
        logicalName: this.orPatientDetails.GENDER_IDENTITY[0],
        locator: this.orPatientDetails.GENDER_IDENTITY[1],
        verificationMethod: cy.cIncludeText,
      },
      {
        logicalName: this.orPatientDetails.PRONOUNS[0],
        locator: this.orPatientDetails.PRONOUNS[1],
        verificationMethod: cy.cIncludeText,
      },
      {
        logicalName: this.orPatientDetails.PREFERRED_NAME[0],
        locator: this.orPatientDetails.PREFERRED_NAME[1],
        verificationMethod: cy.cHasValue,
      },
    ];

    const selectedDetail = details.find(
      (item) => item.logicalName === labelName
    );

    if (selectedDetail) {
      const { locator, verificationMethod } = selectedDetail;
      verificationMethod(locator, labelName, labelValue);
    }
  }

  /**
   * @details - click cross icon
   * @param - label
   * @API - API's are not available
   */
  clickCrossIcon(label: string) {
    if (selectorFactory.getLabelText(label).length > 0) {
      cy.cGet(selectorFactory.getLabelText(label))
        .parent(CommonGetLocators.div)
        .within(() => {
          cy.cClick(
            this.orPatientDetails.CROSS_ICON[1],
            this.orPatientDetails.CROSS_ICON[0]
          );
        });
    }
  }

  /**
   * @details - Verify and select dropdown values in patient details section
   * @param logicalName - Dropdown label
   * @param valToSel - value to be selected from dropdown list
   * @API - API's are not available
   */
  verifyAndSelectDropdownValInPatientDetails(
    logicalName: string,
    valToSel: string
  ) {
    const dropdowns = {
      [this.orPatientDetails.RACE[0]]: this.orPatientDetails.RACE[1],
      [this.orPatientDetails.ETHNICITY[0]]: this.orPatientDetails.ETHNICITY[1],
      [this.orPatientDetails.PRIMARY_LANGUAGE[0]]:
        this.orPatientDetails.PRIMARY_LANGUAGE[1],
    };

    cy.cClick(dropdowns[logicalName], logicalName);
    cy.cClick(valToSel, logicalName, true, true);
  }

  /**
   * @details - To Click On NickName label until Dictionary items loaded
   * @API - API's are not available
   */
  waitUntilDicItemsLoad() {
    cy.cIsVisible(
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS.RACE_DROPDOWN[1],
      this.orCreateCase.MY_TASKS.PATIENT_DETAILS.RACE_DROPDOWN[0]
    );
  }

  /**
   * @details - To Clear the Modified procedure
   * @param cptData used as input parameter
   * @API - API's are not available
   */
  clearModifiedProcedureDescription(cptData: Cpt) {
    cy.cGet(CoreCssClasses.Row.loc_p_selectable_row).each(($rows) => {
      if ($rows.text().includes(cptData.CPTCodeAndDescription)) {
        cy.wrap($rows).within(() => {
          cy.wrap($rows).click();
          cy.cGet(CommonGetLocators.td)
            .eq(1)
            .invoke(InvokeMethods.show)
            .click()
            .type(CommonTypeValues.select_all)
            .type(CommonTypeValues.back_space);
        });
      }
    });
  }

  /**
   * @details - verify if MSP type code drop down exists or not
   * @API - API's are not available
   */
  verifyMSpFieldPresence(option: boolean = false) {
    option
      ? cy.cIsVisible(
          selectorFactory.getLabelText(
            OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[0]
          ),
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[0]
        )
      : cy.cNotExist(
          selectorFactory.getLabelText(
            OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[0]
          ),
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[0]
        );
  }

  /**
   * @details - click on MSP code dropdown
   * @API - API's are not available
   */
  clickMspCodeField() {
    cy.cClick(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[0],
      false,
      true
    );
  }

  /**
   * @details - verifying the presence of options in the msp code drop down
   * @param values -Verifying the drop down values
   * @API - API's are not available
   */
  verifyMspCodeFieldValues(values: string[]) {
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getSpanText(el), el);
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_LABEL[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_LABEL[0]
    );
  }

  /**
   * @details - Selecting the value in msp code drop down
   * @param value -Value to be selected in drop down
   */
  selectMspCodeFieldValue(value: string) {
    cy.cSelectDropdown(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[0],
      value
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Verifying saved msp code value in drop down
   * @param value -Value saved in drop down
   * @API - API's are not available
   */
  verifySavedMspCodeValue(value: string) {
    cy.cIncludeText(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MSP_DROPDOWN[0],
      value
    );
  }

  /**
   * @details - Verify Presence of Insurance Popup
   * @param - presence where user can pass whether presence or absence should be validated
   * @API - API's are not available
   */
  verifyInsurancePopup(presence: boolean = true) {
    if (presence) {
      cy.cIsVisible(
        orInsuranceCoverage.INSURANCE_POPUP[1],
        orInsuranceCoverage.INSURANCE_POPUP[0]
      );
    } else {
      cy.cNotExist(
        orInsuranceCoverage.INSURANCE_POPUP[1],
        orInsuranceCoverage.INSURANCE_POPUP[0]
      );
    }
  }

  /**
   * @Issue - primary insurance drop down is getting closed without selecting any values in drop down
   * @Resolution -Trying to add few more assertion before clicking on the drop down
   * @details - click on primary insurance text in billing details tab
   * @API - API's are not available
   */
  clickPrimaryInsurance() {
    cy.cIsVisible(
      this.orBillingDetails.PRIMARY_INSURANCE_TEXT[1],
      this.orBillingDetails.PRIMARY_INSURANCE_TEXT[0]
    );
    cy.cClick(
      this.orBillingDetails.PRIMARY_INSURANCE_TEXT[1],
      this.orBillingDetails.PRIMARY_INSURANCE_TEXT[0]
    );
  }

  /**
   * @details - To verify Amount collected in Edit Unassigned Payment Allocation is Disabled or Enabled
   * @param disabled to be passed as flag
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyAmountCollected(disabled: boolean = true) {
    const amountCollected = disabled
      ? OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.PAYMENT.AMOUNT_DUE[0]
      : OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.PAYMENT
          .AMOUNT_COLLECTED[0];
    const attribute = disabled
      ? CommonClassAttributes.filled
      : CommonClassAttributes.valid;

    cy.cHasAttribute(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.PAYMENT
        .AMOUNT_COLLECTED[1],
      amountCollected,
      InvokeAttributes.class,
      attribute
    );
  }

  /**
   * @details - To verify period and batch dropdown in Edit Unassigned Payment Allocation is Disabled or Enabled
   * @param locator to be passed as string
   * @param disabled to be passed as flag
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyPeriodAndBatchDropdownState(locator: string, disabled: boolean = true) {
    disabled
      ? cy.cHasAttribute(
          locator,
          locator,
          InvokeAttributes.class,
          CommonClassAttributes.disabled
        )
      : cy.cHasAttribute(
          locator,
          locator,
          InvokeAttributes.class,
          CommonClassAttributes.valid
        );
  }

  /**
   * @details - To verify the create case billing details
   * @API - API's are not available
   */
  assertBillingAndPaymentDetailsInCheckIn() {
    const billingDetails = [
      this.orBillingDetails.WORKER_COMPENSATION[1],
      this.orBillingDetails.SELF_PAY[1],
      this.orBillingDetails.GUARANTORS.PRIMARY_GUARANTOR_DROPDOWN_MANDATORY[1],
    ];
    billingDetails.forEach((billingDetail) => {
      cy.shouldBeEnabled(billingDetail);
    });
  }

  /**
   * @details - Verifying Address in patient details
   * @param  patientDetails - patientDetails which has all required data for verifying patient
   * @API - API's are not available
   * @author Suneetha
   */
  verifyAddressInPatientDetails(patientDetails: PatientDetails) {
    cy.cHasValue(this.orPatientDetails.CITY[1], '', patientDetails.City);
    cy.cHasValue(
      CommonUtils.concatenate(
        this.orPatientDetails.ZIP_CODE[1],
        ' ',
        CommonGetLocators.input
      ),
      '',
      patientDetails.ZipCode
    );
    cy.cHasText(
      CommonUtils.concatenate(
        this.orPatientDetails.STATE[1],
        ' ',
        selectorFactory.getSpanText(patientDetails.State!)
      ),
      '',
      patientDetails.State ?? ''
    );
    cy.cHasValue(this.orPatientDetails.COUNTY[1], '', patientDetails.County);
  }

  /**
   * @details - To verify city county state zip code in request details tab
   * @param patient selecting patient to verify zip code,city,county and state
   * @API - API's are not available
   * @author Suneetha
   */
  verifyCityCountyStateZipCodeInRequestDetails(
    patient: PatientDetails,
    color: string = AppColors.component_case_request
  ) {
    cy.cGet(OR_PATIENT_CASE_CREATION.REQUEST_DETAILS.ZIP_CODE[1])
      .should(ShouldMethods.text, patient.ZipCode)
      .and(ShouldMethods.css, InvokeAttributes.color)
      .and(ShouldMethods.colored, color);

    cy.cGet(OR_PATIENT_CASE_CREATION.REQUEST_DETAILS.CITY[1])
      .should(ShouldMethods.text, patient.City)
      .and(ShouldMethods.css, InvokeAttributes.color)
      .and(ShouldMethods.colored, color);

    cy.cGet(OR_PATIENT_CASE_CREATION.REQUEST_DETAILS.COUNTY[1])
      .should(ShouldMethods.text, patient.County)
      .and(ShouldMethods.css, InvokeAttributes.color)
      .and(ShouldMethods.colored, color);

    cy.cGet(OR_PATIENT_CASE_CREATION.REQUEST_DETAILS.STATE[1])
      .should(ShouldMethods.text, patient.State)
      .and(ShouldMethods.css, InvokeAttributes.color)
      .and(ShouldMethods.colored, color);
  }

  /**
   * @details - To verify exclamation icon in request details tab
   * @param name selecting patient name to verify triangle exclamation.
   * @API - API's are not available
   * @author Suneetha
   */
  verifyExclamationIcon(name: string) {
    cy.contains(name)
      .cGet(selectorFactory.getSpanText(name))
      .parents(CommonGetLocators.tr)
      .within(() => {
        cy.cIsVisible(
          OR_PATIENT_CASE_CREATION.REQUEST_DETAILS.EXCLAMATION[1],
          ''
        );
      });
  }

  /**
   * @details - To click updated button in request details tab
   * @API - API's are not available
   * @author Suneetha
   */
  clickUpdateInRequestDetailsTab() {
    cy.cClick(OR_PATIENT_CASE_CREATION.REQUEST_DETAILS.UPDATE[1], '');
  }

  /**
   * @details - To select added carrier insurance in patient details tab
   * @param insuranceCoverage - To selecting insurance.
   * @API - API's are available -  Implemented
   * @author Suneetha
   */
  selectAddedCarrierInInsuranceCoverage(insuranceCoverage: InsuranceCoverage) {
    cy.cNotExist(selectorFactory.getSpanText(orInsuranceCoverage.TITLE[0]), '');
    const interceptCollection =
      this.createCaseApis.interceptSelectInsuranceDropdownValueApi();
    cy.cClickAndWaitApis(
      selectorFactory.getSpanText(insuranceCoverage.InsuranceCarrier),
      interceptCollection,
      false,
      false,
      { force: true }
    );
    cy.shouldBeEnabled(
      selectorFactory.getH3Text(orInsuranceCoverage.EDIT_INSURANCE[0])
    );
  }

  /**
   * @details - To click on done button in insurance coverage pop-up
   * @API - API's are available - Not Implemented
   * @author Suneetha
   */
  clickDoneInInsuranceCoverage() {
    const interceptCollection =
      this.createCaseApis.interceptDoneInInsuranceCoverage();
    cy.cClickAndWaitApis(
      orInsuranceCoverage.DONE_BUTTON[1],
      interceptCollection
    );
  }

  /**
   * @details - click next button in the patient details page of create case tab
   * @Api - API's are available - Implemented Completely
   * @author -Arushi
   */
  clickNextInPatientDetails() {
    const interceptCollection = this.createCaseApis.interceptCaseDetailsApis();
    cy.cIntercept(interceptCollection);
    this.next();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click next button in the case details page of create case tab
   * @Api - API's are available - Implemented Completely
   * @author -Arushi
   */
  clickNextInCaseDetails() {
    const interceptCollection =
      this.createCaseApis.interceptBillingDetailsApi();
    cy.cIntercept(interceptCollection);
    this.next();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click next button in the case details page of create case tab
   * @Api - API's are not available
   * @author -Arushi
   */
  clickNextInBillingDetails() {
    this.next();
  }

  /**
   * @details - click previous button in the case coordination page of create case tab
   * @Api - API's are not available
   * @author -Arushi
   */
  clickPreviousInCaseCoordination() {
    this.previous();
  }

  /**
   * @details - click previous button in the billing details page of create case tab
   * @Api - API's are available - Implemented Completely
   * @author -Arushi
   */
  clickPreviousInBillingDetails() {
    const interceptCollection = this.createCaseApis.interceptCaseDetailsApis();
    cy.cIntercept(interceptCollection);
    this.previous();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click previous button in the case details page of create case tab
   * @Api - API's are available - Implemented Completely
   * @author -Arushi
   */
  clickPreviousInCaseDetails() {
    const interceptCollection =
      this.createCaseApis.interceptPatientDetailsApis();
    cy.cIntercept(interceptCollection);
    this.previous();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click New Patient Done Button available in My tasks
   */
  clickCreateCaseDoneButton() {
    const interceptCollection = this.createCaseApis.CreateCaseDoneApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select AnesthesiaType in Case Details tab
   * @param anesthesiaType in-order to select anesthesia type from dropdown values
   * @API API's are not available
   * @author Divya
   */
  selectAnesthesiaType(anesthesiaType: string) {
    cy.cClick(
      this.orCaseDetails.ANESTHESIA_TYPE[1],
      this.orCaseDetails.ANESTHESIA_TYPE[0]
    );
    cy.cClick(selectorFactory.getSpanText(anesthesiaType), anesthesiaType);
  }

  /*
   * @details - Verify the Duration after entering  Start and End Time in case details tab
   * @param startValue - as a start time value
   * @param endValue - as a end time value
   * @param durationValue - as a duration value
   * @API - API's are not available
   * @author Bindhu
   */
  verifyTimeAndDuration(caseDetailsInfo: CaseDetails) {
    const startTime: ILocatorValue = {
      locator: this.orCaseDetails.START_TIME[1],
      value: caseDetailsInfo.StartTime,
    };
    const endTime: ILocatorValue = {
      locator: this.orCaseDetails.END_TIME[1],
      value: caseDetailsInfo.EndTime,
    };
    const duration: ILocatorValue = {
      locator: this.orCaseDetails.DURATION[1],
      value: caseDetailsInfo.Duration,
    };
    const caseTimeDurCollection = [startTime, endTime, duration];

    caseTimeDurCollection.forEach((obj: ILocatorValue) => {
      obj.value && cy.cHasValue(obj.locator, '', obj.value);
    });
  }

  /**
   * @details - verify operating room in case details tab
   * @param - value of the Operating Room
   * @API - API's are not available
   * @author Bindhu
   */
  verifyRoom(value: string) {
    cy.cIsVisible(this.orCaseDetails.OPERATING_ROOM[1], value);
  }

  /**
   * @details - verify preference card in case details tab
   * @API - API's are not available
   * @author Bindhu
   */
  verifyPreferenceCard() {
    cy.cIncludeText(
      this.orSisOffice.LABEL_CLASS.LOC_CONTROL_LABEL,
      this.orCaseDetails.PREFERENCE_CARD_LABEL[0],
      this.orCaseDetails.PREFERENCE_CARD_LABEL[0]
    );
  }

  /**
   * @details - selecting multiple insurances in patient details tab
   * @param insurances - To selecting specific insurances.
   * @API - API's are available - Implemented Completely
   * @author Bindhu
   */
  addMultipleInsurances(insurances: InsuranceCoverage[]) {
    insurances.forEach((insuranceCoverage) => {
      this.addInsuranceCoverage(insuranceCoverage);
    });
  }

  /**
   * @details - select Primary Guarantor drop down, Click on Add New Guarantor and Click on Done button
   * @param addGuarantor - Guarantor model fields needs to be passed, ex: first name, last name etc
   * @API - API's are available - Implemented Completely
   * @author Bindhu
   */
  clickAndAddPrimaryGuarantor(addGuarantor: Guarantor) {
    this.clickPrimaryGuarantorDropdown();
    this.selectPrimaryGuarantorDropdownValue();
    this.selectAddGuarantor(addGuarantor);
    this.clickDoneFooterButton();
  }
}

/**
 * @details - return Insurance Locators and values in patient details tab
 * @param insuranceCoverage
 * @API - API's are available - Implemented Completely
 * @author Bindhu
 */
function returnInsuranceLocatorValues(
  insuranceCoverage: InsuranceCoverage
): ILocatorValue[] {
  const firstName: ILocatorValue = {
    locator: orInsuranceCoverage.FIRST_NAME[1],
    value: insuranceCoverage.FirstName,
  };
  const lastName: ILocatorValue = {
    locator: orInsuranceCoverage.LAST_NAME[1],
    value: insuranceCoverage.LastName,
  };
  const middleInitial: ILocatorValue = {
    locator: orInsuranceCoverage.MIDDLE_INITIAL[1],
    value: insuranceCoverage.MI,
  };
  const suffix: ILocatorValue = {
    locator: orInsuranceCoverage.SUFFIX[1],
    value: insuranceCoverage.Suffix,
  };
  const dob: ILocatorValue = {
    locator: orInsuranceCoverage.DOB[1],
    value: insuranceCoverage.DOB,
  };
  const address1: ILocatorValue = {
    locator: orInsuranceCoverage.ADDRESS1[1],
    value: insuranceCoverage.Address1,
  };
  const address2: ILocatorValue = {
    locator: orInsuranceCoverage.ADDRESS2[1],
    value: insuranceCoverage.Address2,
  };
  const zipCode: ILocatorValue = {
    locator: orInsuranceCoverage.ZIP_CODE[1],
    value: insuranceCoverage.ZipCode,
  };
  const email: ILocatorValue = {
    locator: orInsuranceCoverage.EMAIL[1],
    value: insuranceCoverage.Email,
  };
  const groupName: ILocatorValue = {
    locator: orInsuranceCoverage.GROUP_NAME[1],
    value: insuranceCoverage.GroupName,
  };
  const groupNumber: ILocatorValue = {
    locator: orInsuranceCoverage.GROUP_NUMBER[1],
    value: insuranceCoverage.GroupNumber,
  };
  const employer: ILocatorValue = {
    locator: orInsuranceCoverage.EMPLOYER[1],
    value: insuranceCoverage.Employer,
  };
  const primaryPhone: ILocatorValue = {
    locator: orInsuranceCoverage.PRIMARY_PHONE[1],
    value: CommonUtils.concatenate(
      '(',
      insuranceCoverage.PrimaryPhone!.substring(0, 3),
      ') ',
      insuranceCoverage.PrimaryPhone!.substring(3, 6),
      '-',
      insuranceCoverage.PrimaryPhone!.substring(6, 10)
    ),
  };
  const effectiveFrom: ILocatorValue = {
    locator: orInsuranceCoverage.EFFECTIVE_FROM[1],
    value: CommonUtils.concatenate(
      insuranceCoverage.EffectiveFrom!.substring(0, 2),
      '/',
      insuranceCoverage.EffectiveFrom!.substring(2, 4),
      '/',
      insuranceCoverage.EffectiveFrom!.substring(4, 8)
    ),
  };
  const effectiveTo: ILocatorValue = {
    locator: orInsuranceCoverage.EFFECTIVE_TO[1],
    value: CommonUtils.concatenate(
      insuranceCoverage.EffectiveTo!.substring(0, 2),
      '/',
      insuranceCoverage.EffectiveTo!.substring(2, 4),
      '/',
      insuranceCoverage.EffectiveTo!.substring(4, 8)
    ),
  };
  return [
    firstName,
    lastName,
    middleInitial,
    suffix,
    dob,
    address1,
    address2,
    zipCode,
    email,
    groupName,
    groupNumber,
    employer,
    primaryPhone,
    effectiveFrom,
    effectiveTo,
  ];
}
