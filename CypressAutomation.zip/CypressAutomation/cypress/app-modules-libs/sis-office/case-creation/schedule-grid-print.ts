import {
  CommonClassAttributes,
  CommonGetLocators,
  InvokeAttributes,
  InvokeMethods,
  ShouldMethods,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { PrintPreview as PatientLabelsPrintModel } from '../../../test-data-models/sis-office/case/print-preview.model';

import { OR_SCHEDULE_GRID } from './or/schedule-grid.or';

/**
 * Class for scheduleGridPrintPreview
 */
export default class ScheduleGridPrint {
  // Object Repositories For PrintPopUP
  private orPrintPopUp = OR_SCHEDULE_GRID.PRINT_POPUP;

  /**
   * @details - Self Initialization For NewPatientInfo
   * @details - Page Initialization For commonLayoutPage
   * @param printPreviewInfo
   */
  constructor(private printPreviewInfo?: PatientLabelsPrintModel) {}

  /**
   * exposing patientInfo to client
   */
  get printPreviewModel(): PatientLabelsPrintModel | undefined {
    return this.printPreviewInfo;
  }

  /**
   * @details - verify fields - #LabelsperPatient, Begin Row, Begin column and one Patient per page in Patient Labels Popup
   * @API- API's are available - Not Implemented
   */
  verifyPatientLabelsPrintOptions() {
    cy.cIsVisible(
      this.orPrintPopUp.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[1],
      this.orPrintPopUp.PATIENT_LABELS_POPUP.LABEL_PATIENT_INPUT[0]
    );
    cy.cIsVisible(
      this.orPrintPopUp.PATIENT_LABELS_POPUP.BEGIN_ROW[1],
      this.orPrintPopUp.PATIENT_LABELS_POPUP.BEGIN_ROW[0]
    );
    cy.cIsVisible(
      this.orPrintPopUp.PATIENT_LABELS_POPUP.BEGIN_COLUMN[1],
      this.orPrintPopUp.PATIENT_LABELS_POPUP.BEGIN_COLUMN[0]
    );
    cy.cIsVisible(
      this.orPrintPopUp.PATIENT_LABELS_POPUP.ONE_PATIENT_PER_PAGE_YES_BTN[1],
      this.orPrintPopUp.PATIENT_LABELS_POPUP.ONE_PATIENT_PER_PAGE_YES_BTN[0],
      true
    );
    cy.cIsVisible(
      this.orPrintPopUp.PATIENT_LABELS_POPUP.ONE_PATIENT_PER_PAGE_NO_BTN[1],
      this.orPrintPopUp.PATIENT_LABELS_POPUP.ONE_PATIENT_PER_PAGE_NO_BTN[0],
      true
    );
  }

  /**
   * @details - verify fields values - #LabelsperPatient, Begin Row, Begin column and one Patient per page in Patient Labels Popup
   * @param printRec
   * @API- API's are available - Not Implemented
   */
  verifyValuesInPatientLabelsOptions(printRec: PatientLabelsPrintModel) {
    const print = this.orPrintPopUp.PATIENT_LABELS_POPUP;
    if (printRec.LabelPerPatient) {
      cy.cHasValue(
        print.LABEL_PATIENT_INPUT[1],
        print.LABEL_PATIENT_INPUT[0],
        printRec.LabelPerPatient
      );
    }
    if (printRec.BeginRow) {
      cy.cHasValue(print.BEGIN_ROW[1], print.BEGIN_ROW[0], printRec.BeginRow);
    }
    if (printRec.BeginColumn) {
      cy.cHasValue(
        print.BEGIN_COLUMN[1],
        print.BEGIN_COLUMN[0],
        printRec.BeginColumn
      );
    }
    if (printRec.OnePatientPerPage) {
      cy.cGet(print.ONE_PATIENT_PER_PAGE[1])
        .contains(printRec.OnePatientPerPage)
        .parent(CommonGetLocators.div)
        .invoke(InvokeMethods.attribute, InvokeAttributes.class)
        .then(($element) => {
          if ($element!.indexOf(CommonClassAttributes.active) > -1) {
            cy.log(
              printRec.OnePatientPerPage +
                ' Button is selected for One Patient per page'
            );
          } else {
            cy.log(
              printRec.OnePatientPerPage +
                ' Button is not selected for One Patient per page'
            );
          }
        });
    }
  }

  /**
   * @details - Verify Total No of Non Empty Patient Blocks present in Patient labels print popup
   * @param NoOfPatientLabelBlocks
   * @API- API's are available - Not Implemented
   */
  verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
    NoOfPatientLabelBlocks: number
  ) {
    cy.cHasLength(
      this.orPrintPopUp.PATIENT_LABELS_POPUP.PATIENT_LABEL_BLOCK[1],
      this.orPrintPopUp.PATIENT_LABELS_POPUP.PATIENT_LABEL_BLOCK[0],
      NoOfPatientLabelBlocks
    );
  }

  /**
   * @details - enter fields values - #LabelsperPatient, Begin Row, Begin column and one Patient per page in Patient Labels Popup
   * @param printRec
   * @API- API's are available - Not Implemented
   */
  enterValuesInPatientLabelsOptions(printRec: PatientLabelsPrintModel) {
    const print = this.orPrintPopUp.PATIENT_LABELS_POPUP;
    if (printRec.LabelPerPatient) {
      cy.cType(
        print.LABEL_PATIENT_INPUT[1],
        print.LABEL_PATIENT_INPUT[0],
        printRec.LabelPerPatient
      );
    }
    if (printRec.BeginRow) {
      cy.cType(print.BEGIN_ROW[1], print.BEGIN_ROW[0], printRec.BeginRow);
    }
    if (printRec.BeginColumn) {
      cy.cType(
        print.BEGIN_COLUMN[1],
        print.BEGIN_COLUMN[0],
        printRec.BeginColumn
      );
    }
    if (printRec.OnePatientPerPage) {
      cy.cClick(printRec.OnePatientPerPage, printRec.OnePatientPerPage, true);
    }
  }

  /**
   * @details - To select option in print popup
   * @param option
   * @API- API's are available - Not Implemented
   */
  selectOptionToPreviewInPrintPopup(option: string) {
    cy.cClick(selectorFactory.getDataTestId(option), option, false, true);
    cy.cClick(
      OR_SCHEDULE_GRID.PRINT_POPUP.PREVIEW_BUTTON[1],
      OR_SCHEDULE_GRID.PRINT_POPUP.PREVIEW_BUTTON[0]
    );
  }

  /**
   * @details - To verify the group by default option
   * @API- API's are not available
   */
  verifyGroupByDefaultOptionAsPhysician() {
    cy.cGet(
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.GROUP_BY[1],
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.GROUP_BY[0]
    ).then((text) => {
      cy.wrap(text).should(
        ShouldMethods.contain,
        OR_SCHEDULE_GRID.PHYSICIAN_FILTER[0]
      );
    });
  }

  /**
   * @details - To verify layout toggle button
   * @API- API's are not available
   */
  verifyLayoutToggleButton() {
    cy.cIsVisible(
      selectorFactory.getSpanText(
        OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
          .PORTRAIT[0]
      ),
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
        .PORTRAIT[0]
    );
    cy.cIsVisible(
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
        .LANDSCAPE[1],
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
        .LANDSCAPE[0]
    );
  }

  /**
   * @details - To close print preview
   * @API- API's are not available
   */
  ClosePrintPreview() {
    cy.cClick(
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.CLOSE_ICON[1],
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.CLOSE_ICON[0],
      false,
      true
    );
  }

  verifyRefreshButton(IsEnabled: boolean) {
    cy.cIsEnabled(
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW
        .REFRESH_BUTTON[1],
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW
        .REFRESH_BUTTON[0],
      false,
      IsEnabled
    );
  }
}
