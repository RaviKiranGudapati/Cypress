import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import {
  CommonGetLocators,
  FilterMethods,
} from '../../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';
import * as common from 'mocha/lib/interfaces/common';

export const OR_PATIENT_CASE_CREATION = {
  CREATE_A_CASE: {
    CREATE_A_CASE_TAB: ['Create a Case Tab', '#CreateCase1'],
    SEARCH_PATIENT_INPUT: [
      'Search Patient',
      CommonUtils.concatenate(
        `#create-case-patient-search [data-test-id^='patient-search-bar-input'] `,
        CommonGetLocators.input
      ),
    ],
    CLOSED_CREATE_A_CASE_TAB: [
      'create a case tab closed ',
      '.p-tabmenu.p-component.hasActive',
    ],
    SEARCH_PATIENT_RESULT: [
      'Patient Search Results',
      `[data-test-id^='patient-search-bar-result']`,
    ],
    NEW_PATIENT_BUTTON: ['New Patient', '#btnNewPatient'],
    CREATE_NEW_PATIENT: {
      PATIENT_FIRST_NAME: ['Patient First Name*', '#txtFirstName'],
      DOB: [
        'DOB',
        CommonUtils.concatenate(`#txtMaskDOB > `, CommonGetLocators.input),
      ],
      MIDDLE_INITIAL: ['Middle Initial', '#txtMiddleName'],
      LAST_NAME: ['Last Name*', '#txtLastName'],
      SUFFIX: ['Suffix', '#txtTitle'],
      CASE_CROSS: ['Case Cross Icon', '.span-cross'],
      LOSS_OF_DATA: [
        'Loss of Data popup yes',
        '.p-confirm-dialog-accept> .p-button-label',
      ],
      DONE_BUTTON: [
        'Done',
        CommonUtils.concatenate(
          CoreCssClasses.Dialog.loc_dialog_mask_button,
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1]
        ),
      ],
      PATIENT_MATCH_FOUND: [
        'Patient Match Found Warning',
        '.warning-container .duplicate-patient-warning-text',
      ],
      SELECT_PATIENT_CHECKBOX: [
        'Select Patient Checkbox',
        `button.approve[id^='btnSelectPatient']`,
      ],
      EXPAND_ICON: [
        'Expand Icon',
        CommonUtils.concatenate(CommonGetLocators.i, `[id^='iconExpand']`),
      ],
      PATIENT_FULL_NAME: ['Patient Full Name', 'span.patient-name'],
      PATIENT_DOB: ['Patient DOB', 'span.patient-dob'],
      PATIENT_MRN: ['Patient MRN', 'span.patient-mrn'],
      USE_SELECTED_BUTTON: ['Use Selected', '#btnUserSelected'],
      CREATE_NEW_PATIENT_BTN: ['Create New Patient', '#btnCreatePatient'],
    },
    MY_TASKS: {
      PATIENT_DETAILS_TAB: ['patient details tab', '#iconTabName'],
      PATIENT_DETAILS_RADIO_BUTTON: [
        'Patient Details Radio Button',
        '#iconTabName',
      ],
      CASE_DETAILS_TAB: ['case details tab', '#iconTabName2'],
      BILLING_DETAILS_TAB: ['billing details tab', '#iconTabName3'],
      CASE_REQUEST_NEW_PATIENT: ['New Patient', '#newPatientBtn'],
      FOOTER_BUTTONS: {
        PREVIOUS_BUTTON: ['Previous', '#btnPrevious'],
        NEXT_BUTTON: ['Next', '#btnNext'],
      },
      PATIENT_DETAILS: {
        PATIENT_FIRST_NAME: ['Patient First Name', '#firstName'],
        DOB: [
          'DOB',
          CommonUtils.concatenate('#txtMaskDOB > ', CommonGetLocators.input),
        ],
        MIDDLE_INITIAL: ['Middle Initial', '#middleInitial'],
        LAST_NAME: ['Last Name', '#lastName'],
        SUFFIX: ['Suffix', '#title'],
        SEX_LABEL: ['SEX', '[for="inputGender"]'],
        SEX_TOOLTIP: ['SEX', '[for="inputGender"] i'],
        GENDER: ['Gender'],
        GENDER_IDENTITY_LABEL: [
          'Gender Identity',
          '[for="inputGenderIdentity"]',
        ],
        GENDER_IDENTITY_TOOLTIP: [
          'Gender Identity',
          '[for="inputGenderIdentity"] i',
        ],

        GENDER_IDENTITY: [
          'Gender Identity',
          CommonUtils.concatenate(
            '[data-test-id="genderIdentityDropdown"] ',
            CoreCssClasses.Text.loc_p_input_text
          ),
        ],
        CROSS_ICON: ['Cross Icon', CoreCssClasses.DropDown.loc_dropdown_clear],
        PRONOUNS_TOOLTIP: ['Pronouns Tooltip', '[for="inputPronouns"] i'],
        PRONOUNS_LABEL: ['Pronouns Label', '[for="inputPronouns"]'],
        PRONOUNS: [
          'Pronouns',
          CommonUtils.concatenate(
            '#pronounsDropdown #msItems ',
            CoreCssClasses.MultiSelect.loc_p_multiselect_label
          ),
        ],
        PRONOUNS_VALUE: ['pronouns', 'ul.p-multiselect-items'],
        PREFERRED_NAME_LABEL: ['Preferred Name', '[for="preferredName"]'],
        PREFERRED_NAME: ['Preferred Name', '[data-test-id = "preferredName"]'],
        PREFERRED_NAME_TOOLTIP: ['Preferred Name', '[for="preferredName"] i'],
        AGE: ['Age', '#age'],
        NICKNAME: ['Nickname', '#alias'],
        SSN: ['SSN'],
        MRN: ['MRN', '#mrn'],
        EXTERNAL_MRN: ['External MRN', '#externalMrn'],
        MARITAL_STATUS: ['Marital Status'],
        RACE: ['Race', '#raceDropdown'],
        ETHNICITY: ['Ethnicity', '#ethnicityDropdown'],
        PRIMARY_LANGUAGE: ['Primary Language', '#patientLanguageDropdown'],
        RELIGION: ['Religion'],
        OCCUPATION: ['Occupation'],
        ADDRESS1: ['Address 1', '#line1'],
        ADDRESS2: ['Address 2', '#line2'],
        CITY: ['City', '#city'],
        STATE: ['State', '#stateDropdown'],
        ZIP_CODE: ['Zip Code', '#zip_code_patient_details'],
        COUNTY: ['County', '[data-test-id="county"]'],
        COUNTRY: ['Country'],
        PRIMARY_PHONE: ['Primary Phone'],
        PRIMARY_PHONE_CELL_CHECKBOX: ['Cell'],
        SECONDARY_PHONE: ['Secondary Phone'],
        SECONDARY_PHONE_CELL_CHECKBOX: ['Cell'],
        DONE_BUTTON: ['Done', 'button#btnDone'],
        RACE_DROPDOWN: [
          'Race',
          CommonUtils.concatenate(
            '#raceDropdown',
            ' ',
            selectorFactory.getSpanText('Select Item')
          ),
        ],
        ETHNICITY_DROPDOWN: [
          'Ethnicity',
          CommonUtils.concatenate(
            '#ethnicityDropdown',
            ' ',
            CoreCssClasses.DropDown.loc_dropdown_label
          ),
        ],
        PRIMARY_LANGUAGE_DROPDOWN: [
          'Primary Language',
          CommonUtils.concatenate(
            '#patientLanguageDropdown',
            ' ',
            CoreCssClasses.DropDown.loc_dropdown_label
          ),
        ],
        INSURANCE_COVERAGE: {
          INSURANCE_POPUP: [
            'Edit Insurance',
            CoreCssClasses.Dialog.loc_dialog_box_content,
          ],
          ADD_BUTTON: ['Add', '#btnAdd'],
          STATE_DROPDOWN_SEARCH_AREA: [
            'state search area',
            "input[class^='p-dropdown-filter']",
          ],
          SHOW_INACTIVE: ['Show inactive', 'chkShowInactiveIns'],
          TITLE: ['Add Insurance Coverage', '.p-dialog-header>>>h3'],
          EDIT_INSURANCE: ['Edit Insurance Coverage'],
          DROPDOWN_LABELS: [
            'Dropdown labels',
            '[class^="col-md-4"]>[class="control-label"]',
          ],
          INSURANCE_CARRIER_DROPDOWN: [
            'Insurance Carrier',
            '#insuranceCarriersDropdown',
          ],
          INSURANCE_CARRIER_DROPDOWN_PLACEHOLDER: [
            'Insurance Carrier*',
            '#insuranceCarriersDropdown>>>> .p-placeholder',
          ],
          INSURANCE_CARRIER_DROPDOWN_SEARCHBAR: [
            'Insurance Carrier dropdown search bar',
            'input[class^="p-dropdown-filter"]',
          ],
          INSURANCE_CARRIER_DROPDOWN_VALUE: [
            'Insurance Carrier dropdown first value',
            '.limittext-container',
          ],
          INSURANCE_PLAN: [
            'Insurance Plan*',
            '#insurancePlansDropdown>>>> .p-placeholder',
          ],
          INSURANCE_LIST: ['[role="listbox"] li'],
          INSURANCE_WARNING: [
            'Warning',
            '[class="warning-text ng-star-inserted"]',
          ],
          INSURANCE_COVERAGE_DATA_TABLE: [
            'Insurance coverage data table',
            '#insuranceCoverageTable p-table',
          ],
          INSURANCE_COVERAGE_ACTIVE_ROW: [
            'Insurance table active row',
            CommonUtils.concatenate(
              CoreCssClasses.Row.loc_p_selectable_row,
              CoreCssClasses.Ng.loc_star_inserted,
              FilterMethods.visible
            ),
          ],
          CLAIM_OFFICE: ['Claim Office*', '#claimOfficeDropdown'],
          RELATIONSHIP_TO_SUBSCRIBER_DROPDOWN: [
            'Relationship to Subscriber*',
            '#relationshipToSubscriberDropdown >>>> .p-placeholder',
          ],
          RELATIONSHIP_TO_SUBSCRIBER_LABEL: [
            'Relationship to Subscriber*',
            '[class^="col-md-6"]>label',
          ],
          STATE_DROPDOWN: ['State dropdown', '#statesDropdown'],
          STATE_DROPDOWN_VALS_LIST: [
            'State dropdown',
            '.limittext-holder [class^="limittext"]',
          ],
          COUNTRY_DROPDOWN: [
            'Country',
            '#countryDropdown[name=countryDropdown]',
          ],
          GENDER_PARENT: [
            'Gender parent element',
            '#sbGender [role="group"] div',
          ],
          GENDER: ['Gender'],
          FIRST_NAME_LABEL: ['First Name*', '.group-number'],
          MIDDLE_INITIAL_LABEL: ['MI', '.middle-initial'],
          LAST_NAME_LABEL: ['Last Name*', '.col-md-3 > label'],
          FIRST_NAME: ['First Name', '#txtFirstName'],
          MIDDLE_INITIAL: ['Middle Initial', '#txtMiddleInitial'],
          LAST_NAME: ['Last Name', '#txtLastName'],
          SUFFIX: ['Suffix', '#txtSuffix'],
          SUFFIX_LABEL: ['Suffix', '.col-md-2 > label'],
          DOB: [
            'DOB',
            CommonUtils.concatenate(
              `[class^="insurance"] #txtMaskDOB `,
              CommonGetLocators.input
            ),
          ],
          DOB_LABEL: ['DOB', '[for="txtMaskDOB"]'],
          ADDRESS1: ['Address1', '#address1'],
          ADDRESS2: ['Address2', '#address2'],
          SUBSCRIBER_ID: ['Subscriber ID*', '#txtDisplayName'],
          GROUP_NAME: ['Group Name', '#txtGroupName'],
          GROUP_NAME_LABEL: ['Group Name', "[for='txtGroupName']"],
          GROUP_NUMBER_LABEL: ['Group Number', "[for='txtGroupNumber']"],
          EMPLOYER_LABEL: ['Employer', "[for='txtEmployer']"],
          GROUP_NUMBER: ['GROUP NUMBER', '#txtGroupNumber'],
          CITY: ['City', '#txtCity'],
          ZIP_CODE: [
            'Zip code',
            CommonUtils.concatenate(
              '#zip_code_insurance_coverage > ',
              CommonGetLocators.input
            ),
          ],
          EMPLOYER: ['Employer', '#txtEmployer'],
          COUNTY: ['Country', '#txtCountyName'],
          EFFECTIVE_FROM: [
            'Effective from',
            CommonUtils.concatenate(
              '#effectiveFromDate ',
              CommonGetLocators.input
            ),
          ],
          EFFECTIVE_TO: [
            'EFFECTIVE TO',
            CommonUtils.concatenate(
              '#effectiveToDate ',
              CommonGetLocators.input
            ),
          ],
          EMAIL: ['Email', '#txtEmail'],
          PRIMARY_PHONE: [
            'Primary phone',
            CommonUtils.concatenate(
              `#txtMaskPhone > `,
              CommonGetLocators.input
            ),
          ],
          DONE_BUTTON: ['Done', 'p-footer #btnDone'],
          RELATIONSHIP_TO_SUBSCRIBER_SELECTED_DROPDOWN: [
            'Relationship to subscriber*',
            '#relationshipToSubscriberDropdown',
          ],
          RELATIONSHIP_TO_SUBSCRIBER_SELECTED_VALUE: [
            'Relationship To Subscriber Selected Value',
            CommonUtils.concatenate(
              `#relationshipToSubscriberDropdown `,
              CommonGetLocators.span,
              `[class*='p-inputtext']`
            ),
          ],
          DELETE_POPUP_YES: ['Yes', '#btnInsuranceCoverageYes'],
        },
        ADD_EMPLOYER: {
          ADD_BUTTON: ['Add', '#addEmployer'],
          EMPLOYER_NAME: ['Employer Name', '#txtEmployerName'],
          ADDRESS: ['Address', '#txtAddress'],
          CITY: ['City', '#txtCity'],
          STATE_DROPDOWN: ['State', '#stateDropdown'],
          COUNTRY_DROPDOWN: ['Country', '#countryDropdown'],
          ZIP_CODE: ['Zip Code'],
          EMPLOYER_PHONE: ['Employer Phone'],
        },
        EMERGENCY_CONTACT: {
          FIRST_NAME: ['First Name', '#inputEmergencyContactFirstName'],
          MIDDLE_INITIALS: [
            'Middle initials',
            '#inputEmergencyContactMiddleName',
          ],
          LAST_NAME: ['Last Name', '#inputEmergencyContactLastName'],
          RELATIONSHIP: ['Relationship', '#inputEmergencyContactRelationship'],
          PHONE: ['Phone'],
        },
      },
      CASE_DETAILS: {
        CASE_DETAILS_BUTTON: ['Case Details Button', '#iconTabName2'],
        WARNING_MESSAGE: [
          'Warning message',
          '.warning-text > .ng-star-inserted',
        ],
        DATE_WARNING_MESSAGE: ['DATE Warning message', '.warning-text > small'],
        TIME_WARNING_MESSAGE: [
          'Time Warning Message',
          '[data-test-id="warning_time_validations"]',
        ],
        PREFERENCE_CARD_LABEL: [
          'Preference Cards',
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.LABEL_CLASS.LOC_CONTROL_LABEL,
        ],
        OPERATING_ROOM: ['Operating Room*', '#operatingRoomsDropdown'],
        OPERATING_ROOM_DROPDOWN_TEXT: [
          'Operating Room Dropdown Text',
          CommonUtils.concatenate(
            '#operatingRoomsDropdown ',
            CommonGetLocators.span
          ),
        ],
        BLOCK: ['Block Label', '#lblBlock'],
        CASE_NOTES: ['Case Notes', '#textArea'],
        DATE_OF_SERVICE: [
          'Date of Service*',
          CommonUtils.concatenate('#dateOfService ', CommonGetLocators.input),
        ],
        START_TIME: [
          'Start Time*',
          CommonUtils.concatenate(
            '#txtMaskStartTime ',
            CommonGetLocators.input
          ),
        ],
        END_TIME: [
          'End Time*',
          CommonUtils.concatenate('#txtMaskEndTime ', CommonGetLocators.input),
        ],
        DURATION: ['Duration', '#txtDuration'],
        CLEANUP_TIME: ['Clean-Up Time', '#txtCleanUpTime'],
        REFERRING_PHYSICIAN: [
          'Referring Physician',
          '#staffSingleSelectreferPhysicianId',
        ],
        APPOINTMENT_TYPE: ['Appointment Type*', '#specialtiesDropdown'],
        ANESTHESIA_TYPE: ['Anesthesia Type', '#anesthesiaTypeDropdown'],
        ANESTHESIA_SELECT: [
          'Anesthesia select',
          CommonUtils.concatenate(
            '[class*="',
            CoreCssClasses.DropDown.loc_p_dropdown_items,
            '-wrapper"]'
          ),
        ],
        ENTER_ANESTHESIA_TYPE: [
          'Enter Anesthesia Type',
          CommonUtils.concatenate(
            '[class*="',
            CoreCssClasses.DropDown.loc_p_dropdown_filter,
            '-container"]'
          ),
        ],
        CPT_LABEL: ['CPT® Code and Description', '.cpt-asterisk'],
        CPT_LABEL_TEXT: [
          'Search Procedure',
          '#procedureAutoComplete>span>input',
        ],
        Modified_PROC_LABEL: ['Modified Proc. Description', '.procedure-col'],
        PHYSICIAN_LABEL: ['Physician', '.physician-col.asterisk'],
        LATERALITY_LABEL: ['Laterality', 'th.laterality-col'],
        PRE_OP_LABEL: ['Pre-Op Diagnosis Code', 'th.diagnosis-col'],
        PRE_OP_LABEL_TEXT: [
          'Place holder Text',
          '.p-autocomplete-input-token>input',
        ],
        COPY_RIGHT: ['Copy Right', 'sis-cpt-copy-right'],
        CPT_CODE_DESCRIPTION: [
          'Cpt code And Description',
          CommonUtils.concatenate(
            `#procedureAutoComplete `,
            CommonGetLocators.input
          ),
        ],
        CPT_CODE_SELECTION: ['Cpt Code Selection', '.procedure-item'],
        MODIFIED_PROC_DESCRIPTION: [
          'Modified proc. Description',
          `input[id^='modifiedDescription']`,
        ],
        PHYSICIAN: [
          'Physician',
          '[data-test-id^="staffSingleSelectphyscianDropdown"]',
        ],
        LATERALITY: ['Literality', '[data-test-id^="lateralityDropdown"]'],
        PRE_OP_DIAGNOSIS_CODE: [
          'Pre-op Diagnosis Code',
          CommonUtils.concatenate(
            '#procedure-table-autocomplete ',
            CommonGetLocators.input
          ),
        ],
        GREEN_PLUS_ICON: ['Plus Icon', '#iconAdd'],
        ADD_PREFERENCE_CARD: {
          ADD_BUTTON: ['Add', '#btnAdd'],
          PHYSICIAN: [
            'Physician',
            '#staffSingleSelectphysicianphysicianDropdown',
          ],
          SEARCH_PREFERENCE_CARD: [
            'Search Preference Card',
            `input[placeholder='Search Preference Cards']`,
          ],
          SELECTED_PREFERENCE_CARD: [
            'Selected Preference Card',
            CommonUtils.concatenate(
              `div:contains('Selected Preference Cards') ~ ul `,
              CoreCssClasses.Picklist.loc_p_picklist
            ),
          ],
          DONE_BUTTON: ['Done', '.p-dialog-mask button#btnDone'],
          PREFERENCE_CARD_LIST_ITEM_SELECTION: [
            'Preference Card List Item Selection',
            CoreCssClasses.Picklist.loc_p_picklist,
          ],
          PROCEDURE_LIST_ITEM_SELECTION: [
            'Procedure List Item Selection',
            CoreCssClasses.Picklist.loc_p_orderlist,
          ],
          CHECK_MARK: ['Check Mark', CoreCssClasses.Icon.loc_check_mark],
        },
        PREFERENCE_CARD_TABLE: {
          PREFERENCE_CARD_ROW: [
            'Preference Card',
            '#preferenceCardDataTable tr',
          ],
          PREFERENCE_CARD_TRASH_ICON: [
            'Preference Card Trash Icon',
            CommonUtils.concatenate(
              CoreCssClasses.ClassPrefix.loc_fa_fa,
              `-trash[id^='deletePreferenceCard']`
            ),
          ],
          DELETE_PREFERENCE_CARD_POPUP: {
            DELETE_PREFERENCE_CARD: [
              'Delete Preference Card',
              `span:contains('Delete Preference Card')`,
            ],
            YES_BUTTON: ['Yes', '#btnConfirmAdd'],
            NO_BUTTON: ['No', '#btnConfirmNo'],
          },
        },
        ADD_EQUIPMENT: {
          EQUIPMENT_HEADER: [
            'Equipment',
            '.equipment .equipment-label-div label',
          ],
          EQUIPMENT_ROW: ['Equipment', '#equipmentDataTable tr'],
          ADD_BUTTON: ['Add', '#equipmentbtn'],
          EQUIP_NAME_DROPDOWN: ['Equipment Name', '#equipmentName'],
          EQUIP_QTY_USED: ['Quantity'],
          EQUIPMENT_TRASH_ICON: [
            'Equipment Trash Icon',
            CommonUtils.concatenate(
              CoreCssClasses.ClassPrefix.loc_fa_fa,
              `-trash[id^='delEqu']`
            ),
          ],
          DELETE_EQUIPMENT_POPUP: {
            DELETE_EQUIPMENT: [
              'Delete Equipment',
              `span:contains('Delete Equipment')`,
            ],
            YES_BUTTON: ['Yes', '#btnConfirmAdd'],
            NO_BUTTON: ['No', '#btnConfirmNo'],
          },
          DUPLICATE_EQUIPMENT_POPUP: {
            DUPLICATE_EQUIPMENT: [
              'Duplicate Equipment',
              `span:contains('Duplicate Equipment')`,
            ],
            DUPLICATE_MESSAGE: [
              'Duplicate Message',
              CommonUtils.concatenate(
                CoreCssClasses.Dialog.loc_confirm_dialog,
                ' ',
                CoreCssClasses.Dialog.loc_confirm_dialog_message
              ),
            ],
            OK_BUTTON: ['Ok', '#btnWarnMsg'],
          },
        },
        WARNING_BANNER: [
          'Warning Banner',
          CommonUtils.concatenate(
            '.case-details-banner ',
            CoreCssClasses.Text.loc_limittext_container
          ),
        ],
        PROCEDURE_ITEMS: [
          'Procedure Items',
          CommonUtils.concatenate(
            CoreCssClasses.List.loc_p_autocomplete_items,
            '>li'
          ),
        ],
        CLEAR_OPERATING_ROOM: [
          'clear room',
          '[id="operatingRoomsDropdown"] [class*="clear"]',
        ],
      },
      BILLING_DETAILS: {
        BILLING_DETAILS_BUTTON: ['Billing Details', '#iconTabName3'],
        INSURANCE_DROPDOWN: ['.dropdown-item'],
        PRIMARY_INSURANCE_TEXT: [
          'Primary Insurance Text',
          `div[class*='primary-insurance'] .control-label`,
        ],
        PRIMARY_INSURANCE: ['Primary Insurance', '#primaryInsuranceDropdown'],
        SECONDARY_INSURANCE: [
          'Secondary Insurance',
          '#secondaryInsuranceDropdown',
        ],
        TERTIARY_INSURANCE: [
          'Tertiary Insurance',
          '#tertiaryInsuranceDropdown',
        ],
        PRIMARY_INSURANCE_CLEAR: [
          'Primary Insurance Clear',
          CommonUtils.concatenate(
            '[id^="primaryInsuranceDropdown"] > ',
            CoreCssClasses.PrimeNg.loc_single_select,
            CoreCssClasses.DropDown.loc_dropdown_clear
          ),
        ],
        SECONDARY_INSURANCE_CLEAR: [
          'Secondary Insurance Clear',
          CommonUtils.concatenate(
            '[id^="secondaryInsuranceDropdown"] > ',
            CoreCssClasses.PrimeNg.loc_single_select,
            CoreCssClasses.DropDown.loc_dropdown_clear
          ),
        ],
        SELF_PAY: ['Self-Pay', '#sbtnSelfPayOption'],
        SELF_PAY_PROCEDURES: [
          'Self-Pay Procedure',
          `sis-multi-select-dropdown[name='selfPayProcedures']`,
        ],
        WORKER_COMPENSATION: ['Worker Compensation', '#sbtnWorkersCompOption'],
        WORKERS_COMPENSATION_PROCEDURES: [
          'Worker Compensation Procedure',
          `sis-multi-select-dropdown[name='workersCompensationProcedures']`,
        ],
        ADDITIONAL_CLAIM_INFORMATION: {
          PATIENT_CONDITION_DUE_TO: [
            'Patient Condition Due To',
            '#patientCondition',
          ],
          ACCIDENT_DATE: [
            'Accident Date',
            CommonUtils.concatenate(
              '#dateOfAccident ',
              CommonGetLocators.input
            ),
          ],
          ACCIDENT_STATE: ['Accident State', '#accidentState'],
        },
        GUARANTORS: {
          PRIMARY_GUARANTOR_DROPDOWN_MANDATORY: [
            'Primary Guarantor Mandatory Icon',
            `#cgCaseGuarantors .warning-text`,
          ],
          ADD_GUARANTOR_POPUP: [
            'Add Guarantor',
            '[class^=p-dialog-title] > [class^=ng-tns] > h3',
          ],
          PRIMARY_GUARANTOR: ['Primary Guarantor', '#guarantorType'],
          ADD_NEW_GUARANTOR: [
            'Add New Guarantor',
            '.dropdown-item .add-new-item',
          ],
          ADD_GUARANTOR: {
            FIRST_NAME: ['First Name', '#txtFirstName'],
            LAST_NAME: ['Last Name', '#txtLastName'],
            GENDER: ['Gender', '#sbGender'],
            GENDER_MALE: ['Gender Male', '#sbGender > > > [aria-label="Male"]'],
            DOB: [
              'DOB',
              CommonUtils.concatenate(
                CoreCssClasses.Dialog.loc_dialog_box_content,
                ' #txtMaskDOB'
              ),
            ],
            RELATIONSHIP_TO_PATIENT: [
              'Relationship To Patient',
              '#txtPatientRelationship',
            ],
            PRIMARY_PHONE: [
              'Primary Phone',
              '#txtMaskPhoneNumber:nth-child(2)',
            ],
            ADDRESS1: ['Address1', '#txtAddress1'],
            ADDRESS2: ['Address2', '#txtAddress2'],
            CITY: ['City', '#txtCity'],
            STATE_DROPDOWN: [
              'State',
              CommonUtils.concatenate(
                CoreCssClasses.Dialog.loc_dialog_box_content,
                ' #stateDropdown'
              ),
            ],
            ZIP_CODE: [
              'Zip Code',
              CommonUtils.concatenate(
                '#zip_code_add_guarantor_model ',
                CommonGetLocators.input
              ),
            ],
            COUNTRY_DROPDOWN: [
              'Country',
              CommonUtils.concatenate(
                CoreCssClasses.Dialog.loc_dialog_box_content,
                ' #countryDropdown'
              ),
            ],
            DONE_BUTTON: [
              'Done',
              CommonUtils.concatenate(
                CoreCssClasses.Dialog.loc_dialog_box_content,
                ' ~ * #btnDone'
              ),
            ],
          },
          PRIMARY_GUARANTOR_FIRST_NAME: [
            'Primary Guarantor First Name',
            '#gdPrimaryGuarantor > > > > > > #firstName',
          ],
          SECONDARY_GUARANTOR: [
            'Secondary Guarantor',
            '#option ~ * #guarantorType',
          ],
          SECONDARY_GUARANTOR_FIELD: [
            'Secondary Guarantor Field',
            '#firstName',
          ],
          SECONDARY_GUARANTOR_STATE: [
            'Secondary Guarantor First Name',
            '#gdSecondaryGuarantor > > > > > > #stateDropdown',
          ],
          SECONDARY_GUARANTOR_OPTIONS: ['Option', '#option'],
        },
      },
      CROSS_ICON: ['.fa.fa-close.span-cross.pull-right.cursor-pointer'],
      LOSS_OF_DATA_WARNING_YES: [
        'Yes',
        '.p-confirm-dialog-accept> .p-button-label',
      ],
      LOSS_OF_DATA_WARNING_NO: [
        'No',
        '.p-confirm-dialog-reject> .p-button-label',
      ],
    },
    CHECK_IN: {
      FOOTER_BUTTONS: {
        PREVIOUS_BUTTON: ['Previous', '#btnPrevious'],
        DONE_BUTTON: ['Done', '#btnSaveData'],
        NEXT_BUTTON: ['Next', '#btnNextData'],
      },
      ADDITIONAL_CLAIM_INFO: [
        'Additional Claim Info Arrow',
        '#additionalClaimInfo i',
      ],
      ADDITIONAL_CLAIM_INFO_CHECK_MARK: [
        'Additional Claim Info Check mark',
        CommonUtils.concatenate(
          `#additionalClaimInfo `,
          CommonGetLocators.i,
          `[class*="check"]`
        ),
      ],
      ACCIDENT_DATE_CALENDAR: [
        'Accident Date Calendar',
        '#dateOfAccident button[class*="datepicker"]',
      ],
      PAYMENT: {
        PERIOD: ['Period', '#periodDropdown'],
        PERIOD_VERIFY: [
          'Period Verify',
          CommonUtils.concatenate(
            '#periodDropdown ',
            CoreCssClasses.DropDown.loc_p_dropdown,
            ':nth-child(1)'
          ),
        ],
        BATCH: ['Batch', '#batchDropdown'],
        BATCH_VERIFY: [
          'Batch Verify',
          CommonUtils.concatenate(
            '#batchDropdown ',
            CoreCssClasses.DropDown.loc_p_dropdown,
            ':nth-child(1)'
          ),
        ],
        AMOUNT_DUE: ['Amount Due', '#txtAmountDue'],
        AMOUNT_COLLECTED: ['Amount Collected', '#txtAmountCollected'],
        METHOD_OF_PAYMENT: ['Method of Payment', '#methodofPaymentDropdown'],
        TRANSACTION_CODE: ['Transaction Code', '#transactionCodeDropdown'],
        PRINT_RECEIPT: ['Print receipt', '#printBtn'],
        CLOSE: ['close', 'div[role="dialog"] button[class*="close"]'],
      },
      CHECK_IN: ['Check in', '#iconCheckIn'],
      PATIENT_LOCK_MESSAGE: [
        'Patient Lockmessage',
        CoreCssClasses.Text.loc_limittext_container,
      ],
      PATIENT_DETAILS: {
        PATIENT_DETAILS_TAB: ['Patient Details'],
        DOB: [
          'Date Of Birth',
          CommonUtils.concatenate('#txtMaskDOB > ', CommonGetLocators.input),
        ],
        DOB_TEXT: ['DOB Text', "[for='inputDOB']"],
      },
      FORMS_AND_CONSENTS: {
        FORMS_AND_CONSENTS_TAB: ['Forms & Consents'],
      },
      ATTACHMENTS: {
        ATTACHMENTS_TAB: ['Attachments'],
      },
      BILLING_AND_PAYMENTS: {
        BILLING_AND_PAYMENTS_TAB: ['Billing & Payment'],
      },
      PRIMARY_GUARANTOR: ['Primary Guarantor', '#primaryGuarantorDropdown'],
    },
    MSP_DROPDOWN: ['MSP Insurance Type Code', '#mspInsuranceTypeCode'],
    MSP_LABEL: ['MSP Insurance Label', 'sis-msp-insurance-type-code label'],
    SPINNER: ['Spinner', `div[class*='spinner']`],
  },
  L_CREATE_CASE: ['', 'sis-create-case .content-layout'],
  REQUEST_DETAILS: {
    ZIP_CODE: [
      'Zip Code',
      CommonUtils.concatenate(
        '[data-test-id="patient_zipcode"] ',
        CommonGetLocators.span
      ),
    ],
    CITY: [
      'City',
      CommonUtils.concatenate(
        '[data-test-id="patient_city"] ',
        CommonGetLocators.span
      ),
    ],
    COUNTY: [
      'County',
      CommonUtils.concatenate(
        '[data-test-id="patient_county"] ',
        CommonGetLocators.span
      ),
    ],
    STATE: ['State', `[data-test-id="patient_state"]`],
    EXCLAMATION: [
      'Exclamation Triangle',
      '[data-test-id*="iconExclamationTriangle"]',
    ],
    UPDATE: [
      'Update',
      CommonUtils.concatenate(
        '[data-test-id="btnUpdateRequest"] ',
        CommonGetLocators.span
      ),
    ],
  },
};
