import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_SCHEDULE_GRID = {
  SHOW_ALL_DROPDOWN: [
    'Show All',
    CommonUtils.concatenate(
      '#msItems ',
      CoreCssClasses.MultiSelect.loc_p_multiselect_label
    ),
  ],
  PHYSICIAN_FILTER: ['Physician', ''],
  ROOM_FILTER: [
    'Room',
    CommonUtils.concatenate(
      CoreCssClasses.Button.loc_button_label,
      ':contains("Room")'
    ),
  ],
  DATE_OF_SERVICE: ['Date Of Service', '#crDatePicker'],
  PATIENT_CASE_TILE: ['Patient Case Tile'],
  CASE_DETAILS_POPUP: {
    ARRIVAL_TIME: ['Arrived', '#btnArrivalTime'],
    POPUP_TITLE: ['Case Details'],
    ARRIVE_BUTTON: ['Arrive', `button[label="Arrive"]`],
    FACE_SHEET_ICON: [
      'Facesheet',
      '.icon-left-margin-minus.case-details-div label',
    ],
    CASE_POPUP: ['Case popup', '#case-details-popover'],
    CASE_DETAILS_LABEL: [
      'Case Details',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        '.case-details-div',
        CoreCssClasses.Ng.loc_star_inserted,
        ' .case-details-header'
      ),
    ],

    CHECK_IN_ICON: ['Check-In', '.list-icons > :nth-child(2) label'],
    EDIT_ICON: ['Edit', '.edit_case.case-details-div label'],
    CANCEL_ICON: ['Cancel', '#iconCancel'],
    REINSTATE_ICON: ['Reinstate', '.reinstate-icon'],
    CANCELLED_AT: ['Cancelled at', CoreCssClasses.Text.loc_arr_text],
    CANCEL_REASON: [
      'Cancel Reason',
      CommonUtils.concatenate(
        '.ng-star-inserted > :nth-child(1) > ',
        CoreCssClasses.Label.loc_data_label
      ),
    ],
    CANCEL_REASON_TEXT: [
      'Cancel reason text',
      CommonUtils.concatenate(
        '.ng-star-inserted > :nth-child(2) > ',
        CoreCssClasses.Text.loc_data_item
      ),
    ],
    PATIENT_NAME: ['Patient Name'],
    NICKNAME: ['Nick Name', '#alias'],
    MRN: ['MRN'],
    GENDER: ['Gender'],
    DATE_OF_BIRTH: ['Date Of Birth'],
    PHYSICIAN: ['Physician'],
    ANES_TYPE: ['Anes. Type'],
    PROCEDURE: ['Procedure'],
    START_TIME: ['Start Time'],
    DURATION: ['Duration'],
    LOCATION: ['Location'],
    DEPOSIT: ['Deposit'],
  },
  CANCEL_CASE_POPUP: {
    SELECT_REASON_DROPDOWN: [
      'Select Item',
      CommonUtils.concatenate(
        '#itemsDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        `:contains('Select Item')`
      ),
    ],
    SELECT_REASON_VALUE: ['Reason for Cancel Case', ''],
  },
  USER_SETTINGS_POPUP: {
    DEFAULT_VIEW: {
      SCHEDULE_BUTTON: ['Schedule'],
      TRACKER_BUTTON: ['Tracker'],
    },
    SHOW_CANCELLED_CASES: {
      YES_BUTTON: ['Yes', `#showCancellCase span:contains('Yes')`],
      NO_BUTTON: ['No', `#showCancellCase span:contains('No')`],
    },
  },
  PRINT_ICON: ['Print Icon', '#iconPrint'],
  LOADING_SPINNER: ['in progress'],
  PRINT_POPUP: {
    PATIENT_LABELS: ['Patient Labels', 'div[data-test-id="3_Patient Labels"]'],
    PREVIEW_BUTTON: ['Preview', '#rptChooserPreview'],
    SCHEDULE_GRID: ['Schedule Grid', `div[data-test-id="1_Schedule Grid"]`],
    SCHEDULE_GRID_POPUP: {
      PREVIEW: {
        VIEW: ['View'],
        GROUP_BY: ['Group By', `#groupBy span:visible`],
        SORT_BY: ['Sort By'],
        PROCEDURE_FORMAT: ['Procedure Format'],
        LAYOUT: {
          PORTRAIT: [
            'Portrait',
            `#layoutvaluesid div[aria-label^='Portrait'] span`,
          ],
          LANDSCAPE: [
            'Landscape',
            `#layoutvaluesid div[aria-label^='Landscape'] span`,
          ],
          SELECTED_PORTRAIT_BACKGROUND_COLOR: [
            'Portrait Background Color',
            `#layoutvaluesid div[aria-label^='Portrait']`,
          ],
          SELECTED_LANDSCAPE_BACKGROUND_COLOR: [
            'Landscape Background Color',
            `#layoutvaluesid div[aria-label^='Landscape']`,
          ],
        },
        PAGE_BREAK_YES_BUTTON: [
          'Page Break Yes Button',
          `#pageBreakToggleId div[aria-label^='Yes']`,
        ],
        PAGE_BREAK_NO_BUTTON: [
          'Page Break No Button',
          `#pageBreakToggleId div[aria-label^='No']`,
        ],

        REMOVE_PATIENT_INFO_YES_BUTTON: [
          'Remove Patient Info Yes Button',
          `#removePatientInfoToggleId div[aria-label^='Yes']`,
        ],
        REMOVE_PATIENT_INFO_NO_BUTTON: [
          'Remove Patient Info No Button',
          `#removePatientInfoToggleId div[aria-label^='No']`,
        ],
        INCLUDE_ESTIMATED_REVENUE: {
          YES_BUTTON: [
            'Yes',
            `#includeEstimatedRevenueToggleId div[aria-label^='Yes']`,
          ],
          NO_BUTTON: [
            'No',
            `#includeEstimatedRevenueToggleId div[aria-label^='No']`,
          ],
        },
        REFRESH_BUTTON: ['Refresh', '#btnRefresh'],
        PRINT: ['Print', `button[label='Print'] span`],
        CLOSE_ICON: ['Close X mark', CoreCssClasses.Button.loc_close_icon],
      },
    },
    PATIENT_DEMOGRAPHICS_FORM: [
      'Patient Demographics Form',
      `div[data-test-id="2_Patient Demographics Form"]`,
    ],
    PATIENT_LABELS_POPUP: {
      LABEL_PATIENT_INPUT: [
        '# of label/patient',
        `[name^='labelsPerPatient'] input`,
      ],
      BEGIN_ROW: ['Begin Row', `[name^='beginRow'] input`],
      BEGIN_COLUMN: ['Begin Column', `[name^='beginColumn'] input`],
      ONE_PATIENT_PER_PAGE: ['One Patient Per Page', '#onePatientPerPage'],
      ONE_PATIENT_PER_PAGE_YES_BTN: ['One Patient Per Page Yes Button', 'Yes'],
      ONE_PATIENT_PER_PAGE_NO_BTN: ['One Patient Per Page No Button', 'No'],
      PATIENT_LABEL_BLOCK: ['Patient Block', `[id^='LabelBlock']`],
      CLOSE_ICON: ['Close X mark', CoreCssClasses.Button.loc_close_icon],
    },
  },
  GLOBAL_SEARCH: {
    SEARCH: [
      'Global Search',
      `input[placeholder = 'Search by Name, MRN, or DOB']`,
    ],
    SEARCH_RESULTS: ['Search Results', 'div.patient-search-result-name span'],
  },
  SCHEDULE_TIME: ['Schedule Time'],
};
