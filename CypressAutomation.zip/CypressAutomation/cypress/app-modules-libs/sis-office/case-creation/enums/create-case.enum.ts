/* enum values */
export enum CreateCaseOptions {
    PatientConditionDueTo = 'PatientConditionDueTo',
    AccidentDate = 'AccidentDate',
    AccidentState = 'AccidentState',
    FirstName = 'FirstName',
    LastName = 'LastName',
    DOB = 'DOB',
    Gender = 'Gender',
    RelationshipToPatient = 'RelationshipToPatient',
    PrimaryPhone = 'PrimaryPhone',
    Address1 = 'Address1',
    Address2 = 'Address2',
    City = 'City',
    State = 'State',
    ZipCode = 'ZipCode',
    AddNewGuarantor = 'Add New Guarantor',
    String = 'string',
    Self = 'Self',
    Male = 'Male',
    Female = 'Female',
    PREFERENCE_CARD_TEXT = 'Click Add to add a preference card.',
    Search_Procedure = 'Search Procedure',
    Search_Items = 'Search Item(s)',
    Country = 'Country',
  }
  
  export enum PrimaryGuarantorCheckIn {
    PrimaryGuarantor = 'Primary Guarantor In CheckIn',
  }
  