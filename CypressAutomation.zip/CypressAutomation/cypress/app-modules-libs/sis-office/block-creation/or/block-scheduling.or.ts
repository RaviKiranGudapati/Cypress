import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_BLOCK_CREATION = {
  CREATE_A_BLOCK: {
    CREATE_A_BLOCK_TAB: ['create a block table', 'a#CreateBlock'],
    BLOCK_NAME_LABEL: [
      'Block name label',
      CommonUtils.concatenate(
        ':nth-child(1) > :nth-child(1) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    BLOCK_NAME: ['create a block table', '#blockName'],
    PHYSICIAN_NAME_LABEL: [
      'Physician name label',
      CommonUtils.concatenate(
        ':nth-child(1) > :nth-child(2) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    PHYSICIAN: ['Physician dropdown', '#block_schedule_physician_dictionary'],
    PHYSICIAN_NAME: [
      'Physician Name',
      CommonUtils.concatenate(
        ':nth-child(4) > ',
        CoreCssClasses.MultiSelect.loc_ui_multiselect_item,
        ' > .dropdown-item > div.',
        CoreCssClasses.Ng.loc_star_inserted,
        ' > sis-custom-tooltip > .limittext-holder > .limittext-container'
      ),
    ],
    PHYSICIAN_D: [
      'Arrow',
      CommonUtils.concatenate(
        '#staffMultiSelect > .dropdown-width > #msItems > ',
        CoreCssClasses.MultiSelect.loc_p_multiselect,
        ' > ',
        CoreCssClasses.MultiSelect.loc_p_multiselect,
        '-trigger > ',
        CoreCssClasses.MultiSelect.loc_p_multiselect,
        '-trigger-icon'
      ),
    ],
    DATE_LABEL: [
      'Date label',
      CommonUtils.concatenate(
        ':nth-child(2) > :nth-child(1) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    DATE: ['Date', '#blockDateCalendar input'],
    ROOM_LABEL: [
      'Room label',
      CommonUtils.concatenate(
        ':nth-child(2) > :nth-child(2) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    ROOM: [
      'Room dropdown',
      CommonUtils.concatenate(
        '#blockRooms > .dropdown-width > #msItems > ',
        CoreCssClasses.MultiSelect.loc_p_multiselect,
        ' > ',
        CoreCssClasses.MultiSelect.loc_p_multiselect_label_container,
        ' > ',
        CoreCssClasses.MultiSelect.loc_p_multiselect_label
      ),
    ],
    START_TIME_LABEL: [
      'Start time label',
      CommonUtils.concatenate(
        ':nth-child(3) > :nth-child(1) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    START_TIME: ['Start Time', '#txtMaskStartTime input'],
    END_TIME_LABEL: [
      'End time label',
      CommonUtils.concatenate(
        ':nth-child(3) > :nth-child(2) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    END_TIME: ['End Time', '#txtMaskEndTime input'],
    LESS_END_TIME: [
      'less end time',
      CommonUtils.concatenate(
        CoreCssClasses.Text.loc_warning_text,
        CoreCssClasses.Ng.loc_star_inserted,
        ' > ',
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    SPECIALTY_LABEL: [
      'Specialty label',
      CommonUtils.concatenate(
        ':nth-child(4) > :nth-child(1) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    SPECIALTY: [
      'Specialty',
      CommonUtils.concatenate(
        '#blockSpecialities > .primeNG-single-select > .ng-valid > ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        ' > ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        '-trigger > ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        '-trigger-icon'
      ),
    ],
    BLOCK_OUT: ['Yes', 'No', '#sbtnBlockOut'],
    DONE_BUTTON: [
      'Done',
      CommonUtils.concatenate(
        '#btnDone > ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],
    NEW_BLOCK_INSTANCE: ['New Block Instance', '*.section-padding'],
    NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON: {
      New_BLOCK: [
        'New Block',
        CommonUtils.concatenate(
          '.ng-valid > ',
          CoreCssClasses.Button.loc_select_button,
          ' > [aria-pressed="false"] > ',
          CoreCssClasses.Button.loc_select_button
        ),
      ],
      EXISTING_BLOCK: [
        'Existing Block',
        CommonUtils.concatenate(
          '#sbtnNewBlockTab > .ng-untouched > ',
          CoreCssClasses.Button.loc_select_button,
          ' > [aria-pressed="false"] > ',
          CoreCssClasses.Button.loc_select_button
        ),
      ],
    },
  },
};
