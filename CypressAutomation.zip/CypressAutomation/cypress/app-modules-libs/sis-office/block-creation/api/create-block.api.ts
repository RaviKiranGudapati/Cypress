import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class CreateBlockApis {
  /**
   * @details - Click on block schedule tab
   */
  interceptCreateBlockScheduleApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_packs,
        'GetCasePacks',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_color_themes,
        'GetAllColorThemes',
        200
      ),
    ];
  }

  /**
   * @details - Api collection to select block in block Schedule
   * @author - Spoorthy
   */
  interceptSelectBlockApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_packs,
        'GetCasePacks',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_color_themes,
        'GetAllColorThemes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_block_conflicts,
        'BlockConflicts',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Done button in block schedule create block
   * @author - Spoorthy
   */
  interceptDoneBlockApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.save_block_Instance,
        'BlockInstance',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.block_schedule_get,
        'BlockConflicts',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for loss of data pop up in  block Schedule
   * @author - Spoorthy
   */
  interceptLossOfDataApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_packs,
        'GetCasePacks',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_color_themes,
        'GetAllColorThemes',
        200
      ),
    ];
  }

  interceptExistingBlockToggle(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_block_schedule_configs,
        'GetBlockSchedule',
        200
      ),
    ];
  }
}
