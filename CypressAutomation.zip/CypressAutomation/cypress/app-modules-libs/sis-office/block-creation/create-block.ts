import { Application } from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';

import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import { OR_BLOCK_CREATION } from '../../../app-modules-libs/sis-office/block-creation/or/create-block.or';

import { CreateBlockApis } from './api/create-block.api';

export default class blockSchedule {
  private orCreateBlock = OR_BLOCK_CREATION;
  private createBlockApiCollection = new CreateBlockApis();

  /**
   * @details - Enter value in text fields
   * @param locLogicalName - selector for identify input
   * @param value - block value 
   * @API - API's are not available
   */
  blockScheduleText(locLogicalName: string, value: any) {
    let locator: string = '';

    switch (locLogicalName) {
      case this.orCreateBlock.CREATE_A_BLOCK.BLOCK_NAME[0]:
        locator = this.orCreateBlock.CREATE_A_BLOCK.BLOCK_NAME[1];
        break;
      case this.orCreateBlock.CREATE_A_BLOCK.DATE[0]:
        locator = this.orCreateBlock.CREATE_A_BLOCK.DATE[1];
        break;
      case this.orCreateBlock.CREATE_A_BLOCK.START_TIME[0]:
        locator = this.orCreateBlock.CREATE_A_BLOCK.START_TIME[1];
        break;
      case this.orCreateBlock.CREATE_A_BLOCK.END_TIME[0]:
        locator = this.orCreateBlock.CREATE_A_BLOCK.END_TIME[1];
        break;
      default:
        break;
    }
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.BLOCK_NAME_LABEL[1],
      this.orCreateBlock.CREATE_A_BLOCK.BLOCK_NAME_LABEL[0]
    );

    cy.cType(locator, locLogicalName, value);
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.ROOM_LABEL[1],
      this.orCreateBlock.CREATE_A_BLOCK.ROOM_LABEL[0]
    );
  }

  /**
   * @details - click On Block Schedule Tab
   * @API - API's are available Implemented completely
   * @Author -Spoorthy
   */
  openBlockScheduleTab() {
    const interceptCollection =
      this.createBlockApiCollection.interceptCreateBlockScheduleApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.CREATE_A_BLOCK_TAB[1],
      this.orCreateBlock.CREATE_A_BLOCK.CREATE_A_BLOCK_TAB[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details -  To collapse create block tab
   * @API - API's are not  available
   */
  collapseBlockScheduleTab() {
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.CREATE_A_BLOCK_TAB[1],
      this.orCreateBlock.CREATE_A_BLOCK.CREATE_A_BLOCK_TAB[0]
    );
  }

  /**
   * @details - click On DoneButton
   * @API - API's are available Implemented completely
   * @Author - Spoorthy
   */
  clickOnDoneButton() {
    const interceptCollection =
      this.createBlockApiCollection.interceptDoneBlockApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.DONE_BUTTON[1],
      this.orCreateBlock.CREATE_A_BLOCK.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click On Block Schedule Tab
   * @API - API's are available - Implemented Completely
   */
  clickOnBlockScheduleTab() {
    const interceptCollection =
      this.createBlockApiCollection.interceptCreateBlockScheduleApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.CREATE_A_BLOCK_TAB[1],
      this.orCreateBlock.CREATE_A_BLOCK.CREATE_A_BLOCK_TAB[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select block from block schedule grid
   * @param logicalName - selector for block
   * @pram valueToSelect - value of the select block
   * @API - API's are available Implemented completely
   * @Author - Spoorthy
   */
  selectBlock(logicalName: string, valueToSelect: string) {
    const interceptCollection =
      this.createBlockApiCollection.interceptSelectBlockApi();
    cy.cIntercept(interceptCollection);
    let Value = selectorFactory.patientCaseTileInScheduleGrid(valueToSelect);
    cy.cClick(Value, logicalName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select Existing block and verify error message
   * @API - API's are not available
   */
  selectExistingBlockToggleButton(apiFlag: boolean = false) {
    if (apiFlag) {
      cy.cClick(
        this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
          .EXISTING_BLOCK[1],
        this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
          .EXISTING_BLOCK[0]
      );
    } else {
      const interceptCollection =
        this.createBlockApiCollection.interceptExistingBlockToggle();
      cy.cIntercept(interceptCollection);
      cy.cClick(
        this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
          .EXISTING_BLOCK[1],
        this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
          .EXISTING_BLOCK[0]
      );
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - Select Existing block
   * @API - API's are not available
   */
  selectNewBlockToggleButton() {
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
        .NEW_BLOCK[1],
      this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
        .NEW_BLOCK[0]
    );
  }

  /**
   * @details - Verify block name mandatory fields error messages
   * @API - API's are not available
   * Method need to be modified as using selectNewBlockToggleButton method
   */
  verifyBlockNameMandatoryErrorMessage() {
    cy.cClick(
      this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
        .NEW_BLOCK[1],
      this.orCreateBlock.CREATE_A_BLOCK.NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON
        .NEW_BLOCK[0]
    );
    cy.cIsVisible(
      selectorFactory.getSmallText(AppErrorMessages.required_block_name),
      AppErrorMessages.required_block_name
    );
  }

  /**
   * @details - Select Existing block and verify error message
   * @API - API's are not available
   */
  selectExistingBlockAndVerifyMessage() {
    this.selectExistingBlockToggleButton();
    cy.cIsVisible(
      selectorFactory.getSmallText(AppErrorMessages.existing_block_name_error),
      AppErrorMessages.existing_block_name_error
    );
  }

  /**
   * @details - Select  all dropdowns values in create block page
   * @param dropdown - selector of the drop down
   * @param valueToSelect - value for selection of the drop down
   * @API - API's are not available
   */
  selectDropdownValue(dropdown: string, valueToSelect: string) {
    let dropdownSelector: string = '';
    let value = selectorFactory.getDropdownValues(valueToSelect);
    let dropdownLogicalName: string = '';
    switch (dropdown) {
      case this.orCreateBlock.CREATE_A_BLOCK.PHYSICIAN[0]:
        dropdownSelector = this.orCreateBlock.CREATE_A_BLOCK.PHYSICIAN[1];
        dropdownLogicalName = this.orCreateBlock.CREATE_A_BLOCK.PHYSICIAN[0];
        break;
      case this.orCreateBlock.CREATE_A_BLOCK.ROOM[0]:
        dropdownSelector = this.orCreateBlock.CREATE_A_BLOCK.ROOM[1];
        dropdownLogicalName = this.orCreateBlock.CREATE_A_BLOCK.ROOM[0];
        break;
      case this.orCreateBlock.CREATE_A_BLOCK.SPECIALTY[0]:
        dropdownSelector = this.orCreateBlock.CREATE_A_BLOCK.SPECIALTY[1];
        dropdownLogicalName = this.orCreateBlock.CREATE_A_BLOCK.SPECIALTY[0];
        break;
      case this.orCreateBlock.CREATE_A_BLOCK.BLOCK_NAME[0]:
        dropdownSelector = this.orCreateBlock.CREATE_A_BLOCK.BLOCK_NAME[1];
        dropdownLogicalName = this.orCreateBlock.CREATE_A_BLOCK.BLOCK_NAME[0];
        break;
      default:
        break;
    }
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, dropdownLogicalName);
    cy.cClick(value, value);
  }

  /**
   * @details - Select multiple rooms in dropdown
   * @param  value - room names array
   * @API - API's are not available
   */
  selectMultiSelectRoom(value: string[]) {
    const dropDownValue = CoreCssClasses.DropDown.loc_dropdown_item_multiselect;
    const dropDown = this.orCreateBlock.CREATE_A_BLOCK.ROOM[1];
    cy.cClick(dropDown, this.orCreateBlock.CREATE_A_BLOCK.ROOM[0]);
    value.forEach((val: string) => {
      cy.cGet(dropDownValue).contains(val).click({
        force: true,
      });
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropDown, this.orCreateBlock.CREATE_A_BLOCK.ROOM[0]);
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME_LABEL[1],
      OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME_LABEL[0]
    );
  }

  /**
   * @details verifyBlockOutYesOrNo- method verify the the block out toggle button set to yes or no
   * @param  flag - true/false for verify block out
   * @API - API's are not available
   */
  verifyBlockOutYesOrNo(flag: boolean = true) {
    if (flag) {
      cy.cIsVisible(
        OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_OUT[1],
        OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_OUT[0]
      );
    } else {
      cy.cNotExist(
        OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_OUT[1],
        OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_OUT[0]
      );
    }
  }

  /**
   * @details - Select block name drop down
   * @param  blockName - block value
   * @API - API's are not available
   */
  selectBlockNameDropdown(blockName: string) {
    cy.cSelectDropdown(
      OR_BLOCK_CREATION.CREATE_A_BLOCK.EXISTING_BLOCK_NAME_DROPDOWN[1],
      OR_BLOCK_CREATION.CREATE_A_BLOCK.EXISTING_BLOCK_NAME_DROPDOWN[0],
      blockName
    );
  }

  /**
   * @details - Select yes or no button to loss data
   * @param  flag - select yes if flag true, select no if flag false
   * @API - API's are available- Implemented
   * @Author - Spoorthy
   */
  selectYesOrNoButton(flag: boolean = true) {
    if (flag) {
      const interceptCollection =
        this.createBlockApiCollection.interceptLossOfDataApi();
      cy.cIntercept(interceptCollection);
      cy.cClick(
        OR_BLOCK_CREATION.CREATE_A_BLOCK.LOSS_OF_DATA[1],
        OR_BLOCK_CREATION.CREATE_A_BLOCK.LOSS_OF_DATA[0]
      );
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cClick(
        OR_BLOCK_CREATION.CREATE_A_BLOCK.NO_LOSS_OF_DATA[1],
        OR_BLOCK_CREATION.CREATE_A_BLOCK.NO_LOSS_OF_DATA[0]
      );
    }
  }
}
