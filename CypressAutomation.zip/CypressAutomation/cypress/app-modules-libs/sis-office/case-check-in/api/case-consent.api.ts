import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export class CaseConsentApis {
  /**
   * @details - Api collection after clicking on add consents
   * @author - vamshi
   */
  interceptAddConsentsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.consent_configuration_specialty_names,
        'ConsentConfigurationSpecialtyNames',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.consent_configuration_names,
        'ConsentConfigurationNames',
        200
      ),
    ];
  }

  /**
   * @details - api collection for click on next button in forms and consent in check-in
   * @author -Arushi
   */
  interceptFormsAndConsentApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.all_attachment,
        'GetAttachment',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after clicking next in attachments tab
   * @author -Arushi
   */
  interceptAttachmentTabApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.insurance,
        'GetInsurance',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
    ];
  }

  /**
   * @details - Api for clicking on done button in the consent in the nursing department
   * @author - vamshi
   */
  interceptSaveConsentNursingApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_consent_clinical,
        'ConsentClinical',
        200
      ),
    ];
  }

  /**
   * @details - Api for clicking on sign button for physician in the consent
   * @author - vamshi
   */
  interceptSignPhysicianApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.consent_get_user,
        'ConsentGetUser',
        200
      ),
    ];
  }

  /**
   * @details - Api for clicking on sign button for other user in the consent
   * @author - vamshi
   */
  interceptSignOtherUserApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.consent_validate,
        'ConsentValidate',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.consent_get_user,
        'ConsentGetUser',
        200
      ),
    ];
  }

  /**
   * @details - Api for clicking the consent in the list in check-in
   * @author - vamshi
   */
  interceptClickConsentApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_record,
        'PatientRecord',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_consent_clinical,
        'ConsentClinical',
        200
      ),
    ];
  }

  /**
   * @details - Api for close consent API
   * @author - vamshi
   */
  interceptCloseConsentWindowApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.release_lock,
        'ReleaseLock',
        200
      ),
    ];
  }

  /**
   * @details - Api for clicking on the Add consents
   * @author - vamshi
   */
  interceptAddConsentApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_consent_clinical,
        'ConsentClinical',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_consent_summary,
        'ConsentSummary',
        200
      ),
    ];
  }
}
