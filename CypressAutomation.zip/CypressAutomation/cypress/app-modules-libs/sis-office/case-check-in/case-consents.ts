import CommonCore, {
  CommonGetLocators,
  InvokeMethods,
  ShouldMethods,
  TrueOrFalse,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import { UserList } from '../../../fixtures/shared/user-list.td';

import { Consents } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_PATIENT_CASE_CREATION } from '../case-creation/or/create-case.or';
import { OR_PATIENT_CASE_CHECK_IN } from './or/patient-check-in.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { CaseConsentApis } from './api/case-consent.api';
import { CaseConsentsHeader } from './enums/case-consents.enum';

/* constant variables */
const sisOfficeDesktop = new SISOfficeDesktop();

/**
 * Class for CaseConsents
 */

export default class CaseConsents extends CommonCore {
  private caseConsentApi = new CaseConsentApis();

  // #region sc260007 Case Consents

  /**
   * @details - Click on next button after patient check in to navigate to forms & consents
   */
  checkInNext() {
    cy.cClick(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.FOOTER_BUTTONS
        .NEXT_BUTTON[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.FOOTER_BUTTONS
        .NEXT_BUTTON[0]
    );
  }

  /**
   * @details - Click on previous button after patient check in
   * @API - API's are not available
   * @author -Arushi
   */
  checkInPrevious() {
    cy.cClick(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.FOOTER_BUTTONS
        .PREVIOUS_BUTTON[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.FOOTER_BUTTONS
        .PREVIOUS_BUTTON[0]
    );
  }

  signCaseConsent(Index: number) {
    cy.cGet(OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_CONSENT_BLOCK[1])
      .eq(Index)
      .then(($element) => {
        cy.wrap($element).then(() => {
          this.consentPhysicianDetails(CaseConsentsHeader.sign);
          this.verifyUnsignButton();
        });
      });
  }

  /**
   * @details - After editing the consents click on save done button
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   */
  saveConsents() {
    const interceptCollection =
      this.caseConsentApi.interceptSaveConsentNursingApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.SAVE_DONE[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.SAVE_DONE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify Physician details for consent sign
   * @param option
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   */
  consentPhysicianDetails(option: CaseConsentsHeader) {
    switch (option) {
      case CaseConsentsHeader.sign:
        const interceptCollection =
          this.caseConsentApi.interceptSignPhysicianApi();
        cy.cIntercept(interceptCollection);
        cy.cGet(
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PHYSICIAN_SIGN[1]
        ).scrollIntoView();
        cy.cClick(
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PHYSICIAN_SIGN[1],
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PHYSICIAN_SIGN[0],
          false,
          true
        );
        cy.cWaitApis(interceptCollection);
        break;

      case CaseConsentsHeader.addendum_sign:
        cy.cGet(
          OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_PHYSICIAN_SIGN[1]
        ).scrollIntoView();
        cy.cClick(
          OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_PHYSICIAN_SIGN[1],
          OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_PHYSICIAN_SIGN[0],
          false,
          true
        );
        break;

      case CaseConsentsHeader.other_user:
        cy.cGet(
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.OTHER_USER_BUTTON[1]
        ).scrollIntoView();
        cy.cClick(
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.OTHER_USER_BUTTON[1],
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.OTHER_USER_BUTTON[0],
          false,
          true
        );
        this.physicianOtherUser();
        break;

      case CaseConsentsHeader.addendum_other_user:
        cy.cGet(
          OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM
            .ADDENDUM_PHYSICIAN_OTHER_USER_BUTTON[1]
        ).scrollIntoView();
        cy.cClick(
          OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM
            .ADDENDUM_PHYSICIAN_OTHER_USER_BUTTON[1],
          OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM
            .ADDENDUM_PHYSICIAN_OTHER_USER_BUTTON[0],
          false,
          true
        );
        this.physicianOtherUser();
        break;
      default:
        break;
    }
  }

  /**
   * @details - After editing consents select other physician user to sign consent
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   */
  physicianOtherUser() {
    const interceptCollection = this.caseConsentApi.interceptSignOtherUserApi();
    cy.cIsVisible(
      selectorFactory.getH3Text(
        OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGNATURE_LABEL[0]
      ),
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGNATURE_LABEL[0]
    );
    cy.cIsVisible(
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGN_BUTTON[1],
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGN_BUTTON[0]
    );
    cy.cIsVisible(
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGNATURE_CROSS[1],
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGNATURE_CROSS[0]
    );
    cy.cType(
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.OTHER_USER_NAME[1],
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.OTHER_USER_NAME[0],
      UserList.GEM_USER_3[0]
    );
    cy.cIsEnabled(
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGN_BUTTON[1],
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGN_BUTTON[0],
      false,
      false
    );
    cy.cType(
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP
        .OTHER_USER_PASSWORD[1],
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP
        .OTHER_USER_PASSWORD[0],
      UserList.GEM_USER_3[1]
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGN_BUTTON[1],
      OR_PATIENT_CASE_CHECK_IN.OTHER_USER_SIGNATURE_POPUP.SIGN_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - After editing consent click on close the window
   * @API - API's are not available
   */
  closeConsentWindow() {
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.CLOSE_ICON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.CLOSE_ICON[0],
      false,
      false,
      { force: true }
    );
  }

  /**
   * @details - Click on yes or no option for confirmation message
   * @param - yesNoOption
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   */
  closeConsentWindowConfirm(yesNoOption: string) {
    const interceptCollection =
      this.caseConsentApi.interceptCloseConsentWindowApi();
    let selectorOption = '';
    let selectorLogicalName = '';
    switch (yesNoOption) {
      case YesOrNo.yes:
        selectorOption = OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.YES_BUTTON[1];
        selectorLogicalName =
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.YES_BUTTON[0];
        break;
      case YesOrNo.no:
        selectorOption = OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.NO_BUTTON[1];
        selectorLogicalName =
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.NO_BUTTON[0];
        break;
      default:
        break;
    }
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorOption, selectorLogicalName, false, true);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verify warning message when consent window close button is clicked
   * @API - API's are not available
   */
  verifyWarningMessage() {
    cy.cHasText(
      selectorFactory.getSpanText(AppErrorMessages.consent_warning_title),
      selectorFactory.getSpanText(AppErrorMessages.consent_warning_title),
      AppErrorMessages.consent_warning_title
    );
    cy.cHasText(
      selectorFactory.getSpanText(AppErrorMessages.consent_warning_message),
      selectorFactory.getSpanText(AppErrorMessages.consent_warning_message),
      AppErrorMessages.consent_warning_message
    );
  }

  /**
   * @details - Search and select the consent in search window
   * @param - consentsModel
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   **/
  selectConsentInPatientCase(consentName: string) {
    let consentNameLocator =
      CaseConsentsHeader.li + ' ' + selectorFactory.getSpanText(consentName);
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (body.find(selectorFactory.getSpanText(consentName)).length > 0) {
        this.clickConsentNameInList(consentName);
      } else {
        this.clickOnAddConsents();
        cy.cClick(
          selectorFactory.getSpanText(CaseConsentsHeader.all),
          CaseConsentsHeader.all
        );

        cy.cType(
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.SEARCH_BOX[1],
          OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.SEARCH_BOX[0],
          consentName
        );

        cy.cClick(consentNameLocator, consentName);

        cy.cClick(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
        );

        this.clickConsentNameInList(consentName);
      }
    });
  }

  /**
   * @details - Select the consent from list to edit
   * @param - consentName
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   **/
  clickConsentNameInList(consentName: string) {
    const interceptCollection = this.caseConsentApi.interceptClickConsentApi();
    cy.cIsVisible(
      selectorFactory.getSpanText(consentName),
      consentName,
      false,
      true
    ).then(() => {
      cy.cIntercept(interceptCollection);
      cy.cClick(
        selectorFactory.getSpanText(consentName),
        consentName,
        false,
        false,
        { force: true }
      );
      cy.cWaitApis(interceptCollection);
    });
  }

  /**
   * @details - Verify Print & Delete Icons on selected consent row
   * @param - consentName
   * @API - API's are not available
   **/
  verifyPrintDeleteIcon(consentName: string) {
    cy.cGet(OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.CONSENT_ROW[1]).each(
      ($element) => {
        if ($element.text().indexOf(consentName) > -1) {
          cy.wrap($element).within(() => {
            cy.cGet(OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PRINT_ICON[1])
              .invoke(InvokeMethods.show)
              .should(ShouldMethods.visible);
            cy.cGet(OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.TRASH_ICON[1])
              .invoke(InvokeMethods.show)
              .should(ShouldMethods.visible);
          });
          return false;
        }
      }
    );
  }

  /**
   * @details - Enter the text to edit the consent
   * @param - value
   * @Param - templateIndex -starts with 0, 1 ...
   * @API - API's are not available
   */
  enterEditConsentText(value: string, templateIndex: number) {
    cy.cGet(OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_CONSENT_BLOCK[1])
      .eq(templateIndex)
      .then(($element) => {
        cy.wrap($element).within(() => {
          cy.cGet(
            OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_CONSENT[1]
          ).click();
          cy.switchToIframe(
            OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS
              .EDIT_CONSENT_TEXT_BOX_IFRAME[1]
          ).type(value, { force: true });
        });
      });
  }

  /**
   * @details - Verify Unsign Button in edit consent
   * @API - API's are not available
   */
  verifyUnsignButton() {
    cy.cIsVisible(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_UNSIGN[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_UNSIGN[0],
      false,
      true
    );
  }

  /**
   * @details - Click on add Addendum link to add new addendum
   * @param consentName,consentDescription
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   */
  addAddendum(
    consentDescription: string,
    consentName: string,
    signOption: CaseConsentsHeader
  ) {
    const interceptSignPhysicianApiCollection =
      this.caseConsentApi.interceptSignPhysicianApi();
    let addendumText = consentName + consentDescription;
    this.clickConsentNameInList(consentName);
    cy.switchToIframe(
      OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.CKEDITOR_ADDENDUM[1]
    ).should(
      ShouldMethods.attribute,
      CaseConsentsHeader.content_editable,
      TrueOrFalse.false
    );
    cy.cIsVisible(
      selectorFactory.getSpanText(
        OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_CONSENT[0]
      ),
      OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_CONSENT[0]
    );
    cy.shouldBeEnabled(
      selectorFactory.getSpanText(
        OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_CONSENT[0]
      )
    );
    cy.cIntercept(interceptSignPhysicianApiCollection);
    cy.cClick(
      selectorFactory.getSpanText(
        OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_CONSENT[0]
      ),
      OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.ADDENDUM_CONSENT[0],
      false,
      true
    );
    cy.cWaitApis(interceptSignPhysicianApiCollection);
    cy.switchToIframe(
      OR_PATIENT_CASE_CHECK_IN.ADD_ADDENDUM.CKEDITOR_ADDENDUM[1]
    ).type(addendumText, { force: true });
    this.consentPhysicianDetails(signOption);
    cy.cClick(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_UNSIGN[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_UNSIGN[0]
    );
    this.closeConsentWindow();
    this.verifyWarningMessage();
    this.closeConsentWindowConfirm(YesOrNo.no);
    //removed unnecessary code to re-open the consent popup again
    this.consentPhysicianDetails(signOption);
    cy.cIsVisible(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_UNSIGN[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_UNSIGN[0],
      false,
      true
    );
    const interceptSaveConsentNursingApiCollection =
      this.caseConsentApi.interceptSaveConsentNursingApi();
    cy.cIntercept(interceptSaveConsentNursingApiCollection);
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptSaveConsentNursingApiCollection);
  }

  /**
   * @details - Click on Performing Physician Dropdown and select Physicians and close dropdown in consents
   * @param consent - using PerformingPhysician from Consents Model
   * @API - API's are not available
   */
  selectPerformingPhysicians(consent: Consents) {
    sisOfficeDesktop.selectValueFromDropdown(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PERFORMING_PHYSICIAN[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PERFORMING_PHYSICIAN[0],
      CoreCssClasses.MultiSelect.loc_li_p_multiselect_item,
      consent.PerformingPhysician!,
      true
    );
  }

  /**
   * @details - Verify selected Performing Physician Dropdown in consents
   * @param consent - using PerformingPhysician from Consents Model
   * @API - API's are not available
   */
  verifyPerformingPhysicians(consent: Consents) {
    consent.PerformingPhysician!.forEach((val: string) => {
      cy.cIsVisible(selectorFactory.getLiText(val), val);
    });
  }

  /**
   * @details - Verify Procedures in consents
   * @param procedureValue - procedures values to check in consents
   * @API - API's are not available
   */
  verifyProcedures(procedureValue: string) {
    cy.cGet(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PROCEDURES_TEXT_AREA[1]
    ).should(ShouldMethods.value, procedureValue);
  }

  /**
   * @details - Verify Procedures in consents
   * @API - API's are not available
   */
  verifyEditConsent() {
    cy.shouldBeEnabled(OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_CONSENT[1]);
  }

  /**
   * @details - click Performing  Physician Clear Icon in edit consents
   * @API - API's are not available
   */
  clearPerformingPhysicians() {
    cy.cClick(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS
        .PERFORMING_PHYSICIAN_CLEAR_ICON[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.PERFORMING_PHYSICIAN_CLEAR_ICON[0]
    );
  }

  /**
   * @details click on add consents
   * @API - API's are available - Implemented Completely
   * @author - vamshi
   */
  clickOnAddConsents() {
    const interceptCollection = this.caseConsentApi.interceptAddConsentsApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.ADD_CONSENTS[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.ADD_CONSENTS[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click next button in the patient details page of check-in tab
   * @API - API's are not available
   * @author -Arushi
   */
  clickNextInPatientDetailsCheckIn() {
    //no api calls on navigating from patient details to forms and consents
    this.checkInNext();
  }

  /**
   * @details - click next button in the forms and consents tab of check-in tab
   * @API - API's are available - Implemented Completely
   * @author -Arushi
   */
  clickNextInFormsAndConsentsCheckIn() {
    const interceptCollection =
      this.caseConsentApi.interceptFormsAndConsentApis();
    cy.cIntercept(interceptCollection);
    this.checkInNext();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click next button in the attachment tab of check-in tab
   *  @API - API's are available - Implemented Completely
   * @author -Arushi
   */
  clickNextInAttachmentsCheckIn() {
    const interceptCollection = this.caseConsentApi.interceptAttachmentTabApi();
    cy.cIntercept(interceptCollection);
    this.checkInNext();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click previous button in the billing and payment tab of check-in tab
   *  @API - API's are available - Implemented Completely
   * @author -Arushi
   */
  clickPreviousInBillingAndPaymentCheckIn() {
    const interceptCollection =
      this.caseConsentApi.interceptFormsAndConsentApis();
    cy.cIntercept(interceptCollection);
    this.checkInPrevious();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click previous button in the attachments tab of check-in tab
   * @API - API's are not available
   * @author -Arushi
   */
  clickPreviousInAttachmentsCheckIn() {
    //no api calls on navigating from attachments tab to forms and consents
    this.checkInPrevious();
  }

  /**
   * @details - click previous button in the forms and consents tab of check-in tab
   * @API - API's are not available
   * @author -Arushi
   */
  clickPreviousInFormsAndConsentsCheckIn() {
    //no api calls on navigating from forms and consents to patient details
    this.checkInPrevious();
  }

  /**
   * @details - Verify documents and disclosure acknowledged panel
   * @param exist - to verify existence of panel with boolean condition true or false
   * @API - API's are not available
   * @author - Divya
   */
  verifyDocumentsAcknowledgementPanel(exist: boolean = true) {
    if (exist) {
      cy.cGet(
        OR_PATIENT_CASE_CHECK_IN.CASE_CONSENTS.DOCUMENTS_ACKNOWLEDGED
          .STICKY_PANEL[1]
      )
        .eq(0)
        .find(
          OR_PATIENT_CASE_CHECK_IN.CASE_CONSENTS.DOCUMENTS_ACKNOWLEDGED
            .HEADER_ROW[1]
        )
        .should(ShouldMethods.visible);
    } else {
      cy.cNotExist(
        OR_PATIENT_CASE_CHECK_IN.CASE_CONSENTS.DOCUMENTS_ACKNOWLEDGED
          .STICKY_PANEL[1],
        ''
      );
    }
  }

  /**
   * @details - Verify documents in the panel
   * @param name - to verify name in the documents panel
   * @API - API's are not available
   * @author - Divya
   */
  verifyDocuments(name: string) {
    cy.cGet(
      OR_PATIENT_CASE_CHECK_IN.CASE_CONSENTS.DOCUMENTS_ACKNOWLEDGED
        .STICKY_PANEL[1]
    )
      .find(selectorFactory.getSpanText(name))
      .eq(0)
      .should(ShouldMethods.exist);
  }
}
