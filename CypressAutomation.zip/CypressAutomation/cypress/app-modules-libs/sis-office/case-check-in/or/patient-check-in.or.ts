import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_PATIENT_CASE_CHECK_IN = {
  FORMS_CONSENTS: {
    PRINT_ICON: [
      'Print Icon',
      CommonUtils.concatenate(
        CoreCssClasses.ClassPrefix.loc_fa_fa,
        '-print.icon'
      ),
    ],
    TRASH_ICON: [
      'Trash Icon',
      CommonUtils.concatenate(
        CoreCssClasses.ClassPrefix.loc_fa_fa,
        '-trash.icon'
      ),
    ],
    CONSENT_TABLE: ['Consents Summary', `.consent-summary`],
    CONSENT_ROW: [
      'Consent Row',
      CommonUtils.concatenate(
        '#consentsSummary tbody tr.body-row.p-selectable-row',
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    ADD_CONSENTS: ['Add Consents', 'button[label^="Add Consents"]:visible'],
    PICK_CONSENT: [
      '',
      CommonUtils.concatenate(
        CommonGetLocators.ul,
        '.ui-orderlist-list ',
        CommonGetLocators.li
      ),
    ],
    SEARCH_BOX: [
      'Search Box',
      `.add-consents-main-body input[placeholder*='Search']`,
    ],
    PERFORMING_PHYSICIAN: [
      'Performing Physician',
      CommonUtils.concatenate(
        '.physician-dropdown-width #msItems ',
        CoreCssClasses.MultiSelect.loc_p_multiselect_label
      ),
    ],
    PERFORMING_PHYSICIAN_CLEAR_ICON: [
      'Performing Physician Clear Icon',
      CommonUtils.concatenate(
        '#consentPerformingPhysician ',
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    DIAGNOSIS_CODE: ['Diagnosis', '#txtPreop'],
    EDIT_CONSENT: [
      'Edit Consent',
      CommonUtils.concatenate(`.add-addendum-link `, CommonGetLocators.span),
    ],
    EDIT_CONSENT_BLOCK: ['Edit Consent', 'div.single-statement'],
    EDIT_CONSENT_TEXT_BOX_IFRAME: [
      'Edit Consent Iframe Text Box',
      'iframe.cke_wysiwyg_frame:visible',
    ],
    EDIT_RICH_TEXT: ['', '.cke_editable.cke_editable_themed'],
    PHYSICIAN_SIGN: [
      'Physician Sign',
      `div:contains('Physician') #btn_S_stf_sign:nth-child(1)`,
    ],
    OTHER_USER_BUTTON: [
      'Physician Other User',
      `div:contains('Physician') #btn_OU_stf_sign`,
    ],
    EDIT_USER_NAME: ['Username', '#consent_userCredentials_userName'],
    EDIT_PASSWORD: ['Password', `input[type='Password']`],
    EDIT_USER_SIGN: [
      'Sign',
      CommonUtils.concatenate(
        `#btnSign > ')`,
        selectorFactory.getSpanText('Sign')
      ),
    ],
    EDIT_UNSIGN: ['Unsign', `button[label='Unsign']:visible`],
    HEADER_MESSAGE: [
      'Header',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_title,
        ':visible'
      ),
    ],
    WARNING_MESSAGE: [
      'Warning',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_confirm_dialog_message,
        ':visible'
      ),
    ],
    YES_BUTTON: ['Yes', '#btnConfirmAdd'],
    NO_BUTTON: ['No', '#btnConfirmNo'],
    SAVE_DONE: ['DONE', '#btnSaveData:visible'],
    ALL_CONSENTS: [
      '',
      CommonUtils.concatenate(
        '.buttonClass > .p-highlight > ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],

    CKEDITOR_EDIT: ['', `['.cke_wysiwyg_frame']:visible`],
    PROCEDURES_TEXT_AREA: ['Procedures Text Area', '#txtProcedures'],
  },
  OTHER_USER_SIGNATURE_POPUP: {
    SIGNATURE_LABEL: ['Signature'],
    SIGN_BUTTON: ['Sign', '#btnSign'],
    SIGNATURE_CROSS: [
      '',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_header,
        '-close'
      ),
    ],
    OTHER_USER_NAME: ['Username', '#consent_userCredentials_userName'],
    OTHER_USER_PASSWORD: [
      'Password',
      CommonUtils.concatenate(
        selectorFactory.getLabelText('Password'),' + ',
        CommonGetLocators.input
      ),
    ],
  },
  ADD_ADDENDUM: {
    ADDENDUM_CONSENT: ['Add Addendum'],
    ADDENDUM_RICH_TEXT: ['', '.cke_editable.cke_editable_themed'],
    CKEDITOR_ADDENDUM: ['', 'sis-ckeditor .cke_wysiwyg_frame:visible'],
    ADDENDUM_PHYSICIAN_SIGN: [
      'Addendum Physician',
      `div:contains('Physician') #btn_S_add_stf_sign`,
    ],

    ADDENDUM_PHYSICIAN_OTHER_USER_BUTTON: [
      'Addendum Physician',
      `div:contains('Physician') #btn_OU_add_stf_sign`,
    ],
  },
  CASE_CONSENTS: {
    DOCUMENTS_ACKNOWLEDGED: {
      STICKY_PANEL: ['Sticky Panel', '.documentsAcknowledgedStickyPanel'],
      HEADER_ROW: [
        'Header Row',
        CommonUtils.concatenate('.headerRow ', CommonGetLocators.span),
      ],
    },
  },
};
