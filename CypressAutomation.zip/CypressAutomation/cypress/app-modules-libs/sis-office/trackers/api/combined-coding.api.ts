import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class CombinedCodingApis {
  /**
   * @details - APIs while select the procedure in combined coding page.
   * @author - Harsh ranjan
   */
  interceptSelectProcedure(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.record_header,
        'RecordHeader',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_registration,
        'CaseRegistration',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts select Case in Coding/Charge Entry coding tracker API and click on the patient row in Coding/Charge Entry tracker.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh ranjan
  */
  interceptSelectCaseButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'CaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_business_entity_get_image,
        'GetImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_persons_by_roles,
        'PersonsByRoles',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_implants_prosthesis,
        'ImplantsProsthesis',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_modifiers,
        'Modifiers',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_image,
        'PatientImage',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts add select to perform API and click on the patient row in Combined coding tracker.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh ranjan
  */
  interceptAddSelectedToPerformButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_additional_claim_info,
        'AdditionalClaimInfo',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_insurances_for_ce,
        'CaseInsurancesForCE',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts add procedure API and click on the add procedure button in Combined coding tracker.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptAddProcedureButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_record,
        'PatientRecord',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_registrations,
        'CaseRegistration',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts enter amount API and enter amount in Combined coding tracker.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptEnterAmountApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
   * @details - Select supplies from search input field by clicking on add procedure button in combined coding tracker
   * @author - Harsh Ranjan
   */
  interceptSearchAndSelectSupplyApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_inventory,
        'SelectSupplies',
        200
      ),
    ];
  }

  /**
   * @details - Select Procedure from search input field by clicking on add procedure button in combined coding tracker
   * @author - Harsh Ranjan (Add procedure method we are using from charge entry page So, later if it will be added to this page we can use this intercept method)
   */
  interceptSearchProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.post_fee_schedule,
        'SelectProcedure',
        200
      ),
    ];
  }

  /**
   * @details - Select Procedure from search input field by clicking on add procedure button in combined coding tracker
   * @author - Harsh Ranjan
   */
  interceptSearchDiagnosisCodeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_icd_code_classifications,
        'SearchIcdCodes',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for drag n drop in combined coding tracker
   * @author - Arushi
   */
  interceptDragnDropApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'EvaluateDiscount',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for done button in select period and add new batch
   * @author - Arushi
   */
  interceptDoneInAddNewBatch(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insert_batch,
        'InsertBatch',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for clicking on trash icon in combined coding
   * @author - Arushi
   */
  interceptClickTrashInCombinedCoding(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_record,
        'PatientRecord',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.case_registration,
        'CaseRegistration',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for clicking on yes in delete charge pop-up in combined coding
   * @author - Arushi
   */
  interceptClickYesInDeleteChargePopup(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_registration,
        'CaseRegistration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'EvaluateDiscount',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for clicking on add supplies in combined coding
   * @author - Arushi
   */
  interceptClickOnAddSupplies(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_record,
        'PatientRecord',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_registration,
        'CaseRegistration',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for clicking on add supplies in combined coding
   * @author - Arushi
   */
  interceptRemoveProcedure(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'EvaluateDiscount',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for clicking on next case button in combined coding
   * @author - Arushi
   */
  interceptNextCase(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_update_case_status,
        'UpdateCaseStatus',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for searching cpt in combined coding
   * @author - Arushi
   */
  interceptSearchCpt(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule,
        'FeeSchedule',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting cpt in combined coding
   * @author - Arushi
   */
  interceptSelectCpt(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'EvaluateDiscount',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for searching supply in combined coding
   * @author - Arushi
   */
  interceptSearchSupply(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_inventory,
        'GetInventory',
        200
      ),
    ];
  }

  /**
   * @details - After selecting yes in ready for bill and then Done button in combined coding page
   * @author - Arushi
   */
  interceptReadyForBillYesDoneButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_update_case_status,
        'UpdateCaseStatus',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_save_procedure,
        'SaveProcedure',
        200
      ),
    ];
  }

  /**
   * @details - After selecting no in ready for bill and then clicking on Done button in combined coding page
   * @author - Arushi
   */
  interceptReadyForBillNoDoneButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_update_case_status,
        'UpdateCaseStatus',
        200
      ),
    ];
  }

  /**
   * @details - After clicking insurance carrier dropdown
   * @author - Arushi
   */
  interceptClickInsuranceCarrierApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
   * @details - After clicking on primary insurance dropdown cross icon in Charge Entry page
   * @author - Arushi
   */
  interceptPrimaryInsuranceCrossIconApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
    @details - The Api calls happen When we click on Additional claim information button after selecting a procedure in charge Entry Page.
    @author - Prashant Raman
  */
  interceptClickAdditionalClaimInformationbtnApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_additional_claim_info_by_proc_case_id,
        'AdditionalClaimInfo',
        200
      ),
    ];
  }

  /**
   * @details - This Api calls happen when we click on Done button in Additional claim info popup
   * @author - Prashant Raman
   */
  interceptAdditionalClaimInfoDoneBtnApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_upsert_additional_claim_info_with_performed_case_id,
        'UpsertAdditionalClaimInfo',
        200
      ),
    ];
  }

  /**
   * @details - After clicking on yes self pay in Combined coding page
   * @author - Arushi
   */
  interceptSelfPayYesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
   * @details - API Collection after clicking on auto sort button in Combined coding page
   * @author - Prashant Raman
   */
  interceptAutoSortApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.process_contract_logic,
        'ContractLogic',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.charge_entry_auto_sort,
        'ChargeAuto',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.auto_sort_performed_case,
        'AutoSortPerformed',
        200
      ),
    ];
  }
}
