import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class FinancialClearanceApis {
  /**
   * @details - Api collection for Selecting Patient with Self Pay
   * @author - Madhu Kiran
   */
  interceptSelfPaySelectingPatient(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'GetCaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_account_data,
        'GetUserAccountData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_next_case,
        'GetNextCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_estimate_params,
        'PatientEstimateParams',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_mpi_patient_self_pay_verification_by_case_summary_id,
        'InsuranceVerification',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'GetPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_image,
        'GetPatientImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facesheet_list,
        'GetFaceSheetCaseList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.request_lock,
        'RequestLock',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.transportation_contact,
        'TransportationContact',
        200
      ),
    ];
  }

  /**
   * @details - Api Collection for Selecting Patient with Insurence
   * @author - Madhu Kiran
   */
  interceptInsuranceSelectingPatient(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'GetCaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_next_case,
        'GetNextCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_estimate_params,
        'PatientEstimateParams',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_performed_ins_verification,
        'InsuranceVerification',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_faceSheet_ledger_aging_by_case,
        'GetFaceSheetLedgerAgingByCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'GetPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_image,
        'GetPatientImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_faceSheet_case_list_by_patient,
        'GetFaceSheetCaseListByPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.request_lock,
        'RequestLock',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_account_data,
        'GetUserAccountData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.duplicate_response,
        'DuplicateResponse',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.transportation_contact,
        'TransportationContact',
        200
      ),
    ];
  }
}
