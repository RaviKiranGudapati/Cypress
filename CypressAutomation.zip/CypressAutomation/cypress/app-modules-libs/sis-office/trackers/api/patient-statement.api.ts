import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class PatientStatementTrackerApis {
  /**
   * @details - Api collection after selecting patient statements tracker
   * @author Vamshi
   */
  interceptSelectPatientStatementsTrackerApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_statements,
        'PatientStatementsTracker',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Bill selected patients in patient statements tracker
   * @author Vamshi
   */
  interceptSubmitFilePatientStatementsTrackerApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.patient_statements_submit,
        'PatientStatementsTrackerSubmit',
        200
      ),
    ];
  }
}
