import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class CasesToCodeApis {
  /**
    @details - This method intercepts select Case in cases to code tracker API and click on the patient row in Cases to code tracker.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptSelectCaseButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'CaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_business_entity_get_image,
        'GetImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_persons_by_roles,
        'PersonByRole',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_implants_prosthesis,
        'ImplantsProthesis',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_modifiers,
        'Modifiers',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_image,
        'PatientImage',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts select Case in cases to code tracker API and click on the patient row in Cases to code tracker.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author - Harsh Ranjan
  */
  interceptAddSelectedToPerformButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_additional_claim_info,
        'AdditionalClaimInfo',
        200
      ),
    ];
  }

  /**
   * @details - Select supplies from search input field by clicking on add procedure button in case to code
   * @author - Harsh Ranjan
   */
  interceptSearchSupplyButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_inventory,
        'Inventory',
        200
      ),
    ];
  }

  /**
   * @details - To search and select the procedure in case to code.
   * @author - Rakesh Donakonda
   */
  interceptSearchProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule,
        'CodeClassifications',
        200
      ),
    ];
  }

  /**
   * @details - Click on done button after adding diagnosis code where ready to bill is YES
   * @author - Rakesh Donakonda
   */
  interceptClickDoneApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_performed_items,
        'PerformedItems',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_business_entity_get_image,
        'GetImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_available_message,
        'AvailableMessage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_tracker_cases_to_code,
        'CaseToCode',
        200
      ),
    ];
  }

  /**
   * @details - To search and select the Diagnosis in case to code.
   * @author - Rakesh Donakonda
   */
  interceptSearchDiagnosisApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_icd_code_classifications,
        'CodeClassifications',
        200
      ),
    ];
  }

  /**
   * @details - To Enter diagnosis code
   * @author - Spoorthy
   */
  interceptDiagnosisCodeApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_icd_code_classifications,
        'PostICDCodeClassifications',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - Api Collection for click ready for charge and done button
   * @author - Spoorthy
   */
  interceptClickReadyForChargeAndDoneButtonApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_performed_items,
        'PostPerformedItems',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_case_summary,
        'UpdateCaseSatus',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_tracker_cases_to_code,
        'CasesToCodeTracker',
        200
      ),
    ];
    return endpoints;
  }
}
