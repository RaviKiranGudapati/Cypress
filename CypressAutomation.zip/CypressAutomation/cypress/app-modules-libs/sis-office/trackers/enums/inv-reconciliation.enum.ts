export enum LabelHeaders {
  update = 'UPDATE',
  new = 'NEW',
}