export enum InsuranceBillingOptions {
  bill_selected_payers = 'Bill Selected Payers',
  print_selected_payers = 'Print Selected Payers',
  download_claims = 'Download Claims',
}
