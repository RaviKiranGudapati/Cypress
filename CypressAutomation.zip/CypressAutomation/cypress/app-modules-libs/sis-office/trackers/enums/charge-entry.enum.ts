export enum AdditionalClaimInformation {
  apply_all_charges = 'Apply to All Charges ',
}

export enum FreeText {
  hcpcs_field_text = ' Search by name or inv #',
}
