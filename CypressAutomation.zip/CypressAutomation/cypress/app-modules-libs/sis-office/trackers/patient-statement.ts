import {
  CommonGetLocators,
  InvokeMethods,
} from '../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_STATEMENT } from './or/patient-statement.or';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';
import { PatientStatementTrackerApis } from './api/patient-statement.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

export default class PatientStatement {
  /* instance variables */
  private patientStatementTrackerApis = new PatientStatementTrackerApis();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  /**
   * @details - To select checkbox based on patient name
   * @param patientName as string used in function
   * @API - API's are not available
   */
  selectCheckboxByPatient(patientName: string) {
    cy.cGet(selectorFactory.getSpanText(patientName))
      .parents(CommonGetLocators.tr)
      .first()
      .within(() => {
        cy.cClick(
          OR_PATIENT_STATEMENT.CHECKBOX[1],
          OR_PATIENT_STATEMENT.CHECKBOX[0],
          false,
          false,
          {
            force: true,
          }
        );
      });
  }

  /**
   * @details - To select buttons in Patient Statement
   * @param option as string used in function
   * @API - API's are available - Implemented Completely
   * @author Vamshi
   */
  selectButtonsInPatientStatement(option: string) {
    cy.cClick(selectorFactory.getSpanText(option), option);
    if (option === OR_PATIENT_STATEMENT.BILL_SELECTED_PATIENTS[0]) {
      const interceptCollection =
        this.patientStatementTrackerApis.interceptSubmitFilePatientStatementsTrackerApi();
      cy.cIntercept(interceptCollection);
      cy.cClick(
        selectorFactory.getSpanText(OR_PATIENT_STATEMENT.SUBMIT_FILE[0]),
        OR_PATIENT_STATEMENT.SUBMIT_FILE[0]
      );
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - To verify Billed Statement count
   * @param patientName as string used in function
   * @param count as string used in function
   * @API - API's are not available
   */
  verifyBilledStatementCount(patientName: string, count: string) {
    cy.cGet(selectorFactory.getSpanText(patientName))
      .parents(CommonGetLocators.tr)
      .first()
      .within(() => {
        cy.cGet(OR_PATIENT_STATEMENT.PATIENT_STATEMENT_VALUES[1])
          .eq(6)
          .invoke(InvokeMethods.text)
          .then(($ele) => {
            expect($ele).to.contains(count);
          });
      });
  }

  /**
   * @details - To verify unpresence of patient
   * @param patientName as string used in function
   * @API - API's are not available
   */
  verifyPatientPresence(option: string, patientName: string) {
    cy.shouldBeEnabled(selectorFactory.getButtonEnable(option));
    cy.cNotExist(selectorFactory.getSpanText(patientName), patientName);
  }

  /**
   * @details - close print pop-up
   * @API - API's are not available
   * @author - Nikitan
   */
  closePrintPopup() {
    cy.cClick(
      OR_PATIENT_STATEMENT.CLOSE_PRINT_PREVIEW[1],
      OR_PATIENT_STATEMENT.CLOSE_PRINT_PREVIEW[0]
    );
  }

  /**
   * @details select patient statements tracker
   * @API - API's are available - Implemented Completely
   * @author Vamshi
   * This method needs to remove because the alternative method for this is Select Tracker
   */
  clickOnPatientStatementsTracker() {
    const interceptCollection =
      this.patientStatementTrackerApis.interceptSelectPatientStatementsTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectTracker(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the Patient statement tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptPatientStatementsTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }
}
