import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { YesOrNo } from '../../../support/common-core-libs/application/common-core';

import {
  SubRoutes,
  WaitMethods,
} from '../../../support/common-core-libs/application/constants/sub-routes.constants';

import { OR_CLINICAL_DOCUMENTATION } from './or/clinical_documentation.or';

import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

export default class ClinicalDocumentation {
  /**
   * @details To click yes or no option for patient case in clinical documentation tracker
   * @param yesOrNoOption - passing yes or no option
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  selectDocumentationCompleteAndDoneButton(yesOrNoOption: string) {
    const buttonConfig =
      yesOrNoOption === YesOrNo.yes
        ? OR_CLINICAL_DOCUMENTATION.DOCUMENTATION_COMPLETE.YES[1]
        : OR_CLINICAL_DOCUMENTATION.DOCUMENTATION_COMPLETE.NO[1];

    cy.shouldBeEnabled(OR_CLINICAL_DOCUMENTATION.DOCUMENTATION_COMPLETE.NO[1]);
    cy.cClick(buttonConfig, yesOrNoOption, false, true);
    const interceptCollection = this.interceptselectDocumentationCompleteApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   *@details To click yes or no option for patient case in clinical documentation tracker
   * @author - Spoorthy
   */
  interceptselectDocumentationCompleteApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.cmd_document,
        'CDMDocument',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_available_message,
        'GetAvailableMessage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.clinical_documentation,
        'ClinicalDocumentationTracker',
        200
      ),
    ];
    return endpoints;
  }
}
