import {
  Application,
  CommonClassAttributes,
  InvokeMethods,
  HierarchyOptions,
  InvokeAttributes,
  ShouldMethods,
  TrueOrFalse,
  YesOrNo,
  EnableOrDisable,
  CommonGetLocators,
  TriggerAttributes,
} from '../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { AppToolTip } from '../../../support/common-core-libs/application/constants/app-tooltip-constant';
import {
  Adjustment,
  Charges,
  HCFAAdditionalClaim,
  UBAdditionalClaim,
} from '../../../test-data-models/sis-office/trackers/combined-coding.model';
import {
  BillingDetails,
  PatientCase,
} from '../../../test-data-models/sis-office/case/patient-case.model';
import { Cpt } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_CASE_CREATION } from '../case-creation/or/create-case.or';
import { OR_CASES_TO_CODE } from './or/cases-to-code.or';
import { OR_CHARGE_ENTRY } from './or/charge-entry.or';
import { OR_COMBINED_CODING } from './or/combined-coding.or';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';
import { CombinedCodingApis } from './api/combined-coding.api';

import { ChargeAdjustment, CodingPopUpText } from './enums/combined-coding.enum';
import {
  performedItemsHeaders,
  addNewItem,
  ubFields,
  maxFieldLength,
  chargeDetails,
  numEighty,
  hcfaFields,
  headerNames,
} from './constants/combined-coding.const';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

export default class CombinedCoding {
  /* instance variables */
  private combinedCodingApis = new CombinedCodingApis();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  /**
   * selecting period and batch in combine coding
   * removing mask wrapper and selecting patient
   * @param chargeInfo - Taking Period and batch data with patient record from testdata model.
   * @Api - API's are not available
   */
  selectPeriodAndBatch(chargeInfo: Charges) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(chargeInfo.Period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(chargeInfo.Batch),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @detail - To click on Select all procedure checkbox
   * @Api - API's are not available
   */
  selectAllProcedureCheckbox() {
    cy.cClick(
      OR_COMBINED_CODING.SELECT_ALL_PROCEDURE_CHECKBOX[1],
      OR_COMBINED_CODING.SELECT_ALL_PROCEDURE_CHECKBOX[0]
    );
  }

  /**
   * @detail - To click on add selected to perform button
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  addSelectedToPerformed() {
    const interceptCollection =
      this.combinedCodingApis.interceptAddSelectedToPerformButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_COMBINED_CODING.ADD_SELECTED_TO_PERFORMED[1],
      OR_COMBINED_CODING.ADD_SELECTED_TO_PERFORMED[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - To verify and click on the procedure row
   * @param cpt code to be entered
   * @API - API's are available - Implemented Completely
   * @author Arushi
   */
  verifyAndSelectProcedure(cpt: string) {
    const interceptCollection =
      this.combinedCodingApis.interceptSelectProcedure();
    cy.cIntercept(interceptCollection);
    cy.cGet(
      selectorFactory.getProcedureListPerformedItems(cpt)
    ).scrollIntoView();
    cy.cClick(selectorFactory.getProcedureListPerformedItems(cpt), cpt);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - To verify patient in combined coding tracker
   * @param patientFullName -to be entered to verify patient
   * @Api - API's are not available
   */
  verifyPatientRow(patientFullName: string) {
    cy.cGet(selectorFactory.getSpanText(patientFullName))
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible);
  }

  /**
   * @detail - To verify Done button and ready for bill button disable state
   * @param button -Name of the button (ex.ready for bill)
   * @param isDisabled -state of button
   * @Api - API's are not available
   */
  verifyFooterButtonEnableDisable(button: string, isDisabled: boolean) {
    let locator: string = '';
    switch (button) {
      case OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]:
        locator = OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1];
        break;
      case OR_COMBINED_CODING.READY_FOR_BILL_NO[0]:
        locator = OR_COMBINED_CODING.READY_FOR_BILL_NO[1];
        break;
      default:
        break;
    }

    if (isDisabled) {
      if (button == OR_COMBINED_CODING.READY_FOR_BILL_NO[0]) {
        cy.cGet(locator).should(
          ShouldMethods.class,
          CommonClassAttributes.pdisabled,
          CommonClassAttributes.pdisabled
        );
      } else {
        cy.cGet(locator).should(
          ShouldMethods.attribute,
          CommonClassAttributes.disabled,
          CommonClassAttributes.disabled
        );
      }
    } else {
      cy.cIsEnabled(locator, button, false, true);
    }
  }

  /**
   * @detail - To enter diagnosis code in charge tab
   * @param chargeInfo code to be entered
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  selectDiagnosisCode(chargeInfo: Charges) {
    const interceptCollection =
      this.combinedCodingApis.interceptSearchDiagnosisCodeApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_CASES_TO_CODE.CODING.SEARCH_DIAGNOSIS_CODE[1],
      OR_CASES_TO_CODE.CODING.SEARCH_DIAGNOSIS_CODE[0],
      chargeInfo.DiagnosisCode
    );
    cy.cWaitApis(interceptCollection);
    cy.cGet(OR_CASES_TO_CODE.CODING.DIAGNOSIS_CODE_LIST[1]).parent().click();
  }

  /**
   * @detail - To verify DOS,Procedure and case status on green bar after patient selection
   * @param option - text field to be verified
   * @param value- option to be verified
   * @Api - API's are not available
   */
  verifyTextOnGreenBar(option: string, value: string) {
    let locator = '';
    switch (option) {
      case OR_COMBINED_CODING.HEADER.DOS[0]:
        locator = CommonUtils.concatenate(
          OR_COMBINED_CODING.HEADER.DOS[1],
          selectorFactory.getSpanText(value)
        );
        break;
      case OR_COMBINED_CODING.HEADER.PROCEDURE[0]:
        locator = selectorFactory.getTextInLimitTextContainer(value);
        break;
      case OR_COMBINED_CODING.HEADER.CASE_STATUS[0]:
        locator = CommonUtils.concatenate(
          OR_COMBINED_CODING.HEADER.CASE_STATUS[1],
          selectorFactory.getSpanText(value)
        );
        break;
      default:
        break;
    }
    cy.cIsVisible(locator, option);
  }

  /**
   * @detail - To verify Mandatory fields with asterisk in charge tab
   * @param option -field name to be verified
   * @Api - API's are not available
   */
  verifyMandatoryFields(option: string) {
    const loc = selectorFactory.mandatoryFields(option);
    cy.cIsVisible(loc, option);
  }

  /**
   * @detail - To select value from physician,referring physician and discount dropdown
   * @param dropdown - to select the drop down to be verified
   * @param value -to select the drop down value
   * @Api - API's are not available
   */
  enterAllChargeDetails(dropdown: string, value: string) {
    let locator = '';
    switch (dropdown) {
      case OR_COMBINED_CODING.CHARGE.PHYSICIAN[0]:
        locator = OR_COMBINED_CODING.CHARGE.PHYSICIAN[1];
        break;
      case OR_COMBINED_CODING.CHARGE.REFERRING_PHYSICIAN[0]:
        locator = OR_COMBINED_CODING.CHARGE.REFERRING_PHYSICIAN[1];
        break;
      case OR_COMBINED_CODING.CHARGE.DISCOUNT[0]:
        locator = OR_COMBINED_CODING.CHARGE.DISCOUNT[1];
        break;
      case OR_COMBINED_CODING.CHARGE.AMOUNT[0]:
        locator = OR_COMBINED_CODING.CHARGE.AMOUNT[1];
        break;
      default:
        break;
    }

    if (locator == OR_COMBINED_CODING.CHARGE.DISCOUNT[1]) {
      cy.shouldBeEnabled(OR_COMBINED_CODING.CHARGE.DISCOUNT[1]);
      cy.cClick(
        OR_COMBINED_CODING.CHARGE.DISCOUNT[1],
        OR_COMBINED_CODING.CHARGE.DISCOUNT[0]
      ).then(() => {
        //Added assertCombinedCodingMandatoryFields method to avoid latency issue
        this.assertCombinedCodingChargeDetails();
        cy.cType(
          OR_COMBINED_CODING.CHARGE.DISCOUNT_SEARCH[1],
          OR_COMBINED_CODING.CHARGE.DISCOUNT_SEARCH[0],
          value
        );
      });
      cy.cClick(selectorFactory.searchAndSelectItemFromList(value), value);
    } else if (locator == OR_COMBINED_CODING.CHARGE.AMOUNT[1]) {
      cy.cType(
        OR_COMBINED_CODING.CHARGE.AMOUNT[1],
        OR_COMBINED_CODING.CHARGE.AMOUNT[0],
        value
      );
      cy.cGet(
        selectorFactory.mandatoryFields(OR_COMBINED_CODING.CHARGE.AMOUNT[0])
      )
        .invoke(InvokeMethods.show)
        .should(ShouldMethods.visible)
        .click();
    } else {
      cy.cSelectDropdown(locator, dropdown, value);
    }
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @detail - To select add procedure button in coding/charge entry
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  clickAddProcedureButton() {
    const interceptCollection =
      this.combinedCodingApis.interceptAddProcedureButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_COMBINED_CODING.ADD_PROCEDURE[1],
      OR_COMBINED_CODING.ADD_PROCEDURE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - To select add supplies button in coding/charge entry
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  clickAddSuppliesButton() {
    const interceptCollection =
      this.combinedCodingApis.interceptAddProcedureButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_COMBINED_CODING.ADD_SUPPLIES_BUTTON[1],
      OR_COMBINED_CODING.ADD_SUPPLIES_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - To select charge and adjustment toggle button in coding/charge entry
   * @param option charge to be selected
   * @Api - API's are not available
   */
  selectChargeAdjustmentButton(option: string) {
    cy.cClick(selectorFactory.getChargeAdjustmentButton(option), option);
  }

  /**
   * @detail - To select all modifiers dropdown value in charge tab
   * @param value - value to select from modifiers dropdown
   * @param index - To point specific modifiers among 4 (ex: if index=1 it will point modifier1 )
   * @Api - API's are not available
   */
  selectModifiers(value: string, index: number) {
    cy.shouldBeEnabled(selectorFactory.getModifiersDropdown(index));
    cy.cGet(
      selectorFactory.getModifiersDropdown(index),
      ChargeAdjustment.modifier
    )
      .should(ShouldMethods.exist)
      .click()
      .then(() => {
        cy.cType(
          OR_COMBINED_CODING.CHARGE.CHARGE_DROPDOWN_SEARCH[1],
          ChargeAdjustment.modifier + index,
          value
        );
      });
    cy.cClick(selectorFactory.searchAndSelectItemFromList(value), value);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @detail - To search And Select Procedure Supplies
   * @param option -field name to be search
   * @param value- field value to be selected
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  searchAndSelectProcedureSupplies(option: string, value: string) {
    if (option == OR_COMBINED_CODING.CHARGE.HCPCS[0]) {
      cy.cType(
        OR_COMBINED_CODING.CHARGE.HCPCS[1],
        OR_COMBINED_CODING.CHARGE.HCPCS[0],
        value
      );
      cy.cRemoveMaskWrapper(Application.office);
    } else if (option == OR_COMBINED_CODING.CHARGE.SEARCH_PROCEDURE[0]) {
      const interceptSearchCptCollection =
        this.combinedCodingApis.interceptSearchCpt();
      cy.cIntercept(interceptSearchCptCollection);
      cy.cType(
        OR_COMBINED_CODING.CHARGE.SEARCH_PROCEDURE[1],
        OR_COMBINED_CODING.CHARGE.SEARCH_PROCEDURE[0],
        value
      );
      cy.cWaitApis(interceptSearchCptCollection);
      const interceptSelectCptCollection =
        this.combinedCodingApis.interceptSelectCpt();
      cy.cIntercept(interceptSelectCptCollection);
      cy.cClick(selectorFactory.searchAndSelectItemFromList(value), value);
      cy.cWaitApis(interceptSelectCptCollection);
      cy.cRemoveMaskWrapper(Application.office);
    } else {
      const interceptSearchSupplyCollection =
        this.combinedCodingApis.interceptSearchSupply();
      cy.cIntercept(interceptSearchSupplyCollection);
      cy.cType(
        OR_COMBINED_CODING.CHARGE.SEARCH_SUPPLIES[1],
        OR_COMBINED_CODING.CHARGE.SEARCH_SUPPLIES[0],
        value
      );
      cy.cWaitApis(interceptSearchSupplyCollection);
      const interceptCollection = this.combinedCodingApis.interceptSelectCpt();
      cy.cIntercept(interceptCollection);

      cy.cClick(selectorFactory.getSuppliesInCombinedCoding(value), value);
      cy.cWaitApis(interceptCollection);
      cy.cRemoveMaskWrapper(Application.office);
    }
  }

  /**
   * @detail -Select Transaction code under adjustment tab
   * @param dropdown -To select Debit or Write-Off transaction code dropdown.
   * @param index - Index define the write-Off and debit row starting from 0.
   * @param code-code to be selected
   * @Api - API's are not available
   */
  selectTransactionCode(dropdown: string, index: number, code: string) {
    let loc: string = '';
    switch (dropdown) {
      case OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0]:
        loc = selectorFactory.getWriteOffTransactionCodeDropdown(index);
        break;
      case OR_COMBINED_CODING.ADJUSTMENT.DEBIT_TRANSACTION_CODE[0]:
        loc = selectorFactory.getDebitTransactionCodeDropdown(index);
        break;
      default:
        break;
    }
    cy.cClick(loc, dropdown);

    if (
      dropdown == OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0]
    ) {
      cy.cType(
        OR_COMBINED_CODING.ADJUSTMENT.TRANSACTION_CODE_SEARCH[1],
        OR_COMBINED_CODING.ADJUSTMENT.TRANSACTION_CODE_SEARCH[0],
        code
      );
      cy.cClick(
        selectorFactory.getDropdownValues(code),
        OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0]
      );
    } else {
      cy.cClick(
        selectorFactory.getDropdownValues(code),
        OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0]
      );
    }
  }

  /**
   * @detail - To enter all the details in adjustment tab
   * @param field- To verify field names in adjustment tab
   * @param value- To verify field values in adjustment tab
   * @param index- To verify drop down value index
   * @Api - API's are not available
   */
  enterAdjustmentsDetails(field: string, value: string, index: number) {
    let loc: string = '';
    switch (field) {
      case OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0]:
        loc = selectorFactory.getWriteOffAmountInput(index);
        break;
      case OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0]:
        loc = selectorFactory.getDebitOffAmountInput(index);
        break;
      case OR_COMBINED_CODING.ADJUSTMENT.GROUP_CODE[0]:
        loc = selectorFactory.getWriteOffGroupCodeDropdown(index);
        break;
      case OR_COMBINED_CODING.ADJUSTMENT.REASON_CODE[0]:
        loc = selectorFactory.getWriteOffReasonCodeDropdown(index);
        break;
      default:
        break;
    }
    cy.cClick(loc, field);

    if (
      field == OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0] ||
      OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0]
    ) {
      cy.cType(loc, field, value);
      cy.cRemoveMaskWrapper(Application.office);
    } else {
      cy.cType(CoreCssClasses.DropDown.loc_p_dropdown_filter, field, value);
      cy.cClick(selectorFactory.getSpanClassText(value), field);
    }
  }

  /**
   * @details - To select write-Off group code
   * @param index -To select specific group code
   * @param value -To click specific value
   * @Api - API's are not available
   */
  selectWriteOffGroupCode(index: number, value: string) {
    cy.cClick(
      selectorFactory.getWriteOffGroupCodeDropdown(index),
      OR_COMBINED_CODING.ADJUSTMENT.GROUP_CODE[0]
    );

    cy.cClick(
      selectorFactory.getSpanClassText(value),
      OR_COMBINED_CODING.ADJUSTMENT.GROUP_CODE[0]
    );
  }

  /**
   * @detail -To select Write Off reason code.
   * @param index To select specific reason code
   * @param value To enter and click specific value
   * @Api - API's are not available
   */
  selectReasonCode(index: number, value: string) {
    cy.cClick(
      selectorFactory.getWriteOffReasonCodeDropdown(index),
      OR_COMBINED_CODING.ADJUSTMENT.REASON_CODE[0]
    );
    cy.cType(
      CoreCssClasses.DropDown.loc_p_dropdown_filter,
      OR_COMBINED_CODING.ADJUSTMENT.REASON_CODE[0],
      value
    );
    cy.cClick(
      selectorFactory.getSpanText(value),
      OR_COMBINED_CODING.ADJUSTMENT.REASON_CODE[0]
    );
  }

  /**
   * @detail - To select ready for bill yes or no button
   * @param yesNoOption -To select yes/no option
   * @Api - API's are not available
   */
  selectReadyForBill(yesNoOption: string) {
    let selectorOption = '';

    switch (yesNoOption) {
      case YesOrNo.yes:
        selectorOption = OR_COMBINED_CODING.READY_FOR_BILL_YES[1];
        break;
      case YesOrNo.no:
        selectorOption = OR_COMBINED_CODING.READY_FOR_BILL_NO[1];
        break;
      default:
        break;
    }

    cy.cClick(selectorOption, yesNoOption, false, true);
  }

  /**
   * @detail - To select Done button new method clickReadyForBillAndDoneButton() is implemented in order to click done as per yes  or no option in ready for bill
   * @Api - API's are not available
   */
  clickOnDoneButton() {
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
      false,
      false,
      { force: true }
    );
  }

  /**
   * @details Click Ready For Bill Yes Button and Done Button
   * @param flag - true/false needs to be passed as per ready for bill(if ready for bill is no, pass false else pass true )
   * @Api - API's are not available
   * @author Arushi
   */
  clickReadyForBillAndDoneButton(flag: boolean = false) {
    const yesOrNo = flag ? YesOrNo.yes : YesOrNo.no;
    const interceptCollection = flag
      ? this.combinedCodingApis.interceptReadyForBillYesDoneButtonApi()
      : this.combinedCodingApis.interceptReadyForBillNoDoneButtonApi();

    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(
        OR_COMBINED_CODING.READY_FOR_BILL[1],
        selectorFactory.getSpanText(yesOrNo)
      ),
      yesOrNo
    );
    this.clickOnDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To Select supplies from dropdown in charge tab
   * @param input -To enter the value in search fields
   * @param value -to select the displayed values
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  selectSupplies(input: string, value: string) {
    const interceptCollection =
      this.combinedCodingApis.interceptSearchAndSelectSupplyApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_COMBINED_CODING.CHARGE.SEARCH_SUPPLIES[1],
      OR_COMBINED_CODING.CHARGE.SEARCH_SUPPLIES[0],
      input
    );
    cy.cWaitApis(interceptCollection);
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSuppliesInCombinedCoding(value), value);
    cy.cWaitApis(interceptCollection);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - verify patient is not present under combined coding tracker
   * @param value -value to be verified
   */
  verifyPatientFallOffInCombinedCoding(value: string) {
    sisOfficeDesktop.waitTillSpinnerLoads();
    cy.cNotExist(selectorFactory.mandatoryFields(value), value);
  }

  /**
   * @detail - Edit write-Off amount
   * @param amount enter write-off amount
   * @param index enter the index
   * @param newAmount enter new amount after editing
   * @Api - API's are not available
   */
  editWriteOffAmount(amount: string, index: number, newAmount: string) {
    cy.cClick(
      selectorFactory.getWriteOffAmount(amount),
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0]
    );
    cy.cType(
      selectorFactory.getWriteOffAmountInput(index),
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
      newAmount
    );
  }

  /**
   * @detail - To verify balance amount for charges
   * @param- amount to be verified
   * @Api - API's are not available
   */
  verifyBalanceAmount(amount: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.BALANCE[1],
      OR_COMBINED_CODING.CHARGE.BALANCE[0],
      amount
    );
  }

  /**
   * @detail - To verify charge amount for charges
   * @param- amount to be entered
   * @Api - API's are not available
   */
  verifyChargeAmount(amount: string) {
    cy.cHasValue(
      OR_COMBINED_CODING.CHARGE.AMOUNT[1],
      OR_COMBINED_CODING.CHARGE.AMOUNT[0],
      amount
    );
  }

  /**
   * @detail - Performing drag and drop action for the cpt procedures
   * @param charge1 initial position of charge
   * @param charge2 final position to the charge
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  dragAndDropCharges(charge1: string, charge2: string) {
    const interceptCollection = this.combinedCodingApis.interceptDragnDropApi();
    cy.cIntercept(interceptCollection);
    cy.dragAndDrop(
      selectorFactory.dragAndDropCharges(charge1),
      selectorFactory.dragAndDropCharges(charge2)
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - To delete charges
   * @param- cptdata to be deleted
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  deleteChargeInCoding(cptData: Cpt) {
    const interceptClickTrashInCombinedCodingCollection =
      this.combinedCodingApis.interceptClickTrashInCombinedCoding();
    cy.cGet(OR_COMBINED_CODING.CPT_ROW[1]).each(($cptRows) => {
      if ($cptRows.text().includes(cptData.CPTCodeAndDescription)) {
        cy.wrap($cptRows)
          .first()
          .within(() => {
            cy.cIntercept(interceptClickTrashInCombinedCodingCollection);
            cy.cGet(OR_COMBINED_CODING.TRASH_ICON[1])
              .invoke(InvokeMethods.show)
              .eq(2)
              .click();
            cy.cWaitApis(interceptClickTrashInCombinedCodingCollection);
          });
      }
    });
    const interceptClickYesInDeleteChargePopupCollection =
      this.combinedCodingApis.interceptClickYesInDeleteChargePopup();
    cy.cIntercept(interceptClickYesInDeleteChargePopupCollection);
    cy.cClick(OR_COMBINED_CODING.YES[1], OR_COMBINED_CODING.YES[0]);
    cy.cWaitApis(interceptClickYesInDeleteChargePopupCollection);
  }

  /**
   * @detail - To verify Selected guarantor name in charge tab.
   * @param dropdownValue - provide dropdown value to verify
   * @Api - API's are not available
   */
  verifyDropdownValue(dropdownValue: string) {
    cy.cGet(selectorFactory.getSpanText(dropdownValue))
      .scrollIntoView()
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible);
  }

  /**
   * @details - To add supplies
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  addSupplies() {
    const interceptCollection =
      this.combinedCodingApis.interceptClickOnAddSupplies();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_COMBINED_CODING.ADD_SUPPLIES[1],
      OR_COMBINED_CODING.ADD_SUPPLIES[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify CPT® Code or HCPCS Code Label
   * @Api - API's are not available
   */
  verifyCPT() {
    cy.cGet(selectorFactory.getSpanClassText(ChargeAdjustment.cpt))
      .eq(0)
      .first()
      .within(() => {
        cy.cIsVisible(
          selectorFactory.getSpanClassText(ChargeAdjustment.cpt),
          ChargeAdjustment.cpt
        );
      });
  }

  /**
   * @details - To verify unit of measure label
   * @Api - API's are not available
   */
  verifyUnitsOfMeasure() {
    cy.cIsVisible(
      selectorFactory.getSpanText(ChargeAdjustment.units_of_measure),
      ChargeAdjustment.units_of_measure
    );
  }

  /**
   * @details - To type HCPCS value
   * @param value to be entered in field
   * @Api - API's are not available
   */
  enterHcpcsValue(value: string) {
    cy.cType(OR_COMBINED_CODING.HCPCS[1], OR_COMBINED_CODING.HCPCS[0], value);
  }

  /**
   * @details - To remove added procedure supplies
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  crossIconProcedure() {
    const interceptCollection =
      this.combinedCodingApis.interceptRemoveProcedure();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_COMBINED_CODING.CROSS_ICON_PROCEDURE[1],
      OR_COMBINED_CODING.CROSS_ICON_PROCEDURE[0],
      false,
      false,
      { force: true }
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify NDC label and type value
   * @param value to be verified in field
   * @Api - API's are not available
   */
  verifyNdc(value: string) {
    cy.cIsVisible(
      selectorFactory.getSpanText(ChargeAdjustment.ndc),
      ChargeAdjustment.ndc
    ).then(() => {
      cy.cType(
        OR_COMBINED_CODING.NDC_TEXT[1],
        OR_COMBINED_CODING.NDC_TEXT[0],
        value
      );
    });
  }

  /**
   * @details - To verify Base units label and type value
   * @param value to be verified in field
   * @Api - API's are not available
   */
  verifyBaseUnits(value: string) {
    cy.cIsVisible(
      selectorFactory.verifyLabelInCombinedCoding(ChargeAdjustment.base_units),
      ChargeAdjustment.base_units
    ).then(() => {
      cy.cType(
        OR_COMBINED_CODING.BASE_UNIT_VALUE[1],
        OR_COMBINED_CODING.BASE_UNIT_VALUE[0],
        value
      );
    });
  }

  /**
   * @details - To click on next case button
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  nextCaseButton() {
    const interceptCollection = this.combinedCodingApis.interceptNextCase();
    cy.cIntercept(interceptCollection);
    cy.cClick(OR_COMBINED_CODING.NEXT_CASE[1], OR_COMBINED_CODING.NEXT_CASE[0]);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify status Ready to charge in charge entry face sheet
   * @Api - API's are not available
   */
  verifyReadyToCharge() {
    cy.cIsVisible(
      OR_COMBINED_CODING.STATUS_READY_TO_CHARGE[1],
      OR_COMBINED_CODING.STATUS_READY_TO_CHARGE[0]
    );
  }

  /**
   * @details - To verify amount in added supplies procedure
   * @param value -value to be verified
   * @Api - API's are not available
   */
  verifyAmount(value: string) {
    cy.cHasValue(
      OR_COMBINED_CODING.AMOUNT[1],
      OR_COMBINED_CODING.AMOUNT[0],
      value
    );
  }

  /**
   * @details - To verify physician in added supplies procedure
   * @param phyValue value to be verified
   * @Api - API's are not available
   */
  verifyPhysician(phyValue: string) {
    cy.cIsVisible(
      CommonUtils.concatenate(
        OR_COMBINED_CODING.PHYSICIAN_VALUE[1],
        selectorFactory.getSpanText(phyValue)
      ),
      OR_COMBINED_CODING.PHYSICIAN_VALUE[0]
    );
  }

  /**
   * @details - To verify referring physician in added supplie procedure
   * @param refPhyValue value to be verified
   * @Api - API's are not available
   */
  verifyReferringPhysician(refPhyValue: string) {
    cy.cIsVisible(
      CommonUtils.concatenate(
        OR_COMBINED_CODING.REFERRING_PHYSICIAN_VALUE[1],
        selectorFactory.getSpanText(refPhyValue)
      ),
      OR_COMBINED_CODING.REFERRING_PHYSICIAN_VALUE[0]
    );
  }

  /**
   * @details - To verify modifier in added supply procedure
   * @param index - value to be verified
   * @Api - API's are not available
   */
  verifyModifier(index: number) {
    cy.cIsVisible(
      CommonUtils.concatenate(selectorFactory.getModifiersDropdown(index)),
      ChargeAdjustment.modifier
    );
  }

  /**
   * @details - To click on ready for bill yes
   * @Api - API's are not available
   */
  clickOnReadyForBill() {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[0]
    );
  }

  /**
   * @details - To verify units of measure drop down values
   * @param values present in the units of measure drop down
   * @Api - API's are not available
   */
  verifyDropDownValuesInUnitsOfMeasure(values: string[]) {
    cy.cClick(
      OR_COMBINED_CODING.UNITS_OF_MEASURE_DROPDOWN[1],
      OR_COMBINED_CODING.UNITS_OF_MEASURE_DROPDOWN[0],
      false,
      false,
      { force: true }
    );
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getSpanText(el), el);
    });
  }

  /**
   * @details - To click on units of measure cross icon
   * @Api - API's are not available
   */
  clickOnUnitsOfMeasureCrossIcon() {
    cy.cClick(
      OR_COMBINED_CODING.UNITS_OF_MEASURE_CROSS_ICON[1],
      OR_COMBINED_CODING.UNITS_OF_MEASURE_CROSS_ICON[0]
    );
  }

  /**
   * @details - To clicking on performed actions in combined/coding charge entry
   * @param count as parameters inside the function
   * @Api - API's are not available
   */
  clickOnPerformedItems(count: number) {
    Array.from({ length: count + 1 }).forEach(() => {
      cy.cClick(
        OR_COMBINED_CODING.PERFORMED_ITEMS[1],
        OR_COMBINED_CODING.PERFORMED_ITEMS[0]
      );
    });
  }

  /**
   * @detail - Verifying write-Off reason code
   * @param value value to be verified in reason code
   * @Api - API's are not available
   */
  verifyReasonCode(value: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.ADJUSTMENT.WRITEOFF_REASONCODE[1],
      OR_COMBINED_CODING.ADJUSTMENT.WRITEOFF_REASONCODE[0],
      value
    );
  }

  /**
   * @detail - Verifying write-Off group code
   * @param value value to be verified in group code
   * @Api - API's are not available
   */
  verifyGroupCode(value: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.ADJUSTMENT.WRITEOFF_GROUPCODE[1],
      OR_COMBINED_CODING.ADJUSTMENT.WRITEOFF_GROUPCODE[0],
      value
    );
  }

  /**
   * @detail - To verify performed items header labels
   * @param option To provide the insurance carrier value
   * @Api API's are available - Implemented Completely(Apis are available only for primary insurance hence new method clickPrimaryInsuranceCarrierOption() is created with Api implementation)
   * @author Arushi
   */
  clickInsuranceCarrierOption(option: string) {
    cy.cClick(option, option, true, true, { force: true });
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @detail - To select primary insurance value from drop down
   * @param option only primary insurance value to be passed
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  clickPrimaryInsuranceCarrierOption(option: string) {
    const interceptCollection =
      this.combinedCodingApis.interceptClickInsuranceCarrierApi();
    cy.cIntercept(interceptCollection);
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(option, option, true, true);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To update NDC value
   * @param value to be updated
   * @Api - API's are not available
   */
  updateNdcValue(value: string) {
    cy.cType(
      OR_COMBINED_CODING.SEARCH_CPT_PROCEDURE[1],
      OR_COMBINED_CODING.SEARCH_CPT_PROCEDURE[0],
      value
    );
  }

  /**
   * @details - To verify units of measure value
   * @param value -verify the values in units of measure values
   * @Api - API's are not available
   */
  verifyUnitsOfMeasureValue(value: string) {
    cy.cIsVisible(selectorFactory.getSpanText(value), value);
  }

  /**
   * @details - To search and select CPT in procedure
   * @param value to be searched
   * @API -  API's are available - Implemented Completely
   * @Author - Arushi
   * @API -  API's are available - Implemented Completely
   * @author Arushi
   */
  searchAndSelectCptInProcedure(value: string) {
    const interceptSearchCptCollection =
      this.combinedCodingApis.interceptSearchCpt();
    cy.cClick(
      OR_COMBINED_CODING.CPT_PROCEDURE[1],
      OR_COMBINED_CODING.CPT_PROCEDURE[0]
    ).then(() => {
      cy.cIntercept(interceptSearchCptCollection);
      cy.cType(
        OR_COMBINED_CODING.CPT_PROCEDURE[1],
        OR_COMBINED_CODING.ADD_PROCEDURE[0],
        value
      );
      cy.cWaitApis(interceptSearchCptCollection);
      const interceptSelectCptCollection =
        this.combinedCodingApis.interceptSelectCpt();
      cy.cIntercept(interceptSelectCptCollection);
      cy.cClick(
        OR_COMBINED_CODING.SELECT_PROCEDURE[1],
        OR_COMBINED_CODING.SELECT_PROCEDURE[0]
      );
      cy.cWaitApis(interceptSelectCptCollection);
      cy.cRemoveMaskWrapper(Application.office);
    });
  }

  /**
   * @details - To click on contracts Title
   * @param count
   * @Api - API's are not available
   */
  clickOnContractsTitle(count: number) {
    Array.from({ length: count + 1 }).forEach(() => {
      cy.cClick(
        OR_COMBINED_CODING.CONTRACTS_TITLE[1],
        OR_COMBINED_CODING.CONTRACTS_TITLE[0],
        false,
        false,
        { force: true }
      );
    });
  }

  /**
   * @detail - Verifying write-Off amount
   * @param amount to be entered
   * @Api - API's are not available
   */
  verifyWriteOffAmount(amount: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT_VALUE[1],
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT_VALUE[0],
      amount
    );
  }

  /**
   * @detail - to click on any field label in combined coding charge tab
   * @param label - Provide label name to click on that specific label in charge tab
   * @Api - API's are not available
   */
  clickOnMandatoryFieldLabel(label: string) {
    cy.cGet(selectorFactory.mandatoryFields(label))
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible)
      .click();
  }

  /**
   * selecting revenue code in Combined Coding
   * @param - revenueCode to be selected
   * @Api - API's are not available
   */
  selectRevenueCode(revenueCode: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_COMBINED_CODING.CHARGE.REVENUE_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REVENUE_CODE[0],
      false,
      true
    );
    cy.cType(
      OR_COMBINED_CODING.CHARGE.REVENUE_CODE_INPUT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REVENUE_CODE[0],
      revenueCode
    );
    cy.cClick(
      selectorFactory.getDropdownValues(revenueCode),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REVENUE_CODE[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To verify Amount added in added procedure
   * @param value - Provide amount value to verify
   * @Api - API's are not available
   */
  verifyAmountInAddedProcedure(value: string) {
    cy.cHasValue(
      OR_COMBINED_CODING.CHARGE.AMOUNT_PROCEDURE[1],
      OR_COMBINED_CODING.CHARGE.AMOUNT_PROCEDURE[0],
      value
    );
  }

  /**
   * @details - To verify discount in added procedure
   * @param value of balance to be verified
   * @Api - API's are not available
   */
  verifyBalanceInAddedProcedure(value: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.BALANCE_PROCEDURE[1],
      OR_COMBINED_CODING.CHARGE.BALANCE_PROCEDURE[0],
      value
    );
  }

  /**
   * @details - To verify amount in adjustment tab
   * @param value of amount to be verified
   * @Api - API's are not available
   */
  verifyAmountInAdjustmentTab(value: string) {
    cy.cIsVisible(selectorFactory.debitAmountCombinedCoding(value), value);
  }

  /**
   * @details - To update units in the charges section
   * @param value
   * @Api - API's are not available
   */
  updateUnits(value: string) {
    cy.cType(
      OR_COMBINED_CODING.CHARGE.UNITS[1],
      OR_COMBINED_CODING.CHARGE.UNITS[0],
      value,
      false,
      true
    );
    cy.cClick(
      OR_COMBINED_CODING.CHARGE.UNITS[0],
      OR_COMBINED_CODING.CHARGE.UNITS[0],
      true
    );
  }

  /**
   * @detail - Verifying NDC amount
   * @param amount
   * @Api - API's are not available
   */
  verifyNDCAmount(amount: string) {
    cy.cHasValue(
      OR_COMBINED_CODING.CHARGE.NDC_INPUT[1],
      OR_COMBINED_CODING.CHARGE.NDC_INPUT[0],
      amount
    );
  }

  /**
   * @detail - To verify period warning text
   * @param patient - the patient first name,last name using PatientCase model
   * @Api - API's are not available
   */
  verifyPeriodWarning(patient: PatientCase) {
    sisOfficeDesktop.selectPatientRow(
      patient.PatientDetails.PatientFirstName!,
      patient.PatientDetails.LastName!
    );
    cy.cIsVisible(
      selectorFactory.getSpanText(CodingPopUpText.select_period),
      CodingPopUpText.select_period
    );
    cy.cClick(
      OR_CASES_TO_CODE.CODING.OK_BUTTON[0],
      OR_CASES_TO_CODE.CODING.OK_BUTTON[0],
      true,
      true
    );
  }

  /**
   * @detail - To verify CPT procedures in Scheduled Procedures/Billable Supplies table
   * @param charge - charge information using Charges model
   * @Api - API's are not available
   */
  verifyCPTInBillableSupplies(charge: Charges) {
    cy.cIsVisible(
      selectorFactory.getSpanText(
        OR_COMBINED_CODING.SCHEDULED_PROCEDURES_BILLABLE_SUPPLIES[0]
      ),
      OR_COMBINED_CODING.SCHEDULED_PROCEDURES_BILLABLE_SUPPLIES[0]
    );
    cy.cIsVisible(charge.CPT!, charge.CPT!, true, true);
    cy.cIsVisible(charge.Physician!, charge.Physician!, true, true);
    cy.cHasAttribute(
      OR_COMBINED_CODING.SCHEDULED_PROCEDURES_BILLABLE_SUPPLIES[1],
      OR_COMBINED_CODING.SCHEDULED_PROCEDURES_BILLABLE_SUPPLIES[0],
      InvokeAttributes.aria_expanded,
      TrueOrFalse.true
    );
  }

  /**
   * @detail - To verify performed items is displayed after add selected to perform
   * @param none
   * @Api - API's are not available
   */
  verifyPerformedItems() {
    this.selectAllProcedureCheckbox();
    this.addSelectedToPerformed();
    cy.cIncludeText(
      OR_COMBINED_CODING.PERFORMED_ITEMS[1],
      OR_COMBINED_CODING.PERFORMED_ITEMS[0],
      OR_COMBINED_CODING.PERFORMED_ITEMS[0]
    );
  }

  /**
   * @detail - To verify charge and adjustment button behavior
   * @param option - Charge or Adjustment to be provided
   * @Api - API's are not available
   */
  verifyChargeAdjustmentButton(option: string) {
    cy.cHasAttribute(
      selectorFactory.getChargeAdjustmentButton(option),
      option,
      InvokeAttributes.ariaPressed,
      TrueOrFalse.true
    );
  }

  /**
   * @detail - To verify performed items header labels
   * @param none
   * @Api - API's are not available
   */
  verifyPerformedItemsHeader() {
    performedItemsHeaders.forEach((val, index) => {
      cy.cGet(OR_COMBINED_CODING.PERFORMED_ITEMS_HEADERS[1])
        .eq(index)
        .should(ShouldMethods.include_text, val);
    });
  }

  /**
   * @detail - To select the insurance carrier from the dropdown
   * @param option - To provide the type of insurance - Primary, Secondary, Tertiary
   * @Api - API's are not available
   */
  clickInsuranceDropDown(option: string) {
    let locator = '';
    switch (option) {
      case OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0]:
        locator = OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[1];
        break;
      case OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[0]:
        locator = OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[1];
        break;
      case OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[0]:
        locator = OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[1];
        break;
      default:
        break;
    }
    cy.cClick(
      selectorFactory.clickInsuranceLabelCombinedCoding(
        OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[0]
      ),
      option
    );
    cy.shouldBeEnabled(locator);
    cy.cClick(locator, option, false, true, { force: true });
  }

  /**
   * @detail - To verify whether the self pay option is toggled as - Yes/No
   * @param value - To provide value as Yes or No
   * @Api - API's are not available
   */
  verifySelfPay(value: string) {
    cy.cGet(OR_COMBINED_CODING.CHARGE.SELF_PAY[1]).scrollIntoView();
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.SELF_PAY[1],
      OR_COMBINED_CODING.CHARGE.SELF_PAY[0],
      value,
      false,
      true
    );
  }

  /**
   * @detail - To verify the insurance carrier values
   * @param type - Insurance type to be provided, Primary,Secondary,Tertiary
   * @param value - Insurance carrier name value to be provided
   * @Api - API's are not available
   */
  verifyInsuranceValue(type: string, value: string) {
    switch (type) {
      case HierarchyOptions.primary:
        cy.cIncludeText(
          OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[1],
          OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0],
          value
        );
        break;
      case HierarchyOptions.secondary:
        cy.cIncludeText(
          OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[1],
          OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[0],
          value
        );
        break;
      case HierarchyOptions.tertiary:
        cy.cIncludeText(
          OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[1],
          OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[0],
          value
        );
        break;
      default:
        break;
    }
  }

  /**
   * @detail - To verify default values as per patient creation
   * @param value - values to be called using Charges model
   * @Api - API's are not available
   */
  verifyChargeDefaultValues(value: Charges) {
    cy.cIncludeText(
      OR_COMBINED_CODING.PERIOD_VALUE[1],
      OR_COMBINED_CODING.PERIOD_VALUE[0],
      value.Period
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.BATCH_VALUE[1],
      OR_COMBINED_CODING.BATCH_VALUE[0],
      value.Batch
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.PHYSICIAN[1],
      OR_COMBINED_CODING.CHARGE.PHYSICIAN[0],
      value.Physician!
    );
    cy.cHasValue(
      OR_COMBINED_CODING.CHARGE.TYPE_OF_BILL[1],
      OR_COMBINED_CODING.CHARGE.TYPE_OF_BILL[0],
      value.TypeOfBill!,
      false,
      true
    );
    cy.cIsVisible(
      OR_COMBINED_CODING.CHARGE.GENERATE_BILL_CHECKBOX[1],
      OR_COMBINED_CODING.CHARGE.GENERATE_BILL_CHECKBOX[0]
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.BALANCE[1],
      OR_COMBINED_CODING.CHARGE.BALANCE[0],
      value.Balance!,
      false,
      true
    );
    cy.cHasValue(
      OR_COMBINED_CODING.CHARGE.UNITS[1],
      OR_COMBINED_CODING.CHARGE.UNITS[0],
      value.Units!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.DISCOUNT[1],
      OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
      value.Discounts!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.REVENUE_CODE[1],
      OR_COMBINED_CODING.CHARGE.REVENUE_CODE[0],
      value.RevenueCode!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[1],
      OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0],
      value.PrimaryInsurance!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[1],
      OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[0],
      value.SecondaryInsurance!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[1],
      OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[0],
      value.TertiaryInsurance!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.PRIMARY_GUARANTOR[1],
      OR_COMBINED_CODING.CHARGE.PRIMARY_GUARANTOR[0],
      value.PrimaryGuarantor!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.SECONDARY_GUARANTOR[1],
      OR_COMBINED_CODING.CHARGE.SECONDARY_GUARANTOR[0],
      value.SecondaryGuarantor!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.SELF_PAY[1],
      OR_COMBINED_CODING.CHARGE.SELF_PAY[0],
      value.SelfPay!,
      false,
      true
    );
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.WORKERS_COMPENSATION[1],
      OR_COMBINED_CODING.CHARGE.WORKERS_COMPENSATION[0],
      value.WorkersCompensation!,
      false,
      true
    );
  }

  /**
   * @detail - To select period and add new batch
   * @param period - To provide the period name
   * @param batch - To provide the batch name
   * @Api - API's are available - Implemented Completely
   * @author Arushi
   */
  selectPeriodAddNewBatch(period: string, batch: string) {
    const interceptCollection =
      this.combinedCodingApis.interceptDoneInAddNewBatch();
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    cy.cRemoveMaskWrapper(Application.office);
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[1],
        '',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      )
    );
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cClick(selectorFactory.getSpanText(addNewItem), addNewItem);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH_TEXT_INPUT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH_TEXT_INPUT[0],
      batch
    );
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.clickDoneButtonPopup();
    cy.cWaitApis(interceptCollection);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @detail - Performing scroll action to last row in table
   * @Api - API's are not available
   */
  scrollToLastRowInTracker() {
    cy.cGet(OR_COMBINED_CODING.ROWS[1]).last().scrollIntoView();
  }

  /**
   * @details - To verify balance in added supplied procedure
   * @param value
   * @Api - API's are not available
   */
  verifyBalance(value: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.BALANCE[1],
      OR_COMBINED_CODING.CHARGE.BALANCE[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - selecting period and batch Labels in Combined Coding
   * @Api - API's are not available
   */
  clickPeriodAndBatchLabel() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getLabelText(OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getLabelText(OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
  }

  /**
   * @details - Entering the period, batch and selecting the patient in the Combined Coding tracker
   * @Api - API's are available - Implemented Completely
   */
  selectCase(chargesInfo: Charges, patientCaseInfo: PatientCase) {
    const interceptCollection =
      this.combinedCodingApis.interceptSelectCaseButtonApi();
    this.selectPeriodAndBatch(chargesInfo);
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectPatientRow(
      patientCaseInfo.PatientDetails.LastName!,
      patientCaseInfo.PatientDetails.PatientFirstName!
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - Verify discount value in charge tab
   * @Api - API's are not available
   */
  verifyDiscountInChargeTab(value: string) {
    // Validating the delete discount icon(x) in order to add additional assertion after selecting discount
    cy.cGet(OR_COMBINED_CODING.CHARGE.CLEAR_DISCOUNT[1])
      .trigger(TriggerAttributes.mouseover)
      .should(ShouldMethods.visible);
    cy.shouldBeEnabled(OR_COMBINED_CODING.CHARGE.CLEAR_DISCOUNT[1]);
    cy.cGet(OR_COMBINED_CODING.CHARGE.DISCOUNT[1])
      .trigger(TriggerAttributes.mouseover)
      .should(ShouldMethods.visible);
    cy.cIncludeText(
      OR_COMBINED_CODING.CHARGE.DISCOUNT[1],
      OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify Documentation Header
   * @param documentHeader passed to verify header
   * @Api - API's are not available
   */
  verifyDocumentationHeader(documentHeader: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.DOCUMENTATION_HEADER[1],
      OR_COMBINED_CODING.DOCUMENTATION_HEADER[0],
      documentHeader
    );
  }

  /**
   * @details - Verify Op Notes
   * @param opNotes passed to verify Op notes
   * @Api - API's are not available
   */
  verifyOpNotes(opNotes: string) {
    cy.cIncludeText(
      selectorFactory.getSpanClassText(opNotes),
      OR_COMBINED_CODING.OP_NOTES[0],
      opNotes
    );
  }

  /**
   * @details - Verify Progress Bar
   * @Api - API's are not available
   */
  verifyProgressionBar() {
    cy.cGet(OR_COMBINED_CODING.PROGRESS_BAR[1])
      .first()
      .should(ShouldMethods.visible);
  }

  /**
   * @details - Verify OpNotes under Progress Bar
   * @param opNotes passed to verify Op notes text
   * @Api - API's are not available
   */
  verifyOpNotesUnderProgressBar(opNotes: string) {
    cy.cIsVisible(
      selectorFactory.opNotesUnderProgressionBar(opNotes),
      OR_COMBINED_CODING.OP_NOTES[0]
    );
  }

  /**
   * @detail - To verify the additional claim information label
   * @param - value as parameter to pass in the function
   * @Api - API's are not available
   */
  verifyAdditionalClaimInformation(value: string) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[1]
    ).then(($labelName) => {
      cy.wrap($labelName.text()).should(ShouldMethods.contain, value);
    });
  }

  /**
   * @detail -To click on the additional claim information button
   * @param value as parameter in the function
   * @APIs are Available - Implemented Completely
   */
  clickAdditionalClaimInformation(value: string) {
    const interceptCollection =
      this.combinedCodingApis.interceptClickAdditionalClaimInformationbtnApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(value), value);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To enter the data in the fields in UB tab in Additional Claim Information popup
   * @param ubAdditionalClaimInfo model as arguments passed inside of the function
   * @Api - API's are not available
   */
  enterDataInUbFields(ubAdditionalClaimInfo: UBAdditionalClaim) {
    ubFields.forEach((value, index) => {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_ADD_CLAIM_SECTION[1])
        .eq(index)
        .within(() => {
          cy.contains(value).then(() => {
            switch (value) {
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .CONDITIONAL_CODES[0]:
                this.addUbAdditionalClaimCodes(ubAdditionalClaimInfo);
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .OCCURRENCE_SPAN_CODES_DATE_INFO[0]:
                this.addUbAdditionalOccurrenceSpanCodeDate(
                  ubAdditionalClaimInfo
                );
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .OCCURRENCE_CODES_DATE_INFO[0]:
                this.addUbAdditionalOccurrenceCodeDatesInfo(
                  ubAdditionalClaimInfo
                );
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_NOTE_INFO[0]:
                this.addUbAdditionalClaimNoteInfo(ubAdditionalClaimInfo);
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ECI_CODES[0]:
                this.addUbAdditionalClaimCodes(ubAdditionalClaimInfo);
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.REASON_CODES[0]:
                this.addUbAdditionalClaimCodes(ubAdditionalClaimInfo);
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .VALUE_CODES_AMOUNT_INFO[0]:
                this.addUbAdditionalValueCodeAmountInfo(ubAdditionalClaimInfo);
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .CLAIM_SUPPLEMENTAL_INFO[0]:
                this.addUbAdditionalClaimSupplementalInfo(
                  ubAdditionalClaimInfo
                );
                break;
              default:
                break;
            }
          });
        });
    });
  }

  /**
   * @details - To add the additional claim data related to Codes under UB tab in Additional Claim information popup.
   * @param - ubAdditionalClaimInfo as passing the model reference inside the function
   * @Api - API's are not available
   */
  addUbAdditionalClaimCodes(ubAdditionalClaimInfo: UBAdditionalClaim) {
    if (ubAdditionalClaimInfo.Code ?? '') {
      cy.cClick(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
      );
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1])
        .invoke(InvokeMethods.attribute, CommonClassAttributes.maxlength)
        .should(ShouldMethods.contain, maxFieldLength);

      cy.cClick(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[0]
      );
      cy.cType(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[0],
        ubAdditionalClaimInfo.Code
      );
    }
  }

  /**
   * @details To add the data in Occurrence Span Codes under UB tab in Additional Claim information popup.
   * @param ubAdditionalClaimInfo as model reference passed in the function
   * @Api - API's are not available
   */
  addUbAdditionalOccurrenceSpanCodeDate(
    ubAdditionalClaimInfo: UBAdditionalClaim
  ) {
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
    );
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[0]
    );

    if (ubAdditionalClaimInfo.Code ?? '') {
      cy.cType(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[0],
        ubAdditionalClaimInfo.Code
      );
    }

    if (ubAdditionalClaimInfo.Date ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_DATE_FILED[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.Date ?? '');
    }

    if (ubAdditionalClaimInfo.Dateto ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_DATE_FILED[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.Dateto ?? '');
    }
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
    );
  }

  /**
   * @details - Verify Implant Log  Header
   * @param implantLog passed to verify Implant log Header
   * @Api - API's are not available
   */
  verifyImplantLog(implantLog: string) {
    cy.cIncludeText(
      selectorFactory.getSpanClassText(implantLog),
      OR_COMBINED_CODING.IMPlANT_LOG[0],
      implantLog
    );
  }

  /**
   * @details - Verifying writeOff amount in adjustment tab
   * @param  amount that needs to be verified in writeOff amount field
   * @API - API's are not available
   */
  verifyWriteOffAmountValue(amount: string) {
    cy.cIncludeText(
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[1],
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
      amount
    );
  }

  /**
   * @details - Click on Implant Log
   * @param implantLog passed to click
   * @Api - API's are not available
   */
  clickOnImplantLog(implantLog: string) {
    cy.cClick(
      selectorFactory.getSpanClassText(implantLog),
      OR_COMBINED_CODING.IMPlANT_LOG[0]
    );
  }

  /**
   * @details - Verify Implant Scroll Bar
   * @Api - API's are not available
   */
  verifyImplantScrollBar() {
    cy.cIsVisible(
      OR_COMBINED_CODING.IMPLANT_SCROLLPANEL[1],
      OR_COMBINED_CODING.IMPLANT_SCROLLPANEL[0]
    );
  }

  /**
   * @details - Verify Implant Details
   * @param header passed to verify details
   * @Api - API's are not available
   */
  verifyImplantText(header: string | number) {
    cy.cGet(selectorFactory.getImplantDetailHeader(header))
      .first()
      .should(ShouldMethods.visible);
  }

  /**
   * @details - Verify Opnotes is Not exist
   * @param opNotes passed to verify Op notes
   * @Api - API's are not available
   */
  verifyOpNotesNotExist(opNotes: string) {
    cy.cNotExist(
      selectorFactory.getSpanClassText(opNotes),
      OR_COMBINED_CODING.OP_NOTES[0]
    );
  }

  /**
   * @details - Verify Units in Charge
   * @param units passed to verify units
   * @Api - API's are not available
   */
  verifyUnits(units: string) {
    cy.cHasValue(
      OR_COMBINED_CODING.UNITS[1],
      OR_COMBINED_CODING.UNITS[0],
      units
    );
  }

  /**
   * @details - Clear HCPCS code in Charge
   * @Api - API's are not available
   */
  deleteHCPCS() {
    cy.cClick(
      OR_COMBINED_CODING.CLEAR_HCPCS[1],
      OR_COMBINED_CODING.CLEAR_HCPCS[0],
      false,
      false,
      { force: true }
    );
  }

  /**
   * @details - Enter HCPCS code name and Click on Item
   * @param implantName passed to search and select
   * @Api - API's are not available
   */
  enterHCPCScode(implantName: string) {
    cy.cType(
      OR_COMBINED_CODING.IMPLANT_NAME[1],
      OR_COMBINED_CODING.IMPLANT_NAME[0],
      implantName
    );
    cy.cClick(
      OR_COMBINED_CODING.INVENTORY_ITEM[1],
      OR_COMBINED_CODING.INVENTORY_ITEM[0]
    );
  }

  /**
   * @details To add the data in Occurrence Codes and Date Information under UB tab in Additional Claim information popup.
   * @param ubAdditionalClaimInfo as model reference passed as argument inside the function
   * @Api - API's are not available
   */
  addUbAdditionalOccurrenceCodeDatesInfo(
    ubAdditionalClaimInfo: UBAdditionalClaim
  ) {
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
    );
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[0]
    );

    if (ubAdditionalClaimInfo.Code ?? '') {
      cy.cType(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[0],
        ubAdditionalClaimInfo.Code
      );
    }

    if (ubAdditionalClaimInfo.Date ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_DATE_FILED[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.Date ?? '');
    }
  }

  /**
   * @details To add the data in Claim Notes Information under UB tab in Additional Claim information popup.
   * @param ubAdditionalClaimInfo as model reference passed as argument inside the function
   * @Api - API's are not available
   */
  addUbAdditionalClaimNoteInfo(ubAdditionalClaimInfo: UBAdditionalClaim) {
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
    );

    if (ubAdditionalClaimInfo.NoteReference ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.NoteReference ?? '');
    }

    if (ubAdditionalClaimInfo.Description ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.Description ?? '');
    }
  }

  /**
   * @details To add the data in Value Codes & Amount Information under UB tab in Additional Claim information popup.
   * @param ubAdditionalClaimInfo as model reference passed as argument inside the function
   * @Api - API's are not available
   */
  addUbAdditionalValueCodeAmountInfo(ubAdditionalClaimInfo: UBAdditionalClaim) {
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
    );

    if (ubAdditionalClaimInfo.Code ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.Code!.toString());
    }

    if (ubAdditionalClaimInfo.Amount ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.Amount ?? '');
    }
  }

  /**
   * @details To add the data in Claim Supplemental Information under UB tab in Additional Claim information popup.
   * @param ubAdditionalClaimInfo as model reference passed as argument inside the function
   * @Api - API's are not available
   */
  addUbAdditionalClaimSupplementalInfo(
    ubAdditionalClaimInfo: UBAdditionalClaim
  ) {
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
    );

    if (ubAdditionalClaimInfo.ReportTo ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.ReportTo ?? '');
    }

    if (ubAdditionalClaimInfo.TransmissionCode ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.TransmissionCode ?? '');
    }

    if (ubAdditionalClaimInfo.ClaimControl ?? '') {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1])
        .first()
        .click()
        .type(ubAdditionalClaimInfo.ClaimControl ?? '');
    }
  }

  /**
   * @details - To verify the header name of Additional Claim Information popup
   * @param headerValues as string array passed in the function
   * @Api - API's are not available
   */
  verifyUbAdditionalClaimHeaders(headerValues: string[]) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_ADD_CLAIM_HEADERS[1]
    ).each(($headerNames, index) => {
      expect($headerNames.text().trim()).to.contain(headerValues[index]);
    });
  }

  /**
   * @details - To verify the label names in Additional Claim Information popup
   * @param labelValues as argument passed in the function.
   * @Api - API's are not available
   */
  verifyUbAdditionalClaimLabels(labelValues: string[]) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_ADD_CLAIM_SUB_HEADERS[1]
    ).each(($labels, index) => {
      expect($labels.text().trim()).to.contains(labelValues[index]);
    });
  }

  /**
   * @details - To check the UB additional claim data
   * @param value as argument passed inside of the function
   * @Api - API's are not available
   */
  additionalUbClaimData(value: string) {
    if (value ?? '') {
      cy.cClick(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
      );
      cy.cGet(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_FILLED_TEXT[1]
      ).should(ShouldMethods.contain_text, value);
    }
  }

  /**
   * @details - To select the additional claim information tabs
   * @param - tabName as argument passed in the function
   * @API - API's are not available
   */
  selectAdditionalClaimInfoTabs(tabName: string) {
    cy.cClick(selectorFactory.getSpanText(tabName), tabName);
  }

  /**
   * @details - To click on the Done button in Additional Claim Information popup
   * @APIs are Available - Implemented Completely
   */
  selectAdditionalClaimInfoDone() {
    const interceptCollection =
      this.combinedCodingApis.interceptAdditionalClaimInfoDoneBtnApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.DONE[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.DONE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify additional claim information header text is not presence
   * @param headerName - as argument passed inside the function
   * @Api - API's are not available
   */
  verifyAdditionClaimInformationPopup(headerName: string) {
    cy.cNotExist(selectorFactory.getHeaderText(headerName), headerName);
  }

  /**
   * @details - To verify the labels in HCFA tab in additional claim information popup
   * @param - labelValues as argument passed in the function
   * @Api - API's are not available
   */
  verifyHcfaProfessionalLabels(labelValues: string[]) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_LABELS[1]
    ).each(($labels, index) => {
      cy.wrap($labels.text().trim()).should(
        ShouldMethods.contain,
        labelValues[index]
      );
    });
  }

  /**
   * @details - To verify the additional claim data in HCFA tab based on the fields in additional claim information popup
   * @param hcfaAdditionClaimInfo model as arguments passed in the function.
   * @Api - API's are not available
   */
  verifyHcfaAdditionalClaimData(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    const hcfaFields = [
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CONDITIONAL_CODES[0],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_SUPPLEMENTAL_INFO[0],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_NOTE_INFO[0],
    ];

    hcfaFields.forEach((value, index) => {
      cy.cGet(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
      )
        .eq(index)
        .within(() => {
          switch (value) {
            case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CONDITIONAL_CODES[0]:
              cy.contains(value).then(() => {
                this.additionalClaimDataInHcfa(hcfaAdditionClaimInfo.Code!);
              });
              break;
            case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
              .CLAIM_SUPPLEMENTAL_INFO[0]:
              this.additionalClaimDataInHcfa(hcfaAdditionClaimInfo.ReportTo!);
              this.additionalClaimDataInHcfa(
                hcfaAdditionClaimInfo.TransmissionCode!
              );
              this.additionalClaimDataInHcfa(hcfaAdditionClaimInfo.Control!);
              break;
            case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_NOTE_INFO[0]:
              this.additionalClaimDataInHcfa(
                hcfaAdditionClaimInfo.NoteReference!
              );
              this.additionalClaimDataInHcfa(
                hcfaAdditionClaimInfo.Description!
              );
              break;
          }
        });
    });
  }

  /**
   * @details - To check the additional claim data in HCFA tab.
   * @param - value as argument passed in the function.
   * @Api - API's are not available
   */
  additionalClaimDataInHcfa(value: string | number) {
    if (value ?? '') {
      cy.cClick(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
      );
      cy.cGet(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_FILLED_TEXT[1]
      ).then(($data) => {
        cy.wrap($data.text().trim()).should(ShouldMethods.contain, value);
      });
    }
  }

  /**
   * @details To add the values in claim supplemental information in HCFA tab
   * @param hcfaAdditionClaimInfo as model reference passed in the function
   * @Api - API's are not available
   */
  addHcfaAdditionalClaimSupplementalInfo(
    hcfaAdditionClaimInfo: HCFAAdditionalClaim
  ) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
    )
      .eq(1)
      .within(() => {
        cy.contains(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_SUPPLEMENTAL_INFO[0]
        ).then(() => {
          cy.cClick(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
          );
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1]
          )
            .first()
            .click()
            .type(hcfaAdditionClaimInfo.ReportTo ?? '');
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1]
          )
            .first()
            .click()
            .type(hcfaAdditionClaimInfo.TransmissionCode ?? '');
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1]
          )
            .first()
            .click()
            .type(hcfaAdditionClaimInfo.Control ?? '');
        });
      });
  }

  /**
   * @details - To click on the trash icon in conditional codes in HCFA tab in additional claim information popup
   * @param - row as argument passed in the function.
   * @Api - API's are not available
   */
  clickConditionCodeTrashIconInHcfa(row: number) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
    )
      .first()
      .within(() => {
        cy.cGet(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TRASH_ICON[1]
        )
          .eq(row)
          .invoke(InvokeMethods.show)
          .click({ force: true });
      });
  }

  /**
   * @details To add the values in claim notes information in HCFA tab
   * @param hcfaAdditionClaimInfo as model reference passed in the function
   * @Api - API's are not available
   */
  addHcfaAdditionalClaimNotesInfo(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
    )
      .eq(2)
      .within(() => {
        cy.contains(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_NOTE_INFO[0]
        ).then(() => {
          cy.cClick(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
          );
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1]
          )
            .first()
            .click()
            .type(hcfaAdditionClaimInfo.NoteReference ?? '');
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TEXT_FIELDS[1]
          )
            .first()
            .click()
            .type(hcfaAdditionClaimInfo.Description ?? '');
        });
      });
  }

  /**
   * @details - To add the codes under HCFA tab in additional claim information popup
   * @param - hcfaAdditionClaimInfo as model reference passed in the function
   * @Api - API's are not available
   */
  addHcfaAdditionalClaimCodes(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
    )
      .eq(0)
      .within(() => {
        cy.contains(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CONDITIONAL_CODES[0]
        ).then(() => {
          cy.cClick(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
          );
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1]
          )
            .invoke(InvokeMethods.attribute, CommonClassAttributes.maxlength)
            .then(($fieldLength) => {
              cy.wrap($fieldLength).should(
                ShouldMethods.contain,
                maxFieldLength
              );
            });
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1]
          )
            .click()
            .type(hcfaAdditionClaimInfo.Code!.toString());
        });
      });
  }

  /**
   * @details - To verify the entered the data in HCFA tab in additional claim information popup
   * @param flag as arguments passed in the function
   * @API - API's are not available
   */
  verifyHcfaDateFields(flag: boolean = true) {
    const hcfaDateFields = [
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_FIRST_OCCURRENCE[0],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DATE_OF_ONSET[0],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_INITIAL_TREATMENT[0],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_FROM_DATE[0],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_THROUGH[0],
    ];

    hcfaDateFields.forEach((value) => {
      if (hcfaDateFields.includes(value)) {
        cy.cGet(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DATE_FIELDS_FILLED[1]
        )
          .invoke(InvokeMethods.attribute, InvokeAttributes.class)
          .then(($classValue) => {
            flag
              ? expect($classValue).to.contains(
                  OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                    .HCFA_DATE_FIELDS_FILLED[0]
                )
              : cy
                  .wrap($classValue)
                  .should(
                    ShouldMethods.not_contain,
                    OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                      .HCFA_DATE_FIELDS_FILLED[0]
                  );
          });
      }
    });
  }

  /**
   * @details - To verify the additional claim data in HCFA tab based on the fields in additional claim information popup
   * @param hcfaAdditionClaimInfo,index model as arguments passed in the function.
   * @API - API's are not available
   */
  verifyConditionCodesHCFA(
    hcfaAdditionClaimInfo: HCFAAdditionalClaim,
    index: number
  ) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
    )
      .first()
      .within(() => {
        cy.contains(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CONDITIONAL_CODES[0]
        )
          .eq(index)
          .then(() => {
            this.additionalClaimDataInHcfa(hcfaAdditionClaimInfo.Code!);
          });
      });
  }

  /**
   * @details - To verify the additional claim data in HCFA tab based on the fields in additional claim information popup
   * @param hcfaAdditionClaimInfo model as arguments passed in the function.
   * @API - API's are not available
   */
  verifyClaimSupplementalInfo(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    const claimInfo = [
      hcfaAdditionClaimInfo.ReportTo ?? '',
      hcfaAdditionClaimInfo.TransmissionCode!,
      hcfaAdditionClaimInfo.Control!,
    ];
    claimInfo.forEach((val, index) => {
      cy.cGet(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
      )
        .eq(1)
        .within(() => {
          cy.contains(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_SUPPLEMENTAL_INFO[0]
          ).then(() => {
            cy.cClick(
              OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
              OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
            );
            cy.cGet(
              OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_FILLED_TEXT[1]
            )
              .eq(index)
              .within(($data) => {
                cy.wrap($data.text().trim()).should(ShouldMethods.contain, val);
              });
          });
        });
    });
  }

  /**
   * @details - To verify the additional claim data in HCFA tab based on the fields in additional claim information popup
   * @param hcfaAdditionClaimInfo model as arguments passed in the function.
   * @API - API's are not available
   */
  verifyClaimNoteInfo(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    const claimNote = [
      hcfaAdditionClaimInfo.NoteReference!,
      hcfaAdditionClaimInfo.Description!,
    ];
    claimNote.forEach((val, index) => {
      cy.cGet(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
      )
        .eq(2)
        .within(() => {
          cy.contains(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_NOTE_INFO[0]
          ).then(() => {
            cy.cClick(
              OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
              OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
            );
            cy.cGet(
              OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_FILLED_TEXT[1]
            )
              .eq(index)
              .within(($data) => {
                cy.wrap($data.text()).should(ShouldMethods.contain, val);
              });
          });
        });
    });
  }

  /**
   * @details - click on Insurance cross icon in charges tab
   * @APIs are Available - Implemented Completely
   */
  clickOnInsuranceCrossIcon() {
    const interceptCollection =
      this.combinedCodingApis.interceptClickInsuranceCarrierApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_COMBINED_CODING.INSURANCE_CROSS_ICON[1],
      OR_COMBINED_CODING.INSURANCE_CROSS_ICON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verifying performed items label
   * @API - API's are not available
   */
  verifyPerformedItem() {
    cy.cIsVisible(
      OR_COMBINED_CODING.PERFORMED_ITEMS[1],
      OR_COMBINED_CODING.PERFORMED_ITEMS[0]
    );
  }

  /**
   * @details - Enter Units in Charge
   * @param  units that needs to be entered
   * @API - API's are not available
   */
  enterUnits(units: string) {
    cy.cType(OR_COMBINED_CODING.UNITS[1], OR_COMBINED_CODING.UNITS[0], units);
  }

  /**
   * @details - Verifying patient in patient label
   * @param patientFullName as parameters inside the function
   * @API - API's are not available
   */
  verifyPatientInPatientPanel(patientFullName: string) {
    cy.cIsVisible(OR_COMBINED_CODING.PATIENT_INFO[1], patientFullName);
  }

  /**
   * @details - Verify charge details in combined coding
   * @API - API's are not available
   */
  assertCombinedCodingChargeDetails() {
    const fields = [
      OR_COMBINED_CODING.PERIOD_LABEL[1],
      OR_COMBINED_CODING.BATCH_LABEL[1],
      OR_COMBINED_CODING.CHARGE.DISCOUNT[1],
      selectorFactory.getSpanText(chargeDetails[0]),
      selectorFactory.getSpanText(chargeDetails[1]),
      selectorFactory.getSpanText(chargeDetails[2]),
    ];
    fields.forEach((field) => {
      cy.shouldBeEnabled(field);
    });
  }

  /**
   * @detail - To click the self pay option is toggled as - Yes/No
   * @param value - To provide value as Yes or No
   * @API - API's are not available
   */
  clickSelfPay(value: YesOrNo) {
    const interceptCollection =
      this.combinedCodingApis.interceptSelfPayYesApi();
    if (value == YesOrNo.yes) {
      cy.cIntercept(interceptCollection);
      cy.cClick(OR_COMBINED_CODING.CHARGE.SELF_PAY_YES[1], value);
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cClick(OR_COMBINED_CODING.CHARGE.SELF_PAY_NO[1], value);
    }
  }

  /**
   * @details - To edit the data of conditional codes in HCFA tab in additional claim information popup
   * @param - label as argument passed in the function.
   * @param - value as argument passed in the function.
   * @param - index as argument passed in the function.
   * @API - API's are not available
   */
  editConditionalCodeInHcfa(label: string, value: string, index: number) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
    )
      .first()
      .within(() => {
        cy.contains(label).then(() => {
          cy.cGet(
            OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_FILLED_TEXT[1]
          )
            .eq(index)
            .then(($data) => {
              cy.wrap($data).invoke(InvokeMethods.show).click();
            });
        });
        cy.cClick(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1],
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[0]
        );
        cy.cGet(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_INFO_INPUT[1]
        )
          .clear({ force: true })
          .focus()
          .type(value, { force: true });
        cy.cClick(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[1],
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_PLUS_ICON[0]
        );
      });
  }

  /**
   * @details - To click on the trash icon for code fields in HCFA tab in additional claim information popup
   * @param row - to provide the row index value
   * @param index - index 0 - Condition Codes, index 1 - Claim Supplemental Information, index 2 - Claim Note Information
   * @API - API's are not available
   */
  clickCodeFieldsTrashIconHCFA(row: number, index: number) {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_CODE_FIELDS[1]
    )
      .eq(index)
      .within(() => {
        cy.cGet(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADD_CLAIM_TRASH_ICON[1]
        )
          .eq(row)
          .invoke(InvokeMethods.show)
          .click({ force: true });
      });
  }

  /**
   * @details - To verify hover text for clinical trial #
   * @param data - To verify the data entered in clinical trial # input field
   * @API - API's are not available
   */
  verifyClinicalTrial(data: string) {
    cy.cIsVisible(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLINICAL_TRIAL_TEXT[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLINICAL_TRIAL_TEXT[0]
    );
    cy.cHasValue(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLINICAL_TRIAL_TEXT_INPUT[1],
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLINICAL_TRIAL_TEXT_INPUT[0],
      data
    );
  }

  /**
   * @detail - To select the insurance carrier from the dropdown
   * @param option - To provide the type of insurance - Primary, Secondary, Tertiary
   * @param - state - To verify properties are enable or disable
   * @API - API's are not available
   */
  verifyInsuranceDropDownState(option: string, state: EnableOrDisable) {
    let locator = '';
    switch (option) {
      case OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0]:
        locator =
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .PRIMARY_INSURANCE[1];
        break;
      case OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[0]:
        locator =
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .SECONDARY_INSURANCE[1];
        break;
      case OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[0]:
        locator =
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .TERTIARY_INSURANCE[1];
        break;
      default:
        break;
    }
    const locProperties = {
      [EnableOrDisable.enable]: CommonUtils.concatenate(
        locator,
        ' ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
      [EnableOrDisable.disable]: CommonUtils.concatenate(
        locator,
        ' ',
        CoreCssClasses.Style.loc_p_disabled
      ),
    };
    cy.cIsVisible(locProperties[state], option);
  }

  /**
   * @detail - To verify Billing Procedure Description label, max-length and tooltip
   * @API - API's are not available
   */
  verifyBillingProcedureDescriptionField() {
    cy.cIsVisible(
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[0],
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[0],
      true
    );
    cy.cIsVisible(
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[1],
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[0]
    );
    cy.cGet(
      selectorFactory.getSpanText(
        OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[0]
      )
    )
      .first()
      .within(() => {
        cy.cGet(CommonGetLocators.i).should(
          InvokeMethods.attribute,
          InvokeAttributes.p_tool_tip,
          AppToolTip.billing_procedure_description
        );
      });
    cy.cHasAttribute(
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[1],
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[0],
      CommonClassAttributes.maxlength,
      numEighty
    );
  }

  /**
   * @detail - To enter Billing Procedure Description
   * @param value - data to be entered in Billing Procedure Description
   * @API - API's are not available
   */
  enterBillingProcedureDescription(value: string) {
    cy.cType(
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[1],
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[0],
      value
    );
  }

  /**
   * @detail - To verify Billing Procedure Description value
   * @param value - data in Billing Procedure Description
   * @API - API's are not available
   */
  verifyBillingProcedureDescription(value: string) {
    cy.cHasValue(
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[1],
      OR_COMBINED_CODING.CHARGE.BILLING_PROCEDURE_DESCRIPTION[0],
      value
    );
  }

  /**
   * @details - To enter the data in the fields of HCFA tab in additional claim information popup
   * @param hcfaAdditionClaimInfo model as arguments passed in the function.
   * @API - API's are not available
   */
  enterDataInHcfaFields(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    const hcfaFieldsProperties = {
      [OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_FIRST_OCCURRENCE[0]]: {
        selector:
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_FIRST_OCCURRENCE[1],
        val: hcfaAdditionClaimInfo.FirstOccurrence,
      },
      [OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DATE_OF_ONSET[0]]: {
        selector:
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DATE_OF_ONSET[1],
        val: hcfaAdditionClaimInfo.DateOfOnset,
      },
      [OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_INITIAL_TREATMENT[0]]: {
        selector:
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_INITIAL_TREATMENT[1],
        val: hcfaAdditionClaimInfo.InitialTreatment,
      },
      [OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_STATUS[0]]: {
        selector:
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_STATUS[1],
        val: hcfaAdditionClaimInfo.DisabilityStatus,
      },
      [OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_FROM_DATE[0]]: {
        selector:
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_FROM_DATE[1],
        val: hcfaAdditionClaimInfo.DisabilityFrom,
      },
      [OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_THROUGH[0]]: {
        selector:
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_THROUGH[1],
        val: hcfaAdditionClaimInfo.DisabilityThrough,
      },
      [OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_CLINICAL_TRAIL[0]]: {
        selector:
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_CLINICAL_TRAIL[1],
        val: hcfaAdditionClaimInfo.ClinicalTrail,
      },
    };

    hcfaFields.forEach((value, index) => {
      const hcfaData = hcfaFieldsProperties[value];

      if (!hcfaFieldsProperties) {
        return;
      }
      const hcfaSelector = hcfaData.selector;
      const hcfaVal = hcfaData.val;

      if (hcfaVal ?? '') {
        cy.cGet(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_ADD_CLAIM_FIELDS[1]
        )
          .eq(index)
          .within(() => {
            cy.contains(value).then(() =>
              value ==
              OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_DISABILITY_STATUS[0]
                ? cy.cClick(selectorFactory.getSpanText(hcfaVal ?? ''), value)
                : cy.cType(hcfaSelector, value, hcfaVal)
            );
          });
      }
    });
  }

  /**
   * @details - To check the additional claim data which is entered in the fields in additional claim popup
   * @param ubAdditionalClaimInfo model as argument passed inside of the function.
   * @API - API's are not available
   */
  verifyUbAdditionalClaimData(ubAdditionalClaimInfo: UBAdditionalClaim) {
    ubFields.forEach((value, index) => {
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_ADD_CLAIM_SECTION[1])
        .eq(index)
        .within(() => {
          cy.contains(value).then(() => {
            switch (value) {
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .CONDITIONAL_CODES[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.Code!.toString()
                );
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .OCCURRENCE_SPAN_CODES_DATE_INFO[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.Code!.toString()
                );
                this.additionalUbClaimData(ubAdditionalClaimInfo.Date ?? '');
                this.additionalUbClaimData(ubAdditionalClaimInfo.Dateto ?? '');
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .OCCURRENCE_CODES_DATE_INFO[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.Code!.toString()
                );
                this.additionalUbClaimData(ubAdditionalClaimInfo.Date ?? '');
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CLAIM_NOTE_INFO[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.NoteReference!
                );
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.Description ?? ''
                );
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ECI_CODES[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.Code!.toString()
                );
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.REASON_CODES[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.Code!.toString()
                );
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .VALUE_CODES_AMOUNT_INFO[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.Code!.toString()
                );
                this.additionalUbClaimData(ubAdditionalClaimInfo.Amount ?? '');
                break;
              case OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
                .CLAIM_SUPPLEMENTAL_INFO[0]:
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.ReportTo ?? ''
                );
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.TransmissionCode!
                );
                this.additionalUbClaimData(
                  ubAdditionalClaimInfo.ClaimControl ?? ''
                );
                break;
            }
          });
        });
    });
  }

  /**
   * @details selecting period and batch Labels in charge entry
   * @API - API's are not available
   */
  clickPeriodAndBatch() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getLabelText(OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getLabelText(OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
  }

  /**
   * @detail - Verifying that no data documented for UB/HCFA fields
   * @API - API's are not available
   */
  verifyNoAdditionalClaimNoteInfo() {
    cy.cGet(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_HCFA_PLUS_ICONS[1]
    ).each(($icon, index) => {
      if (index == 8) {
        this.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
      }
      cy.wrap($icon).click();
      cy.cGet(OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_HCFA_INPUT[1])
        .eq(0)
        .click();
      cy.cClick(
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFORMATION_HEADER[1],
        OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFORMATION_HEADER[0]
      );
      this.verifyAdditionalText();
    });
  }

  /**
   * @detail - Verifying no records found text
   * @API - API's are not available
   */
  verifyAdditionalText() {
    cy.cIncludeText(
      OR_COMBINED_CODING.UB_HCFA[1],
      OR_COMBINED_CODING.UB_HCFA[0],
      OR_COMBINED_CODING.UB_HCFA[0]
    );
  }

  /**
   * @details - To Verify CPT procedure added
   * @param value cpt value to be verified
   * @API - API's are not available
   */
  verifyCPTProcedure(value: string) {
    cy.cIsVisible(selectorFactory.combinedCodingPerformedCPTRow(value), value);
  }

  /**
   * @details - To click Generate Bill CheckBox In Details Table
   * @API - API's are not available
   */
  clickGenerateBillCheckBoxInDetailsTable() {
    cy.cClick(
      OR_COMBINED_CODING.CHARGE.GENERATE_BILL_CHECKBOX[1],
      OR_COMBINED_CODING.CHARGE.GENERATE_BILL_CHECKBOX[0]
    );
  }

  /**
   * @details - Select procedure or add procedure in coding/Charge Entry page and use this assertion to load the charge tab
   * @API - API's are not available
   */
  assertChargeDetail() {
    const itemsToCheck = [
      OR_COMBINED_CODING.CHARGE.CHARGE_PERIOD_DROPDOWN_ICON[1],
      OR_COMBINED_CODING.CHARGE.PHYSICIAN_DROPDOWN_ICON[1],
      OR_COMBINED_CODING.CHARGE.REVENUE_CODE_DROPDOWN_ICON[1],
      OR_COMBINED_CODING.CHARGE.CHARGE_BATCH_DROPDOWN_ICON[1],
    ];
    itemsToCheck.forEach((itemsToCheck) => cy.shouldBeEnabled(itemsToCheck));
  }

  /**
   * @details -  To enter charge amount for charges
   * @param - amount that needs to be entered in charge amount field
   * @API - API's are not available
   * @author -Arushi
   */
  enterChargeAmount(amount: string) {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1])
      .clear({ force: true })
      .focus();
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[0],
      false,
      true
    );
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[0],
      amount
    );
  }

  /**
   * @details To add the supply in Charge Entry file
   * @param cptData as reference model in the function.
   * @Api - API's are available - Implemented Completely
   * @Author Arushi
   */
  addSupply(cptData: Cpt) {
    const interceptCollection =
      this.combinedCodingApis.interceptSearchAndSelectSupplyApi();
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(
      selectorFactory.getBText(cptData.CPTCodeAndDescription),
      cptData.CPTCodeAndDescription
    );
    cy.cIntercept(interceptCollection);
    cy.cSelectListItem(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SUPPLIES_SELECTION[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SUPPLIES_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To select the discount in the charges section
   * @param option - To provide the discount value from the dropdown
   * @Api - API's are not available
   * @author Arushi
   */
  selectDiscount(option: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DISCOUNT_DROPDOWN[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DISCOUNT_DROPDOWN[0]
    );
    cy.cClick(selectorFactory.getSpanText(option), option);
  }

  /**
   * @details Verifying write off of an expanded procedure
   * @param writeOffAmount that needs to be verified
   * @API - API's are not available
   * @author Arushi
   */
  validateWriteOff(writeOffAmount: string) {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.WRITEOFF_AMOUNT[1])
      .scrollIntoView()
      .should(ShouldMethods.contain_text, writeOffAmount);
  }

  /**
   * @details Removing primary insurance for the selected procedure
   * @param type - To pass Primary, Secondary or Tertiary
   * @API - API's are available - Implemented Completely
   * @Author Arushi
   */
  removeInsurance(type: string) {
    const interceptCollection =
      this.combinedCodingApis.interceptPrimaryInsuranceCrossIconApi();
    switch (type) {
      case HierarchyOptions.primary:
        cy.cIntercept(interceptCollection);
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PRIMARY_INSURANCE_CLEAR[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PRIMARY_INSURANCE_CLEAR[0]
        );
        cy.cWaitApis(interceptCollection);
        break;
      case HierarchyOptions.secondary:
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.SECONDARY_INSURANCE_CLEAR[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.SECONDARY_INSURANCE_CLEAR[0]
        );
        break;
      case HierarchyOptions.tertiary:
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.TERTIARY_INSURANCE_CLEAR[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.TERTIARY_INSURANCE_CLEAR[0]
        );
        break;
    }
    // added remove mask wrapper for clicking on the next step
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the Combined Coding tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptCombinedCodingTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To get the total cases count in the combined/coding tracker page
   * @API - API's are not available
   * @author Prashant Raman
   */
  getTotalCasesCount() {
    cy.cGet(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TOTAL_CASES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TOTAL_CASES[0]
    ).invoke(InvokeMethods.text);
  }

  /**
   * @details - To click on the X icon in the physician field to remove the physician in combined/coding.
   * @API - API's are not available
   * @author - Prashant Raman
   */
  removePhysician() {
    cy.cClick(
      OR_COMBINED_CODING.CROSS_ICON.PHYSICIAN_CROSS_ICON[1],
      OR_COMBINED_CODING.CROSS_ICON.PHYSICIAN_CROSS_ICON[0]
    );
  }

  /**
   * @details - To click on the X icon in the referring physician field to remove the referring physician in combined/coding.
   * @API - API's are not available
   * @author - Prashant Raman
   */
  removeReferringPhysician() {
    cy.cClick(
      OR_COMBINED_CODING.CROSS_ICON.REFERRING_PHYSICIAN_CROSS_ICON[1],
      OR_COMBINED_CODING.CROSS_ICON.REFERRING_PHYSICIAN_CROSS_ICON[0]
    );
  }

  /**
   * @details - To click on the X icon in the Primary Guarantor field to remove the Primary Guarantor in combined/coding.
   * @API - API's are not available
   * @author - Prashant Raman
   */
  removePrimaryGuarantor() {
    cy.cClick(
      OR_COMBINED_CODING.CROSS_ICON.PRIMARY_GUARANTOR_CROSS_ICON[1],
      OR_COMBINED_CODING.CROSS_ICON.PRIMARY_GUARANTOR_CROSS_ICON[0]
    );
  }

  /**
   * @details To verify Total Balance Due for the case
   * @param - totalBalanceDue passed to verify the Total Balance Due of the case
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyTotalBalanceDue(totalBalanceDue: string) {
    cy.cGet(
      selectorFactory.getSpanText(totalBalanceDue),
      totalBalanceDue
    ).should(ShouldMethods.contain_text, totalBalanceDue);
  }

  /**
   * @details - To verify the Balance displaying in the procedure row in combined/coding
   * @param value should be provided as the balance amount that needs to be verified
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyBalanceInProcedureRow(value: string) {
    cy.cIncludeText(
      selectorFactory.combinedCodingPerformedCPTRow(value),
      OR_COMBINED_CODING.PERFORMED_ITEMS[0],
      value
    );
  }

  /**
   * @details Click On Auto sort button in combined Coding Page
   * @api API's are available - Implemented Completely
   * @author - Prashant raman
   */
  clickOnAutoSort() {
    const interceptCollection = this.combinedCodingApis.interceptAutoSortApi();
    cy.cIntercept(interceptCollection);
    cy.cScrollClick(OR_COMBINED_CODING.AUTO_SORT[1], false, true);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - Combined and merged for selecting multiple discounts and verifying balance and total balance due
   * @param detailsInfo is passed as the model reference inside the function
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  addDiscountsAndVerifyBalances(detailsInfo: Charges[]) {
    for (const details of detailsInfo) {
      this.selectDiscount(details.Discounts!);
      this.verifyBalance(details.Balance!);
      this.verifyTotalBalanceDue(details.TotalBalanceDue!);
    }
  }

  /**
   * @detail - Clicking on the Headers to perform sorting.
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  clickOnHeadersToSort() {
    sisOfficeDesktop.clickHeadersToSort(headerNames);
    sisOfficeDesktop.sortInDescendingOrderByDOS();
  }

  /**
   * @detail - combined and Grouped the functions to Click on adjustment and verify Balance and document a writeoff
   * @param adjustment is passed as the model reference inside the function
   * @param chargesInfo is passed as the model reference inside the function
   * @param index is passed as a number parameter to document a particular row
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  addWriteOffAndVerifyBalances(
    adjustment: Adjustment,
    chargesInfo: Charges,
    index: number
  ) {
    this.selectChargeAdjustmentButton(ChargeAdjustment.adjustment);
    this.enterAdjustmentsDetails(
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
      adjustment.WriteoffAmount![index],
      index
    );
    this.selectTransactionCode(
      OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0],
      index,
      adjustment.WriteoffTransactionCode![index]
    );
    this.selectWriteOffGroupCode(index, adjustment.WriteoffGroupCode![index]);
    this.selectReasonCode(index, adjustment.WriteoffReasonCode![index]);
    this.verifyBalanceInProcedureRow(chargesInfo.Balance!);
  }

  /**
   * @detail - combined and Grouped the functions to verify Balance, Total Balance Due and document a Debit
   * @param adjustment  is passed as the model reference inside the function
   * @param chargesInfo  is passed as the model reference inside the function
   * @param index is passed as a number parameter to document a particular row
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  addDebitsAndVerifyBalances(
    adjustment: Adjustment,
    chargesInfo: Charges,
    index: number
  ) {
    this.enterAdjustmentsDetails(
      OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0],
      adjustment.DebitAmount![index],
      index
    );
    this.selectTransactionCode(
      OR_COMBINED_CODING.ADJUSTMENT.DEBIT_TRANSACTION_CODE[0],
      index,
      adjustment.DebitTransactionCode![index]
    );
    this.verifyBalanceInProcedureRow(chargesInfo.Balance!);
    this.verifyTotalBalanceDue(chargesInfo.TotalBalanceDue!);
  }

  /**
   * @detail - Verification of Sorted Procedures
   * @param - dataValues provide as an array to verify the order of cpt
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  verifyOrderOfProcedure(dataValues: string[]) {
    cy.cGet(
      OR_COMBINED_CODING.PERFORMED_ITEMS[1],
      OR_COMBINED_CODING.PERFORMED_ITEMS[0]
    ).scrollIntoView();
    cy.cGet(OR_COMBINED_CODING.TRANSACTION_DETAILS[1])
      .should(ShouldMethods.visible)
      .each(function ($ele, index) {
        let expectedCpt = $ele.text();
        expect(expectedCpt.replace(/\n/g, '').trim()).to.contain(
          dataValues[index]
        );
      });
  }

  /**
   * @details - Selecting modifier value from multiple modifiers dropdown
   * @param chargesInfo is passed as the model reference inside the function
   * @param dropdownIndex is passed as a number parameter to select the modifier dropdown
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  selectMultipleModifiers(chargesInfo: Charges, dropdownIndex: number) {
    for (let index = 1; index <= dropdownIndex; index++) {
      this.selectModifiers(chargesInfo.Modifier!, index);
    }
  }

  /**
   * @details - combined and Grouped the functions to Select physician and referring physician from their respective dropdowns
   * @param cptCodeInfo is passed as the model reference inside the function
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  selectPhysicianAndReferringPhysician(cptCodeInfo: Cpt) {
    this.enterAllChargeDetails(
      OR_COMBINED_CODING.CHARGE.PHYSICIAN[0],
      cptCodeInfo.Physician!
    );
    this.enterAllChargeDetails(
      OR_COMBINED_CODING.CHARGE.REFERRING_PHYSICIAN[0],
      cptCodeInfo.Physician!
    );
  }

  /**
   * @details - Select primary guarantor value from the primary guarantor dropdown
   * @param details is passed as the model reference inside the function
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  selectPrimaryGuarantor(details: BillingDetails) {
    cy.cSelectDropdown(
      OR_COMBINED_CODING.CHARGE.PRIMARY_GUARANTOR[1],
      OR_COMBINED_CODING.CHARGE.PRIMARY_GUARANTOR[0],
      details.PrimaryGuarantor
    );
  }

  /**
   * @details - Select Secondary guarantor value from the Secondary guarantor dropdown
   * @param details is passed as the model reference inside the function
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  selectSecondaryGuarantor(details: BillingDetails) {
    cy.cSelectDropdown(
      OR_COMBINED_CODING.CHARGE.SECONDARY_GUARANTOR[1],
      OR_COMBINED_CODING.CHARGE.SECONDARY_GUARANTOR[0],
      details.SecondaryGuarantor
    );
  }

  /**
   * @details - Combined and Grouped the function to select the primary and secondary guarantor values from their dropdowns
   * @param details is passed as the model reference inside the function
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  selectPrimaryAndSecondaryGuarantor(details: BillingDetails) {
    this.selectPrimaryGuarantor(details);
    this.selectSecondaryGuarantor(details);
  }

  /**
   * @details - Combined and Grouped the function to selecting period, batch and the case and select a procedure
   * @param chargeInfo is passed as the model reference inside the function
   * @param patientCaseInfo is passed as the model reference inside the function
   * @param cptCodeInfo is passed as the model reference inside the function
   * @API - API's are available - Implemented Completely
   * @author - Prashant Raman
   */
  selectCaseAndVerifyAndSelectProcedure(
    chargeInfo: Charges,
    patientCaseInfo: PatientCase,
    cptCodeInfo: Cpt
  ) {
    this.selectCase(chargeInfo, patientCaseInfo);
    this.verifyAndSelectProcedure(cptCodeInfo.CPTCodeAndDescription);
  }

  /**
   * @details - Combined and Grouped functions to click/verify on additional claim button and verify additional claim information headers/labels
   * @param headerValues as string array passed in the function
   * @param labelValues as string array passed in the function.
   * @APIs are Available - Implemented Completely
   * @author - Prashant Raman
   */
  clickAndVerifyUbAdditionalClaim(
    headerValues: string[],
    labelValues: string[]
  ) {
    this.verifyAdditionalClaimInformation(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[0]
    );
    this.clickAdditionalClaimInformation(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[0]
    );
    this.verifyUbAdditionalClaimHeaders(headerValues);
    this.verifyUbAdditionalClaimLabels(labelValues);
  }

  /**
   * @details - Combined and Grouped functions to click on the Done button in Additional Claim Information popup and verify the popup
   * @APIs are Available - Implemented Completely
   * @author - Prashant Raman
   */
  selectAdditionalClaimInfoDoneAndVerifyPopup() {
    this.selectAdditionalClaimInfoDone();
    this.verifyAdditionClaimInformationPopup(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[0]
    );
  }

  /**
   * @details - Combined and Grouped functions to click on the Additional Claim Information button , Info Tabs and verify the HCFA Labels
   * @param labelValues as string array passed in the function.
   * @APIs are Available - Implemented Completely
   * @author - Prashant Raman
   */
  clickAndVerifyHcfaAdditionalClaim(labelValues: string[]) {
    this.clickAdditionalClaimInformation(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[0]
    );
    this.selectAdditionalClaimInfoTabs(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
    );
    this.verifyHcfaProfessionalLabels(labelValues);
  }

  /**
   * @details - Combined and Grouped functions to add Details for HCFA additional claim information.
   * @param hcfaAdditionClaimInfo is passed as the model reference inside the function.
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  addHcfaAdditionalData(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    this.enterDataInHcfaFields(hcfaAdditionClaimInfo);
    this.addHcfaAdditionalClaimCodes(hcfaAdditionClaimInfo);
    this.addHcfaAdditionalClaimSupplementalInfo(hcfaAdditionClaimInfo);
    this.addHcfaAdditionalClaimNotesInfo(hcfaAdditionClaimInfo);
  }

  /**
   * @details - Combined and Grouped functions to verify Details for HCFA additional claim information.
   * @param hcfaAdditionClaimInfo is passed as the model reference inside the function.
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  verifyHcfaAdditionalClaim(hcfaAdditionClaimInfo: HCFAAdditionalClaim) {
    this.verifyClaimSupplementalInfo(hcfaAdditionClaimInfo);
    this.verifyClaimNoteInfo(hcfaAdditionClaimInfo);
    this.verifyHcfaDateFields();
    this.verifyHcfaAdditionalClaimData(hcfaAdditionClaimInfo);
  }

  /**
   * @details - Verify Scheduled Procedure Items
   * @param procedureName - Pass Procedure or Implant or Supply or Medication Name to verify in Scheduled Procedures or Billable Supplies
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyScheduledProcedureItems(procedureName: string) {
    cy.cGet(selectorFactory.getScheduleProcedure(procedureName))
      .first()
      .should(ShouldMethods.visible);
  }
}
