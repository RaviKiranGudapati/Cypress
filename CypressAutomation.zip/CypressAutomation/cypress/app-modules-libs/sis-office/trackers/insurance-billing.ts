import {
  CommonGetLocators,
  ShouldMethods,
} from '../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_INSURANCE_BILLING } from './or/insurance-billing.or';

import { InsuranceBillingApis } from './api/insurance-billing.api';
import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

export default class InsuranceBilling {
  /* instance variables */
  private insuranceBillingApis = new InsuranceBillingApis();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  /**
   * @details - Expand plus icon for the Carrier
   * @param insuranceName as string used in function
   * @APIs are not available
   */
  expandPlusIconBasedOnCarrier(insuranceName: string) {
    cy.cGet(selectorFactory.getSpanText(insuranceName))
      .parents(OR_INSURANCE_BILLING.CARRIER_ROW[1])
      .first()
      .within(() => {
        cy.cClick(
          OR_INSURANCE_BILLING.EXPAND_PLUS_ICON[1],
          OR_INSURANCE_BILLING.EXPAND_PLUS_ICON[0]
        );
      });
  }

  /**
   * @details - To verify amount in expanded plus icon based on patient name
   * @param patientName as string used in function
   * @param amount as string used in function
   * @APIs are not available
   */
  verifyAmountByPatientName(patientName: string, amount: string) {
    cy.cGet(OR_INSURANCE_BILLING.PATIENT_ROW[1]).each(($ele) => {
      if ($ele.text().indexOf(patientName) && $ele.text().indexOf(amount) > 1) {
        cy.wrap($ele)
          .first()
          .within(() => {
            cy.cGet(CommonGetLocators.td)
              .eq(4)
              .should(ShouldMethods.contain_text, amount);
          });
      }
    });
  }

  /**
   * @details - To click checkbox in expanded plus icon
   * @param patientName as string used in function
   * @APIs are not available
   */
  clickCheckboxInExpandedIcon(patientName: string) {
    cy.cGet(OR_INSURANCE_BILLING.PATIENT_ROW[1]).each(($ele) => {
      if ($ele.text().indexOf(patientName) > -1) {
        cy.wrap($ele)
          .first()
          .within(() => {
            cy.cGet(OR_INSURANCE_BILLING.CHECK_BOX[1]).click({ force: true });
          });
      }
    });
  }

  /**
   * @details - To select the option in insurance billing tracker
   * @param option as string used in function
   * @APIs -API's are available - Implemented Completely
   * @Author - Spoorthy
   */
  selectButtonsInInsuranceBilling(option: string) {
    //TODO : Need to Implement API
    let selector: string = '';
    let selectorName: string = '';
    let interceptCollection: ApiEndpoint[] = [];
    switch (option) {
      case OR_INSURANCE_BILLING.BILL_SELECTED_PAYERS[0]:
        selector = OR_INSURANCE_BILLING.BILL_SELECTED_PAYERS[1];
        selectorName = OR_INSURANCE_BILLING.BILL_SELECTED_PAYERS[0];
        interceptCollection =
          this.insuranceBillingApis.interceptBillSelectedPayersApi();
        break;
      case OR_INSURANCE_BILLING.PRINT_SELECTED_PAYERS[0]:
        selector = OR_INSURANCE_BILLING.PRINT_SELECTED_PAYERS[1];
        selectorName = OR_INSURANCE_BILLING.PRINT_SELECTED_PAYERS[0];
        break;
      case OR_INSURANCE_BILLING.DOWNLOAD_CLAIMS[0]:
        selector = OR_INSURANCE_BILLING.DOWNLOAD_CLAIMS[1];
        selectorName = OR_INSURANCE_BILLING.DOWNLOAD_CLAIMS[0];
        break;
      default:
        break;
    }
    cy.cIntercept(interceptCollection);
    cy.cClick(selector, selectorName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the Insurance Billing tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection = this.sisOfficeDesktopApis.interceptInsuranceTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To close the print preview dialog
   * @API - API's are not available
   * @author - Nikitan
   */
  closePrintPreview() {
    cy.cGet(
      CommonUtils.concatenate(
        CoreCssClasses.Button.loc_button_tag,
        CoreCssClasses.Dialog.loc_p_dialog_header_close
      )
    ).click({ force: true });
  }
}
