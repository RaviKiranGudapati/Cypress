import {
  CommonGetLocators,
  YesOrNo,
} from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_INVENTORY_RECONCILIATION = {
  INVENTORY_RECONCILIATION: {
    INVENTORY_RECONCILIATION_TABLE: {
      PATIENT_NAME: ['Patient Name'],
      MRN: ['MRN'],
      DEPLETE_SELECTED_BUTTON: ['Deplete Selected', '#btnDepleteSelected'],
      SORTABLE_COL_ICON: ['DOS', 'th[psortablecolumn=dateOfSurgery]'],
    },
    INVENTORY: {
      IMPLANTS_TABLE: {
        TABLE_NAME: ['Implants Table'],
        IMPLANTS: ['Implants'],
        USED: ['Used', 'used'],
        ADD_IMPLANTS_PROSTHETIC_BUTTON: [
          'Add Implant / Prosthetic',
          '#btnAddImplant',
        ],
        IMPLANTS_DATA: ['Implants', '#implants td'],
        IMPLANTS_CLEAR_ICON: [
          'Implants Clear Icon',
          CommonUtils.concatenate(
            CoreCssClasses.ClassPrefix.loc_fa_fa,
            '-times-circle'
          ),
        ],
        TOTAL_DEPLETED: [
          'Total Depleted',
          CommonUtils.concatenate(
            CommonGetLocators.td,
            '.total-depleted-column',
            ' ',
            CommonGetLocators.span
          ),
        ],
        BILLED: [
          'Billed',
          CommonUtils.concatenate(
            CommonGetLocators.td,
            '.implants-billed',
            ' ',
            CommonGetLocators.span
          ),
        ],
        FREE_TOOLTIP_TEXT: [
          CommonUtils.concatenate(
            '.implant-name ',
            CoreCssClasses.Icon.loc_exclamation
          ),
        ],
      },
      ADD_IMPLANTS_PROSTHETIC_POPUP: {
        POPUP_NAME: ['Add Implant or Prosthetic'],
        IMPLANT_SEARCH: ['Implant*', '#ios_search_input'],
        MANUFACTURER: ['Manufacturer', '#manufacturer'],
        HARDWARE_BUTTON: ['Hardware'],
        TISSUE_BUTTON: ['Tissue'],
        QUANTITY: ['Quantity', '#quantity'],
        SIZE: ['Size', '#size'],
        LOT_NO: ['Lot #', '#lotNum'],
        SERIAL_NO: ['Serial #', '#serialNum'],
        EXPIRATION: ['Expiration', '#expiration'],
        REFERENCE_NO: ['Reference #', '#referenceNum'],
        NOTES: ['Notes', '#notes'],
        ADD_ANOTHER_BUTTON: ['Add Another', '#btnAddAnother'],
        DONE_BUTTON: [
          'Done',
          '.implant-prosthetic-modal-footer button#btnDone',
        ],
        ENTERED_IMPLANT_NAME: [
          'LENS MA60MA.',
          '#iosextendscrollpanel > .p-scrollpanel > .p-scrollpanel-wrapper > .p-scrollpanel-content > :nth-child(1)',
        ],
        IMPLANT_MFD_NAME: ['ALCON', '#select_next_level_result_set'],
      },
      MEDICATIONS_TABLE: {
        MEDICATIONS: ['Medications'],
        TABLE_NAME: ['Medications Table'],
        ADMINISTERED: ['Administered', '#totalUsedQty>input'],
        WASTED: ['Wasted', '#wastedQty>input'],
        USAGE_TOTAL: ['Usage Total', '#usageTotal>input'],
        TOTAL_DEPLETED: [
          'Total Depleted',
          CommonUtils.concatenate(
            CommonGetLocators.td,
            '.total-depleted-column ',
            CommonGetLocators.span
          ),
        ],
        BILLED: [
          'Billed',
          CommonUtils.concatenate(
            CommonGetLocators.td,
            '.billed-column ',
            CommonGetLocators.span
          ),
        ],
      },
      FREE_TEXT_ITEM: ['Free Text Item'],
      SUPPLIES_TABLE: {
        SUPPLIES: ['Supplies'],
        TOTAL_DEPLETED: [
          'Total Depleted',
          CommonUtils.concatenate(
            CommonGetLocators.td,
            '.supply-quantity-depleted-column',
            ' ',
            CommonGetLocators.span
          ),
        ],
        PULLED: [
          'Pulled',
          CommonUtils.concatenate(
            CommonGetLocators.td,
            '.supply-quantity-pulled-column',
            ' ',
            CommonGetLocators.span
          ),
        ],
        USED: ['Used', selectorFactory.getSupplyInputQuantity('used')],
        WASTED: ['Wasted', selectorFactory.getSupplyInputQuantity('wasted')],
        DEFECTIVE: [
          'Defective',
          selectorFactory.getSupplyInputQuantity('defective'),
        ],
        BILLED: [
          'Billed',
          CommonUtils.concatenate(
            CommonGetLocators.td,
            '.supply-quantity-billed-column',
            ' ',
            CommonGetLocators.span
          ),
        ],
        FREE_TOOLTIP_TEXT: [
          CommonUtils.concatenate(
            '.supplies-container',
            ' ',
            CoreCssClasses.Icon.loc_exclamation
          ),
        ],
        KEY_BOARD_ICON: ['Key Board Icon'],
      },
      IOS_TEXT_ITEM_WITH_MANUFACTURER: ['IOS Text Item With Manufacturer'],
      IOS_TEXT_ITEM_WITHOUT_MANUFACTURER: [
        'IOS Text Item Without Manufacturer',
      ],
      USED_AND_BILLED: ['Difference between Used And Billed Quantity'],
      DEPLETION_VERIFIED_YES: [
        'Yes',
        CommonUtils.concatenate(
          selectorFactory.getDivText('Depletion Verified'),
          ' ',
          `sis-select-button `,
          selectorFactory.getSpanText(YesOrNo.yes)
        ),
      ],
      DEPLETION_VERIFIED_NO: [
        'No',
        CommonUtils.concatenate(
          selectorFactory.getDivText('Depletion Verified'),
          ' ',
          `sis-select-button `,
          selectorFactory.getSpanText(YesOrNo.no)
        ),
      ],
      BANNER_ICON: [
        'Banner Icon',
        CommonUtils.concatenate(
          'sis-warning-banner ',
          CoreCssClasses.Icon.loc_triangle_exclamation
        ),
      ],
      BANNER_TEXT: [
        'Banner Text',
        CommonUtils.concatenate(
          'sis-warning-banner sis-custom-tooltip ',
          CommonGetLocators.span
        ),
      ],
    },
  },
};
