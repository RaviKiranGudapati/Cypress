import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_BALANCE_RECONCILIATION = {
  BALANCE_RECONCILIATION_TABLE: [
    'Balance Reconciliation',
    '#balance-reconciliation-inner-table',
  ],
  BALANCE_RECONCILIATION_ROW: [
    'Balance Reconciliation Rows',
    CommonUtils.concatenate(
      '#balance-reconciliation-inner-table ',
      CoreCssClasses.List.loc_p_data_table,
      '-tbody tr'
    ),
  ],
  BATCH: [
    'Batch',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper,
      ' >ul'
    ),
  ],
};
