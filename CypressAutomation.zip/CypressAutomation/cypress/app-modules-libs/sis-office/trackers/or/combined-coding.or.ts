import {
  InvokeAttributes,
  TrueOrFalse,
  YesOrNo,
} from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_COMBINED_CODING = {
  HEADER: {
    DOS: ['DOS', '.date-of-surgery '],
    PROCEDURE: ['Procedure', '.case-procedures '],
    CASE_STATUS: ['Case Status', '.case-status '],
  },
  PERFORMED_ITEMS: ['Performed Items', '#codingCEPI div.header-title'],
  ROWS: [
    'Table Rows',
    CommonUtils.concatenate('tr', CoreCssClasses.Row.loc_p_selectable_row),
  ],
  AUTO_SORT: ['Auto sort', '#autoSortBtn'],
  TRANSACTION_DETAILS: ['Transaction row', `[id^='pnlTransactionDetails']`],
  CHARGE: {
    SEARCH_PROCEDURE: [
      'CPT® Code or HCPCS Code',
      CommonUtils.concatenate(
        '.procedure-search ',
        CoreCssClasses.Input.loc_p_autocomplete_input
      ),
    ],
    SEARCH_SUPPLIES: [
      'CPT® Code or HCPCS Code',
      CommonUtils.concatenate(
        '.ios-details-search-container ',
        CoreCssClasses.Input.loc_p_autocomplete_input
      ),
    ],
    BILLING_PROCEDURE_DESCRIPTION: [
      'Billing Procedure Description',
      '#billingProcedureDescription',
    ],
    CLEAR_DISCOUNT: [
      'Clear Discount',
      '#sourceOfRevenueDropdown .dropdown-clearicon',
    ],
    HCPCS: ['HCPCS', '#hcpcsInput'],
    PHYSICIAN: [
      'Physician',
      CommonUtils.concatenate(
        '#staffSingleSelectphysicianDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown
      ),
    ],
    REFERRING_PHYSICIAN: [
      'Referring Physician',
      CommonUtils.concatenate(
        '#staffSingleSelectreferringPhysicianDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown
      ),
    ],
    DISCOUNT: [
      'Discount',
      CommonUtils.concatenate(
        '#sourceOfRevenueDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown
      ),
    ],
    DISCOUNT_SEARCH: [
      'Discount',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown_filter_container,
        ' ',
        CoreCssClasses.DropDown.loc_p_dropdown_filter
      ),
    ],
    AMOUNT: ['Amount', '#txtAmount #numericInput'],
    DIAGNOSIS_CODE: ['Diagnosis Codes', '#diagnosisSearchText'],
    BALANCE: [
      'Balance',
      CommonUtils.concatenate('label', CoreCssClasses.Text.loc_label_text),
    ],
    CHARGE_DROPDOWN_SEARCH: [
      'Charge search',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown_filter_container,
        ' ',
        CoreCssClasses.DropDown.loc_p_dropdown_filter
      ),
    ],
    BALANCE_PROCEDURE: [
      'Discount',
      CommonUtils.concatenate('label', CoreCssClasses.Text.loc_label_text),
    ],
    CPT_PROCEDURE: ['CPT Procedure', '#procedureAutoComplete input'],
    AMOUNT_PROCEDURE: [
      'Amount',
      CommonUtils.concatenate(
        '#txtAmount ',
        CoreCssClasses.Input.loc_p_input_text
      ),
    ],
    NDC_INPUT: ['NDC', '#txtNdcNum'],
    GENERATE_BILL_CHECKBOX: [
      'Generate Bill',
      CommonUtils.concatenate(
        '#chkGenerateBill ',
        CoreCssClasses.Checkbox.loc_p_checkbox_checked
      ),
    ],
    TYPE_OF_BILL: ['Type Of Bill', 'input#txtTypeOfBill'],
    UNITS: ['Units', `[id*='txtUnits'] input`],
    REVENUE_CODE: [
      'Revenue Code',
      CommonUtils.concatenate(
        '#revenueCodeDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    REVENUE_CODE_INPUT: [
      'Revenue Code',
      CoreCssClasses.DropDown.loc_p_dropdown_filter,
    ],
    PRIMARY_INSURANCE: [
      'Primary Insurance',
      CommonUtils.concatenate(
        '#primaryInsuranceDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    SECONDARY_INSURANCE: [
      'Secondary Insurance',
      CommonUtils.concatenate(
        '#secondaryInsuranceDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    TERTIARY_INSURANCE: [
      'Tertiary Insurance',
      CommonUtils.concatenate(
        '#tertiaryInsuranceDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    PRIMARY_GUARANTOR: [
      'Primary Guarantor',
      CommonUtils.concatenate(
        '#primaryGuarantorDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    SECONDARY_GUARANTOR: [
      'Secondary Guarantor',
      CommonUtils.concatenate(
        '#secondaryGuarantorDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    SELF_PAY: [
      'Self Pay',
      CommonUtils.concatenate(
        '#toggleInsSelfPay div[',
        InvokeAttributes.ariaPressed,
        '="',
        TrueOrFalse.true,
        '"]'
      ),
    ],
    SELF_PAY_YES: [
      'Yes',
      CommonUtils.concatenate(
        '#toggleInsSelfPay div[',
        InvokeAttributes.aria_label,
        '="',
        YesOrNo.yes,
        '"]'
      ),
    ],
    SELF_PAY_NO: [
      'No',
      CommonUtils.concatenate(
        '#toggleInsSelfPay div[',
        InvokeAttributes.aria_label,
        '="',
        YesOrNo.no,
        '"]'
      ),
    ],
    WORKERS_COMPENSATION: [
      'Workers Compensation',
      CommonUtils.concatenate(
        '#toggleWorkersCompensation div[',
        InvokeAttributes.ariaPressed,
        '="',
        TrueOrFalse.true,
        '"]'
      ),
    ],
    CHARGE_PERIOD_DROPDOWN_ICON: [
      'Charge period dropdown icon',
      CommonUtils.concatenate(
        '[id*="periodDropdownssPeriodBatchHeader"] ',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      ),
    ],
    CHARGE_BATCH_DROPDOWN_ICON: [
      'Charge batch dropdown icon',
      CommonUtils.concatenate(
        '[id*="batchDropdownssPeriodBatchHeader"] ',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      ),
    ],
    PHYSICIAN_DROPDOWN_ICON: [
      'Physician',
      CommonUtils.concatenate(
        '#staffSingleSelectphysicianDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      ),
    ],
    REVENUE_CODE_DROPDOWN_ICON: [
      'Revenue Code',
      CommonUtils.concatenate(
        '#revenueCodeDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      ),
    ],
  },
  ADJUSTMENT: {
    WRITE_OFF_AMOUNT: [
      'Write-off amount',
      'sis-numeric-input[id*="txtWriteOffAmount"] input ',
    ],
    WRITE_OFF_TRANSACTION_CODE: [
      'Transaction Code',
      '#woTransactionCodeDropdown_1',
    ],
    GROUP_CODE: ['Group Code', '#woGroupCodeDropdown_0'],
    REASON_CODE: ['Reason Code', '#woReasonCodeDropdown_0'],
    REASON_CODE_SEARCH: [
      'Reason Code',
      CoreCssClasses.DropDown.loc_p_dropdown_filter,
    ],
    DEBIT_AMOUNT: ['Debit Amount', '#txtDebitAmount0'],
    DEBIT_TRANSACTION_CODE: [
      'Transaction code dropdown',
      '#DBTransactionCodeDropdown_0',
    ],
    TRANSACTION_CODE_SEARCH: [
      'Transaction code',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown_filter_container,
        ' input'
      ),
    ],
    WRITE_OFF_AMOUNT_VALUE: ['Amount', '#amount'],
    WRITEOFF_REASONCODE: ['Writeoff reason code', '#writeOffReasonCode'],
    WRITEOFF_GROUPCODE: ['Writeoff group code', ' #writeOffGroupCode'],
  },
  SELECT_ALL_PROCEDURE_CHECKBOX: [
    'Checkbox',
    CommonUtils.concatenate(
      CoreCssClasses.Checkbox.loc_table_header_checkbox,
      ' ',
      CoreCssClasses.Checkbox.loc_p_checkbox_box
    ),
  ],
  ADD_SELECTED_TO_PERFORMED: [
    'Add Selected to Performed',
    '#btnAddPerformedItems',
  ],
  ADD_PROCEDURE: [
    'Add Procedure',
    CommonUtils.concatenate(
      '#btnAddProcedure ',
      CoreCssClasses.Button.loc_button_label
    ),
  ],
  ADD_SUPPLIES: [
    'Add Supplies',
    CommonUtils.concatenate(
      '#btnAddSupplies ',
      CoreCssClasses.Button.loc_button_label
    ),
  ],
  READY_FOR_BILL_NO: [
    'Ready for bill',
    CommonUtils.concatenate(
      '#inpsReadyForBill div ',
      selectorFactory.getDivText(YesOrNo.no)
    ),
  ],
  READY_FOR_BILL_YES: ['Ready for bill', '#inpsReadyForBill:contains("Yes")'],

  ADDITIONAL_CLAIM_INFO: {
    CONDITIONAL_CODES: ['Condition Codes'],
    OCCURRENCE_SPAN_CODES_DATE_INFO: [
      'Occurrence Span Codes & Date Information',
    ],
    OCCURRENCE_CODES_DATE_INFO: ['Occurrence Codes & Date Information'],
    CLAIM_NOTE_INFO: ['Claim Note Information'],
    ECI_CODES: ['ECI Codes'],
    REASON_CODES: ['Reason Codes'],
    VALUE_CODES_AMOUNT_INFO: ['Value Codes & Amount Information'],
    CLAIM_SUPPLEMENTAL_INFO: ['Claim Supplemental Information'],
    HCFA_PROFESSIONAL: ['HCFA/Professional'],
    UB_INSTITUTIONAL: ['UB/Institutional'],
    DONE: ['Done', '#btnDoneAddInfo'],
    ADD_CLAIM_PLUS_ICON: [
      'Additional Claim Plus Icon',
      CoreCssClasses.Icon.loc_p_button_icon,
    ],
    ADDITIONAL_CLAIM_INFORMATION: [
      'Additional Claim Information',
      '.additional_claim button span',
    ],
    ADD_CLAIM_INFO_INPUT: [
      'Additional Claim Input Fields',
      `[data-test-id*='input_']`,
    ],
    UB_ADD_CLAIM_HEADERS: [
      'UB/Institutional',
      `.ub-tab .column-gap-half div[class^='col'] label`,
    ],
    UB_ADD_CLAIM_SUB_HEADERS: [
      'UB/Institutional',
      `.ub-tab table[id*='pr_id_'] th[class*='input-col']`,
    ],
    ADD_CLAIM_FILLED_TEXT: ['filled', '.writeoff-text'],
    UB_ADD_CLAIM_SECTION: [
      'UB/Institutional',
      '.ub-tab .column-gap-half div[class^="col"]',
    ],
    ADD_CLAIM_DATE_FILED: [
      'Additional Claim Date Fields',
      CommonUtils.concatenate(
        CoreCssClasses.Input.loc_p_input_mask,
        ':not(',
        CoreCssClasses.Style.loc_p_filled,
        ')'
      ),
    ],
    ADD_CLAIM_TEXT_FIELDS: [
      'Additional Claim Text Fields',
      CommonUtils.concatenate(
        CoreCssClasses.Input.loc_p_input_text,
        ':not(',
        CoreCssClasses.Style.loc_p_filled,
        ')'
      ),
    ],
    HCFA_ADD_CLAIM_LABELS: [
      'HCFA/Professional',
      '.hcfa-tab .tab-hcfa-top-part label',
    ],
    HCFA_ADD_CLAIM_FIELDS: [
      'HCFA/Professional',
      '.hcfa-tab .tab-hcfa-top-part>div',
    ],
    HCFA_FIRST_OCCURRENCE: ['First Occurrence', '#firstOccurenceDate input'],
    HCFA_DATE_OF_ONSET: ['Date of Onset', '#dateOfOnsetDate input'],
    HCFA_INITIAL_TREATMENT: ['Initial Treatment', '#intialTreatmentDate input'],
    HCFA_DISABILITY_STATUS: ['Disability Status'],
    HCFA_DISABILITY_FROM_DATE: ['Disability From', '#disabilityFromDate input'],
    HCFA_DISABILITY_THROUGH: [
      'Disability Through',
      '#disabilityThroughDate input',
    ],
    HCFA_CLINICAL_TRAIL: ['Clinical Trial', '#clinicalTrialNumber'],
    HCFA_ADD_CLAIM_CODE_FIELDS: [
      'HCFA Additional Claim Data',
      `.hcfa-tab .column-gap-half div[class^='col']`,
    ],
    HCFA_DATE_FIELDS_FILLED: [
      'filled',
      CommonUtils.concatenate(
        '.hcfa-tab .tab-hcfa-top-part div ',
        CoreCssClasses.Panel.loc_p_calendar
      ),
    ],
    ADD_CLAIM_TRASH_ICON: ['Trash Icon', CoreCssClasses.Trash.loc_trash_icon],
    CLINICAL_TRIAL_TEXT: [
      'Clinical Trial #',
      'label[for="clinicalTrialNumber"] span',
    ],
    CLINICAL_TRIAL_TEXT_INPUT: [
      'Clinical Trial #',
      'input#clinicalTrialNumber',
    ],
    UB_HCFA_PLUS_ICONS: ['UB/Institutional', 'div.footer button[id*="btnAdd"]'],
    UB_HCFA_INPUT: [
      'Input',
      CommonUtils.concatenate(CoreCssClasses.Panel.loc_p_tabpanel, ' input'),
    ],
    ADDITIONAL_TEXT: ['No records found', '.td-no-hover'],
    ADDITIONAL_HEADER: [
      'Additional Claim Information',
      CommonUtils.concatenate('div', CoreCssClasses.Dialog.loc_dialog_header),
    ],
  },
  ADD_SUPPLIES_BUTTON: ['Add Supplies', '#btnAddSupplies'],
  SEARCH_CPT_PROCEDURE: [
    'Search cpt',
    '[class*="ios-details-search-container "]',
  ],
  CROSS_ICON_PROCEDURE: ['Cross Icon', 'span.autocomplete-clear'],
  NDC_Label: ['NDC', '#txtNdcNum'],
  UNITS_OF_MEASURE_DROPDOWN: [
    'Units of measure dropdown',
    CommonUtils.concatenate(
      '#unitOfMeasureDropdown',
      CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
    ),
  ],
  BASE_UNITS: [
    'Base units',
    CommonUtils.concatenate(
      '#baseUnits',
      CoreCssClasses.Input.loc_p_input_text
    ),
  ],
  NDC_TEXT: ['NDC Text', '#txtNdcNum'],
  DIAGNOSIS_CODE_SEARCH_BOX: ['Diagnosis', '#diagnosisSearchText'],
  HCPCS: ['HCPCS', '#hcpcsInput'],
  BASE_UNIT_VALUE: ['Base unit value', '#baseUnits #numericInput'],
  NEXT_CASE: ['Next Case', '#btnNextCase'],
  STATUS_READY_TO_CHARGE: ['Status', 'div.case-middle'],
  AMOUNT: ['Amount', `[id*='txtAmount'] #numericInput`],
  UNITS_OF_MEASURE_DROPDOWN_VALUES: [
    'Units of Measure',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_dropdown_items,
      ' ',
      CoreCssClasses.Text.loc_limittext_holder
    ),
  ],
  UNITS_OF_MEASURE_CROSS_ICON: [
    'Cross Icon',
    CommonUtils.concatenate(
      '#unitOfMeasureDropdown .primeNG-single-select ',
      CoreCssClasses.DropDown.loc_dropdown_clear
    ),
  ],
  UNITS_OF_MEASURE_VALUE: [
    'Units of measure value',
    CommonUtils.concatenate(
      '#unitOfMeasureDropdown',
      CoreCssClasses.DropDown.loc_dropdown_label,
      CoreCssClasses.Input.loc_p_input_text
    ),
  ],
  PHYSICIAN_VALUE: ['Physician value', '#physicianDropdown '],
  REFERRING_PHYSICIAN_VALUE: [
    'Referring physician value',
    '#referringPhysicianDropdown ',
  ],
  BALANCE_PROCEDURE: ['Discount', 'label.label-text '],
  CPT_PROCEDURE: ['CPT Procedure', '#procedureAutoComplete input'],
  AMOUNT_PROCEDURE: [
    'Amount',
    CommonUtils.concatenate(
      '#txtAmount ',
      CoreCssClasses.Input.loc_p_input_text
    ),
  ],
  SELECT_PROCEDURE: ['Select Procedure', '.procedure-item'],
  AMOUNT_DETAILS_REVIEW_EDIT: [
    'Amount',
    '#decimalTextBox_review_reviewChargeString_dtb',
  ],
  SEARCH_PROCEDURE_IN_CONTRACTS: [
    'Procedure in contract',
    '.review-edit-container .search-cpt input',
  ],
  SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS: [
    'Selecting Procedure',
    '.table-scroll-review .dynamic-columns#row_0_',
  ],
  CONTRACT_SEARCH_BOX: ['Search box', '#txt_cs_'],
  TYPE_DROPDOWN_CONTRACTS: ['Dropdown type', '#review_type  #ssDiv_  .fa-lg'],
  EXEMPT_DROPDOWN: ['Dropdown Exempt', '#exempt_dpdwn #ssDiv_  .fa-lg'],
  TYPE_DROPDOWN_VALUES: [
    'Dropdown values',
    CommonUtils.concatenate(CoreCssClasses.List.loc_dictionary_items, ' '),
  ],
  CONTRACTS_TITLE: ['Contracts Title', '.ins-contract-title'],
  REVIEW_TYPE: ['Review Type', '#review_type #ssIi_ '],
  EXEMPT_DROPDOWN_VALUES: ['Dropdown values Exempt', '#exempt_dpdwn '],
  CPT_ROW: ['CPT', '.data-row'],
  TRASH_ICON: ['Trash Icon', `i[id*='iconTrash']`],
  YES: [
    'yes',
    CommonUtils.concatenate(
      CoreCssClasses.Dialog.loc_dialog_accept,
      ' ',
      CoreCssClasses.Button.loc_button_label
    ),
  ],
  SCHEDULED_PROCEDURES_BILLABLE_SUPPLIES: [
    'Scheduled Procedures/Billable Supplies',
    CommonUtils.concatenate(
      '[header="Scheduled Procedures/Billable Supplies"] button[role="tab"]'
    ),
  ],
  PERFORMED_ITEMS_HEADERS: [
    'Performed Items Headers',
    '#codingCEPI div[class*="colH"]',
  ],
  PERIOD_VALUE: [
    'Period',
    'sis-single-select-dropdown#periodDropdownssPeriodBatchHeader2 span',
  ],
  BATCH_VALUE: [
    'Batch',
    'sis-single-select-dropdown#batchDropdownssPeriodBatchHeader2 span',
  ],
  INSURANCE_CROSS_ICON: [
    'Primary Insurance Cross Icon',
    CommonUtils.concatenate(
      '	#primaryInsuranceDropdown ',
      CoreCssClasses.DropDown.loc_dropdown_clear
    ),
  ],
  UNITS: ['Units', "sis-numeric-input[id*='txtUnits'] input"],
  PATIENT_INFO: ['Patient full name', '.panel-patient .patientfull-name'],
  UB_HCFA: ['No records found', '.td-no-hover'],
  ADDITIONAL_CLAIM_INFORMATION_HEADER: [
    'Additional Claim Information header',
    CommonUtils.concatenate('div', CoreCssClasses.Dialog.loc_dialog_header),
  ],
  PERIOD_LABEL: [
    'Period',
    CommonUtils.concatenate(
      '.period-dropdown ',
      CoreCssClasses.Label.loc_control_label
    ),
  ],
  BATCH_LABEL: [
    'Batch',
    CommonUtils.concatenate(
      '.batch-dropdown ',
      CoreCssClasses.Label.loc_control_label
    ),
  ],
  READY_FOR_BILL: ['Ready for bill', '#inpsReadyForBill '],
  DOCUMENTATION_HEADER: ['Documentaion Header', '[class="header-container"]'],
  OP_NOTES: ['Op Notes'],
  IMPlANT_LOG: ['Implant Log'],
  PROGRESS_BAR: [
    'Progress bar',
    CommonUtils.concatenate(
      '[class*="p-progressbar ',
      CoreCssClasses.Panel.loc_p_component
    ),
  ],
  IMPLANT_SCROLLPANEL: ['Implant scroll bar', '#implantsScrollpanel'],
  CLEAR_HCPCS: ['Clear HCPCS', 'span[class*="autocomplete-clear"]'],
  INVENTORY_ITEM: ['Inventory Item', '[class*="inventory-item"]'],
  IMPLANT_NAME: ['Implant Name', '[placeholder*="Search by name"]'],
  CROSS_ICON: {
    PHYSICIAN_CROSS_ICON: [
      'Physician cross icon',
      CommonUtils.concatenate(
        '#staffSingleSelectphysicianDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    REFERRING_PHYSICIAN_CROSS_ICON: [
      'Referring Physician cross icon',
      CommonUtils.concatenate(
        '#referringPhysicianDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    PRIMARY_GUARANTOR_CROSS_ICON: [
      'Primary Guarantor cross icon',
      CommonUtils.concatenate(
        '#primaryGuarantorDropdown ',
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
  },
};
