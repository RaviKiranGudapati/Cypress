import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

import { OR_PATIENT_CASE_CREATION } from '../../case-creation/or/create-case.or';

export const OR_REMITTANCE_POSTING = {
  MANUAL_REMITTANCE_POSTING: [
    'Manual Remittance Posting',
    '#btnManualRemittance',
  ],
  START_DOS: [
    'Case Date Of Service',
    CommonUtils.concatenate(
      '#rp_startDate ',
      CoreCssClasses.Icon.loc_p_button_icon
    ),
  ],
  END_DOS: [
    'Case Date Of Service',
    CommonUtils.concatenate(
      '#rp_endDate ',
      CoreCssClasses.Icon.loc_p_button_icon
    ),
  ],
  CURRENT_DATE: [
    'Current Date',
    CommonUtils.concatenate(
      CommonGetLocators.td,
      CoreCssClasses.DatePicker.loc_datepicker,
      '-today'
    ),
  ],
  RECEIVED_FROM: [
    'Received From',
    CommonUtils.concatenate(
      '#rp_receivedFromDropdown ',
      CoreCssClasses.DropDown.loc_dropdown_label
    ),
  ],
  RECEIVED_FROM_SEARCH: [
    'Received From',
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
      .INSURANCE_COVERAGE.STATE_DROPDOWN_SEARCH_AREA[1],
  ],
  CHECK_AMOUNT: ['Check Amount', '#numericInput'],
  PERIOD: ['Period', '#rp_periodDropdown'],
  BATCH: ['Batch', '#rp_batchDropdown'],
  CONTRACT: ['Contract name', '#contract_name'],
  AllOWED_AMOUNT: [
    'Allowed amount',
    CommonUtils.concatenate('#lblRpAllowedAmount', ' ', CommonGetLocators.span),
  ],
  ICON_ELLIPSIS: ['Ellipsis Icon'],
  DOWN_ACTIVE: ['Down Active', '[class$="down active"]'],
  POSTEOB_STATUS: ['Post Eob'],
  POST: ['Post', '#btnPost'],
  UNASSIGNED_PAVEMENT_DONE: ['Done', 'button.btn-done'],
  REMITTANCE_POSTING_DETAILS_DONE: ['done', '#divTotalPaymentTotalWO button'],
  PAYMENT_ID: ['Payment id', '#paymentId'],
  PAYMENT: ['Payment', `[id*='paymentInput']`],
  WRITE_OFF1: ['Write-off 1', `[id*='writeOff1Input']`],
  WRITE_OFF2: ['Write-off 2', `[id*='writeOff2Input']`],
  TRANSFER_TO: ['Transfer to', '#rp_transferCode_toggle '],
  GENERATE_BILL: ['Generate bill', '#rp_generateBill '],
  POST_EOB: ['Post Eob', '#rp_postEob '],
  DEBIT_TRANSACTION_CODE_DROPDOWN: [
    'Transction Code',
    '#rp_debitTransactionDropdown',
  ],
  PAYMENT_TRANSACTION_DROPDOWN: [
    'Payment Transaction Code',
    '#rp_paymentTransactionCode',
  ],
  PAYMENT_TRANSACTION_DROPDOWN_VALUE: [
    'Payment Transaction Code',
    CommonUtils.concatenate(
      '#rp_paymentTransactionCode',
      ' ',
      CoreCssClasses.DropDown.loc_p_dropdown,
      ' ',
      CommonGetLocators.span
    ),
  ],
  START_DATE_FORMAT: [
    'Date Format',
    CommonUtils.concatenate(
      'sis-remittance-posting #rp_startDate',
      ' ',
      CommonGetLocators.input
    ),
  ],
  END_DATE_FORMAT: [
    'Date Format',
    CommonUtils.concatenate(
      'sis-remittance-posting #rp_endDate',
      ' ',
      CommonGetLocators.input
    ),
  ],
  CASE_DATE_OF_SERVICE_MANDATORY: [
    'Case Date of Service',
    CommonUtils.concatenate(
      selectorFactory.getLabelText('Case Date of Service'),
      ' ',
      CommonGetLocators.span
    ),
  ],
  METHOD_OF_PAYEMENT_VALUE: [
    'Method Payment Value',
    CommonUtils.concatenate(
      '#rp_methodOfPaymentDropdown',
      ' ',
      CommonGetLocators.input
    ),
  ],
  METHOD_OF_PAYMENT_DROPDOWN: [
    'Method Of Payment',
    '#rp_methodOfPaymentDropdown',
  ],
  PANEL_ICON: [
    'Panel Icon',
    CommonUtils.concatenate(
      CommonGetLocators.div,
      CoreCssClasses.Icon.loc_p_panel_icons,
      ' ',
      CommonGetLocators.button
    ),
  ],
  PANEL_DEFAULTS_HEADER: ['Panel Defaults Header', '#rp_showDefaultsPanel'],
  GROUP_CODE_1: ['Group code', '#rp_groupCode1'],
  GROUP_CODE_2: ['Group code', '#rp_groupCode2'],
  GROUP_CODE_3: ['Group code', '#rp_groupCode3'],
  REASON_CODE_1: ['Reason code', '#rp_ReasonCode1'],
  REASON_CODE_2: ['Reason code', '#rp_ReasonCode2'],
  REASON_CODE_3: ['Reason code', '#rp_ReasonCode3'],
  PERIOD_DROPDOWN: [
    'Selected Period',
    CommonUtils.concatenate(
      '#rp_periodDropdown',
      ' ',
      CommonGetLocators.span,
      CoreCssClasses.Button.loc_p_element
    ),
  ],
  PAYMENT_METHOD_DROPDOWN_VALUE: [
    'Payment Method Dropdown Value',
    CommonUtils.concatenate(
      CommonGetLocators.div,
      CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper
    ),
  ],

  TRANSACTION_DATE: [
    'Transaction Date',
    CommonUtils.concatenate(
      '#rp_transactionDate',
      ' ',
      CommonGetLocators.input
    ),
  ],
  TRANFER_TO_YES: [
    'Transfer To Yes',
    CommonUtils.concatenate(
      '#rp_transferCode_toggle',
      ' ',
      CommonGetLocators.div,
      ' ',
      CommonGetLocators.div
    ),
  ],
  GENERATE_BILL_YES: [
    'Transfer To Yes',
    CommonUtils.concatenate(
      '#rp_generateBill',
      ' ',
      CommonGetLocators.div,
      ' ',
      CommonGetLocators.div
    ),
  ],
  WRITEOFF_1_TRANSACTION_DROPDOWN: [
    'WriteOff 1 Transaction Code',
    '#rp_writeoff1TransactionDropdown',
  ],
  WRITEOFF_1_TRANSACTION_DROPDOWN_SEARCH: [
    'WriteOff 1 Transaction Code Search',
    '[class*="p-dropdown-filter-container"]',
  ],
  WRITEOFF_1_TRANSACTION_DROPDOWN_VALUE: [
    'WriteOff 1 Transaction Code Value',
    CommonUtils.concatenate(
      '#rp_writeoff1TransactionDropdown',
      ' ',
      CoreCssClasses.DropDown.loc_p_dropdown,
      ' ',
      CommonGetLocators.span
    ),
  ],
  WRITEOFF_2_TRANSACTION_DROPDOWN: [
    'WriteOff 2 Transaction Code',
    '#rp_writeoff2TransactionDropdown',
  ],
  WRITEOFF_2_TRANSACTION_DROPDOWN_VALUE: [
    'WriteOff 2 Transaction Code Value',
    CommonUtils.concatenate(
      '#rp_writeoff2TransactionDropdown',
      ' ',
      CoreCssClasses.DropDown.loc_p_dropdown,
      ' ',
      CommonGetLocators.span
    ),
  ],
  DROPDOWN_ITEM: ['Dropdown Item', '[class*="dropdown-item"]'],
  HISTORY: ['History', '#btnHistory'],
  REMITTANCE_HISTORY: [
    'Remittance history',
    CommonUtils.concatenate(
      '#rp_remittanceHistory',
      ' ',
      CommonGetLocators.tr,
      ' ',
      CommonGetLocators.th
    ),
  ],
  TRANSACTION_DETAILS: {
    DEDUCTIBLE: ['Deductible', ' #rp_deductible_amount'],
    COINS: ['CoIns', '#rp_coins_amount'],
    COPAY: ['Copay', '#rp_copay_amount'],
    PERIOD: ['Period', '#rp_de_periodDropdown'],
    BATCH: ['Batch', '#rp_de_batchDropdown'],
    METHOD_OF_PAYMENT: ['Method of payment', '#rp_de_payment_type'],
    TRANSFER_TO: ['Transfer to', '#rp_de_transfer_to'],
    TRANSFER: ['Transfer', '#rp_transfer_toggle'],
    GENERATE_BILL: ['Generate bill', '#rp_de_generateBill'],
    TRANSACTIONS: ['Transactions', '#divTransactions span'],
    TRANSACTION_TITLE: [
      'Transaction',
      CommonUtils.concatenate(
        '#rp_remittancedetails',
        ' ',
        CoreCssClasses.Text.loc_datable_thead
      ),
    ],
    CPTCDT_CODE: [
      'CPT CDT code',
      CoreCssClasses.Dialog.loc_dialog_footer,
      ' sis-cpt-copy-right',
    ],
    DONE_BUTTON: ['Done', '#rp_trans_details_btn_done span'],
    PAYMENT: ['Payment', '#payment1'],
    TRANSACTION_HEADER: ['Transaction Header', '#hDetailsEditing'],
    DOS: ['DOS', '#lblRpDOS+span'],
    CPT_HCPS: ['CPT?HCPS', '#lblRpCptHcpcs+span'],
    BALANCE_DUE: ['Balance due', '#lblBalanceDue+span'],
    ALLOWED_AMOUNT: ['Allowed amount', '#lblRpAllowedAmount+span'],
    CHARGE_AMOUNT: ['Charge amount', '#lblRpChargeAmount+span'],
    RESPONSIBLE_PARTY: [
      'Responsible party',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        CoreCssClasses.Button.loc_p_element,
        CoreCssClasses.Label.loc_label_content
      ),
    ],
    RECEIVED_FROM: [
      'Received from',
      CommonUtils.concatenate(
        '.only-padding-bottom',
        ' ',
        CoreCssClasses.Button.loc_p_element,
        CoreCssClasses.Label.loc_label_content
      ),
    ],
    PAYMENT_ID: ['Payment id', '#lblRpPaymentId+span'],
    TRANSACTION_DATE: ['Transaction Date', '#lblRpTransactionDate+span'],
    TOTAL_PAYMENT: ['Total payment', '#lblTotalPayments'],
    TOTAL_WRITE_OFF: ['Total write-off', '#lblTotalWriteOffs'],
  },
  CONFIRM_REMITTANCE_POSTING: {
    MRN: [
      'MRN',
      CommonUtils.concatenate(CommonGetLocators.td, ' ', 'span.gcol-2'),
    ],
    DOS: [
      'DOS',
      CommonUtils.concatenate(CommonGetLocators.td, ' ', 'span.gcol-3'),
    ],
    CPT_HCPCS: [
      'CPT/HCPS',
      CommonUtils.concatenate(
        '#rp_remittancePostingHistory',
        ' ',
        CommonGetLocators.td,
        '.cpt-or-hcpcs div'
      ),
    ],
    PAYMENT: [
      'Payment',
      CommonUtils.concatenate(
        '#rp_remittancePostingHistory',
        ' ',
        CommonGetLocators.td,
        '.payment span'
      ),
    ],
    WRITE_OFF_1: [
      'Write-off 1',
      CommonUtils.concatenate(
        '#rp_remittancePostingHistory',
        ' ',
        CommonGetLocators.td,
        '.writeoff1 span'
      ),
    ],
    WRITE_OFF_2: [
      'Write-off 2',
      CommonUtils.concatenate(
        '#rp_remittancePostingHistory',
        ' ',
        CommonGetLocators.td,
        '.writeoff2 span'
      ),
    ],
    BALANCE_DUE: [
      'Balance due',
      CommonUtils.concatenate(
        '#rp_remittancePostingHistory',
        ' ',
        CommonGetLocators.td,
        '.balance-due span'
      ),
    ],
    PATIENT_NAME: [
      'Patient name',
      CommonUtils.concatenate(CommonGetLocators.td, '', 'span.gcol-1'),
    ],
  },
  SELECT_DATE: ['Select Date'],
  TRANSACTION_GRID: ['Transaction Grid'],
  MRN_SORT_ICON: [
    'Mrn Sort Icon',
    CommonUtils.concatenate(
      '[class*="p-element mrn p-sortable"]',
      ' ',
      CoreCssClasses.Icon.loc_p_sort_icon
    ),
  ],
  MRN_SORT: ['Mrn Sort', '[class*="p-element mrn p-sortable"]'],
  DOS_SORT_ICON: [
    'Dos Sort Icon',
    CommonUtils.concatenate(
      '[class*="p-element dos p-sortable"]',
      ' ',
      CoreCssClasses.Icon.loc_p_sort_icon
    ),
  ],
  DOS_SORT: ['Dos Sort', '[class*="p-element dos p-sortable"]'],
  PATIENT_NAME_SORT_ICON: [
    'Patient Sort Icon',
    CommonUtils.concatenate(
      '[class*="p-element patient-name p-sortable"]',
      ' ',
      CoreCssClasses.Icon.loc_p_sort_icon
    ),
  ],
  PATIENT_COLUMN: ['Patient Colum', '[class="patient-name"] '],
  DATE: ['Date'],
  CPT_CODE: ['Cpt Code'],
  PAYMENT_TRANSACTION_GRID: ['Payment'],
  WRITEOFF1_TRANSACTION_GRID: ['Writeoff1'],
  WRITEOFF2_TRANSACTION_GRID: ['Writeoff2'],
  DEBIT_TRANSACTION_GRID: ['Debit'],
  TRANSFER_TO_TRANSACTION_GRID: ['Transfer To'],
  CALENDER_PREVIOUS_ICON: [
    'Previous Icon',
    '[class*="p-datepicker-prev-icon"]',
  ],
  UNASSIGNED_PAYMENT_TABLE: [
    'Unassigned Payments',
    '#rp_tbl_UnassignedPaymentsData',
  ],
  GENERATE_BILL_ICON: ['Generate Bill Icon', '#iconGenerateBill'],
};
