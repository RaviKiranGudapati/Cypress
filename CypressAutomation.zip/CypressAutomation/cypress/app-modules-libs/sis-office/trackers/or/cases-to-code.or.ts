import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_CASES_TO_CODE = {
  CODING: {
    SELECT_ALL_SCHEDULE_PROCEDURES: [
      'Select All Schedule Procedures',
      CommonUtils.concatenate(
        CoreCssClasses.Checkbox.loc_table_header_checkbox,
        ' ',
        CoreCssClasses.Checkbox.loc_checkbox
      ),
    ],
    SCHEDULED_PROCEDURES_LIST: [
      'Scheduled Procedure List Item',
      CommonUtils.concatenate(
        CoreCssClasses.Checkbox.loc_table_checkbox,
        ' ',
        CoreCssClasses.Checkbox.loc_checkbox
      ),
    ],
    ADD_SELECTED_TO_PERFORMED: [
      'Add Selected to Performed',
      '#btnAddPerformedItems',
    ],
    PERFORMED_CASES_PANEL: [
      'Selected Performed Cases',
      CommonUtils.concatenate(
        '#piPerformedCases ',
        CoreCssClasses.Panel.loc_p_panel
      ),
    ],
    EXPAND_PLUS_ICON: ['Plus Icon', CoreCssClasses.Icon.loc_expand_icon()],
    EXPAND_MINUS_ICON: ['Minus Icon', CoreCssClasses.Icon.loc_collapse_icon()],
    SEARCH_DIAGNOSIS_CODE: ['Diagnosis Code', '#diagnosisSearchText'],
    DIAGNOSIS_CODE_LIST: [
      'Diagnosis List',
      CoreCssClasses.List.loc_diagnosis_list_item,
    ],
    READY_FOR_CHARGE_YES_BUTTON: [
      'Yes',
      '#inpsReadyForCharge span:contains("Yes")',
    ],
    ADD_PROCEDURE: ['Add Procedure', '#btnAddProcedure'],
    PROCEDURE_DESCRIPTION: [
      'Procedure Description',
      '#procedureAutoComplete input',
    ],
    PROCEDURE_SELECTION: [
      'Cpt Code Selection',
      CoreCssClasses.List.loc_procedure_item,
    ],
    OK_BUTTON: ['OK'],
    UNITS: ['Units', `#numericInput`],
    HCPCS: ['HCPCS', `input[placeholder='HCPCS']`],
    DOCUMENTATION: {
      IMPLANT_PROSTHETIC: ['Implant', '.implant-prosthetic-col'],
      MANUFACTURER: ['Manufacturer', '.manufacturer-col'],
      TYPE: ['Type', '.type-col'],
      SIZE: ['Size', '.size-col'],
      LOT_NO: ['Lot #', '.lot-col'],
      EXPIRATION: ['Expiration', '.expiration-col'],
      SERIAL_NO: ['Serial #', '.serialNum-col'],
      REFERENCE: ['Reference', '.referenceNum-col'],
      NOTES: ['Notes', '.notes-col'],
    },
  },
};
