import {
  Application,
  CommonGetLocators,
  UPContextMenuOptions,
  InvokeAttributes,
  ShouldMethods,
  confirmation,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';

import {
  PatientDetails,
  SelectRcmStatusInSummary,
  TurnOverToCollections,
} from '../../../test-data-models/sis-office/trackers/revenue-cycle-management.model';
import { UnAssignedAllocation } from '../../../test-data-models/sis-office/facesheet/facesheet-ledger.model';

import { OR_REVENUE_CYCLE_MANAGEMENT } from './or/revenue-cycle-management.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../shared/application-settings/or/enterprise-configuration.or';
import { OR_FACESHEET_LEDGER_TAB } from '../facesheet/or/facesheet-ledger.or';

import { responsibleParty } from './constants/revenue-cycle-management.const';
import { ShowMoreLess, DropDown, RefreshClearFilters, ShowHidePayments } from './enums/revenue-cycle-management.enum';

import LedgerTabFaceSheet from '../facesheet/facesheet-ledger';

import { RevenueCycleManagementApis } from './api/revenue-cycle-management.api';
import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

/* locators */
const table_header = CommonUtils.concatenate(
  CoreCssClasses.DataTable.loc_table_tag,
  ' ',
  CoreCssClasses.Text.loc_datable_thead,
  ' ',
  CommonGetLocators.tr
);

/* const values */
const allocate = 'Allocate';

/* instance variables */
const ledgerTabFaceSheet = new LedgerTabFaceSheet();

/**
 * Class for RevenueCycleManagement Page
 */
export default class RevenueCycleManagement {
  /* instance variables */
  private revenueCycleManagementApis = new RevenueCycleManagementApis();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();
  private orRcmDetails = OR_REVENUE_CYCLE_MANAGEMENT.RCM_DETAILS;

  /**
   * @details Verify Column Names in RCM Tracker
   * @param values Column Names will be passed from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyColumnsNameInRCMTracker(values: string[]) {
    cy.cGet(table_header)
      .first()
      .within(() => {
        Array.from({ length: values.length }).forEach(($val, $index) => {
          cy.cGet(`${selectorFactory.getThText(values[$index])}`);
        });
      });
  }

  /**
   * @details To select RCM tracker
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickOnRCMTracker() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptRcmTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectTracker(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
    );
  }

  /**
   * @details - clicking on the Responsible Party drop down
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  clickResponsiblePartyDropDown() {
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.RESPONSIBLE_PARTY[1],
      OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.RESPONSIBLE_PARTY[0],
      false,
      true
    );
  }

  /**
   * @details -  To select responsible parties in revenue cycle management under trackers
   * @param insuranceName - Responsible party to be selected should be passed
   * @API - API's are available - Implemented Completely
   * @author - Rakesh Donakonda
   */
  selectResponsibleParty(insuranceName: string[]) {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptSelectResponsiblePartyApi();

    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.DROPDOWN[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cType(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.SEARCH_FIELD[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.SEARCH_FIELD[0],
      responsibleParty[0]
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.MULTI_SELECT_WRAPPER[1],
        ' ',
        selectorFactory.getSpanText(responsibleParty[0])
      ),
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.MULTI_SELECT_WRAPPER[0]
    );

    cy.cRemoveMaskWrapper(Application.office);
    cy.cType(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.SEARCH_FIELD[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.SEARCH_FIELD[0],
      responsibleParty[0]
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.MULTI_SELECT_WRAPPER[1],
        ' ',
        selectorFactory.getSpanText(responsibleParty[0])
      ),
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.MULTI_SELECT_WRAPPER[0]
    );

    insuranceName.forEach(($ele) => {
      cy.cType(
        OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.SEARCH_FIELD[1],
        OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.SEARCH_FIELD[0],
        $ele
      );
      cy.cClick(
        CommonUtils.concatenate(
          OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.MULTI_SELECT_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText($ele)
        ),
        OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.MULTI_SELECT_WRAPPER[0]
      );
    });
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.RESPONSIBLE_PARTY_LABEL[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.RESPONSIBLE_PARTY_LABEL[1]
    );
    cy.cIntercept(interceptCollection);
    this.clickOnRefresh();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To select the patient row from charges list
   * @param carrier Provide the insurance provider
   * @param dos Provide the DOS
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  selectChargeBasedOnDOS(carrier: string, dos: string) {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForSelectPatientInRow();
    cy.cIntercept(interceptCollection);
    cy.cGet(selectorFactory.getTdText(carrier))
      .parents(CommonGetLocators.tr)
      .find(
        CommonUtils.concatenate(
          CommonGetLocators.td,
          OR_REVENUE_CYCLE_MANAGEMENT.DOS_COLUMN[1],
          ' ',
          selectorFactory.getSpanText(dos)
        )
      )
      .scrollIntoView({ easing: 'linear' })
      .click();
  }

  /**
   * @details - To click on Refresh button in Revenue Cycle Management
   * @API - API's are not available
   * @author - Rakesh Donakonda
   */
  clickOnRefresh() {
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.REFRESH_BUTTON[1],
      OR_REVENUE_CYCLE_MANAGEMENT.REFRESH_BUTTON[1]
    );
  }

  /**
   * @details - verifying the presence of options in the Responsible Party drop down
   * @param values - drop down values will be passed from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyResponsiblePartyDropDownValues(values: string[]) {
    this.clickResponsiblePartyDropDown();
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getSpanText(el), el);
    });
  }

  /**
   * @detail - To select the department from the facesheet page
   * @param option - values show Defaults or hide Defaults will be passed from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  clickShowLessMore(option: ShowMoreLess) {
    let locator = '';
    switch (option) {
      case ShowMoreLess.show_defaults:
        locator = OR_REVENUE_CYCLE_MANAGEMENT.SHOW_DEFAULTS[1];
        break;
      case ShowMoreLess.hide_defaults:
        locator = OR_REVENUE_CYCLE_MANAGEMENT.HIDE_DEFAULTS[1];
        break;
      default:
        break;
    }
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(locator, option, false, true);
  }

  /**
   * @detail - verifying the Filters visibility in the RCM Tracker
   * @param option - dropdown names will be passed from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyFiltersInRcmTracker(option: DropDown) {
    let dropdownSelector: string = '';
    switch (option) {
      case DropDown.responsible_party:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.RESPONSIBLE_PARTY[1];
        break;
      case DropDown.insurance_plan_type:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.INSURANCE_PLAN_TYPE[1];
        break;
      case DropDown.rcm_status:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.RCM_STATUS[1];
        break;
      case DropDown.claim_status:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.CLAIM_STATUS[1];
        break;
      case DropDown.denials:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.DENIALS[1];
        break;
      case DropDown.denial_reason:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.RESPONSIBLE_PARTY[1];
        break;
      case DropDown.aging_type:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.AGING_TYPE[1];
        break;
      case DropDown.aging_category:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.AGING_CATEGORY[1];
        break;
      case DropDown.payer_role:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.PAYER_ROLE[1];
        break;
      case DropDown.insurance_classification:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.INSURANCE_CLASSIFICATION[1];
        break;
      case DropDown.appointment_type:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.APPOINTMENT_TYPE[1];
        break;
      case DropDown.physician:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.PHYSICIAN[1];
        break;
      default:
        break;
    }
    cy.cIsVisible(dropdownSelector, option);
  }

  /**
   * @details -verify responsible party contact information labels in rcm
   * @param data values - Passing Carrier Name, Address, Phone from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyLabelsInResponsibleParty(dataValues: string[]) {
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY_LABELS[1]).each(
      function ($ele, index) {
        expect($ele.text().trim()).to.contain(dataValues[index]);
      }
    );
  }

  /**
   * @details verify responsible party contact information
   * @param fieldName - Label name in Responsible Party Section as Name, Address, Phone
   * @param  value - contact info to be verified in Responsible Party Section
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyResponsiblePartyFieldValues(fieldName: string, value: string) {
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY_LABELS[1])
      .contains(fieldName)
      .parents(CommonGetLocators.div)
      .find(selectorFactory.getLabelText(value))
      .should(ShouldMethods.contain_text, value);
  }

  /**
   * @details - Select multiple items in dropdown
   * @param option - Multi select dropdown Label name to be provided as param
   * @param  value - Value to be selected from dropdown
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  selectMultiSelectDropdownValue(option: DropDown, value: string[]) {
    const dropDownValue = CoreCssClasses.DropDown.loc_dropdown_item_multiselect;
    let dropdownSelector: string = '';
    switch (option) {
      case DropDown.responsible_party:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.RESPONSIBLE_PARTY[1];
        break;
      case DropDown.insurance_plan_type:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.INSURANCE_PLAN_TYPE[1];
        break;
      case DropDown.rcm_status:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.RCM_STATUS[1];
        break;
      case DropDown.claim_status:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.CLAIM_STATUS[1];
        break;
      case DropDown.aging_category:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.AGING_CATEGORY[1];
        break;
      case DropDown.payer_role:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.PAYER_ROLE[1];
        break;
      case DropDown.insurance_classification:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.INSURANCE_CLASSIFICATION[1];
        break;
      case DropDown.appointment_type:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.APPOINTMENT_TYPE[1];
        break;
      case DropDown.physician:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.PHYSICIAN[1];
        break;
      default:
        break;
    }
    cy.cClick(dropdownSelector, option);
    value.forEach((val: string) => {
      cy.cGet(dropDownValue).contains(val).click({
        force: true,
      });
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, option);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Verify Single Select items in dropdown
   * @param option - Single select dropdown Label name - Denial, Aging Type
   * @param  value - Value to be verified from dropdown
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifySingleSelectDropdownValue(option: DropDown, value: string[]) {
    const dropDownValue = CoreCssClasses.DropDown.loc_dropdown_item;
    let dropdownSelector: string = '';
    switch (option) {
      case DropDown.denials:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.DENIALS[1];
        break;
      case DropDown.aging_type:
        dropdownSelector = OR_REVENUE_CYCLE_MANAGEMENT.FILTERS.AGING_TYPE[1];
        break;
      default:
        break;
    }
    cy.cClick(dropdownSelector, option);
    value.forEach((val: string) => {
      cy.contains(dropDownValue, val);
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, option);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details Click and Verify Refresh and Clear Filters button
   * @param option - Refresh or Clear Filters button  to be provided as param
   * @API - API's are available and implemented completely
   * @author - Ravi Kiran
   */
  clickRefreshClearFilters(option: RefreshClearFilters) {
    let locator = '';
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForClearRefreshFilters();
    cy.cIntercept(interceptCollection);
    switch (option) {
      case RefreshClearFilters.refresh:
        locator = selectorFactory.getSpanText(
          OR_REVENUE_CYCLE_MANAGEMENT.REFRESH[0]
        );
        break;
      case RefreshClearFilters.clear_Filters:
        locator = selectorFactory.getSpanText(
          OR_REVENUE_CYCLE_MANAGEMENT.CLEAR_FILTERS[0]
        );
        break;
      default:
        break;
    }
    cy.cIsVisible(locator, option);
    cy.cClick(locator, option);
  }

  /**
   * @details - To verify the patient details in revenue cycle management
   * @param patientDetails - The details to be verified should be passed as patientDetails Model
   * @API - API's are not available
   * @author - Rakesh Donakonda
   */
  verifyThePatientDetailsInRcm(patientDetails: PatientDetails) {
    const patientName = `${patientDetails.LastName}, ${patientDetails.PatientFirstName}`;
    cy.cGet(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.PATIENT_NAME_IN_RCM[1],
        ' ',
        selectorFactory.getSpanText(patientName!)
      )
    )
      .parents(CommonGetLocators.tr)
      .within(() => {
        if (patientDetails.Dos !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.DOS_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.Dos!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.DOS_WITHIN_ROW_IN_RCM[0],
            patientDetails.Dos
          );
        }

        if (patientDetails.Balance !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.BALANCE_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.Balance!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.BALANCE_WITHIN_ROW_IN_RCM[0],
            patientDetails.Balance
          );
        }

        if (patientDetails.ResponsibleParty !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT
                .RESPONSIBLE_PARTY_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.ResponsibleParty!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY_WITHIN_ROW_IN_RCM[0],
            patientDetails.ResponsibleParty
          );
        }

        if (patientDetails.TransferDate !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.TRANSFER_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.TransferDate!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.TRANSFER_WITHIN_ROW_IN_RCM[0],
            patientDetails.TransferDate
          );
        }

        if (patientDetails.PatientFirstName !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.PATIENT_NAME_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientName)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.PATIENT_NAME_WITHIN_ROW_IN_RCM[0],
            patientName
          );
        }

        if (patientDetails.Mrn !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.MRN_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.Mrn!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.MRN_WITHIN_ROW_IN_RCM[0],
            patientDetails.Mrn
          );
        }

        if (patientDetails.ArDays !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.ARDAYS_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.ArDays!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.ARDAYS_WITHIN_ROW_IN_RCM[0],
            patientDetails.ArDays
          );
        }

        if (patientDetails.FollowUpDate !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.FOLLOW_UP_DATE_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.FollowUpDate!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.FOLLOW_UP_DATE_WITHIN_ROW_IN_RCM[0],
            patientDetails.FollowUpDate
          );
        }

        if (patientDetails.Status !== undefined) {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_REVENUE_CYCLE_MANAGEMENT.STATUS_WITHIN_ROW_IN_RCM[1],
              ' ',
              selectorFactory.getSpanText(patientDetails.Status!)
            ),
            OR_REVENUE_CYCLE_MANAGEMENT.STATUS_WITHIN_ROW_IN_RCM[0],
            patientDetails.Status
          );
        }
      });
  }

  /**
   * @details - To select the required patient row in RCM tracker
   * @param patientName - combination of patient lastName and patient firstName as to be passed
   * @API - API's are available - Implemented Completely
   * @author - Rakesh Donakonda
   */
  selectPatientRowInRCM(patientName: string) {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptSelectPatientRowInRcmApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.PATIENT_NAME_WITHIN_ROW_IN_RCM[1],
        ' ',
        selectorFactory.getSpanText(patientName)
      ),
      OR_REVENUE_CYCLE_MANAGEMENT.PATIENT_NAME_WITHIN_ROW_IN_RCM[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To select the UP context menu icon
   * @API - API's are not available
   * @author - Nikitan
   */
  clickUPContextMenu(receivedFrom: string) {
    cy.cGet(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.RCM_PAYMENT_TABLE[1],
        ' ',
        selectorFactory.getSpanText(receivedFrom)
      )
    )
      .parents(CommonGetLocators.tr)
      .find(CommonGetLocators.i)
      .click();
  }

  /**
   * @details To select the Allocate button
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickAllocate() {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForClickOnAllocate();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getSpanText(UPContextMenuOptions.allocate),
      UPContextMenuOptions.allocate
    );
  }

  /**
   * @details - This is used to select the RCM Status in RCM Summary
   * @param rcmStatus - rcmStatus is  model which contains Cpt, RmStatus
   * @API - API's are not available
   * @author - Rakesh Donakonda
   */
  selectRcmStatusInSummary(rcmStatus: SelectRcmStatusInSummary) {
    cy.cGet(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.CPT_IN_CHARGES[1],
        ' ',
        selectorFactory.getSpanText(rcmStatus.Cpt)
      )
    )
      .parents(OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.SIS_RCM_TAG[1])
      .within(() => {
        cy.cClick(
          OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.RCM_STATUS[1],
          OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.RCM_STATUS[1]
        );
      });
    cy.cClick(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.RCM_DROPDOWN_WRAPPER[1],
        ' ',
        selectorFactory.getSpanText(rcmStatus.RcmStatus)
      ),
      OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.RCM_DROPDOWN_WRAPPER[0]
    );
  }

  /**
   * @details - To select the check box of the patient in RCM tracker
   * @param patientName - The patientName has to be passed
   * @API - API's are not available
   * @author - Rakesh Donakonda
   */
  clickPatientCheckBox(patientName: string) {
    cy.cGet(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.PATIENT_NAME_WITHIN_ROW_IN_RCM[1],
        ' ',
        selectorFactory.getSpanText(patientName)
      )
    )
      .parents(CommonGetLocators.tr)
      .within(() => {
        cy.cClick(
          OR_REVENUE_CYCLE_MANAGEMENT.CHECK_BOX_WITHIN_ROW_IN_RCM[1],
          OR_REVENUE_CYCLE_MANAGEMENT.CHECK_BOX_WITHIN_ROW_IN_RCM[0],
          false,
          false,
          { force: true }
        );
      });
  }

  /**
   * @details - To click on the turnover to collection button
   * @API - API's are not available
   * @author - Rakesh Donakonda
   */
  clickOnTurnOverToCollection() {
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_BUTTON[1],
      OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_BUTTON[0]
    );
  }

  /**
   * @details - To select new rcm status in turnover to collection pop up
   * @param status - status to be selected should be passed
   * @API - API's are not available
   * @author - Rakesh Donakonda
   */
  selectNewRcmStatus(status: string) {
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
        .NEW_RCM_STATUS[1],
      OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP.NEW_RCM_STATUS[0]
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .NEW_RCM_STATUS_WRAPPER[1],
        ' ',
        selectorFactory.getSpanText(status)
      ),
      OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
        .NEW_RCM_STATUS_WRAPPER[0]
    );
  }

  /**
   * @details - To select Yes or No for Write Off All Selected Charges
   * @param option - YesOrNo as to be passed
   * @API - API's are not available
   * @author - Rakesh Donakonda
   */
  selectWriteOffAllSelectedCharges(option: string) {
    cy.cClick(
      selectorFactory.selectWriteOffAllSelectedChargesYesOrNo(option),
      ' '
    );
  }

  /**
   * @details - To click on the Done button in the RCM summary
   * @API - API's are available - Implemented Completely
   * @author - Rakesh Donakonda
   */
  clickDoneButton() {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptClickDoneButton();
    cy.cRemoveMaskWrapper(Application.office);
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.DONE_BUTTON[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RCM_SUMMARY.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Enter value in text fields
   * @param locLogicalName - field Name  passing PatientFrom/To/Date
   * @param value -  to be entered in text box
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  enterPatientNameFollowUpDate(locLogicalName: string, value: any) {
    let locator: string = '';
    switch (locLogicalName) {
      case OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMEFROM[0]:
        locator = OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMEFROM[1];
        break;
      case OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMETO[0]:
        locator = OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMETO[1];
        break;
      case OR_REVENUE_CYCLE_MANAGEMENT.FOLLOW_UP_DATE[0]:
        locator = OR_REVENUE_CYCLE_MANAGEMENT.FOLLOW_UP_DATE[1];
        break;
      default:
        break;
    }
    cy.cType(locator, locLogicalName, value);
    cy.cIsVisible(locator, locLogicalName);
  }

  /**
   * @details - verifying the Filters visibility in the RCM Tracker
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyDefaultFiltersInRcmTracker() {
    cy.cIsVisible(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY_DROPDOWN[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY_DROPDOWN[0]
    );
    cy.cIsVisible(
      OR_REVENUE_CYCLE_MANAGEMENT.INSURANCE_CLASSIFICAITON_DROPDOWN[1],
      OR_REVENUE_CYCLE_MANAGEMENT.INSURANCE_CLASSIFICAITON_DROPDOWN[0]
    );
    cy.cIsVisible(
      OR_REVENUE_CYCLE_MANAGEMENT.RCM_STATUS_DROPDOWN[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RCM_STATUS_DROPDOWN[0]
    );
    cy.cIsVisible(
      OR_REVENUE_CYCLE_MANAGEMENT.DENIALS_DROPDOWN[1],
      OR_REVENUE_CYCLE_MANAGEMENT.DENIALS_DROPDOWN[0]
    );
  }

  /**
   * @details -To verify Paginator exists or not in RCM Tracker
   * @param option -To provide boolean true or false
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyPaginationExists(option: boolean = true) {
    option
      ? cy.cIsVisible(
          OR_REVENUE_CYCLE_MANAGEMENT.PAGINATOR[1],
          OR_REVENUE_CYCLE_MANAGEMENT.PAGINATOR[1]
        )
      : cy.cNotExist(
          OR_REVENUE_CYCLE_MANAGEMENT.PAGINATOR[1],
          OR_REVENUE_CYCLE_MANAGEMENT.PAGINATOR[1]
        );
  }

  /**
   * @details To select the patient row from tracker list
   * @param - rowIdentifier Patient Name to be provided as param
   * @API - API's are available and implemented completely
   * @author - Ravi Kiran
   */
  selectTableRow(rowIdentifier: string) {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForSelectPatientInRow();
    cy.cIntercept(interceptCollection);
    cy.cGet(selectorFactory.getTdText(rowIdentifier))
      .first()
      .scrollIntoView({ easing: 'linear' })
      .click();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To verify the waystar icon sent
   * @param state To verify the state of the icon, visible or invisible
   * @API - API's are not available
   * @author - Nikitan
   */
  verifyWaystarIcon(state: string) {
    cy.cHasAttribute(
      OR_REVENUE_CYCLE_MANAGEMENT.RCM_STATUS_INDICATOR[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RCM_STATUS_INDICATOR[0],
      InvokeAttributes.class,
      state
    );
  }

  /**
   * @details - open Billing History
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickOnBillingHistory() {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForBillingHistory();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.BILLING_HISTORY[1],
      OR_REVENUE_CYCLE_MANAGEMENT.BILLING_HISTORY[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To click on Done button in UP allocation dialog
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickDoneAllocation() {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForAllocationDone();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION_DONE[1],
      OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION_DONE[0]
    );
  }

  /**
   * @details - Select Charges in the billing history
   * @param- index of the charge to be selected
   * @API - API's are not available
   * @author - Nikitan
   */
  selectChargesCheckBox(index: number) {
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.BILLING_HISTORY_CHARGE_CHECKBOX[1])
      .eq(index)
      .click();
  }

  /**
   * @details - click on bill selected insurance charge and click on OK button
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickBillSelectedInsuranceCharge() {
    const interceptCollectionBill =
      this.revenueCycleManagementApis.interceptForBillSelectedInsuranceCharge();
    const interceptCollectionOk =
      this.revenueCycleManagementApis.interceptForRCMChargeInsurance();
    cy.cIntercept(interceptCollectionBill);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_INSURANCE_CHARGE[1],
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_INSURANCE_CHARGE[0]
    );
    cy.cWaitApis(interceptCollectionBill);
    cy.cIntercept(interceptCollectionOk);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT_OK[1],
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT_OK[0]
    );
    cy.cWaitApis(interceptCollectionOk);
  }

  /**
   * @details - click on bill selected patient statement
   * @API - API's are not available
   * @author - Nikitan
   */
  clickBillSelectedPatientStatement() {
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT[1],
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT[0]
    );
  }

  /**
   * @details - click on yes or no in bill selected patient statement confirmation dialog
   * @param option to be clicked on, Yes or No
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickYesOrNoBillSelectedPatientStatement(option = true) {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForBillPatientStatementYesOrNo();
    cy.cIntercept(interceptCollection);
    option
      ? cy
          .cGet(
            OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT_YES[1]
          )
          .eq(0)
          .click({ force: true })
      : cy
          .cGet(
            OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT_NO[1]
          )
          .eq(0)
          .click({ force: true });
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT_OK[1]
    );
  }

  /**
   * @details - Verify Bill Selected Patient Dialog Bill Sent confirmation
   * @API - API's are not available
   * @author - Nikitan
   */
  verifyStatementSentDialog() {
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.BILL_CONFIRMATION_POPUP_HEADER[1])
      .eq(0)
      .should(
        ShouldMethods.include_text,
        OR_REVENUE_CYCLE_MANAGEMENT.BILL_CONFIRMATION_POPUP_HEADER[0]
      );
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.BILL_CONFIRMATION_TEXT[1])
      .eq(0)
      .should(ShouldMethods.include_text, confirmation.statement_sent);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT_OK[1],
      OR_REVENUE_CYCLE_MANAGEMENT.BILL_SELECTED_PATIENT_STATEMENT_OK[0]
    );
  }

  /**
   * @details - click on bill selected patient statement
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickPrintSelectedInsuranceCharge() {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForPrintInsuranceCharge();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.PRINT_SELECTED_INSURANCE_CHARGE[1],
      OR_REVENUE_CYCLE_MANAGEMENT.PRINT_SELECTED_INSURANCE_CHARGE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - selecting period and batch Labels in Ledger
   * @API - API's are not available
   * @author Nikitan
   */
  clickPeriodAndBatchLabel() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getLabelText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0]
      ),
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getLabelText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0]
      ),
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0],
      false,
      true
    );
  }

  /**
   * @details - Select the values from dropdown  in unassigned allocation  popup.
   * @param - dropdown and valueToSelect - as parameters in function
   * @API - API's are not available
   * @author Nikitan
   */
  unassignedPaymentAllocationSelectDropdown(
    dropdown: string,
    valueToSelect: string
  ) {
    let dropdownSelector = '';
    let value = selectorFactory.getDropdownValues(valueToSelect);
    let dropdownLogicalName = '';
    switch (dropdown) {
      case OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0]:
        dropdownSelector =
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[1];
        dropdownLogicalName =
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0];
        break;
      case OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0]:
        dropdownSelector =
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[1];
        dropdownLogicalName =
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0];
        break;
      case OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION.TRANSACTION_CODE[0]:
        dropdownSelector =
          OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION.TRANSACTION_CODE[1];
        dropdownLogicalName =
          OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION.TRANSACTION_CODE[0];
        break;
      default:
        break;
    }
    cy.cClick(dropdownSelector, dropdownLogicalName);
    cy.cClick(value, value);
  }

  /**
   * @details - close print pop-up
   * @API - API's are not available
   * @author - Nikitan
   */
  closePrintPopup() {
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.CLOSE_PRINT_PREVIEW[1],
      OR_REVENUE_CYCLE_MANAGEMENT.CLOSE_PRINT_PREVIEW[0],
      false,
      false,
      { force: true }
    );
  }

  /**
   * @details - Print selected patient statements
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickPrintSelectedPatientStatement() {
    const interceptCollection =
      this.revenueCycleManagementApis.interceptForPrintPatientStatement();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.PRINT_SELECTED_PATIENT_STATEMENT[1],
      OR_REVENUE_CYCLE_MANAGEMENT.PRINT_SELECTED_PATIENT_STATEMENT[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - close billing history pop-up
   * @API - API's are not available
   * @author - Nikitan
   */
  closeBillingHistory() {
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.CLOSE_ICON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.CLOSE_ICON[0]
    );
  }

  /**
   * @detail - Performing scroll action to last row in table
   * @API - API's are not available
   * @author - Nikitan
   */
  scrollToLastRowInTracker() {
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.ROWS[1]).last().scrollIntoView();
  }

  /**
   * @details Allocate UP amount to a charge from UP amount payer
   * @param - allocate UnAssignedAllocation test model as parameter
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  allocateUPAmount(allocate: UnAssignedAllocation) {
    cy.cGet(
      selectorFactory.getUPAmountReceivedFromInRCM(allocate.ReceivedFrom!)
    )
      .first()
      .parents(CommonGetLocators.tr)
      .find(OR_REVENUE_CYCLE_MANAGEMENT.UNASSIGNED_PAYMENT.CONTEXT_MENU[1])
      .click();
    cy.cClick(
      selectorFactory.getSpanText(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.COLUMN_SIX_CHARGE_TO_ALLOCATE[0]
      ),
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.COLUMN_SIX_CHARGE_TO_ALLOCATE[0]
    );
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0]
    );
    cy.cClick(
      selectorFactory.getDropdownValues(allocate.TransactionCode!),
      allocate.TransactionCode!
    );
    cy.cGet(
      selectorFactory.getPatientCharge(allocate.CPTHCPCSCode),
      allocate.CPTHCPCSCode
    )
      .parents(CommonGetLocators.tr)
      .find(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
          .DISCOUNT_PERCENT[1]
      )
      .clear({ force: true })
      .focus()
      .type(allocate.AmountAllocation!, { force: true });
    const interceptCollection =
      this.revenueCycleManagementApis.interceptAllocateUpAmount();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_footer,
        ' ',
        CoreCssClasses.Button.loc_button_tag
      ),
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Verify received from information based on the amount allocated
   * @param - amount as Parameters in the function, Pass amount value for which received from is to be verified
   * @param - receivedFrom as Parameters in the function, Pass expected received from value
   * @API - API's are not available
   * @author - Nikitan
   */
  verifyReceivedFromUPAmount(amount: string, receivedFrom: string) {
    cy.cGet(selectorFactory.getUPAmountAllocatedInRCM(amount))
      .parents(CommonGetLocators.tr)
      .find(OR_REVENUE_CYCLE_MANAGEMENT.UNASSIGNED_PAYMENT.RECEIVED_FROM_COL[1])
      .should(ShouldMethods.include_text, receivedFrom);
  }

  /**
   * @details - To document the fields in Turnover To Collection pop up model
   * @param turnoverToCollection - Fields to be selected to be passed
   * @API - Api's are not available
   * @author - Rakesh Donakonda
   */
  selectFieldsTurnOverToCollection(
    turnoverToCollection: TurnOverToCollections
  ) {
    if (turnoverToCollection.WriteOffAllSelectedCharges) {
      cy.cClick(
        selectorFactory.selectWriteOffAllSelectedChargesYesOrNo(
          turnoverToCollection.WriteOffAllSelectedCharges
        ),
        ' '
      );
    }

    if (turnoverToCollection.Period) {
      cy.cRemoveMaskWrapper(Application.office);
      cy.cClick(
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP.PERIOD[1],
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP.PERIOD[0]
      );
      cy.cClick(
        CommonUtils.concatenate(
          OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
            .NEW_RCM_STATUS_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText(turnoverToCollection.Period!)
        ),
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .NEW_RCM_STATUS_WRAPPER[0]
      );
    }

    if (turnoverToCollection.Batch) {
      cy.cClick(
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP.BATCH[1],
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP.BATCH[0]
      );
      cy.cClick(
        CommonUtils.concatenate(
          OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
            .NEW_RCM_STATUS_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText(turnoverToCollection.Batch!)
        ),
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .NEW_RCM_STATUS_WRAPPER[0]
      );
    }

    if (turnoverToCollection.TransactionDate) {
      cy.cType(
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .TRANSACTION_DATE[1],
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .TRANSACTION_DATE[0],
        turnoverToCollection.TransactionDate
      );
    }

    if (turnoverToCollection.NewRcmStatus) {
      cy.cClick(
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .NEW_RCM_STATUS[1],
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .NEW_RCM_STATUS[0]
      );
      cy.cClick(
        CommonUtils.concatenate(
          OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
            .NEW_RCM_STATUS_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText(turnoverToCollection.NewRcmStatus)
        ),
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .NEW_RCM_STATUS_WRAPPER[0]
      );
    }

    if (turnoverToCollection.TransactionCode) {
      cy.cClick(
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .TRANSACTION_CODE[1],
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .TRANSACTION_CODE[0]
      );
      cy.cClick(
        CommonUtils.concatenate(
          OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
            .NEW_RCM_STATUS_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText(turnoverToCollection.TransactionCode)
        ),
        OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
          .NEW_RCM_STATUS_WRAPPER[0]
      );
    }
  }

  /**
   * @details - To select Insurance for Responsible Party
   * @param insurance passing as param to select Insurance in Responsible Party
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  selectInsurance(insurance: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(CoreCssClasses.Row.loc_p_selectable_row).last().scrollIntoView();
    cy.cWaitForElementToBeAttached(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.DROPDOWN[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.DROPDOWN[0]
    );
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.DROPDOWN[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY.DROPDOWN[0],
      false,
      true
    );
    cy.cIsVisible(
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY_SEARCH[1],
      OR_REVENUE_CYCLE_MANAGEMENT.RESPONSIBLE_PARTY_SEARCH[0]
    );
    cy.cClick(
      selectorFactory.getDropdownValues(insurance),
      OR_REVENUE_CYCLE_MANAGEMENT.INSURANCE_DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To select Patient in RCM tracker based on rowNo
   * @param - rowIdentifier passing as param to select patient
   * @param - logicalName passing as param to select patient
   * @param - rowNo passing as param to select patient
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  selectPatient(rowIdentifier: string, logicalName: string, rowNo: number) {
    cy.cGet(selectorFactory.getTdText(rowIdentifier), logicalName)
      .eq(rowNo)
      .click();
  }

  /**
   * @details - Enter the details in allocation popup
   * @param - allocation is model reference inside the function
   * @API - API's are not available
   * @author Nikitan
   */
  unassignedPaymentAllocation(allocation: UnAssignedAllocation) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    this.unassignedPaymentAllocationSelectDropdown(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0],
      allocation.Period!
    );
    this.unassignedPaymentAllocationSelectDropdown(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0],
      allocation.Batch!
    );
    this.unassignedPaymentAllocationSelectDropdown(
      OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION.TRANSACTION_CODE[0],
      allocation.TransactionCode
    );
  }

  /**
   * @param -allocation passing as param to select filed's in allocation popup
   * @param -rowNo passing as param to select filed's in allocation popup based on rowNo value
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  allocateUnassignedPayment(allocation: UnAssignedAllocation, rowNo: string) {
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.UNASSIGNED_PAYMENT.DOWN_CONTEXT[1],
      OR_REVENUE_CYCLE_MANAGEMENT.UNASSIGNED_PAYMENT.DOWN_CONTEXT[0]
    );
    cy.shouldBeEnabled(selectorFactory.getSpanClassText(allocate));
    cy.cClick(
      selectorFactory.getSpanClassText(allocate),
      OR_REVENUE_CYCLE_MANAGEMENT.UNASSIGNED_PAYMENT.ALLOCATE[0]
    );
    ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0],
      allocation.Period!
    );
    ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0],
      allocation.Batch!
    );
    ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0],
      allocation.TransactionCode
    );
    ledgerTabFaceSheet.enterAllocationAmount(
      allocation.AmountAllocation,
      rowNo
    );
    cy.cClick(
      OR_REVENUE_CYCLE_MANAGEMENT.UNASSIGNED_PAYMENT.DONE[1],
      OR_REVENUE_CYCLE_MANAGEMENT.UNASSIGNED_PAYMENT.DONE[0]
    );
  }

  /**
   * @details Allocation Amount in Unassigned Payment Allocation Popup
   * @param - amount,cpt parameters in the function
   * @API - API's are not available
   * @author Nikitan
   */
  amountAllocation(amount: string, cpt: string) {
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION.CHARGE_TO_ALLOCATE_ROW[1])
      .contains(cpt)
      .parents(CommonGetLocators.tr)
      .find(
        CommonUtils.concatenate(
          OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION
            .COLUMN_SIX_CHARGE_TO_ALLOCATE[1],
          ' ',
          CommonGetLocators.input
        )
      )
      .clear({ force: true })
      .focus()
      .type(amount, { force: true });
  }

  /**
   * @details To verify the amount for a charge allocated in Allocation window
   * @param - amount,cpt parameters in the function
   * @API - API's are not available
   * @author Nikitan
   */
  verifyAmountAllocationInPopUp(amount: string, cpt: string) {
    cy.cGet(OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION.CHARGE_TO_ALLOCATE_ROW[1])
      .contains(cpt)
      .parents(CommonGetLocators.tr)
      .find(
        CommonUtils.concatenate(
          OR_REVENUE_CYCLE_MANAGEMENT.ALLOCATION
            .COLUMN_SIX_CHARGE_TO_ALLOCATE[1],
          ' ',
          CommonGetLocators.input
        )
      )
      .should(ShouldMethods.value, amount);
  }

  /**
   * @details -verify insurance information labels in rcm
   * @param datavalues - Passing Carrier Name, Address, Phone from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyLabelsInInsuranceTab(datavalues: string[]) {
    cy.cGet(
      this.orRcmDetails.RESPONSIBLE_PARTY_LABELS[1]
    ).each(function ($ele, index) {
      expect($ele.text().trim()).to.contain(datavalues[index]);
    });
  }

  /**
   * @details To verify select the tab names in RCM Case Details
   * @param tabName - To provide the tab names like Insurance/Subscriber
   * @Api - API's are not available
   * @author - Ravi Kiran
   */
  selectResponsiblePartyTab(tabName: string) {
    cy.cClick(selectorFactory.getAText(tabName), tabName, false, true, {
      force: true, // Added force true because in the dashboard sometimes click is not working
    });
  }

  /**
   * @details -verify responsible party Subscriber Field Values
   * @param datavalues - Passing Carrier Name, Address, Phone from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyLabelsInSubscriberTab(datavalues: string[]) {
    cy.cGet(this.orRcmDetails.SUBSCRIBER_LABELS[1]).each(
      function ($ele, index) {
        expect($ele.text().trim()).to.contain(datavalues[index]);
      }
    );
  }

  /**
   * @details verify Subscriber Field Values
   * @param fieldName - Label name in Subscriber tab as Name, Address, Phone
   * @param  value - contact info to be verified in Responsible Party Section
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifySubscriberFieldValues(fieldName: string, value: string) {
    cy.cGet(this.orRcmDetails.SUBSCRIBER_LABELS[1])
      .contains(fieldName)
      .parents(CommonGetLocators.div)
      .find(selectorFactory.getLabelText(value))
      .should(ShouldMethods.contain_text, value);
  }

  /**
   * @details To verify the Subscriber Field Values in Subscriber tab
   * @param - labels as parameters in function.
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifySubscriberFieldsData(
    subscriberLabels: string[],
    subscriberValues: string[]
  ) {
    cy.cGet(this.orRcmDetails.SUBSCRIBER_LABELS[1])
      .each(($labels, index) => {
        expect($labels.text().trim()).to.contain(subscriberLabels[index]);
      })
      .then(() => {
        cy.cGet(
          this.orRcmDetails.SUBSCRIBER.SUBSCRIBER_INFO[1]
        ).each(($data, index) => {
          expect($data.text().replace(/\n/g, '').trim()).to.includes(
            subscriberValues[index]
          );
        });
      });
  }

  /**
   * @details To verify the Insurance Field Values in Subscriber tab
   * @param - labels as parameters in function.
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  verifyInsuranceFieldValues(
    insuranceLabels: string[],
    insuranceValues: string[]
  ) {
    cy.cGet(this.orRcmDetails.RESPONSIBLE_PARTY_LABELS[1])
      .each(($labels, index) => {
        expect($labels.text().trim()).to.contain(insuranceLabels[index]);
      })
      .then(() => {
        cy.cGet(
          this.orRcmDetails.INSURANCE.INSURANCE_INFO[1]
        ).each(($data, index) => {
          expect($data.text().replace(/\n/g, '').trim()).to.includes(
            insuranceValues[index]
          );
        });
      });
  }

  /**
  /**
   * @detail - To Click on Show Payment/Hide Payment
   * @param option - values show Payment or hide Payment will be passed from constant values
   * @API - API's are not available
   * @author - Ravi Kiran
   */
  clickHideShowPayments(option: ShowHidePayments) {
    const optionMappings = {
      [ShowHidePayments.show_payments]: {
        locator: this.orRcmDetails.SHOW_PAYMENTS[1],
      },
      [ShowHidePayments.hide_payments]: {
        locator: this.orRcmDetails.HIDE_PAYMENTS[1],
      },
    };

    const selectedOption = optionMappings[option];

    if (selectedOption) {
      cy.cClick(selectedOption.locator, option, false, true);
    }
  }
}
