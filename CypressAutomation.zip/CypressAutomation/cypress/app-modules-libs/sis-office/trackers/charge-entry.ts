import {
  Application,
  CommonClassAttributes,
  ExpandOrCollapse,
  FilterMethods,
  HierarchyOptions,
  InvokeAttributes,
  InvokeMethods,
  ShouldMethods,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';

import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import {
  Adjustment,
  Charges,
  UBAdditionalClaim,
} from '../../../test-data-models/sis-office/trackers/combined-coding.model';
import {
  PatientCase,
  Cpt,
} from '../../../test-data-models/sis-office/case/patient-case.model';
import { CasesToCodeDetails } from '../../../test-data-models/sis-office/trackers/cases-to-code.model';
import { WriteOffs } from '../../../test-data-models/sis-office/facesheet/case-transaction.model';

import { OR_CHARGE_ENTRY } from './or/charge-entry.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_CASE_CREATION } from '../case-creation/or/create-case.or';
import { OR_FACESHEET_LEDGER_TAB } from '../facesheet/or/facesheet-ledger.or';
import { OR_FACESHEET_CASE_PAGE } from '../facesheet/or/facesheet-cases.or';
import { OR_FACE_SHEET_CHARGE_ENTRY } from '../facesheet/or/facesheet-chargentry.or';
import { OR_COMBINED_CODING } from './or/combined-coding.or';
import { OR_TRANSACTION } from '../facesheet/or/facesheet-transactions.or';

import Transactions from '../facesheet/facesheet-transactions';
import FaceSheetChargeEntry from '../facesheet/facesheet-chargeentry';
import CombinedCoding from './combined-coding';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';
import { ChargeEntryApis } from './api/charge-entry.api';
import { FacesheetChargeEntryApis } from '../facesheet/api/facesheet-chargeentry.api';
import { unitsOfMeasure, headersName } from './constants/charge-entry.const';
import { addNewItem } from './constants/combined-coding.const';
import { AdditionalClaimInformation, FreeText } from './enums/charge-entry.enum';

/* instance variables */
const transactions = new Transactions();
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();
const faceSheetChargeEntry = new FaceSheetChargeEntry();
/**
 * Class for ChargeEntry Page
 */
export default class ChargeEntry {
  /* instance variables */
  private chargeEntryApis = new ChargeEntryApis();
  private facesheetChargeEntryApi = new FacesheetChargeEntryApis();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  sisOfficeDesktop = new SISOfficeDesktop();

  constructor(private patientCaseInfo: PatientCase) {
    this.sisOfficeDesktop = new SISOfficeDesktop();
  }

  /**
   * @details - selecting period and batch in charge entry
   * removing mask wrapper and selecting patient
   * @param - chargesInfo
   * @API - API's are not available
   */
  selectPeriodAndBatch(chargesInfo: Charges) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    cy.cRemoveMaskWrapper(Application.office);
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[1],
        '',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      )
    );
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(chargesInfo.Period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cGet(selectorFactory.getDropdownValues(chargesInfo.Batch))
      .first()
      .click();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Entering the period, batch and selecting the patient in the charge Entry tracker
   * @param - chargesInfo
   * @API - API's are available and Implemented Completely
   * @Author Harsh Ranjan
   */
  selectCase(chargesInfo: Charges) {
    const interceptCollection =
      this.chargeEntryApis.interceptSelectingPatient();
    this.selectPeriodAndBatch(chargesInfo);
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.selectPatientRow(
      this.patientCaseInfo.PatientDetails.LastName!,
      this.patientCaseInfo.PatientDetails.PatientFirstName!
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - selecting the case from the charge entry tracker page and Performing charge Entry & verifying/clicking generate bill check box
   * @param - chargesInfo
   * @API - API's are available and Implemented Completely
   * @Author Harsh Ranjan
   */
  performChargeEntry(chargesInfo: Charges) {
    const interceptSelectingPatientCollection =
      this.chargeEntryApis.interceptSelectingPatient();
    this.sisOfficeDesktop.selectTracker(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
    );
    this.selectPeriodAndBatch(chargesInfo);
    cy.cIntercept(interceptSelectingPatientCollection);
    this.sisOfficeDesktop.selectPatientRow(
      this.patientCaseInfo.PatientDetails.LastName!,
      this.patientCaseInfo.PatientDetails.PatientFirstName!
    );
    cy.cWaitApis(interceptSelectingPatientCollection);
    cy.cClick(selectorFactory.getSpanText(YesOrNo.yes), YesOrNo.yes);
    const interceptCollection =
      this.chargeEntryApis.interceptReadyForBillYesDoneButtonApi();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verifying write off of an expanded procedure
   * @param - writeOffAmount
   * @API - API's are not available
   * @author - chandrika
   */
  validateWriteOff(writeOffAmount: string) {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.WRITEOFF_AMOUNT[1])
      .scrollIntoView()
      .should(ShouldMethods.contain_text, writeOffAmount);
  }

  /**
   * @details - Verifying balance amount of an expanded procedure code
   * @param - balanceAmount
   * @API - API's are not available
   * @author - chandrika
   */
  verifyBalance(balanceAmount: string) {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.BALANCE_AMOUNT[1]).should(
      ShouldMethods.contain_text,
      balanceAmount
    );
  }

  /**
   * @details - Verifying write Off is not present
   * @API - API's are not available
   * @author - chandrika
   */
  verifyNoChargeResults() {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.NO_RESULTS[1])
      .eq(0)
      .scrollIntoView()
      .should(ShouldMethods.visible);
  }

  /**
   * @details Removing primary insurance for the selected procedure
   * @param type - To pass Primary, Secondary or Tertiary
   * @API - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  removeInsurance(type: string) {
    const interceptCollection =
      this.chargeEntryApis.interceptPrimaryInsuranceCrossIconApi();
    switch (type) {
      case HierarchyOptions.primary:
        cy.cIntercept(interceptCollection);
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PRIMARY_INSURANCE_CLEAR[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PRIMARY_INSURANCE_CLEAR[0]
        );
        cy.cWaitApis(interceptCollection);
        break;
      case HierarchyOptions.secondary:
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.SECONDARY_INSURANCE_CLEAR[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.SECONDARY_INSURANCE_CLEAR[0]
        );
        break;
      case HierarchyOptions.tertiary:
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.TERTIARY_INSURANCE_CLEAR[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.TERTIARY_INSURANCE_CLEAR[0]
        );
        break;
      default:
        break;
    }
    // added remove mask wrapper for clicking on the next step
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details Adding primary insurance for selected procedure
   * @param type - To pass Primary, Secondary or Tertiary
   * @param - insuranceName
   * @API - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  addInsurance(type: HierarchyOptions, insuranceName: string) {
    const interceptCollection =
      this.chargeEntryApis.interceptPrimaryInsuranceCrossIconApi();
    const dropdownProperties = {
      [HierarchyOptions.primary]: {
        selector: OR_CHARGE_ENTRY.CHARGE_ENTRY.PRIMARY_INSURANCE[1],
      },
      [HierarchyOptions.secondary]: {
        selector: OR_CHARGE_ENTRY.CHARGE_ENTRY.SECONDARY_INSURANCE[1],
      },
      [HierarchyOptions.tertiary]: {
        selector: OR_CHARGE_ENTRY.CHARGE_ENTRY.TERTIARY_INSURANCE[1],
      },
    };
    const dropdownData = dropdownProperties[type];
    if (!dropdownData) {
      return;
    }

    const dropdownSelector = dropdownData.selector;
    cy.cGet(dropdownSelector).click();

    cy.cIntercept(interceptCollection);

    cy.cGet(selectorFactory.getSpanText(insuranceName)).click({ force: true });
    cy.cWaitApis(interceptCollection);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details Expand Collapse Procedure In Performed Items Based On CPT
   * @param - option where user can pass expand or collapse
   * @param - cptCode
   * @API - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  expandCollapseProcedureInPerformedItemsBasedOnCPT(
    option: ExpandOrCollapse,
    cptCode: string
  ) {
    const rowProperties = {
      [ExpandOrCollapse.expand]: {
        selector:
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_PLUS_ICON[1],
        logicalName:
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_PLUS_ICON[0],
      },
      [ExpandOrCollapse.collapse]: {
        selector:
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_MINUS_ICON[1],
        logicalName:
          OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_MINUS_ICON[0],
      },
    };
    const rowData = rowProperties[option];
    const interceptCollection = this.chargeEntryApis.interceptMinusIconApi();
    if (!rowData) {
      return;
    }
    cy.cGet(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.PERFORMED_ITEMS_PANEL[1]
    ).each(($element) => {
      if ($element.text().indexOf(cptCode) > -1) {
        cy.wrap($element)
          .first()
          .within(() => {
            if (option.toUpperCase() === ExpandOrCollapse.expand) {
              cy.cClick(
                OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS
                  .EXPAND_PLUS_ICON[1],
                OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_PLUS_ICON[0]
              );
            } else {
              cy.cIntercept(interceptCollection);
              cy.cClick(
                OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS
                  .EXPAND_MINUS_ICON[1],
                OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS
                  .EXPAND_MINUS_ICON[0]
              );

              cy.cWaitApis(interceptCollection);
            }
          });
      }
    });
  }

  /**
   * @details To add the procedure in Charge Entry file
   * @param cptData as reference model in the function.
   * @Api - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  addProcedure(cptData: Cpt) {
    const interceptAddProcedureApiCollection =
      this.chargeEntryApis.interceptAddProcedureApi();
    this.clickAddProcedureButton();
    cy.cRemoveMaskWrapper(Application.office);
    this.verifyAddProcedureMandatoryFields();
    cy.cIntercept(interceptAddProcedureApiCollection);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PROCEDURE_DESCRIPTION[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PROCEDURE_DESCRIPTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptAddProcedureApiCollection);

    cy.cIsVisible(
      selectorFactory.getTextInLimitTextContainer(
        cptData.CPTCodeAndDescription
      ),
      cptData.CPTCodeAndDescription
    );
    const interceptSelectProcedureSelfPayApiCollection =
      this.chargeEntryApis.interceptSelectProcedureSelfPayApi();
    cy.cIntercept(interceptSelectProcedureSelfPayApiCollection);
    cy.cSelectListItem(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PROCEDURE_SELECTION[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PROCEDURE_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptSelectProcedureSelfPayApiCollection);
    cy.cRemoveMaskWrapper(Application.office);
    // Removed the step to collapse the charge handled with different function based on api call.
    //  Removed the step to click on ready for bill yes and done button.
    //  Using clickReadyForBillAndDoneButton() method to click on ready for bill yes and done button.
  }

  /**
   * @details Click Ready For Bill Yes Button and Done Button
   * @param flag-- to be passed true or false(true if ready for bill is yes and false if ready for bill is false)
   * @API - API's are not available
   * @author Harsh
   */
  clickReadyForBillAndDoneButton(flag: boolean = false) {
    const interceptCollection = flag
      ? this.chargeEntryApis.interceptReadyForBillYesDoneButtonApi()
      : this.chargeEntryApis.interceptReadyForBillNoDoneButtonApi();

    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[0]
    );
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To click on Ready for bill in charge entry
   * @API - API's are not available
   */
  clickOnReadyForBill() {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[0]
    );
  }

  /**
   * @details - Uncheck Generate Bill Checkbox
   * @API - API's are not available
   * @author - chandrika
   */
  uncheckGenerateBill() {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.GENERATE_BILL[1]).then(($ele) => {
      if ($ele.hasClass(CoreCssClasses.Panel.loc_p_highlight)) {
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.GENERATE_BILL[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.GENERATE_BILL[0],
          false,
          true
        );
      }
    });
  }

  /**
   * @details To verify amount for charges
   * @param - amount as amount of the charge
   * @API - API's are not available
   * @author - chandrika
   */
  verifyChargeAmount(amount: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[0],
      amount
    );
  }

  /**
   * @detail - To verify patient in Charge Entry tracker
   * @param - patientFullName as patient complete name
   * @API - API's are not available
   * @author - chandrika
   */
  verifyPatientRow(patientFullName: string) {
    cy.cGet(selectorFactory.getSpanText(patientFullName))
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible);
  }

  /**
   * @details - Click balance header of an expanded procedure code
   * @API - API's are not available
   * @author - chandrika
   */
  clickBalanceLabel() {
    cy.cClick(
      selectorFactory.getSpanText(
        OR_CHARGE_ENTRY.CHARGE_ENTRY.BALANCE_AMOUNT[0]
      ),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BALANCE_AMOUNT[0]
    );
  }

  /**
   * @details To add the supply in Charge Entry file
   * @param cptData as reference model in the function.
   * @Api - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  addSupply(cptData: Cpt) {
    const interceptCollection =
      this.chargeEntryApis.interceptSearchAndSelectSupplyApi();
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES[0]
    );
    // Added remove mask wrapper helps to type in the CPT text box
    cy.cRemoveMaskWrapper(Application.office);
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(
      selectorFactory.getBText(cptData.CPTCodeAndDescription),
      cptData.CPTCodeAndDescription
    );
    cy.cIntercept(interceptCollection);
    cy.cSelectListItem(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SUPPLIES_SELECTION[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SUPPLIES_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To enter charge amount for charges
   * @param - amount
   * @API - API's are not available
   * @author - chandrika
   */
  enterChargeAmount(amount: string) {
    this.clickAmountLabel();
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[0],
      false,
      true
    );
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1])
      .clear({ force: true })
      .focus();
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[0],
      false,
      true
    );
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CHARGE_AMOUNT[0],
      amount
    );
  }

  /**
   * @details - selecting revenue code in charge entry
   * @param - revenueCode
   * @API - API's are not available
   * @author - chandrika
   */
  selectRevenueCode(revenueCode: string) {
    // Added remove mask wrapper to select and click on the dropdown
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REVENUE_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REVENUE_CODE[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(revenueCode),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REVENUE_CODE[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    // Added remove mask wrapper because it will help to once this action complete it will click on the other fields
  }

  /**
   * @details To enter debit amount for charges
   * @param - amount
   * @API - API's are not available
   * @author - chandrika
   */
  enterDebitAmount(amount: string) {
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DEBIT_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DEBIT_AMOUNT[0],
      amount
    );
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DEBIT_HEADER[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DEBIT_HEADER[0]
    );
  }

  /**
   * @details To enter debit amount for charges
   * @param - amount
   * @API - API's are not available
   * @author - chandrika
   */
  verifyDebitAmount(amount: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DEBIT_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DEBIT_AMOUNT[0],
      amount
    );
  }

  /**
   * @details - Click balance header of an expanded procedure code
   * @API - API's are not available
   * @author - chandrika
   */
  clickAmountLabel() {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.AMOUNT_LABEL[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.AMOUNT_LABEL[0]
    );
  }

  /**
   * @details To enter HCPCS of the supply
   * @param - cptData
   * @API - API's are not available
   * @author - chandrika
   */
  enterHcpcs(cptData: Cpt) {
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.HCPCS[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.HCPCS[0],
      cptData.HCPCS
    );
  }

  /**
   * @details Add Diagnosis Code for an expanded procedure
   * @param diagnosisCode - pass diagnosis code from cases to code model
   * @Api - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  addAdditionalDiagnosisCode(diagnosisCode: string) {
    const interceptCollection =
      this.chargeEntryApis.interceptSearchDiagnosisCodeApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_DIAGNOSIS_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_DIAGNOSIS_CODE[0],
      diagnosisCode
    );
    cy.cWaitApis(interceptCollection);
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.DIAGNOSIS_CODE_LIST[1])
      .parent()
      .click();
  }

  /**
   * @details Delete Diagnosis Code for an expanded procedure
   * @param diagnosisCode - pass diagnosis code from cases to code model
   * @Api - API's are not available
   */
  deleteDiagnosisCode(diagnosisCode: string) {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.DIAGNOSIS_CODE_LIST[1]).each(
      ($code) => {
        if ($code.text().indexOf(diagnosisCode) > -1) {
          cy.wrap($code).within(() => {
            cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.DIAGNOSIS_TRASH_ICON[1])
              .invoke(
                InvokeMethods.css,
                InvokeAttributes.visibility,
                CommonClassAttributes.visible
              )
              .invoke(InvokeMethods.show)
              .should(ShouldMethods.visible)
              .click();
          });
          return false;
        }
      }
    );
  }

  /**
   * @details Update Referring Physician for an expanded procedure
   * @param physician - pass referring physician from cases to code model
   *  @Api - API's are not available
   */
  updateReferringPhysician(physician: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REFERRING_PHYSICIAN[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.REFERRING_PHYSICIAN[0]
    );
    cy.cGet(CoreCssClasses.DropDown.loc_p_dropdown_items).within(() => {
      cy.cClick(
        selectorFactory.getSpanText(physician),
        OR_CHARGE_ENTRY.CHARGE_ENTRY.REFERRING_PHYSICIAN[0]
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details Update Self Pay for an expanded procedure
   * @param selfPay - from billing details model
   * @Api - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  updateSelfPay(selfPay: string) {
    const interceptCollection =
      this.chargeEntryApis.interceptSelectProcedureSelfPayApi();
    cy.cIntercept(interceptCollection);
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.SELF_PAY[1]).within(() => {
      cy.cClick(selectorFactory.getSpanText(selfPay), selfPay);
    });
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Click Add procedure in Charge Entry page
   * @Api - API's are not available
   */
  clickAddProcedure() {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_PROCEDURE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_PROCEDURE[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details Verify Field Values for an expanded procedure
   * @param cptData - where user will pass Cpt model to verify Physician
   * @param casesInfo - where user will pass CasesToCodeDetails model to verify DiagnosisCode and Referring Physician
   * @param chargesInfo - where user will pass Charges model to verify Period and Batch
   */
  verifyFieldValues(
    cptData: Cpt,
    casesInfo?: CasesToCodeDetails,
    chargesInfo?: Charges
  ) {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.PROCEDURE_GRID[1]).within(() => {
      // Physician
      cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.PHYSICIAN[1]).should(
        ShouldMethods.contain,
        cptData.Physician
      );
      // Period
      cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1]).should(
        ShouldMethods.contain,
        chargesInfo?.Period
      );
      // Batch
      cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1]).should(
        ShouldMethods.contain,
        chargesInfo?.Batch
      );
    });
    // Diagnosis Codes
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.DIAGNOSIS_CODE_LIST[1]).should(
      ShouldMethods.contain,
      casesInfo?.DiagnosisCode
    );
    // Referring Physician
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.REFERRING_PHYSICIAN[1]).should(
      ShouldMethods.contain,
      casesInfo?.ReferringPhysician
    );
    // Self Pay
    if (this.patientCaseInfo.BillingDetails?.SelfPay) {
      cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.SELF_PAY[1])
        .find(
          selectorFactory.verifyToggleOption(
            this.patientCaseInfo.BillingDetails?.SelfPay ?? ''
          )
        )
        .should(ShouldMethods.visible);
    }
    // Primary Insurance
    if (this.patientCaseInfo.BillingDetails?.PrimaryInsurance) {
      cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.PRIMARY_INSURANCE[1]).should(
        ShouldMethods.contain,
        this.patientCaseInfo.BillingDetails?.PrimaryInsurance
      );
    }
    // Secondary Insurance
    if (this.patientCaseInfo.BillingDetails?.SecondaryInsurance) {
      cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.SECONDARY_INSURANCE[1]).should(
        ShouldMethods.contain,
        this.patientCaseInfo.BillingDetails?.SecondaryInsurance
      );
    }
    // Tertiary Insurance
    if (this.patientCaseInfo.BillingDetails?.TertiaryInsurance) {
      cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.TERTIARY_INSURANCE[1]).should(
        ShouldMethods.contain,
        this.patientCaseInfo.BillingDetails?.TertiaryInsurance
      );
    }
  }

  /**
   * @details To enter the procedure in Charge Entry file
   * @param cptData as reference model in the function.
   * @Api - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  enterProcedure(cptData: Cpt) {
    const interceptAddProcedureApiCollection =
      this.chargeEntryApis.interceptAddProcedureApi();
    cy.cIntercept(interceptAddProcedureApiCollection);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_PROCEDURE_INPUT_FIELD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_PROCEDURE_INPUT_FIELD[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptAddProcedureApiCollection);
    cy.cIsVisible(
      selectorFactory.getBText(cptData.CPTCodeAndDescription),
      cptData.CPTCodeAndDescription
    );
    const interceptSelectProcedureSelfPayApiCollection =
      this.chargeEntryApis.interceptSelectProcedureSelfPayApi();
    cy.cIntercept(interceptSelectProcedureSelfPayApiCollection);
    cy.cSelectListItem(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PROCEDURE_SELECTION[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PROCEDURE_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptSelectProcedureSelfPayApiCollection);
    this.sisOfficeDesktop.waitTillSpinnerLoads();
  }

  /**
   * @details Edit Field Values for an expanded procedure
   * @param newCasesInfo - where user will pass CasesToCodeDetails model to verify DiagnosisCode and Referring Physician
   * @param oldCasesInfo - where user will pass CasesToCodeDetails model to delete existing DiagnosisCode
   * @param chargesInfo - where user will pass Charges model to verify Period and Batch
   * @param billingInfo - where user will pass billingInfo to verify Self Pay
   * @Api - API's are not available
   */
  editFieldValues(
    newCasesInfo: CasesToCodeDetails,
    oldCasesInfo: CasesToCodeDetails,
    chargesInfo: Charges,
    billingInfo?: string
  ) {
    // Physician
    cy.cClick(
      CommonUtils.concatenate(
        OR_CHARGE_ENTRY.CHARGE_ENTRY.PHYSICIAN[1],
        FilterMethods.visible
      ),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PHYSICIAN[0],
      false,
      true
    );
    cy.cGet(CoreCssClasses.DropDown.loc_p_dropdown_items).within(() => {
      cy.cClick(
        selectorFactory.getSpanText(
          this.patientCaseInfo.CaseDetails?.CptCodeInfo[2].Physician ?? ''
        ),
        OR_CHARGE_ENTRY.CHARGE_ENTRY.REFERRING_PHYSICIAN[0]
      );
    });

    // Period
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      CommonUtils.concatenate(
        OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1],
        FilterMethods.visible
      ),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(chargesInfo.Period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
    cy.cRemoveMaskWrapper(Application.office);

    // Batch
    cy.cClick(
      CommonUtils.concatenate(
        OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1],
        FilterMethods.visible
      ),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(chargesInfo.Batch),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0]
    );
    cy.cRemoveMaskWrapper(Application.office);

    // Diagnosis Codes
    this.deleteDiagnosisCode(oldCasesInfo.DiagnosisCode);
    this.addAdditionalDiagnosisCode(newCasesInfo.DiagnosisCode);

    // Referring Physician
    this.updateReferringPhysician(newCasesInfo?.ReferringPhysician ?? '');
    // Self Pay
    if (billingInfo) {
      this.updateSelfPay(billingInfo ?? '');
    }
  }

  /**
   * @details To select the discount in the charges section
   * @param option - To provide the discount value from the dropdown
   * @Api - API's are not available
   */
  selectDiscount(option: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DISCOUNT_DROPDOWN[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.DISCOUNT_DROPDOWN[0]
    );
    cy.cClick(selectorFactory.getSpanText(option), option);
  }

  /**
   * @details To verify the amount value in the charges screen
   * @param value - To provide the value that is to be asserted from amount field
   * @API - API's are not available
   * @author - chandrika
   */
  verifyAmount(value: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.AMOUNT[0],
      value
    );
  }

  // Removed addSupplyChargeEntry Method since it is duplication of method addSupply in this page.

  /**
   * @details - selecting period and batch Labels in charge entry
   * @API - API's are not available
   * @author - chandrika
   */
  clickPeriodAndBatchLabel() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getpText(OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getpText(OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
  }

  /**
   * @details - To verify the mandatory fields of charges when add the new procedure.
   * @API - API's are not available
   * @author - chandrika
   */
  verifyAddProcedureMandatoryFields() {
    const addProcDropdownFields = [
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_PROCEDURE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_PROCEDURE_PHYSICIAN[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_PROCEDURE_PERIOD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_PROCEDURE_BATCH[1],
    ];
    addProcDropdownFields.forEach((addProcFields) => {
      cy.shouldBeEnabled(addProcFields);
    });
  }

  /**
   * @details - Enter the value in Modifier dropdown search bar in the charge entry
   * @param value- chares model values needs to be passed ex:period,batch,modifier etc
   * @Api - API's are not yet identified
   * @author Nikitan
   */
  selectModifier(value: Charges) {
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.CPT_COL_HEADER[1]).scrollIntoView();
    cy.cGet(OR_FACE_SHEET_CHARGE_ENTRY.MODIFIER_DROPDOWN[1])
      .click({ scrollBehavior: false })
      .then(function () {
        cy.cClick(selectorFactory.getSpanText(value.Modifier!), '');
      });
  }

  /**
   * @details - To enter Pi Document value in additional claim information
   * @param value as string is used in function
   * @API - API's are not available
   * @author - chandrika
   */
  enterPiDocument(value: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PI_DOCUMENT[0]
    );
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PI_DOCUMENT[0],
      value
    );
  }

  /**
   * @details - To verify Apply all charges label
   * @API - API's are not available
   * @author - chandrika
   */
  verifyApplyAllChargesLabel() {
    cy.cIsVisible(
      selectorFactory.getSpanText(AdditionalClaimInformation.apply_all_charges),
      AdditionalClaimInformation.apply_all_charges
    );
  }

  /**
   * @details - To verify Apply all charges is set to no
   * @API - API's are not available
   * @author - chandrika
   */
  verifyApplyAllChargesSetNo() {
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.APPLY_ALL_CHARGES_NO[1],
      selectorFactory.getSpanText(YesOrNo.no)
    );
  }

  /**
   * @details - To enter resubmission code in additional claim information
   * @param value - resubmission code value that needs to be entered
   * @API - API's are not available
   * @author - chandrika
   */
  enterResubmissionCode(value: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.RESUBMISSION_FREQUENCY_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.RESUBMISSION_FREQUENCY_CODE[0]
    );
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.RESUBMISSION_FREQUENCY_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.RESUBMISSION_FREQUENCY_CODE[0],
      value
    );
  }

  /**
   * @details - To enter Si Document value in additional claim information
   * @param value - Si document value that needs to be entered
   * @API - API's are not available
   * @author - chandrika
   */
  enterSiDocument(value: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SI_DOCUMENT[0]
    );
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SI_DOCUMENT[0],
      value
    );
  }

  /**
   * @details - To enter Ti Document value in additional claim information
   * @param value - Ti document value that needs to be entered
   * @API - API's are not available
   * @author - chandrika
   */
  enterTiDocument(value: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TI_DOCUMENT[0]
    );
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TI_DOCUMENT[0],
      value
    );
  }

  /**
   * @details - To verify resubmission code in additional claim information
   * @param  value - resubmission code document value that needs to be verified
   * @API - API's are not available
   * @author - chandrika
   */
  verifyResubmissionCode(value: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.RESUBMISSION_FREQUENCY_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.RESUBMISSION_FREQUENCY_CODE[0],
      value
    );
  }

  /**
   * @details - To verify Pi Document in additional claim information
   * @param value - Pi document value that needs to be verified
   * @API - API's are not available
   * @author - chandrika
   */
  verifyPiDocument(value: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PI_DOCUMENT[0],
      value
    );
  }

  /**
   * @details - To verify Pi Document value in additional claim information
   * @param value - Si document value that needs to be verified
   * @API - API's are not available
   * @author - chandrika
   */
  verifySiDocument(value: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SI_DOCUMENT[0],
      value
    );
  }

  /**
   * @details - To verify Pi Document value in additional claim information
   * @param value - Ti document value that needs to be verified
   * @API - API's are not available
   * @author - chandrika
   */
  verifyTiDocument(value: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TI_DOCUMENT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TI_DOCUMENT[0],
      value
    );
  }

  /**
   * @details - To patient condition in additional claim information
   * @param value as string used in function
   * @API - API's are not available
   * @author - chandrika
   */
  verifyPatientCondition(value: string) {
    cy.cIsVisible(selectorFactory.getSpanText(value), value);
  }

  /**
   * @details - To verify Accident state in additional claim information
   * @param value as string used in function
   * @API - API's are not available
   * @author - chandrika
   */
  verifyAccidentDate(value: string) {
    cy.cHasValue(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
        .ADDITIONAL_CLAIM_INFORMATION.ACCIDENT_DATE[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
        .ADDITIONAL_CLAIM_INFORMATION.ACCIDENT_DATE[0],
      value
    );
  }

  /**
   * @details - To verify accident state in additional claim information
   * @param - value as string used in function
   * @API - API's are not available
   * @author - chandrika
   */
  verifyAccidentState(value: string) {
    cy.cIsVisible(selectorFactory.getSpanText(value), value);
  }

  /**
   * @details - To click apply all charges to yes
   * @API - API's are not available
   * @author - chandrika
   */
  clickApplyAllChargesYes() {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.APPLY_ALL_CHARGES_YES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.APPLY_ALL_CHARGES_YES[0]
    );
  }

  /**
   * @details - To verify additional claim information button is enable or disable
   * @param isDisabled as boolean used in function
   * @API - API's are not available
   * @author - chandrika
   */
  verifyAdditionalClaimInfoButton(isDisabled: boolean = true) {
    cy.cIsEnabled(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADDITIONAL_CLAIM_INFO_ENABLE_DISABLE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADDITIONAL_CLAIM_INFO_ENABLE_DISABLE[0],
      false,
      isDisabled
    );
  }

  /**
   * @details - To clear resubmission code in additional claim information
   * @API - API's are not available
   * @author - chandrika
   */
  clearResubmissionCode() {
    cy.cClear(OR_CHARGE_ENTRY.CHARGE_ENTRY.RESUBMISSION_FREQUENCY_CODE[1]);
  }

  /**
   * @details - To clear Si Document value in additional claim information
   * @API - API's are not available
   * @author - chandrika
   */
  clearSiDocument() {
    cy.cClear(OR_CHARGE_ENTRY.CHARGE_ENTRY.SI_DOCUMENT[1]);
  }

  /**
   * @details - To clear Pi Document value in additional claim information
   * @API - API's are not available
   * @author - chandrika
   */
  clearPiDocument() {
    cy.cClear(OR_CHARGE_ENTRY.CHARGE_ENTRY.PI_DOCUMENT[1]);
  }

  /**
   * @details - To clear Ti Document value in additional claim information
   * @API - API's are not available
   * @author - chandrika
   */
  clearTiDocument() {
    cy.cClear(OR_CHARGE_ENTRY.CHARGE_ENTRY.TI_DOCUMENT[1]);
  }

  /**
   * @details - To enter hcpcs value in added supplies in charge entry
   * @param value as string used in function
   * @API - API's are not available
   * @author - chandrika
   */
  enterHcpcsValue(value: string) {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_HCPCS[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_HCPCS[0]
    ).then(() => {
      cy.cType(
        OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_HCPCS[1],
        OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_HCPCS[0],
        value
      );
    });
  }

  /**
   * @details - To mouse hover on procedure row trash icon according to cpt and verify
   * @param cpt To select the cpt row
   * @param index - To find the delete icon index starts with 0 for first procedure
   * @API - API's are not available
   */
  verifyDeleteIconOnMouseOver(cpt: string, index: number) {
    cy.cGet(
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_panel,
        ' ',
        selectorFactory.getSpanText(cpt)
      )
    ).each(($element) => {
      if ($element.text().indexOf(cpt) > -1) {
        cy.wrap($element).within(() => {
          cy.cGet(selectorFactory.getProcedureTrashIcon(index))
            .invoke(InvokeMethods.show)
            .should(ShouldMethods.visible);
        });
        return false;
      }
    });
  }

  /**
   * @details Click on add supplies in charge entry
   * @API - API's are not available
   */
  clickAddSupplies() {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES[0]
    );
  }

  /**
   * @details Verifying the write-off fields of supplies
   * @param values to be passed as string array to verify all the values present
   * @API - API's are not available
   */
  verifySupplyWriteOffFields(values: string[]) {
    values.forEach((el) => {
      cy.cGet(selectorFactory.getSuppliesWriteOffs(el))
        .scrollIntoView()
        .should(ShouldMethods.visible);
    });
  }

  /**
   * @details Verifying the debits fields of supplies
   * @API - API's are not available
   */
  verifySupplyDebitsFields() {
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_DEBIT_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_DEBIT_AMOUNT[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_DEBIT_TRANSACTION_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_DEBIT_TRANSACTION_CODE[0]
    );
  }

  /**
   * @details Verifying the revenue code fields of supplies
   * @API - API's are not available
   */
  verifySupplyRevenueFields() {
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_REVENUE_DISCOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_REVENUE_DISCOUNT[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_REVENUE_REVENUE_CODE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_REVENUE_REVENUE_CODE[0]
    );
  }

  /**
   * @details Verifying the charge details fields of supplies
   * @API - API's are not available
   */
  verifySupplyChargeDetailsFields() {
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_BALANCE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_BALANCE[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_AMOUNT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_AMOUNT[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_TYPE_OF_BILL[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_TYPE_OF_BILL[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_UNITS[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CHARGE_DETAILS_UNITS[0]
    );
  }

  /**
   * @details Verifying the modifier fields of supplies
   * @param values to be passed as string array for the verification
   * @API - API's are not available
   */
  verifySupplyModifiersFields(values: string[]) {
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getPStrongText(el), el);
    });
  }

  /**
   * @details Verifying the insurances of supplies
   * @API - API's are not available
   */
  verifySupplyInsurancesFields() {
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_PRIMARY_INSURANCE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_PRIMARY_INSURANCE[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_SECONDARY_INSURANCE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_SECONDARY_INSURANCE[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_TERTIARY_INSURANCE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_TERTIARY_INSURANCE[0]
    );
  }

  /**
   * @details Verifying the header fields of supplies
   * @param values to be passed as string array for verification
   * @API - API's are not available
   */
  verifySupplyHeadersFields(values: string[]) {
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getSuppliesHeaderFields(el), el);
    });
  }

  /**
   * @details Verifying the toggles of supplies and additional claim
   * @API - API's are not available
   */
  verifySupplyTogglesAndAdditionalClaimFields() {
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_SELF_PAY[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_SELF_PAY[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CLAIM_INFO[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_CLAIM_INFO[0]
    );
    cy.cIsVisible(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_COMPENSATION[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_SUPPLIES_COMPENSATION[0]
    );
  }

  /**
   * @details Verifying the default value in units of measure dropdown
   * @param value to be passed as parameter for verification
   * @API - API's are not available
   */
  verifyDefaultUnitsOfMeasure(value: string) {
    cy.cIncludeText(selectorFactory.getSpanClassText(value), value, value);
  }

  /**
   * @details Verifying the values in units of measure dropdown
   * @param values to be passed in form of array in order to verify the options
   * @API - API's are not available
   * @Author Arushi
   */
  verifyUnitsOfMeasure(values: string[]) {
    cy.cRemoveMaskWrapper(Application.office);
    this.verifyDefaultUnitsOfMeasure(unitsOfMeasure[0]);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CLEAR_UNITS_OF_MEASURE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.CLEAR_UNITS_OF_MEASURE[0]
    );
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS_OF_MEASURE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS_OF_MEASURE[0]
    );
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getSpanText(el), el);
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cSelectListItem(
      selectorFactory.getSpanText(unitsOfMeasure[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS_OF_MEASURE[0],
      unitsOfMeasure[0]
    );
  }

  /**
   * @details Verifying the free text of Hcpcs field
   * @API - API's are not available
   */
  verifyHcpcsFreeText() {
    cy.cHasAttribute(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[0],
      CommonClassAttributes.placeholder,
      FreeText.hcpcs_field_text
    );
  }

  /**
   * @details Entering data in ios supply field and verifying the displayed options
   * @param cptData to be passed as model for reference
   * @API are available - Implemented Completely
   */
  verifyDataInIosField(cptData: Cpt) {
    cy.cRemoveMaskWrapper(Application.office);
    const interceptCollection =
      this.chargeEntryApis.interceptSearchAndSelectSupplyApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(
      selectorFactory.getBText(cptData.CPTCodeAndDescription),
      cptData.CPTCodeAndDescription
    );
  }

  /**
   * @details Clear the ios supply field
   * @API - API's are not available
   */
  clearIosSupplyField() {
    cy.cClear(OR_CHARGE_ENTRY.CHARGE_ENTRY.SEARCH_SUPPLIES[1]);
  }

  /**
   * @details Select displayed value from iOS search field
   * @param cptData to be passed as model for reference
   * @API is Available - Implemented Completely
   */
  selectIosSupply(cptData: Cpt) {
    const interceptCollection =
      this.chargeEntryApis.interceptSelectProcedureSelfPayApi();
    cy.cIntercept(interceptCollection);
    cy.cSelectListItem(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SUPPLIES_SELECTION[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.SUPPLIES_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details update units of measure
   * @param value - Unit of measure item
   * @param index - Index starts with 0
   * @API - API's are not available
   * @Author - Nikitan
   */
  updateUnitsOfMeasure(value: string, index: number) {
    cy.cClick(
      CommonUtils.concatenate(
        selectorFactory.getUnitOfMeasureChargeEntry(index),
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
      value
    );
    cy.cClick(selectorFactory.getUnitOfMeasureChargeEntry(index), value);
    cy.cClick(selectorFactory.getSpanText(value), value);
  }

  /**
   * @details To add the procedure in Charge Entry file
   * @param cptData as reference model in the function.
   * @API are available - Implemented Completely
   */
  addSupplyChargeEntry(cptData: Cpt) {
    this.clickAddSupplies();
    cy.cRemoveMaskWrapper(Application.office);
    this.verifyDataInIosField(cptData);
    this.selectIosSupply(cptData);
  }

  /**
   * @details To click on 'x' icon in supply field
   * @param index - index starts with 0 for procedure list supply cross icon in charge entry
   * @API - API's are not available
   */
  removeIosFieldData(index: number) {
    cy.cGet(selectorFactory.getRemoveSuppliesChargeEntry(index))
      .scrollIntoView()
      .click({ force: true });
  }

  /**
   * @details To update the supply in Charge Entry file
   * @param cptData as reference model in the function.
   * @API are Available - Implemented Completely
   */
  updateIosSupplyField(cptData: Cpt) {
    this.verifyDataInIosField(cptData);
    this.selectIosSupply(cptData);
  }

  /**
   * @details- To remove patient from charge entry procedure/supply
   * @param index as the procedure/supply index from which procedure to be deleted
   * @API - API's are not available
   */
  removePhysician(index: number) {
    cy.cClick(selectorFactory.getPhysicianCrossIconInChargeEntry(index), 'x');
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To update NDC field in medication
   * @param charge Charges model value needs to be passed
   * @param index index value of the charge needs to be passed
   * @API - API's are not available
   */
  editNDCField(charge: Charges, index: number) {
    cy.cGet(selectorFactory.updateNdcField(index))
      .clear()
      .type(charge.NDC!, { force: true });
  }

  /**
   * @details - Select Physician dropdown in charge entry tracker
   * @param physician is passed as parameter
   * @Uses - Using List box [role="listbox"] li from create case or
   * @API - API's are not available
   */
  selectPhysicianDropdown(physician: string, index: number) {
    const PHYSICIAN_DROPDOWN = selectorFactory.selectPhysicianDropDown(index);
    const PHYSICIAN =
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.PHYSICIAN_DROPDOWN[0];
    cy.cIsVisible(PHYSICIAN_DROPDOWN, PHYSICIAN);
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(PHYSICIAN_DROPDOWN).dblclick();
    cy.cGet(PHYSICIAN_DROPDOWN)
      .invoke(InvokeMethods.show)
      .scrollIntoView()
      .should(ShouldMethods.visible)
      .click()
      .then(() => {
        cy.cGet(selectorFactory.getPhysicianListValue(physician))
          .invoke(InvokeMethods.show)
          .should(ShouldMethods.visible)
          .click();
      });
  }

  /**
   * @details - updating unit value in charge entry
   * @param  value value of the units that needs to be entered
   * @param index to provide index value of units text box
   * @APIs are not yet identified
   * @Author Nikitan
   */
  updateUnit(value: Charges, index: number) {
    cy.cGet(selectorFactory.unitTextBox(index)).type(value.Units!);
  }

  /**
   * @details - To mouse hover on procedure row trash icon according to cpt and delete
   * @param cpt To select the cpt row
   * @param index - To find the delete icon index starts with 0 for first procedure
   * @API - API's are not available
   */
  deleteProcedure(cpt: string, index: number) {
    cy.cGet(
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_panel,
        ' ',
        selectorFactory.getSpanText(cpt)
      )
    ).each(($element) => {
      if ($element.text().indexOf(cpt) > -1) {
        cy.wrap($element).within(() => {
          cy.cGet(selectorFactory.getProcedureTrashIcon(index))
            .invoke(InvokeMethods.show)
            .should(($element) => {
              expect(Cypress.dom.isDetached($element)).to.equal(false);
            })
            .click();
        });
      }
    });
  }

  /**
   * @details to expand or collapse the added procedures/supplies in charge entry
   * @param index to be passed in order to expand or collapse the particular procedure/supply
   */
  expandOrCollapseProcedure(index: number) {
    cy.cGet(selectorFactory.getExpandOrCollapseProcedure(index))
      .scrollIntoView()
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible)
      .click();
  }

  /**
   * @details To verify the delete procedure/ supply warning
   * @API - API's are not available
   */
  deleteProcedureMessage() {
    cy.cClick(
      selectorFactory.getSpanClassText(AppErrorMessages.delete_charge_warning),
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.DELETE[0]
    );
  }

  /**
   * @details - To select yes or no button on delete popup in charge entry
   * @param flag value is passed as parameter in form of true/false
   * @API - API's are available - Implemented Completely
   */
  selectYesOrNoOnDeletePopUp(flag: boolean = false) {
    const interceptCollection =
      this.chargeEntryApis.interceptClickYesInDeleteChargePopupApi();
    if (flag) {
      cy.cIntercept(interceptCollection);
      cy.cClick(
        CommonUtils.concatenate(
          CoreCssClasses.Button.loc_button,
          selectorFactory.getSpanText(YesOrNo.yes)
        ),
        ''
      );
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cGet(
        CommonUtils.concatenate(
          CoreCssClasses.Button.loc_button,
          selectorFactory.getSpanText(YesOrNo.no)
        )
      ).click();
    }
  }

  /**
   * @details Verifying cpt code name in procedure
   * @param cpt - cpt code name to verify
   * @API - API's are not available
   */
  verifyCptCodeName(cpt: string) {
    cy.cIsVisible(selectorFactory.getProcedureInChargeEntry(cpt), cpt);
  }

  /**
   * @detail - To select period and add new batch
   * @param period - To provide the period name
   * @param batch - To provide the batch name
   * @Api - API's are available - Implemented Completely
   * @Author Harsh Ranjan
   */
  selectPeriodAddNewBatch(period: string, batch: string) {
    const interceptCollection = this.chargeEntryApis.interceptAddBAtchApi();
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    cy.cRemoveMaskWrapper(Application.office);
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[1],
        '',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      )
    );
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cClick(selectorFactory.getSpanText(addNewItem), addNewItem);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH_TEXT_INPUT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH_TEXT_INPUT[0],
      batch
    );
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptCollection);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Add Writeoff in Charge Entry
   * @param- writeoff passed as parameter to select period,batch,writeoffTransactionCode,WriteoffAmount and TransactionDate
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  addingWriteoff(writeoff: WriteOffs) {
    transactions.transactionWriteoffPopupSelectDropdownValue(
      OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.PERIOD[0],
      writeoff.Period ?? ''
    );
    transactions.transactionWriteoffPopupSelectDropdownValue(
      OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.BATCH[0],
      writeoff.Batch ?? ''
    );
    transactions.transactionWriteoffPopupSelectDropdownValue(
      OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.WRITEOFF_TRANS_CODE[0],
      writeoff.WriteoffTransactionCode!
    );
    transactions.transactionDebitEnterDebitAmount(writeoff.WriteoffAmount!);
    transactions.enterDateOfTransaction(writeoff.TransactionDate!);
    sisOfficeDesktop.clickDoneButton();
  }

  /**
   * @details - Select Primary Insurance in Charge Entry
   * @param- primaryInsurance passed as parameter to select primaryInsurance
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  selectPrimaryInsurance(primaryInsurance: string) {
    cy.cSelectDropdown(
      OR_FACE_SHEET_CHARGE_ENTRY.PRIMARY_INSURANCE[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PRIMARY_INSURANCE[0],
      primaryInsurance
    );
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the charge entry tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptChargeEntryTrackerApi();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To collapse the charge once after updating the charges in charge entry tracker.
   * @param - index
   * @API - API's are available - Implemented Completely
   * @author Praveen
   */
  clickOnChargeCollapse(index: number) {
    const interceptCollection =
      this.chargeEntryApis.interceptCollapseChargeApi();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, index);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - Performing drag and drop action for the cpt procedures
   * @param cptCodeAndDescription initial position of charge
   * @param cptCodeAndDescription1 final position to the charge
   * @API - API's are available - Implemented Completely
   * @author Rakesh Donakonda
   */
  dragAndDropCharges(
    cptCodeAndDescription: string,
    cptCodeAndDescription1: string
  ) {
    const interceptCollection =
      this.facesheetChargeEntryApi.interceptDragAndDropApi();
    cy.cIntercept(interceptCollection);
    cy.dragAndDrop(
      selectorFactory.dragAndDropCharges(cptCodeAndDescription),
      selectorFactory.dragAndDropCharges(cptCodeAndDescription1)
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify Units in Charge
   * @param units passed to verify units
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyUnits(units: string) {
    cy.cHasValue(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS[0],
      units
    );
  }

  /**
   * @detail - To click the add procedure button in coding/charge entry
   * @Api - API's are not yet identified
   * @author Nikitan
   */
  clickAddProcedureButton() {
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_PROCEDURE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.ADD_PROCEDURE[0]
    );
  }

  /**
   * @details - To click on generate bill label in charge entry
   * @author - chandrika
   * @api -  API's are not available
   */
  clickOnGenerateBillLabel() {
    cy.cClick(
      OR_CHARGE_ENTRY.GENERATE_BILL_LABEL[1],
      OR_CHARGE_ENTRY.GENERATE_BILL_LABEL[0]
    );
  }

  /**
   * @details - To click on cross icon in additional claim information
   * @API - API's are not available
   * @author - chandrika
   */
  clickOnAddClaimInfoCrossIcon() {
    cy.cClick(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.CLOSE_ICON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.CLOSE_ICON[0]
    );
  }

  /**
   * @details - To update units in the charges section
   * @param value - passed units value for procedure or inventory item
   * @API - API's are not available
   * @author - Sai Swarup
   */
  updateUnits(value: string) {
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS[0],
      value,
      false,
      true
    );
    sisOfficeDesktop.clickPatientSearchIcon();
  }

  /**
   * @details - Click balance header of an expanded procedure code
   * @API - API's are not available
   * @author - Vamshi
   */
  clickWriteOffAmountLabel() {
    cy.cClick(
      selectorFactory.getThText(
        OR_CHARGE_ENTRY.CHARGE_ENTRY.WRITEOFF_AMOUNT[0]
      ),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.WRITEOFF_AMOUNT[0]
    );
  }
  /**
   * @details To get the total cases count in the charge entry tracker page
   * @API - API's are not available
   * @author Prashant Raman
   */
  getTotalCasesCount() {
    cy.cGet(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TOTAL_CASES[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.TOTAL_CASES[0]
    ).invoke(InvokeMethods.text);
  }

  /**
   * @details Click On Auto sort button
   * @api API's are available - Implemented Completely
   * @author - Prashant raman
   */
  clickOnAutoSort() {
    faceSheetChargeEntry.clickOnAutoSort();
  }

  /**
   * @details To verify Total amount for the case
   * @param - totalAmount passed  to verify the Total amount of the case
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyTotalAmount(totalAmount: string) {
    cy.cGet(selectorFactory.getSpanText(totalAmount), totalAmount).should(
      ShouldMethods.contain_text,
      totalAmount
    );
  }

  /**
   * @details To verify Total Balance Due for the case
   * @param - totalBalanceDue passed to verify the Total Balance Due of the case
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyTotalBalanceDue(totalBalanceDue: string) {
    cy.cGet(
      selectorFactory.getSpanText(totalBalanceDue),
      totalBalanceDue
    ).should(ShouldMethods.contain_text, totalBalanceDue);
  }

  /**
   * @details - Click On Notes Button in charge entry
   * @API - API calls are available - Implemented COmpletely
   * @author - Prashant Raman
   */
  clickNotesButton() {
    const interceptCollection =
      this.chargeEntryApis.interceptChargeEntryNotesApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_CASE_PAGE.NOTES_BUTTON[1],
      OR_FACESHEET_CASE_PAGE.NOTES_BUTTON[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click Done Button in Notes Popup Opened
   * @param - notes - content to be written in notes
   * @API - API calls are available - Implemented Completely
   * @author - Prashant Raman
   */
  addNotes(notes: string) {
    const interceptCollection =
      this.chargeEntryApis.interceptChargeEntrySaveNotesApi();
    cy.cClick(
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[1],
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[0],
      false,
      true
    );
    cy.cType(
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[1],
      OR_FACESHEET_CASE_PAGE.NOTES.NOTES_TEXT[0],
      notes,
      false,
      true
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.NOTES_DONE[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.NOTES_DONE[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cNotExist(
      OR_FACESHEET_CASE_PAGE.NOTES.DIALOG_BOX[1],
      OR_FACESHEET_CASE_PAGE.NOTES.DIALOG_BOX[0]
    );
  }

  /**
   * @detail - To enter all the details in adjustment tab
   * @param amount - amount provided as parameter for the writeoff value to be entered
   * @param index - To select the writeoff field in the amount parameter will be provided
   * @Api - API's are not available
   * @author - Prashant Raman
   */
  enterWriteOff(amount: string, index: number) {
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.PLUS_ICON[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PLUS_ICON[0]
    );
    cy.cType(
      selectorFactory.getWriteOffAmountInputInChargeEntry(index),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.WRITE_OFFS
        .WRITE_OFF_AMOUNT[0],
      amount
    );
  }

  /**
   * @detail -Select Transaction code on adding a writeoff
   * @param dropdownValue -To select Write-Off transaction code dropdown.
   * @param index - Index define the write-Off row starting from 0.
   * @Api - API's are not available
   * @author - Prashant Raman
   */
  selectWriteOffTransactionCode(dropdownValue: string, index: number) {
    cy.cClick(
      selectorFactory.getWriteOffTransactionCodeDropdown(index),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.WRITE_OFFS
        .WRITE_OFF_TRANSACTION_CODE[0]
    );
    cy.cClick(selectorFactory.getDropdownValues(dropdownValue), '');
  }

  /**
   * @detail -Select Writeoff Group code on adding a writeoff
   * @param dropdownValue -To select Write-Off Group code dropdown.
   * @param index - Index define the write-Off row starting from 0.
   * @Api - API's are not available
   * @author - Prashant Raman
   */
  selectWriteOffGroupCode(dropdownValue: string, index: number) {
    cy.cClick(
      selectorFactory.getWriteOffGroupCodeDropdown(index),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.WRITE_OFFS
        .WRITE_OFF_GROUP_CODE[0]
    );
    cy.cClick(selectorFactory.getDropdownValues(dropdownValue), '');
  }

  /**
   * @detail -Select writeoff reason code on adding a writeoff
   * @param dropdownValue -To select Write-Off reason code dropdown.
   * @param index - Index define the write-Off row starting from 0.
   * @Api - API's are not available
   * @author - Prashant Raman
   */
  selectWriteOffReasonCode(dropdownValue: string, index: number) {
    cy.cClick(
      selectorFactory.getWriteOffReasonCodeDropdown(index),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.WRITE_OFFS
        .WRITE_OFF_REASON_CODE[0]
    );
    cy.cClick(selectorFactory.getDropdownValues(dropdownValue), '');
  }

  /**
   * @detail - To click on x icon in procedure field in a charge in charge entry page
   * @API are  Available - Implemented Completely
   * @author - Prashant Raman
   */
  clickOnXIconInSearchProcedure() {
    const interceptCollection =
      this.chargeEntryApis.interceptPrimaryInsuranceCrossIconApi();
    cy.cClick(
      selectorFactory.removeProcedureXIcon[1],
      selectorFactory.removeProcedureXIcon[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - enter the units in the units textfield
   * @param units - units define the value for the units Textfield
   * @param index - Index define the write-Off and debit row starting from 0.
   * @Api - API's are not available
   * @author - Prashant Raman
   */
  enterUnits(units: string, index: number) {
    cy.cType(
      selectorFactory.units(index),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS[0],
      units
    );
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS_HEADER[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.UNITS_HEADER[0]
    );
  }

  /**
   * @detail - To click the self pay option is toggled as - Yes/No
   * @param value - To provide value as Yes or No
   * @api - Api's are Available - Implemented Completely.
   * @author - Prashant Raman
   */
  clickSelfPay(value: YesOrNo) {
    combinedCoding.clickSelfPay(value);
  }

  /**
   * @detail - Combined and merged the  functions for documenting the multiple writeoffs and verifying balance and total balance due
   * @param adjustment is passed as the model reference inside the function
   * @param charges2 is passed as the model reference inside the function
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  enterWriteOffAndVerifyBalanceAndTotalBalanceDue(
    adjustment: Adjustment,
    charges2: Charges
  ) {
    let valueIndex = 1;
    let index;
    let rowIndex = 0;
    cy.cClick(
      OR_FACE_SHEET_CHARGE_ENTRY.PLUS_ICON[1],
      OR_FACE_SHEET_CHARGE_ENTRY.PLUS_ICON[0]
    );
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.WRITE_OFF_ROW[1])
      .then(($list) => {
        for (let i = 0; i < $list.length; i++) {
          rowIndex = $list.length - 1;
        }
      })
      .then(() => {
        for (
          valueIndex = 0, index = rowIndex;
          valueIndex < adjustment.WriteoffAmount!.length;
          valueIndex++, index++
        ) {
          this.documentWriteoffDetails(
            adjustment.WriteoffAmount![valueIndex],
            adjustment.WriteoffTransactionCode![valueIndex],
            adjustment.WriteoffGroupCode![valueIndex],
            adjustment.WriteoffReasonCode![valueIndex],
            index
          );
          this.verifyBalanceAndTotalBalanceDue(
            charges2.Balance![index],
            charges2.TotalBalanceDue![index]
          );
        }
      });
  }

  /**
   * @detail - Combined and merged the unit functions for documenting the writeoff
   * @param writeOffAmount - amount provided as parameter for the writeoff value to be entered
   * @param transactionCodeDropdownValue -To select Write-Off transaction code dropdown.
   * @param groupCodeDropdownValue -To select Write-Off Group code value from dropdown.
   * @param reasonCodeDropdownValue -To select Write-Off reason code value from dropdown.
   * @param index - Index define the write-Off row starting from 0
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  documentWriteoffDetails(
    writeOffAmount: string,
    transactionCodeDropdownValue: string,
    groupCodeDropdownValue: string,
    reasonCodeDropdownValue: string,
    index: number
  ) {
    this.enterWriteOff(writeOffAmount, index);
    this.selectWriteOffTransactionCode(transactionCodeDropdownValue, index);
    this.selectWriteOffGroupCode(groupCodeDropdownValue, index);
    this.selectWriteOffReasonCode(reasonCodeDropdownValue, index);
  }

  /**
   * @detail - Combined and merged for selecting multiple discounts and verifying balance and total balance due
   * @param detailsInfo is passed as the model reference inside the function
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  addDiscountAndVerifyBalanceAndTotalBalanceDue(detailsInfo: Charges[]) {
    for (const details of detailsInfo) {
      this.selectDiscount(details.Discounts!);
      this.verifyBalanceAndTotalBalanceDue(
        details.Balance!,
        details.TotalBalanceDue!
      );
    }
  }

  /**
   * @detail - Combined and merged the unit functions for verifying balance and total balance due
   * @param balanceAmount - To Verify the balance amount of an expanded procedure
   * @param totalBalanceDue - To verify the Total Balance Due of the Case.
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  verifyBalanceAndTotalBalanceDue(
    balanceAmount: string,
    totalBalanceDue: string
  ) {
    this.verifyBalance(balanceAmount);
    this.verifyTotalBalanceDue(totalBalanceDue);
  }

  /**
   * @detail - Clicking on the Headers to perform sorting.
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  clickOnHeadersToSort() {
    this.sisOfficeDesktop.clickHeadersToSort(headersName);
    //In parallel Execution , we are unable to find the patient as their are many patients. So added sorting for DOS in ascending to make the patient visible
    this.sisOfficeDesktop.sortInDescendingOrderByDOS();
  }

  /**
   * @detail - Verification of Sorted Procedures
   * @param - dataValues provide as an array to verify the order of cpt
   * @api - Api's are not Available .
   * @author - Prashant Raman
   */
  verifyTheOrderOfProcedure(dataValues: string[]) {
    faceSheetChargeEntry.autoSort(dataValues);
  }

  /**
   * @details To enter the data in the fields in UB tab in Additional Claim Information popup
   * @param ubAdditionalClaimInfo model as arguments passed inside of the function
   * @API - API's are not available
   * @author - Prashant Raman
   */
  enterDataInUbFields(ubAdditionalClaimInfo: UBAdditionalClaim) {
    combinedCoding.enterDataInUbFields(ubAdditionalClaimInfo);
  }

  /**
   * @details - To check the additional claim data which is entered in the fields in additional claim popup
   * @param ubAdditionalClaimInfo model as argument passed inside of the function.
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyUbAdditionalClaimData(ubAdditionalClaimInfo: UBAdditionalClaim) {
    combinedCoding.verifyUbAdditionalClaimData(ubAdditionalClaimInfo);
  }

  /**
   * @details - Combined and Grouped functions to click/verify on additional claim button and verify additional claim information headers/labels
   * @param headerValues as string array passed in the function
   * @param labelValues as string array passed in the function.
   * @APIs are Available - Implemented Completely
   * @author - Prashant Raman
   */
  verifyAndClickAdditionalClaimInformationBtnAndVerifyUbAdditionalClaimHeadersAndLabels(
    headerValues: string[],
    labelValues: string[]
  ) {
    combinedCoding.verifyAdditionalClaimInformation(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[0]
    );
    combinedCoding.clickAdditionalClaimInformation(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[0]
    );
    combinedCoding.verifyUbAdditionalClaimHeaders(headerValues);
    combinedCoding.verifyUbAdditionalClaimLabels(labelValues);
  }

  /**
   * @details - Combined and Grouped functions to verify the amount, balance , total amount and total balance due
   * @param chargeInfo - passed as a reference model in the function
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyAmountTotalAmountBalanceAndTotalBalanceDue(chargeInfo: Charges) {
    this.verifyChargeAmount(chargeInfo.Amount!);
    this.verifyTotalAmount(chargeInfo.TotalAmount!);
    this.verifyBalanceAndTotalBalanceDue(
      chargeInfo.Balance!,
      chargeInfo.TotalBalanceDue!
    );
  }

  /**
   * @details - Combined and Grouped functions to click on the Done button in Additional Claim Information popup and verify the popup
   * @APIs are Available - Implemented Completely
   * @author - Prashant Raman
   */
  selectAdditionalClaimInfoDoneAndVerifyPopup() {
    combinedCoding.selectAdditionalClaimInfoDone();
    combinedCoding.verifyAdditionClaimInformationPopup(
      OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.ADDITIONAL_CLAIM_INFORMATION[0]
    );
  }

  /**
   * @details Verifying the Primary insurance
   * @param insuranceName - string value for insurance name to be passed for verification
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyPrimaryInsurance(insuranceName: string) {
    cy.cIsVisible(selectorFactory.getSpanText(insuranceName), insuranceName);
  }

  /**
   * @details - verify patient is not present under combined coding tracker
   * @param patientFullName -patientFullName to be verified
   * @API - API's are not available
   * @author - Prashant Raman
   */
  verifyPatientFallOff(patientFullName: string) {
    combinedCoding.verifyPatientFallOffInCombinedCoding(patientFullName);
  }
}
