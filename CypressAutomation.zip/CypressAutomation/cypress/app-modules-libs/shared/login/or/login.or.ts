import { CommonGetLocators } from "../../../../support/common-core-libs/application/common-core";
import { CoreCssClasses } from "../../../../support/common-core-libs/core-css-classes";
import { CommonUtils } from "../../../../support/common-core-libs/framework/common-utils";

export const OR_LOGIN = {
  LOGIN: {
    LOGIN_WEB_TITLE: ['SIS Exchange'],
    USER_NAME: ['User Name', '[placeholder="username"]'],
    PASSWORD: ['Password', '[placeholder="password"]'],
    LOGIN_BUTTON: ['Login', 'button[type="submit"]'],
    ERROR_MESSAGE: [
      'Error',
      CommonUtils.concatenate(
        '[class*="login-form"] ',
        CommonGetLocators.div,
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
  },
};
