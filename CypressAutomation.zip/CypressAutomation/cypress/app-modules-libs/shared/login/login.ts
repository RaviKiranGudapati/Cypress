import CommonCore, {
  Application,
  ShouldMethods,
} from '../../../support/common-core-libs/application/common-core';
import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { UserLogin } from '../../../test-data-models/core/user-info.model';

import { OR_LOGIN } from './or/login.or';

export default class Login extends CommonCore {
  constructor(private applicationNames: Application) {
    super();
  }
  getPatientModel() {
    this.applicationNames;
  }

  /**
   * @details - login to application using user credentials and business entity provided
   * @param username - passed to document username
   * @param password - passed to document password
   * @param loginLocation - passed to click on login location
   * @APIs are available - Not Implemented
   */
  login(username: string, password: string, loginLocation?: string) {
    this.pageTitle.should(ShouldMethods.include, this.applicationNames);
    cy.cType(OR_LOGIN.LOGIN.USER_NAME[1], '', username);
    cy.cType(OR_LOGIN.LOGIN.PASSWORD[1], '', password);
    cy.cClick(OR_LOGIN.LOGIN.LOGIN_BUTTON[1], '');

    const loginLocation_loc =
      this.applicationNames === Application.sis_complete
        ? selectorFactory.getLiText(loginLocation ?? '')
        : selectorFactory.getSpanText(loginLocation ?? '');

    if (loginLocation) {
      cy.cClick(loginLocation_loc, '');
    }
  }

  /**
   * @details - To verify login error message by typing incorrect username and password
   * @param  UserLogin model passed to document user name and password
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifyInvalidLogin(userLog: UserLogin[]) {
    userLog.forEach((element) => {
      this.login(element.UserName, element.Password);
      this.verifyLoginErrorMessage();
    });
  }

  /**
   * @details - To verify login error message by typing incorrect username and password
   * @param flag pass value as true to verify error message is displayed, pass value as false to verify error message is not displaye
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifyLoginErrorMessage(flag: boolean = true) {
    if (flag) {
      cy.cIncludeText(
        OR_LOGIN.LOGIN.ERROR_MESSAGE[1],
        OR_LOGIN.LOGIN.ERROR_MESSAGE[0],
        AppErrorMessages.incorrect_user_name_or_password
      );
    } else {
      cy.cNotExist(
        OR_LOGIN.LOGIN.ERROR_MESSAGE[1],
        OR_LOGIN.LOGIN.ERROR_MESSAGE[0]
      );
    }
  }
}
