/* enum values */
export enum HelpText {
  business_without_list = 'Please create a new item.',
  business_with_list = 'Please select an existing item or create a new item.',
  business_without_add = 'Please select an existing item.',
  on_hover_add_when_disabled = 'This is an Enterprise Configuration.Adding to this configuration from within this facility is disabled.Please edit the list under Enterprise > Enterprise Build.',
  include_insurance = 'Include Charges and Unassigned Payments due from Insurance',
}

export enum ShowPatients {
  show_patients = 'Show patients',
}

export enum DictionaryItems {
  rcm_status = 'RCM Status',
}

export enum FreeText {
  free_text_item = 'Free Text Item',
}

export enum ImplantHeaders {
  implant = 'Implant',
  manufacturer = 'Manufacturer',
  used = 'Used',
  size = 'Size',
  lot = 'Lot',
  serial = 'Serial',
  expiration = 'Expiration',
  reference = 'Reference',
}

export enum IosTextItem {
  ios_text_item = 'Ios Text Item',
}

export enum SupplyHeaders {
  supply = 'SupplyName',
  pre_op_open = 'PreOpOpen',
  pre_op_hold = 'PreOpHold',
  or_open = 'OrOpen',
  or_hold = 'OrHold',
  recovery_open = 'RecoveryOpen',
  recovery_hold = 'RecoveryHold',
  notes = 'Notes',
  used = 'Used',
  wasted = 'Wasted',
  defective = 'Defective',
  pulled = 'Pulled',
}

export enum Formulary {
  administration_amount = 'AdministrationAmount',
  usage_unit_of_measure = 'UsageUnitOfMeasure',
  compound_medication = 'CompoundMedication',
  ios_inventory_medication = 'IosInventoryMedication',
}
