import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export default class EnterpriseConfigurationApi {
  /**
   * @details - After selecting facility in facility Management
   */
  selectFacilityInFacilityManagementApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facility_details,
        'GetFacilityDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facility_addresses,
        'GetFacilityAddresses',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facility_internal_data,
        'GetFacilityInternalData',
        200
      ),
    ];
  }

  /**
   * @details - API Collection after selecting the toggles in the Internal Tab
   */
  togglesInInternalTabApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_set_organization_feature,
        'SetOrganizationFeature',
        200
      ),
    ];
  }

  /**
   * @details - API Collection after selecting enterprise in pop-up
   */
  selectEnterpriseApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_business_entity_get_image,
        'BusinessEntityImage',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts Enterprise configuration Search API and click on the configuration after Searching the configuration name in search field.
    @author - Harsh Ranjan (Todo Unable to find common api for enterprise configuration)
  */
  interceptSelectConfigurationApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_business_entities,
        'BusinessEntities',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.block_schedule_get,
        'BlockSchedule',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Facility Management Feature Enable Disable Api and click on enable disable toggle button in facility management configuration under feature tab..
    @author - Harsh Ranjan 
  */
  interceptFacilityManagementFeatureEnableDisableApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_set_organization_feature,
        'SetOrganizationFeature',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Fee Schedule Add buttonApi and click on Add button in enterprise build fee schedule.
    @author - Harsh Ranjan 
  */
  interceptFeeScheduleAddButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_revenue_code_list,
        'RevenueCodeList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_procedures,
        'AllProcedure',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Type in add procedure pop-up Api and click on Add button in enterprise build fee schedule then type in add procedure pop-up.
    @author - Harsh Ranjan 
  */
  interceptTypeInAddProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_procedure_search,
        'ProcedureSearch',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Done button Api and click on Done button in add procedure pop-up in enterprise build fee schedule.
    @author - Harsh Ranjan 
  */
  interceptAddProcedureDoneButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_add_procedure,
        'AddProcedure',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.fee_schedule_count,
        'FeeScheduleCount',
        200
      ),
    ];
  }

  /**
    @details - This method intercept searchfee schedule procedure  Api and click on search and type cpt code in enterprise build fee schedule.
    @author - Harsh Ranjan 
  */
  interceptSearchProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_fee_schedule_page_search,
        'FeeSchedulePageSearch',
        200
      ),
    ];
  }

  /**
    @details - This method intercept status code Api and click on status code dropdown and select the dropdown value for the selected procedure in enterprise build fee schedule.
    @author - Harsh Ranjan 
  */
  interceptUpdateProcedureDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule_update,
        'FeeScheduleUpdate',
        200
      ),
    ];
  }

  /**
    @details - This method intercept update modified procedure description Api and click on modified procedure description clear and update in enterprise build fee schedule.
    @author - Harsh Ranjan  
  */
  interceptUpdateModifiedProcedureDescriptionApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule_update,
        'FeeScheduleUpdate',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.scdl_grid_gemini_get,
        'ScheduleGridData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.block_schedule_get,
        'BlockScheduleData',
        200
      ),
    ];
  }

  /**
    @details - This method intercept enterprise build fee schedule Api and click on Fee schedule in enterprise build.
    @author - Harsh Ranjan  
  */
  interceptSelectEnterpriseBuildFeeScheduleApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_revenue_code_list,
        'GetRevenueCodeList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_procedures,
        'AllProcedure',
        200
      ),

      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.fee_schedule_count,
        'FeeScheduleCount',
        200
      ),
    ];
  }

  /**
    @details - This method intercept enterprise build transaction code Api and click on transaction code in enterprise build.
    @author - Harsh Ranjan 
  */
  interceptSelectEnterpriseBuildTransactionCodeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_transaction_code_list,
        'TransactionCodeList',
        200
      ),
    ];
  }

  /**
    @details - This method intercept enterprise build dictionaries Api and click on dictionaries in enterprise build.
    @author - Harsh Ranjan 
  */
  interceptSelectEnterpriseBuildDictionariesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_dictionaries_list,
        'DictionariesList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_build_dictionary,
        'EnterpriseBuildDictionary',
        200
      ),
    ];
  }

  /**
    @details - This method intercept enterprise build discount Api and click on discount in enterprise build.
    @author - Harsh Ranjan 
  */
  interceptSelectEnterpriseBuildDiscountApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_source_of_revenue_list,
        'SourceOfRevenueList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_list_transaction_type,
        'ListTransactionType',
        200
      ),
    ];
  }

  /**
    @details - This method intercept fee schedule history button Api and click on History button in enterprise build fee schedule.
    @author - Harsh Ranjan  
  */
  interceptFeeScheduleHistoryButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_fee_schedule_history_list,
        'FeeScheduleHistoryList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule_update,
        'FeeScheduleUpdate',
        200
      ),
    ];
  }

  /**
    @details - This method intercept delete procedure Api and click on procedure trash icon in enterprise build fee schedule.
    @author - Harsh Ranjan  
  */
  interceptDeleteProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_paged_list,
        'PagedList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.fee_schedule_count,
        'FeeScheduleCount',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Select Dictionary Api and click on Dictionary in enterprise build Dictionaries.
    @author - Harsh Ranjan  
  */
  interceptSelectDictionaryApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_dictionary,
        'EnterpriseDictionary',
        200
      ),
    ];
  }

  /**
    @details - This method intercept add dictionary item Api and click on add Item button type the name in input field and click on items label in enterprise build Dictionaries.
    @author - Harsh Ranjan  
  */
  interceptAddDictionariesItemsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_add_dictionary_item,
        'AddDictionariesItem',
        200
      ),
    ];
  }

  /**
    @details - This method intercept add Transaction code Api and click on Done button in add transaction code pop-up in enterprise build Transaction code.
    @author - Harsh Ranjan  
  */
  interceptAddTransactionCodeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_save_transaction_code,
        'SaveTransaction',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Delete Transaction code Api and click on Trash icon then click on yes button in delete transaction code pop-up in enterprise build Transaction code.
    @author - Harsh Ranjan  
  */
  interceptDeleteTransactionCodeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.delete,
        SubRoutes.delete_transaction_code,
        'DeleteTransactionCode',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_transaction_code_list,
        'TransactionCodeList',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Enter Discount Details Api and Enter or select the value in enterprise build Discounts.
    @author - Harsh Ranjan  
  */
  interceptUpdateDiscountDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_source_of_revenue,
        'SourceOfRevenue',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Change login location Api and Click on user menu dropdown select change login location option in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptChangeLoginLocationApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_org_map,
        'UserOrgMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_record_lock,
        'RecordLock',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Select facility Change login location Api and select change login location option and select facility in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptSelectFacilityChangeLoginLocationApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_user_session_org,
        'UserOrgMap',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Allow add to configuration Yes Api and click on Yes toggle button for Allow add to configuration items in facility management under configuration tab.
    @author - Harsh Ranjan  
  */
  interceptAllowAddToConfigurationYesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_allow_add_true,
        'AllowAddConfigurationTrue',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Allow add to configuration No Api and click on no toggle button for Allow add to configuration items in facility management under configuration tab.
    @author - Harsh Ranjan
  */
  interceptAllowAddToConfigurationNoApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_allow_add_false,
        'AllowAddConfigurationFalse',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Facility Management Api and click on facility management Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptFacilityManagementApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_business_entities,
        'GetAllBusinessEntities',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Profiles Api and click on Profiles Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptProfilesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_check_point_type,
        'CheckPointType',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_role_management,
        'EnterpriseRoleManagement',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Roles Api and click on Roles Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptRolesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_features,
        'EnterpriseFeatures',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_role_management,
        'EnterpriseRoleManagement',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Users Api and click on Users Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptUsersApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_allow_bypassing_mfa,
        'AllowBypassingMfa',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_multi_factor_authentication,
        'MultiFactorAuthentication',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_sure_script_service_level,
        'SureScriptServiceLevel',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_features,
        'EnterpriseFeatures',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_business_entities,
        'BusinessEntities',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Non user Api and click on non user Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptNonUserApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.security_get_feature,
        'SecurityGetFeature',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_features,
        'EnterpriseFeatures',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_business_entities,
        'BusinessEntities',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Login Acknowledgement Api and click on Login Acknowledgement Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptLoginAcknowledgementsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_login_screen_acknowledgement,
        'LoginScreenAcknowledgement',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Support Contacts Api and click on Support Contacts Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptSupportContactsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_support_contacts,
        'SupportContacts',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Security Api and click on Security Under enterprise configuration items in enterprise desktop.
    @author - Harsh Ranjan  
  */
  interceptSecurityApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_login_settings,
        'LoginSettings',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_password_settings,
        'PasswordSettings',
        200
      ),
    ];
  }

  /**
    @details - This method intercept select add on features
    @author - chandrika
  */
  interceptSelectAddOnFeaturesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_organizations,
        'GetAllOrganizations',
        200
      ),
    ];
  }

  /**
    @details - This method intercept to select cbo management 
    @author - chandrika 
  */
  interceptCboManagementApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_business_entities,
        'GetAllBusinessEntities',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_cbo_entities,
        'GetAllCBOEntities',
        200
      ),
    ];
  }

  /**
   * @details - This method intercept the Api's on clicking on toggles in internal tab
   * @author - Rakesh Donakonda
   */
  interceptTogglesInInternalTabsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_organization_map,
        'GetUserOrganizationMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_feature_states,
        'GetAllFeatureStates',
        200
      ),
    ];
  }

  /**
    @details - This method intercept for cbo management to click show button
    @author - chandrika
  */
  interceptSelectCboManagementShowApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_security_admin,
        'Security',
        200
      ),
    ];
  }

  /**
   * @details - This method intercept the api's when click on Review/Edit tab
   *  @author - Rakesh Donakonda
   */
  interceptSelectTabHeadingInContractsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_review_list,
        'ReviewsList',
        200
      ),
    ];
  }

  /**
   *@details - This method intercept the Api's when clicked on plus icon under Review/Edit
   @author - Rakesh Donakonda
   */
  interceptAddFeeGroupApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_fee_group_save,
        'FeeGroper',
        200
      ),
    ];
  }

  /**
   * @details - This method intercept the Api's when clicked on write off dropdown
   *  @author - Rakesh Donakonda
   */
  interceptWriteOffDropDownApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.posting_options_save,
        'WriteOffDropdownSave',
        200
      ),
    ];
  }

  /**
   * @details - The method Api's intercept the Api's when clicked on the contracts under enterprise build
   * @author - Rakesh Donakonda
   */
  interceptSelectEnterpriseBuildContractsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_enterprise_contract_list,
        'ContractList',
        200
      ),

      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_list_transaction_type,
        'GetDictionary',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Include enterprise no Api and click on no toggle button for include enterprise items in facility management under configuration tab.
    @author - Harsh Ranjan  
  */
  interceptIncludeEnterpriseNoApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_include_enterprise_false,
        'IncludeEnterpriseTrue',
        200
      ),
    ];
  }

  /**
    @details - This method intercept Include enterprise yes Api and click on yes toggle button for include enterprise items in facility management under configuration tab.
    @author - Harsh Ranjan  
  */
  interceptIncludeEnterpriseYesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_include_enterprise_true,
        'IncludeEnterpriseTrue',
        200
      ),
    ];
  }

  /**
   * @details - selecting facility in Add On Features
   * @author - Rakesh Donakonda
   */
  interceptSelectFacilityInAddOnFeaturesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_organization_all_features,
        'GetOrganizationAllFeatures',
        200
      ),
    ];
  }

  /**
   * @details - selecting facility in Add On Features
   * @author - Rakesh Donakonda*
   */
  interceptSelectEnterpriseBuildAddOnFeaturesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_organizations,
        'GetAllOrganization',
        200
      ),
    ];
  }

  /**
   * @details - This method intercept for cbo management to click show button
   * @author - chandrika
   */
  interceptSelectCboManagementHideApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_security_disable,
        'Security',
        200
      ),
    ];
  }

  /**
   * @details - This method intercept to click MFA Button
   * @author - Dharani
   */
  interceptClickMfaButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_configuration_toggle_map,
        'ConfigurationToggleMap',
        200
      ),
    ];
  }

  /**
   * @details - This method intercept to click Create Copy User
   * @author - Dharani
   */
  interceptClickCreateCopyUserApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_users_account_list,
        'AllUsersAccountList',
        200
      ),
    ];
  }

  /**
   * @details - This method intercept to click Ip From and Ip To
   * @author - Dharani
   */
  interceptClickIpFromToApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.put_mfa_bypass_ip_range,
        'MFABypassIPRange',
        200
      ),
    ];
  }

  /**
   *@details - To click on Done button in add contract popup when Create Copy is selected
   *@author - Rakesh Donakonda
   */
  interceptClickDoneOrCancelInAddContractPopUp() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.copy_contract_save,
        'CopyContractSave',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API Collection for user Details tab in User
   * @author - Jayasree
   */
  selectUserDetailsTabApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_carrier,
        'GetInsuranceCarriers',
        200
      ),

      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_person_id,
        'GetUserDetailsByPersonId',
        200
      ),
    ];
  }

  /**
   * @details - API Collection for user Details tab in User
   * @author - Jayasree
   */
  newUserDoneApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(WaitMethods.post, SubRoutes.new_user, 'AddNewUser', 200),
    ];
  }

  /**
   * @details - API Collection for user Details tab in User
   * @author - Jayasree
   */
  selectCboEntity(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.cbo_entity_mapping,
        'CboEntityMapping',
        200
      ),
    ];
  }
}
