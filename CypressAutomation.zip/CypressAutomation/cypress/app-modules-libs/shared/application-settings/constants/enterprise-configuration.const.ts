export const typeDropDownOptionValues = [
  'Allocation',
  'Correction',
  'Debit',
  'Payment',
  'Transfer',
  'Unassigned',
  'Write-Off',
];

export const systemDefaultTransactionCodes = [
  'System Correction',
  'Transfer to PG',
  'Transfer to PI',
  'Transfer to SG',
  'Transfer to SI',
  'Transfer to TI',
];

export const defaultWriteOffGroupCode = [
  'CO; Contractual obligations',
  'CR; Correction and reversals',
  'OA; Other adjustments',
  'PI; Payer initiated reductions',
  'PR; Patient responsibility',
  'Select Item',
];

export const defaultWriteOffReasonCode = [
  '1; Deductible Amount',
  '2; Coinsurance Amount',
  '3; Co-payment Amount',
  '4; The procedure code is inconsistent with the modifier used or a required modif',
  '5; The procedure code/bill type is inconsistent with the place of service. Note:',
  'Select Item',
];

export const contractTypes = [
  'Grouper',
  'Contract Fee Schedule',
  '% of Billed Charges',
];

export const adjustmentTime = [
  'At Charge Posting',
  'At Payment Posting',
  'Charge at Net',
];

export const grouperTypeColumnsInReviewEdit = [
  'CPT® /HCPCS',
  'Standard Fee',
  'Type',
  'Details',
  'Allowed Amount',
  'Exempt',
];

export const feeScheduleTypeColumnInReviewEdit = [
  'CPT® /HCPCS',
  'Standard Fee',
  'Type',
  'Imported Amt',
  'Details',
  'Allowed Amount',
  'Exempt',
];

export const typeOptionsForContractFeeSchedule = [
  'Appended Fee',
  '% of Billed Charges',
  'Not Covered/No Write-Off',
  'Not Covered/Write-Off',
  'Contract Allowable',
];

export const typeOptionsForGrouper = [
  'Appended Fee',
  '% of Billed Charges',
  'Not Covered/No Write-Off',
  'Not Covered/Write-Off',
  'Grouper',
];

export const reviewTypeOptionsUnderProcedures = [
  'Appended Fee',
  '% of Billed Charges',
  'Not Covered/No Write-Off',
  'Not Covered/Write-Off',
];

export const contractHeadersForFeeSchedule = [
  '1. Posting Option',
  '2. Import Rates',
  '3. Multiple Procedures',
  '4. Review/Edit',
  '5. Supplies',
];

export const contractHeadersForBilledCharges = [
  '1. Posting Option',
  '2. Multiple Procedures',
  '3. Review/Edit',
  '4. Supplies',
];
