import {
  CommonGetLocators,
  YesOrNo,
} from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_NURSING_CONFIGURATION = {
  CONFIGURATION_SEARCH: {
    CONFIGURATION_HEADER: ['Configuration', '#configHeader'],
    CONFIGURATION_SEARCH: ['Search', '#adminconfig_search'],
    REVENUE_CYCLE_MANAGER: [
      'Revenue Cycle Manager',
      `a[id='Revenue Cycle Manager_link']`,
    ],
    REVENUE_CYCLE_MANAGER_CHECK_MARK: [
      'RCM Check Mark',
      `[id='Revenue Cycle Manager_btn']`,
    ],
    INSURANCE: ['Insurance', '#Insurance_link'],
    ELECTRONIC_CLAIM_CONFIGURATION: [
      'Electronic Claim Configuration',
      '#btn_elec_claim_custom',
    ],
    PAPER_CLAIM_CONFIGURATION: [
      'Paper Claim Configuration',
      '#btn_paper_claim_custom',
    ],
    BLOCK_SCHEDULING: ['Block Scheduling', `a[id='Block Scheduling_link']`],
    BLOCK_NOTES: ['Block Notes'],
    CONTRACTS: ['Contracts'],
    FEE_SCHEDULE: ['Fee Schedule'],
    PROCEDURES_SEARCH_BOX: [
      'ProceduresSearchBox',
      '.right-inner-addon .full-input',
    ],
  },
  REVENUE_CYCLE_MANAGER: {
    SUB_HEADER: ['Revenue Cycle Manager', 'h4.rcm_title'],
    CLASSIFICATION_LABEL: ['Classification', 'h4.rcm_title.top-padding'],
    CLASSIFICATION: ['Classification', '#btn_rcm_classification_dictionary'],
    CLASSIFICATION_LIST: [
      'Classification List',
      '*[class^="sisMultiselect.scroller"]',
    ],
    DAYS_FROM_POST_TRANSFER_LABEL: [
      'Days from Post/Transfer',
      CommonUtils.concatenate(
        'h4.rcm_title',
        CoreCssClasses.Text.loc_label_text
      ),
    ],
    DAYS_FROM_POST_TRANSFER: [
      'Days From Post/Transfer',
      '#decimalTextBox_sorc_days_dtb',
    ],
  },

  BLOCK_SCHEDULING: {
    SUB_HEADER: ['Block Schedule', '.bs_title > span'],
    SELECT_BLOCK_SCHEDULE: [
      'Block Name',
      '[data-test-id^="config-selector-list"]',
    ],
    PHYSICIAN_DROPDOWN: [
      'Physician',
      '#btn_block_schedule_physician_dictionary',
    ],
    ROOM_DROPDOWN: ['Room', '#btn_roomId'],
    SPECIALTY: [
      'Specialty',
      CommonUtils.concatenate(
        '#caseSpecialtyList_select ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        '  > ',
        CoreCssClasses.DropDown.loc_dictionary,
        '-block > ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
    START_TIME: [
      'Start Time',
      CommonUtils.concatenate(
        '*[time-ctrl-id="recurrence_start_time"] ',
        CoreCssClasses.Text.loc_time_input
      ),
    ],
    END_TIME: [
      'End Time',
      CommonUtils.concatenate(
        '*[time-ctrl-id="recurrence_end_time"] ',
        CoreCssClasses.Text.loc_time_input
      ),
    ],
    WEEKLY: [
      'Weekly',
      CommonUtils.concatenate(
        '#radioListUL ',
        CoreCssClasses.Ng.loc_binding,
        CoreCssClasses.Ng.loc_isolate,
        ':contains("Weekly")'
      ),
    ],
    MONTHLY: [
      'Monthly',
      CommonUtils.concatenate(
        '#radioListUL ',
        CoreCssClasses.Ng.loc_binding,
        CoreCssClasses.Ng.loc_isolate,
        ':contains("Monthly")'
      ),
    ],
    WEEKLY_TOGGLE: ['WeeklyToggle', ':nth-child(1) > .flex > .radio-button'],
    MONTHLY_TOGGLE: ['MonthlyToggle', ':nth-child(2) > .flex > .radio-button'],
    MONTHLY_WEEKDAYS: [
      'Month',
      '*[id="btn_weekdaysList_multiselect"]~ul li[class="list-item"]',
    ],
    THE_MONTH: ['The month', '#btn_daysList_multiselect'],
    MONTH_ON: ['The month', '#btn_weekdaysList_multiselect span'],
    RECUR_EVERY: ['RECUR EVERY', ' #decimalTextBox_rec_weeks_id'],
    OF_EVERY: ['of every', '#decimalTextBox_number_of_months_id'],
    WEEK_ON: ['Week(s)On', '#btn_weekly_daysList_multiselect'],
    WEEK_ON_VALUE: [
      'Selected Values',
      '#btn_weekly_daysList_multiselect .ng-binding',
    ],
    WEEK_DAYS_LISTS: ['Week Days', '#btn_weekdaysList_multiselect'],
    WEEK_DAYS_LISTS_VALUE: [
      'Week Days selected values',
      '#btn_weekdaysList_multiselect .ng-binding',
    ],
    START_DATE: ['Start Date', '#datepicker-start #date-input'],
    BLOCK_COLOR: [
      'Block Color',
      CommonUtils.concatenate(
        '#block-color-list ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' ',
        CoreCssClasses.DropDown.loc_dictionary,
        '-block div'
      ),
    ],
    BLOCK_OUT: ['Block Out', '*[data-toggle= "tab"]:contains("Yes")'],
    END_DATE: ['End Date', '#datepicker-end #date-input'],
    CROSS_ICON: [
      'Cross Icon',
      CommonUtils.concatenate(
        CommonGetLocators.span,
        CoreCssClasses.Icon.loc_cross_icon,
        ':first-child'
      ),
    ],
    ROOM_CLOSE: [
      'Room Closed',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_title,
        ':contains("Room Closed")'
      ),
    ],
    OK_BUTTON: [
      'Ok',
      CommonUtils.concatenate(
        '#btnOk > ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],
  },

  DISCOUNTS: {
    SUB_HEADER: ['Discounts', 'h4.sor_title'],
    DISCOUNT_PERCENT: [
      'Discount Percent',
      '#decimalTextBox_sorc_discountPercentString_dtb',
    ],
    TRANSACTION_CODE: [
      'Transaction Code Dropdown',
      '#sourceofrevenue_transaction_codes div[class*="dropdown-btn"]',
    ],
    WRITEOFF_GROUP_CODE: [
      'Writeoff group code Dropdown',
      '#sourceofrevenue_group_codes div[class*="dropdown-btn"]',
    ],
    WRITEOFF_REASON_CODE: [
      'Reason Code Dropdown',
      '#sourceofrevenue_reason_codes div[class*="dropdown-btn"]',
    ],
    ADD_DISCOUNT_SEARCH_FIELD: ['Search field', '#addConsents'],
    SEARCH_INPUT: ['Search', '#txt_cs_'],
    DISCOUNTS_LISTS: [
      'discounts item lists',
      'div[class*="config-selector-list-item-container"] ',
    ],
    SOURCE_FIELD_IN_DISCOUNT: ['Source field', '.item-source'],
  },
  COMMON: {
    PATIENT_SEARCH_ICON: ['Patient Search Icon', '.icon-patient-search'],
    ADD: {
      ADD_POPUP_WINDOW: ['AddWindow', '.modal-body.consent-config-wrapper'],
      ADD_NAME: ['Add', '#addConsents'],
      DONE_BUTTON: ['Done', '#btnAddCopyDone'],
      CANCEL_BUTTON: ['Cancel', '#btnAddCopyCancel'],
      DUPLICATE_MESSAGE: ['Warning Text', '*[class^="warning-text"]'],
      ADD_POPUP_DUPLICATE_MESSAGE: [
        'Add Popup Warning Text',
        '.add-popup-dictionary [class^="warning-text"]',
      ],
      CREATE_COPY: ['Create copy', '#rdoACCreateCopy'],
    },
    HEADER: ['Business', '.panelTitle.ng-binding'],
    ADD_BUTTON: ['AddWindow', '#btn_Add_'],
    SEARCH: ['Search', '#txt_cs_'],
    NAME: ['Name', '#source_revenue_name'],
    ALL_LIST_OPTIONS: [
      'All List Items',
      '.config-selector-list-item-container',
    ],
    FIRST_OPTION_IN_LIST: ['First List Item', '.list-group-item:nth-child(1)'],
    HELPER_TEXT: ['Helper Text', '.select_create'],
  },

  TRANSACTION_CODES: {
    SUB_HEADER: ['Transaction Codes', 'h4.panel_title'],
    SEARCH: ['Search', '#txt_cs_'],
    TRANSACTION_CODE_NAME: ['Transaction Code Name', '#transaction_code_name'],
    TYPE_LABEL: [
      'Type',
      CommonUtils.concatenate(
        'label',
        CoreCssClasses.Text.loc_label_text,
        '.transaction-type'
      ),
    ],
    TYPE: ['Type', CoreCssClasses.DropDown.loc_dropdown_btn],
    TYPE_LIST: ['Type List', '*[class^="infinite-items.scroller"]'],
    ADD_BUTTON: ['Add', '#btn_Add_'],
    ADD_TRANSACTION_CODE_SEARCH: [
      'Add transaction code search',
      '#addConsents',
    ],
    SELECTED_TRANSACTION_TYPE: [
      'Selected Transaction Type',
      'div[class="selected"] span',
    ],
    SOURCE_FIELD_IN_TRANSACTION: [
      'Source field',
      '.col-md-6.ng-scope input',
      'sourceField',
    ],
    ADD_BUTTON_WHEN_DISABLED: [
      'Add button when disabled',
      '.search-row div:nth-child(2)',
    ],
  },
  INSURANCE: {
    SUB_HEADER: ['Insurance', '#Insurance_link'],
    INSURANCE_NAME: ['Insurance Carrier Name', '#insurance_carrier_name'],
    DUPLICATE_MESSAGE: [
      'Warning Text',
      CommonUtils.concatenate(
        CoreCssClasses.ClassPrefix.loc_fa_fa,
        '-exclamation-circle'
      ),
    ],
    E_PAYER_ID: ['EPayer ID', '.inner-search > .full-input'],
    ELECTRONIC_CLAIM_INSTITUTIONAL: [
      'Electronic Claim',
      '#institutional_input',
    ],
    ELECTRONIC_CLAIM_PROFESSIONAL: ['Electronic Claim', '#professinal_input'],
    ELECTRONIC_CLAIM_NA: ['Electronic Claim', '#na_input'],
    PAPER_FORM_UB: ['Paper Form', '#ub_input'],
    PAPER_FORM_HCFA: ['Paper Form', '#hcfa_input'],
    PAPER_FORM_NA: ['Paper Form', '#pageform_na_input'],
    INSURANCE_ADD_PLAN_BUTTON: [
      'Add New Insurance Plan',
      '#add_insurance_plan_btn',
    ],
    INSURANCE_PLAN_NAME: ['Insurance Plan Name', '#insuranceplan_name'],
    PAYER_CODE: ['Payer Code', '#primaryEmcPayerid'],
    INSURANCE_CLASSIFICATION: [
      'Insurance Classification',
      CommonUtils.concatenate(
        '#ipc_classification_select > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
    SECONDARY_PAYER_CODE: ['Secondary Payer Code', '#secondaryEmcPayerid'],
    INSURANCE_PLAN_TYPE: [
      'Insurance Plan Type',
      CommonUtils.concatenate(
        '##ipc_insurancePlanTypes_select > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        '> #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
    PRIMARY_HP_ID: ['Primary HPID', '#primaryHpId'],
    GROUP_INSURANCE_ID: [
      'Group Insurance ID',
      '#insuranceplan_group_insuranceid',
    ],
    ACCEPT_ASSIGNMENT_YES: [
      'Accept Assignment',
      '#accept_assignment_radio_yes',
    ],
    ACCEPT_ASSIGNMENT_NO: ['Accept Assignment', '#accept_assignment_radio_no'],
    GENERATE_BILL_YES: ['Generate Bill', '#genarate_claim_radio_yes'],
    GENERATE_BILL_NO: ['Generate Bill', '#genarate_claim_radio_no'],
    CONTRACT: [
      'Contract',
      CommonUtils.concatenate(
        '#insuranceplan_contract > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > ',
        CoreCssClasses.DropDown.loc_dropdown_arrow
      ),
    ],
    DEFAULT_PAYMENT_TRANSACTION_CODE: [
      'Default Payment Transaction Code',
      CommonUtils.concatenate(
        '#ins_payment_transaction_codes > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
    DEFAULT_WRITEOFF_TRANSACTION_CODE: [
      'Default WriteOff Transaction Code',
      CommonUtils.concatenate(
        '#ins_wo_transaction_codes > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > ',
        CoreCssClasses.DropDown.loc_dropdown_arrow
      ),
    ],
    DEFAULT_WRITEOFF_GROUP_CODE: [
      'Default WriteOff Group Code',
      CommonUtils.concatenate(
        '#ins_wo_group_codes > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
    DEFAULT_WRITEOFF_REASON_CODE: [
      'Default WriteOff Reason Code',
      CommonUtils.concatenate(
        '#ins_wo_reason_codes > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > ',
        CoreCssClasses.DropDown.loc_dropdown_arrow
      ),
    ],
    ADD_CLAIM_OFFICE_NAME: ['ADD Claim Office ITEM', '#btn_Add_claim_office'],
    CLAIM_OFFICE_NAME: ['Claim Office Name', '#addclaim_office_name'],
    ADDRESS: ['Address', '#addclaim_address1'],
    CITY: ['City', '#addclaim_city'],
    STATE: [
      'State dropdown',
      CommonUtils.concatenate(
        '#addclaim_state > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > ',
        CoreCssClasses.DropDown.loc_dropdown_arrow
      ),
    ],
    ZIP: ['Zip', '#addclaim_zipcode'],
    EXTENDED_ZIP: ['Extended Zip', '#addclaim_extzipcode'],
    PHONE: [
      'Phone',
      CommonUtils.concatenate(
        '#add_claim_office_phone > .',
        CoreCssClasses.Text.loc_input_text
      ),
    ],
    CONTACT_NAME: ['Contact Name', '#addclaim_contact'],
    CLAIM_OFFICE_DONE: ['Done', '#add_acop_cancel'],
    INSURANCE_DONE: ['Done', '#ipc_done_btn'],
    INSURANCE_PLAN_CONTEXT_ICON: [
      'Insurance Plan Context Icon',
      '.context-icon',
    ],
    DEFAULT_PLAN: ['Default Plan', 'label[ng-click*="defaultPlanTf=false"]'],
  },

  CONTRACTS: {
    SUB_HEADER: ['Contracts', ' '],
    EFFECTIVE_DATE: [
      'Effective Date',
      '#datepicker-effective-container #date-input',
    ],
    EXPIRATION_DATE: [
      'ExpirationDate',
      '#datepicker-expire-container #date-input',
    ],
    CONTRACT_TYPE: [
      'Contract Type',
      CommonUtils.concatenate(
        '#contract_type ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
    CONTRACT_TYPE_DROPDOWN: [
      'Contract Type',
      CommonUtils.concatenate(
        '#contract_type ',
        CoreCssClasses.DropDown.loc_fa_dropdown_lg
      ),
    ],
    CONTRACT_SEARCH_BOX: ['Search box', '#txt_cs_'],
    SEARCHED_CONTRACT: [
      'Searched contract',
      '.config-selector-list-item-container',
    ],
    SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS: [
      'Selecting Procedure',
      '.table-scroll-review  #row_0_',
    ],
    TYPE_DROPDOWN_CONTRACTS: ['Dropdown type', '#review_type #ssDiv_ .fa-lg'],
    REVIEW_TYPE: ['ReviewType', ' #review_type .dictionaryItem '],
    SEARCH_PROCEDURE_IN_CONTRACTS: [
      'Procedure in contract',
      '.review-edit-container .search-cpt input',
    ],
    EXEMPT_DROPDOWN_CONTRACTS: ['Exempt', '#exempt_dpdwn  #ssDiv_  .fa-lg'],
    EXEMPT: ['Exempt', ' #exempt_dpdwn .dictionaryItem '],
    DETAILS: ['Details', '#decimalTextBox_review_reviewChargeString_dtb'],
    PROCEDURES_LABEL: ['Procedures', '.tableTop .custom-label-long'],
    POSTING_OPTIONS: {
      POSTING_OPTIONS: ['Posting Option', '#tab_posting_option'],
      PERCENTAGE_OF_ALLOWED: [
        '% Allowed',
        '#decimalTextBox_popt_billingChargeString_dtb',
      ],
      ADJUSTMENT_TIME: [
        'Adjustment Time',
        CommonUtils.concatenate(
          '#nonGrouperAdjTimeId ',
          CoreCssClasses.DropDown.loc_dropdown_btn
        ),
      ],
      DEFAULT_WRITEOFF_TRANSACTION_CODE: [
        'DefaultWrite-OffTransactionCode',
        CommonUtils.concatenate(
          '#popt_transaction_codes ',
          CoreCssClasses.DropDown.loc_dropdown_btn
        ),
      ],
      DEFAULT_WRITEOFF_GROUP_CODE: [
        'DefaultWrite-OffGroupCode',
        CommonUtils.concatenate(
          '#popt_group_codes ',
          CoreCssClasses.DropDown.loc_dropdown_btn
        ),
      ],
      DEFAULT_WRITEOFF_REASON_CODE: [
        'DefaultWrite-OffReasonCode',
        CommonUtils.concatenate(
          '#popt_reason_codes ',
          CoreCssClasses.DropDown.loc_dropdown_btn
        ),
      ],
      PLUS_ICON: ['Plus Icon', '.btn-add-attachment-type'],
      FEE_GROUPS: {
        FEE_GROUP: ['Fee Group', '.fee-group'],
        DROP_DOWN: [
          'Drop down',
          CommonUtils.concatenate(
            CoreCssClasses.DropDown.loc_dictionary_block,
            ' ',
            CommonGetLocators.div
          ),
        ],
        DROP_DOWN_LIST: [
          'Drop down list',
          CoreCssClasses.List.loc_diagnosis_list_item,
        ],
        REIMBURSEMENT: ['Reimbursement', 'input[id*="decimalTextBox"]'],
        ITEMS: ['Items', '.infinite-items'],
        SEARCH: ['Search', '.searchfield'],
        DATA_COLUMN: ['Data Column', '.data-col-val'],
      },
    },
    IMPORT_RATES: {
      IMPORT_RATES: ['Import Rates', ''],
    },
    MULTIPLE_PROCEDURES: {
      MULTIPLE_PROCEDURES: ['Multiple Procedures', ''],
    },
    REVIEW_EDIT: {
      REVIEW_EDIT: ['Review/Edit', '#tab_review_edit'],
    },
    SUPPLIES: {
      SUPPLIES: ['Supplies', ''],
    },
  },
  SCHEDULE: {
    SCHEDULE: ['Schedule', ''],
    WORKING_DAYS: {
      SUNDAY: ['Sunday', ''],
      MONDAY: ['Monday', ''],
      TUESDAY: ['Tuesday', ''],
      WEDNESDAY: ['Wednesday', ''],
      THURSDAY: ['Thursday', ''],
      FRIDAY: ['Friday', ''],
      SATURDAY: ['Saturday', ''],
    },
  },
  FEE_SCHEDULE: {
    SUB_HEADER: ['Fee Schedule', ' '],
    ADD: ['Add', 'item-list-add-button'],
    ADD_PROCEDURE_SEARCH: [
      'Add Procedure Search',
      CommonUtils.concatenate(
        `[data-test-id='dbSearchAutocomplete'] `,
        CommonGetLocators.input
      ),
    ],
    PROCEDURE_LIST: ['Procedure List', '[role="listbox"] '],
    CPT_SELECT: ['CPT Select', CoreCssClasses.List.loc_p_autocomplete_items],
    CANCEL: ['Cancel', '#btnCancel'],
    KEY_BOARD_ICON: ['Keyboard Icon', `[data-test-id='keyBoardTooltip']`],
    PROCEDURE_FREE_TEXT_BOX: ['Procedure Free Text', `#dbSearchInput`],
    CPT_SELECT_LIST: ['CPT Select from List', 'item-list-child-container'],
    AMOUNT: [
      'Amount',
      CommonUtils.concatenate('.amount ', CommonGetLocators.input),
    ],
    FEE_STATUS: [
      'Fee Status',
      CommonUtils.concatenate(
        `[data-test-id='fsStatusDropdown'] `,
        CoreCssClasses.MultiSelect.loc_p_multiselect_label
      ),
    ],
    MODIFIED_PROCEDURE_DESCRIPTION: [
      'Modified Procedure Description',
      '#fsModifiedProcedureDescription',
    ],
    STATUS_DROPDOWN: [
      'Status Dropdown',
      CommonUtils.concatenate(
        `[data-test-id='fsStatusDropdown'] `,
        CoreCssClasses.MultiSelect.loc_p_multiselect_label
      ),
    ],
    STATUS_DROPDOWN_LIST: [
      'Status Dropdown List',
      CommonUtils.concatenate(
        `[data-test-id*='ui-dropdown-default'] `,
        CommonGetLocators.li
      ),
    ],
    UPLOAD_FILE: ['Upload File', `div[class*='upload-drop-area']`],
    HISTORY: {
      HISTORY_BUTTON: ['History', 'fsHistoryBtn'],
      ADD_AMOUNT: ['Add Amount'],
      AMOUNT_INPUT: [
        'Amount Input Field',
        CommonUtils.concatenate(
          `.feeSchedule-history-amount  `,
          CommonGetLocators.input
        ),
      ],
      EFFECTIVE_DATE_INPUT: [
        'Effective Date Input',
        '.date-time-container  input[placeholder="mm/dd/yyyy"]',
      ],
      AMOUNT: ['Amount', '.feeSchedule-history-amount'],
      EFFECTIVE_DATE: [
        'Effective Date',
        CommonUtils.concatenate(
          `.feeSchedule-history-effectivedate `,
          CommonGetLocators.span
        ),
      ],
      MODIFIED_BY: ['Modified By', '.feeSchedule-history-modifiedby'],
      MODIFIED_DATE: ['Modified Date', '.feeSchedule-history-modifieddate'],
    },
  },
  PREFERENCE_CARDS_CONFIGURATION: {
    EXISTING_PREFERENCE_CARD: [
      'Existing preference card',
      'div[title="Preference Card1"]',
    ],
    PREFERENCE_CARD_SELECTED_ITEM: [
      'Preference card selected item',
      '#configItem',
    ],
    PREFERENCE_CARD_WARNING_BANNER: [
      'preference_card Warning banner',
      '.warning-banner.ng-scope',
    ],
    CONFIGURATION: ['Configuration', '#Configuration_link'],
    PREFERENCE_CARD_NAME: ['preference_card_name', '#preferenceCardName'],
    TRASH_ICON: [
      'Trash Icon',
      '#configItem > .config-selector-list-item-container > .fa-trash-o',
    ],
    CASE_SPECIALTY: [
      'Case_Specialty',
      CommonUtils.concatenate(
        '#pcc_caseSpecialtyList_select > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > .pull-left'
      ),
    ],
    APPOINTMENT_TYPE: [
      'Appointment_Type',
      CommonUtils.concatenate(
        '#appointmenttypelist_select > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > .pull-left'
      ),
    ],
    PHYSICIAN: [
      'Physician',
      CommonUtils.concatenate(
        '#physicianlist_select > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > .pull-left'
      ),
    ],

    ANESTHESIA_TYPE: [
      'Anesthesia Type',
      CommonUtils.concatenate(
        '#anesthesiatypelist_select > ',
        CoreCssClasses.DropDown.loc_dropdown_dictionary,
        ' > #ssDiv_ > ',
        CoreCssClasses.DropDown.loc_dropdown_btn,
        ' > .pull-left'
      ),
    ],
    PROCEDURE: ['Procedure', '#cptdropdownn_configuration_searchWord'],
    PROCEDURE_SELECTED_ITEM: [
      'Procedure Selected Item',
      '.proc-list-container  .proc-list .procedure-text',
    ],
    DURATION: ['Duration', '#decimalTextBox_pcc_duration_dtb'],
    DURATION_MINS_TEXT: [
      'DurationMins',
      CommonUtils.concatenate(CoreCssClasses.Text.loc_label_text, '.min-label'),
    ],
    CLEAN_UP_TIME: ['Clean_Up_Time', '#decimalTextBox_pcc_cleanUpTime_dtb'],
    CLEAN_UP_MINS_TEXT: [
      'Clean_Up_Mins_Text',
      CommonUtils.concatenate(
        CoreCssClasses.Text.loc_label_text,
        '.clean-up-min-label'
      ),
    ],
    PHYSICIAN_PREFERENCES: [' Physician_Preferences', '#notes-field'],
    PREFERENCE_DROP_DOWN: [
      'Preference Dropdown',
      '#ssDiv_addCopy  span[class="pull-left ng-binding ng-scope"]',
    ],
    CPT_TRADEMARK: ['CPT_Trademark', '.col-md-12.disclaimer-text.ng-binding'],
    RESOURCES: {
      ADD_IMPLANT_OR_PROSTHETIC: {
        SUB_HEADER: ['Add Implant or Prosthetic', '#btn_addNew_'],
        ADD_IMPLANT_OR_PROSTHETIC_POPUP: [
          'Add Implant or Prosthetic PopUp',
          '.implant-or-prosthetic-add',
        ],
        IMPLANT_KEYBOARD_ICON: [
          'Implant Keyboard Icon',
          CommonUtils.concatenate(
            `external-inventory-search[place-holder-text*="name or inventory"] `,
            CoreCssClasses.Icon.loc_keyboard_icon
          ),
        ],
        MANUFACTURER_KEYBOARD_ICON: [
          'Manufacturer Keyboard Icon',
          CommonUtils.concatenate(
            `external-inventory-search[place-holder-text="name"] `,
            CoreCssClasses.Icon.loc_keyboard_icon
          ),
        ],
        IMPLANT: [
          'Implant',
          CommonUtils.concatenate(
            `external-inventory-search[place-holder-text*="name or inventory"] `,
            CommonGetLocators.input
          ),
        ],
        MANUFACTURER: [
          'Manufacturer',
          CommonUtils.concatenate(
            `external-inventory-search[place-holder-text="name"] `,
            CommonGetLocators.input
          ),
        ],
        QUANTITY: ['Quantity', 'input[placeholder="Quantity"]'],
        SIZE: ['Size', 'input[placeholder="Size"]'],
        LOT_NO: ['Lot #', 'input[placeholder="Lot #"]'],
        SERIAL_NO: ['Serial #', 'input[placeholder="Serial #"]'],
        EXPIRATION: ['Expiration', 'input[placeholder="Expiration"]'],
        REFERENCE_NO: ['Reference #', 'input[placeholder="Reference #"]'],
        NOTES: ['Notes', 'input[placeholder="Add Notes"]'],
        ADD_ANOTHER_BUTTON: ['Add Another', '#btn_addAnotherButtonL'],
        DONE: ['Done', '#btn_doneButtonLabel'],
      },
      SUPPLIES_AND_INSTRUMENTS: {
        SUB_HEADER: ['Supplies and Instruments'],
        KEYBOARD_ICON: ['Keyboard Icon', CoreCssClasses.Icon.loc_keyboard_icon],
        SUPPLY: [
          'Supply',
          CommonUtils.concatenate(
            `external-inventory-search[place-holder-text*="name"] `,
            CommonGetLocators.input
          ),
        ],
        QUANTITY: ['Quantity', 'decimal-text-box #decimalTextBox_'],
        NOTES: ['Notes', 'input[placeholder="Notes"]'],
        CLICK_SUPPLY_ITEM: [
          'Click on Supply Item',
          `div[ng-switch-when="externalInventorySearch"]`,
        ],
      },
      INVENTORY_FREE_TEXT: [
        'Inventory Free Text',
        'input[placeholder="Enter Text"]',
      ],
      INVENTORY_IOS_TEXT: [
        'Inventory Ios Text',
        'input[placeholder=" Search by name or inv #"]',
      ],
    },
    ADD_IMPLANTS: {
      ADD_IMPLANT_BUTTON: ['Add Implant/Prosthetic', '#btn_addNew_'],
      IMPLANTS_SEARCH_FIELD: [
        'implant-prosthesis-ios-search field',
        'div[class*="implant-prosthesis-ios-search"] span input',
      ],
      QUANTITY: ['Quantity', '[placeholder="Quantity"]'],
      DONE_BUTTON: ['Done', '#btn_doneButtonLabel'],
      MANUFACTURER: ['Manufacturer'],
      IMPLANT_DESCRIPTION: ['ImplantDescription'],
    },
  },
  RECOVERY_SETTINGS: {
    SETTINGS: ['Recovery Settings', '#Recovery Settings_link'],
  },
  ADD_ON_FEATURES: {
    SUB_HEADER: [
      'Add On Features',
      CommonUtils.concatenate(
        'a ',
        selectorFactory.getSpanText('Add On Features')
      ),
    ],
    ADD_ON_FEATURE: [
      'Add On Feature Minus',
      'collapsible-panel[header-text="Add On Features"] #sei_',
    ],
    UNRELEASED_FEATURE: [
      'Unreleased Feature Plus',
      'collapsible-panel[header-text="Unreleased Feature Management (Enterprise)"] #sei_',
    ],
    OUTBOUND_CCDA: {
      FLAG: ['Outbound CCDA', selectorFactory.getLabelText('Outbound CCDA')],
      TOGGLE: ['CCDA Toggle', '[for*="configFeaturesOutbound CCDA"]'],
    },
    ENABLE_DISABLE_TOGGLE: [
      'Enable Disable Toggle',
      CoreCssClasses.Toggle.loc_on_off_switch_label,
    ],
    FEATURE_SECTION: ['Feature Section', '.section-text'],
    LABEL: ['Label', '.label_admin'],
  },
  SIS_GATEWAY_CONFIG: {
    SIS_GATEWAY: ['SIS Gateway'],
    OUTBOUND_CCDA: {
      DISABLE: [
        'Outbound CCDA Disable',
        selectorFactory.gatewayConfigDisabled('Outbound CCDA'),
      ],
      ENABLE: ['Outbound CCDA Enable', '#ooutboundCCDA-gateway-url'],
    },
  },
  REPORTING_CODES: {
    REPORTING_CODES: ['Reporting Codes', 'h4 > span'],
    CCDA_CODE: ['CCDA Code', 'input[placeholder=" CCDA Description"]'],
    ETHNICITY: ['Ethnicity', 'div[title*="Ethnicity"]'],
    LANGUAGE: ['Language', 'div[title*="Language"]'],
    RACE: ['Race', 'div[title*="Race"]'],
    TOBACCO_USE: ['Tobacco Use', 'div[title*="Tobacco Use"]'],
  },
  DICTIONARIES: {
    DICTIONARIES_TEXT: [
      'Dictionaries',
      CommonUtils.concatenate(
        'a ',
        selectorFactory.getSpanText('Dictionaries')
      ),
    ],
    SHOW_INACTIVE: ['Show Inactive', 'label[data-test-id="show-inactive-lbl"]'],
    SEARCH_FIELD: ['Search', '#txtConsentFilter'],
    ADD_ITEM: ['Add Item', 'button[data-test-id="add-item-btn"]'],
    ITEM: ['Item', 'input[data-test-id="dict-item-new"]'],
    SEARCH_RESET_ICON: ['Search reset icon', '#iconSearchInput'],
  },
  DICTIONARY: {
    DICTIONARY: ['Dictionaries', ''],
    SEARCH_BOX: ['Search Box', '#txtConsentFilter'], //SEARCH_FIELD
    SHOW_INACTIVE_LABEL: [
      'ShowInactiveLabel',
      '[data-test-id="show-inactive-lbl"]', //SHOW_INACTIVE:
    ],
    SHOW_INACTIVE: ['Show Inactive', '[data-test-id="show-inactive-switch"]'], // rename as _toggle
    ADD_ITEM: ['Add Item', '[data-test-id="add-item-btn"]'], //ADD_ITEM
    DIC_ITEM_NEW: ['Add New Dic Item', '[data-test-id="dict-item-new"]'], //ITEM
    ACTIVE_TOGGLE: ['Active Toggle', '[data-test-id="active-option"]'],
    SHOW_ACTIVE_COUNT: ['Active count', '[data-test-id="show-active-count"]'],
    SHOW_ALL_COUNT: ['All Count', '[data-test-id="show-all-count"]'],
    ITEM_CONTAINER: ['Item Container', '[data-test-id^="dict-item-row"]'],
    ITEM_HEADER: ['Item', '[data-test-id="hdr-item"]'],
    ACTIVE_HEADER: ['Active', '[data-test-id="hdr-active"]'],
    SELECT_DICTIONARY: [
      'Dictionary Name',
      '[data-test-id="item-list-child-container"]',
    ],
    ROW_ID: ['Row Id', '[data-test-id^= "dict-item-row"]'],
    CONFIRM_DIALOG: [
      'Confirm Warning Dialog',
      '[data-test-id="confirm-dialog"]',
    ],
  },
  TOGGLE_BUTTON_DISABLED_TEXT: ['Toggle button disabled text', '.disabled-txt'],
  INCLUDE_CHARGES_UNASSIGNED_PAY_TOGGLE: [
    'Include Charges Unassigned Pay',
    `sis-toggle-switch[model*='includeInsuranceChargesAndUPTf'] #div_ div`,
  ],
  ENABLE_INCLUDE_INSURANCE: [
    'Enable include insurance',
    '[ng-class*="Changes"].decimal_container',
  ],
  INCLUDE_INSURANCE_ADDON: [
    'Include insurance in add on feature',
    'input[id*="Include Insurance"]~label',
  ],
  PATIENT_STATEMENT_INSURANCE_CSV: [
    'Patient Statement Include Insurances CSV Changes',
    `input[id*='Patient Statement Include Insurances CSV Changes']`,
  ],
  CONSENTS: {
    SUB_HEADER: ['Consents'],
    PRIMARY_PROCEDURE_ONLY_LABEL: [
      'Primary Procedure Only',
      '.primary-procedure-only-container',
    ],
    PRIMARY_PROCEDURE_ONLY: [
      'Primary Procedure Only',
      '.primary-procedure-only-switch-container input[class*=ng-empty]',
    ],
    PRIMARY_PROCEDURE_ONLY_TOGGLE: ['Disable', '.onoffswitch-inner'],
    PRIMARY_PROCEDURE_ONLY_SWITCH: [
      'Primary Procedure Switch',
      '#primaryProcedureOnlySwitch',
    ],
    PROCEDURE_DISPLAY: {
      DROP_DOWN: ['Procedure Display', '.procedure-display'],
      DROP_DOWN_ARROW_ICON: [
        'Arrow Icon',
        CoreCssClasses.DropDown.loc_fa_dropdown_angle_down,
      ],
      DROP_DOWN_VALUES: ['Values', '.dictionaryItem span'],
      DROP_DOWN_TEXT: [
        'Procedure Dropdown',
        CommonUtils.concatenate(
          CoreCssClasses.DropDown.loc_dropdown_btn,
          ' span.pull-left'
        ),
      ],
    },
    SINGLE_SELECT: ['SingleSelect', 'single-select div[id=ssDiv_]'],
    INSERT_VARIABLES: {
      EDITOR_CONTAINER: ['Editor Container', '.editor-container'],
      DROP_DOWN: [
        'Drop Down Arrow',
        CommonUtils.concatenate(
          'single-select span',
          CoreCssClasses.DropDown.loc_fa_dropdown_lg
        ),
      ],
      INSERT_BUTTON: ['Insert Button', '#btn_I_'],
      TEXT_AREA: ['Text Area'],
    },
  },
  EXEMPT_DROPDOWN_CONTRACTS: ['Exempt', '#exempt_dpdwn  #ssDiv_  .fa-lg'],
  REVIEW_TYPE: ['Review Type', ' #review_type .dictionaryItem '],
  EXEMPT: ['Exempt', ' #exempt_dpdwn .dictionaryItem '],
  DETAILS: ['Details', '#decimalTextBox_review_reviewChargeString_dtb'],
  SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS: [
    'Selecting Procedure',
    '.table-scroll-review  #row_0_',
  ],
  TYPE_DROPDOWN_CONTRACTS: [
    'Dropdown type',
    CommonUtils.concatenate(
      '#review_type  #ssDiv_  ',
      CoreCssClasses.DropDown.loc_fa_lg
    ),
  ],
  SEARCH_PROCEDURE_IN_CONTRACTS: [
    'Procedure in contract',
    '.review-edit-container .search-cpt input',
  ],
  ADD_ON_FEATURE: {
    ADD_ON_FEATURE_HEADER: ['Add On Features', '#Add On Features_btn'],
    UNRELEASED_PLUS: [
      'Unreleased Plus icon',
      CommonUtils.concatenate(
        '.expand-collapse',
        CoreCssClasses.DropDown.loc_dropdown_arrow,
        CoreCssClasses.Button.loc_unreleased_plus,
        CoreCssClasses.Icon.loc_plus_icon
      ),
    ],
    MFASSO_HEADER: [
      'Multifactor Authentication and Single Sign On',
      CommonUtils.concatenate(
        CoreCssClasses.Text.loc_label_text,
        CoreCssClasses.Ng.loc_binding
      ),
    ],
    MFASSO: [
      'Multifactor Authentication and Single Sign On',
      'input[id="configFeaturesMultifactor Authentication and Single Sign On"]',
    ],
    MFASSO_BUTTON: [
      'Multifactor Authentication and Single Sign On',
      CommonUtils.concatenate(
        '[for="configFeaturesMultifactor Authentication and Single Sign On"] ',
        CoreCssClasses.Toggle.loc_on_off_switch_inner
      ),
    ],
    CDT_CODE: ['CDT', 'input[id="configFeaturesCDT (ADA) Codes"]'],
  },
  FACILITY_USERS: {
    USERS: ['Users', '#Users_link'],
    USER_SEARCH: ['User Search', '#filterString'],
    USERS_DISABLE: ['Change password', '#mercury_setorchange_passbtn'],
    USER_SETTING_DISABLE: ['Change password', '.button-secondary-small'],
    CLICK_ON_CROSS_ICON: ['Cross icon', CoreCssClasses.Button.loc_fa_close],
  },
  FORMULARY: {
    SUB_HEADER: ['Formulary'],
    SEARCH_MEDICATION: ['Search Medication', '#medication_search_field'],
    EDIT_TEMPLATE: {
      SUB_HEADER: ['Edit Template', '.add-medication-template'],
      MEDICATION: [
        'Medication',
        'input[placeholder=" Search medication database"]',
      ],
      ADMINISTRATION_AMOUNT: [
        'Administration Amount',
        '#decimalTextBox_adt_amt_',
      ],
      USAGE_UNIT_OF_MEASURE: [
        'Usage Unit of Measure',
        '#decimalTextBox_usg_mes_',
      ],
      DONE: ['Done', '#add_medication_done'],
      COMPOUND_MEDICATION_YES: [
        'Compound Medication',
        CommonUtils.concatenate(
          'compound-medication ',
          '.sis-toggle-switch ',
          selectorFactory.getDivText(YesOrNo.yes)
        ),
      ],
      COMPOUND_MEDICATION_NO: [
        'Compound Medication',
        CommonUtils.concatenate(
          'compound-medication ',
          '.sis-toggle-switch ',
          selectorFactory.getDivText(YesOrNo.no)
        ),
      ],
    },
  },
  PHYSICIAN_ORDERS: {
    SUB_HEADER: ['Orders', `div[heading='Physician'] #Orders_link`],
    LIST: ['Orders List', `[data-test-id*='config-selector-list-item']`],
    ORDERS_NAME: ['Orders Name', '.physician-orders-right input'],
    PHYSICIANS: ['Physicians', 'button.sisMultiselect'],
    ADD_MEDICATION_ORDER: [
      'Add Medication Order',
      selectorFactory.getButtonText('Add Medication Order'),
    ],
    ADD_MEDICATION: {
      SUB_HEADER: [
        'Add Medication',
        selectorFactory.getButtonText('Add Medication'),
      ],
      NOTES: ['Medication Notes', '.medication-notes'],
      SEARCH_AVAILABLE_MEDICATIONS: [
        'Search Available Medication',
        '#aval_medication_searchtext',
      ],
      AVAILABLE_MEDICATION_LIST: [
        'Available Medication List',
        '.medication-list',
      ],
    },
  },
  PLANS: {
    SUB_HEADER: ['Plans'],
    SEARCH_BOX: ['Search Box', 'search-input input[placeholder=" Search"]'],
    ADD_PLAN: {
      SUB_HEADER: ['Add Plan'],
    },
    PLAN_NAME: ['Plan Name', 'input#planName'],
  },

  PRE_ADMISSION_INSTRUCTIONS: {
    SUB_HEADER: ['Pre-Admission Instructions'],
    WORKLIST_SEARCH: ['WorkList Search', '#worklist_filter_string'],
    ADD: ['Add', `[data-test-id='worklist-add-template']`],
    WORKLIST_NAME: ['WorkList Name', '#addworklist'],
    WORKLIST_OPTIONS: ['Options', `[draggable-options*='worklist']`],
    PLUS_ICON: ['Plus Icon', '.add-worklist-icon'],
    WORKLIST_SECTION: ['Worklist Items', '.worklist-items'],
    SEARCH: ['Search', `.worklist-item-search [placeholder*='Search']`],
    CONFIGURABLE_QUESTIONS: {
      SELECT_ITEM: [
        'Select Item',
        CommonUtils.concatenate(
          '.worklist-questions ',
          CoreCssClasses.DropDown.loc_dropdown_btn
        ),
      ],
    },
    DOCUMENTS_ACKNOWLEDGED: {
      SUB_HEADER: ['Documents Acknowledged'],
      YES_NO: ['Yes Or No', `[data-test-id='wlq-dw-yesno']`],
      ADD_ITEM_INPUT: [
        'Add Item Input',
        `[data-test-id='wlq-dw-addItemInput']`,
      ],
      ADD_ITEM_BUTTON: [
        'Add Item Button',
        `[data-test-id='wlq-dw-addItemButton']`,
      ],
    },
  },
  PATIENT_TRACKING: {
    SUB_HEADER: ['Patient Tracking'],
    TRACKING_BOARD_URL: ['Tracking Board URL'],
    TRACKER_PANEL: ['Tracker Panel', '.url-board'],
    SURGERY_BOARD_TRACKER: ['Surgery Board Tracker'],
  },
  CLICK_ON_DETAILS: [
    'Details',
    CommonUtils.concatenate(
      '[id="review_group_idx"] ',
      CoreCssClasses.DropDown.loc_fa_dropdown_lg
    ),
  ],
  OPERATIVE: ['Operative', '#Operative_link'],
  SEARCH_WORKLISK: ['Search Worklist', '#worklist_filter_string'],
  SELECT_WORKLIST: [
    'Select Worklist',
    '[id*="checklistScrollTarget"] [id*="addworklist"]',
  ],
  DELETE_WORKLIST_ITEM: ['Delete Worklist Item', '[class*="delete-icon"]'],
  DELETE_WORKLIST_ITEM_YES: ['Yes', '[data-test-id*="yes"]'],
  ADD_WORKLIST_ITEM: [
    'Plus Icon',
    '[class*="worklist-configurable-item"] [class*="plus"]',
  ],
  SEARCH_WORKLIST_ITEM: [
    'Search Worklist Item',
    '[id*="worklist_item_search_field"]',
  ],
  SELECT_WORKLIST_ITEM: [
    'Select Worklist Item',
    '[class*="worklist-configurable-list-item"]',
  ],
};
