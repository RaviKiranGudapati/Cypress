export const OR_REPORTS = {
  REPORTS: {
    SEARCH: ['Search', '.search-field'],
    AUDIT_TRAIL: ['Audit Trail'],
  },
  AUDIT_TRAIL: {
    IFRAME: ['iframe', '#reportViewer'],
    AREA: ['Area', '#RsReportViewer_ctl08_ctl17'],
    AREA_ANESTHESIA_DROPDOWNVAL: [
      'Anesthesia',
      '#RsReportViewer_ctl08_ctl17_divDropDown_ctl03',
    ],
    MRN: ['MRN', '#RsReportViewer_ctl08_ctl19_txtValue'],
    VIEW_REPORT: ['View Report', '#RsReportViewer_ctl08_ctl00'],
  },
};
