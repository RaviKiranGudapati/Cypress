/* enum values */
export enum AppointmentRequestTabs {
    procedure_details = 'Procedure Details',
    patient_details = 'Patient Details',
    attachment = 'Attachments',
  }
  
  export enum InfoText {
    show_all = 'Show All',
    select_time_slot = 'Select Time slot and enter appointment details',
    add_procedure = 'Add Procedure',
    referring_physician = 'Referring Physician',
  }
  
  export enum PanelOptions {
    surgery_scheduling = 'Surgery Scheduling',
    appointment_history = 'Appointment History',
    case_coordination = 'Case Coordination',
  }