import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_PPE_CASE_CREATION = {
  ROOM_TIME_SLOT: ['Room Time Slot'],
  DROP_DOWN_ITEM: [
    '',
    CommonUtils.concatenate(
      CoreCssClasses.ClassPrefix.loc_ui,
      '-dropdown-items'
    ),
  ],
  SURGERY_SCHEDULING_TRACKER: ['Surgery Scheduling Tracker', '.sidebar-list a'],
  APPOINTMENT_FIELDS: ['', 'app-appointment-date h5'],
  PATIENT_DETAILS_FIELDS: ['', '.left-section .field-title'],
  PATIENT_ADDRESS_DETAILS_FIELDS: ['', '.right-section .field-title'],
  PROCEDURE_FIELDS: ['', '.procedure-list-header div'],
  ADD_PROCEDURE_TEXT: ['Add Procedure', '.procedure-list .add-button span'],
  CASE_STATUS_CHECKBOX: ['Status Checkbox', '.checkbox-container label'],
  SHOW_ALL_TEXT: [
    'Show all',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_p_dropdown_tag,
      ' label ',
      CommonGetLocators.div
    ),
  ],
  PRINT_ICON: ['Print', '#iconPrint'],
  APPOINTMENT_REQUEST: {
    APPOINTMENT_REQUEST_TABS: [
      'Scheduling Tracker',
      CommonUtils.concatenate(
        '.tabview ',
        CommonGetLocators.li,
        ' ',
        CommonGetLocators.span
      ),
    ],
    PROCEDURE_DETAILS: {
      APPOINTMENT: {
        DATE: ['Date', '#CreateCase1'],
      },
      PROCEDURES: {
        BODY_SIDE: ['Body Side', '.procedure-list .body-side'],
        BODY_SIDE_DROPDOWN_VALUE: [
          'Body Side',
          CommonUtils.concatenate(
            '.body-side ',
            CoreCssClasses.DropDown.loc_pi_caret_dropdown
          ),
        ],
        CPT_CODE_AND_DESCRIPTION: {
          INPUT_BOX: [
            'CPT® Code and Description',
            `input[placeholder="Search Procedure"]`,
          ],
          CODE: ['Code', '.code'],
          DESCRIPTION: ['Description', '.description'],
        },
        SURGEON: [
          'Surgeon',
          CommonUtils.concatenate(
            '.code-description ',
            CoreCssClasses.DropDown.loc_pi_caret_dropdown
          ),
        ],
        PROCEDURE_SEARCH_VALUES: [
          'Procedure Search Results',
          CommonUtils.concatenate(
            'li[class*=',
            CoreCssClasses.List.loc_autocomplete_list_item,
            ']'
          ),
        ],
        PRE_OP_DIAGNOSIS_CODE_FIELD: [
          'Pre-op Diagnosis Code',
          CommonUtils.concatenate(
            '.diagnosis ',
            CommonGetLocators.li,
            ' ',
            CommonGetLocators.input
          ),
        ],
        PRE_OP_DIAGNOSIS_CODE_VALUE: [
          'Pre-op Diagnosis Code',
          CommonUtils.concatenate(
            CoreCssClasses.ClassPrefix.loc_ui,
            '-autocomplete-list ',
            CoreCssClasses.ClassPrefix.loc_ui,
            '-autocomplete-list-item'
          ),
        ],
        DROPDOWN_VALUES: [
          'Dropdown Values',
          CoreCssClasses.DropDown.loc_ui_dropdown_item,
        ],
        ANESTHESIA_TYPE: [
          'Anesthesia Type',
          CommonUtils.concatenate(
            '.procedure-details app-appointment-dropdown ',
            CoreCssClasses.DropDown.loc_pi_caret_dropdown
          ),
        ],
        REFERRING_PHYSICIAN_DROPDOWN: [
          'Referring Physician',
          CommonUtils.concatenate(
            '.referring-physician ',
            CoreCssClasses.DropDown.loc_pi_caret_dropdown
          ),
        ],
        PRE_OP_DIAGNOSIS_LABEL: [
          'Pre-op Diagnosis Code',
          '.procedure-list .diagnosis-code',
        ],
      },
      COPY_RIGHT: ['CopyRight', '.copyright'],
      PROCEDURE_CODE: [
        'Procedure Code',
        CommonUtils.concatenate('.code ', CommonGetLocators.span),
      ],
      EQUIPMENT: [
        'Equipment',
        '.procedure-details .procedure-details-item-equipment',
      ],
      CASE_NOTES: ['Case Notes', '.appointment-notes .appointment-notes-area'],
      CASE_NOTES_LABEL: [
        'Case Notes',
        '.appointment-notes .appointment-notes-label',
      ],
    },
    PATIENT_DETAILS: {
      FIRST_NAME: [
        'First Name',
        CommonUtils.concatenate('input', CoreCssClasses.Input.loc_first_name),
      ],
      LAST_NAME: ['Last Name', 'input[name="lastName"]'],
      DOB: ['DOB', '.left-section input[placeholder="mm/dd/yyyy"]'],
      ZIP_CODE: ['Zip Code', '[data-test-id="zipcode-inputmask"] input'],
      INPUT_TEXT: ['Input Text', `[type='text']`],
      CITY: ['City', '[data-test-id="city-input"]'],
      COUNTY: ['County', '[data-test-id="county-input"]'],
      COUNTY_LABEL: ['County label', '.field-county'],
      COUNTY_ASTERISK: ['Asterisk', '.field-county .warning-asterisk'],
      STATE: ['State', `[data-test-id="state-dropdown"] label`],
      PRIMARY_GUARANTOR: ['Primary Guarantor', '.guarantor .input-mask'],
      GUARANTOR_FIELDS_LABEL: ['', '.section-wrapper.guarantor .field-title'],
      ADDRESS1: ['Address1', '#address1-input'],
      ADDRESS2: ['Address2', '#address2-input'],
      MARITAL_STATUS_LABEL: ['Marital Status', '.material-status .field-title'],
      GENDER_IDENTITY: [
        'Gender Identity',
        CommonUtils.concatenate(
          '.patient-demographics-section .gender-identity ',
          CoreCssClasses.ClassPrefix.loc_ui,
          '-corner-right'
        ),
      ],
      MARITAL_STATUS: [
        'Marital Status',
        CommonUtils.concatenate(
          '.patient-demographics-section #marital-status-dropdown ',
          CoreCssClasses.ClassPrefix.loc_ui,
          '-corner-right'
        ),
      ],
      SSN: ['SSN', '#ssn-inputmask'],
      PRIMARY_PHONE: ['Primary Phone', '#primary-inputmask'],
      MOBILE_PHONE: ['Mobile Phone', '#mobile-inputmask'],
      EMAIL: ['Email', '#email-input'],
      PRIMARY_INSURANCE: {
        INSURANCE_FIELDS_LABEL: ['', '.section-wrapper.insurance .field-title'],
        INSURANCE_NAME: [
          'Insurance Name',
          `.section-wrapper.insurance input[class*='field-full-width ng-untouched']`,
        ],
        INSURANCE_LAST_NAME: [
          'Insurance Last Name',
          `.section-wrapper.insurance .last-name input[class*='ng-untouched']`,
        ],
        INSURANCE_FIRST_NAME: [
          'Insurance First Name',
          `.section-wrapper.insurance .field-group input[class*='field-name-blue ng-untouched']`,
        ],
        INSURANCE_ID: [
          'ID',
          `.section-wrapper.insurance input[class*='field-id ng-untouched']`,
        ],
        INSURANCE_GROUP_NAME: [
          'Group Name',
          `.section-wrapper.insurance .group input[class*='ng-untouched'][maxlength='50']`,
        ],
        INSURANCE_GROUP_NUMBER: [
          'Group Number',
          `.section-wrapper.insurance .group input[class*='ng-untouched'][maxlength='15']`,
        ],
        INSURANCE_PHONE: [
          'Phone',
          CommonUtils.concatenate(
            '.section-wrapper.insurance ',
            CoreCssClasses.Ng.loc_untouched,
            ` input[class*='ui-inputtext']`
          ),
        ],
        RELATIONSHIP_TO_SUBSCRIBER_ICON: [
          'Relationship To Subscriber',
          CommonUtils.concatenate(
            '.section-wrapper.insurance .relationship ',
            CoreCssClasses.ClassPrefix.loc_ui,
            '-corner-right'
          ),
        ],
        SELF_PAY: [
          'Self-Pay',
          '.section-wrapper.insurance label[for="self-pay-checkbox"]',
        ],
      },
      PRIMARY_GUARANTOR_DETAIL: {
        FIRST_NAME: [
          'First Name',
          `div[class="section-wrapper guarantor"] .field-title:contains('First Name')~input`,
        ],
        LAST_NAME: [
          'Last Name',
          `div[class="section-wrapper guarantor"] .last-name .field-name`,
        ],
        DOB: [
          'DOB',
          `div[class="section-wrapper guarantor"]  [mask='99/99/9999'] input`,
        ],
        PHONE: [
          'Phone',
          `div[class="section-wrapper guarantor"] [mask='999-999-9999'] input`,
        ],
        RELATIONSHIP_TO_PATIENT: [
          'Relationship to Patient',
          `div[class="section-wrapper guarantor"] .field-title:contains('Relationship to Patient')~input`,
        ],
        ADDRESS1: [
          'Address1',
          `div[class="section-wrapper guarantor"] .field-title:contains('Address 1')~input`,
        ],
        ADDRESS2: [
          'Address2',
          `div[class="section-wrapper guarantor"] .field-title:contains('Address 2')~input`,
        ],
        CITY: [
          'City',
          `div[class="section-wrapper guarantor"] .field-title:contains('City')~input`,
        ],
        STATE: [
          'STATE',
          `div[class="section-wrapper guarantor"] [class*=' ui-dropdown ui-widget ui-state-default']`,
        ],
        ZIP_CODE: [
          'Zip Code',
          'div[class="section-wrapper guarantor"] .field-group p-inputmask[mask="99999?-9999"]',
        ],
      },
    },
  },
  CLOSE_ICON: ['Close Icon', '.cancel-btn'],
  MISSING_INFO_POPUP: ['Missing Information', 'div[class*="info-message"]'],
  ATTACHMENT: {
    ADD_ATTACHMENT_BUTTON: [
      'Add attachment',
      '.attachment-wrapper div[class="add-button"]',
    ],
    ATTACHMENT_TYPE_LABEL: ['All Attachment Types'],
    BROWSE: [
      'Browse',
      CommonUtils.concatenate(
        CoreCssClasses.FileUpload.loc_p_file_upload,
        '[chooselabel="Browse"] input[type="file"]'
      ),
    ],
    FILTER_BY: ['Filter By', `.filter-dropdown label`],
    DONE_BUTTON: ['Done', '.done-button'],
  },
};
