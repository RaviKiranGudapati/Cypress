import {
  Application,
  DoneOrCancel,
  InvokeAttributes,
  InvokeMethods,
  NextOrPrevious,
  ShouldMethods,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import {
  AppointmentRequest,
  Attachments,
  PatientDetails,
  PrimaryGuarantor,
  PrimaryInsurance,
  Procedure,
  ProcedureDetails,
} from '../../../test-data-models/sis-exchange/appointment-request/appointment-request.model';

import { OR_PPE_CASE_CREATION } from './or/appointment-request.or';

import { InfoText, PanelOptions, AppointmentRequestTabs } from './enums/appointment-request.enum';
import { appointmentRequestTabs } from './constants/appointment-request.const';

import PpeAppointmentRequestApi from './api/appointment-request.api';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

/* const values */
const color = require('onecolor');

export default class PpeAppointmentRequest {
  private ppeAppointmentRequestApi = new PpeAppointmentRequestApi();
  private sisOfficeDesktop = new SISOfficeDesktop();

  /**
   * @details To click on the time slot in schedule grid
   * @param time
   * @param roomIndex
   * @API - API's are available - Implemented Completely
   * @author- chandrika
   */
  selectTimeSlot(time: string, roomIndex: number) {
    const interceptCollection =
      this.ppeAppointmentRequestApi.interceptSelectTimeSlotApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.ppeTimeSlot(time, roomIndex),
      OR_PPE_CASE_CREATION.ROOM_TIME_SLOT[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details select the surgeon value based on the physician
   * @param physician - To provide the physician name value from Surgeon field.
   * @API - API's are not available
   */
  selectSurgeon(physician: string) {
    cy.cClick(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .SURGEON[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .SURGEON[0]
    );
    cy.cGet(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .DROPDOWN_VALUES[1]
    )
      .contains(physician)
      .click();
  }

  /**
   * @details Enter the procedure details in appointment request popup
   * @param procedure - To provide the CPT code, surgeon data as a parameter based on the model
   * @API - API's are available -  Implemented Completely
   * @author - chandrika
   */
  enterProcedureDetails(procedure: Procedure) {
    const interceptCollection =
      this.ppeAppointmentRequestApi.interceptProcedureApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .CPT_CODE_AND_DESCRIPTION.INPUT_BOX[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .CPT_CODE_AND_DESCRIPTION.INPUT_BOX[0],
      procedure.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
    cy.cSelectListItem(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .CPT_CODE_AND_DESCRIPTION.CODE[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .CPT_CODE_AND_DESCRIPTION.CODE[0],
      procedure.CPTCodeAndDescription
    );
    this.selectSurgeon(procedure.Surgeon!);
  }

  /**
   * @details click on the footer button in appointment request popup
   * @param buttonName - TO provide the button names in appointment request popup
   * @API - API's are available - Implemented Completely
   * This method can be used for previous and next buttons where no apis are loading
   * Where as in procedure details next button and attachments previous button apis will be loaded refer to
   * clickNextButtonInProcedureDetails(),clickPreviousButtonInAttachments
   * @author - chandrika
   */
  clickFooterButtons(buttonName: string) {
    cy.cClick(selectorFactory.getSpanText(buttonName), buttonName);
  }

  /***
   * @details enter the patient details of First Name,Last Name and DOB
   * @param patient - To provide the case details like first name,last name, DOB
   * @API - API's are available - Implemented Completely
   * @author - chandrika
   */
  enterPatientDetails(patient: PatientDetails) {
    // Removing the API implemented after entering DOB for patient details because it was not working
    cy.cType(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.FIRST_NAME[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.FIRST_NAME[0],
      patient.FirstName
    );
    cy.cType(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.LAST_NAME[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.LAST_NAME[0],
      patient.LastName
    );
    cy.cType(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.DOB[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.DOB[0],
      patient.DOB
    );
    cy.cClick(selectorFactory.getSpanText(patient.Sex!), patient.Sex!);
  }

  /**
   * @details To verify the copy right text in Procedure details page.
   * @param copyRightValue - To provide the copy right text message as a parameter.
   * @API - API's are not available
   */
  verifyCopyRightText(copyRightValue: string) {
    cy.cGet(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.COPY_RIGHT[1]
    ).each(($copyRightText) => {
      expect($copyRightText.text()).to.contains(copyRightValue);
    });
  }

  /**
   * @details To verify the search results of procedure items in Procedure Details section
   * @API - API's are not available
   */
  verifyProcedureCodeSearchResults() {
    cy.cGet(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .PROCEDURE_SEARCH_VALUES[1]
    ).then(($searchVal) => {
      if (
        $searchVal.text().includes(AppErrorMessages.procedure_no_results_found)
      ) {
        expect($searchVal.text()).to.equal(
          AppErrorMessages.procedure_no_results_found
        );
        cy.cClick(
          OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
            .PROCEDURE_SEARCH_VALUES[1],
          AppErrorMessages.procedure_no_results_found
        );
      } else {
        cy.cClick(
          OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
            .PROCEDURE_CODE[1],
          OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
            .PROCEDURE_CODE[0],
          false,
          true
        );
      }
    });
  }

  /**
   * @details To verify the CDT Code in Procedure Details
   * @param procedure - To provide the CPT code info using Procedure model
   * @API - API's are not available
   */
  verifyCDTCodeInProcedureDetails(procedure: Procedure) {
    cy.cType(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .CPT_CODE_AND_DESCRIPTION.INPUT_BOX[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .CPT_CODE_AND_DESCRIPTION.INPUT_BOX[0],
      procedure.CPTCodeAndDescription
    );
    this.verifyProcedureCodeSearchResults();
    // In the recent change 271 build we have raised the bug 281334 for the commented code and PO and if we close icon yes popup is not displayed, it is a invalid flow
  }

  /**
   * @details To verify room name as displayed in the scheduling page
   * @param roomName - To provide the room details.
   * @API - API's are not available
   */
  verifyRoomInSchedulingDesktop(roomName: string) {
    cy.cIsVisible(selectorFactory.getThText(roomName), roomName);
  }

  /**
   * @details - To verify the missing information popup in patient details.
   * @param buttonName - To click OK in information popup
   * @API - API's are not available
   * @author Suneetha
   */
  verifyMissingInformationPopupInPatientDetails(buttonName: string) {
    cy.cIncludeText(
      OR_PPE_CASE_CREATION.MISSING_INFO_POPUP[1],
      OR_PPE_CASE_CREATION.MISSING_INFO_POPUP[0],
      AppErrorMessages.ppe_missing_information_patient_details
    );
    cy.cClick(
      selectorFactory.getButtonText(buttonName),
      buttonName,
      false,
      true
    );
  }

  /***
   * @details To verify county field in patient details
   * @API - API's are not available
   * @author Suneetha
   */
  verifyCountyMandatoryFieldInPatientDetails() {
    cy.cIsVisible(
      CommonUtils.concatenate(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .COUNTY_LABEL[1],
        ' ',
        selectorFactory.getDivText(
          OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.COUNTY[0]
        )
      ),
      ''
    );
    cy.cIsVisible(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .COUNTY_ASTERISK[1],
      ' '
    );
  }

  /***
   * @details enter the patient details of First Name,Last Name and DOB
   * @param PatientDetails -used zip code from model to enter in guarantor field
   * @param isPrimGuar - if primary guarantor set flag true if not false.
   * @API - API's are not available
   * @author Suneetha
   */
  enterZipCodeInPrimaryGuarantor(
    patient: PatientDetails,
    isPrimGuar: boolean = true
  ) {
    if (isPrimGuar) {
      cy.cGet(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR[1]
      )
        .find(
          selectorFactory.getDivText(
            OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ZIP_CODE[0]
          )
        )
        .scrollIntoView()
        .parent()
        .within(() => {
          cy.cType(
            OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
              .INPUT_TEXT[1],
            '',
            patient.ZipCode
          );
        });
    }
  }

  /***
   * @details select patient in surgery scheduling
   * @param name -to click on patient based on name
   * @API - API's are available - Implemented
   * @author Suneetha
   */
  selectPatientInSurgeryScheduling(name: string) {
    const interceptCollection =
      this.ppeAppointmentRequestApi.interceptSelectPatientInSurgerySchedulingApi();
    cy.cIntercept(interceptCollection);
    cy.cGet(selectorFactory.getTitleText(name)).scrollIntoView().click();
    cy.cWaitApis(interceptCollection);
  }

  /***
   * @details enter the patient details of zip code
   * @param PatientDetails -used zip code from model to enter in patient details
   * @API - API's are available - Implemented
   * @author Suneetha
   */
  enterZipCodeInPatientDetails(patient: PatientDetails) {
    if (patient.ZipCode) {
      const interceptCollection =
        this.ppeAppointmentRequestApi.interceptZipCodeApi();
      cy.cIntercept(interceptCollection);
      cy.cGet(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ZIP_CODE[1]
      )
        .click()
        .clear()
        .type(patient.ZipCode!);
      cy.cWaitApis(interceptCollection);
      this.verifyCityCountyStateInPatientDetails(patient);
    }
  }

  /***
   * @details verify City, county, state patient details
   * @param PatientDetails -used city, county, state from model to enter in patient details
   * @API - API's are not available
   * @author Suneetha
   */
  verifyCityCountyStateInPatientDetails(patient: PatientDetails) {
    cy.cHasValue(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.CITY[1],
      '',
      patient.City
    );
    cy.cHasValue(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.COUNTY[1],
      '',
      patient.County
    );
    cy.cIsVisible(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.STATE[1],
      ' '
    ).should(ShouldMethods.text, patient.State);
  }

  /**
   * @details - To click done button in appointment request popup
   * @param buttonName - To provide the button name as a parameter with intercepts
   * @API - API's are available - Implemented Completely
   * @author - chandrika
   */
  clickDoneButton(buttonName: string) {
    const interceptCollection =
      this.ppeAppointmentRequestApi.interceptDoneButtonApi();
    cy.cIntercept(interceptCollection);
    this.clickFooterButtons(buttonName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To click next button in procedure details in appointment request popup
   * @param buttonName - To provide the button name as a parameter with intercepts
   * @API - API's are available - Implemented Completely
   * @author - chandrika
   */
  clickNextButtonInProcedureDetails(buttonName: string) {
    const interceptCollection =
      this.ppeAppointmentRequestApi.interceptNextAndPreviousButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(buttonName), buttonName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To click next button in Patient details in appointment request popup
   * @param buttonName -Name of the button should be passed
   * @API - API's are not available
   * @author - Praveen
   */
  clickNextButtonInPatientDetails(buttonName: string) {
    cy.cClick(selectorFactory.getSpanText(buttonName), buttonName);
  }

  /**
   * @details - To click previous button in attachments in appointment request popup
   * @param - buttonName - To provide the button name as a parameter with intercepts
   * @API - API's are available - Implemented Completely
   * @author - chandrika
   */
  clickPreviousButtonInAttachments(buttonName: string) {
    const interceptCollection =
      this.ppeAppointmentRequestApi.interceptNextAndPreviousButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(buttonName), buttonName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify tracker name in scheduling desktop
   * @param trackerName - To provide the tracker names like Surgery Scheduling, Appointment History..etc., as arguments in the function
   * @API - API's are not available
   * @author - Praveen
   */
  verifySchedulingTracker(trackerName: string[]) {
    cy.cGet(OR_PPE_CASE_CREATION.SURGERY_SCHEDULING_TRACKER[1]).each(
      ($vals, index) => {
        expect($vals.text()).to.contain(trackerName[index]);
      }
    );
  }

  /**
   * @details - To verify print icon in scheduling desktop
   * @API - API's are not available
   * @author - Praveen
   */
  verifyPrintIconInScheduling() {
    cy.cIsVisible(
      OR_PPE_CASE_CREATION.PRINT_ICON[1],
      OR_PPE_CASE_CREATION.PRINT_ICON[0]
    );
  }

  /**
   * @details To verify the checkbox label names in surgery scheduling desktop
   * @param checkboxLabels - To pass the check box names like booked, pending,block,charges,denied as arguments in scheduling desktop
   * @API - API's are not available
   * @author - Praveen
   */
  verifyCaseStatusCheckbox(checkboxLabels: string[]) {
    cy.cGet(OR_PPE_CASE_CREATION.CASE_STATUS_CHECKBOX[1]).each(
      ($rows, index) => {
        cy.wrap($rows)
          .invoke(InvokeMethods.attribute, InvokeAttributes.for)
          .then(($val) => {
            expect($val).to.contains(checkboxLabels[index]);
          });
      }
    );
  }

  /**
   * @details To verify showAll Text in surgery scheduling desktop
   * @param text - To pass the check box names like booked, pending,block,charges,denied as arguments in scheduling desktop
   * @API - API's are not available
   * @author - Praveen
   */
  verifyShowAllText(text: string) {
    cy.cGet(OR_PPE_CASE_CREATION.SHOW_ALL_TEXT[1])
      .invoke(InvokeMethods.attribute, InvokeAttributes.title)
      .then(($value) => {
        expect($value).to.contain(text);
      });
  }

  /**
   * @details To verify the appointment request related tabs in Appointment Request header popup.
   * @param tabNames - To specify the tab names in appointment request popup.
   * @API - API's are not available.
   * @author - Praveen
   */
  verifyAppointmentRequestTabs(tabNames: string[]) {
    cy.cGet(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.APPOINTMENT_REQUEST_TABS[1]
    ).each(($vals, index) => {
      expect($vals.text()).to.contain(tabNames[index]);
    });
  }

  /**
   * @details To verify the Appointment section fields in Procedure Details tab in Appointment Request
   * @param values - To pass the field names in Appointment section
   * @API - API's are not available.
   * @author - Praveen
   */
  verifyAppointmentSectionFields(values: string[]) {
    cy.cGet(OR_PPE_CASE_CREATION.APPOINTMENT_FIELDS[1]).each(
      ($fieldValues, index) => {
        expect($fieldValues.text()).to.contain(values[index]);
      }
    );
  }

  /**
   * @details To verify the Patient Details section fields in Patient Details tab in Appointment Request
   * @param values - To pass the field names in Patient details section
   * @API - API's are not available.
   * @author - Arushi
   */
  verifyPatientDetailsSectionFields(values: string[]) {
    cy.cGet(OR_PPE_CASE_CREATION.PATIENT_DETAILS_FIELDS[1]).each(
      ($fieldValues, index) => {
        expect($fieldValues.text()).to.contain(values[index]);
      }
    );
  }

  /**
   * @details To verify the Patient Address section fields in Patient Details tab in Appointment Request
   * @param values - To pass the field names in Patient Address section
   * @API - API's are not available.
   * @author - Arushi
   */
  verifyPatientAddressDetailsSectionFields(values: string[]) {
    cy.cGet(OR_PPE_CASE_CREATION.PATIENT_ADDRESS_DETAILS_FIELDS[1]).each(
      ($fieldValues, index) => {
        expect($fieldValues.text()).to.contain(values[index]);
      }
    );
  }

  /**
   * @details To verify the Procedure section fields in Procedure Details tab in Appointment Request
   * @param values - To pass the field names in Procedure section
   * @API - API's are not available.
   * @author - Arushi
   */
  verifyProcedureSectionFields(values: string[]) {
    cy.cGet(OR_PPE_CASE_CREATION.PROCEDURE_FIELDS[1]).each(
      ($fieldValues, index) => {
        expect($fieldValues.text()).to.contain(values[index]);
      }
    );
  }

  /**
   * @details To select the referring physician value from dropdown in procedure details tab.
   * @param procedureDetails - procedureDetails as model reference, To select the referring physician value from dropdown
   * @Api - API's are not available
   * @author - Praveen
   */
  selectReferringPhysician(procedureDetails: ProcedureDetails) {
    if (procedureDetails.ReferringPhysician) {
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .REFERRING_PHYSICIAN_DROPDOWN[1],
        procedureDetails.ReferringPhysician ?? ''
      );
      cy.cGet(
        CommonUtils.concatenate(OR_PPE_CASE_CREATION.DROP_DOWN_ITEM[1], '')
      ).within(() => {
        cy.cClick(
          selectorFactory.getSpanText(
            procedureDetails.ReferringPhysician ?? ''
          ),
          procedureDetails.ReferringPhysician ?? ''
        );
      });
      cy.cClick(
        selectorFactory.getH5Text(InfoText.referring_physician),
        procedureDetails.ReferringPhysician ?? ''
      );
    }
  }

  /**
   * @details To select the body side option from dropdown in procedure details tab.
   * @param procedure - procedure as model reference and to select the body side option from dropdown field.
   * @Api - API's are not available
   * @author - Praveen
   */
  selectBodySide(procedure: Procedure) {
    if (procedure.BodySide) {
      cy.cGet(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .BODY_SIDE[1]
      )
        .first()
        .click();
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .BODY_SIDE_DROPDOWN_VALUE[1],
        procedure.BodySide ?? ''
      );
      cy.cClick(
        selectorFactory.getSpanText(procedure.BodySide ?? ''),
        procedure.BodySide ?? ''
      );
      cy.cGet(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .BODY_SIDE[1]
      )
        .first()
        .click();
    }
  }

  /**
   * @details Searching and selecting pre-op diagnosis code in procedure details tab
   * @param procedure - procedure as model reference, enter the diagnosis code and select the diagnosis value from search list.
   * @Api - API's are available-Implemented completely
   * @author - Arushi
   */
  selectPreOpDiagnosisCode(procedure: Procedure) {
    if (procedure.PreOpDiagnosisCode) {
      const interceptCollection =
        this.ppeAppointmentRequestApi.interceptPreOpDiagnosisCodeSearch();
      cy.cIntercept(interceptCollection);
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .PRE_OP_DIAGNOSIS_CODE_FIELD[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .PRE_OP_DIAGNOSIS_CODE_FIELD[0],
        procedure.PreOpDiagnosisCode
      );
      cy.cWaitApis(interceptCollection);
      cy.cRemoveMaskWrapper(Application.office);
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .PRE_OP_DIAGNOSIS_CODE_VALUE[1],
        procedure.PreOpDiagnosisCode ?? '',
        false,
        true
      );
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .PRE_OP_DIAGNOSIS_LABEL[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
          .PRE_OP_DIAGNOSIS_LABEL[0]
      );
    }
  }

  /**
   * @details Verifying added procedure text in procedure details tab
   * @param procedureText - To verify the procedure text in procedure details tab
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyAddProcedureText(procedureText: string) {
    cy.cGet(OR_PPE_CASE_CREATION.ADD_PROCEDURE_TEXT[1]).then(($val) => {
      expect($val.text()).to.contain(procedureText);
    });
  }

  /**
   * @details To select the value from Anesthesia Type dropdown
   * @param procedure - procedure as model reference to pass as argument in function, based on that user select the anesthesia type value from dropdown.
   * @Api - API's are not available
   * @author - Praveen
   */
  selectAnesthesiaTypeValue(procedure: Procedure) {
    cy.cClick(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.PROCEDURES
        .ANESTHESIA_TYPE[1],
      procedure.AnesthesiaType ?? ''
    );
    cy.cGet(
      CommonUtils.concatenate(OR_PPE_CASE_CREATION.DROP_DOWN_ITEM[1], '')
    ).within(() => {
      cy.cClick(
        selectorFactory.getSpanText(procedure.AnesthesiaType ?? ''),
        procedure.AnesthesiaType ?? ''
      );
    });
  }

  /**
   * @details To enter the values of equipment details in procedure details tab
   * @param procedure - procedure as model reference to pass as argument in function, based on that user enter the equipment data.
   * @Api - API's are not available
   * @author - Praveen
   */
  enterEquipmentDetails(procedure: Procedure) {
    if (procedure.Equipment) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.EQUIPMENT[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.EQUIPMENT[0],
        procedure.Equipment ?? ''
      );
      cy.cClick(
        selectorFactory.getAnesthesiaTypeAndEquipmentLabel(
          OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
            .EQUIPMENT[0]
        ),
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.EQUIPMENT[0]
      );
    }
  }

  /**
   * @details Enter value of case notes in appointment request popup
   * @param procedure - procedure as model reference to pass as argument in function, based on that user enter the case notes.
   * @Api - API's are not available
   * @author - Praveen
   */
  enterCaseNotes(procedure: Procedure) {
    if (procedure.CaseNotes) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
          .CASE_NOTES[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
          .CASE_NOTES[0],
        procedure.CaseNotes
      );
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
          .CASE_NOTES_LABEL[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
          .CASE_NOTES_LABEL[0]
      );
    }
  }

  /**
   * @details Enter value of patient's address1 field in patient details tab
   * @param patient -patient as model reference to provide the address1 details
   * @Api - API's are not available
   * @author - Praveen
   */
  enterPatientAddress1(patient: PatientDetails) {
    if (patient.Address1) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS1[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS1[0],
        patient.Address1
      );
    }
  }

  /**
   * @details Enter value of patient's address2 fields in patient details tab
   * @param patient -patient as model reference to provide the address2 details
   * @Api - API's are not available
   * @author - Praveen
   */
  enterPatientAddress2(patient: PatientDetails) {
    if (patient.Address2) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS2[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS2[0],
        patient.Address2
      );
    }
  }

  /**
   * @details Enter value of case notes and equipments
   * @param option -field name should be passed(equipment/case notes)
   * @param value- value for the field should be passed in the fields
   * @Api - API's are not available
   * @author - Praveen
   */
  enterProcedureNotesAndEquipment(option: string, value: string) {
    const inputOptions: { [key: string]: string } = {
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.EQUIPMENT[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS.EQUIPMENT[1],
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
        .CASE_NOTES[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PROCEDURE_DETAILS
          .CASE_NOTES[1],
    };
    cy.cType(inputOptions[option], '', value);
  }

  /**
   * @details Enter value of patient's address fields
   * @param addressOption -field name should be passed(EX.Address1,Address2)
   * @param addressValue - that should be passed in the selected fields
   * @Api - API's are not available
   * @author - Praveen
   */
  enterAddressDetails(addressOptions: string, addressValue: string) {
    const inputOptions: { [key: string]: string } = {
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS1[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS1[1],
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS2[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.ADDRESS2[1],
    };
    cy.cType(inputOptions[addressOptions], '', addressValue);
  }

  /**
   * @details Selecting status values in patient details
   * @param option -field name needs to be passed(Ex:marital status,gender identity)
   * @param value- values to be passed in those fields.
   * @Api - API's are not available
   * @author - Praveen
   */
  selectCaseStatus(options: string, value: string) {
    const dropdownOptions: { [key: string]: string } = {
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .MARITAL_STATUS[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MARITAL_STATUS[1],
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .GENDER_IDENTITY[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .GENDER_IDENTITY[1],
    };
    cy.cClick(dropdownOptions[options], '');
    cy.cGet(OR_PPE_CASE_CREATION.DROP_DOWN_ITEM[1]).within(() => {
      cy.cClick(selectorFactory.getTitleValue(value), options);
    });
  }

  /**
   * @details Enter value of patient's address fields
   * @param patient -patient as model reference to select the value of Marital Status value from dropdown
   * @Api - API's are not available
   * @author - Praveen
   */
  selectPatientMaritalStatus(patient: PatientDetails) {
    if (patient.MaritalStatus) {
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MARITAL_STATUS[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MARITAL_STATUS[0]
      );

      cy.cGet(OR_PPE_CASE_CREATION.DROP_DOWN_ITEM[1]).within(() => {
        cy.cClick(
          selectorFactory.getTitleValue(patient.MaritalStatus ?? ''),
          OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
            .MARITAL_STATUS[0]
        );
      });
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MARITAL_STATUS_LABEL[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MARITAL_STATUS[0]
      );
    }
  }

  /**
   * @details Enter value of patient's address fields
   * @param patient -patient as model reference to provide the SSN number
   * @Api - API's are not available
   * @author - Praveen
   */
  enterPatientSSN(patient: PatientDetails) {
    if (patient.SSN) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.SSN[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.SSN[0],
        patient.SSN
      );
    }
  }

  /**
   * @details Enter value of patient's address fields
   * @param patient -patient as model reference to provide the primary phone number
   * @Api - API's are not available
   * @author - Praveen
   */
  enterPatientPrimaryPhone(patient: PatientDetails) {
    if (patient.PrimaryPhone) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_PHONE[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_PHONE[0],
        patient.PrimaryPhone
      );
    }
  }

  /**
   * @details Enter value of patient's address fields
   * @param patient -patient as model reference to provide the mobile phone number
   * @Api - API's are not available
   * @author - Praveen
   */
  enterPatientMobilePhone(patient: PatientDetails) {
    if (patient.MobilePhone) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MOBILE_PHONE[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MOBILE_PHONE[0],
        patient.MobilePhone
      );
    }
  }

  /**
   * @details Enter value of patient's address fields
   * @param patient -patient as model reference to provide the email address of the patient
   * @Api - API's are not available
   * @author - Praveen
   */
  enterPatientEmail(patient: PatientDetails) {
    if (patient.Email) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.EMAIL[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.EMAIL[0],
        patient.Email
      );
    }
  }

  /**
   * @details Enter value of patient's phone details fields
   * @param options -field name should be passed(EX.SSN,PrimaryPhone,MobilePhone,email )
   * @param value- that should be passed in the fields in the selected field
   * @Api - API's are not available
   * @author - Praveen
   */
  enterCasePhoneDetails(options: string, value: string) {
    const inputOptions: { [key: string]: string } = {
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.SSN[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.SSN[1],
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .PRIMARY_PHONE[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_PHONE[1],
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .MOBILE_PHONE[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .MOBILE_PHONE[1],
      [OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.EMAIL[0]]:
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.EMAIL[1],
    };
    cy.cType(inputOptions[options], '', value);
  }

  /**
   * @details Enter value of patient's primary insurance details fields
   * @param insuranceInfo - Primary insurance model field name should be passed(EX.InsuranceName,InsuranceFirstName etc)
   * @Api - API's are not available
   * @author - Praveen
   */
  enterPrimaryInsuranceDetails(insuranceInfo: PrimaryInsurance) {
    this.enterInsuranceName(insuranceInfo);
    this.enterInsuranceLastName(insuranceInfo);
    this.enterInsuranceFirstName(insuranceInfo);
    this.enterInsuranceId(insuranceInfo);
    this.enterInsuranceGroupName(insuranceInfo);
    this.enterInsuranceGroupNumber(insuranceInfo);
    this.enterInsurancePhone(insuranceInfo);
    this.selectRelationshipToSubscriberValue(insuranceInfo);
  }

  /**
   * @details Selecting the value of relationship to subscriber
   * @param insuranceInfo- To select the value from RelationShip To Subscriber dropdown based on model reference.
   * @Api - API's are not available
   * @author - Praveen
   */
  selectRelationshipToSubscriberValue(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.RelationshipToSubscriber) {
      cy.cClick(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.RELATIONSHIP_TO_SUBSCRIBER_ICON[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.RELATIONSHIP_TO_SUBSCRIBER_ICON[0]
      );
      cy.cGet(OR_PPE_CASE_CREATION.DROP_DOWN_ITEM[1]).within(() => {
        cy.cClick(
          selectorFactory.getTitleValue(
            insuranceInfo.RelationshipToSubscriber!
          ),
          OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
            .PRIMARY_INSURANCE.RELATIONSHIP_TO_SUBSCRIBER_ICON[0]
        );
      });
    }
  }

  /**
   * @details Verify the filterBy value in attachments
   * @param filterValue -field name needs to be passed(Ex.All Attachment Types etc)
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyFilterByValueInAttachments(filterValue: string) {
    cy.cGet(OR_PPE_CASE_CREATION.ATTACHMENT.FILTER_BY[1]).then(($value) => {
      expect($value.text()).to.contain(filterValue);
    });
  }

  /**
   * @details - To click next button in Patient details in appointment request popup
   * @param buttonName - To provide the name of the button like Next.
   * @API - API's are not available
   * @author - Praveen
   */
  clickNextOrPreviousButton(buttonName: NextOrPrevious) {
    cy.cClick(selectorFactory.getSpanText(buttonName), buttonName);
  }

  /**
   * @details Enter value of patient's primary insurance details fields
   * @param attachments -filePath needs to be passed where the attachment is present in fixtures based on model reference
   * @Api - API's are available-Implemented completely
   * @author - Arushi
   */
  uploadAttachmentInAppointment(attachments: Attachments) {
    if (attachments) {
      this.verifyFilterByValueInAttachments(
        OR_PPE_CASE_CREATION.ATTACHMENT.ATTACHMENT_TYPE_LABEL[0]
      );
      const interceptCollection =
        this.ppeAppointmentRequestApi.interceptDoneButtonAddAttachment();
      cy.cClick(
        OR_PPE_CASE_CREATION.ATTACHMENT.ADD_ATTACHMENT_BUTTON[1],
        OR_PPE_CASE_CREATION.ATTACHMENT.ADD_ATTACHMENT_BUTTON[1]
      );
      this.sisOfficeDesktop.uploadAttachment(
        attachments.FilePath,
        OR_PPE_CASE_CREATION.ATTACHMENT.BROWSE[1]
      );
      cy.cIntercept(interceptCollection);
      cy.cClick(
        OR_PPE_CASE_CREATION.ATTACHMENT.DONE_BUTTON[1],
        OR_PPE_CASE_CREATION.ATTACHMENT.DONE_BUTTON[0]
      );
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details To verify the insurance fields in Patient Details tab in Appointment Request
   * @param values - To pass the field names in Insurance section
   * @API - API's are not available.
   * @author - Dharani
   */
  verifyInsuranceSectionFields(values: string[]) {
    cy.cGet(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.PRIMARY_INSURANCE
        .INSURANCE_FIELDS_LABEL[1]
    ).each(($fieldValues, index) => {
      expect($fieldValues.text()).to.contain(values[index]);
    });
  }

  /**
   * @details To verify the self-pay insurance field in Patient Details tab in Appointment Request
   * @API - API's are not available.
   * @author - Dharani
   */
  verifySelfPayFieldInInsurance() {
    cy.cGet(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS.PRIMARY_INSURANCE
        .SELF_PAY[1]
    ).then(($fieldValue) => {
      expect($fieldValue.text()).to.contain(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.SELF_PAY[0]
      );
    });
  }

  /**
   * @details To verify the guarantor fields in Patient Details tab in Appointment Request
   * @param values - To pass the field names in Guarantor section
   * @API - API's are not available.
   * @author - Dharani
   */
  verifyGuarantorSectionFields(values: string[]) {
    cy.cGet(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .GUARANTOR_FIELDS_LABEL[1]
    ).each(($fieldValues, index) => {
      expect($fieldValues.text()).to.contain(values[index]);
    });
  }

  /**
   * @details Enter value of patient's primary guarantor details fields
   * @param guarantorInfo - primary guarantor model field name should be passed(EX.LastName,FirstName etc)
   * @Api - API's are not available
   * @author - Arushi
   */
  enterPrimaryGuarantorDetails(guarantorInfo: PrimaryGuarantor) {
    this.enterGuarantorLastName(guarantorInfo);
    this.enterGuarantorFirstName(guarantorInfo);
    this.enterGuarantorDob(guarantorInfo);
    this.enterGuarantorRelationshipToPatient(guarantorInfo);
    this.enterGuarantorPhone(guarantorInfo);
    this.enterGuarantorAddress1(guarantorInfo);
    this.enterGuarantorAddress2(guarantorInfo);
  }

  /**
   * @details Enter value of state in guarantor details
   * @param state -value of state that should be selected
   * @Api - API's are not available
   * @author - Arushi
   */
  selectState(state: string) {
    cy.cSelectDropdown(
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .PRIMARY_GUARANTOR_DETAIL.STATE[1],
      OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
        .PRIMARY_GUARANTOR_DETAIL.STATE[0],
      state
    );
  }

  /**
   * @details To check the case status in scheduling desktop
   * @param caseName -To provide the case name based on the appointment type
   * @param bgColor - To provide the hex value based on case name for check the case status.
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyCaseStatus(caseName: string, bgColor: string) {
    cy.cGet(selectorFactory.getAText(caseName))
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .then((colorValue) => {
        expect(color(colorValue).hex()).to.contain(bgColor);
      });
  }

  /**
   * @details To select the side panel option in ppe environment
   * @param option - name of the option ex:scheduling desktop,appointment history etc
   * @Api - API's are available,Implemented Completely
   * @author - Arushi
   */
  selectSidePanelOptions(option: PanelOptions) {
    const panelOptionsMapping = {
      [PanelOptions.surgery_scheduling]: {
        interceptCollection:
          this.ppeAppointmentRequestApi.interceptSelectPatientInSurgerySchedulingApi(),
      },
      [PanelOptions.appointment_history]: {
        interceptCollection:
          this.ppeAppointmentRequestApi.interceptSelectAppointmentHistoryApi(),
      },
      [PanelOptions.case_coordination]: {
        interceptCollection:
          this.ppeAppointmentRequestApi.interceptSelectCaseCoordinationApi(),
      },
    };

    const mapping = panelOptionsMapping[option];

    if (mapping) {
      const interceptCollection = mapping.interceptCollection;

      cy.cIntercept(interceptCollection);
      cy.cClick(selectorFactory.selectSidePanelOptions(option), option);
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details To check the case status in appointment history as  per the patient name
   * @param patientName - full name of patient needs to be passed
   * @param status -case status needs to be passed ex:booked,pending etc
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyCaseStatusInAppointmentHistory(patientName: string, status: string) {
    cy.cGet(selectorFactory.getPpeCaseStatus(patientName, status))
      .scrollIntoView({ easing: 'linear' })
      .click()
      .should(ShouldMethods.visible);
  }

  /**
   * @details - To click done button in appointment request popup after updating request
   * @param - buttonName - button name needs to be passed like done
   * @API - API's are available - Implemented Completely
   * @author - Arushi
   */
  clickDoneButtonAfterUpdate(buttonName: string) {
    const interceptCollection =
      this.ppeAppointmentRequestApi.interceptDoneButtonApi();
    cy.cIntercept(interceptCollection);
    this.clickFooterButtons(buttonName);
  }

  /**
   * @details - select the tab where we want to navigate to in appointment request pop-up
   * @param tab - passed procedure details,patient details,attachment tabs to select
   * @API - API's are available - Implemented Completely
   * @author- Arushi
   */
  selectTabInAppointmentRequestPopup(tab: string) {
    let interceptCollection: ApiEndpoint[] = [];
    let loc: string = '';
    let locator: string = '';
    switch (tab) {
      case AppointmentRequestTabs.procedure_details:
        loc = appointmentRequestTabs[0];
        break;
      case AppointmentRequestTabs.patient_details:
        loc = appointmentRequestTabs[1];
        interceptCollection =
          this.ppeAppointmentRequestApi.interceptSelectPatientDetailsTabInAppointmentRequest();
        break;
      case AppointmentRequestTabs.attachment:
        loc = appointmentRequestTabs[2];
        break;
      default:
        break;
    }

    locator = selectorFactory.selectTabsInAppointmentRequestPopUp(loc);

    cy.cIntercept(interceptCollection);
    cy.cClick(locator, tab, false, true);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Enter value of procedure details in appointment request popup
   * @param procedureDetails - This is model reference and to select the referring physician value from dropdown.
   * @Api - API's are not available
   * @author - Praveen
   */
  enterAppointmentProcedureDetails(procedureDetails: ProcedureDetails) {
    this.enterProcedureDetails(procedureDetails.Procedures);
    this.selectBodySide(procedureDetails.Procedures);
    this.selectPreOpDiagnosisCode(procedureDetails.Procedures);
    this.enterEquipmentDetails(procedureDetails.Procedures);
    this.enterCaseNotes(procedureDetails.Procedures);
    this.selectReferringPhysician(procedureDetails);
    this.selectAnesthesiaTypeValue(procedureDetails.Procedures);
  }

  /**
   * @details Enter value of patient details in appointment request popup.
   * @param patient -patient as model reference to enter the patient details in appointment request popup
   * @Api - API's are not available
   * @author - Praveen
   */
  enterAppointmentPatientDetails(patient: PatientDetails) {
    this.enterPatientDetails(patient);
    this.enterPatientAddress1(patient);
    this.enterPatientAddress2(patient);
    this.enterZipCodeInPatientDetails(patient);
    this.enterPatientSSN(patient);
    this.enterPatientPrimaryPhone(patient);
    this.enterPatientMobilePhone(patient);
    this.selectPatientMaritalStatus(patient);
    this.enterPatientEmail(patient);

    if (patient.PrimaryInsurance)
      this.enterPrimaryInsuranceDetails(patient.PrimaryInsurance!);

    if (patient.PrimaryGuarantor)
      this.enterPrimaryGuarantorDetails(patient.PrimaryGuarantor!);
  }

  /**
   * @details - verify if attachment is present in appointment
   * @param fileName - name of the attachment should be passed
   * @API - API's are not  available
   * @author- Arushi
   */
  verifyAttachment(fileName: string) {
    cy.cIsVisible(selectorFactory.verifyAttachment(fileName), fileName);
  }

  /**
   * @details - enter insurance name
   * @param insuranceInfo- name of the insurance should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterInsuranceName(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.InsuranceName) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_NAME[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_NAME[0],
        insuranceInfo.InsuranceName
      );
    }
  }

  /**
   * @details - enter insurance first name
   * @param insuranceInfo- first name of insured should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterInsuranceFirstName(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.InsuredFirstName) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_FIRST_NAME[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_FIRST_NAME[0],
        insuranceInfo.InsuredFirstName
      );
    }
  }

  /**
   * @details - enter insurance last name
   * @param insuranceInfo- last name of the insured should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterInsuranceLastName(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.InsuredLastName) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_LAST_NAME[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_LAST_NAME[0],
        insuranceInfo.InsuredLastName
      );
    }
  }

  /**
   * @details - enter insurance ID
   * @param insuranceInfo- insurance IDof the insured should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterInsuranceId(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.ID) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_ID[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_ID[0],
        insuranceInfo.ID
      );
    }
  }

  /**
   * @details - enter insurance group name
   * @param insuranceInfo- groupName of the insured should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterInsuranceGroupName(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.GroupName) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_GROUP_NAME[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_GROUP_NAME[0],
        insuranceInfo.GroupName
      );
    }
  }

  /**
   * @details - enter insurance group number
   * @param insuranceInfo- insuranceInfo as model reference to pass group number
   * @API - API's are not  available
   * @author- Arushi
   */
  enterInsuranceGroupNumber(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.GroupNumber) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_GROUP_NUMBER[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_GROUP_NUMBER[0],
        insuranceInfo.GroupNumber
      );
    }
  }

  /**
   * @details - enter insurance phone number
   * @param insuranceInfo- insuranceInfo as model reference to pass  phone number
   * @API - API's are not  available
   * @author- Arushi
   */
  enterInsurancePhone(insuranceInfo: PrimaryInsurance) {
    if (insuranceInfo.Phone) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_PHONE[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_INSURANCE.INSURANCE_PHONE[0],
        insuranceInfo.Phone
      );
    }
  }

  /**
   * @details - enter guarantor last name
   * @param guarantorInfo-last name of the guarantor should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorLastName(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.LastName) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.LAST_NAME[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.LAST_NAME[0],
        guarantorInfo.LastName
      );
    }
  }

  /**
   * @details - enter guarantor first name
   * @param guarantorInfo- first name of the guarantor should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorFirstName(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.FirstName) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.FIRST_NAME[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.FIRST_NAME[0],
        guarantorInfo.FirstName
      );
    }
  }

  /**
   * @details - enter guarantor DOB
   * @param guarantorInfo- dob of the guarantor should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorDob(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.DOB) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.DOB[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.DOB[0],
        guarantorInfo.DOB
      );
    }
  }

  /**
   * @details - enter guarantor relationship to patient
   * @param guarantorInfo-guarantor's relationship to patient should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorRelationshipToPatient(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.RelationshipToPatient) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.RELATIONSHIP_TO_PATIENT[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.RELATIONSHIP_TO_PATIENT[0],
        guarantorInfo.RelationshipToPatient
      );
    }
  }

  /**
   * @details - enter guarantor phone
   * @param guarantorInfo-guarantor phone number value should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorPhone(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.Phone) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.PHONE[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.PHONE[0],
        guarantorInfo.Phone
      );
    }
  }

  /**
   * @details - enter guarantor address1
   * @param guarantorInfo- guarantor's address1 value should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorAddress1(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.Address1) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.ADDRESS1[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.ADDRESS1[0],
        guarantorInfo.Address1
      );
    }
  }

  /**
   * @details - enter guarantor address2
   * @param guarantorInfo-guarantor's address2 value should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorAddress2(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.Address2) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.ADDRESS2[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.ADDRESS2[0],
        guarantorInfo.Address2
      );
    }
  }

  /**
   * @details - enter guarantor city
   * @param guarantorInfo - guarantor's city value should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorCity(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.City) {
      cy.cGet(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.CITY[1]
      )
        .clear()
        .type(guarantorInfo.City!);
    }
  }

  /**
   * @details - enter guarantor state
   * @param guarantorInfo- guarantor's state value should be passed based on model reference.
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorState(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.State) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.STATE[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.STATE[0],
        guarantorInfo.State
      );
    }
  }

  /**
   * @details - enter guarantor zip code
   * @param guarantorInfo - guarantor's zip code value should be passed based on model reference
   * @API - API's are not  available
   * @author- Arushi
   */
  enterGuarantorZipCode(guarantorInfo: PrimaryGuarantor) {
    if (guarantorInfo.ZipCode) {
      cy.cType(
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.ZIP_CODE[1],
        OR_PPE_CASE_CREATION.APPOINTMENT_REQUEST.PATIENT_DETAILS
          .PRIMARY_GUARANTOR_DETAIL.ZIP_CODE[0],
        guarantorInfo.ZipCode
      );
    }
  }

  /**
   * @details - To verify the case status in appointment history page
   * @param option - To select the tracker based on the options
   * @param patientDetails - Patient Details as model reference as argument and specify the case last name
   * @param caseStatus - To provide the case status as an option
   * @API - API's are not  available
   * @author- Arushi
   */
  verifyAppointmentHistoryCaseStatus(
    option: PanelOptions,
    patientDetails: PatientDetails,
    caseStatus: string
  ) {
    this.selectSidePanelOptions(option);
    this.verifyCaseStatusInAppointmentHistory(
      patientDetails.LastName ?? '',
      caseStatus
    );
  }

  /**
   * @details - close appointment request pop-up after opening created request
   * @API - API's are not  available
   * @author- Arushi
   */
  closeAppointmentRequest() {
    cy.cClick(
      OR_PPE_CASE_CREATION.CLOSE_ICON[1],
      OR_PPE_CASE_CREATION.CLOSE_ICON[0]
    );
  }

  /**
   * @details - close appointment request pop-up while creating appointment request
   * @API - API's are not  available
   * @author- Arushi
   */
  closeAppointmentRequestDuringCreation() {
    this.closeAppointmentRequest();
    cy.cClick(selectorFactory.getSpanText(YesOrNo.yes), YesOrNo.yes);
  }

  /**
   * @details Verify procedure details fields,tabs and copyright values in procedure details tabs
   * @param tabNames - tabNames like procedure details,patient details etc
   * @param fieldValues- appointment fields date,requested start etc should be passed as array
   * @param procedureFields- field labels for entering procedure details like cpt,description should be passed as array
   * @param copyRightValue -value of copyright text should be passed
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyProcedureDetails(
    tabNames: string[],
    fieldValues: string[],
    procedureFields: string[],
    copyRightValue: string
  ) {
    this.verifyAppointmentRequestTabs(tabNames);
    this.verifyAppointmentSectionFields(fieldValues);
    this.verifyProcedureSectionFields(procedureFields);
    this.verifyCopyRightText(copyRightValue);
  }

  /**
   * @details Verify patient details fields like insurance,guarantor etc
   * @param patientDetailsFields - values of patient info fields should be passed as array
   * @param patientAddressDetailsFields- value of patient address fields should be passed as array
   * @param insuranceFields- values of insurance fields should be passed as array
   * @param guarantorFields -values of guarantor fields should be passed as array
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyPatientDetails(
    patientDetailsFields: string[],
    patientAddressDetailsFields: string[],
    insuranceFields: string[],
    guarantorFields: string[]
  ) {
    this.verifyPatientDetailsSectionFields(patientDetailsFields);
    this.verifyPatientAddressDetailsSectionFields(patientAddressDetailsFields);
    this.verifyInsuranceSectionFields(insuranceFields);
    this.verifyGuarantorSectionFields(guarantorFields);
    this.verifySelfPayFieldInInsurance();
  }

  /**
   * @details create appointment along with addition of attachment
   * @param appointmentRequest - values of appointment request model fields should be passed
   * @Api - API's are available,implemented completely
   * @author - Arushi
   */
  appointmentCreation(appointmentRequest: AppointmentRequest) {
    this.enterAppointmentProcedureDetails(appointmentRequest.ProcedureDetails);
    this.clickNextButtonInProcedureDetails(NextOrPrevious.Next);
    this.enterAppointmentPatientDetails(appointmentRequest.PatientDetails);
    this.clickNextButtonInPatientDetails(NextOrPrevious.Next);
    this.uploadAttachmentInAppointment(appointmentRequest.Attachments!);
    this.clickDoneButton(DoneOrCancel.done);
  }

  /**
   * @details To edit the denied case
   * @param patientDetails - To pass the argument as patient details model. Based on that will select the last name in scheduling desktop.
   * @param procedure - To pass the argument as procedure model. Based on that will select the surgeon value from dropdown.
   * @API - API's implement in unit functions
   * @author - Praveen
   */
  editDeniedCase(patientDetails: PatientDetails, procedure: Procedure) {
    this.selectSidePanelOptions(PanelOptions.surgery_scheduling);
    this.selectPatientInSurgeryScheduling(patientDetails.LastName);
    this.selectSurgeon(procedure.Surgeon);
    this.clickDoneButtonAfterUpdate(DoneOrCancel.done);
  }
}
