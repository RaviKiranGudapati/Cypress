export const OR_EXCHANGE_LOGIN = {
  LOGIN: {
    LOGIN_WEB_TITLE: ['SIS Exchange'],
    USER_NAME: ['User Name', `[name='username']`],
    PASSWORD: ['Password', `[name='password']`],
    LOGIN_BUTTON: ['Login', 'button.sis-login-form-submit'],
  },
  LOGIN_LOCATION: {
    LOGIN_LOCATION_WINDOW: ['Select Login Location'],
  },
  LOGO: ['Logo', '.logo-link'],
  APPLICATION_INFORMATION_LOGO: [
    'Application Information Logo',
    '[class="navbar-container"]',
  ],
  COPY_RIGHT_TEXT: ['Copy Right Text', '[class*="copyright"]'],
};
