import {
  Application,
  ShouldMethods,
} from '../../../support/common-core-libs/application/common-core';

import { ILocatorValue } from '../../../test-data-models/core/locator.model';

import { OR_EXCHANGE_LOGIN } from './or/login.or';

import Login from '../../shared/login/login';

/*  const values */
const copyrightText = [
  'Copyright 2016 - 2019 Amkai LLC. All Rights Reserved.',
  'CPT only © 2022 American Medical Association. All rights reserved.',
  'CPT® is a registered trademark of the American Medical Association.',
];

export default class sisExchangeLogin extends Login {
  constructor() {
    super(Application.sis_exchange);
  }

  /**
   * @details - To verify Sis logo
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifySisLogo() {
    cy.cIsVisible(OR_EXCHANGE_LOGIN.LOGO[1], OR_EXCHANGE_LOGIN.LOGO[0]);
  }

  /**
   * @details - To verify application information logo
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifyApplicationInformationLogo() {
    cy.cIsVisible(
      OR_EXCHANGE_LOGIN.APPLICATION_INFORMATION_LOGO[1],
      OR_EXCHANGE_LOGIN.APPLICATION_INFORMATION_LOGO[0]
    );
  }

  /**
   * @details - To verify username and password as blank
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifyUserNameAndPasswordAsBlank() {
    const userNameLoc: ILocatorValue = {
      locator: OR_EXCHANGE_LOGIN.LOGIN.USER_NAME[1],
    };
    const passwordLoc: ILocatorValue = {
      locator: OR_EXCHANGE_LOGIN.LOGIN.PASSWORD[1],
    };
    const locatorMap = [userNameLoc, passwordLoc];
    locatorMap.forEach((obj) => {
      cy.cHasValue(obj.locator, '', '');
    });
  }

  /**
   * @details - To verify Login button
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifyLoginButton() {
    cy.cIsVisible(
      OR_EXCHANGE_LOGIN.LOGIN.LOGIN_BUTTON[1],
      OR_EXCHANGE_LOGIN.LOGIN.LOGIN_BUTTON[0]
    );
  }

  /**
   * @details - To verify copy right messages
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifyCopyRightMessage() {
    copyrightText.forEach((val) => {
      cy.cIncludeText(
        OR_EXCHANGE_LOGIN.COPY_RIGHT_TEXT[1],
        OR_EXCHANGE_LOGIN.COPY_RIGHT_TEXT[0],
        val
      );
    });
  }

  /**
   * @details - To verify Sis exchange title
   * @APIs - Api's are not available
   * @author Madhu Kiran
   */
  verifySisExchangeTitle() {
    this.pageTitle.should(
      ShouldMethods.include,
      OR_EXCHANGE_LOGIN.LOGIN.LOGIN_WEB_TITLE[0]
    );
  }
}
