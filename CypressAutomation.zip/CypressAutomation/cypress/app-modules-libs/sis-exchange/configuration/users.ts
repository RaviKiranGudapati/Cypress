import {
  CommonTypeValues,
  InvokeMethods,
  ShouldMethods,
  TrueOrFalse,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import { UserDetails } from '../../../test-data-models/shared/enterprise-configuration/enterprise.model';

import { OR_USERS_CONFIGURATION } from './or/users.or';
import { OR_EXCHANGE_CONFIGURATION } from './or/configuration.or';

import UsersApi from './api/users.api';

export default class Users {
  private userApi = new UsersApi();

  /**
   * @details - Select Options from user menu dropdown in ppe configuration page
   * @param option
   * @API - API's are available - Implemented Completely
   * @Author Madhu Kiran
   */
  selectSettingInConfiguration(name: string) {
    const interceptFunctions = {
      [OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.USERS[0]]:
        this.userApi.interceptUserConfiguration,
      [OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.MANDATORY_FIELDS[0]]:
        this.userApi.interceptMandatoryFieldsConfiguration,
    };

    const interceptCollection = interceptFunctions[name]
      ? interceptFunctions[name]()
      : [];
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getAText(name), name);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To select the value from the Mapped Physician dropdown.
   * @param userName & name as string reference in the function.
   * @APIs - API's are available - Implemented Completely
   * @Author Madhu Kiran
   */
  selectPhysicianInMappedPhysician(userName: string, name: string) {
    const interceptCollection = this.userApi.interceptSelectPhysician();
    cy.cType(
      OR_USERS_CONFIGURATION.USERS.USER_SEARCH[1],
      OR_USERS_CONFIGURATION.USERS.USER_SEARCH[0],
      userName
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(userName), userName);
    cy.cWaitApis(interceptCollection);
    cy.cGet(OR_USERS_CONFIGURATION.USERS.MAPPED_PHYSICIAN_LABEL[1]).each(
      ($labelName) => {
        if ($labelName.text().includes(AppErrorMessages.select_items)) {
          cy.cClick(
            OR_USERS_CONFIGURATION.USERS.MAPPED_PHYSICIAN_DROPDOWN_ICON[1],
            OR_USERS_CONFIGURATION.USERS.MAPPED_PHYSICIAN_DROPDOWN_ICON[0]
          );
          cy.cGet(OR_USERS_CONFIGURATION.USERS.MAPPED_PHYSICIAN_LIST[1]).each(
            ($list) => {
              cy.wrap($list)
                .find(
                  OR_USERS_CONFIGURATION.USERS.MAPPED_PHYSICIAN_LABEL_VALUES[1]
                )
                .then(($values) => {
                  return cy
                    .wrap($values)
                    .cClick(
                      $values.text(),
                      OR_USERS_CONFIGURATION.USERS
                        .MAPPED_PHYSICIAN_LABEL_VALUES[0],
                      TrueOrFalse.true.includes(TrueOrFalse.true)
                    );
                });
            }
          );
          this.selectSettingInConfiguration(name);
        } else {
          this.selectSettingInConfiguration(name);
        }
      }
    );
  }

  /**
   * @details - To search and the select the users.
   * @param - userDetails - pass first name to search and select the user
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  searchAndSelectUser(userDetails: UserDetails) {
    const searchInterceptCollection = this.userApi.interceptSearchUser();
    cy.cIntercept(searchInterceptCollection);
    cy.cType(
      OR_USERS_CONFIGURATION.USERS.USER_SEARCH[1],
      OR_USERS_CONFIGURATION.USERS.USER_SEARCH[0],
      userDetails.FirstName
    );
    cy.cWaitApis(searchInterceptCollection);
    const selectInterceptCollection = this.userApi.interceptSelectUser();
    cy.cIntercept(selectInterceptCollection);
    cy.cClick(
      selectorFactory.getSpanText(userDetails.FirstName!),
      userDetails.FirstName!
    );
    cy.cWaitApis(selectInterceptCollection);
  }

  /**
   * @details - To click on the add user button.
   * @API - API's are not available
   * @author - Vamshi
   */
  clickAddUser() {
    cy.cClick(
      OR_USERS_CONFIGURATION.USERS.ADD_BUTTON[1],
      OR_USERS_CONFIGURATION.USERS.ADD_BUTTON[0]
    );
  }

  /**
   * @details - verify the email in user settings
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyEmailLabel() {
    cy.cIncludeText(
      OR_USERS_CONFIGURATION.USERS.LABEL[1],
      OR_USERS_CONFIGURATION.USERS.EMAIL_LABEL[0],
      OR_USERS_CONFIGURATION.USERS.EMAIL_LABEL[0]
    );
  }

  /**
   * @details - verify the Password in user settings
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyPasswordLabel() {
    cy.cIncludeText(
      OR_USERS_CONFIGURATION.USERS.LABEL[1],
      OR_USERS_CONFIGURATION.USERS.PASSWORD[0],
      OR_USERS_CONFIGURATION.USERS.PASSWORD[0]
    );
  }

  /**
   * @details - verify the Password in user settings
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyConfirmPasswordLabel() {
    cy.cIncludeText(
      OR_USERS_CONFIGURATION.USERS.LABEL[1],
      OR_USERS_CONFIGURATION.USERS.CONFIRM_PASSWORD[0],
      OR_USERS_CONFIGURATION.USERS.CONFIRM_PASSWORD[0]
    );
  }

  /**
   * @details - verify the Done button is disabled
   * @param - isEnabled - sending to true or false to verify the Done button
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyDoneButton(isEnabled: boolean = true) {
    cy.cIsEnabled(
      OR_USERS_CONFIGURATION.USERS.DONE[1],
      OR_USERS_CONFIGURATION.USERS.DONE[0],
      false,
      isEnabled
    );
  }

  /**
   * @details - verify the Cancel button is enabled
   * @param - isEnabled - sending to true or false to verify the Cancel Button
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyCancelButton(isEnabled: boolean = true) {
    cy.cIsEnabled(
      OR_USERS_CONFIGURATION.USERS.CANCEL[1],
      OR_USERS_CONFIGURATION.USERS.CANCEL[0],
      false,
      isEnabled
    );
  }

  /**
   * @details -Enter First name, Last name, in Add user popup
   * @param - userDetails - First name , Last name , middle initial should be enter in new user popup(First name:Test , LastName:Last name:User)
   * @API - API's are not available
   * @author - Vamshi
   */
  createUser(userDetails: UserDetails) {
    cy.cClick(
      OR_USERS_CONFIGURATION.USERS.FIRST_NAME[1],
      OR_USERS_CONFIGURATION.USERS.FIRST_NAME[0]
    );
    cy.cType(
      OR_USERS_CONFIGURATION.USERS.FIRST_NAME[1],
      OR_USERS_CONFIGURATION.USERS.FIRST_NAME[0],
      userDetails.FirstName
    );
    cy.cClick(
      OR_USERS_CONFIGURATION.USERS.MIDDLE_INITIAL[1],
      OR_USERS_CONFIGURATION.USERS.MIDDLE_INITIAL[0]
    );
    cy.cType(
      OR_USERS_CONFIGURATION.USERS.MIDDLE_INITIAL[1],
      OR_USERS_CONFIGURATION.USERS.MIDDLE_INITIAL[0],
      userDetails.MiddleInitial
    );
    cy.cClick(
      OR_USERS_CONFIGURATION.USERS.LAST_NAME[1],
      OR_USERS_CONFIGURATION.USERS.LAST_NAME[0]
    );
    cy.cType(
      OR_USERS_CONFIGURATION.USERS.LAST_NAME[1],
      OR_USERS_CONFIGURATION.USERS.LAST_NAME[0],
      userDetails.LastName
    );
  }

  /**
   * @details - Entering the User Name in the user details tab
   * @param -  userDetails - username should be enter in user details tab
   * @API - API's are not available
   * @author - Vamshi
   */
  enterUserName(userDetails: UserDetails) {
    cy.cType(
      OR_USERS_CONFIGURATION.USERS.USER_NAME[1],
      OR_USERS_CONFIGURATION.USERS.USER_NAME[0],
      userDetails.Username
    );
  }

  /**
   * @details - Entering the email in the user details tab
   * @param -  userDetails -Email should be enter in user details tab
   * @API - API's are not available
   * @author - Vamshi
   */
  enterEmail(userDetails: UserDetails) {
    cy.cClick(
      OR_USERS_CONFIGURATION.USERS.CREATE_USER[1],
      OR_USERS_CONFIGURATION.USERS.CREATE_USER[0]
    );
    cy.cGet(OR_USERS_CONFIGURATION.USERS.EMAIL[1])
      .click()
      .type(CommonTypeValues.select_all)
      .type(CommonTypeValues.back_space);
    cy.cClear(OR_USERS_CONFIGURATION.USERS.EMAIL[1]);
    cy.cGet(
      OR_USERS_CONFIGURATION.USERS.EMAIL[1],
      OR_USERS_CONFIGURATION.USERS.EMAIL[0]
    ).dblclick();
    cy.cType(
      OR_USERS_CONFIGURATION.USERS.EMAIL[1],
      OR_USERS_CONFIGURATION.USERS.EMAIL[0],
      userDetails.EMail
    );
  }

  /**
   * @details - Verify the Invalid message of email box
   * @param - errorMessage - message that needs to be verified(invalid error message)
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyEmailText(errorMessage: string) {
    cy.cIncludeText(
      OR_USERS_CONFIGURATION.USERS.INVALID_EMAIL[1],
      OR_USERS_CONFIGURATION.USERS.INVALID_EMAIL[0],
      errorMessage
    );
  }

  /**
   * @details - Click on the Done button In Add User popup
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  clickDoneInAddUser() {
    const interceptCollection = this.userApi.interceptClickDoneInAdd();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_USERS_CONFIGURATION.USERS.DONE[1],
      OR_USERS_CONFIGURATION.USERS.DONE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verify the Entered email in user settings
   * @param - email - verified email in user popup
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyEnteredEmail(email: string) {
    cy.cIncludeText(
      OR_USERS_CONFIGURATION.USERS.ENTERED_EMAIL[1],
      OR_USERS_CONFIGURATION.USERS.ENTERED_EMAIL[0],
      email
    );
  }

  /**
   * @details - To verify total items and shown counts at the bottoms of dictionaries tab
   * @param - value - message that needs to be verified(tooltip text)
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyToolTip(value: string) {
    cy.cGet(OR_USERS_CONFIGURATION.TOOL_TIP[1])
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible);
    cy.cIncludeText(
      OR_USERS_CONFIGURATION.TOOL_TIP[1],
      OR_USERS_CONFIGURATION.TOOL_TIP[0],
      value
    );
  }
}
