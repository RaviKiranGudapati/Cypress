import {
  CheckedOrUnchecked,
  InvokeAttributes,
} from '../../../support/common-core-libs/application/common-core';
import {
  InvokeMethods,
  ShouldMethods,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_EXCHANGE_CONFIGURATION } from './or/configuration.or';
import {
  FacilityOptions,
  PostOpNotificationsOptions,
  PreOpNotificationsOptions,
  SisLinkSettingsOptions,
  WorklistOptions,
} from './enums/configuration.enum';

import ConfigurationApi from './api/configuration.api';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

export default class Configuration {
  private configurationApi = new ConfigurationApi();

  /**
   * Function Details - Select Options from user menu dropdown in ppe configuration page
   * @param option
   * @APIs are Not available
   */
  selectOptionInUserMenuDropdown(option: string) {
    cy.cClick(
      OR_EXCHANGE_CONFIGURATION.USER_MENU[1],
      OR_EXCHANGE_CONFIGURATION.USER_MENU[0]
    );
    cy.cClick(option, option, true, true);
  }

  /**
   * @details - logout the application
   * @APIs are Not available
   */
  logout() {
    this.selectOptionInUserMenuDropdown(
      OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.LOGOUT[0]
    );
    cy.cClickIfExist(
      selectorFactory.getSpanText(
        OR_EXCHANGE_CONFIGURATION.LOGOUT_CONFIRMATION.YES[0]
      ),
      OR_EXCHANGE_CONFIGURATION.LOGOUT_CONFIRMATION.YES[0]
    );
  }

  /***
   * @details click mandatory field toggle YesNO
   * @param name - for county filed ,verify toggle yes or no
   * @param yesNo - To select yes or no for mandatory field
   * @API - API's are not available
   * @author Suneetha
   */
  clickMandatoryFieldToggle(name: string, yesNo: string = YesOrNo.no) {
    cy.cGet(selectorFactory.getSpanText(name))
      .should(ShouldMethods.visible)
      .parent()
      .within(() => {
        cy.cGet(OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.TOGGLE[1])
          .invoke(InvokeMethods.attribute, InvokeAttributes.data_test_id)
          .then(($val) => {
            if (
              (yesNo == YesOrNo.yes && $val == CheckedOrUnchecked.unchecked) ||
              (yesNo == YesOrNo.no && $val == CheckedOrUnchecked.checked)
            ) {
              cy.cClick(
                OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.TOGGLE[1],
                ' '
              );
            }
          });
      });
  }

  /**
   * @details click on scheduling desktop option from user dropdown list
   * @param option that needs to be selected ex:Scheduling desktop
   * @author Praveen
   */
  clickSchedulingDesktop(option: string) {
    const interceptCollection =
      this.configurationApi.interceptSchedulingDesktopApi();
    cy.cIntercept(interceptCollection);
    this.selectOptionInUserMenuDropdown(option);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details select option in pre-op notification setting
   * @param option name of the setting that needs to be selected
   * @Api Apis are available ,Implemented completely
   * @author Arushi
   */
  selectOptionInPreOpNotification(option: PreOpNotificationsOptions) {
    let interceptCollection: ApiEndpoint[] = [];
    const optionMappings = {
      [PreOpNotificationsOptions.general_reminders]: {
        intercept: this.configurationApi.interceptPreOpGeneralReminder(),
        locator:
          OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS.GENERAL_REMINDERS[1],
      },
      [PreOpNotificationsOptions.speciality_specific_reminders]: {
        intercept:
          this.configurationApi.interceptPreOpSpecialitySpecificReminder(),
        locator:
          OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS
            .SPECIALITY_SPECIFIC_REMINDERS[1],
      },
      [PreOpNotificationsOptions.welcome_messages]: {
        intercept: this.configurationApi.interceptPreOpWelcomeBackMessages(),
        locator:
          OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS.WELCOME_MESSAGES[1],
      },
    };

    const selectedOption = optionMappings[option];

    if (selectedOption) {
      interceptCollection = selectedOption.intercept;
      cy.cIntercept(interceptCollection);
      cy.cClick(selectedOption.locator, option);
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details select option in post-op notification settings
   * @param option name of the setting that needs to be selected
   * @Api Apis are available ,Implemented completely
   * @author Arushi
   */
  selectOptionInPostOpNotification(option: PostOpNotificationsOptions) {
    let interceptCollection: ApiEndpoint[] = [];
    const optionMappings = {
      [PostOpNotificationsOptions.general_reminders]: {
        intercept: this.configurationApi.interceptPostOpGeneralReminder(),
        locator:
          OR_EXCHANGE_CONFIGURATION.POST_OP_NOTIFICATIONS.GENERAL_REMINDERS[1],
      },
      [PostOpNotificationsOptions.speciality_specific_reminders]: {
        intercept:
          this.configurationApi.interceptPostOpSpecialitySpecificReminder(),
        locator:
          OR_EXCHANGE_CONFIGURATION.POST_OP_NOTIFICATIONS
            .SPECIALITY_SPECIFIC_REMINDERS[1],
      },
      [PostOpNotificationsOptions.post_op_messages]: {
        intercept: this.configurationApi.interceptPostOpMessages(),
        locator:
          OR_EXCHANGE_CONFIGURATION.POST_OP_NOTIFICATIONS.POST_OP_MESSAGES[1],
      },
    };

    const selectedOption = optionMappings[option];

    if (selectedOption) {
      interceptCollection = selectedOption.intercept;
      cy.cIntercept(interceptCollection);
      cy.cClick(selectedOption.locator, option);
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details select option in post-op notification settings
   * @param option name of the setting that needs to be selected
   * @Api Apis are available ,Implemented completely
   * @author Arushi
   */
  selectOptionWorklists(option: WorklistOptions) {
    let interceptCollection: ApiEndpoint[] = [];
    const optionMappings = {
      [WorklistOptions.pre_admission_qx]: {
        intercept: this.configurationApi.interceptPreAdmissionInstruction(),
        locator: OR_EXCHANGE_CONFIGURATION.WORKLISTS.PRE_ADMISSION_QX[1],
      },
      [WorklistOptions.pre_admission_instructions]: {
        intercept: this.configurationApi.interceptPreAdmissionInstruction(),
        locator:
          OR_EXCHANGE_CONFIGURATION.WORKLISTS.PRE_ADMISSION_INSTRUCTIONS[1],
      },
      [WorklistOptions.post_operative_qx]: {
        intercept: this.configurationApi.interceptPreAdmissionInstruction(),
        locator: OR_EXCHANGE_CONFIGURATION.WORKLISTS.POST_OPERATIVE_QX[1],
      },
    };

    const selectedOption = optionMappings[option];

    if (selectedOption) {
      interceptCollection = selectedOption.intercept;
      cy.cIntercept(interceptCollection);
      cy.cClick(selectedOption.locator, option);
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details select physician notifications in Configuration
   * @Api Apis are available - Implemented completely
   * @author Arushi
   */
  selectPhysicianNotifications() {
    const interceptCollection: ApiEndpoint[] =
      this.configurationApi.interceptPhysicianNotification();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_EXCHANGE_CONFIGURATION.PHYSICIAN_NOTIFICATION[1],
      OR_EXCHANGE_CONFIGURATION.PHYSICIAN_NOTIFICATION[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on Done button in User Settings
   * @API - API's are available - Implemented Completely
   * @author - Dharani
   */
  clickDone() {
    const interceptCollection = this.configurationApi.interceptClickDoneApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_EXCHANGE_CONFIGURATION.USER_SETTINGS.DONE[1],
      OR_EXCHANGE_CONFIGURATION.USER_SETTINGS.DONE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details select option in sIS-Link Settings
   * @param option name of the setting that needs to be selected
   * @Api Apis are available - Implemented completely
   * @author Dharani
   */
  selectOptionInSisLinkSettings(option: SisLinkSettingsOptions) {
    let interceptCollection: ApiEndpoint[] = [];
    const optionMappings = {
      [SisLinkSettingsOptions.general]: {
        intercept: this.configurationApi.interceptSisLinkGeneral(),
        locator: OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.GENERAL[1],
      },
      [SisLinkSettingsOptions.users]: {
        intercept: this.configurationApi.interceptSisLinkUsers(),
        locator: OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.USERS[1],
      },
      [SisLinkSettingsOptions.mandatory_fields]: {
        intercept: this.configurationApi.interceptSisLinkMandatoryFields(),
        locator:
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.MANDATORY_FIELDS[1],
      },
      [SisLinkSettingsOptions.sis_link_notifications]: {
        intercept: this.configurationApi.interceptSisLinkNotifications(),
        locator:
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.SIS_LINK_NOTIFICATIONS[1],
      },
    };

    const selectedOption = optionMappings[option];

    if (selectedOption) {
      interceptCollection = selectedOption.intercept;
      cy.cIntercept(interceptCollection);
      cy.cClick(selectedOption.locator, option);
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details select Dictionaries in Configuration
   * @Api Apis are available - Implemented completely
   * @author Dharani
   */
  selectDictionaries() {
    const interceptCollection: ApiEndpoint[] =
      this.configurationApi.interceptDictionaries();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_EXCHANGE_CONFIGURATION.DICTIONARIES[1],
      OR_EXCHANGE_CONFIGURATION.DICTIONARIES[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details select option in Facility
   * @param option name of the setting that needs to be selected
   * @Api Apis are available - Implemented completely
   * @author Dharani
   */
  selectOptionInFacility(option: FacilityOptions) {
    let interceptCollection: ApiEndpoint[] = [];
    const optionMappings = {
      [FacilityOptions.branding]: {
        intercept: this.configurationApi.interceptFacilityBranding(),
        locator: OR_EXCHANGE_CONFIGURATION.FACILITY.BRANDING[1],
      },
      [FacilityOptions.contact_settings]: {
        intercept: this.configurationApi.interceptFacilityContactSettings(),
        locator: OR_EXCHANGE_CONFIGURATION.FACILITY.CONTACT_SETTINGS[1],
      },
      [FacilityOptions.documents_and_disclosures]: {
        intercept:
          this.configurationApi.interceptFacilityDocumentsAndDisclosures(),
        locator:
          OR_EXCHANGE_CONFIGURATION.FACILITY.DOCUMENTS_AND_DISCLOSURES[1],
      },
    };

    const selectedOption = optionMappings[option];

    if (selectedOption) {
      interceptCollection = selectedOption.intercept;
      cy.cIntercept(interceptCollection);
      cy.cClick(selectedOption.locator, option);
      cy.cWaitApis(interceptCollection);
    }
  }

  /*
   * @details - verify the change password button is disabled
   * @param -  isDisabled - sending to true or false to verify the change password button
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyChangePassword(isDisabled: boolean = false) {
    cy.cIsEnabled(
      OR_EXCHANGE_CONFIGURATION.USER_SETTINGS.CHANGE_PASSWORD[1],
      OR_EXCHANGE_CONFIGURATION.USER_SETTINGS.CHANGE_PASSWORD[0],
      false,
      isDisabled
    );
  }
}
