import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_USERS_CONFIGURATION = {
  USERS: {
    USER_SEARCH: ['Search', `input[class*='inputtext']`],
    ADD_BUTTON: ['Add', '.add-button'],
    FIRST_NAME: ['First Name*', '[name="firstName"]'],
    LAST_NAME: ['Last Name*', '[name="lastName"]'],
    MIDDLE_INITIAL: ['Middle Initial', '.middle-initial'],
    USER_NAME: ['Username*', '[name="login"]'],
    EMAIL_LABEL: ['E-Mail*'],
    PASSWORD: ['Password'],
    CONFIRM_PASSWORD: ['Confirm Password'],
    EMAIL: ['E-Mail', '[name="email-address"]'],
    CREATE_USER: ['Create User', '.title'],
    INVALID_EMAIL: ['Invalid Email', '.error-message'],
    DONE: ['Done', '.done-button'],
    CANCEL: ['Cancel', '[label="Cancel"]'],
    ENTERED_EMAIL: ['Entered Email', '.col-row-item'],
    LABEL: ['Label', '.last-name .row-header'],
    MAPPED_PHYSICIAN_DROPDOWN_ICON: [
      'Mapped Physician Dropdown Icon',
      CoreCssClasses.MultiSelect.loc_ui_multiselect_label,
    ],
    MAPPED_PHYSICIAN_LABEL: [
      'Mapped Physician Label Name',
      CommonUtils.concatenate(
        CoreCssClasses.MultiSelect.loc_p_multiselect_tag,
        ' div label'
      ),
    ],
    MAPPED_PHYSICIAN_LIST: [
      'Mapped Physician List',
      CoreCssClasses.MultiSelect.loc_ui_multiselect_item,
    ],
    MAPPED_PHYSICIAN_LABEL_VALUES: ['Mapped Physician Values', 'label'],
  },
  TOOL_TIP: ['Tool Tip Message', '.ui-tooltip'],
};
