import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_PPE_PRE_ADMISSION_INSTRUCTIONS = {
  SEARCH: ['Search', `[type="search"]`],
  ADD_BUTTON: ['Add'],
  ADD_WORKLIST: {
    HEADER: ['Add Worklist'],
    WORKLIST_NAME: ['Worklist Name', `.content [placeholder="Worklist Name"]`],
  },
  SPECIALITY: ['Speciality', '.sis-speciality'],
  PLUS_ICON: ['Plus Icon', CoreCssClasses.Icon.loc_plus_circle],
  SEARCH_BOX: ['Search Box', '.search-box-input'],
  DELETE_WIDGET: {
    WIDGET: ['Widget', '.question-wrapper'],
    DELETE_ICON: ['Delete Icon', '.delete-icon'],
    DELETE_WORKLIST_ITEM: ['Delete Worklist Item'],
    CONFIRM_DIALOG: [
      'Confirm Dialog',
      CommonUtils.concatenate(
        'body ',
        CoreCssClasses.Dialog.loc_ui_confirmdialog
      ),
    ],
  },
  DOCUMENTS_ACKNOWLEDGED: {
    HEADER: ['Documents Acknowledged'],
    SELECT_ITEM: ['Select Item', `[data-test-id="dd-multiselect"]`],
    INPUT_TEXT_BOX: [
      'Input Box',
      CommonUtils.concatenate(
        CoreCssClasses.MultiSelect.loc_ui_multiselect_filter_container,
        ` input[type='text']`
      ),
    ],
    ITEMS_LIST: ['Items List', CoreCssClasses.List.loc_ui_multiselect_list],
  },
  LABEL: [
    'Label',
    CommonUtils.concatenate(
      `.widget-p-card `,
      CoreCssClasses.Label.loc_ui_card_content
    ),
  ],
  NPO: ['NPO'],
};
