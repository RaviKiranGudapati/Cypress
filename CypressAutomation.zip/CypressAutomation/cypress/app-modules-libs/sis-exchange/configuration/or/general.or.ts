import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_PPE_GENERAL = {
  SETTING_ROW: ['Setting', 'body .settings-status'],
  ENABLE_EDITING_BOOKED_APPOINTMENTS: ['Enable Editing Booked Appointments'],
  GENERAL: ['General'],
  ALL_PHYSICIAN: ['All Physician', '.settings-physicians'],
  PHYSICIAN_DROPDOWN: [
    'Physician dropdown',
    CommonUtils.concatenate(
      '.settings-physicians-multiselect ',
      CoreCssClasses.MultiSelect.loc_p_multiselect_tag,
      ' ',
      CoreCssClasses.MultiSelect.loc_ui_multiselect
    ),
  ],
  PHYSICIAN_DROPDOWN_LIST: [
    'Physician dropdown list',
    CommonUtils.concatenate(
      'body ',
      CoreCssClasses.MultiSelect.loc_ui_multiselect_items
    ),
  ],
  SELECTED_PHYSICIANS: ['Selected Physicians', '.settings-physicians-list li'],
};
