import {
  CommonGetLocators,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_EXCHANGE_CONFIGURATION } from './or/configuration.or';

export default class PostOpGeneralReminders {
  /**
   * @details selecting yes in send requests in appointment type
   * @param appointmentType to be passed as an array of options for which yes needs to be selected
   * @Api Apis are not available
   * @author Arushi
   */
  selectYesNoInAppointmentTypeInPostOp(appointmentType: string[]) {
    appointmentType.forEach((el) => {
      cy.cGet(CommonGetLocators.body).then((body) => {
        if (
          body.find(
            selectorFactory.preOPNotificationsGeneralReminderAppointmentType(
              el,
              YesOrNo.no
            )
          ).length > 0
        ) {
          cy.cClick(
            selectorFactory.preOPNotificationsGeneralReminderAppointmentType(
              el,
              YesOrNo.no
            ),
            YesOrNo.no
          );
          cy.cClick(
            selectorFactory.preOPNotificationsGeneralReminderAppointmentTypeYesOrNo(
              el
            ),
            YesOrNo.yes
          );
          cy.cClick(
            OR_EXCHANGE_CONFIGURATION.POST_OP_NOTIFICATIONS
              .APPOINTMENT_TYPE_HEADERS[1],
            OR_EXCHANGE_CONFIGURATION.POST_OP_NOTIFICATIONS
              .APPOINTMENT_TYPE_HEADERS[0]
          );
        }
      });
    });
  }

  /**
   * @details enable send patient postal requests
   * @Api Apis are not available
   * @author Arushi
   */
  enablePatientPortalRequests() {
    cy.cClick(
      OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS.SEND_REQUEST_PRE_OP[1],
      OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS.SEND_REQUEST_PRE_OP[0]
    );
    cy.shouldBeEnabled(
      OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS
            .ENABLE_PORTAL_REQUEST_YES[1]
    );
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (
        body.find(
          OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS
            .DISABLE_PORTAL_REQUEST_TOGGLE[1]
        ).length > 0
      ) {
        cy.cClick(
          OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS
            .ENABLE_PORTAL_REQUEST_YES[1],
          YesOrNo.yes
        );
        cy.cClick(
          OR_EXCHANGE_CONFIGURATION.POST_OP_NOTIFICATIONS
            .APPOINTMENT_TYPE_HEADERS[1],
          OR_EXCHANGE_CONFIGURATION.POST_OP_NOTIFICATIONS
            .APPOINTMENT_TYPE_HEADERS[0]
        );
      }
    });
  }

  /**
   * @details entering date for send notification on appointments with DOS after field
   * @param date date that needs to be entered to be passed in format yyyy-mm-dd
   * @Api Apis are not available
   * @author Arushi
   */
  selectSendNotificationDate(date: string) {
    cy.cGet(OR_EXCHANGE_CONFIGURATION.PRE_OP_NOTIFICATIONS.DATE_PICKER[1]).type(
      date
    );
  }
}
