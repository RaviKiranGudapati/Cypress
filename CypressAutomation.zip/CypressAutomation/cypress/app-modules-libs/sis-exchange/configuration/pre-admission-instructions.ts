import {
  DoneOrCancel,
  LeftOrRight,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_PPE_PRE_ADMISSION_INSTRUCTIONS } from './or/pre-admission-instructions.or';

export class PpePreAdmissionInstructions {
  /**
   * @details - To click on add button
   * @API - API's are not available
   * @author - Divya
   */
  clickAddButton() {
    cy.cClick(
      selectorFactory.getButtonText(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.ADD_BUTTON[0]
      ),
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.ADD_BUTTON[0]
    );
  }

  /**
   * @details - To enter worklist name
   * @param name - name of the worklist that needs to be entered
   * @API - API's are not available
   * @author - Divya
   */
  enterWorklistName(name: string) {
    cy.cType(
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.ADD_WORKLIST.WORKLIST_NAME[1],
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.ADD_WORKLIST.WORKLIST_NAME[0],
      name
    );
  }

  /**
   * @details - To click on cancel or done
   * @param cancelDone - cancel or done button
   * @API - API's are available - Not Implemented
   * @author - Divya
   */
  clickCancelOrDone(cancelDone: string = DoneOrCancel.done) {
    cy.cClick(selectorFactory.getSpanText(cancelDone), cancelDone);
  }

  /**
   * @details - To add the worklist
   * @param name- worklist name used as parameter
   * @API - API's are not available
   * @author - Divya
   */
  addWorkList(name: string) {
    this.clickAddButton();
    this.enterWorklistName(name);
    this.clickCancelOrDone();
    cy.cIsVisible(selectorFactory.getSpanText(name), name);
    cy.cIsVisible(
      selectorFactory.getLabelText(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.ADD_WORKLIST.WORKLIST_NAME[0]
      ),
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.ADD_WORKLIST.WORKLIST_NAME[0]
    );
  }

  /**
   * @details - To click on plus icon
   * @param leftRight- based on left or right panels clicking on plus icon
   * @API - API's are not available
   * @author - Divya
   */
  clickPlusIcon(leftRight: string) {
    const value =
      leftRight.trim().toUpperCase() === LeftOrRight.left.trim().toUpperCase()
        ? 0
        : 1;
    cy.cGet(OR_PPE_PRE_ADMISSION_INSTRUCTIONS.PLUS_ICON[1]).eq(value).click();
  }

  /**
   * @details - To select Worklist Widget
   * @param widget- based on widget name selecting the widget
   * @API - API's are not available
   * @author - Divya
   */
  selectWorklistWidget(widget: string) {
    cy.cType(
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.SEARCH_BOX[1],
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.SEARCH_BOX[0],
      widget
    );
    cy.cClick(widget, widget, true, true);

    if (widget == OR_PPE_PRE_ADMISSION_INSTRUCTIONS.NPO[0]) {
      cy.cIsVisible(OR_PPE_PRE_ADMISSION_INSTRUCTIONS.LABEL[1], widget);
    }
  }

  /**
   * @details - To select delete Worklist Widget
   * @param widget- based on widget name deleting the widget
   * @API - API's are not available
   * @author - Divya
   */
  deleteWidget(widget: string) {
    cy.cGet(OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DELETE_WIDGET.WIDGET[1])
      .find(OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DELETE_WIDGET.DELETE_ICON[1])
      .click();

    cy.cGet(OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DELETE_WIDGET.CONFIRM_DIALOG[1])
      .find(selectorFactory.getSpanText(YesOrNo.yes))
      .click();
  }

  /**
   * @details - To add documents to the documents acknowledged
   * @param items- to add items for documents widget
   * @API - API's are not available
   * @author - Divya
   */
  addItemToDocumentsAcknowledged(items: string[]) {
    cy.cClick(
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED.SELECT_ITEM[1],
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED.SELECT_ITEM[0]
    );
    items.forEach((item) => {
      cy.cType(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED
          .INPUT_TEXT_BOX[1],
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED
          .INPUT_TEXT_BOX[0],
        item
      );
      cy.cGet(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED.ITEMS_LIST[1]
      )
        .find(selectorFactory.getLabelText(item))
        .eq(0)
        .click();
    });
  }

  /**
   * @details - To search and select the worklist
   * @param name- name of the worklist that needs to be searched and selected
   * @API - API's are not available
   * @author - Divya
   */
  searchAndSelectWorklist(name: string) {
    cy.cType(
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.SEARCH[1],
      OR_PPE_PRE_ADMISSION_INSTRUCTIONS.SEARCH[0],
      name
    );
    cy.cClick(selectorFactory.getSpanText(name), name);
  }
}
