import { CommonUtils } from '../../../../../../support/common-core-libs/framework/common-utils';

import { td_consents_config_sc265840 } from '../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-config-tcid-265840.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { OR_PHYSICIAN_DESKTOP } from '../../../../../../app-modules-libs/sis-charts/physician/or/physician-desktop.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISPhysicianDesktop from '../../../../../../app-modules-libs/sis-charts/physician/physician-desktop';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';

/*instance variables*/
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const sisPhysicianDesktop = new SISPhysicianDesktop();
const login = new SISCompleteLogin();

export class PhysicianConsentsTcId265840 {
  verifyPhysicianConsentsModifiedProcedures() {
    describe('To verify procedure data in consents popup in physician desktop', () => {
      it('Verify all procedures data based on the case selection in consents popup in physician desktop', () => {
        // #region verify the all procedure data in consents popup

        cy.cGroupAsStep('Verify procedure data in consents popup');
        /**********Login To Application***********/
        login.login(
          UserList.PHYSICIAN[0],
          UserList.PHYSICIAN[1],
          OrganizationList.GEM_ORG_21
        );
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_config_sc265840.PatientCase[3].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);

        sisPhysicianDesktop.selectTaskInMyTasksInPhysicianDesktop(
          OR_PHYSICIAN_DESKTOP.MY_TASKS.CONSENTS[0]
        );

        sisPhysicianDesktop.verifyProceduresInConsentsTab(
          td_consents_config_sc265840.ConsentsModel[0].ConsentName,
          CommonUtils.concatenate(
            td_consents_config_sc265840.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_config_sc265840.ConsentsModel[0].Procedures![3]
          )
        );

        // #endregion
      });
    });
  }
}
