import { td_inv_rec_implant_tcid_74203 } from '../../../fixtures/sis-office/trackers/inventory-reconciliation/inv-rec-implant-tcid-74203.td';
import { td_rev_cyc_manager_tcid_97581 } from '../../../fixtures/shared/application-settings/revenue-cycle-manager-tcid-97581.td';
import InventoryReconciliation from '../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import {
  CommonUtils,
  StringType,
} from '../../../support/common-core-libs/framework/common-utils';
import { cyUtils } from '../../../support/common-core-libs/framework/cypress-wrapper';
import { RevenueCycleManager } from '../../../test-data-models/shared/application-settings/application-settings.model';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { OR_NURSING_CONFIGURATION } from '../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
const os = require('os');
describe('Unit Test - Model Integration Verification', () => {
  it('Verify PatientModel and Implant Model Passed As Input Works Well And Can Be Read Back ', () => {
    const invReconPg = new InventoryReconciliation(
      td_inv_rec_implant_tcid_74203.PatientInfo,
      td_inv_rec_implant_tcid_74203.ImplantInfo
    );
    let str = invReconPg.patientModel.PatientFirstName;
    expect(str).to.be.equal('Pfnamesc2354_1');
    invReconPg.implantModel!.forEach((item, index) => {
      cy.log(`Implant Model - ${index + 1}`);
      for (const [k, v] of Object.entries(item)) {
        cy.log(`key = ${k}`);
        expect(k).oneOf([
          'Implant',
          'Manufacturer',
          'Used',
          'Size',
          'Lot',
          'Serial',
          'Expiration',
          'Reference',
          'Notes',
        ]);
        cy.log(`value = ${v}`);
        expect(v).to.be.not.equal(undefined);
      }
    });
  });

  it('verify calling to random generator function in test data mimicking model should return unique value with each call', () => {
    let rcmModel1: RevenueCycleManager =
      td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo;
    let rcmModel2: RevenueCycleManager =
      td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo;
    cyUtils.LOG(`rcmModel1 = ${rcmModel1.Name}`); //47 --ABC
    rcmModel2.Name = CommonUtils.generateUniqueString(
      81,
      StringType.ALPHANUMERIC
    );
    cyUtils.LOG(`rcmModel2 = ${rcmModel2.Name}`); // 48 -- XYZ , is it same as ABC, different than ABC, observed XYZ = ABC
  });

  it('Object Parser', () => {
    let EmployeeTD = {
      Name: 'Debasish',
      EmpId: 'E001518',
      Designation: '',
      Age: 0,
      IsInNotice: false,
      Salary: null,
      Experience: undefined,
    };
    for (const [key, value] of Object.entries(EmployeeTD)) {
      if (CommonUtils.isDefinedAndNotEmpty(value)) {
        cy.log(`Key = ${key}, Value = ${value}`);
      }
    }
    for (const [key, value] of Object.entries(EmployeeTD)) {
      if (CommonUtils.isDefinedAndEmpty(value)) {
        cy.log(`EmptyKey = ${key}, Value = ${value}`);
      }
    }
    for (const [key, value] of Object.entries(EmployeeTD)) {
      if (CommonUtils.isNotEmptyAndUndefined(value)) {
        cy.log(`NotEmptyKey = ${key}, Value = ${value}`);
      }
    }
    for (const [key, value] of Object.entries(EmployeeTD)) {
      if (CommonUtils.isNotEmptyAndUndefined(value)) {
        cy.log(`UndefinedKey = ${key}, Value = ${value}`);
      }
    }
    for (const [key, value] of Object.entries(EmployeeTD)) {
      if (CommonUtils.isNotEmptyAndUndefined(value)) {
        cy.log(`NotUndefinedKey = ${key}, Value = ${value}`);
      }
    }
  });

  it('OS Capture', () => {
    if (os.release().includes('Windows')) {
      cy.log('Its Windows');
    }
    if (os.release().includes('Linux')) {
      cy.log('Its Linux');
    }
  });
  it.only('Concatenate String', () => {
    cy.log(
      CommonUtils.concatenate(
        'Hello',
        'World',
        ',',
        CoreCssClasses.DropDown.loc_dropdown,
        'Am',
        'Debasish '
      )
    );
    //'#sourceofrevenue_group_codes > > > .dropdown-btn',
    expect(
      OR_NURSING_CONFIGURATION.INSURANCE.INSURANCE_CLASSIFICATION[1]
    ).equals(
      '#ipc_classification_select > .dropdown-dictionary > #ssDiv_ > .dropdown-btn'
    );
  });
});
