import { cyUtils } from '../../../support/common-core-libs/framework/cypress-wrapper';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OrganizationList } from '../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../fixtures/shared/user-list.td';

import { OR_SCHEDULE_GRID } from '../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import ScheduleGrid from '../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import SISCompleteLogin from '../../../app-modules-libs/sis-office/login/login';

const login = new SISCompleteLogin();
const scheduleGrid = new ScheduleGrid();

describe('sanityTest', () => {
  //before suite
  before(`Launching Web Application`, function () {
    Cypress.on('uncaught:exception', (error, runnable) => {
      return false;
    });
    /****Open the URL as defined in baseUrl in Cypress Configuration File Or CLI flag - --config baseUrl ********/
    cy.visit('/');
    cyUtils.LOG(`Launched Web Application - ${Cypress.config('baseUrl')}`);
    /**********Login To Application***********/
    login.login(
      UserList.GEM_USER_1[0],
      UserList.GEM_USER_1[1],
      OrganizationList.GEM_ORG_1
    );
  });
  it.skip('verify-drag-drop for preference card', () => {
    scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
      'Plnamesc3913, Pfnamesc3913 M',
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
    );
    cy.get('#btnAdd').click();
    cy.wait(2000);
    cy.get(`.ui-picklist-list > :nth-child(2)`).drag(
      `.ui-picklist-target-wrapper > .ui-picklist-list`
    );
    cy.get('.ui-dialog #btnDone').click();
    cy.get('.sticky-footer-container #btnDone').click();
  });

  it('verify-drag-drop In schedule grid for patient tile', () => {
    //Method - using cypress drag-drop plugin - dragging patient case tile to empty slot
    cy.log(
      'using cypress drag-drop plugin - dragging patient case tile to empty slot'
    );
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    ).drag(`:nth-child(2) > .fc-timegrid-slot > :nth-child(4)`);
    cy.get(':nth-child(2) > .fc-timegrid-slot > :nth-child(4)').trigger(
      'pointermove'
    );
  });

  it.only('verify-drag-drop In schedule grid for patient tile', () => {
    //Method - using cypress drag-drop plugin - dragging patient case tile to empty slot
    //cy.wait('3000');
    //debugger;
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    )
      .trigger('mousedown', { which: 1, button: 0 })
      .trigger('mousemove', {
        pageX: 175,
        pageY: 1750,
      })
      .trigger('mouseup', { force: true });
  });

  it('using cypress drag-drop plugin - dragging patient case tile to same table', () => {
    //Method - using cypress drag-drop plugin - dragging patient case tile to same table
    cy.log(
      'using cypress drag-drop plugin - dragging patient case tile to same table'
    );
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    ).drag(`td.fc-timegrid-col:nth-child(4)`, { force: true });
  });
  it('using cypress drag-drop plugin - move function', () => {
    //Method - using cypress drag-drop plugin - move function
    cy.log('using cypress drag-drop plugin - move function');
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    ).move({
      deltaX: 100,
      deltaY: 100,
    });
  });
  it('using wrap', () => {
    //Method - using wrap
    cy.log('using wrap');
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    ).then(($element) => {
      cy.wrap($element)
        .trigger('dragstart')
        .get(':nth-child(1) > .fc-timegrid-slot > :nth-child(4)')
        .trigger('drop')
        .click();
    });
  });

  it('using cypress dragstart and drop', () => {
    //Method - using cypress dragstart and drop
    cy.log('using cypress dragstart and drop');
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    ).trigger('dragstart');
    cy.get(`:nth-child(1) > .fc-timegrid-slot > :nth-child(4)`).trigger('drop');
  });
  it('using cypress dragstart and drop with dataTransfer', () => {
    //Method - using cypress dragstart and drop with dataTransfer
    cy.log('using cypress dragstart and drop with dataTransfer');
    const dataTransfer = new DataTransfer();
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    ).trigger('dragstart', {
      dataTransfer,
    });
    cy.get(`:nth-child(1) > .fc-timegrid-slot > :nth-child(4)`).trigger(
      'drop',
      {
        dataTransfer,
      }
    );
  });

  it('using cypress trigger movements', () => {
    //Method - using cypress trigger movements
    cy.log(' using cypress trigger movements');
    cy.get(
      selectorFactory.patientCaseTileInScheduleGrid(
        'Plnamesc3913, Pfnamesc3913 M'
      )
    )
      .trigger('mousemove')
      .trigger('mousedown')
      .trigger('pointerdown')
      .trigger('dragstart');
    cy.get(`:nth-child(1) > .fc-timegrid-slot > :nth-child(4)`)
      .trigger('mouseup')
      .trigger('pointerup');
  });
});
