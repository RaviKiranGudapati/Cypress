import { LeftOrRight } from '../../../../../support/common-core-libs/application/common-core';
import {
  CommonUtils,
  StringType,
} from '../../../../../support/common-core-libs/framework/common-utils';

import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_PPE_PRE_ADMISSION_INSTRUCTIONS } from '../../../../../app-modules-libs/sis-exchange/configuration/or/pre-admission-instructions.or';

import SISExchangeUsers from '../../../../../app-modules-libs/sis-exchange/configuration/users';
import { PpePreAdmissionInstructions } from '../../../../../app-modules-libs/sis-exchange/configuration/pre-admission-instructions';
import { DocumentsAndDisclosures } from '../../../../../app-modules-libs/sis-exchange/configuration/documents-and-disclosures';

/* instance variables */
const sisExchangeUsers = new SISExchangeUsers();
const ppePreAdmissionInstructions = new PpePreAdmissionInstructions();
const documentsAndDisclosures = new DocumentsAndDisclosures();

/* const values */
const files = ['jpg-file', 'gif-file'];
const filePath = [
  'tcid-270997/jpg-file.jpg',
  'tcid-270997/bmp-file.bmp',
  'tcid-270997/gif-file.gif',
  'tcid-270997/png-file.png',
];
const worklistName =
  'PPEWorklist' +
  CommonUtils.generateUniqueString(2, StringType.ALPHABETS) +
  '270997';
const bmpFile = 'bmp-file';

export class DocumentsAndDisclosuresTcId270997 {
  addDocuments() {
    it('Add Documents to the pre-admission instructions ', () => {
      // #region Add documents and Mapping documents to worklist

      cy.cGroupAsStep(
        'Adding documents to the documents and disclosures and mapping to the pre-admission worklist.'
      );

      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.DOCUMENTS_AND_DISCLOSURES[0]
      );
      documentsAndDisclosures.clickAddButton();
      documentsAndDisclosures.verifyMaximumSizeAndSupportedFile();
      documentsAndDisclosures.verifyBrowseForFile();
      documentsAndDisclosures.clickCrossIcon();

      documentsAndDisclosures.clickAddButton();
      documentsAndDisclosures.uploadFile(filePath[0]);

      documentsAndDisclosures.clickAddButton();
      documentsAndDisclosures.uploadFile(filePath[1]);

      documentsAndDisclosures.clickAddButton();
      documentsAndDisclosures.uploadFile(filePath[2]);

      documentsAndDisclosures.clickAddButton();
      documentsAndDisclosures.uploadFile(filePath[3]);

      documentsAndDisclosures.searchAndSelectFile(bmpFile);
      documentsAndDisclosures.verifyMaxLengthForFileNameAndStatement();
      documentsAndDisclosures.verifyPreviewFile();

      documentsAndDisclosures.deleteAddedItem(bmpFile);

      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.CONTACT_SETTINGS[0]
      );

      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.DOCUMENTS_AND_DISCLOSURES[0]
      );

      documentsAndDisclosures.showInactive(true);
      documentsAndDisclosures.verifyAddedFile(bmpFile);

      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS
          .PRE_ADMISSION_INSTRUCTIONS[0]
      );

      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.DOCUMENTS_AND_DISCLOSURES[0]
      );
      documentsAndDisclosures.showInactive(false);

      documentsAndDisclosures.verifyAddedFile(files[1]);
      documentsAndDisclosures.verifyAddedFile(files[0]);
      // #endregion

      // #region Mapping documents to pre admission instructions
      
      cy.cGroupAsStep(
        'Mapping the added documents to the pre-admission instructions worklist.'
      );
      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS
          .PRE_ADMISSION_INSTRUCTIONS[0]
      );

      ppePreAdmissionInstructions.addWorkList(worklistName);
      ppePreAdmissionInstructions.searchAndSelectWorklist(worklistName);

      ppePreAdmissionInstructions.clickPlusIcon(LeftOrRight.right);
      ppePreAdmissionInstructions.selectWorklistWidget(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED.HEADER[0]
      );
      ppePreAdmissionInstructions.deleteWidget(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED.HEADER[0]
      );
      ppePreAdmissionInstructions.clickPlusIcon(LeftOrRight.right);
      ppePreAdmissionInstructions.selectWorklistWidget(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED.HEADER[0]
      );
      ppePreAdmissionInstructions.addItemToDocumentsAcknowledged(files);

      ppePreAdmissionInstructions.clickPlusIcon(LeftOrRight.right);

      ppePreAdmissionInstructions.selectWorklistWidget(
        OR_PPE_PRE_ADMISSION_INSTRUCTIONS.NPO[0]
      );

      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.DOCUMENTS_AND_DISCLOSURES[0]
      );
      sisExchangeUsers.selectSettingInConfiguration(
        OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS
          .PRE_ADMISSION_INSTRUCTIONS[0]
      );

      // #endregion
    });
  }
}
