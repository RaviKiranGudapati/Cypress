import SISOfficeDesktop from '../../../../support/common-core-libs/application/sis-office-desktop';

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import Login from '../../../../app-modules-libs/sis-exchange/login/login';

import { CaseRequestCountyFieldTcId274923 } from '../../sis-office/case/create/scenarios/tcid-274923.sc';
import { PpePatientDetailsTcId274923 } from './scenarios/tcid-274923.sc';

/* instance variables */
const ppePatientDetails = new PpePatientDetailsTcId274923();
const caseRequestCountyField = new CaseRequestCountyFieldTcId274923();
const sisOfficeDesktop = new SISOfficeDesktop();

/*****************Test Script Validation Details **********************
 * New County field added in sis exchange and should map in sis office case request,patient details and vice-versa
 * *Script Execution Approach -
 * 1. Login into sis exchange application and navigate to applications settings.
 * 2. Click on mandatory field and verify county is added newly with YesNo toggle.Select No toggle for county field
 * 3. Create appointment request ,after entering zip code auto populate city,county and state field and same should accept in sis-office case request.
 * 4. Create new patient and verify  same zip code,city,county and state.
 * 5. Navigate back to sis office ,modify zip code and verify new city,county,state as per the zip code.
 * 6. In sis office case request verify modification triangle icon and verify red color highlighted modified from sis exchange,
 * 7. After clicking on updated button red color highlighted text should change to black color.
 * 8. Verify updated zip code, city,county and state in patients details and face-sheet patient details tabs.
 * 9. Add insurance and verify zip code,city,county,stated field.
 */

describe(
  'Verify patient details County field with toggle No',
  {
    tags: ['patient-details', 'US#271907', 'TC#274923'],
  },
  () => {
    before(`Launching Web Application`, function () {
      cy.visit(Cypress.env('ppeURL'));
      /**********Login To PPE Application***********/
      const ppeLogin = new Login();
      ppeLogin.login(
        UserList.GEM_USER_2[0],
        UserList.GEM_USER_2[1],
        OrganizationList.GEM_ORG_2
      );
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisOfficeDesktop.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        ppePatientDetails.verifyCountyField();
        caseRequestCountyField.verifyAddressFields();
        ppePatientDetails.verifyModifiedZipCode();
        caseRequestCountyField.verifyModifiedDetails();
        caseRequestCountyField.verifyModifiedDetailsInFaceSheet();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
