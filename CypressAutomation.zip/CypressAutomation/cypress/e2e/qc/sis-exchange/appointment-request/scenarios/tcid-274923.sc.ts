import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';

import { td_county_field_tcid_274923 } from '../../../../../fixtures/sis-exchange/appointment-request/patient-details-county-field-274923.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';

import PpeAppointmentRequest from '../../../../../app-modules-libs/sis-exchange/case-creation/appointment-request';
import Configuration from '../../../../../app-modules-libs/sis-exchange/configuration/configuration';
import Users from '../../../../../app-modules-libs/sis-exchange/configuration/users';
import Login from '../../../../../app-modules-libs/sis-exchange/login/login';
import General from '../../../../../app-modules-libs/sis-exchange/configuration/general';

/* instance variables */
const appReq = new PpeAppointmentRequest();
const ppeConfig = new Configuration();
const sisExchangeUsers = new Users();
const ppeLogin = new Login();
const sisExchangeGeneral = new General();

/* const values */
const physicians = [
  'sis Gem_user10, Dr',
  'sis Gem_user11, Dr',
  'sis Physician, Dr',
];

export class PpePatientDetailsTcId274923 {
  verifyCountyField() {
    describe('Verify county field in both SIS Exchange and SIS Office', () => {
      it('Creating Case in SIS Exchange to verify county field', () => {
        // #region - verifying city,count,state,zip code in patient details tab

        cy.cGroupAsStep('Select Scheduling Desktop in SIS Exchange');
        ppeConfig.selectOptionInUserMenuDropdown(
          OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.APPLICATION_SETTINGS[0]
        );
        sisExchangeUsers.selectSettingInConfiguration(
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.MANDATORY_FIELDS[0]
        );
        ppeConfig.clickMandatoryFieldToggle(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .COUNTY[0],
          YesOrNo.no
        );
        sisExchangeGeneral.selectGeneralInConfiguration();
        sisExchangeGeneral.enableEditingBookedAppointmentsToggle();
        sisExchangeGeneral.selectPhysician(physicians);
        ppeConfig.clickSchedulingDesktop(
          OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
        );
        appReq.selectTimeSlot(
          td_county_field_tcid_274923.PatientCase[0].CaseDetails?.StartTime!,
          4
        );
        appReq.enterProcedureDetails(td_county_field_tcid_274923.CptCodeInfo);
        appReq.clickFooterButtons(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.FOOTER_BUTTONS
            .NEXT_BUTTON[0]
        );
        appReq.enterPatientDetails(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
        );
        appReq.enterZipCodeInPatientDetails(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
        );
        appReq.verifyCityCountyStateInPatientDetails(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
        );
        appReq.enterZipCodeInPrimaryGuarantor(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
        );
        appReq.clickFooterButtons(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
        );
        ppeConfig.logout();
        // #endregion
      });
    });
  }

  verifyModifiedZipCode() {
    describe('Modify the zip code to verify ciy, county and state in SIS Exchange', () => {
      it('Modify Zip code for patient and verify city, county and state details auto populate', () => {
        // #region - verifying modified city,count,state,zip code in patient details tab

        cy.cGroupAsStep('Select Scheduling Desktop in SIS Exchange');
        cy.visit(Cypress.env('ppeURL'));
        ppeLogin.login(
          UserList.GEM_USER_2[0],
          UserList.GEM_USER_2[1],
          OrganizationList.GEM_ORG_2
        );
        ppeConfig.selectOptionInUserMenuDropdown(
          OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
        );
        appReq.selectPatientInSurgeryScheduling(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
            .FirstName
        );
        appReq.clickFooterButtons(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.FOOTER_BUTTONS
            .NEXT_BUTTON[0]
        );
        appReq.enterZipCodeInPatientDetails(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails
        );
        appReq.verifyCityCountyStateInPatientDetails(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails
        );
        appReq.clickFooterButtons(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
        );
        ppeConfig.logout();
        // #endregion
      });
    });
  }
}
