import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import Login from '../../../../app-modules-libs/sis-exchange/login/login';
import Configuration from '../../../../app-modules-libs/sis-exchange/configuration/configuration';

import { AppointmentCreationTcId276995 } from './scenarios/tcid-276995.sc';
import { CaseRequestDenyTcId276995 } from '../../sis-office/ditl/scenarios/tcid-276995.sc';

/* instance variables */
const appointmentCreation = new AppointmentCreationTcId276995();
const caseRequestDeny = new CaseRequestDenyTcId276995();
const ppeConfig = new Configuration();

/*****************Test Script Validation Details **********************
 * New County field added in sis exchange and should map in sis office case request,patient details and vice-versa
 * *Script Execution Approach -
 * 1. Login into sis exchange application and create the appointment with attachment.
 * 2. Navigate to scheduling desktop page and verify the labels, case status related checkbox, text, print icon,trackers.
 * 3. click on the time slot in grid and verify field names, fill all the data for appointment creation.
 * 4. Login into sis office application, select the case in case request page
 * 5. Navigate back to sis office ,modify zip code and verify new city,county,state as per the zip code.
 * 6. Verify the appointment data in Request Information tab and attachments.
 * 7. Verify the deny request popup on click deny button in Request Information tab.
 * 8. Login into SIS Exchange application and verify the case status of denied case.
 * 9. Navigate to appointment history and verify the case status as denied.
 * 10.Navigate to scheduling desktop and update the denied case.
 * 11.Navigate to appointment history and verify case status as pending.
 */

describe(
  `Verification of Case status as "Denied" in appointment history for created SIS Exchange Cases`,
  {
    tags: ['ditl', 'ppe', 'US#277580', 'TC#276995'],
  },
  () => {
    before(`Launching Web Application`, function () {
      cy.visit(Cypress.env('ppeURL'));
      /**********Login To PPE Application***********/
      const ppeLogin = new Login();
      ppeLogin.login(
        UserList.GEM_USER_3[0],
        UserList.GEM_USER_3[1],
        OrganizationList.GEM_ORG_3
      );
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      ppeConfig.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        appointmentCreation.ppeAppointmentCreation();
        caseRequestDeny.verifyDenyRequest();
        appointmentCreation.verifyDeniedCaseStatus();
        appointmentCreation.verifyUpdatedDeniedCase();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
