import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { td_login_verification_tcid_276972 } from '../../../../../fixtures/sis-exchange/ditl/login-verification-tcid-276972.td';

import sisExchangeLogin from '../../../../../app-modules-libs/sis-exchange/login/login';

/* instance variables */
const sisExchange = new sisExchangeLogin();

export class SisExchangeTcId276972 {
  verifyUiLoginErrorMessage() {
    it('Verify SIS-Exchange Login Error messages for invalid userName/Password combinations', () => {
      verifyUnsuccessfulLogin();
    });

    it('Verify SIS-Exchange Successful login', () => {
      verifySuccessfulLogin();
    });
  }
}

function verifyUnsuccessfulLogin() {
  // #region Visit Sis exchange, verify logo, application information and Sis exchange title

  cy.cGroupAsStep(
    'Visit Sis exchange, verify logo, application information and Sis exchange title'
  );
  sisExchange.verifySisLogo();
  sisExchange.verifyApplicationInformationLogo();
  sisExchange.verifySisExchangeTitle();
  // #endregion

  // #region Verify login button, verify copy right messages and verify User name field, Password field default as blank

  cy.cGroupAsStep(
    'Verify login button, verify copy right messages and verify User name field, Password field default as blank'
  );
  sisExchange.verifyUserNameAndPasswordAsBlank();
  sisExchange.verifyLoginButton();
  sisExchange.verifyCopyRightMessage();
  // #endregion

  // #region Verify login error messages when invalid userName/password combination is provided

    cy.cGroupAsStep(
      'Verify login error messages when invalid userName/password combination is provided'
    );
    sisExchange.verifyInvalidLogin(td_login_verification_tcid_276972.UserLogin);
    // #endregion
}

function verifySuccessfulLogin() {
  // #region Verify login error message is not displayed by documenting valid user name and valid password

  cy.cGroupAsStep(
    'Verify login error message is not displayed by documenting valid user name and valid password'
  );
  sisExchange.login(
    UserList.GEM_USER_3[0],
    UserList.GEM_USER_3[1],
    OrganizationList.GEM_ORG_3
  );
  sisExchange.verifyLoginErrorMessage(false);
  // #endregion
}
