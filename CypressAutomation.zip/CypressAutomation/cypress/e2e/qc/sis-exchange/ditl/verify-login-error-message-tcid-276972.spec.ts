import Configuration from '../../../../app-modules-libs/sis-exchange/configuration/configuration';

import { SisExchangeTcId276972 } from './scenarios/tcid-276972.sc';

/* instance variables */
const sisExchange = new SisExchangeTcId276972();
const sisExchangeConfiguration = new Configuration();

/*****************Test Script Validation Details **********************
 * 1.Enter the SIS Exchange URL and  login page should be displayed.
 * 2.Verify the login page is displayed ,sis logo, application information logo  "?"
 * 3.Verify text as SIS Exchange, User Name, Password is displayed blank, Login button at the bottom in login page
 * 4.Verify copy right information in login page
 * 5.Enter invalid Username, invalid Password and verify error message
 * 6.Enter valid Username, invalid Password and verify error message
 * 7.Enter valid Username, invalid Password and verify error message
 * 8.Enter invalid Username, valid Password and verify error message
 * 9.Enter correct username & correct Password Check the login page.
 */

describe(
  'Verify error message in sis exchange application login page',
  { tags: ['ditl', 'ppe', 'TC#276972', 'US#278353'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /** Launch the SIS Exchange application  */
      cy.visit(Cypress.env('ppeURL'));
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisExchangeConfiguration.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {
        sisExchange.verifyUiLoginErrorMessage();
      }
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => undefined
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
