import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { DictionaryItemTcid264635 } from './scenarios/tcid-264635.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

// SHIFT + ALT + O - Organizing the import
/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify the new Dictionary item Gender Identity in Dictionaries
 * Script Execution Approach -
 * 1. Navigating to User Icon --> Application Settings
 * 2. Search for Dictionaries and search Gender Identity
 * 3. Validate Show Inactive toggle, Item button is available at top right side, Item, Active columns
 * 4. Verify six items displayed, item and shown count at right bottom, verify item, count value should be 6
 * 5. Click Add Item button and observe that a empty text field is displayed with Yes, No toggles (By default, toggle is selected as Yes)
 * 6. Add item should not except data more then 100 char.
 * 7. Add items with yes toggle and no toggle, verify shown and item count for shown inactive as No.
 * 8. verify item count for shown inactive as Yes.
 * 9. Verify duplicate name warning while adding duplicate item.
 * 10. Add item with active toggle yes and verify its added in chronological order.
 * 11. Logout
 ************************************************************************/

/* instance variables */
const dictionaryItem = new DictionaryItemTcid264635();

describe(
  'Verifying Patient Details: Gender Identity Functionality',
  {
    tags: ['application-settings', 'US#189158', 'TC#264635'],
  },
  () => {
    before('Launching Web Application', function () {
      // Login To Application

      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_7, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {
        undefined;
      }
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        dictionaryItem.verifyDictionaryGenderInputUI();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => {}
    );
  }
);
