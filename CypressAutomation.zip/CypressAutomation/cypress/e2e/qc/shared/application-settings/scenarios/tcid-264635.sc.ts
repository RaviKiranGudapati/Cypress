import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { td_dic_itm_gender_input_tcid_264635 } from '../../../../../fixtures/shared/application-settings/dic-itm-gender-input-tcid-264635.td';

import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';

/* instance variables */
const nursingConfiguration = new NursingConfiguration();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const sisOfficeDesktop = new SISOfficeDesktop();

/* const values */
const number100 = 100;

export class DictionaryItemTcid264635 {
  verifyDictionaryGenderInputUI() {
    describe('Validate Show Inactive toggle, Item button, Item, Active columns, dic items displayed and verify the duplicate items functionality ', () => {
      it('Validate toggle,button, Items, dic items displayed', () => {
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.DICTIONARY.DICTIONARY[0]
        );

        cy.cGroupAsStep(
          'Validate Show Inactive toggle, Item button is available at top right side, Item, Active columns'
        );

        nursingConfiguration.selectDictionary(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.Dictionary[0]
        );
        nursingConfiguration.verifyDictionaryUI(
          OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE[0]
        );
        nursingConfiguration.verifyDictionaryUI(
          OR_NURSING_CONFIGURATION.DICTIONARY.ADD_ITEM[0]
        );
        nursingConfiguration.verifyDictionaryUI(
          OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_HEADER[0]
        );
        nursingConfiguration.verifyDictionaryUI(
          OR_NURSING_CONFIGURATION.DICTIONARY.ITEM_HEADER[0]
        );

        cy.cGroupAsStep('Show inactive should be selected as No ');

        nursingConfiguration.verifyDictionaryActiveToggle(
          OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE[0],
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.ShowInactive[1]
        );

        cy.cGroupAsStep(
          'Verify six items displayed, item and shown at right bottom, verify item value should be 6 '
        );

        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[0]
        );
        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[1]
        );
        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[2]
        );
        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[3]
        );
        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[4]
        );

        cy.cGroupAsStep(
          'Click Add Item button and observe that a empty text field is displayed with Yes, No toggles '
        );

        nursingConfiguration.addItemBtn();
        nursingConfiguration.verifyDictionaryUI(
          OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[0]
        );
        nursingConfiguration.verifyDictionaryUI(
          OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[0]
        );
        nursingConfiguration.verifyDictionaryActiveToggle(
          OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[0],
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.ActiveButton[0]
        );
        nursingConfiguration.clickDictionaryInActiveLabel();

        cy.cGroupAsStep(
          'Go to other section and come back to Gender Identity dictionary check empty text field with Yes, No toggles are not displayed'
        );

        nursingConfiguration.selectDictionary(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.Dictionary[1]
        );
        nursingConfiguration.selectDictionary(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.Dictionary[0]
        );
        nursingConfiguration.verifyDictionaryLabels();

        cy.cGroupAsStep('Verify maxlength should be 100');

        nursingConfiguration.addItemBtn();
        nursingConfiguration.verifyMaxLength(number100);
        nursingConfiguration.clickDictionaryInActiveLabel();

        cy.cGroupAsStep(
          'Click add item and add more Gender Identities, one with Yes toggle and 2 with No toggle'
        );

        nursingConfiguration.addDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.Dictionary[0],

          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[5]
        );
        nursingConfiguration.addDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.Dictionary[0],

          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[6]
        );
        nursingConfiguration.addDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.Dictionary[0],

          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[7]
        );

        cy.cGroupAsStep('Verify these items are saved');

        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[5]
        );

        cy.cGroupAsStep(
          'Select Show Inactive toggle as Yes and check all the active & inactive items are displayed '
        );

        nursingConfiguration.selectShowInactiveToggle(true);
        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[6]
        );
        nursingConfiguration.verifyDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[7]
        );

        cy.cGroupAsStep(
          'Now select Show Inactive toggle as No and observe that only active items are displayed, verify items, shown at bottom'
        );

        nursingConfiguration.selectShowInactiveToggle(false);

        cy.cGroupAsStep(
          'Verify System should display the duplicate text for duplicate items'
        );

        nursingConfiguration.addItemBtn();
        nursingConfiguration.addItemInput(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[6]
        );
        nursingConfiguration.clickDictionaryInActiveLabel();

        nursingConfiguration.confirmWarningDialog();

        cy.cGroupAsStep(
          'Change the Name in the text field Observe that duplicate warning is removed and entered data is saved in chronological order'
        );

        nursingConfiguration.addItemInput(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[8]
        );

        nursingConfiguration.verifyShowInActiveLabels(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[8]
        );

        cy.cGroupAsStep(
          'Click Show Inactive Yes toggle, Select Inactive Item. Click on Active column "toggle" Yes button and verify'
        );

        nursingConfiguration.selectShowInactiveToggle(true);
        nursingConfiguration.clickDictionaryItem(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[6]
        );
        nursingConfiguration.selectActiveToggle(YesOrNo.yes);
        nursingConfiguration.verifyShowInActiveLabels(
          td_dic_itm_gender_input_tcid_264635.DictionaryInfo.DictionaryItem[6]
        );

        cy.cGroupAsStep(
          'Click Show Inactive No toggle, verify items, shown at the bottom'
        );

        nursingConfiguration.selectShowInactiveToggle(false);

        sisOfficeDesktop.selectSisLogo();
      });
    });
  }
}
