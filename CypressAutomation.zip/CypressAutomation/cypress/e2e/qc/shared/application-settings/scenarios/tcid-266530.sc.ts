import { EnableOrDisable } from '../../../../../support/common-core-libs/application/common-core';
import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';

import { td_Outbound_CCDA_tcid_266530 } from '../../../../../fixtures/shared/application-settings/outboundCCDA-disabled-tcid-266530.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import ChartsFacesheet from '../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';

import { OutboundCCDATcId266228 } from './tcid-266228.sc';
import {
  NursingDept,
  MyTasks,
} from '../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

/* instance variables */
const nursingConfiguration = new NursingConfiguration();
const nursingConfLayout = new NursingConfigurationLayout();
const enterpriseConfig = new EnterpriseConfiguration();
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const chartsFacesheet = new ChartsFacesheet();
const scheduleGrid = new ScheduleGrid();
const outboundCCDA = new OutboundCCDATcId266228();

/* const values */
const featureId = 145;

export class OutboundCCDATcId266530 {
  verifyCCDACodeColNotPresent(dicName: string) {
    nursingConfiguration.selectReportingCodesItem(dicName);
    nursingConfiguration.verifyCCDACodeCol(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[0],
      false
    );
  }

  disableAndVerifyReportingCodesCCDACodeCol() {
    describe('To Disable outbound CCDA from Add On Features and in Enterprise Settings', () => {
      it('Verify CCDA Code Column un-presence in Reporting Codes', () => {
        // #region - Enable Outbound CCDA from Unreleased feature from Application settings

        cy.cGroupAsStep(
          'Enable Outbound CCDA flag in Add on features > Unreleased feature'
        );
        cy.enableUnreleasedFeature(featureId);
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion

        // #region - Disable Outbound CCDA from Enterprise settings, Facility Management

        cy.cGroupAsStep(
          'Disable Outbound CCDA from enterprise settings Internal Tab'
        );
        outboundCCDA.navigateToInternalTab(OrganizationList.GEM_ORG_4);
        enterpriseConfig.verifyOutboundCCDAFeature(true);
        enterpriseConfig.verifyOutboundCCDAState();
        enterpriseConfig.togglesFeaturesInInterfacesInternalTab(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.OUTBOUND_CCDA.FLAG[0],
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERFACES
            .DISABLE[0]
        );
        enterpriseConfig.switchToFacilityFromEnterprise(
          OrganizationList.GEM_ORG_4
        );
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion

        // #region - Verify gateway config and Tobacco use in Reporting codes

        cy.cGroupAsStep(
          'Verify SIS Gateway Configuration is disabled and no Tobacco Use in Reporting codes'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        outboundCCDA.verifyGatewayConfigTobaccoUseInReportingCodes(
          EnableOrDisable.disable,
          false
        );
        // #endregion

        // #region - Verify CCDA Code Column is not displayed in Reporting codes

        cy.cGroupAsStep(
          'Verify No CCDA Code Col displayed in Reporting codes Dictionary Items'
        );
        nursingConfLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.REPORTING_CODES[0]
        );
        this.verifyCCDACodeColNotPresent(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.RACE[0]
        );
        this.verifyCCDACodeColNotPresent(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.LANGUAGE[0]
        );
        this.verifyCCDACodeColNotPresent(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.ETHNICITY[0]
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  addDictionaryItemsAndVerifyInReportingCodes() {
    describe('To Add new Dictionary items and verify them in Reporting codes', () => {
      it('Verify CCDA Code Column un-presence in Reporting Codes', () => {
        scheduleGrid.verifyRoomInScheduleGrid();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.DICTIONARIES.DICTIONARIES_TEXT[0]
        );

        // #region - Add new dictionary items for Race, Language and Tobacco Use
        cy.cGroupAsStep(
          'Add new dictionary item in Application Settings - Dictionaries for Race and Language and Tobacco Use'
        );
        nursingConfiguration.addDictionaryItem(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.RACE[0],
          td_Outbound_CCDA_tcid_266530.DictionaryInfo[1].Item
        );
        nursingConfiguration.addDictionaryItem(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.LANGUAGE[0],
          td_Outbound_CCDA_tcid_266530.DictionaryInfo[2].Item
        );
        nursingConfiguration.addDictionaryItem(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.TOBACCO_USE[0],
          td_Outbound_CCDA_tcid_266530.DictionaryInfo[3].Item
        );
        // #endregion

        // #region - Verify new dictionary items added in Race and Language dictionaries in Reporting codes
        cy.cGroupAsStep(
          'Verify values added in Race and Language dictionaries in Reporting codes'
        );
        nursingConfLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.REPORTING_CODES[0]
        );
        nursingConfiguration.verifyNewDicItemsInReportingCodes(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.RACE[0],
          td_Outbound_CCDA_tcid_266530.DictionaryInfo[1].Item
        );
        nursingConfiguration.verifyNewDicItemsInReportingCodes(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.LANGUAGE[0],
          td_Outbound_CCDA_tcid_266530.DictionaryInfo[2].Item
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyAndAddNewTobaccoItemInPreAdQXInSISCharts() {
    describe('To add and verify new Tobacco item in Pre-Admit QX dropdown', () => {
      it('Add and verify new Tobacco item in Pre-Admit Qx', () => {
        scheduleGrid.verifyRoomInScheduleGrid();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.closeNotificationIcon();

        // #region - Add Pre-Admit QX template

        cy.cGroupAsStep(
          'Navigate to Face sheet, My tasks, Pre-Admission Qx and add Worklist'
        );
        sisChartsDesktop.selectPatientFromPatientList(
          td_Outbound_CCDA_tcid_266530.PatientInfo
        );
        chartsFacesheet.selectDepartment(NursingDept.pre_operative);
        chartsFacesheet.waitToLoadContents(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS
            .CONSENTS_HEADER[0]
        );
        chartsFacesheet.selectMyTasks(MyTasks.pre_admit);
        chartsFacesheet.waitToLoadContents(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE[0]
        );
        chartsFacesheet.addWorkList(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ALL_WORKLISTS[0],
          td_Outbound_CCDA_tcid_266530.PreAdQxInfo.WorklistName
        );
        chartsFacesheet.waitToLoadQuestionnaire();
        // #endregion

        // #region - Select Tobacco Dictionary items in Qx, Add new item and verify

        cy.cGroupAsStep('Add New Item and verify new Tobacco item');
        chartsFacesheet.selectValInPreAdQxDropdown(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.ALCOHOL[0],
          td_Outbound_CCDA_tcid_266530.PreAdQxInfo.Alcohol
        );
        chartsFacesheet.waitToLoadQuestionnaire();
        chartsFacesheet.selectValInPreAdQxDropdown(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0],
          td_Outbound_CCDA_tcid_266530.PreAdQxInfo.Tobacco
        );
        chartsFacesheet.waitToLoadQuestionnaire();
        chartsFacesheet.addNewItemInDictionary(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.DRUG_USE[0],
          td_Outbound_CCDA_tcid_266530.DictionaryInfo[4].Item
        );
        chartsFacesheet.waitToLoadQuestionnaire();
        chartsFacesheet.verifyDisplayedValInPreAdQxDropdown(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0],
          td_Outbound_CCDA_tcid_266530.PreAdQxInfo.Tobacco
        );
        chartsFacesheet.addNewItemInDictionary(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0],
          td_Outbound_CCDA_tcid_266530.DictionaryInfo[5].Item
        );
        chartsFacesheet.waitToLoadQuestionnaire();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion
      });
    });
  }
}
