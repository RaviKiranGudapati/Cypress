import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { OutboundCCDATcId266530 } from './scenarios/tcid-266530.sc';

/* instance variables */
const outboundCCDADisable = new OutboundCCDATcId266530();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Disable Outbound CCDA feature flag from Enterprise settings Facility Management --> Interfaces
 * 2. Verify Disabled Gateway settings and No Tobacco Use in Reporting Codes.
 * 3. Verify No CCDA Code column in reporting codes for Dictionary items
 * 4. Add new dictionary items and verify them in reporting codes.
 * 5. Navigate to SIS Charts --> Face sheet --> Pre-Operative --> My Tasks-->PRE-ADMIT-->Questionnaire --> Add Work list.
 * 6. Verify Add New Item and new dropdown items in Tobacco Use in Pre-Admit Qx
 * 7. Select the value in Tobacco Use, complete the questionnaire and verify the displayed value
 */

describe(
  'Verify Dictionary Items and patient workflows follow current flows when Outbound CCDA is disabled',
  {
    tags: ['application-settings', 'outbound-ccda', 'US#254862', 'TC#266228'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        outboundCCDADisable.disableAndVerifyReportingCodesCCDACodeCol();
        outboundCCDADisable.addDictionaryItemsAndVerifyInReportingCodes();
        outboundCCDADisable.verifyAndAddNewTobaccoItemInPreAdQXInSISCharts();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
