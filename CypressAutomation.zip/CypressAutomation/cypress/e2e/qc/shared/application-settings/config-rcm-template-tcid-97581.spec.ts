import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { RevCycleManagerTcId97581 } from './scenarios/tcid-97581.sc';

// SHIFT + ALT + O - Organizing the import
/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verifying all the functionality of Revenue Cycle Manager from Application Settings
 * Script Execution Approach -
 * 1. Navigating to User Icon --> Application Settings
 * 2. Search for Revenue Cycle Manager and click on it
 * 3. Validate background
 * 4. Create one new data and Validate data is saved
 * 5. Validate look and feel (UI)
 * 6. Validate Cancel button functionality in Add Popup window
 * 7. Validate the functionality of Days From Post/Transfer field
 * 8. Validate duplicate message on duplicate entry
 * 9. Validate sorting of revenue cycle manager list items
 * 10. Edit the existing data and validate the newly edited data is saved
 * 11. Logout
 ************************************************************************/

const revCycleManager = new RevCycleManagerTcId97581();

describe(
  'Verifying Template Creation for Revenue Cycle Manager under Configuration in Application Settings',
  {
    tags: [
      'application-settings',
      'US#91610',
      'US#91611',
      'US#91612',
      'US#91613',
      'TC#97581',
    ],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {
        // Verify Background color, Header And Sub Header, Page Load Text and Labels in RCM Page
        revCycleManager.verifyUI();
      }
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        // Verify Add, Edit, Duplicate and Sorting Functionality in RCM Page
        revCycleManager.verifyAddEditDuplicateSorting();

        // Verify Done button, Cancel button and Days From Post Transfer field functionality
        revCycleManager.verifyDoneCancelButtonAndDaysFromPostTransfer();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
