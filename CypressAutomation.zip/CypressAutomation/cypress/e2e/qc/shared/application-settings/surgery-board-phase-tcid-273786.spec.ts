import { TrackerBoard } from '../../../../app-modules-libs/patient-tracking/tracking-board';

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

/* As in azure enviornment we are unable to login/logout with API. Hence, commented the code */
import { UserLogin } from '../../../../test-data-models/core/user-info.model';
import { SurgeryBoardTrackerTcId273786 } from './scenarios/tcid-273786.sc';

/* instance variables */
const trackerBoard = new TrackerBoard();
const surgeryBoardTrackerScenarios = new SurgeryBoardTrackerTcId273786();

/*****************Test Script Validation Details **********************
 * This script uses seed data for creating 10 patients.
 * Script Execution Approach -
 * 1. Login to sis-complete application
 * 2. Document the patients in different departments in sis-office and sis-charts when phase is enabled.
 * 3. Login to patient tracking url
 * 4. Verify all patients in surgery board tracker with valid details.
 */

describe(
  'Verify the checkpoint permission for user to access the Preference card',
  {
    tags: ['patient-tracking', 'US#196473', 'TC#273786'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_PHASE_001, userLogin);
    });

    // After Each test (it), actions to be performed

    after('Logout', () => {
      trackerBoard.logout();
    });

    describe('Precondition', () => {
      surgeryBoardTrackerScenarios.preCondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        surgeryBoardTrackerScenarios.verifyPatientsData();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
