import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { FacesheetTcId264050 } from './scenarios/tcid-263136.sc';

/*instance variables*/
const facesheet = new FacesheetTcId264050();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to application, navigate to application settings and search for Fee Schedule in Configuration.
 * 2. Add new CPT Text without code and mark the status as billable, navigate back to contracts.
 * 3. Create a contract1 and click on review/edit chevron and check the newly created CPT code in search should be displayed without code.
 * 4. Navigate back to business desktop, schedule grid and create a patient with all the required data and in case details search for the CPT text and select.
 * 5. Navigate to Nursing desktop, click on the created patient case and discharge with the outside facility as case status performed.
 * 6. Navigate back to business desktop, and in the cases to code tracker and select the patient check for CPT code should be displayed without code.
 * 7. Navigate to schedule grid, click on patient 1 facesheet, In my tasks click on charge entry, click on add procedures and check for CPT data and verify.
 * 8. Create Patient 2 in FORS facility, and give all the mandatory data while creating and check for free text CPT and add.
 * 9. Navigate to cases to code after discharging, select period and batch click on patient and check for free text CPT.
 * 10. Document all the mandatory data in the cases to code and click on ready to bill.
 * 11. Navigate to schedule grid, click on patient 2 facesheet, In my tasks click on charge entry, click on add procedures and check for CPT data and verify.
 * 12. Logout from the application.
 */

describe(
  ' Verify Fee Schedule Configuration-Free Text Procedure Codes in Fee schedule and Contracts>>Review and Edit table and Case creation ',
  { tags: ['fee-schedule', 'TC#264050', 'US#263136'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_13[0],
        Password: UserList.GEM_USER_13[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_13, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        facesheet.verifySampleFeeSchedule();
        facesheet.verifyCaseDetails();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
