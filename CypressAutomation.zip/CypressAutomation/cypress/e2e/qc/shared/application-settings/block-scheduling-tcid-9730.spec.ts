import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { BlockScheduleTcId9730 } from './scenarios/tcid-9730.sc';

/* instance variables */
const blockSchedule = new BlockScheduleTcId9730();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to the application
 * 2. Navigate to nursing configuration page
 * 3. Select configuration Block scheduling
 * 4. Create blocks
 * 5. Verify the block error massages.
 * 6. Verify weekly and monthly toggle button functionality.
 * 7. Verify data selected for block is saved.
 * 8. Create a block and verify it is visible on the block schedule for start and end date.
 * 9. Logout from application.
 */

describe(
  'Block scheduling:Verifying positive and negative block utilization',
  { tags: ['block-schedule', 'TC#87358', 'US#261967'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        blockSchedule.VerifyBlockScheduleWeeklyRadioButtonFunctionality();
        blockSchedule.VerifyMonthlyRadioButtonFunctionality();
        blockSchedule.createWeeklyBlocksFromBlockSchedulingConfigurations();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
