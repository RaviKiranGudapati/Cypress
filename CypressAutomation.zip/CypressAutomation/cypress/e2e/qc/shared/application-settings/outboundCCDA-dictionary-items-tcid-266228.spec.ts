import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { OutboundCCDATcId266228 } from './scenarios/tcid-266228.sc';

/* instance variables */
const outboundCCDAEnable = new OutboundCCDATcId266228();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Verify new Outbound CCDA feature flags from Add On Features --> Unreleased and from Enterprise settings Facility Management --> Interfaces
 * 2. Enable Outbound CCDA from Add on Features and Enterprise Settings and verify the Gateway settings and Tobacco Use in Reporting Codes.
 * 3. Verify new CCDA Code column in reporting codes and verify CCDA code can be added
 * 4. Select items having CCDA code in Patient details and verify the displayed items in Face sheet --> Patient Details tab.
 * 5. Navigate to SIS Charts --> Face sheet --> Pre-Operative --> My Tasks-->PRE-ADMIT-->Questionnaire --> Add Work list.
 * 6. Verify item mapped with CCDA code in reporting codes is displayed in dropdown items in Tobacco Use in Pre-Admit Qx
 * 7. Select the value in Tobacco Use, complete the questionnaire and verify the displayed value
 * 8. Disable Outbound CCDA feature and verify Gateway Settings is disabled and Tobacco Use is not displayed in Reporting codes
 */

describe(
  'Verify new dictionary items for Race, Ethnicity, Language and Tobacco Use when Outbound CCDA is enabled ',
  {
    tags: ['application-settings', 'outbound-ccda', 'US#254862', 'TC#266228'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        outboundCCDAEnable.enableFeature();
        outboundCCDAEnable.verifyConfigDictionaryItems();
        outboundCCDAEnable.addDicItemsAndVerifyInPatientDetailsTab();
        outboundCCDAEnable.verifyTobaccoUseInPreAdQxInSISCharts();
        outboundCCDAEnable.disableFeature();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
