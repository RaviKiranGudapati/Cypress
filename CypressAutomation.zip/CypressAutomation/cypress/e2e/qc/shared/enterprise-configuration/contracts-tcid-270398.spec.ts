import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { EnterpriseContractsTcId270398 } from './scenarios/tcid-270398.sc';

/* instance variables */
const enterpriseContracts = new EnterpriseContractsTcId270398();

/*****************Test Script Validation Details **********************
 * * Verify Discounts option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name.
 * 3. Verify Contracts feature is displaying under Enterprise Build section.
 * 4. Ensure shared Fee schedule and transaction code are available.
 * 5. Adding new Contract at enterprise
 * 6. Validating the UI and adding a new contract
 * 7. Make sure the contract is not preserved after cancelling in the Add popup.
 * 8. After clicking "Done" in the Add window, be sure the contract was saved
 * 9. Verify the Transaction code, WriteOff Group Code and WriteOff Reason Code default behavior.
 * 10.Verify procedure details under Review/Edit tab.
 * 11.Verify contract details and under Posting options
 * 12.Verify the columns names and procedure details under Review/Edit
 * 13.Under Configuration tab, verify the Discounts feature option
 * 14.Select Include Enterprise Items Toggles to Yes and verify the toggles saved conditions
 */

describe(
  'Verify new feature Discounts under Configuration tab and Enterprise Build',
  {
    tags: ['enterprise-configuration', 'US#237466', 'TC#270398'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed

    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseContracts.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseContracts.verifyContractFeatureUnderEnterpriseBuild();
        enterpriseContracts.contractFeeScheduleType();
        enterpriseContracts.percentageOfBilledCharges();
        enterpriseContracts.contractConfigurationTab();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
