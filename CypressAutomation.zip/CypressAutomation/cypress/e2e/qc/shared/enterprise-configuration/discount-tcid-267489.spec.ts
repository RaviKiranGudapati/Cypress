import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseDiscountTcId267489 } from './scenarios/tcid-267489.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseDiscountConfig = new EnterpriseDiscountTcId267489();

/*****************Test Script Validation Details **********************
 * * Verify Transaction code option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name
 * 3. Set Include Enterprise Items to Yes and Allow add to Configuration to Yes for Discounts and Transaction code to gem_Org003
 * 4. Set Include Enterprise Items to Yes and Allow add to Configuration to No for Discounts and Transaction code to gem_Org004
 * 5. Set Include Enterprise Items to No for Discounts and Transaction code to gem_Org005
 * 6. Add new Transaction code and map to new DiscountA(Documents all the fields) at Enterprise level.
 * 7. Change login location to gem_Org003, verify state of Add button and shared Discounts from Enterprise.
 * 8. Add new DiscountB at gem_Org003, check the newly added discount is not shared to Enterprise from facility and the same code at facility.
 * 9. Update dropdown value for DiscountB and cross verify the updated DiscountB at gem_Org003
 * 10.Change login location to gem_Org004, verify that Add button must be in disable state.
 * 11.Change login location to gem_Org005, when sharing is disable Enterprise Discount items should not be present at gem_Org005
 * 12.Add new DiscountC at Enterprise and enable sharing only for Discount at gem_Org005 and check the shared Discount at the gem_Org005
 * 13.Check the dropdown value should be 'Select Items' as sharing is turned off for Transaction code at Enterprise.
 * 14.From Facility Management Enable sharing for Discount, change login location to gem_Org005 and check shared discounts are displaying at gem_Org005 from Enterprise
 */

describe(
  'Verify sharing functionality of Discounts (Enterprise and Facility level)',
  {
    tags: ['enterprise-configuration', 'US#237466', 'TC#267489'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    //After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseDiscountConfig.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseDiscountConfig.verifyDiscountsWhenSharingIsEnabled();
        enterpriseDiscountConfig.verifyAddButtonStateWhenConfigurationIsNO();
        enterpriseDiscountConfig.verifyDiscountsWhenSharingDisabled();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
