/************************Revision History*************************** *
 * 09/12/22, Arushi Agarwal, Nikitan Chawhan designed the new spec based on the Test Case - TCID - 262407.
 */

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseFeeScheduleTcId262507 } from './scenarios/tcid-262407.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseFeeSchedule = new EnterpriseFeeScheduleTcId262507();

/* Test Script Validation Details *****
 * Pre-Condition-
 * Shared dictionaries/configurations is disable mode and enterprise build is not visible
 * Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management,in Internal tab shared dictionaries/configurations will be enable so that enterprise build will be visible
 * 3. Select fee schedule in enterprise build,add the CPT code and verify the fields available for adding procedure details
 * 4. Verify the default values in the fields as well the default toggle behavior for different kinds of procedure
 * 5. Verifying the options availability in Configuration tab and the default behavior of the toggle
 * 6. Verifying the addition,updation,deletion of Hcpcs code procedure Verifying the addition,updation,deletion of Gcode procedure
 * 7. Verifying the addition,updation,deletion of Gcode procedure
 * 8. Verifying the access permission for the non-admin users
 */

describe(
  'Verify Configurations tab, Fee schedule option at Enterprise settings & addition, updation, deletion of G code, HCPCs codes at Fee schedule Enterprise settings',
  {
    tags: ['enterprise-configuration', 'US#262539', 'TC#262407'],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        /*** Verify fee schedule enable feature,verifying the addition, update and deletion of procedure codes and also verifying access for non admin users ****/
        enterpriseFeeSchedule.verifyFeeScheduleEnableFeature();
        enterpriseFeeSchedule.verifyGCodeFunctionality();
        enterpriseFeeSchedule.verifyHcpcsCodeFunctionality();
        enterpriseFeeSchedule.verifyNonAdminUserPermissions();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
