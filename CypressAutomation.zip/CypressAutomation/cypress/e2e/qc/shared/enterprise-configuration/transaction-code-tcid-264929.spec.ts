import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseTransactionCodeTcId264929 } from './scenarios/tcid-264929.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseTransactionCode = new EnterpriseTransactionCodeTcId264929();

/*****************Test Script Validation Details **********************
 * * Verify Transaction code option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name
 * 3. Verify Transaction Codes feature is displaying under Enterprise Build section.
 * 4. Verify Dictionaries and Configuration tab were visible at Enterprise settings >Facility Management tab
 * 5. Select Transaction Codes, verify Search field, Add button and default text message is displaying.
 * 6. Click on Add button and verify the Add popup window fields like helper text, Cancel and Done button.
 * 7. Click on Add button and add new code, hit cancel button. Verify the cancelled Transaction code is not saved.
 * 8. Again Add new Transaction code by hitting done button and verify the newly added code is saved.
 * 9. Search and select the newly added code and verify the Type dropdown values.
 * 10.Navigate to Facility Management and verify Transaction Codes under Configuration tab.
 * 11.Verify Include Enterprise Items and Allow Add to Configuration column hover text message.
 * 12.Verify the default behavior of Include Enterprise Items and Allow Add to Configuration.
 * 13.Select 'Yes' toggle from Include Enterprise Items and verify Allow Add to Configuration is set to 'Yes' automatically.
 */

describe(
  'Verify Transaction code feature at Enterprise build and under Configurations at Enterprise settings Facility Management tab',
  {
    tags: ['enterprise-configuration', 'US#237464', 'TC#264929'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseTransactionCode.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseTransactionCode.verifyTransactionCodeFeature();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
