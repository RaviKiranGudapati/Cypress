import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { AddOnFeaturesMfaSsoTcId265133 } from './scenarios/tcid-265133.sc';

/* instance variables */
const mfaSso = new AddOnFeaturesMfaSsoTcId265133();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into application and navigate to Schedule grid.
 * 2. Navigating to the addon features and verifying the MFA in enterprise section
 * 3. Navigating to the MFA section and verifying the MFA labels, its functionality
 * 4. Navigating to the users and verifying the email for the inactive user
 * 5. Logout from application
 */

describe(
  'Verify the MFA feature flag in application and enterprise',
  { tags: ['enterprise-configuration', 'TC#265133', 'US#255971'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        mfaSso.addOnFeaturesAppSettings();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
