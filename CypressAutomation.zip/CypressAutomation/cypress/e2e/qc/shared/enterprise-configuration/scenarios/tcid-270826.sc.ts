import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  DoneOrCancel,
  ShowOrHide,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_cbo_views_cbo_management_tcid_270826 } from '../../../../../fixtures/shared/enterprise-configuration/cbo-views-cbo-management-tcid-270826.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();

export class CBOManagementTcId270826 {
  verifyCBODetails() {
    describe('Verifying CBO Management warning message and CBO Details screen', () => {
      it('Verifying CBO Management warning message and CBO Details screen and Verifying by Deleting CBO Entities', () => {
        // #region Navigating to Enterprise location and changing CBO views flag as Show

        cy.cGroupAsStep(
          'Navigating to Enterprise location and changing CBO views flag as Show'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .CBO_CENTRALIZED_VIEWS[0],
          ShowOrHide.show
        );

        // #endregion

        // #region Adding CBO Entity and verifying warning messages in CBO Management

        cy.cGroupAsStep(
          'Adding CBO Entity and verifying warning messages in CBO Management'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0]
        );
        enterpriseConfig.addCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0],
          DoneOrCancel.done
        );
        enterpriseConfig.mapUnMapFacilityToCBO(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.verifyFacilitiesIncluded(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ADD_ON_FEATURES.ADD_ON_FEATURES_LABEL[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0]
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.mapUnMapFacilityToCBO(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.verifyDuplicateWarningCBO(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.updateCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[1]
        );
        enterpriseConfig.verifyBlankCBOEntityWarning(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[1]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ADD_ON_FEATURES.ADD_ON_FEATURES_LABEL[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0]
        );

        // #endregion

        // #region Adding CBO Entity and performing mapping in CBO details

        cy.cGroupAsStep(
          'Adding CBO Entity and performing mapping in CBO details'
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[1]
        );
        enterpriseConfig.deleteCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[1],
          YesOrNo.yes
        );
        enterpriseConfig.addCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0],
          DoneOrCancel.done
        );
        enterpriseConfig.mapUnMapFacilityToCBO(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.mapUnMapFacilityToCBO(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.addCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[1],
          DoneOrCancel.done
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.searchAndSelectItem(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].User,
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].User
        );
        enterpriseConfig.clickOnTab(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].TabName
        );
        enterpriseConfig.verifyCBOUserToggle(true, YesOrNo.yes);
        enterpriseConfig.verifyCBODetailsTab(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[1],
          true
        );
        enterpriseConfig.clickOnTab(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[1].TabName
        );
        enterpriseConfig.mapCBOEntities(
          td_cbo_views_cbo_management_tcid_270826.CBODetails[0]
        );
        enterpriseConfig.verifyCBOListInCBODetails(
          td_cbo_views_cbo_management_tcid_270826.CBODetails[0]
        );

        // #endregion

        // #region Deleting CBO entity and verifying CBO Details

        cy.cGroupAsStep('Deleting CBO entity and verifying CBO Details');
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0]
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[1]
        );
        enterpriseConfig.mapUnMapFacilityToCBO(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[1]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.searchAndSelectItem(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].User,
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].User
        );
        enterpriseConfig.clickOnTab(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[1].TabName
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0]
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0]
        );
        enterpriseConfig.deleteCBOEntity(
          td_cbo_views_cbo_management_tcid_270826.CBOManagement[0],
          YesOrNo.yes
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.searchAndSelectItem(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].User,
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].User
        );
        enterpriseConfig.clickOnTab(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[0].TabName
        );
        enterpriseConfig.verifyCBOUserToggle(true, YesOrNo.yes);
        enterpriseConfig.verifyCBODetailsTab(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[1],
          true
        );
        enterpriseConfig.clickOnTab(
          td_cbo_views_cbo_management_tcid_270826.UserManagement[1].TabName
        );
        enterpriseConfig.verifyCBOListInCBODetails(
          td_cbo_views_cbo_management_tcid_270826.CBODetails[1]
        );

        // #endregion
      });
    });
  }
}
