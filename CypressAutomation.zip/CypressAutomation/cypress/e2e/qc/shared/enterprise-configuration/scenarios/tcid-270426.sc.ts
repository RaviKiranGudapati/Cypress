import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  DoneOrCancel,
  ShowOrHide,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_contracts_tcid_270426 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-contracts-tcid-270426.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import {
  defaultWriteOffGroupCode,
  typeDropDownOptionValues,
  defaultWriteOffReasonCode,
  adjustmentTime,
  typeOptionsForGrouper,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';
import { ContractHeaders } from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();

/* const values */
const copyContractName = CommonUtils.concatenate(
  'Copy of',
  ' ',
  td_enterprise_config_contracts_tcid_270426.Contracts[0].ContractName
);
const zero = '0';
const exemptOptionsInReviewEdit = [YesOrNo.yes, YesOrNo.no];

export class EnterpriseContractsTcId270426 {
  precondition() {
    describe('Enable "Shared Dictionaries/Configurations" and verify Enterprise Build-Contracts', () => {
      it('Verifying Enterprise Build-Contracts Feature ', () => {
        // #region - Change login location to Enterprise and enable Enterprise Build - Contracts from Add On Features

        cy.cGroupAsStep(
          'Enable contracts from Add On Features under Enterprise Build'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        // #endregion

        // #region -- Change login location to enterprise and Set Shared Dictionaries/Configuration to 'Show' state

        cy.cGroupAsStep(
          'Enable Shared Dictionaries/Configuration to Show state and Verifying Contracts Feature under Enterprise Build'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        // #endregion

        // #region - verify Contracts, Fee schedule and Transaction Code under Enterprise Build

        cy.cGroupAsStep('Verify Enterprise Build Configurations');
        enterpriseConfig.verifyEnterpriseBuild(true);
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // #endregion

        // #region - Adding Transaction code at Enterprise level

        cy.cGroupAsStep(
          'Adding new Transaction code with type as WriteOff at Enterprise level'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_contracts_tcid_270426.TransactionCodeName[0]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_contracts_tcid_270426.TransactionCodeName[1]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        // #endregion

        // #region - Adding Procedure at Enterprise level

        cy.cGroupAsStep(
          'Adding new Procedure with status as billable at Enterprise level'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270426.FeeSchedules[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270426.FeeSchedules[1]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        // #endregion
      });
    });
  }

  verifyGrouperTypAtEnterprise() {
    describe('verify Addition, update and error message check for duplicate item for grouper type contract at Enterprise', () => {
      it('Add, Modify and check for error message for adding existing grouper type contracts at Enterprise level', () => {
        // #region - Add new Contract and select Grouper Contract Type from dropdown

        cy.cGroupAsStep(
          'Add new Contract, document Effective date, Expire date and Contract Type(Grouper) dropdown'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfig.addContract(
          td_enterprise_config_contracts_tcid_270426.Contracts[0],
          DoneOrCancel.done
        );
        enterpriseConfig.contractEffectiveDate(
          td_enterprise_config_contracts_tcid_270426.Contracts[0]
        );
        enterpriseConfig.contractExpirationDate(
          td_enterprise_config_contracts_tcid_270426.Contracts[0]
        );
        enterpriseConfig.selectContractType(
          td_enterprise_config_contracts_tcid_270426.Contracts[0]
        );
        // #endregion

        // #region - Document posting options dropdown fields

        cy.cGroupAsStep(
          'Document posting options dropdown fields and verify warning text'
        );
        enterpriseConfig.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfig.verifyWarningTextUnderPostingOptions();
        enterpriseConfig.selectAdjustmentTimeDropdown(adjustmentTime[1]);
        enterpriseConfig.verifyDefaultWriteOffTransactionCodeOptions(
          td_enterprise_config_contracts_tcid_270426.TransactionCodeName
        );
        enterpriseConfig.selectDefaultWriteOffTransactionCode(
          td_enterprise_config_contracts_tcid_270426.TransactionCodeName[0]
        );
        enterpriseConfig.selectDefaultWriteOffGroupCode(
          defaultWriteOffGroupCode[1]
        );
        enterpriseConfig.selectDefaultWriteOffReasonCode(
          defaultWriteOffReasonCode[1]
        );
        // #endregion

        // #region - Add fee group index and enter Reimbursement amount

        cy.cGroupAsStep(
          'Select Index as 0 and enter reimbursement amount as $10.00'
        );
        enterpriseConfig.verifyFeeGroup();
        enterpriseConfig.addFeeGroup(
          td_enterprise_config_contracts_tcid_270426.FeeGroup[0]
        );

        // #endregion

        // #region - verify shared procedure and map index value under details dropdown at Review/Edit tab

        cy.cGroupAsStep(
          'Under Review/Edit tab, select the index value to shared procedure under details column dropdown'
        );
        enterpriseConfig.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfig.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[0].CptHcpsc
        );
        enterpriseConfig.selectDetailsInReviewEdit(zero);
        enterpriseConfig.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[0]
        );
        enterpriseConfig.clearProcedureSearchInContract();
        enterpriseConfig.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[1].CptHcpsc
        );
        enterpriseConfig.selectDetailsInReviewEdit('0');
        enterpriseConfig.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[1]
        );
        enterpriseConfig.clearProcedureSearchInContract();
        //#endregion

        // #region - verify Dropdown values under Type header

        cy.cGroupAsStep(
          'Verify the Dropdown values under Type header in Review/Edit'
        );
        enterpriseConfig.verifyTypeOptionsInReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[0].CptHcpsc,
          typeOptionsForGrouper
        );
        enterpriseConfig.verifyExemptOptionsInReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[0].CptHcpsc,
          exemptOptionsInReviewEdit
        );
        // #endregion

        // #region - Navigate away and come back to verify the disable state of Contract type for saved contracts

        cy.cGroupAsStep(
          'Verify the Contract Type dropdown is enabled and user can modify the type dropdown'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfig.searchAndSelectContract(
          td_enterprise_config_contracts_tcid_270426.Contracts[0]
        );
        enterpriseConfig.selectConfigurationFirstTemplate();
        // #endregion

        // #region - Modify the fields at posting options

        cy.cGroupAsStep('Modify Reimbursement data and change dropdown values');
        enterpriseConfig.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfig.selectDefaultWriteOffTransactionCode(
          td_enterprise_config_contracts_tcid_270426.TransactionCodeName[1]
        );
        enterpriseConfig.selectDefaultWriteOffGroupCode(
          defaultWriteOffGroupCode[2]
        );
        enterpriseConfig.selectDefaultWriteOffReasonCode(
          defaultWriteOffReasonCode[2]
        );
        enterpriseConfig.enterReimbursement(
          td_enterprise_config_contracts_tcid_270426.FeeGroup[1]
        );

        // #endregion

        // #region - verify updated Reimbursement data under review/edit

        cy.cGroupAsStep(
          'Verify the updated Reimbursement amount under Details header in Review/Edit'
        );
        enterpriseConfig.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfig.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270426.FeeSchedules[0]
            .CptProcedure
        );
        enterpriseConfig.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[2]
        );
        enterpriseConfig.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270426.FeeSchedules[1]
            .CptProcedure
        );
        enterpriseConfig.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[3]
        );
        // #endregion

        // #region - Duplicate error message in add popup

        cy.cGroupAsStep(
          'Check the Duplicate error message in add popup by adding existing contract'
        );
        enterpriseConfig.clearConfigurationSearch();
        enterpriseConfig.addContract(
          td_enterprise_config_contracts_tcid_270426.Contracts[0],
          DoneOrCancel.done
        );
        enterpriseConfig.duplicateWarningInContractAddPopup();
        // #endregion

        // #region - Duplicate warning message banner

        cy.cGroupAsStep(
          'Check duplicate warning by adding existing contract in name field and verify disable states of fields'
        );
        enterpriseConfig.clearConfigurationSearch();
        enterpriseConfig.addContract(
          td_enterprise_config_contracts_tcid_270426.Contracts[1],
          DoneOrCancel.done
        );
        enterpriseConfig.contractEffectiveDate(
          td_enterprise_config_contracts_tcid_270426.Contracts[1]
        );
        enterpriseConfig.contractExpirationDate(
          td_enterprise_config_contracts_tcid_270426.Contracts[1]
        );
        enterpriseConfig.selectContractType(
          td_enterprise_config_contracts_tcid_270426.Contracts[1]
        );
        enterpriseConfig.verifyWarningBannerByClearingOrDuplicateContractName(
          td_enterprise_config_contracts_tcid_270426.Contracts[0]
        );
        // #endregion

        // #region - check for copy contract function

        cy.cGroupAsStep('Verify the functionality of create copy in Add popup');
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfig.searchAndSelectContract(
          td_enterprise_config_contracts_tcid_270426.Contracts[0]
        );
        enterpriseConfig.verifyCopyContractFields(
          td_enterprise_config_contracts_tcid_270426.Contracts[0].ContractName
        );
        enterpriseConfig.addCopyContract(
          td_enterprise_config_contracts_tcid_270426.Contracts[0],
          copyContractName
        );
        // #endregion

        // #region - Check that a copy of previously added contract is populated

        cy.cGroupAsStep(
          'Check that a copy of previously added contract is populated'
        );
        enterpriseConfig.verifyContractType(
          td_enterprise_config_contracts_tcid_270426.Contracts[0].ContractType
        );
        enterpriseConfig.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfig.verifySelectedAdjustmentTimeInContracts(
          adjustmentTime[1]
        );
        enterpriseConfig.verifySelectedTransactionCodeInContracts(
          td_enterprise_config_contracts_tcid_270426.TransactionCodeName[1]
        );
        enterpriseConfig.verifySelectedGroupCodeInContracts(
          defaultWriteOffGroupCode[2]
        );
        enterpriseConfig.verifySelectedReasonCodeInContracts(
          defaultWriteOffReasonCode[2]
        );
        // #endregion

        // #region - Verify copy contract details under Review/Edit

        cy.cGroupAsStep('Verify copy contract details under Review/Edit');
        enterpriseConfig.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfig.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270426.FeeSchedules[0]
            .CptProcedure
        );

        enterpriseConfig.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[2]
        );

        enterpriseConfig.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270426.FeeSchedules[1]
            .CptProcedure
        );
        enterpriseConfig.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270426
            .ProcedureDetailsInReviewEdit[3]
        );
        // #endregion
      });
    });
  }
}
