/**Revision History
 *Narasimha: 31-03-2023 : Corrected Wrong reference of import from DoneOrCancel
 */
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ShowOrHide,
  YesOrNo,
  DoneOrCancel,
} from '../../../../../support/common-core-libs/application/common-core';

import {
  systemDefaultTransactionCodes,
  typeDropDownOptionValues,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_transaction_code_tcid_265077 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-transaction-code-tcid-265077.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */

const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();

export class EnterpriseTransactionCodeTcId265077 {
  verifyTransactionCodeAtEnterprise() {
    describe('To verify the addition deletion and updates for transaction code options at Enterprise level', () => {
      it('Verify the transaction code addition deletion and updates for transaction code at Enterprise level', () => {
        // #region - Navigating to the Transaction code menu by enabling the Shared Dictionaries/Configurations and verifying that system default transaction codes are not available

        cy.cGroupAsStep(
          'Verifying that system default transaction codes are not available and displays warning message when adding the same'
        );

        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );

        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );

        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );

        enterpriseConfig.verifySystemDefaultCodes(
          systemDefaultTransactionCodes
        );

        // #endregion

        // #region - Verifying the default values available in the type dropdown, max length for transaction code name, warning text without name

        cy.cGroupAsStep(
          'Verifying the default values available in the type dropdown, max length for transaction code name and warning text without name'
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[0]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.verifyTransactionCodeTypeItems();

        enterpriseConfig.addTransactionCode(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[1]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.verifyTransactionCodeNameLength(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[2]
        );

        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );

        enterpriseConfig.verifyTransactionType(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[2],
          typeDropDownOptionValues[0]
        );

        enterpriseConfig.clearTransactionCodeName();

        enterpriseConfig.verifyTransactionCodeNameWarning();

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );

        // #endregion

        // #region - Verifying the updated name and type for a newly added code and warning message when adding duplicate code

        cy.cGroupAsStep(
          'Verifying the updated name and type for a newly added code and warning message when adding duplicate code'
        );

        enterpriseConfig.updateTransactionCode(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[3],
          typeDropDownOptionValues[0]
        );

        enterpriseConfig.addTransactionCode(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[0]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        //Removed the verification step as this is already implemented in clickAddTransactionDone method

        // #endregion

        // #region - Verifying that code is not available in list after deleting the code and verifying delete pop up text

        cy.cGroupAsStep(
          'Verifying that code is not available in list after deleting '
        );

        enterpriseConfig.deleteTransactionCode(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[0],
          YesOrNo.no
        );

        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[0]
        );

        enterpriseConfig.deleteTransactionCode(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[0],
          YesOrNo.yes
        );

        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[0],
          false
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );

        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265077.TransactionCode
            .TransactionCodeName[0],
          false
        );

        // #endregion
      });
    });
  }
}
