import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  DoneOrCancel,
  ShowOrHide,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_contracts_tcid_270427 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-contracts-tcid-270427.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import {
  defaultWriteOffGroupCode,
  defaultWriteOffReasonCode,
  feeScheduleTypeColumnInReviewEdit,
  adjustmentTime,
  typeOptionsForContractFeeSchedule,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';
import { ContractHeaders } from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfiguration = new EnterpriseConfiguration();

/* const values */
const exemptOptionsInReviewEdit = [YesOrNo.yes, YesOrNo.no];

export class EnterpriseContractsTcId270427 {
  precondition() {
    describe('Enable "Shared Dictionaries/Configurations" And verify Enterprise Build-Contracts', () => {
      it('Ensure shared Transaction codes, Fee schedule items are created and available at Enterprise ', () => {
        // #region - Change login location to Enterprise and enable Enterprise Build - Contracts from Add On Features

        cy.cGroupAsStep(
          'Enable contracts from Add On Features under Enterprise Build'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfiguration.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        // #endregion

        // #region - Set Shared Dictionaries/Configuration to Show state

        cy.cGroupAsStep('Set Shared Dictionaries/Configuration to Show state');
        enterpriseConfiguration.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfiguration.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_1
        );
        enterpriseConfiguration.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfiguration.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        // #endregion

        // #region - Verifying Contracts feature under Enterprise Build

        cy.cGroupAsStep('Verifying Contracts feature under Enterprise Build');
        enterpriseConfiguration.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.verifyEnterpriseBuild(true);
        enterpriseConfiguration.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        // #endregion

        // #region - Adding transactions codes at Enterprise Level

        cy.cGroupAsStep('Adding transactions codes at Enterprise Level');
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfiguration.addTransactionCode(
          td_enterprise_config_contracts_tcid_270427.TransactionCodes[0]
            .TransactionCodeOne!
        );
        enterpriseConfiguration.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfiguration.addTransactionCode(
          td_enterprise_config_contracts_tcid_270427.TransactionCodes[1]
            .TransactionCodeTwo!
        );
        enterpriseConfiguration.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfiguration.searchAndSelectTransactionCode(
          td_enterprise_config_contracts_tcid_270427.TransactionCodes[0]
            .TransactionCodeOne!
        );
        enterpriseConfiguration.selectTransactionCodeTypeItem(
          td_enterprise_config_contracts_tcid_270427.TransactionCodes[0].Type
        );
        enterpriseConfiguration.searchAndSelectTransactionCode(
          td_enterprise_config_contracts_tcid_270427.TransactionCodes[1]
            .TransactionCodeTwo!
        );
        enterpriseConfiguration.selectTransactionCodeTypeItem(
          td_enterprise_config_contracts_tcid_270427.TransactionCodes[1].Type
        );
        // #endregion

        // #region - Adding Fee Schedule at Enterprise Level

        cy.cGroupAsStep('Adding Fee Schedule at Enterprise Level');
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270427.FeeSchedules[1]
        );
        enterpriseConfiguration.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270427.FeeSchedules[0]
        );
        // #endregion
      });
    });
  }

  verifyContractsCodeFeature() {
    describe('Verify Contracts functionality under Enterprise build', () => {
      it('Verify the Contracts options at Enterprise level', () => {
        // #region - Adding new Contract and validating the functionality

        cy.cGroupAsStep('Adding new Contract and validating the functionality');
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270427.Contracts[0],
          DoneOrCancel.done
        );
        enterpriseConfiguration.contractEffectiveDate(
          td_enterprise_config_contracts_tcid_270427.Contracts[0]
        );
        enterpriseConfiguration.contractExpirationDate(
          td_enterprise_config_contracts_tcid_270427.Contracts[0]
        );
        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270427.Contracts[0]
        );
        enterpriseConfiguration.addNotesInContract(
          td_enterprise_config_contracts_tcid_270427.Contracts[0]
        );
        enterpriseConfiguration.verifyWarningTextUnderPostingOptions();
        // #endregion

        // #region - Verify column names under review edit tab

        cy.cGroupAsStep('Verify column names under review edit tab');
        enterpriseConfiguration.enterContractPercentage(
          td_enterprise_config_contracts_tcid_270427
            .ProcedureDetailsInReviewEdit[0].Details
        );
        enterpriseConfiguration.selectAdjustmentTimeDropdown(adjustmentTime[2]);
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.verifyColumnsNameUnderReviewEdit(
          feeScheduleTypeColumnInReviewEdit
        );
        // #endregion

        // #region - Verify procedure details under Review/Edit

        cy.cGroupAsStep('Verify procedure details under Review/Edit');
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270427.FeeSchedules[0]
            .CptProcedure
        );
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270427
            .ProcedureDetailsInReviewEdit[0]
        );

        // #region - Verify type options in Review/Edit

        cy.cGroupAsStep('Verify type options in Review/Edit');
        enterpriseConfiguration.verifyTypeOptionsInReviewEdit(
          td_enterprise_config_contracts_tcid_270427.FeeSchedules[0]
            .CptProcedure,
          typeOptionsForContractFeeSchedule
        );
        enterpriseConfiguration.verifyExemptOptionsInReviewEdit(
          td_enterprise_config_contracts_tcid_270427.FeeSchedules[0]
            .CptProcedure,
          exemptOptionsInReviewEdit
        );
        // #endregion

        // #region - Verify the state of contract type is disabled after navigating to some where and getting back to the respective contract

        cy.cGroupAsStep(
          'Verify the state of contract type is disabled after navigating to some where and getting back to the respective contract'
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.searchAndSelectContract(
          td_enterprise_config_contracts_tcid_270427.Contracts[0]
        );
        enterpriseConfiguration.selectConfigurationFirstTemplate();
        // #endregion

        // #region - Verify duplicate warning message in when the contract name is edited with existing contract name

        cy.cGroupAsStep(
          'Verify duplicate warning message in when the contract name is edited with existing contract name'
        );
        enterpriseConfiguration.enterContractPercentage(
          td_enterprise_config_contracts_tcid_270427
            .ProcedureDetailsInReviewEdit[1].Details
        );
        enterpriseConfiguration.selectDefaultWriteOffGroupCode(
          defaultWriteOffGroupCode[2]
        );
        enterpriseConfiguration.selectDefaultWriteOffReasonCode(
          defaultWriteOffReasonCode[2]
        );
        enterpriseConfiguration.selectDefaultWriteOffTransactionCode(
          td_enterprise_config_contracts_tcid_270427.TransactionCodes[0]
            .TransactionCodeOne!
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270427.FeeSchedules[1]
            .CptProcedure
        );

        /**
         * need to uncomment this code once bug is fixed
         */
        // enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
        //   td_enterprise_config_contracts_tcid_270427
        //     .ProcedureDetailsInReviewEdit[1]
        // );

        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270427.Contracts[0],
          DoneOrCancel.done
        );
        enterpriseConfiguration.duplicateWarningInContractAddPopup();
        // #endregion

        // #region - Observe all the options under posting options tab are disabled

        cy.cGroupAsStep(
          'Verify the warning message when contract name is cleared and try to save it'
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270427.Contracts[1],
          DoneOrCancel.done
        );
        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270427.Contracts[1]
        );
        enterpriseConfiguration.verifyWarningBannerByClearingOrDuplicateContractName(
          td_enterprise_config_contracts_tcid_270427.Contracts[0]
        );
        // #endregion

        // #region - Verify the fields under Posting option are disabled when the contact name is cleared are duplicated

        cy.cGroupAsStep(
          'Verify the fields under Posting option are disabled when the contact name is cleared are duplicated'
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfiguration.verifyStateOfPercentageOfBilledCharge(false);
        enterpriseConfiguration.verifyStateOfDefaultWriteOffReasonCode(false);
        enterpriseConfiguration.verifyStateOfDefaultWriteOffTransactionCode(
          false
        );
        enterpriseConfiguration.verifyStateOfDefaultWriteOffGroupCode(false);
        // #endregion

        // #region - Verify the fields under Review/Edit are disabled when the contact name is cleared are duplicated

        cy.cGroupAsStep(
          'Verify the fields under Review/Edit are disabled when the contact name is cleared are duplicated'
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270427.FeeSchedules[1]
            .CptProcedure
        );
        enterpriseConfiguration.verifyStateOfTypeUnderReviewEdit(false);
        enterpriseConfiguration.verifyStateOfDetailsInputFieldUnderReviewEdit(
          false
        );
        enterpriseConfiguration.verifyStateOfExemptUnderReviewEdit(false);
        // #endregion
      });
    });
  }
}
