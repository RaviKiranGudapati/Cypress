import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import {
  ExpandOrCollapse,
  ShowOrHide,
  TrueOrFalse,
} from '../../../../../support/common-core-libs/application/common-core';
import {
  YesOrNo,
  DoneOrCancel,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_transaction_code_tcid_265079 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-transaction-code-tcid-265079.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';

import { TypeDropdownOptions } from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import ChartsLogin from '../../../../../app-modules-libs/sis-charts/login/login';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();
const chartsLogin = new ChartsLogin();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const faceSheetCases = new FaceSheetCases();
const transactions = new Transactions();
const scheduleGrid = new ScheduleGrid();

/* const values */
const TransactionCodes = 'Transaction Codes';
const ApplicationSettings = 'Application Settings';
const Facility = 'Facility';
const Enterprise = 'Enterprise';

export class EnterpriseTransactionCodeTcId265079 {
  preCondition() {
    describe('Enable Share Dictionaries/Configurations under Internal tab and Selection of Toggles Yes/No options for facilities under Configuration tab ', () => {
      it('Selection of toggles under Configuration for different facilities', () => {
        cy.cGroupAsStep(
          'Enable Share Dictionaries/Configurations under Internal tab'
        );
        // #region - Enable Share Dictionaries/Configurations under Internal tab
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );

        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_CONFIGURATION.PROFILES[0]
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifySharedDictionariesConfigurationsState(
          TrueOrFalse.true
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.verifyColumnsInConfigurationsTab();
        /**
         * Added the below assertion to load the configuration page
         * and display the enterprise build options post enabling the internal tab feature
         */
        enterpriseConfig.assertToLoadConfigurationTab(
          YesOrNo.yes,
          TransactionCodes
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );

        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        /**
         * @codeRemoved - We have removed toggle internal tab method to refrain from the repetitive api calls.
         */
        enterpriseConfig.verifyEnterpriseBuild(true);
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // #endregion

        cy.cGroupAsStep(
          'Set Include Enterprise Items to Yes and Allow add to Configuration to Yes for Transaction code to gem_Org003'
        );
        // #region - Set Include Enterprise Items to Yes and Allow add to Configuration to Yes
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_CONFIGURATION.PROFILES[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );

        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          TransactionCodes
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.yes,
          TransactionCodes
        );
        // #endregion

        cy.cGroupAsStep(
          'Set Include Enterprise Items to Yes and Allow add to Configuration to No for Transaction code to gem_Org004'
        );
        // #region - Set Include Enterprise Items to Yes and Allow add to Configuration to No

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_4
        );

        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          TransactionCodes
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.no,
          TransactionCodes
        );
        // #endregion

        cy.cGroupAsStep(
          'Set Include Enterprise Items to No for Transaction code to gem_Org005'
        );
        // #region - Set Include Enterprise Items to No

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_5
        );

        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.no,
          TransactionCodes
        );
        // #endregion

        cy.cGroupAsStep('Adding Transaction codes at Enterprise level');
        // #region - Adding Transaction code
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          TypeDropdownOptions.allocation
        );
        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!,
          true
        );
        // #endregion
      });
    });
  }

  verifyTransactionCode() {
    describe('To verify sharing functionality of Transaction codes at Enterprise and Facility level', () => {
      it('Verify sharing functionality of Transaction codes at Enterprise and Facility level', () => {
        cy.cGroupAsStep('Add new transaction code at facility(GEM_ORG_3)');
        // #region - Add new transaction code
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);
        nursingConfiguration.verifyStateOfAddButton();
        // #endregion

        // #region - Adding new transaction code and verify the state of add button at facility-GEM_ORG_3
        nursingConfiguration.addTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1!
        );
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!,
          true
        );
        nursingConfiguration.verifyTextInTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!
        );
        nursingConfiguration.verifyTransactionType(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!,
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.Type!
        );
        nursingConfiguration.verifySourceFieldInTransactionCode(Facility);
        // #endregion

        cy.cGroupAsStep(
          'Verified the added transaction code one from the enterprise'
        );
        // #region - Verified the added transaction code
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!,
          true
        );
        nursingConfiguration.verifyTextInTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!
        );
        nursingConfiguration.verifyTransactionType(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!,
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.Type2[0]!
        );
        nursingConfiguration.verifySourceFieldInTransactionCode(Enterprise);
        sisOfcDesktop.selectSisLogo();
        // #endregion

        cy.cGroupAsStep('Add and Update transaction code two at enterprise');
        // #region - Add and Update transaction code
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!,
          false
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.Type2[1]!
        );
        // #endregion

        cy.cGroupAsStep('Verify added transaction code two at GEM_Org003');
        // #region - Verify added transaction code
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);
        // #endregion

        // #region - Check that facility information data is overwritten with Enterprise
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!,
          true
        );
        nursingConfiguration.verifyTextInTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!
        );
        nursingConfiguration.verifyTransactionType(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!,
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.Type2[1]!
        );
        nursingConfiguration.verifySourceFieldInTransactionCode(Enterprise);
        // #endregion

        cy.cGroupAsStep(
          'Verify added transaction codes from enterprise at facility'
        );
        // #region - Verify added transaction code added from Enterprise
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocation(OrganizationList.GEM_ORG_4);
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!,
          true
        );
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!,
          true
        );
        nursingConfiguration.verifyStateOfAddButton(false);
        // #endregion

        cy.cGroupAsStep(
          'Verify transaction code not reflecting at GemOrg_005 as Sharing is turned off'
        );
        // #region - Changing login location to facility GEM_ORG_5
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocation(OrganizationList.GEM_ORG_5);
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[0]
            .TransactionCode1?.TransactionCodeName!,
          false
        );
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!,
          false
        );
        // #endregion

        cy.cGroupAsStep('Delete transaction code one at enterprise level');
        // #region - Delete transaction code
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.deleteTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!,
          YesOrNo.yes
        );
        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[0]!,
          false
        );
        // #endregion

        cy.cGroupAsStep('Add new transaction code Three at enterprise level');
        // #region - Add new transaction code
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.Type2[2]!
        );
        // #endregion

        // #region - Turn on sharing for Gem_org005
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_5
        );

        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );

        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          TransactionCodes
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.yes,
          TransactionCodes
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify newly Add Transaction code three is displaying at GEM_ORG_5'
        );
        // #region - Verify newly Add Transaction code
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_5
        );
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);
        nursingConfiguration.verifyStateOfAddButton();
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!,
          true
        );
        nursingConfiguration.verifyTextInTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!
        );
        nursingConfiguration.verifyTransactionType(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!,
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.Type2[2]!
        );
        nursingConfiguration.verifySourceFieldInTransactionCode(Enterprise);
        sisOfcDesktop.selectSisLogo();
        // #endregion

        cy.cGroupAsStep('Map transaction code three to patient');
        // #region - Map transaction code
        sisOfcDesktop.sisOfficeGlobalSearchPatient(
          td_enterprise_config_transaction_code_tcid_265079.PatientDetails
        );
        sisOfcDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_enterprise_config_transaction_code_tcid_265079.Payments.CPTHCPCS
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_enterprise_config_transaction_code_tcid_265079.Payments
        );
        transactions.selectPeriodAddNewBatch(
          td_enterprise_config_transaction_code_tcid_265079.ChargeDetails
            .Period,
          td_enterprise_config_transaction_code_tcid_265079.ChargeDetails.Batch
        );

        transactions.clickDoneInPayment();
        sisOfcDesktop.selectSisLogo();
        // #endregion

        // #region - Delete transaction code three at enterprise and verify transaction code three is not deleted at GemOrg_005
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.deleteTransactionCode(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!,
          YesOrNo.yes
        );
        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!,
          false
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify transaction code is not deleted at facility GemOrg_005'
        );
        // #region - Verify transaction code is not deleted
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_5
        );
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);

        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!,
          true
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify transaction code is deleted at facility GemOrg_003'
        );
        // #region - Verify transaction code is deleted
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocation(OrganizationList.GEM_ORG_3);
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);

        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!,
          false
        );
        nursingConfiguration.verifyStateOfAddButton();
        // #endregion

        cy.cGroupAsStep(
          'Verify transaction code is deleted at facility GemOrg_004'
        );
        // #region - Verify transaction code is deleted
        sisOfcDesktop.selectSisLogo();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocation(OrganizationList.GEM_ORG_4);
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(ApplicationSettings);
        nursingConfigurationLayout.selectConfiguration(TransactionCodes, true);
        nursingConfiguration.verifyTransactionCodeExists(
          td_enterprise_config_transaction_code_tcid_265079.TransactionCodes[1]
            .TransactionCode2?.TransactionCodeName2[1]!,
          false
        );
        nursingConfiguration.verifyStateOfAddButton(false);
        // #endregion
      });
    });
  }
}
