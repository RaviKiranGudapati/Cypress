import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import {
  ShowOrHide,
  YesOrNo,
  DoneOrCancel,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_discount_tcid_2647258 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-discount-tcid-267258.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import {
  defaultWriteOffGroupCode,
  typeDropDownOptionValues,
  defaultWriteOffReasonCode,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();
const discountsName =
  td_enterprise_config_discount_tcid_2647258.Discount.DiscountNames;

/* const values */
const Discounts = 'Discounts';
const selectItem = 'Select Item';

export class EnterpriseDiscountTcId267258 {
  precondition() {
    describe('Enable "Shared Dictionaries/Configurations" and verify Enterprise Build-Discount', () => {
      it('Verifying Enterprise Build-Discount Feature ', () => {
        // #region -- Change login location to enterprise and Set Shared Dictionaries/Configuration to 'Show' state

        cy.cGroupAsStep(
          'Enable Shared Dictionaries/Configuration to Show state and Verifying Discount Feature under Enterprise Build'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        // #endregion

        // #region - verify Discount and Transaction Code under Enterprise Build

        cy.cGroupAsStep('Verify Enterprise Build Configurations');
        enterpriseConfig.verifyEnterpriseBuild(true);
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // #endregion

        // #region - Adding Transaction code at Enterprise level

        cy.cGroupAsStep(
          'Adding new Transaction code with type as WriteOff at Enterprise level'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_discount_tcid_2647258.Discount
            .TransactionCodeDropdownValues[0]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_discount_tcid_2647258.Discount
            .TransactionCodeDropdownValues[1]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        // #endregion
      });
    });
  }

  verifyDiscountFeatureUnderEnterpriseBuild() {
    describe('Verify Discounts Configuration feature functionality under Enterprise build', () => {
      it('Verify the Discounts feature options at Enterprise level', () => {
        // #region -- Check discounts user interfaces.

        cy.cGroupAsStep('Validating the UI and adding a new discount');
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.verifyDiscountScreenOptions();
        enterpriseConfig.verifyDiscountAddPopup();
        enterpriseConfig.verifyDiscountScreenOptions();
        // #endregion

        // #region -- Verify the Add popup's cancel button does not save the discount

        cy.cGroupAsStep(
          'Make sure the discount is not preserved after cancelling in the Add popup.'
        );

        enterpriseConfig.addDiscount(discountsName, DoneOrCancel.cancel);
        enterpriseConfig.verifyDiscountScreenOptions();
        enterpriseConfig.verifyDiscountExists(discountsName, false);
        // #endregion

        // #region -- check that the discount was saved after clicking "done" in the Add popup

        cy.cGroupAsStep(
          'After clicking "Done" in the Add window, be sure the discount was saved.'
        );
        enterpriseConfig.addDiscount(discountsName, DoneOrCancel.done);
        enterpriseConfig.verifyDiscountExists(discountsName, true);
        enterpriseConfig.verifyTickMark(discountsName);
        // #endregion

        // #region -- verify default behavior of Transaction code, WriteOff Group Code, WriteOff Reason Code Dropdowns

        cy.cGroupAsStep(
          'Verify the Transaction code, WriteOff Group Code and WriteOff Reason Code default behavior.'
        );
        enterpriseConfig.verifyDiscountNameField(discountsName);
        enterpriseConfig.verifyTransactionCodeInDiscount(selectItem);
        enterpriseConfig.verifyWriteOffGroupCodeInDiscount(selectItem);
        enterpriseConfig.verifyWriteOffReasonCodeInDiscount(selectItem);
        // #endregion

        // #region -- click on each dropdowns, then check the values.

        cy.cGroupAsStep('choose a dropdown and check the values');
        enterpriseConfig.verifyTransactionCodeListsInDiscount(
          td_enterprise_config_discount_tcid_2647258.Discount
            .TransactionCodeDropdownValues
        );
        enterpriseConfig.verifyWriteOffGroupCodeListsInDiscount(
          defaultWriteOffGroupCode
        );
        enterpriseConfig.verifyWriteOffReasonCodeListsInDiscount(
          defaultWriteOffReasonCode
        );
        // #endregion

        // #region -- verify the Discounts feature under facility management>configuration tab

        cy.cGroupAsStep(
          'Under Configuration tab, verify the Discounts feature option'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.verifyColumnsInConfigurationsTab();
        enterpriseConfig.verifyMouseHoverTextInConfigurationsTab();
        enterpriseConfig.verifyDefaultBehaviorToggleSwitch(Discounts);
        // #endregion

        // #region - select Include Enterprise Items Toggles to Yes and verify the toggles saved conditions

        cy.cGroupAsStep(
          'select Include Enterprise Items Toggles to Yes and verify the toggles saved conditions'
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          Discounts
        );
        enterpriseConfig.verifyYesNoIsEnabledForIncludeEnterpriseItems(
          YesOrNo.yes,
          Discounts
        );
        enterpriseConfig.verifyYesNoIsEnabledForAllowAddToConfiguration(
          YesOrNo.yes,
          Discounts
        );
        // #endregion
      });
    });
  }
}
