import { YesOrNo } from '../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

import { td_consents_procedure_sc265842 } from '../../../fixtures/sis-office/case/check-in/forms-consents/consents-procedure-tcid-265842.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_ANESTHESIA_DESKTOP } from '../../../app-modules-libs/sis-anesthesia/or/anesthesia.or';

import SISAnesthesiaDesktop from '../../../app-modules-libs/sis-anesthesia/anesthesia';
import CaseConsents from '../../../app-modules-libs/sis-office/case-check-in/case-consents';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisAnesthesiaDesktop = new SISAnesthesiaDesktop();
const caseConsents = new CaseConsents();

export class AnesthesiaConsentsTcId265842 {
  verifyCPTDescInConsents() {
    describe('To verify the cpt and description in procedure section within the consents popup in anesthesia desktop', () => {
      it('Verify the cpt and description under procedure text area in consents popup', () => {
        // #region - cpt and description verification in procedures text area in consents popup

        cy.cGroupAsStep(
          'Verify the cpt and description in procedure text area when open consents popup and close the consents popup'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisAnesthesiaDesktop.selectAnesthesiaInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_ANESTHESIA_DESKTOP_BUTTON[0]
        );
        sisAnesthesiaDesktop.selectPatientInSearchBox(
          td_consents_procedure_sc265842.PatientCase[0].PatientDetails
        );
        sisAnesthesiaDesktop.clickPreAndPostOpTab(
          OR_ANESTHESIA_DESKTOP.PRE_POSTOP_TAB.PRE_AND_POSTOP[0]
        );
        sisAnesthesiaDesktop.clickPreAndPostOpIcons();
        sisAnesthesiaDesktop.selectCaseConsent(
          td_consents_procedure_sc265842.ConsentsModel[0].ConsentName
        );
        sisOfficeDesktop.verifyProceduresInConsents(
          CommonUtils.concatenate(
            td_consents_procedure_sc265842.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_procedure_sc265842.ConsentsModel[0].Procedures![1]
          )
        );
        caseConsents.closeConsentWindow();
        caseConsents.closeConsentWindowConfirm(YesOrNo.yes);
        cy.cLogOut();
        // #endregion
      });
    });
  }

  verifyModifiedProcedureDescInConsents() {
    describe('To verify the modified procedure description in procedure section within the consents popup in anesthesia desktop', () => {
      it('Verify modified procedure description under procedure text area in consents popup', () => {
        // #region - cpt and description verification in procedures text area in consents popup

        cy.cGroupAsStep(
          'Verify the modified procedure description in procedure text area when open consents popup and close the consents popup'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisAnesthesiaDesktop.selectAnesthesiaInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_ANESTHESIA_DESKTOP_BUTTON[0]
        );
        sisAnesthesiaDesktop.selectPatientInSearchBox(
          td_consents_procedure_sc265842.PatientCase[1].PatientDetails
        );
        sisAnesthesiaDesktop.clickPreAndPostOpTab(
          OR_ANESTHESIA_DESKTOP.PRE_POSTOP_TAB.PRE_AND_POSTOP[0]
        );
        sisAnesthesiaDesktop.clickPreAndPostOpIcons();
        sisAnesthesiaDesktop.selectCaseConsent(
          td_consents_procedure_sc265842.ConsentsModel[1].ConsentName
        );
        sisOfficeDesktop.verifyProceduresInConsents(
          td_consents_procedure_sc265842.ConsentsModel[1].Procedures![0]
        );
        caseConsents.closeConsentWindow();
        caseConsents.closeConsentWindowConfirm(YesOrNo.yes);
        cy.cLogOut();
        // #endregion
      });
    });
  }
}
