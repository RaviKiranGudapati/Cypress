import { YesOrNo } from '../../../../support/common-core-libs/application/common-core';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_ANESTHESIA_DESKTOP } from '../../../../app-modules-libs/sis-anesthesia/or/anesthesia.or';
import { td_consents_primary_proc_sc265841 } from '../../../../fixtures/sis-office/case/check-in/forms-consents/consents-primary-proc-tcid-265841.td';

import SISAnesthesiaDesktop from '../../../../app-modules-libs/sis-anesthesia/anesthesia';
import CaseConsents from '../../../../app-modules-libs/sis-office/case-check-in/case-consents';
import SISOfficeDesktop from '../../../../support/common-core-libs/application/sis-office-desktop';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisAnesthesiaDesktop = new SISAnesthesiaDesktop();
const caseConsents = new CaseConsents();

export class AnesthesiaConsentsTcId265841 {
  verifyModifiedProcDescOfPrimaryProc() {
    describe('Verifying modified procedure description under procedure text area in Anesthesia Desktop', () => {
      it('Verify the modified procedure description under procedure section in consents', () => {
        // #region - Select Case Request from Case request Tracker

        cy.cGroupAsStep(
          'Verify the single procedure data under procedure section in consents'
        );

        sisAnesthesiaDesktop.selectAnesthesiaInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_ANESTHESIA_DESKTOP_BUTTON[0]
        );

        sisAnesthesiaDesktop.selectPatientInSearchBox(
          td_consents_primary_proc_sc265841.PatientCase[0].PatientDetails
        );

        sisAnesthesiaDesktop.clickPreAndPostOpTab(
          OR_ANESTHESIA_DESKTOP.PRE_POSTOP_TAB.PRE_AND_POSTOP[0]
        );
        sisAnesthesiaDesktop.clickPreAndPostOpIcons();

        sisAnesthesiaDesktop.selectCaseConsent(
          td_consents_primary_proc_sc265841.ConsentsModel[0].ConsentName
        );

        sisOfficeDesktop.verifyProceduresInConsents(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![0]
        );

        caseConsents.closeConsentWindow();
        caseConsents.closeConsentWindowConfirm(YesOrNo.yes);
        cy.cLogOut();
        // #endregion
      });
    });
  }
}
