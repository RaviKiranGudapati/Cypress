import { CommonUtils } from '../../../../../../support/common-core-libs/framework/common-utils';
import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';

import { td_consents_config_sc265840 } from '../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-config-tcid-265840.td';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import ConsentsTask from '../../../../../../app-modules-libs/sis-charts/departments/consents/consents';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import OperativeWorkList from '../../../../../../app-modules-libs/sis-charts/departments/operative/worklist';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import { OR_NURSING_CONSENTS } from '../../../../../../app-modules-libs/sis-charts/departments/consents/or/consents.or';

/*instance variables*/
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_consents_config_sc265840.PatientCase[0]);
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const consentsTask = new ConsentsTask();
const operativeWorkList = new OperativeWorkList();

export class NursingConsentsTcId265840 {
  verifyConsentsModifiedProcedureDesc() {
    describe('To verify the modified procedure description and CPT description in nursing desktop', () => {
      it('Verify the modified procedure description in procedure text area in consents popup, facesheet and case header', () => {
        // #region verify procedure data in consents popup, case header and facesheet in nursing desktop based on configuration

        /** Step6 - To check the Modified Procedure Description for case1 */
        cy.cGroupAsStep(
          'Verify the single modified procedure description data in consents popup'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        consentsTask.selectCaseConsent(
          td_consents_config_sc265840.ConsentsModel[0].ConsentName
        );
        consentsTask.verifyProcedure(
          td_consents_config_sc265840.ConsentsModel[0].Procedures![0]
        );
        cy.shouldBeEnabled(
          OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP
            .EDIT_CONSENTS_EDITOR[1]
        );
        consentsTask.clickConsentsCrossIcon();
        sisChartsDesktop.clickLossOfDataWarning(YesOrNo.yes);

        /** Step7 - To check the more than one Modified Procedure Description for case2 */
        cy.cGroupAsStep(
          'Verify multiple procedure data with modified procedure description in consents popup'
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_config_sc265840.PatientCase[1].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        consentsTask.selectCaseConsent(
          td_consents_config_sc265840.ConsentsModel[0].ConsentName
        );
        consentsTask.verifyProcedure(
          CommonUtils.concatenate(
            td_consents_config_sc265840.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_config_sc265840.ConsentsModel[0].Procedures![1]
          )
        );
        cy.shouldBeEnabled(
          OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP
            .EDIT_CONSENTS_EDITOR[1]
        );
        consentsTask.clickConsentsCrossIcon();
        sisChartsDesktop.clickLossOfDataWarning(YesOrNo.yes);

        /** Step8 - To check the CPT description as procedure don't have Modified Procedure Description for case3 */
        cy.cGroupAsStep(
          'Verify single procedure data with CPT description in consents popup'
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_config_sc265840.PatientCase[2].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        consentsTask.selectCaseConsent(
          td_consents_config_sc265840.ConsentsModel[0].ConsentName
        );
        consentsTask.verifyProcedure(
          td_consents_config_sc265840.ConsentsModel[0].Procedures![3]
        );
        consentsTask.clickConsentsCrossIcon();
        cy.shouldBeEnabled(
          OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP
            .EDIT_CONSENTS_EDITOR[1]
        );
        sisChartsDesktop.clickLossOfDataWarning(YesOrNo.yes);

        /** Step9 - To check the Modified description for first procedure & CPT description for second procedure and  for case4 */
        cy.cGroupAsStep(
          'Verify multiple procedure data with CPT description and Modified description in consents popup'
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_config_sc265840.PatientCase[3].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);

        consentsTask.selectCaseConsent(
          td_consents_config_sc265840.ConsentsModel[0].ConsentName
        );
        consentsTask.verifyProcedure(
          CommonUtils.concatenate(
            td_consents_config_sc265840.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_config_sc265840.ConsentsModel[0].Procedures![3]
          )
        );
        consentsTask.clickPhysicianSign();
        consentsTask.saveConsents();

        /**Step10- To select the operative Department & verify the procedure data section for case4*/
        cy.cGroupAsStep(
          'Verify procedure data in facesheet and header when incision and operative time is documented'
        );

        sisOfficeDesktop.selectPersonIconInMyTasks();

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        operativeWorkList.clickEnterInOutTime();
        operativeWorkList.enterAdmissionTime(
          td_consents_config_sc265840.Operative
        );
        operativeWorkList.clickRoomDropdown(
          td_consents_config_sc265840.Operative
        );
        operativeWorkList.clickOperativeTimeOut();
        operativeWorkList.clickSignInOperativeTimeOut();
        operativeWorkList.clickDoneInOperativeTimeOut();
        operativeWorkList.enterIncisionStartTime(
          td_consents_config_sc265840.Operative
        );

        sisOfficeDesktop.selectPersonIconInMyTasks();
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.CHART_ATTACHMENTS[0]
        );
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.SURGICAL_CASES[0]
        );
        chartsCoverFaceSheet.verifyProcedureInFaceSheet(
          CommonUtils.concatenate(
            td_consents_config_sc265840.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_config_sc265840.ConsentsModel[0].Procedures![3]
          )
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        operativeWorkList.verifyProcedureDetails(
          CommonUtils.concatenate(
            td_consents_config_sc265840.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_config_sc265840.ConsentsModel[0].Procedures![3]
          )
        );

        chartsCoverFaceSheet.verifyProcedureInCaseHeader(
          CommonUtils.concatenate(
            td_consents_config_sc265840.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_config_sc265840.ConsentsModel[0].Procedures![3]
          )
        );
        // #endregion
      });
    });
  }
}
