import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { OR_CHARTS_SCHEDULE_PRINT } from '../../../../../../app-modules-libs/sis-charts/schedule/print/or/charts-schedule-print.or';
import { OR_SIS_CHARTS_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-charts-desktop.or';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import ChartsLogin from '../../../../../../app-modules-libs/sis-charts/login/login';
import ChartsSchedulePrint from '../../../../../../app-modules-libs/sis-charts/schedule/print/charts-schedule-print';

/* instance variables */
const chartsSchedulePrint = new ChartsSchedulePrint();
const sisChartsDesktop = new SISChartsDesktop();
const chartsLogin = new ChartsLogin();

export class SisChartsScdlGridPrintTcId49238 {
  clickOnLayoutToggle() {
    cy.cClick(
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.LAYOUT.TOGGLE_BUTTON[1],
      OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID_POPUP.LAYOUT.TOGGLE_BUTTON[0]
    );
  }

  verifyScheduleGridPrintPreviewOptions() {
    describe('Verify Print Icon, Print Options, Schedule Grid Preview fields and refresh button enabling when layout is changed in SIS Charts', () => {
      it('Verify the Schedule Grid Print Options in Nursing Desktop Schedule Grid Print Preview Popup and Change Login Location to Gem_org005', () => {
        // #region - Verify the Schedule Grid Print Options in Nursing Desktop Schedule Grid Print Preview Popup and Change Login Location to Gem_org0050000

        cy.cGroupAsStep(
          'Click on Print Icon, select Schedule Grid and click on Preview'
        );
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.PRINT_ICON[1],
          OR_CHARTS_SCHEDULE_PRINT.PRINT_ICON[0]
        );
        chartsSchedulePrint.selectPreviewOptionInPrintPopup(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID[0]
        );

        cy.cGroupAsStep(
          'Verifying the layout toggle button in Nursing Desktop for Schedule Grid Print Preview'
        );
        chartsSchedulePrint.verifyRefreshButton(true);
        this.clickOnLayoutToggle();

        cy.cGroupAsStep('Verifying Physician is visible in GroupBy');
        chartsSchedulePrint.verifyGroupByDefaultOptionAsPhysician();
        chartsSchedulePrint.verifyRefreshButton(false);
        this.clickOnLayoutToggle();
        cy.cGroupAsStep(
          'Closing the Schedule Grid Preview and Changing the login location to Gem_Org005'
        );
        chartsSchedulePrint.ClosePrintPreview();
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_CHARTS_DESKTOP.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocation(OrganizationList.GEM_ORG_5);
      });
      // #endregion
    });
  }

  verifyPrintPageForAnotherOrg() {
    describe('Verify Schedule Grid Print Preview options in SIS Office after Changing the Login Location to Gem_Org005', () => {
      it('Verify Schedule Grid Print Preview options in Nursing Desktop in Gem_Org005', () => {
        // #region - Verify Schedule Grid Print Preview options in Nursing Desktop in Gem_Org005

        cy.cGroupAsStep(
          'Click on Print Icon, select Schedule Grid and click on Preview'
        );
        cy.cClick(
          OR_CHARTS_SCHEDULE_PRINT.PRINT_ICON[1],
          OR_CHARTS_SCHEDULE_PRINT.PRINT_ICON[0]
        );
        chartsSchedulePrint.selectPreviewOptionInPrintPopup(
          OR_CHARTS_SCHEDULE_PRINT.SCHEDULE_GRID[0]
        );

        cy.cGroupAsStep('Verifying refresh button is disabled by default');
        chartsSchedulePrint.verifyRefreshButton(true);

        cy.cGroupAsStep(
          'Verifying refresh button is enabled after selecting and GroupBy Physician'
        );
        this.clickOnLayoutToggle();
        chartsSchedulePrint.verifyGroupByDefaultOptionAsPhysician();
        chartsSchedulePrint.verifyRefreshButton(false);
        this.clickOnLayoutToggle();
        cy.cGroupAsStep('Closing the Schedule Grid Preview');
        chartsSchedulePrint.ClosePrintPreview();
      });
      // #endregion
    });
  }
}
