import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { td_appointment_attachment_tcid_278108 } from '../../../../../fixtures/sis-office/case-requests/appointment-attachment-tcid-278108.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { OR_CASE_REQUEST } from '../../../../../app-modules-libs/sis-office/case-request/or/case-request.or';

import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import CaseRequest from '../../../../../app-modules-libs/sis-office/case-request/case-request';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase();
const caseRequest = new CaseRequest();

/* const values */
const fileName = 'appointment-attachment-tcid-278108';

export class AcceptCaseTcId278108 {
  acceptAppointmentRequest() {
    it('Logging into business desktop, navigating to case requests and verifying it', () => {
      selectCaseRequest();
      verifyCaseRequest();
    });

    it('Verify attachment is present in request and accepting the case request in sis-office', () => {
      // #region Verifying attachment in request

      cy.cGroupAsStep('Verifying attachment in request');
      verifyAttachmentInRequest();
      // #endregion

      // #region  Accepting the case request and clicking on done button

      cy.cGroupAsStep(
        'Accepting the case request and clicking on done button in sis-office'
      );
      caseRequest.acceptCaseRequest(
        td_appointment_attachment_tcid_278108.PatientCase.CaseDetails!
          .AppointmentType
      );
      // #endregion

      // #region Verifying patient fall off from tracker after case gets accepted
      cy.cGroupAsStep(
        'Verifying patient fall off from tracker after case gets accepted'
      );
      caseRequest.verifyPatientFallOffFromCaseRequest(
        td_appointment_attachment_tcid_278108.PatientCase.PatientDetails
          .LastName
      );
      cy.cLogOut();
      // #endregion
    });
  }
}

function selectCaseRequest() {
  // #region Logging into business desktop and selecting patient in case request

  cy.cGroupAsStep(
    'Logging into business desktop and selecting patient in case request'
  );
  const userLogin: UserLogin = {
    UserName: UserList.GEM_USER_5[0],
    Password: UserList.GEM_USER_5[1],
  };

  cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);

  sisOfficeDesktop.selectPatientInCaseRequest(
    td_appointment_attachment_tcid_278108.PatientCase.PatientDetails.LastName
  );
  // #endregion
}

function verifyCaseRequest() {
  // #region Selecting patient in case request,verifying details and clicking on next button

  cy.cGroupAsStep('Verifying details and clicking on next button');
  caseRequest.verifyRequestInformationLabels();
  caseRequest.verifyRequestInformation(
    td_appointment_attachment_tcid_278108.RequestInformation
  );
  // #endregion
}

function verifyAttachmentInRequest() {
  // #region Verify attachment in request and navigating back to request information

  cy.cGroupAsStep(
    'Verify attachment in request and navigating back to request information'
  );
  caseRequest.selectRequestDetailsTab(
    OR_CASE_REQUEST.CASE_ATTACHMENT.CASE_ATTACHMENT_TAB[0]
  );
  caseRequest.verifyFileNameInAttachments(fileName);
  caseRequest.selectRequestDetailsTab(
    OR_CASE_REQUEST.REQUEST_DETAILS.REQUEST_INFORMATION[0]
  );
  createCase.next();
  // #endregion
}
