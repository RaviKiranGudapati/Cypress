import {
  InvokeAttributes,
  InvokeMethods,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../../../../support/common-core-libs/framework/selector-factory';

import { td_case_cancel_tcid_260016 } from '../../../../../../fixtures/sis-office/case/cancel/case-cancel-tcid-260016.td';
import { AppColors } from '../../../../../../support/common-core-libs/application/constants/app-colors.constants';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';

const color = require('onecolor');

/* instance variables */
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_case_cancel_tcid_260016.PatientCase);

/* const values */
const patient =
  td_case_cancel_tcid_260016.PatientCase.PatientDetails.LastName +
  `, ` +
  td_case_cancel_tcid_260016.PatientCase.PatientDetails.PatientFirstName;

export class CaseCancelTcId260016 {
  verifyBackgroundColor(locator: string, bgColor: string) {
    cy.cGet(locator)
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .should((colorValue) => {
        expect(color(colorValue).hex()).to.equal(bgColor);
      });
  }

  verifyShowCancelCaseNo() {
    describe('Verify upon setting up - NO, to show cancelled cases in User Settings, cancelled cases dont show up on schedule grid', () => {
      it('Verify Cancelled Case Not displayed in schedule grid when Show Cancelled Cases Set to No in User Settings', () => {
        // #region - Create a patient case
        cy.cGroupAsStep('Create a patient case');

        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        createCase.createCase();
        // #endregion

        // #region - Set the show cancelled case option to no in user settings
        cy.cGroupAsStep(
          'Set the show cancelled case option to no in user settings'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.USER_SETTINGS[0]
        );
        scheduleGrid.selectShowCancelledCase(YesOrNo.no);
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region - select patient case tile in schedule grid and cancel it
        cy.cGroupAsStep(
          'select patient case tile in schedule grid and cancel it'
        );
        scheduleGrid.selectRoomInScheduleGrid(
          td_case_cancel_tcid_260016.PatientCase.CaseDetails.OperatingRoom
        );
        scheduleGrid.selectPatientAndCancelCase(
          patient,
          td_case_cancel_tcid_260016.CancelReason
        );
        // #endregion

        // #region - Verify patient case tile is not displayed as show cancelled case set to no
        cy.cGroupAsStep(
          'Verify patient case tile is not displayed as show cancelled case set to no'
        );
        scheduleGrid.verifyPatientCaseUnpresence(patient);
        // #endregion
      });
    });
  }

  verifyShowCancelCaseYes() {
    describe('Verify upon setting up - YES, to show cancelled cases in User Settings, cancelled cases show up In disabled state in Grey color on schedule grid', () => {
      it('Verify the cancelled cases are disabled by Setting Yes in User Settings for showing cancelled cases in User Settings', () => {
        // #region - Set the show cancelled case option to yes in user settings

        cy.cGroupAsStep(
          'Set the show cancelled case option to yes in user settings'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.USER_SETTINGS[0]
        );
        scheduleGrid.selectShowCancelledCase(YesOrNo.yes);
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region - Verify cancelled case is displayed in grid in Grey color
        cy.cGroupAsStep(
          'Verify cancelled case is displayed in grid in Grey color'
        );
        this.verifyBackgroundColor(
          selectorFactory.patientCaseTileInScheduleGrid(patient),
          AppColors.component_disabled_state
        );
        // #endregion
      });
    });
  }

  verifyButtonsInCancelledCase() {
    describe('Verify Reinstate Icon and Other Icons state in cancelled case details popup in schedule grid', () => {
      it('Verify Reinstate Buttons enabled/disabled in cancelled case in schedule grid', () => {
        // #region - Verify the Icons state in case details popup of cancelled case
        cy.cGroupAsStep(
          'Verify the Icons state in case details popup of cancelled case'
        );
        scheduleGrid.selectPatientCase(patient);
        scheduleGrid.verifyIconsStateInCancelledCase();
        // #endregion

        // #region - Verify the cancelled Reason in case details popup of cancelled case
        cy.cGroupAsStep(
          'Verify the cancelled Reason in case details popup of cancelled case'
        );
        scheduleGrid.verifyCancelReasonInCaseDetailsPopup(
          td_case_cancel_tcid_260016.CancelReason
        );
        // #endregion
      });
    });
  }

  verifyReinstateFunctionality() {
    describe('Verify clicking on Reinstate Icon in cancelled case reactivates Case in schedule grid', () => {
      it('Verify Case is Enabled after clicking on Reinstate Button in cancelled case in schedule grid', () => {
        // #region - Verify the Reinstate Icon color and click on it
        cy.cGroupAsStep('Verify the Reinstate Icon color and click on it');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientCase(patient);
        this.verifyBackgroundColor(
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[1],
          AppColors.component_on_selection
        );
        scheduleGrid.clickOnReinstateButton();
        // #endregion

        // #region - Verify the Icons state in case details popup of reinstated case
        cy.cGroupAsStep(
          'Verify the Icons state in case details popup of reinstated case'
        );
        scheduleGrid.selectPatientCase(patient);
        scheduleGrid.verifyIconsStateInReinstateCase();
        // #endregion

        // #region - Verify the background color of active patient case after reinstating the case
        cy.cGroupAsStep(
          'Verify the background color of active patient case after reinstating the case'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        this.verifyBackgroundColor(
          selectorFactory.patientCaseTileInScheduleGrid(patient),
          AppColors.component_disabled_state
        );
        // #endregion
      });
    });
  }
}
