import { YesOrNo } from '../../../../../../../support/common-core-libs/application/common-core';

import { td_consents_primary_proc_sc265841 } from '../../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-primary-proc-tcid-265841.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CaseConsents from '../../../../../../../app-modules-libs/sis-office/case-check-in/case-consents';
import FaceSheetCases from '../../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import SISOfficeDesktop from '../../../../../../../support/common-core-libs/application/sis-office-desktop';

/*instance variables*/
const sisOfficeDesktop = new SISOfficeDesktop();
const caseConsents = new CaseConsents();
const faceSheetCases = new FaceSheetCases();

export class SISOfficeConsentsTcId265841 {
  verifyModifiedProcInFormsAndConsents() {
    describe('To verify modified procedure description data in consents popup in business desktop', () => {
      it('Verify the modified procedure description of primary procedure in forms and consents in business desktop', () => {
        // #region verify the all procedure data in consents popup

        cy.cGroupAsStep(
          'Verify the modified procedure description of primary procedure in forms and consents '
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_consents_primary_proc_sc265841.PatientCase[1].PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.FORMS_AND_CONSENTS
        );

        caseConsents.clickConsentNameInList(
          td_consents_primary_proc_sc265841.ConsentsModel[0].ConsentName
        );

        sisOfficeDesktop.verifyProceduresInConsents(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![2]
        );

        caseConsents.closeConsentWindow();
        caseConsents.closeConsentWindowConfirm(YesOrNo.yes);

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.LOGOUT[0]
        );
        // #endregion
      });
    });
  }
}
