import { td_consents_sc260007 } from '../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-tcid-260007.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { ConsentsTcId260007 } from './scenarios/tcid-260007.sc';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

/* instance variables */
const consents = new ConsentsTcId260007();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation, consent template creation with consents
 * 1. Login to application
 * 2. After, patient check-in , enter mandatory patient details as address and zip code.
 * 3. Verify consents created are present on case consents tab for patient.
 * 4. Verify consent template with consent details Physician Sign.
 * 5. Verify consent template with unsigned consents.
 * 6. Verify warning message for loss of data.
 * 7. Verify addendum added to existing consent and signed by physician.
 * 8. Verify consent template two with consent.
 * 9. Verify other user name and password.
 * 10. Verify consent template two with consent signed by other user.
 * 11. Verify add addendum for consent template two signed by physician.
 * 12. Verify consent details saved.
 * 13. Logout from application.
 * */

describe(
  'Verify edit consent, add addendum with signed by physician/other user in schedule grid',
  {
    tags: ['case-consents', 'TC#260007', 'US#260246'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_4[0],
        Password: UserList.GEM_USER_4[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        consents.patientCheckIn(td_consents_sc260007.PatientCase);
        consents.updateConsents();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
