import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { AnesthesiaConsentsTcId262596 } from '../../../../sis-anesthesia/scenarios/tcid-262596.sc';
import { NursingConsentsTcId262596 } from '../../../../sis-charts/case/consents/scenarios/tcid-262596.sc';
import { MobileConsentsTcId262596 } from '../../../../sis-mobile/scenarios/tcid-262596.sc';
import { ConsentsTcId262596 } from './scenarios/tcid-262596.sc';
import SISMobileLogin from '../../../../../../app-modules-libs/sis-mobile/login/login';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

/* instance variables */

const sisMobileLogin = new SISMobileLogin();
const geminiConsents = new ConsentsTcId262596();
const nursingConsents = new NursingConsentsTcId262596();
const anesthesiaConsents = new AnesthesiaConsentsTcId262596();
const mobileConsents = new MobileConsentsTcId262596();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data [JIT] for patient creation, consent template creation with consents
 * Steps:
 *  1. Login to SIS Complete application with Admin User.
 *  2. Select Patient 1 case from Schedule grid & Check-in and Navigate to Forms & Consents and click on Consent1.
 *  3. Select multiple physicians from Performing physician dropdown and save consent by clicking Done Button.
 *  4. Reopen Consent1 and verify added physician. close consent and switch to Schedule grid.
 *  5. Switch to Nursing desktop, Select Patient1 case and navigate to Consents and verify the Performing physician added in Consent1
 *  6. Select another 2 physicians for that Consent in the the Performing physician dropdown & click on Done
 *  7. Reopen Consent1 and verify added physician. close consent and switch to Schedule grid and Navigate to Incomplete items tracker.
 *  8. Click on Consents for Patient1 & verify the Performing physician dropdown field.
 *  9. Switch to Anesthesia desktop and click on consents for Patient1 case
 * 10. Verify updated physicians are selected at Performing physician dropdown field and Unselect 1 physician and click on done button.
 * 11. Navigate to SIS Charts, Select Patient1 case and click Consents and Select Consent1 and verify the Performing physician dropdown field.
 * 12. Switch to Anesthesia Desktop -> select Patient case and sign consent1 and verify
 * 13. Navigate to Business Desktop -> UserMenu -> Reports -> Audit Trail and verify the Patient 1 case details with multiple physicians for
 *     Areas - Scheduling, Anesthesia, Documents and Facesheet
 * 14. Logout from application and login with Physician User1, Select Patient1 case and navigate to Consents and verify that Multiple physicians
 *     are displayed in physician desktop for consent1
 * 15. Launch Physician mobile URL and login with Physician User1, Select Patient1 case and navigate to Consents and verify that Multiple physicians
 *     are displayed in physician desktop for consent1
 * 16. Sign the consent in physician mobile, Logout and login to Physician mobile with another physician, who is added to consent
 * 17. Check the Consent1 details - Consent details should not be displayed for that physician, since another physician signed that consent
 * 18. Logout from application
 * */

describe(
  'Verify ',
  {
    tags: ['physician-consents', 'TC#263891', 'US#262596'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisMobileLogin.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        geminiConsents.updateConsentsPerformingPhysician();
        nursingConsents.updateConsentsPerformingPhysician();
        anesthesiaConsents.updateConsentsPerformingPhysician();
        nursingConsents.verifyPhysicianUpdatedInAnesthesia();
        anesthesiaConsents.signConsentsPerformingPhysician();
        nursingConsents.verifyAuditTrailReport();
        nursingConsents.verifyConsentDisplayedInPhysicianDesktop();
        mobileConsents.signConsents();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
