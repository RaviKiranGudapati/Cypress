import { td_case_equip_tcid_260005 } from '../../../../../../fixtures/sis-office/case/create/case-equipment-tcid-260005.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { AppErrorMessages } from '../../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase();

/* const values */
const patient =
  td_case_equip_tcid_260005.PatientDetails.LastName +
  `, ` +
  td_case_equip_tcid_260005.PatientDetails.FirstName;

const alreadyAddedMsg =
  'This item Equip2 is already added to the Case. Please update the Quantity instead.';

export class CaseEquipmentTcId260005 {
  updatePpeCaseFromCaseRequests() {
    describe('Select Case row From Case Requests, fill mandatory fields and create case In SIS Office', () => {
      it('selecting the PPE Case From Case Requests in Business Desktop and Saving the case', () => {
        // #region - Login to SIS Office with Gem_User1
        cy.cGroupAsStep('Login to SIS Office with Gem_User1');
        /** Login into SIS Office application*/
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_1[0],
          Password: UserList.GEM_USER_1[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
        // #endregion,

        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep('Select Case Request from Case request Tracker');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .CASE_REQUESTS[0]
        );
        sisOfficeDesktop.selectPatientRow(patient, patient);
        createCase.next();
        // #endregion

        // #region - Create the New Patient with details entered in SIS Exchange
        cy.cGroupAsStep(
          'Create the New Patient with details entered in SIS Exchange'
        );
        createCase.clickNewPatientButtonForCaseRequest();
        createCase.clickDoneButton();
        createCase.next();
        // #endregion
        // #region - Enter Mandatory Fields and Create case
        cy.cGroupAsStep('Enter Mandatory Fields and Create case');
        createCase.selectAppointmentType(
          td_case_equip_tcid_260005.PatientCase.CaseDetails.AppointmentType
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion
      });
    });
  }

  verifyAddPreferenceCardInCreateCase() {
    describe('Verifying the case should be updated with details in preference card on adding the preference card template in Case Details Tab', () => {
      it('Verify the Procedures Added to CPT table from preference card containing Procedures and Equipment Overbooked Warning', () => {
        // #region - Verify adding preference card with cpt procedures
        cy.cGroupAsStep('Verify adding preference card with cpt procedures');

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase.selectPreferenceCard(
          td_case_equip_tcid_260005.PreferenceCard2
        );
        createCase.verifyCptCode(
          1,
          td_case_equip_tcid_260005.PreferenceCard2.Procedures[0]
        );
        createCase.verifyCptCode(
          2,
          td_case_equip_tcid_260005.PreferenceCard2.Procedures[1]
        );
        createCase.clickNextInCaseDetails();
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region - Verify Equipment Overbooked Warning in Case Details
        cy.cGroupAsStep('Verify Equipment Overbooked Warning in Case Details');
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase.enterEquipmentUsed(0, 6);
        createCase.verifyCaseDetailsWarningBanner(
          AppErrorMessages.equipment_overbooked
        );
        // #endregion

        // #region - Verify Unpresence of Equipment Overbooked Warning
        cy.cGroupAsStep('Verify Unpresence of Equipment Overbooked Warning');
        createCase.enterEquipmentUsed(0, 5);
        createCase.verifyWarningBanner();
        // #endregion

        // #region - Verifying Adding 2 more preference cards
        cy.cGroupAsStep('Verifying Adding 2 more preference cards');
        createCase.selectPreferenceCard(
          td_case_equip_tcid_260005.PreferenceCard1
        );
        // #endregion

        // #region - Verify Equipment Overbooked Warning for Equipment Equip1
        cy.cGroupAsStep(
          'Verify Equipment Overbooked Warning for Equipment Equip1'
        );
        createCase.enterEquipmentUsed(1, 11);
        createCase.verifyCaseDetailsWarningBanner(
          AppErrorMessages.equipment_overbooked
        );
        // #endregion

        // #region - Verify Unpresence of Equipment Overbooked Warning
        cy.cGroupAsStep('Verify Unpresence of Equipment Overbooked Warning');
        createCase.enterEquipmentUsed(1, 10);
        createCase.verifyWarningBanner();
        // #endregion
      });
    });
  }

  verifyDeletePreferenceCardAndEquipment() {
    describe('Verifying the deleting Equipment, adding duplicate equipment and deleting Preference card In Case Details Tab in Create Case', () => {
      it('Verify deleting the Equipment in Case Details Equipment Table and deleting Preference Card in Preference card Table', () => {
        // #region - Verify deleting the equipment in case details

        cy.cGroupAsStep('Verify deleting the equipment in case details');
        createCase.deleteEquipment(
          td_case_equip_tcid_260005.Equipments[1].Equipment
        );
        createCase.clickEquipment();
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_equip_tcid_260005.Equipments[1].Equipment,
          false
        );
        createCase.deleteEquipment(
          td_case_equip_tcid_260005.Equipments[2].Equipment
        );
        createCase.clickEquipment();
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_equip_tcid_260005.Equipments[2].Equipment,
          false
        );
        // #endregion

        // #region - Verify adding duplicate equipment in case details

        cy.cGroupAsStep('Verify adding duplicate equipment in case details');
        createCase.addEquipment(
          td_case_equip_tcid_260005.Equipments[0].Equipment
        );
        createCase.verifyDuplicateEquipmentPopupAndClose(alreadyAddedMsg);
        createCase.clickEquipment();
        createCase.enterEquipmentUsed(3, 3);
        // #endregion

        // #region - Verify deleting the preference card in case details
        cy.cGroupAsStep('Verify deleting the preference card in case details');
        createCase.deletePreferenceCard(
          td_case_equip_tcid_260005.PreferenceCard1.AvailablePreferenceCards[1]
        );
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_equip_tcid_260005.PreferenceCard1.AvailablePreferenceCards[1],
          false
        );
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_equip_tcid_260005.Equipments[3].Equipment,
          false
        );
        // #endregion

        // #region - Verify adding the equipment in case details
        cy.cGroupAsStep('Verify adding the equipment in case details');
        createCase.addEquipment(
          td_case_equip_tcid_260005.Equipments[3].Equipment
        );
        createCase.clickEquipment();
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_equip_tcid_260005.Equipments[3].Equipment
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion
      });
    });
  }
}
