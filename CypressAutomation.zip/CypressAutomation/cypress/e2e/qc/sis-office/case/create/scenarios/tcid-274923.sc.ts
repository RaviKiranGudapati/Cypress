import { AppColors } from '../../../../../../support/common-core-libs/application/constants/app-colors.constants';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_county_field_tcid_274923 } from '../../../../../../fixtures/sis-exchange/appointment-request/patient-details-county-field-274923.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import Login from '../../../../../../app-modules-libs/sis-office/login/login';
import PatientDetailsFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase();
const patientDetailsFaceSheet = new PatientDetailsFaceSheet();
const login = new Login();

/* const values */
const patient =
  td_county_field_tcid_274923.PatientCase[0].PatientDetails.LastName +
  `, ` +
  td_county_field_tcid_274923.PatientCase[0].PatientDetails.FirstName;

export class CaseRequestCountyFieldTcId274923 {
  verifyAddressFields() {
    describe('Select Case row From Case Requests, fill mandatory fields and create case In SIS Office', () => {
      it('Selecting the PPE Case From Case Requests in Business Desktop and verify address filed', () => {
        // #region - verifying city,count,state,zip code in request details tab

        cy.cGroupAsStep('Select Case Request from Case request Tracker');
        cy.visit('/');
        login.login(
          UserList.GEM_USER_2[0],
          UserList.GEM_USER_2[1],
          OrganizationList.GEM_ORG_2
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .CASE_REQUESTS[0]
        );
        sisOfficeDesktop.selectPatientInCaseRequest(patient);
        createCase.verifyCityCountyStateZipCodeInRequestDetails(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
        );
        createCase.next();
        createCase.clickNewPatientButtonForCaseRequest();
        createCase.clickDoneButton();
        createCase.verifyAddressInPatientDetails(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
        );
        createCase.next();
        createCase.selectAppointmentType(
          td_county_field_tcid_274923.PatientCase[0].CaseDetails!
            .AppointmentType
        );
        sisOfficeDesktop.clickDoneButton();
        sisOfficeDesktop.logout();
        // #endregion
      });
    });
  }

  verifyModifiedDetails() {
    describe('Verify Modified zip code is updated in SIS Office', () => {
      it('Verify Zip code, city, county and state details are updated based on SIS-Exchange', () => {
        // #region - verifying city,count,state,zip code in request details and patient details

        cy.cGroupAsStep('Select Case Request from Case request Tracker');
        cy.visit('/');
        login.login(
          UserList.GEM_USER_2[0],
          UserList.GEM_USER_2[1],
          OrganizationList.GEM_ORG_2
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .CASE_REQUESTS[0]
        );
        createCase.verifyExclamationIcon(
          td_county_field_tcid_274923.PatientCase[0].PatientDetails
            .FirstName
        );
        sisOfficeDesktop.selectPatientInCaseRequest(patient);
        createCase.verifyCityCountyStateZipCodeInRequestDetails(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails,
          AppColors.component_modified_case_request
        );
        createCase.clickUpdateInRequestDetailsTab();

        createCase.verifyCityCountyStateZipCodeInRequestDetails(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails,
          AppColors.component_case_request
        );
        sisOfficeDesktop.clickDoneButton();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails
            .FirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase.previous();
        createCase.waitUntilDicItemsLoad();
        createCase.addInsuranceCoverage(
          td_county_field_tcid_274923.InsuranceInfo
        );
        createCase.selectAddedCarrierInInsuranceCoverage(
          td_county_field_tcid_274923.InsuranceInfo
        );
        createCase.verifyAddressInPatientDetails(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails
        );
        createCase.clickDoneInInsuranceCoverage();
        createCase.next();
        sisOfficeDesktop.clickDoneButtonPopup();
        // #endregion
      });
    });
  }

  verifyModifiedDetailsInFaceSheet() {
    describe('Verify Modified zip code is updated in FaceSheet SIS Office', () => {
      it('Verify Zip code,city,county and state details are updated based on FaceSheet SIS-Exchange', () => {
        // #region - verifying city,count,state,zip code in Facesheet patient details

        cy.cGroupAsStep(
          'Verify County,Zip code,State and City in Facesheet patient details'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails
            .FirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        patientDetailsFaceSheet.clickOnPatientDetailsTab();
        patientDetailsFaceSheet.verifyPatientAddressInPatientDetailsTab(
          td_county_field_tcid_274923.PatientCase[1].PatientDetails
        );
        sisOfficeDesktop.selectSisLogo();
      });
      // #endregion
    });
  }
}
