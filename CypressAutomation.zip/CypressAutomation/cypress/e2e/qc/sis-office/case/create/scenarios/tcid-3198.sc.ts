import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { td_case_insurance_tcid_3198 } from '../../../../../../fixtures/sis-office/case/create/case-insurance-tcid-3198.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import { SubRoutes } from '../../../../../../support/common-core-libs/application/constants/sub-routes.constants';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';

/*instance variables*/
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_case_insurance_tcid_3198.PatientCase[0]);
const nursingConfig = new NursingConfiguration();
const loginPage = new SISCompleteLogin();

export class CaseInsuranceTcId3198 {
  verifyDataInInsuranceCoveragePopup() {
    describe('To verify the fields and data in Add Insurance Coverage popup in Create Case', () => {
      it('Verifying the labels,dropdown values, state of done button and data validation in Insurance popup under patient details in Create Case', () => {
        // #region To make the default plan option to NO in configuration side

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfig.editInsurance(
          td_case_insurance_tcid_3198.InsuranceCoverage[0].InsuranceCarrier,
          td_case_insurance_tcid_3198.Edit
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion default plan option changed to no in configuration side

        cy.cGroupAsStep(
          'Verifying the field names and checking the data is cleared in DOB field in Add Insurance popup under Patient Details in Create Case'
        );
        // #region Verifying the field names and checking the data is cleared in DOB field in Insurance popup
        /*Verifying the Insurance Carrier,Insurance Plan and Claim Office,Verifying the title and labels of the patient details*/
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.searchAndSelectOrCreatePatient(
          td_case_insurance_tcid_3198.PatientCase[0].PatientDetails
        );
        cy.cWait(SubRoutes.facility_address);
        createCase.verifyMRNExternalMRN();
        createCase.selectGender(
          td_case_insurance_tcid_3198.PatientCase[0].PatientDetails.Gender
        );
        createCase.clickInsuranceAddButton();
        createCase.verifyTitlesIconsInsuranceModel();

        /*Verifying Gender and DOB in Insurance Pop Up*/
        createCase.verifyInsuranceGender();
        createCase.verifyInsuranceDOB();

        /*Verify the DOB field as clear when enter the invalid DOB*/
        createCase.enterInsuranceDOB(
          td_case_insurance_tcid_3198.InsuranceCoverage[0]
        );

        createCase.enterInsuranceMiddleInitial(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.verifyInsuranceDOBFilled();

        /*Verify SubscriberID,Group Name,Group Number and Employer Labels*/
        createCase.verifySubscriberID(
          td_case_insurance_tcid_3198.InsuranceCoverage[0]
        );
        createCase.verifyLabelsInInsurancePopUp();
        createCase.verifyDateFormatEffectiveTo(
          td_case_insurance_tcid_3198.InsuranceCoverage[1]
        );
        createCase.verifyDateFormatEffectiveFrom(
          td_case_insurance_tcid_3198.InsuranceCoverage[1]
        );
        // #endregion verified the fields and data in Insurance popup

        cy.cGroupAsStep(
          'Verifying the fields dropdown values in Add Insurance popup under Patient Details in Create Case'
        );
        // #region Verifying the fields dropdown values in Insurance popup
        /*Verify Relationship to Subscriber dropdown values and label*/
        createCase.verifyRelationshipToSubscriberLabel();
        createCase.verifyRelationshipToSubscriberDefaultValue();
        createCase.clickRelationshipToSubscriberDropdown();
        createCase.verifyDropdownValues(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0].subvalue,
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0].Relationship_dropdown_vals
        );

        /*Verify State Dropdown values,Address fields,Country*/
        createCase.verifyInsuranceAddressFields();
        createCase.verifyStateDropDownValues(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0].STATE_DROPDOWN_VALS
        );
        createCase.verifyCountyDropDownValues(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0].COUNTRY_DROPDOWN_VALS
        );
        // #endregion verified the fields dropdown values in Insurance popup

        cy.cGroupAsStep(
          'Verifying the data is cleared in phone number, Effective from and to fields in Add Insurance popup under Patient Details in Create Case'
        );
        // #region Verifying the data is cleared in phone number, Effective from and to fields in Insurance popup
        /*Verify Phone field and validate data*/
        createCase.enterPhoneNumber(
          td_case_insurance_tcid_3198.InsuranceCoverage[0]
        );
        createCase.clickEmail();
        createCase.verifyPhoneNumberFilled();

        /*Verify EffectiveFrom,EffectiveTo focus validations*/
        createCase.clearEffectiveFrom();
        createCase.enterEffectiveFrom(
          td_case_insurance_tcid_3198.InsuranceCoverage[0]
        );
        createCase.clickEffectiveTo();
        createCase.verifyEffectiveFromFilled();
        createCase.clearEffectiveTo();
        createCase.enterEffectiveTo(
          td_case_insurance_tcid_3198.InsuranceCoverage[0]
        );
        createCase.clickEffectiveFrom();
        createCase.verifyEffectiveToFilled();
        // #endregion verified the data is cleared in phone number, Effective from and to fields in Insurance popup

        cy.cGroupAsStep(
          'Verifying the done button state as disable mode while entering the data step by step in Add Insurance popup under Patient Details in Create Case'
        );
        // #region Verifying the done button state as disable mode while entering the data step by step in Insurance popup
        /*Verify done button as disable mode after entering first name,subscriber ID,Insurance details*/
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.selectInsuranceCarrierDropdownValue();
        createCase.enterInsuranceFirstName(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterSubscriberID(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.verifyInsuranceDone(false);

        /*Verify done button as disable mode after entering Last name*/
        createCase.enterInsuranceLastName(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.verifyInsuranceDone(false);

        /*Verify done button as disable mode when not selected any option in the relationship to subscriber dropdown*/
        createCase.verifyRelationshipToSubscriberDefaultValue();
        createCase.verifyInsuranceDone(false);

        /*Verify done button as enable mode after selecting option from relationship to subscriber dropdown*/
        createCase.clickOnSelectedValueInRelationshipToSubscriberDropdown(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.verifyInsuranceDone();

        /*Verify that user can pick another option instead closing dropdown values list*/
        createCase.clickOnSelectedValueInRelationshipToSubscriberDropdown(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.verifySelectedValueInRelationshipToSubscriber(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[1].RelationshipToSubscriber
        );
        sisOfficeDesktop.clickCloseIcon();
        createCase.verifyInsurancePopupClosed();
        createCase.verifyCheckMarkPatientDetails();
        createCase.clickCaseCross();
        createCase.clickLossData();
        cy.cLogOut();
        // #endregion verified the done button state as disable mode while entering the data step by step in Insurance popup

        cy.cGroupAsStep(
          'Verifying the data in Add Insurance popup under Patient Details in Create Case with user2'
        );
        // #region Verifying the data in Insurance popup with user2
        /*Verifying the data in Insurance popup with user2 and Insurance 2 and checking the first name and last name as disable state in Insurance popup */

        /**
         * @Issue: Due to logout and re login, API is not working and we have tried with the cy reload after logout and still not worked
         * @Resolution: we are moving to old login application
         */
        cy.reload();
        cy.visit('/');
        /** Login into SIS Office application*/
        loginPage.login(
          UserList.GEM_USERVONLY_SS[0],
          UserList.GEM_USERVONLY_SS[1],
          OrganizationList.GEM_ORG_2
        );
        // Once the API will work fro relogin and will revert the commented code
        /** Login into SIS Office application*/
        // const userLogin: UserLogin = {
        //   UserName: UserList.GEM_USERVONLY_SS[0],
        //   Password: UserList.GEM_USERVONLY_SS[1],
        // };
        // cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin);

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.searchAndSelectOrCreatePatient(
          td_case_insurance_tcid_3198.PatientCase[0].PatientDetails
        );
        createCase.verifyMRNExternalMRN();
        createCase.selectGender(
          td_case_insurance_tcid_3198.PatientCase[0].PatientDetails.Gender
        );
        createCase.clickInsuranceAddButton();
        createCase.verifyTitlesIconsInsuranceModel();
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.selectInsuranceCarrierDropdownValue();
        createCase.clickOnSelectedValueInRelationshipToSubscriberDropdown(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.verifyInsurerNamesIsDisabled(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[1].FirstName
        );
        createCase.verifyInsurerNamesIsDisabled(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[1].LastName
        );
        sisOfficeDesktop.clickCloseIcon();
        createCase.verifyInsurancePopupClosed();
        createCase.verifyCheckMarkPatientDetails();
        createCase.clickCaseCross();
        createCase.clickLossData();
        cy.cLogOut();
        // #endregion Verified the data in Insurance popup with user2

        cy.cGroupAsStep(
          'Verifying the state of the done button as enabled while entering the data step by step in Add Insurance popup under Patient Details in Create Case'
        );
        /**
         * @Issue: Due to logout and re login, API is not working and we have tried with the cy reload after logout and still not worked
         * @Resolution: we are moving to old login application
         */
        cy.reload();
        cy.visit('/');
        /** Login into SIS Office application*/
        loginPage.login(
          UserList.GEM_USERVONLY_SS[0],
          UserList.GEM_USERVONLY_SS[1],
          OrganizationList.GEM_ORG_2
        );
        // #region Verifying the state of the done button as enabled while entering the data step by step in Insurance popup
        /*Verify Title icons in insurance popup*/
        /** Login into SIS Office application*/
        // const userLogin1: UserLogin = {
        //   UserName: UserList.GEM_USER_2[0],
        //   Password: UserList.GEM_USER_2[1],
        // };
        // cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin1);

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.searchAndSelectOrCreatePatient(
          td_case_insurance_tcid_3198.PatientCase[0].PatientDetails
        );
        createCase.verifyMRNExternalMRN();
        createCase.clickInsuranceAddButton();
        createCase.verifyTitlesIconsInsuranceModel();

        /*Verify that Insurance Pop Up should be closed*/
        sisOfficeDesktop.clickCloseIcon();

        /*Verify that done button as enable after entering all mandatory values*/
        createCase.clickInsuranceAddButton();
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.selectInsuranceCarrierDropdownValue();

        createCase.clickOnSelectedValueInRelationshipToSubscriberDropdown(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterSubscriberID(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterGroupName(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterGroupNumber(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterEffectiveFrom(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.verifyInsuranceDone();

        /*Verify that done button as enable after entering the effectiveTo field value*/
        createCase.enterEffectiveTo(
          td_case_insurance_tcid_3198.PatientCase[0].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.verifyInsuranceDone();

        /** click on the done button in Insurance popup and verify the popup should be closed correctly */
        createCase.clickInsuranceDoneButton();
        createCase.verifyInsurancePopupClosed();
        createCase.verifyCheckMarkPatientDetails();
        createCase.clickCaseCross();
        createCase.clickLossData();
        // #endregion Verified the state of the done button as enabled while entering the data step by step in Insurance popup
      });
    });
  }
}
