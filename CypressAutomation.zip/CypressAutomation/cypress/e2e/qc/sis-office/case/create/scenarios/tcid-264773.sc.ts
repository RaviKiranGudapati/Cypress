import { CommonUtils } from '../../../../../../support/common-core-libs/framework/common-utils';
import { AppToolTip } from '../../../../../../support/common-core-libs/application/constants/app-tooltip-constant';

import { td_case_gender_identity_tcid_264773 } from '../../../../../../fixtures/sis-office/case/create/case-gender-identity-tcid-264773.td';
import { OR_PATIENT_CASE_CREATION } from '../../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import PatientDetailsFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(
  td_case_gender_identity_tcid_264773.PatientCase
);
const patientFacesheet = new PatientDetailsFaceSheet();

/* const values */
const patient =
  td_case_gender_identity_tcid_264773.PatientCase.PatientDetails.LastName +
  `, ` +
  td_case_gender_identity_tcid_264773.PatientCase.PatientDetails
    .PatientFirstName;
const orPatientDetails =
  OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS;

export class ScheduleGridTcId264773 {
  patientDetailsGenderIdentityUI() {
    describe('Verify sex,gender identity,pronouns and preferredName', () => {
      it('Create and Update a case with new Dictionary item "Gender Identity" & "Pronouns" -WF9-US#189158', () => {
        cy.cGroupAsStep(
          'Click create patient tab, verify sex, gender identity, pronouns, preferred Name Label in schedule grid patient details '
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );

        createCase.verifyLabelsInPatientDetails(orPatientDetails.SEX_LABEL[0]);
        createCase.verifyLabelsInPatientDetails(
          orPatientDetails.GENDER_IDENTITY_LABEL[0]
        );
        createCase.verifyLabelsInPatientDetails(
          orPatientDetails.PRONOUNS_LABEL[0]
        );
        createCase.verifyLabelsInPatientDetails(
          orPatientDetails.PREFERRED_NAME_LABEL[0]
        );

        cy.cGroupAsStep(
          'Select Sex, Gender Identity, Pronouns, preferred Name '
        );
        createCase.selectGender(
          createCase.patientCaseModel!.PatientDetails!.Gender!
        );
        createCase.selectGenderIdentity(
          createCase.patientCaseModel!.PatientDetails!.GenderIdentity!
        );
        createCase.selectPronouns(
          createCase.patientCaseModel!.PatientDetails.Pronouns!
        );

        createCase.enterPreferredName(
          createCase.patientCaseModel!.PatientDetails!
        );

        cy.cGroupAsStep(
          'Verify, Sex, Gender Identity, Pronouns, preferred Name, tooltip massage on schedule grid patient details page '
        );
        createCase.verifyToolTipMessage(
          orPatientDetails.SEX_TOOLTIP[1],
          orPatientDetails.SEX_TOOLTIP[0],
          AppToolTip.patient_details_sex
        );

        createCase.verifyToolTipMessage(
          orPatientDetails.GENDER_IDENTITY_TOOLTIP[1],
          orPatientDetails.GENDER_IDENTITY_TOOLTIP[0],
          AppToolTip.gender_identity
        );

        createCase.verifyToolTipMessage(
          orPatientDetails.PRONOUNS_TOOLTIP[1],
          orPatientDetails.PRONOUNS_TOOLTIP[0],
          AppToolTip.pronouns
        );
        createCase.verifyToolTipMessage(
          orPatientDetails.PREFERRED_NAME_TOOLTIP[1],
          orPatientDetails.PREFERRED_NAME_TOOLTIP[0],
          AppToolTip.preferred_name
        );
        cy.cGroupAsStep('Enter mandatory patient data and create patient');
        createCase.clickNextInPatientDetails();
        createCase.enterCaseDetails(createCase.patientCaseModel!.CaseDetails!);
        createCase.clickCreateCaseDoneButton();

        cy.cGroupAsStep(
          'Go to schedule grid, click patient tile, select facesheet and go to patient details'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        patientFacesheet.clickOnPatientDetailsTab();

        cy.cGroupAsStep(
          'Verify, Sex, Gender Identity, Pronouns, preferred Name, tooltip massage on facesheet patient details page '
        );
        createCase.verifyToolTipMessage(
          orPatientDetails.SEX_TOOLTIP[1],
          orPatientDetails.SEX_TOOLTIP[0],
          AppToolTip.patient_details_sex
        );
        createCase.verifyToolTipMessage(
          orPatientDetails.GENDER_IDENTITY_TOOLTIP[1],
          orPatientDetails.GENDER_IDENTITY_TOOLTIP[0],
          AppToolTip.gender_identity
        );

        createCase.verifyToolTipMessage(
          orPatientDetails.PRONOUNS_TOOLTIP[1],
          orPatientDetails.PRONOUNS_TOOLTIP[0],
          AppToolTip.pronouns
        );
        createCase.verifyToolTipMessage(
          orPatientDetails.PREFERRED_NAME_TOOLTIP[1],
          orPatientDetails.PREFERRED_NAME_TOOLTIP[0],
          AppToolTip.preferred_name
        );

        cy.cGroupAsStep(
          'Verify, Sex, Gender Identity, Pronouns, preferred Name, Label on facesheet patient details page '
        );
        createCase.verifyLabelsInPatientDetails(orPatientDetails.SEX_LABEL[0]);
        createCase.verifyLabelsInPatientDetails(
          orPatientDetails.GENDER_IDENTITY_LABEL[0]
        );
        createCase.verifyLabelsInPatientDetails(
          orPatientDetails.PRONOUNS_LABEL[0]
        );
        createCase.verifyLabelsInPatientDetails(
          orPatientDetails.PREFERRED_NAME_LABEL[0]
        );

        cy.cGroupAsStep(
          'Verify, Sex, Gender Identity, Pronouns, preferred Name field value in facesheet patient details page '
        );
        createCase.verifyActiveSex(
          td_case_gender_identity_tcid_264773.PatientCase.PatientDetails.Gender
        );

        createCase.verifySelectedTextInPatientDetails(
          orPatientDetails.GENDER_IDENTITY[0],
          td_case_gender_identity_tcid_264773.PatientCase.PatientDetails
            .GenderIdentity
        );
        createCase.verifySelectedTextInPatientDetails(
          orPatientDetails.PRONOUNS[0],
          CommonUtils.concatenate(
            td_case_gender_identity_tcid_264773.PatientCase.PatientDetails
              .Pronouns[0],
            ', ',
            td_case_gender_identity_tcid_264773.PatientCase.PatientDetails
              .Pronouns[1]
          )
        );
        createCase.verifySelectedTextInPatientDetails(
          orPatientDetails.PREFERRED_NAME[0],
          td_case_gender_identity_tcid_264773.PatientCase.PatientDetails
            .PreferredName
        );

        patientFacesheet.clickOnCasesTab();

        sisOfficeDesktop.selectSisLogo();

        cy.cGroupAsStep(
          'Go to schedule grid, click patient tile, select edit and edit Sex, Gender Identity, Pronouns, preferred name'
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase.clickPreviousInCaseDetails();
        createCase.selectGender(
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
            .Gender
        );
        createCase.selectGenderIdentity(
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
            .GenderIdentity
        );
        createCase.clickCrossIcon(orPatientDetails.PRONOUNS[0]);

        createCase.selectPronouns(
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
            .Pronouns
        );
        createCase.enterPreferredName(
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
        );
        createCase.clickNextInCaseDetails();        
        createCase.clickCreateCaseDoneButton();

        cy.cGroupAsStep(
          'Navigating to facesheet and verify patient details which was edited '
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        patientFacesheet.clickOnPatientDetailsTab();
        createCase.verifyActiveSex(
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
            .Gender
        );
        createCase.verifySelectedTextInPatientDetails(
          orPatientDetails.GENDER_IDENTITY[0],
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
            .GenderIdentity
        );
        createCase.verifySelectedTextInPatientDetails(
          orPatientDetails.PRONOUNS[0],
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
            .Pronouns[0]
        );
        createCase.verifySelectedTextInPatientDetails(
          orPatientDetails.PREFERRED_NAME[0],
          td_case_gender_identity_tcid_264773.PatientCase1.PatientDetails1
            .PreferredName
        );
      });
    });
  }
}
