import {
  InvokeAttributes,
  InvokeMethods,
} from '../../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { AppColors } from '../../../../../../support/common-core-libs/application/constants/app-colors.constants';
import { SubRoutes } from '../../../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import ScheduleGridPrint from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid-print';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const scheduleGridPrint = new ScheduleGridPrint();
const scheduleGrid = new ScheduleGrid();

/* const values */
const defaultValue = 'default';
const number = 2000;

export class SisOfficeScdlGridPrintTcId49238 {
  selectNursingDesktop() {
    sisOfficeDesktop.selectOptionInUserMenuDropdown(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.SWITCH_TO_NURSING_DESKTOP[0]
    );
    /**** Verifying and closing the Notification Message ****/
    sisChartsDesktop.closeNotificationIcon();
  }

  changeToggleButtonSelection() {
    cy.cGet(
      OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
        .SELECTED_PORTRAIT_BACKGROUND_COLOR[1]
    )
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .then(($background) => {
        if (
          $background.toString() ==
          AppColors.component_enabled_toggle_button_selected
        ) {
          cy.cClick(
            OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
              .LANDSCAPE[1],
            OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
              .LANDSCAPE[0]
          );
        } else {
          cy.cClick(
            OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
              .PORTRAIT[1],
            OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
              .PORTRAIT[0]
          ).then(() => {
            sisOfficeDesktop.verifyBackgroundColor(
              OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
                .SELECTED_PORTRAIT_BACKGROUND_COLOR[1],
              OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID_POPUP.PREVIEW.LAYOUT
                .SELECTED_PORTRAIT_BACKGROUND_COLOR[0],
              AppColors.component_enabled_toggle_button_selected
            );
          });
        }
      });
  }

  verifyScheduleGridPrintPreviewOptions() {
    describe('Verify Print Icon, Print Options, Schedule Grid Preview fields and refresh button enabling when layout is changed in SIS Office', () => {
      it('Verify the Schedule Grid Print Options in Business Desktop Schedule Grid Print Preview Popup', () => {
        // #region - Selecting the Print icon and Clicking on Schedule Grid Preview

        cy.cGroupAsStep(
          'Logged In successfully with Gem_user4 and Selecting the Print icon and Clicking on Schedule Grid Preview'
        );

        scheduleGrid.clickPrintIcon();
        scheduleGridPrint.selectOptionToPreviewInPrintPopup(
          OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID[0]
        );
        // Waiting for loading spinner to disappear after clicking on preview
        cy.cWaitForElementToDisappear(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.ICON_IN_PROGRESS[1],
          OR_SCHEDULE_GRID.LOADING_SPINNER[0],
          number
        );
        // #endregion

        // #region - Verifying the Background color of the Portrait Option in Layout Toggle Button
        cy.cGroupAsStep(
          'Verifying the Background color of the Portrait Option in Layout Toggle Button'
        );
        this.changeToggleButtonSelection();
        scheduleGridPrint.verifyRefreshButton(true);
        // #endregion

        // #region - Verifying Physician is visible in GroupBy after re-login
        cy.cGroupAsStep(
          'Verifying Physician is visible in GroupBy after re-login'
        );
        scheduleGridPrint.verifyGroupByDefaultOptionAsPhysician();
        // #endregion

        // #region - Closing the Schedule Grid Preview and Navigate to Nursing Desktop
        cy.cGroupAsStep(
          'Closing the Schedule Grid Preview and Navigate to Nursing Desktop'
        );
        scheduleGridPrint.ClosePrintPreview();
        this.selectNursingDesktop();
        // #endregion
      });
    });
  }

  verifyPrintPageForAnotherOrg() {
    describe('Verify Schedule Grid Print Preview options in SIS Office after Changing the Login Location to Gem_Org005', () => {
      it('Verify Schedule Grid Print Preview options in Business Desktop in Gem_Org005', () => {
        cy.cWait(SubRoutes.config_schedule_get);
        cy.reload();
        cy.cWait(SubRoutes.config_schedule_get);
        // #region - Selecting the Print icon and Clicking on Schedule Grid Preview
        cy.cGroupAsStep(
          'Selecting the Print icon and Clicking on Schedule Grid Preview'
        );
        scheduleGrid.clickPrintIcon();
        scheduleGridPrint.selectOptionToPreviewInPrintPopup(
          OR_SCHEDULE_GRID.PRINT_POPUP.SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Verifying the Layouts in schedule grid preview
        cy.cGroupAsStep('Verifying the Layouts in schedule grid preview');
        scheduleGridPrint.verifyLayoutToggleButton();
        // #endregion

        // #region - Verifying refresh button is disabled by default
        cy.cGroupAsStep('Verifying refresh button is disabled by default');
        scheduleGridPrint.verifyRefreshButton(false);
        this.changeToggleButtonSelection();
        scheduleGridPrint.verifyRefreshButton(true);
        // #endregion

        // #region - Verifying Physician is visible in GroupBy by default
        cy.cGroupAsStep('Verifying Physician is visible in GroupBy by default');
        scheduleGridPrint.verifyGroupByDefaultOptionAsPhysician();
        // #endregion

        // #region - Closing the Schedule Grid Preview and Navigate to Nursing Desktop
        cy.cGroupAsStep(
          'Closing the Schedule Grid Preview and Navigate to Nursing Desktop'
        );
        cy.cWait(SubRoutes.case_request_get_pending_count);
        scheduleGridPrint.ClosePrintPreview();
        this.selectNursingDesktop();
        // #endregion
      });
    });
  }

  verifyNonAccessUser() {
    describe('Verify with user GEM_USERVSNOVCF(without scheduling view permission) should not able to access print Icon', () => {
      it('Logging out and login with the GEM_USERVSNOVCF user and Verify User does not have access for print icon', () => {
        // #region - Logging out from application and Logging with the GEM_USERVSNOVCF to Verify print Icon is disabled
        cy.cGroupAsStep(
          'Logging out from application and Logging with the GEM_USERVSNOVCF to Verify print Icon is disabled'
        );
        cy.cLogOut();

        /** Login into SIS Office application*/
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USERVSNOVCF[0],
          Password: UserList.GEM_USERVSNOVCF[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);

        cy.cHasCursor(
          OR_SCHEDULE_GRID.PRINT_ICON[1],
          OR_SCHEDULE_GRID.PRINT_ICON[0],
          defaultValue
        );
        // #endregion
      });
    });
  }
}
