import { td_patient_label_print_tcid_52033 } from '../../../../../../fixtures/sis-office/case/print/patient-label-print-tcid-52033.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import ScheduleGridPrint from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid-print';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(
  td_patient_label_print_tcid_52033.PatientCase
);
const scheduleGrid = new ScheduleGrid();
const scheduleGridPrint = new ScheduleGridPrint(
  td_patient_label_print_tcid_52033.PrintPreviewInfo[1]
);

export class PatientLabelPrintTcId52033 {
  verifyPatientLabelsAndDefaultValues() {
    describe('Verify Patient Label Print Preview In Business DesktopAnd Default Values displayed In Patient Label Print Options', () => {
      it('Verify the Print Options and preview blocks after selecting Patient Label in Business Desktop Print Popup', () => {
        // #region - Verify Total cases count and create new patient if not available

        cy.cGroupAsStep(
          'Verify Total cases count and create new patient if not available'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cGet(OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TOTAL_CASES_COUNT[1]).then(
          ($element) => {
            if (Number($element.text().trim()) == 0) {
              createCase.clickCreateACaseTab();
              createCase.createNewPatient(
                createCase.patientCaseModel!.PatientDetails
              );
              createCase.createCase();
            }
          }
        );
        // #endregion

        // #region - Selecting Patient Labels in Print Popup and click on Preview Button
        cy.cGroupAsStep(
          'Selecting Patient Labels in Print Popup and click on Preview Button'
        );
        scheduleGrid.clickPrintIcon();
        scheduleGridPrint.selectOptionToPreviewInPrintPopup(
          OR_SCHEDULE_GRID.PRINT_POPUP.PATIENT_LABELS[0]
        );
        // #endregion

        // #region - Verify the Labels in Patient Labels Print Popup Screen
        cy.cGroupAsStep(
          'Verify the Labels in Patient Labels Print Popup Screen'
        );
        //Verify fields in Patient Labels Print Popup
        scheduleGridPrint.verifyPatientLabelsPrintOptions();
        // #endregion

        // #region - Verify default values in Print Options
        cy.cGroupAsStep('Verify default values in Print Options');
        //Verify Default Field Values in Patient Label Print Popup screen
        scheduleGridPrint.verifyValuesInPatientLabelsOptions(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[0]
        );
        //Verify number of patient blocks in patient labels popup
        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[0]
            .NoOfPatientLabelBlocks!
        );
        // #endregion
      });
    });
  }

  verifyMaxAndMoreThanMaxPrintOptions() {
    describe('Verify the values accepted by Print Options by giving Max values and more than Max values', () => {
      it('Entering Max Allowed Values and More than Max Allowed Values in Print Options and Verify the Results', () => {
        // #region - Verify Max Allowed Values in Patient Labels Print Popup
        cy.cGroupAsStep(
          'Verify Max Allowed Values in Patient Labels Print Popup'
        );
        scheduleGridPrint.enterValuesInPatientLabelsOptions(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[1]
        );
        // Verify maximum allowed values
        scheduleGridPrint.verifyValuesInPatientLabelsOptions(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[1]
        );
        // Verify maximum number of patient blocks in patient labels popup
        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[1]
            .NoOfPatientLabelBlocks!
        );
        // #endregion

        // #region - Verify the Print fields by entering more than max values
        cy.cGroupAsStep(
          'Verify the Print fields by entering more than max values'
        );
        scheduleGridPrint.enterValuesInPatientLabelsOptions(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[2]
        );
        // #endregion

        // #region - Verify the Print fields by entering negative test data
        cy.cGroupAsStep(
          'Verify the Print fields by entering negative test data'
        );
        scheduleGridPrint.verifyValuesInPatientLabelsOptions(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[1]
        );
        // #endregion

        // #region - Verify maximum number of patient blocks in patient labels popup and close Print popup
        cy.cGroupAsStep(
          'Verify maximum number of patient blocks in patient labels popup'
        );
        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_print_tcid_52033.PrintPreviewInfo[1]
            .NoOfPatientLabelBlocks!
        );
        scheduleGridPrint.ClosePrintPreview();
        // #endregion
      });
    });
  }
}
