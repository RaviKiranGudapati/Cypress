import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { BlockScheduleTcId259994 } from './scenarios/tcid-259994.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const blockSchedule = new BlockScheduleTcId259994();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.verify presence of block name
 * 2.Entering  block details
 * 3.Entering Wrong End Time and verifying the error message
 * 4.Entering value in Physician and multiselect dropdown
 * 5.verifying slide tab out functionality
 * 6.Select and verify Existing Block
 * 7.verify error message and fill mandatory fields in New Block
 * 8. Logout from application
 */

describe(
  'Verify Block Schedule Grid functionality',
  { tags: ['block-schedule', 'TC#259994', 'US#260244'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        blockSchedule.verifyNewBlockMandatoryFields();
        blockSchedule.verifyExistingBlockFields();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
