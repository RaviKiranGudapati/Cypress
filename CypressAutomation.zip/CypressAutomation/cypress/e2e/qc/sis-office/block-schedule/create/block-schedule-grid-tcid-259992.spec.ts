import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { BlockScheduleTcId259992 } from './scenarios/tcid-259992.sc';

/* instance variables */
const blockSchedule = new BlockScheduleTcId259992();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to the application
 * 2. Click on the logged-in user dropdown
 * 3. Click on Application settings
 * 4. Search for block scheduling in the configuration
 * 5. Add and enter all the block details (Mandatory fields)
 * 6. click on done only when all the mandatory fields are selected
 * 7. Click on SIS logo and navigate back to business desktop page
 * 8. Click on Block schedule grid and enter all the block details (mandatory fields)
 * 9. Check for scheduling conflict message, select another room and click on done
 * 10. Navigate to Schedule grid and click on Test Block 1 as per dates configured (Monday) and check the date change
 * 11. Click on create block and navigate to existing block and choose Test Block 3
 * 12. Navigate to schedule grid and check whether the Block 4 & 5is created as per the given recurrence details
 * 13. Check whether the case is getting created in Test Block 4 and should be able to create
 * 14. Check whether the case is getting created for Test Block 5 and case should not be create and it should a Room closed message
 */

describe(
  'Verify recurring block creation and Add 5th week in Block Scheduling Configuration and Allow Multi-Select for Rooms',
  { tags: ['block-schedule', 'TC#259992', 'US#260243'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed

    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        blockSchedule.verifyBlockSchedulingApplicationSettings();
        blockSchedule.verifyBlockSchedulingGrid();
        blockSchedule.verifyTestBlock1();
        blockSchedule.verifyChangeDate();
        blockSchedule.verifyBlock();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
