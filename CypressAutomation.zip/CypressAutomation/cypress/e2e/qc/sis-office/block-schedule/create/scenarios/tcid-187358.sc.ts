import { Application } from '../../../../../../support/common-core-libs/application/common-core';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_block_schedule_tcid_187358 } from '../../../../../../fixtures/sis-office/block-schedule/create/block-schedule-tcId-187358.td';

import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_BLOCK_CREATION } from '../../../../../../app-modules-libs/sis-office/block-creation/or/create-block.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import createBlock from '../../../../../../app-modules-libs/sis-office/block-creation/create-block';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';

/* instance variables */
const createBlocks = new createBlock();
const createCase = new CreateCase(td_block_schedule_tcid_187358.PatientCase[0]);
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfiguration = new NursingConfiguration();
const nursingConfigurationLayout = new NursingConfigurationLayout();

export class BlockScheduleTcId187358 {
  verifyBlockSchedulingApplicationSettings() {
    describe('Creating two recurring blocks(Test Block1, Test Block2) from application settings ', () => {
      it('Entering block scheduling details for creation of both the blocks', () => {
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0]
        );
        nursingConfiguration.addBlockScheduling(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].BlockName
        );

        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].Physician
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].Room
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].Specialty
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].StartTime
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].EndTime
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].StartDate
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].EndDate
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].RecurEvery
        );
        nursingConfiguration.selectWeeklyAndMonthlyRadioButton(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY[0]
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[0].WeeksOn
        );

        // #region -Creating Block 2

        cy.cGroupAsStep('Entering block scheduling Details for Test Block 2');

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_NOTES[0]
        );

        cy.cGroupAsStep('Selecting Block Scheduling Configuration');
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0]
        );
        nursingConfiguration.addBlockScheduling(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].BlockName
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].Physician
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].Room
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].Specialty
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].BlockColor
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].StartTime
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].EndTime
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].StartDate
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].EndDate
        );
        nursingConfiguration.enterBlockDetails(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].RecurEvery
        );
        nursingConfiguration.selectWeeklyAndMonthlyRadioButton(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY[0]
        );
        nursingConfiguration.selectDropdownInBlockScheduling(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[1].WeeksOn
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_NOTES[0]
        );
        // #endregion

        // #region -Navigate to business desktop and select Block schedule under schedule type

        cy.cGroupAsStep(
          'Navigate to business desktop and select Block schedule under schedule type'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        // #endregion
      });
    });
  }

  verifyBlockScheduleGrid() {
    describe('Creating other new blocks from block schedule tab ', () => {
      it('Creation of new Blocks from block schedule ', () => {
        createBlocks.openBlockScheduleTab();
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].BlockName
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].StartDate
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.START_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].StartTime
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.END_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].EndTime
        );

        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.PHYSICIAN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].Physician[0]
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.SPECIALTY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].Specialty
        );
        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.selectMultiSelectRoom(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].Room
        );

        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.clickOnDoneButton();
        // #region-Create test block 4

        cy.cGroupAsStep('Create test block 4');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        createBlocks.openBlockScheduleTab();
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].BlockName
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].StartDate
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.START_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].StartTime
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.END_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].EndTime
        );

        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.PHYSICIAN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].Physician[0]
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.SPECIALTY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].Specialty
        );
        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.selectMultiSelectRoom(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].Room
        );

        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.clickOnDoneButton();

        // #endregion

        // #region -Creating Test block 5

        cy.cGroupAsStep('Creating Test block 5');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        createBlocks.openBlockScheduleTab();
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].BlockName
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].StartDate
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.START_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].StartTime
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.END_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].EndTime
        );

        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.PHYSICIAN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].Physician[0]
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.SPECIALTY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].Specialty
        );
        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.selectMultiSelectRoom(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].Room
        );

        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.clickOnDoneButton();
        // #endregion

        // #region -Creating test block 6

        cy.cGroupAsStep('Creating test block 6');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        createBlocks.openBlockScheduleTab();
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[5].BlockName
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.DATE[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[5].StartDate
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.START_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[5].StartTime
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.END_TIME[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[5].EndTime
        );

        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.PHYSICIAN[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[5].Physician[0]
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.SPECIALTY[0],
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[5].Specialty
        );
        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.selectMultiSelectRoom(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[5].Room
        );

        cy.cRemoveMaskWrapper(Application.office);

        createBlocks.clickOnDoneButton();
        // #endregion
      });
    });
  }

  createCasesForBlockUtilization() {
    describe('Creating patients over the added test blocks for the verification of positive and negative utilization', () => {
      it('Create a new Patient and verify Block Positive and negative utilization across all the blocks', () => {
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.clickBlockNameInSchedule(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].BlockName
        );
        createCase.createNewPatient(
          td_block_schedule_tcid_187358.PatientCase[1].PatientDetails
        );
        createCase.enterPatientDetails(
          td_block_schedule_tcid_187358.PatientCase[1].PatientDetails
        );
        createCase.selectAppointmentType(
          td_block_schedule_tcid_187358.PatientCase[1].CaseDetails
            .AppointmentType
        );
        createCase.enterCPTRowData(
          td_block_schedule_tcid_187358.PatientCase[1].CaseDetails
            .CptCodeInfo[0]
        );
        createCase.clickNextInCaseDetails();
        sisOfficeDesktop.clickDoneButton();

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_block_schedule_tcid_187358.PatientCase[1].PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );

        // #region -Verify Block positive utilization

        cy.cGroupAsStep('Verify Block positive utilization');
        createCase.verifyPresenceOfBlockUtilization(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[3].BlockName
        );
        sisOfficeDesktop.clickDoneButton();

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.clickCreateACaseTab();

        createCase.createNewPatient(
          td_block_schedule_tcid_187358.PatientCase[0].PatientDetails
        );
        createCase.createCase();

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_block_schedule_tcid_187358.PatientCase[0].PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        // #endregion

        // #region -verifying block Utilization

        cy.cGroupAsStep('Verify Block negative utilization');
        createCase.verifyPresenceOfBlockUtilization(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].BlockName,
          false
        );

        createCase.selectRoom(
          td_block_schedule_tcid_187358.PatientCase[3].CaseDetails.OperatingRoom
        );

        cy.cRemoveMaskWrapper(Application.office);
        createCase.clickNextInCaseDetails;
        createCase.clickPreviousInBillingDetails();
        createCase.clickNextInPatientDetails();
        // #endregion

        // #region -verifying block Utilization

        cy.cGroupAsStep('Verify Block Positive utilization');
        createCase.verifyPresenceOfBlockUtilization(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[2].BlockName
        );
        sisOfficeDesktop.clickDoneButton();

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.clickBlockNameInSchedule(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].BlockName
        );

        createCase.createNewPatient(
          td_block_schedule_tcid_187358.PatientCase[2].PatientDetails
        );
        createCase.enterPatientDetails(
          td_block_schedule_tcid_187358.PatientCase[2].PatientDetails
        );
        createCase.selectAppointmentType(
          td_block_schedule_tcid_187358.PatientCase[2].CaseDetails
            .AppointmentType
        );
        createCase.enterCPTRowData(
          td_block_schedule_tcid_187358.PatientCase[2].CaseDetails
            .CptCodeInfo[0]
        );
        createCase.verifyPresenceOfBlockUtilization(
          td_block_schedule_tcid_187358.BlockInfos.CreateBlock[4].BlockName
        );
        createCase.clickNextInCaseDetails();
        sisOfficeDesktop.clickDoneButton();
        // #endregion
      });
    });
  }
}
