import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { BlockScheduleTcId187358 } from './scenarios/tcid-187358.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const blockScheduleTcId87358 = new BlockScheduleTcId187358();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to the application
 * 2.Navigate to nursing configuration page
 * 3.Select configuration Block scheduling
 * 4.Create blocks
 * 5.Navigate to business desktop
 * 6.Create blocks from block schedule.
 * 7.Create Patient and verify negative and positive utilizations
 * 8. Logout from application
 */

describe(
  'Block scheduling:Verifying positive and negative block utilization',
  { tags: ['block-schedule', 'TC#87358', 'US#261967'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        blockScheduleTcId87358.verifyBlockSchedulingApplicationSettings();
        blockScheduleTcId87358.verifyBlockScheduleGrid();
        blockScheduleTcId87358.createCasesForBlockUtilization();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
