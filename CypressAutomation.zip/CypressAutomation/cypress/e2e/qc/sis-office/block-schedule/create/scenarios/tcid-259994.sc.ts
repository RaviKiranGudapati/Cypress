import { Application } from '../../../../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_block_schedule_tcid_259994 } from '../../../../../../fixtures/sis-office/block-schedule/create/block-schedule-tcid-259994.td';

import { AppErrorMessages } from '../../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_BLOCK_CREATION } from '../../../../../../app-modules-libs/sis-office/block-creation/or/create-block.or';

import createBlock from '../../../../../../app-modules-libs/sis-office/block-creation/create-block';

/* instance variables */
const createBlocks = new createBlock();
const sisOfficeDesktop = new SISOfficeDesktop();

export class BlockScheduleTcId259994 {
  verifyNewBlockMandatoryFields() {
    describe('Verify Creating a Block by clicking Create a Block Slide-out and Hooking up the Create a Block Slide-out', () => {
      it('Verify end time greater warning message in Create a new Block and save Block by providing mandatory fields', () => {
        // #region - Verify the user is able to click on block schedule

        cy.cGroupAsStep('Verify the user is able to click on block schedule');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        createBlocks.openBlockScheduleTab();
        // #endregion

        // #region - Enter details to create block

        cy.cGroupAsStep('Enter details to create block');
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.BlockName
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.DATE[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.Date
        );
        // #endregion

        // #region - Verify warning message by giving end time lesser than start time

        cy.cGroupAsStep(
          'Verify warning message by giving end time lesser than start time'
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.START_TIME[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.StartTime
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.END_TIME[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.EndTime2
        );
        cy.cIsVisible(
          selectorFactory.getSmallText(
            AppErrorMessages.end_time_should_greater
          ),
          AppErrorMessages.end_time_should_greater
        );
        // #endregion

        // #region - Verify creating Block schedule tile in schedule grid

        cy.cGroupAsStep('Verify creating Block schedule tile in schedule grid');
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.END_TIME[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.EndTime
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.PHYSICIAN[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.Physician
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.SPECIALTY[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.Specialty
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.ROOM[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.Room
        );
        cy.cRemoveMaskWrapper(Application.office);
        createBlocks.collapseBlockScheduleTab();
        createBlocks.openBlockScheduleTab();

        createBlocks.clickOnDoneButton();
        // #endregion
      });
    });
  }
  verifyExistingBlockFields() {
    describe('Verify Renaming Existing Block validation with block name mandatory error message', () => {
      it('Verify Renaming Existing Block validation with block name mandatory error message', () => {
        // #region - verify recurring block error message

        cy.cGroupAsStep('verify recurring block error message');
        createBlocks.selectBlock(
          td_block_schedule_tcid_259994.BlockInfo.createBlock.BlockName,
          td_block_schedule_tcid_259994.BlockInfo.createBlock.BlockName
        );
        createBlocks.selectExistingBlockAndVerifyMessage();
        // #endregion

        // #region - verify block name mandatory error message
        cy.cGroupAsStep('verify block name mandatory error message');
        createBlocks.verifyBlockNameMandatoryErrorMessage();
        // #endregion

        // #region - verify block creation by filling mandatory fields
        cy.cGroupAsStep('verify block creation by filling mandatory fields');
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME[0],
          td_block_schedule_tcid_259994.BlockInfo.ExistingBlock.BlockName
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.PHYSICIAN[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.Physician
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.SPECIALTY[0],
          td_block_schedule_tcid_259994.BlockInfo.createBlock.Specialty
        );
        cy.cRemoveMaskWrapper(Application.office);
        createBlocks.clickOnDoneButton();
        // #endregion
      });
    });
  }
}
