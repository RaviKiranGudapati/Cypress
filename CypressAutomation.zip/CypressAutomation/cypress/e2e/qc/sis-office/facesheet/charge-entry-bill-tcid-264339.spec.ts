import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { ChargeEntryBillCheckingTcid264339 } from './scenarios/tcid-264339.sc';

/*instance variables*/
const chargeEntryBillChecking = new ChargeEntryBillCheckingTcid264339();

/**********************Test Script Validation Details *************************
 * 1.Login SIS Complete Business desktop with User1,Navigate to patient1 Ledger tab.
 *2.Click on Add Button and Enter Unassigned Payment details and Click Done.
 *3.Allocate the payment to the Procedure1 Go to FaceSheet Charge Entry for the  Procedure1,and Verify Generate Bill is checked.
 *4.Navigate to FaceSheet Transactions tab Edit the allocation amount for Procedure1.
 *5.Navigate back to FaceSheet Charge Entry for the  Procedure1,and Verify Generate Bill is checked.
 *6.Navigate to Schedule grid enter in Trackers Revenue Cycle Management Click on Patient 1,allocation amount for Procedure1.
 *7.Navigate back to FaceSheet Charge Entry for the  Procedure1,and Verify Generate Bill is checked.
 *8.Navigate to FaceSheet Transactions tab Edit the allocation amount added From (RCM)for Procedure1.
 *9.Navigate back to FaceSheet Charge Entry for the  Procedure1,and Verify Generate Bill is checked.
 *10.Navigate to Schedule grid enter in Trackers Remittance Posting click Manual Remittance Posting.
 *11.Enter Case Date of Service, Received From, Check Amount, Period Batch, Transaction Date, Generate Bill Payments, Write-offs, Debits and Transfers modal window.
 *12.Select Procedure2 Select period and batch Enter the allocation amount from unassigned payment and Click Done.
 *13.Select Post EOB as Yes and Click Done and Post.
 *14.Navigate back to FaceSheet Charge Entry for the  Procedure2,and Verify Generate Bill is checked.
 *15.Navigate to FaceSheet Transactions tab Edit the allocation amount added From  Remittance Posting for Procedure2.
 *16.Navigate back to FaceSheet Charge Entry for the  Procedure2,and Verify Generate Bill is checked.
 */

describe(
  'Verify Bill is Checked even after Allocating Unassigned Pavement from Ledger tab,Revenue Cycle Management and Remittance Posting',
  { tags: ['facesheet', 'TC#264339', 'US#269620'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        chargeEntryBillChecking.verifyBillIsUnchecked();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
