import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { VerifyFieldsInLedgerAndTransactions263220 } from './scenarios/tcid-263220.sc';

/* instance variables */
const verifyFields = new VerifyFieldsInLedgerAndTransactions263220();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * Pre-Condition: -- Make sure one Patient is created, one period and one batch are created,
 * --transaction codes of types (correction, unassigned payment, allocation) are created,
 * --and discharge the patient with procedure of charge $5000.00
 * 1. Login into application and navigate to Schedule grid.
 * 2. Search and select patient from mast head, click on ledger
 * 3. Add Unassigned payment(200) and verify the options in context menu
 * 4. Click on Allocate in context menu and verify model window is opened, has fields has documented in unassigned payment
 * 5. verify the Allocated amount, Due field, Unallocated with different allocation amounts and allocate 100
 * 6. Navigate to Cases tab >> Transactions , Click on Correction for allocation amount 200 verify the fields has documented in ledger allocation page
 * 7. Navigate to Ledger tab >> show aging, verify the balance and amounts
 */

describe(
  'Verify Ledger Unassigned payment, Allocate, Correction fields from check-in',
  { tags: ['facesheet', 'TC#263220', 'US#263589'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After All(it) blocks , action to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        verifyFields.verifyFieldsInLedger();
        verifyFields.verifyFieldsInTransactions();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
