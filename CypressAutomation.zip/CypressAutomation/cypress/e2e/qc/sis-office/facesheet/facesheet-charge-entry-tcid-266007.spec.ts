import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { FaceSheetChargeEntryTcId266007 } from './scenarios/tcid-266007.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const faceSheetChargeEntry = new FaceSheetChargeEntryTcId266007();

/**********************Test Script Validation Details *************************
 * 1.Login to the application and select the patient 1 Masthead and navigate to face sheet.
 * 2.Select charge entry from my task and select Procedure1
 * 3.Verify Balance amount at charge tab and In the 1st line, it should display the write off Contractual amount
     In the 2nd line, it should not display the contractual discount
 * 4.Add procedure and verify charge Amount.
 * 5. verify contractual writeoff & multi procedure discount at Adjustment tab by selecting insurances individually to primary insurance.
 * 6.On Hover of the Procedure1 and drag and drop the charge at other procedure row and check for the contractual writeoff & multi procedure discount at Adjustment tab .
 * 7.verify In the 1st line, it should display the write off Contractual amount. In the 2nd line, it should not display the contractual discount.
 * 8.Click on add other procedure which is not configured with amount and verify charge amount should not display.
 * 9.Add procedure which is configured with amount and verify charge amount should be displayed.
 * 10.Update quantity to 2 and verify charge amount.
 * 11.Click on update button and verify saved Amount  and Balance and those should be display as like before save.
 * 12.Logout from the application.
 */

describe(
  'Verify Charges are posted with contracts in my tasks charge entry',
  { tags: ['charge-entry', 'US#266531', 'TC#266007'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        faceSheetChargeEntry.verifyCharges();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
