import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { MyTaskChargeEntryTcid264161 } from './scenarios/tcid-264161.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/*instance variables*/
const myTaskChargeEntry = new MyTaskChargeEntryTcid264161();

/**********************Test Script Validation Details *************************
 * 1. Login to the application and select the patient 1 from global search box and navigate to face sheet.
 * 2. Select charge entry from my task.
 * 3. Add 2 supplies to patient case 1 with charge amount respectively.
 * 4. Add charge amount to all procedure and click on auto sort button.
 * 5. Verify that all procedure and supplies should automatically auto sort according to auto sort logic.
 * 6. Add charge and verify auto sort button functionality.
 * 7. Select patient 2 from global search box and navigate to face sheet.
 * 8. Select charge entry from my task.
 * 9. Verify that all procedure and supplies should automatically auto sort according to auto sort logic.
 * 10. Logout from the application.
 */

describe(
  'Verify Auto sort button and its functionality in My Tasks Charge entry',
  { tags: ['facesheet', 'TC#264161', 'US#264926'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        myTaskChargeEntry.autoSortFacesheet();
        myTaskChargeEntry.autoSortChargeEntry();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
