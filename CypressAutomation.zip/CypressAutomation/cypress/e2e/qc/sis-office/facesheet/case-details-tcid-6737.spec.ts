import { UserList } from '../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';

import { CaseDetailsTcId6737 } from './scenarios/tcid-6737.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const caseDetails = new CaseDetailsTcId6737();

/*****************Test Script Validation Details **********************
 1.create patient 1 and 2 using seed data, search for patient after login
2.navigate to case details from faceSheet modified all data and add preference cards,equipments and one more CPT code.
3.navigate payer details navigate back to case details and verify modified data is saved or not.
4.navigate business desktop scheduling and verify patient according details modified.
5.click on patient2 from MastHead search.
6.navigate to case details  from faceSheet and remove mandatory fields one by one and verify warning message.
7.enter all mandatory fields back one by one and verify if warning messages disappears
8.navigate payer details and back to case details to verify modified data is saved or not.
9.logout and login sis office with user2 and verify warning message (User2 do not have modify access in scheduling).
 */

describe(
  'Verify the data and warning messages by modifying and Updating data in Face Sheet Case Details Tab',
  { tags: ['facesheet', 'TC#6737', 'US#2625138'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_4[0],
        Password: UserList.GEM_USER_4[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        caseDetails.verifyCaseDetailsDataOfPatient_One();
        caseDetails.verifyCaseDetailsDataOfPatient_Two();
        caseDetails.verifyUser2modifyPermission();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
