import { UserList } from '../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';
import { LedgerBillingHistoryTcId266916 } from './scenarios/tcid-200160.sc';

/* instance variables */
const ledgerBillingHistory = new LedgerBillingHistoryTcId266916();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 *1.Login to the application and select the patient 1 Masthead and navigate to face sheet Ledger tab.
 *2.Click on Billing history and Verify data under each column headers for the listed items.
 *3.Verify 'Bill Selected charges', 'Print selected charges' buttons and Check box.
 *4.Click on '+' for respected Case and Verify previous Billing history and Verify data under each column headers for the listed items.
 *5.Click on '-' and Verify list of items should collapse.
 *6.Select patient 1 case and click on 'Bill Selected charges' and verify conform pop.
 *5.verify current billed new line and previous billed line.
 *7.Select patient 2 case and click 'Print selected charge' and verify Print button.
 *8.In ledger tab verify '+' should not display as no since the charges has no History.
 *9.In Billing history Click on '+' for respected Case and Verify previous Billing history and Verify data under each column headers for the listed items.
 *10.Select patient 3 case Billing and click on 'Bill Selected charges' and verify conform pop.
 *11.Select patient 3 case Billing and click 'Print selected charge' and verify Print button.
 *12.Select patient 4 case Billing and click on 'Bill Selected charges' and verify conform pop.
 *13.Click on patient 5 case Billing and verify billed amount should be 3500.
 *14.Select patient 5 case Billing verify paper form as N/A in procedure2.
 *15.Select procedure2, click on Bill selected payers and Verify Error message pop up.
 *16.Select procedure1, procedure3 click on Bill selected payers and Verify Error message pop up.
 *17.Select procedure1, procedure2 click on Bill selected payers and Verify Error message pop up.
 */

describe(
  'Verify Billing History in Ledger tab FaceSheet',
  { tags: ['facesheet', 'TC#200160', 'US#266916'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        ledgerBillingHistory.verifyBillingHistoryInLedger();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
