import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { FacsheetPaymentTcId261980 } from './scenarios/tcid-261980.sc';

/*instance variables*/
const faceheetPayment = new FacsheetPaymentTcId261980();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to application  and click on add button in Ledger tab, Add allocate amount and unassigned amount for all cases.
 * 2. Verify that the Unallocated payment should be displayed under the current Aging bucket.
 * 3. Verify the CPT and CDT copyright information for all the cases.
 * 4. Verify that the Unallocated payment should be displayed under for different days in Aging bucket.
 * 5. Verify that its should display the Total Balance  for all cases(case 1,case 2,case 3,case 4 and case 5) as document for Unallocated payment for each case
 * 6. Navigate cases tab and Click Print icon(Patient 1 case 1 panel) and verify the print icon pop up options
 * 7. Login to application and  Check for the context menu for the  Unassigned Payments in ledger
 * 8. Verify that that will not be any option for the user to view Allocate or Edit for the Unallocated Payments context menu.
 * 9. Logout from application
 */

describe(
  ' Verify Calculation of Unassigned Payments in Aging and copy right information in transaction screen ',
  { tags: ['facesheet', 'TC#261980', 'US#262536'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_7[0],
        Password: UserList.GEM_USER_7[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_7, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        faceheetPayment.verifyUnallocatedPayment();
        faceheetPayment.verifyTotalAmountInAging();
        faceheetPayment.verifyContextMenuNotVisible();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
