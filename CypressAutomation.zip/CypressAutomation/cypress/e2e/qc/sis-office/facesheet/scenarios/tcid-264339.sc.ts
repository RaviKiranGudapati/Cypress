import {
  DoneOrCancel,
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_charge_entry_tcid_264339 } from '../../../../../fixtures/sis-office/facesheet/charge-entry-bill-tcid-264339.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_REMITTANCE_POSTING } from '../../../../../app-modules-libs/sis-office/trackers/or/remittance-posting.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import FaceSheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import PatientDetailsFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import { RemittancePosting } from '../../../../../app-modules-libs/sis-office/trackers/remittance-posting';
import RevenueCycleManagement from '../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import { ShowHidePayments } from '../../../../../app-modules-libs/sis-office/trackers/enums/revenue-cycle-management.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const patientDetailsFaceSheet = new PatientDetailsFaceSheet();
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const revenueCycleManagement = new RevenueCycleManagement();
const remittancePosting = new RemittancePosting();
const facesheetCases = new FaceSheetCases();

/* const values */
const index = ['0', '1'];

export class ChargeEntryBillCheckingTcid264339 {
  verifyBillIsUnchecked() {
    describe('Verify Bill is Checked even after Allocating Unassigned Payment from Ledger tab, Revenue Cycle Management and Remittance Posting', () => {
      it('Verify Bill is Checked even after Allocating Unassigned Payment from Ledger tab', () => {
        // #region - Select patient and navigate ledger tab and allocate unassigned Payment to case one

        cy.cGroupAsStep(
          'Select patient and navigate ledger tab and allocate unassigned Payment'
        );
        sisOfficeDesktop.pickPatient(
          td_charge_entry_tcid_264339.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_charge_entry_tcid_264339.UnassignedPay
        );
        ledgerTabFaceSheet.selectContextMenu();
        ledgerTabFaceSheet.clickOnAllocate();
        ledgerTabFaceSheet.unassignedPaymentAllocation(
          td_charge_entry_tcid_264339.UnassignedAllocated[0],
          index[1]
        );
        // #endregion

        // #region - Navigate to charge entry and Verify Generate Bill as checked

        cy.cGroupAsStep(
          'Navigate to charge entry and Verify Generate Bill as checked'
        );
        patientDetailsFaceSheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.verifyGenerateBillAsChecked(
          td_charge_entry_tcid_264339.CptCodeInfo[0].CPTCodeAndDescription
        );
        // #endregion

        // #region - Navigate to Transactions edit added unassigned payment and Navigate back to charge entry and Verify Generate Bill as checked

        cy.cGroupAsStep(
          'Navigate to Transactions edit added unassigned payment and Navigate back to charge entry and Verify Generate Bill as checked'
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        transactions.clickOnTransactionContextMenu(
          0,
          OR_TRANSACTION.CHARGES.ALLOCATION[0]
        );
        ledgerTabFaceSheet.unassignedPaymentAllocation(
          td_charge_entry_tcid_264339.UnassignedAllocated[1],
          index[0]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.verifyGenerateBillAsChecked(
          td_charge_entry_tcid_264339.CptCodeInfo[0].CPTCodeAndDescription
        );
        // #endregion
      });

      it('Verify Bill is Checked even after Allocating Unassigned Payment in RCM tracker', () => {
        // #region - Navigate to RCM tracker and Allocate Unassigned payment

        cy.cGroupAsStep(
          'Navigate to RCM tracker and Allocate Unassigned payment'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        sisOfficeDesktop.selectPatientRow(
          td_charge_entry_tcid_264339.PatientCase.PatientDetails
            .PatientFirstName,
          td_charge_entry_tcid_264339.PatientCase.PatientDetails.LastName
        );
        revenueCycleManagement.selectResponsiblePartyTab(
          td_charge_entry_tcid_264339.RcmDetails.Subscriber
        );
        revenueCycleManagement.clickHideShowPayments(
          ShowHidePayments.show_payments
        );
        revenueCycleManagement.allocateUnassignedPayment(
          td_charge_entry_tcid_264339.UnassignedAllocated[0],
          index[1]
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion

        // #region - Navigate to charge entry and Verify Generate Bill as checked

        cy.cGroupAsStep(
          'Navigate to charge entry and Verify Generate Bill as checked'
        );
        sisOfficeDesktop.pickPatient(
          td_charge_entry_tcid_264339.PatientCase.PatientDetails
        );
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.verifyGenerateBillAsChecked(
          td_charge_entry_tcid_264339.CptCodeInfo[0].CPTCodeAndDescription
        );
        // #endregion

        // #region - Navigate to Transactions edit added unassigned payment and Navigate back to charge entry and Verify Generate Bill as checked

        cy.cGroupAsStep(
          'Navigate to Transactions edit added unassigned payment and Navigate back to charge entry and Verify Generate Bill as checked'
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        transactions.clickOnTransactionContextMenu(
          1,
          OR_TRANSACTION.CHARGES.ALLOCATION[0]
        );
        ledgerTabFaceSheet.unassignedPaymentAllocation(
          td_charge_entry_tcid_264339.UnassignedAllocated[1],
          index[0]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.verifyGenerateBillAsChecked(
          td_charge_entry_tcid_264339.CptCodeInfo[0].CPTCodeAndDescription
        );
        // #endregion
      });

      it('Verify Bill is Checked even after Allocating Unassigned Payment in Remittance Posting', () => {
        // #region - Navigate to Remittance Posting tracker and Allocate Unassigned payment

        cy.cGroupAsStep(
          'Navigate to Remittance Posting tracker and Allocate Unassigned payment'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REMITTANCE_POSTING[0]
        );
        remittancePosting.selectManualRemittancePostingButton();
        remittancePosting.selectAnyDateInCaseDateOfService(
          td_charge_entry_tcid_264339.PatientCase.CaseDetails.DateOfService,
          OR_REMITTANCE_POSTING.START_DOS[1]
        );
        remittancePosting.selectValueFromReceivedFromDropdown(
          td_charge_entry_tcid_264339.Charges.PrimaryInsurance
        );
        remittancePosting.selectAnyDateInCaseDateOfService(
          td_charge_entry_tcid_264339.PatientCase.CaseDetails.DateOfService,
          OR_REMITTANCE_POSTING.END_DOS[1]
        );
        remittancePosting.enterCheckAmount(
          td_charge_entry_tcid_264339.ManualRemittancePosting.CheckAmount
        );
        remittancePosting.selectPeriodAndBatch(
          td_charge_entry_tcid_264339.Charges
        );
        remittancePosting.clickOnEllipsisBasedOnCpt(
          td_charge_entry_tcid_264339.CptCodeInfo[1].CPTCodeAndDescription
        );
        remittancePosting.clickOnDownActive();
        remittancePosting.clickOnAllocate();
        remittancePosting.unassignedPaymentAllocation(
          td_charge_entry_tcid_264339.UnassignedAllocated[0],
          index[0]
        );
        remittancePosting.clickOnDoneButton();
        remittancePosting.clickOnPostEobYesOrNoAndDone(YesOrNo.yes);
        remittancePosting.clickOnPostEobYesOrNoAndDone(DoneOrCancel.done);
        remittancePosting.clickOnPostRemittancePost();
        // #endregion

        // #region - Navigate to charge entry and Verify Generate Bill as checked

        cy.cGroupAsStep(
          'Navigate to charge entry and Verify Generate Bill as checked'
        );
        sisOfficeDesktop.pickPatient(
          td_charge_entry_tcid_264339.PatientCase.PatientDetails
        );
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.verifyGenerateBillAsChecked(
          td_charge_entry_tcid_264339.CptCodeInfo[0].CPTCodeAndDescription
        );
        // #endregion

        // #region - Navigate to Transactions edit added unassigned payment and Navigate back to charge entry and Verify Generate Bill as checked

        cy.cGroupAsStep(
          'Navigate to Transactions edit added unassigned payment and Navigate back to charge entry and Verify Generate Bill as checked'
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        transactions.clickOnTransactionContextMenu(
          0,
          OR_TRANSACTION.CHARGES.ALLOCATION[0]
        );
        ledgerTabFaceSheet.unassignedPaymentAllocation(
          td_charge_entry_tcid_264339.UnassignedAllocated[1],
          index[0]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.verifyGenerateBillAsChecked(
          td_charge_entry_tcid_264339.CptCodeInfo[1].CPTCodeAndDescription
        );
        // #endregion
      });
    });
  }
}
