import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { transactionalAPIs } from '../../../../../support/common-core-libs/application/transactional-apis';
import {
  CommonUtils,
  DateFormats,
} from '../../../../../support/common-core-libs/framework/common-utils';

import { td_ins_verification_tcid_6646 } from '../../../../../fixtures/sis-office/facesheet/insurance-verification-tcid-6646.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import PatientDetailsFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import SISCompleteLogin from '../../../../../app-modules-libs/sis-office/login/login';

/* instance variables */
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase();
const sisOfficeDesktop = new SISOfficeDesktop();
const patientDetailsFaceSheet = new PatientDetailsFaceSheet();
const loginPage = new SISCompleteLogin();

/* const values */
const expectedCount = [3, 2];
const deleteIndex = 2;
const number1000 = 1000; // To do we will be revisited this month to remove the done date filter
const insuranceFullName = CommonUtils.concatenate(
  td_ins_verification_tcid_6646.InsuranceInfo[0].InsuranceCarrier,
  ', ',
  'Binsurance'
);

export class InsuranceVerificationTcId6646 {
  verifyInsuranceWithAllAccess() {
    describe('Verify Insurance Validation in Patient Edit, Check-In and in Facesheet for user with View, Modify, Create and Delete Permission for Patient Demographics', () => {
      it('Validate Insurance for user with all patient demographics access', () => {
        // #region Click on Edit Icon for the patient

        cy.cGroupAsStep('Navigate to given date where patient is available');
        transactionalAPIs
          .API_Login(
            UserList.GEM_USER_3[0],
            UserList.GEM_USER_3[1],
            OrganizationList.GEM_ORG_3
          )
          .then(() => {
            transactionalAPIs
              .API_GetPatientCaseDOS(
                td_ins_verification_tcid_6646.PatientCase.PatientDetails
                  .PatientFirstName,
                td_ins_verification_tcid_6646.PatientCase.PatientDetails
                  .LastName,
                CommonUtils.getBeforeDate_yyyymmdd(
                  number1000,
                  DateFormats.hyphen
                ),
                CommonUtils.getTodayDate_yyyymmdd(DateFormats.hyphen)
              )
              .then(($response) => {
                sisOfficeDesktop.selectDateFromScheduleGrid(
                  $response.toString()
                );
              });
          });

        cy.cGroupAsStep('Click on Edit Icon for the patient');
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
            .PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        // #endregion

        // #region Navigate to Patient Details and click on First Existing Insurance
        cy.cGroupAsStep(
          'Navigate to Patient Details and click on First Existing Insurance'
        );
        createCase.clickPatientDetails();
        createCase.clickExistingInsuranceName(insuranceFullName);
        // #endregion

        // #region Edit the Insurance Details and click Done button
        cy.cGroupAsStep('Edit the Insurance Details and click Done button');
        createCase.editInsuranceCoverage(
          td_ins_verification_tcid_6646.InsuranceInfo[0]
        );
        createCase.clickNextInPatientDetails();
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region Navigate to schedule grid
        cy.cGroupAsStep('Navigate to schedule grid');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region Search for the patient in master head and click on patient details tab in facesheet
        cy.cGroupAsStep(
          'Search for the patient in master head and click on patient details tab in facesheet'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
        );
        patientDetailsFaceSheet.clickOnPatientDetailsTab();
        // #endregion

        // #region Verify Sorting
        cy.cGroupAsStep('Verify Sorting');
        sisOfficeDesktop.verifyListIfSorted(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .INSURANCE_COVERAGE.INSURANCE_COVERAGE_ACTIVE_ROW[1]
        );
        // #endregion

        // #region Verify All the Insurance Fields for first Insurance in Facesheet Patient Details
        cy.cGroupAsStep(
          'Verify All the Insurance Fields for first Insurance in Facesheet Patient Details'
        );

        createCase.clickExistingInsuranceName(insuranceFullName);
        createCase.verifyInsuranceCoverage(
          td_ins_verification_tcid_6646.InsuranceInfo[0]
        );
        // #endregion

        // #region Verify First Name is not getting saved when user clicks on cross icon instead of done button
        cy.cGroupAsStep(
          'Verify First Name is not getting saved when user clicks on cross icon instead of done button'
        );
        createCase.enterInsuranceFirstName(
          td_ins_verification_tcid_6646.InsuranceInfo[1]
        );
        sisOfficeDesktop.clickCloseIcon();
        createCase.clickExistingInsuranceName(insuranceFullName);
        createCase.verifyInsuranceFirstName(
          td_ins_verification_tcid_6646.InsuranceInfo[0]
        );
        // #endregion

        // #region Verify the error message when First Name and Last Name is removed in Edit Insurance Popup
        cy.cGroupAsStep(
          'Verify the error message when First Name and Last Name is removed in Edit Insurance Popup'
        );
        // Removing first and last name
        createCase.clearInsuranceFirstLastName();

        // Verify warning text for first and last name
        createCase.verifyWarningMsgInsuranceFirstLastName();
        // #endregion

        // #region Verify user is able to edit first name, last name and gender in Edit Insurance Popup
        cy.cGroupAsStep(
          'Verify user is able to edit first name, last name and gender in Edit Insurance Popup'
        );
        createCase.enterInsuranceFirstName(
          td_ins_verification_tcid_6646.InsuranceInfo[1]
        );
        createCase.enterInsuranceLastName(
          td_ins_verification_tcid_6646.InsuranceInfo[1]
        );
        createCase.verifyWarningMsgInsuranceFirstLastName(false);

        createCase.selectInsuranceGender(
          td_ins_verification_tcid_6646.InsuranceInfo[1]
        );
        sisOfficeDesktop.clickDoneButton();
        patientDetailsFaceSheet.assertionsForPatientDetailsLoad();

        createCase.clickExistingInsuranceName(insuranceFullName);
        createCase.verifyInsuranceFirstName(
          td_ins_verification_tcid_6646.InsuranceInfo[1]
        );
        createCase.verifyInsuranceLastName(
          td_ins_verification_tcid_6646.InsuranceInfo[1]
        );
        createCase.verifySelectedInsuranceGender(
          td_ins_verification_tcid_6646.InsuranceInfo[1]
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region Navigate to Schedule Grid
        cy.cGroupAsStep('Navigate to Schedule Grid');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion

        // #region Add 3rd Insurance in Patient Check-In
        cy.cGroupAsStep('Add 3rd Insurance in Patient Check-In');
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
            .PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.addInsuranceCoverage(
          td_ins_verification_tcid_6646.InsuranceInfo[2]
        );
        createCase.enterPatientDetailsAddressFields(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
        );
        createCase.clickCheckInDone();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
        );
        patientDetailsFaceSheet.clickOnPatientDetailsTab();
        createCase.verifyCountOfInsurances(expectedCount[0]);
        // #endregion

        // #region Verify Sorting after adding third insurance
        cy.cGroupAsStep('Verify Sorting after adding third insurance');
        sisOfficeDesktop.verifyListIfSorted(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .INSURANCE_COVERAGE.INSURANCE_COVERAGE_ACTIVE_ROW[1]
        );
        // #endregion

        // #region Verify Trash Icon On Hover on insurance
        cy.cGroupAsStep('Verify Trash Icon On Hover on insurance');
        createCase.verifyInsuranceTrashIcon(
          td_ins_verification_tcid_6646.InsuranceInfo[2].InsuranceCarrier
        );
        // #endregion

        // #region Delete First insurance and verify the length post deletion
        cy.cGroupAsStep(
          'Delete First insurance and verify the length post deletion'
        );
        createCase.deleteInsurance(deleteIndex);
        createCase.verifyCountOfInsurances(expectedCount[1]);
        // #endregion

        // #region Verify the length in Check-In after deletion
        cy.cGroupAsStep('Verify the length in Check-In after deletion');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
            .PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.verifyCountOfInsurances(expectedCount[1]);
        createCase.clickCheckInDone();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region Verify the length in Edit after deletion
        cy.cGroupAsStep('Verify the length in Edit after deletion');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
            .PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase.clickPatientDetails();
        createCase.verifyCountOfInsurances(expectedCount[1]);
        createCase.clickNextInPatientDetails();
        sisOfficeDesktop.clickDoneButton();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region Logout From application
        cy.cGroupAsStep('Logout From application');
        cy.cLogOut();
        // #endregion
      });
    });
  }

  verifyInsuranceWithViewModifyAccess() {
    describe('Verify Insurance Validation in Facesheet for user with View and Modify Permission for Patient Demographics', () => {
      it('Validate Insurance for user with view and modify access for patient demographics access', () => {
        // #region Login with View and Modify Patient Demographics access

        cy.cGroupAsStep(
          'Login with View and Modify Patient Demographics access'
        );

        /**
         * @Issue: Due to logout and re login, API is not working and we have tried with the cy reload after logout and still not worked
         * @Resolution: we are moving to old login application
         */
        cy.reload();
        cy.visit('/');
        /Login To Application*/;
        loginPage.login(
          UserList.GEM_USERVM_PTDEMO[0],
          UserList.GEM_USERVM_PTDEMO[1]
        );
        // #endregion

        // #region Search for the same patient and navigate to Patient Details in Facesheet
        cy.cGroupAsStep(
          'Search for the same patient and navigate to Patient Details in Facesheet'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
        );
        patientDetailsFaceSheet.clickOnPatientDetailsTab();
        // #endregion

        // #region Verify Trash Icon On Hover on insurance
        cy.cGroupAsStep('Verify Trash Icon On Hover on insurance');
        createCase.verifyInsuranceTrashIcon(
          td_ins_verification_tcid_6646.InsuranceInfo[2].InsuranceCarrier
        );
        // #endregion

        // #region Logout From application
        cy.cGroupAsStep('Logout From application');
        cy.cLogOut();
        // #endregion
      });
    });
  }

  verifyInsuranceWithOnlyViewAccess() {
    describe('Verify Insurance Validation in Facesheet for user with View Permission for Patient Demographics', () => {
      it('Validate Insurance for user with view access for patient demographics access', () => {
        // #region Login with View Only Patient Demographics access

        cy.cGroupAsStep('Login with View Only Patient Demographics access');
        /**
         * @Issue: Due to logout and re login, API is not working and we have tried with the cy reload after logout and still not worked
         * @Resolution: we are moving to old login application
         */
        cy.reload();
        cy.visit('/');
        /Login To Application*/;
        loginPage.login(
          UserList.GEM_USERVONLY[0],
          UserList.GEM_USERVONLY[1],
          OrganizationList.GEM_ORG_3
        );
        // #endregion

        // #region Search for the same patient and navigate to Patient Details in Facesheet
        cy.cGroupAsStep(
          'Search for the same patient and navigate to Patient Details in Facesheet'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ins_verification_tcid_6646.PatientCase.PatientDetails
        );
        patientDetailsFaceSheet.clickOnPatientDetailsTab();
        // #endregion

        // #region Verify Trash Icon On Hover on insurance
        cy.cGroupAsStep('Verify Trash Icon On Hover on insurance');
        createCase.verifyInsuranceTrashIcon(
          td_ins_verification_tcid_6646.InsuranceInfo[2].InsuranceCarrier
        );
        // #endregion
      });
    });
  }
}
