import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { Application } from '../../../../../support/common-core-libs/application/common-core';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { td_billed_case_status_252090 } from '../../../../../fixtures/sis-office/facesheet/billed-case-status-tcid-252090.td';
import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_PATIENT_STATEMENT } from '../../../../../app-modules-libs/sis-office/trackers/or/patient-statement.or';

import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import InsuranceBilling from '../../../../../app-modules-libs/sis-office/trackers/insurance-billing';
import PatientStatement from '../../../../../app-modules-libs/sis-office/trackers/patient-statement';
import FacesheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const insuranceBilling = new InsuranceBilling();
const createCase = new CreateCase(td_billed_case_status_252090.PatientCase[0]);
const createSecondCase = new CreateCase(
  td_billed_case_status_252090.PatientCase[1]
);
const createThirdCase = new CreateCase(
  td_billed_case_status_252090.PatientCase[2]
);
const createFourthCase = new CreateCase(
  td_billed_case_status_252090.PatientCase[3]
);
const createFifthCase = new CreateCase(
  td_billed_case_status_252090.PatientCase[4]
);
const createSixthCase = new CreateCase(
  td_billed_case_status_252090.PatientCase[5]
);
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const transactions = new Transactions(
  td_billed_case_status_252090.PatientCase[0]
);
const faceSheetCases = new FaceSheetCases(
  td_billed_case_status_252090.PatientCase[0]
);
const facesheetChargeEntry = new FacesheetChargeEntry();
const patientStatement = new PatientStatement();
const chargeEntry = new ChargeEntry(createSixthCase.patientCaseModel!);

export class FaceSheetTcId252090 {
  faceSheetCaseStatus() {
    describe('To verify the case status in facesheet and bill statement count for zero charges in patient statement tracker', () => {
      it('Verify the case status as Billed in facesheet when balance due as zero for all charges', () => {
        // #region verify the case status in facesheet page once all the charges as balance due as zero

        cy.cGroupAsStep(
          'Verify the balance due as zero when charges are system billed and case status for case-1'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_billed_case_status_252090.PatientCase[0].CaseDetails
            ?.CptCodeInfo[0].CPTCodeAndDescription
        );

        // Interception of api calls are handled in the below function
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.selectDropdownValueInDebitPopup(
          OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.PERIOD[0],
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].Period
        );

        transactions.selectDropdownValueInDebitPopup(
          OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.BATCH[0],
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].Batch
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1]
        );

        transactions.clickDoneInPayment();

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        transactions.verifyBalanceDueBasedOnCpt(
          td_billed_case_status_252090.PatientCase[0].CaseDetails
            ?.CptCodeInfo[0].CPTCodeAndDescription!,
          td_billed_case_status_252090.CaseTransaction.ChargesData[0].BalanceDue
        );

        transactions.verifyBalanceDueBasedOnCpt(
          td_billed_case_status_252090.PatientCase[0].CaseDetails
            ?.CptCodeInfo[1].CPTCodeAndDescription!,
          td_billed_case_status_252090.CaseTransaction.ChargesData[1].BalanceDue
        );

        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();

        faceSheetCases.verifyCaseStatus(
          td_billed_case_status_252090.CaseHeaderDetails[1].CaseStatus
        );

        sisOfficeDesktop.selectSisLogo();

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  faceSheetBilledStatus() {
    describe('To verify billed statement count in patient statement tracker is not increasing for system billed charges', () => {
      it('Verify billed statement count in patient statement tracker when new charge is added', () => {
        // #region verify the billed statement count in tracker before and after adding the new charge to case

        cy.cGroupAsStep(
          'Verify billed statement count as zero in patient statement tracker for case-4 when charges are system billed.'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );

        patientStatement.verifyBilledStatementCount(
          td_billed_case_status_252090.PatientStatement[1].PatientName,
          td_billed_case_status_252090.PatientStatement[1].BilledStatements
        );

        /*To check the Billed Statement Count in Patient Statement Tracker*/
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createFourthCase.patientCaseModel!.PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_billed_case_status_252090.PatientCase[0].CaseDetails
            ?.CptCodeInfo[0].CPTCodeAndDescription
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[5]
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[6]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );
        transactions.clickDoneInPayment();

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectSisLogo();

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );

        patientStatement.verifyBilledStatementCount(
          td_billed_case_status_252090.PatientStatement[1].PatientName,
          td_billed_case_status_252090.PatientStatement[1].BilledStatements
        );

        cy.cGroupAsStep(
          'Bill selection from patient statement tracker for case-4'
        );

        patientStatement.selectCheckboxByPatient(
          td_billed_case_status_252090.PatientStatement[1].PatientName
        );

        patientStatement.selectButtonsInPatientStatement(
          OR_PATIENT_STATEMENT.BILL_SELECTED_PATIENTS[0]
        );

        patientStatement.verifyPatientPresence(
          OR_PATIENT_STATEMENT.BILL_SELECTED_PATIENTS[0],
          td_billed_case_status_252090.PatientStatement[1].PatientName
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createFourthCase.patientCaseModel!.PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);

        facesheetChargeEntry.addProcedure(
          td_billed_case_status_252090.CptCodeInfo
        );

        facesheetChargeEntry.clickUpdateButton();

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createFourthCase.patientCaseModel!.PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[2].CPTHCPCS
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[7]
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[8]
        );

        transactions.clickDoneInPayment();

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        transactions.verifyDebitPopup();

        cy.cGroupAsStep(
          'Unselect the billed check mark and verify count in patient statement tracker for case-4.'
        );

        transactions.clickBilledCheckMark(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS
        );

        sisOfficeDesktop.selectSisLogo();

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );

        patientStatement.verifyBilledStatementCount(
          td_billed_case_status_252090.PatientStatement[2].PatientName,
          td_billed_case_status_252090.PatientStatement[2].BilledStatements
        );
        // #endregion
      });
    });
  }

  claimAndBillHistoryStatus() {
    describe('To verify claim status and billing history in ledger and transaction pages for system billed charges', () => {
      it('Verify the claim status and billing history in transaction and ledger page when charges are system billed', () => {
        // #region To make all the charges as Zero and Verify the claim status and billing history for case3

        cy.cGroupAsStep(
          'Making charges as system billed in transaction page for case-3'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createThirdCase.patientCaseModel!.PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_billed_case_status_252090.PatientCase[0].CaseDetails
            ?.CptCodeInfo[0].CPTCodeAndDescription
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[9]
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[10]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.clickDoneInPayment();

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        cy.cGroupAsStep(
          'Verify the billed checkmark, information icon and last billed date in transaction page for case-3.'
        );

        transactions.verifyBilledCheckMark(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          OR_TRANSACTION.CHARGES.BILLED_CHECK_BOX_CHECKED[0]
        );
        transactions.verifyBilledCheckMark(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          OR_TRANSACTION.CHARGES.BILLED_CHECK_BOX_CHECKED[0]
        );

        transactions.verifyInformationIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS
        );
        transactions.verifyInformationIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS
        );

        transactions.verifyLastBilledDate(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          CommonUtils.getTodayDate()
        );
        transactions.verifyLastBilledDate(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          CommonUtils.getTodayDate()
        );

        cy.cGroupAsStep(
          'Verify the info icon for the charges in claim status and case status in facesheet for case-3.'
        );

        transactions.clickClaimStatus();

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );
        sisOfficeDesktop.clickCloseIcon();

        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.verifyCaseStatus(
          td_billed_case_status_252090.CaseHeaderDetails[0].CaseStatus
        );

        cy.cGroupAsStep(
          'Verify the claim status and billing history in ledger page once after perform the payment transaction'
        );
        //Step10 - To check open sent to waystar ring is hidden for charges.
        ledgerTabFaceSheet.clickOnLedgerTab();

        transactions.verifySentToWaystar(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          false
        );

        transactions.verifySentToWaystar(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          false
        );

        cy.cGroupAsStep(
          'Verify charge transaction in ledger billing history for case-3.'
        );

        ledgerTabFaceSheet.clickButtonsInLedger(
          OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[0]
        );

        ledgerTabFaceSheet.clickPlusIconBasedOnCPT(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS
        );

        ledgerTabFaceSheet.verifyBillHistoryTransactions(
          td_billed_case_status_252090.BillingHistTransInfo[0]
        );
        sisOfficeDesktop.clickCloseIcon();

        cy.cGroupAsStep('Verify info icon in ledger claim status for case-3.');

        transactions.clickClaimStatus();

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );
        sisOfficeDesktop.clickCloseIcon();

        cy.cGroupAsStep(
          'To make the charges as system billed from write-off in transaction page for case-5.'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createFifthCase.patientCaseModel!.PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_billed_case_status_252090.PatientCase[0].CaseDetails
            ?.CptCodeInfo[0].CPTCodeAndDescription
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );

        transactions.enterDateOfTransaction(
          td_billed_case_status_252090.CaseTransaction.WriteOffInfo
            .TransactionDate
        );

        transactions.writeoffPopupPostTransaction(
          td_billed_case_status_252090.CaseTransaction.WriteOffInfo
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        transactions.selectCPTCode(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );

        transactions.enterDateOfTransaction(
          td_billed_case_status_252090.CaseTransaction.WriteOffInfo
            .TransactionDate
        );

        transactions.writeoffPopupPostTransaction(
          td_billed_case_status_252090.CaseTransaction.WriteOffInfo
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        cy.cGroupAsStep(
          'Verify billed checkmark with information icon and last billed date in transaction page for case-5.'
        );

        transactions.verifyBilledCheckMark(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          OR_TRANSACTION.CHARGES.BILLED_CHECK_BOX_CHECKED[0]
        );
        transactions.verifyBilledCheckMark(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          OR_TRANSACTION.CHARGES.BILLED_CHECK_BOX_CHECKED[0]
        );

        transactions.verifyInformationIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS
        );
        transactions.verifyInformationIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS
        );

        transactions.verifyLastBilledDate(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          CommonUtils.getTodayDate()
        );
        transactions.verifyLastBilledDate(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          CommonUtils.getTodayDate()
        );

        transactions.verifySentToWaystar(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          false
        );

        transactions.verifySentToWaystar(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          false
        );

        cy.cGroupAsStep(
          'Verify the claim status in ledger page once after perform the writeoff transaction for case-5.'
        );

        transactions.clickClaimStatus();

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );
        sisOfficeDesktop.clickCloseIcon();

        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.verifyCaseStatus(
          td_billed_case_status_252090.CaseHeaderDetails[0].CaseStatus
        );

        ledgerTabFaceSheet.clickOnLedgerTab();

        cy.cGroupAsStep(
          'Verify waystar ring unpresence for charges in ledger tab for case-5'
        );

        transactions.verifySentToWaystar(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          false
        );

        transactions.verifySentToWaystar(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          false
        );

        cy.cGroupAsStep(
          'Verify charge transactions in billing history and claim status in ledger tab for case-5'
        );

        ledgerTabFaceSheet.clickButtonsInLedger(
          OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[0]
        );
        ledgerTabFaceSheet.clickPlusIconBasedOnCPT(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS
        );

        ledgerTabFaceSheet.verifyBillHistoryTransactions(
          td_billed_case_status_252090.BillingHistTransInfo[0]
        );
        sisOfficeDesktop.clickCloseIcon();

        transactions.clickClaimStatus();

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyClaimStatus(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.LastBilledTo
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );

        transactions.verifyLastBilledInfoIcon(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[1].CPTHCPCS,
          td_billed_case_status_252090.ClaimStatus.InfoIcon
        );
        sisOfficeDesktop.clickCloseIcon();

        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyZeroChargesAndCaseStatus() {
    describe('To verify charges with zero amount in insurance billing tracker and case status in facesheet after bill selected from patient statement tracker', () => {
      it('Verify the zero charges in insurance billing tracker and case status in facesheet when bill selected from patient statement tracker', () => {
        // #region Verify zero charges and case status in insurance billing tracker and facesheet.

        cy.cGroupAsStep(
          'Verify the QM charges zero amount and other charges amount in insurance billing tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INSURANCE_BILLING[0]
        );

        insuranceBilling.expandPlusIconBasedOnCarrier(
          td_billed_case_status_252090.InsuranceBilling[0].InsuranceCarrier
        );
        insuranceBilling.verifyAmountByPatientName(
          td_billed_case_status_252090.InsuranceBilling[0].PatientName,
          td_billed_case_status_252090.InsuranceBilling[0].Amount
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        chargeEntry.performChargeEntry(
          td_billed_case_status_252090.ChargeDetails
        );

        cy.cRemoveMaskWrapper(Application.office);

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INSURANCE_BILLING[0]
        );

        insuranceBilling.expandPlusIconBasedOnCarrier(
          td_billed_case_status_252090.InsuranceBilling[1].InsuranceCarrier
        );

        insuranceBilling.verifyAmountByPatientName(
          td_billed_case_status_252090.InsuranceBilling[2].PatientName,
          td_billed_case_status_252090.InsuranceBilling[2].Amount
        );

        insuranceBilling.verifyAmountByPatientName(
          td_billed_case_status_252090.InsuranceBilling[1].PatientName,
          td_billed_case_status_252090.InsuranceBilling[1].Amount
        );

        cy.cGroupAsStep(
          'Verify the case status as billed when user performs the bill selection'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createSecondCase.patientCaseModel!.PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        transactions.selectCPTCode(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0].CPTHCPCS
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[2]
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[3]
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[4]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.clickDoneInPayment();

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        cy.cRemoveMaskWrapper(Application.office);

        sisOfficeDesktop.selectSisLogo();

        cy.cGroupAsStep(
          'Verify case status as billed when patient is billed from patient statement tracker for case-2.'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );

        patientStatement.selectCheckboxByPatient(
          td_billed_case_status_252090.PatientStatement[0].PatientName
        );

        patientStatement.selectButtonsInPatientStatement(
          OR_PATIENT_STATEMENT.BILL_SELECTED_PATIENTS[0]
        );

        patientStatement.verifyPatientPresence(
          OR_PATIENT_STATEMENT.BILL_SELECTED_PATIENTS[0],
          td_billed_case_status_252090.PatientStatement[0].PatientName
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createSecondCase.patientCaseModel!.PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[2].CPTHCPCS
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.enterDateOfTransactionInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[0]
            .TransactionDate
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[2]
        );

        transactions.selectTransactionValuesInPayments(
          td_billed_case_status_252090.CaseTransaction.PaymentsInfo[4]
        );

        transactions.clickDoneInPayment();

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.verifyCaseStatus(
          td_billed_case_status_252090.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion
      });
    });
  }
}
