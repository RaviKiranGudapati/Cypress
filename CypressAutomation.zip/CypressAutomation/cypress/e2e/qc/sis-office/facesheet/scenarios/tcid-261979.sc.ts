import { td_payer_details_tcid_261979 } from '../../../../../fixtures/sis-office/facesheet/payer-details-tcid-261979.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import PayerDetailsFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-payerdetails';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const facesheetCases = new FaceSheetCases(
  td_payer_details_tcid_261979.PatientCase
);
const transaction = new Transactions(td_payer_details_tcid_261979.PatientCase);
const createCase = new CreateCase(td_payer_details_tcid_261979.PatientCase);
const faceSheetCases = new FaceSheetCases();
const payerDetailsFaceSheet = new PayerDetailsFaceSheet();

export class PayerDetailsTcid261979 {
  payerDetailsFacesheet() {
    describe('Verify the data and update button based on the actions performed in the Payer Details', () => {
      it('Verify the data and update button based on the actions performed on the primary insurance', () => {
        // #region Verify the data and update button based on the actions performed on the primary insurance

        cy.cGroupAsStep(
          'Search and select the patient from global search list'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_payer_details_tcid_261979.PatientCase.PatientDetails
        );

        cy.cGroupAsStep('Select the Payer Details option from facesheet');
        faceSheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );

        cy.cGroupAsStep(
          'verify the update button is enabled in Payer Details from facesheet'
        );
        transaction.verifyUpdateButton();

        cy.cGroupAsStep(
          'Click on cross for primary insurance in Payer Details from facesheet'
        );
        createCase.removeInsurance(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .PRIMARY_INSURANCE[0]
        );
        transaction.verifyUpdateButton();

        cy.cGroupAsStep(
          'Navigating to case details and back to Payer Details from facesheet'
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CASE_DETAILS[0]
        );
        createCase.verifyCaseDetailsLabels();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.PAYER_DETAILS[0]
        );
        transaction.verifyUpdateButton();

        cy.cGroupAsStep(
          'Verify and click on cross for primary insurance and click on update in Payer Details from facesheet'
        );
        facesheetCases.verifyPrimaryInsurance(
          td_payer_details_tcid_261979.PatientCase.InsuranceCoverage
            .InsuranceCarrier
        );
        createCase.removeInsurance(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .PRIMARY_INSURANCE[0]
        );
        payerDetailsFaceSheet.clickUpdateButtonInPayerDetails();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CASE_DETAILS[0]
        );
        createCase.verifyCaseDetailsLabels();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.PAYER_DETAILS[0]
        );

        cy.cGroupAsStep(
          'verify and select the primary insurance dropdown in Payer Details from facesheet'
        );
        facesheetCases.verifyPrimaryInsurance(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DROPDOWN_VALUES.SELECT_ITEM
        );
        createCase.enterPrimaryInsurance(
          td_payer_details_tcid_261979.PatientCase.InsuranceCoverage
            .InsuranceCarrier
        );
        // #endregion
      });

      it('Verify the primary guarantor NOT be editable when self is selected in Payer Details of facesheet.', () => {
        // #region Changing the primary guarantor to self and verifying the first name

        cy.cGroupAsStep(
          'Changing the primary guarantor to self and verifying the first name'
        );
        createCase.clickPrimaryGuarantorDropdown();
        createCase.selectPrimaryGuarantorDropdownSelfValue();
        createCase.verifyPrimaryGuarantorFields();
        payerDetailsFaceSheet.clickUpdateButtonInPayerDetails();
        // #endregion
      });

      it('Verify the secondary guarantor state field data is updated in Payer Details.', () => {
        // #region Verify the secondary guarantor for reset data and update button in Payer Details
        createCase.secondaryGuarantorState(
          td_payer_details_tcid_261979.PatientCase.GuarantorDetails
        );
        payerDetailsFaceSheet.clickUpdateButtonInPayerDetails();
        createCase.verifySecondaryGuarantorState(
          td_payer_details_tcid_261979.PatientCase.GuarantorDetails
        );
        // #endregion
      });
    });
  }
}
