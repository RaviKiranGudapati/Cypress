import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { td_facesheet_notes_tcid_105234 } from '../../../../../fixtures/sis-office/facesheet/my-tasks-notes-tcid-105234.td';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import { ExpandOrCollapse } from '../../../../../support/common-core-libs/application/common-core';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const faceSheetCases = new FaceSheetCases();

/* const values */
const notes = 'Test Notes';

export class NotesTcId105234 {
  createAndVerifyNotesInCaseDetails() {
    describe('Create and Verify the Notes Added in Case Details under My Tasks', () => {
      it('Creating Notes in Case Details', () => {
        cy.cGroupAsStep('Search and select the patient from global search');

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_facesheet_notes_tcid_105234.PatientCase.PatientDetails
        );

        cy.cGroupAsStep('Select Case Details in Facesheet page');
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);

        cy.cGroupAsStep('Add Notes In Case Details');
        faceSheetCases.clickNotesButton();
        faceSheetCases.addNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Case Details');
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);
      });
    });
  }

  verifyNotesInMyTasks() {
    describe('Verify the Notes Added in Case Details in all other My Tasks Pages for CDM Organization', () => {
      it('Verify Notes in all pages of My Tasks', () => {
        cy.cGroupAsStep('Verify Added Notes In Payer Details');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.PAYER_DETAILS[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Financial Clearance');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.FINANCIAL_CLEARANCE[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Attachments');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.ATTACHMENTS[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Forms & Consents');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.FORMS_CONSENTS[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Clinical');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CLINICAL[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Inventory');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.INVENTORY[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Coding');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Charge Entry');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);

        cy.cGroupAsStep('Verify Added Notes In Transactions');
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(notes);
      });
    });
  }
}
