import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  Application,
  ExpandOrCollapse,
} from '../../../../../support/common-core-libs/application/common-core';

import { td_charge_entry_supply_tcid_214240 } from '../../../../../fixtures/sis-office/facesheet/charge-entry-supply-tcid-214240.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetChargeEntryPage from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';

/* instance variables */
const createCase = new CreateCase(
  td_charge_entry_supply_tcid_214240.PatientCase[0]
);
const createCase1 = new CreateCase(
  td_charge_entry_supply_tcid_214240.PatientCase[1]
);
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const nursingConfiguration = new NursingConfiguration();
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const faceSheetChargeEntry = new FaceSheetChargeEntryPage();

/* const values */
const rCode = '0001';

export class ChargeEntryTcId214240 {
  chargeEntrySupply() {
    describe('Verify the When Supply charges are posted in charge Entry and Calculations for each pricing type ', () => {
      it('Verify the When Supply charges are posted in charge Entry and Calculations for each pricing type', () => {
        // #region Navigating application setting and opening the contracts from front end

        cy.cGroupAsStep(
          'Navigating application setting and opening the contracts from front end'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_supply_tcid_214240.ContractInfo[0]
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_supply_tcid_214240.ContractInfo[1]
        );
        // #endregion

        // #region Validating Write-off Balance and Debit for Patient case row in Charge Entry

        cy.cGroupAsStep(
          'Navigating to Charge Entry and select the patient in the tracker'
        );
        sisOfficeDesktop.selectSisLogo();
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        // #endregion

        // #region Validating contract calculation for supply of revenue code type in Charge Entry

        cy.cGroupAsStep(
          'Validating contract calculation for supply of revenue code type in Charge Entry'
        );
        chargeEntry.verifyPatientRow(
          td_charge_entry_supply_tcid_214240.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        chargeEntry.selectCase(
          td_charge_entry_supply_tcid_214240.ChargeDetails
        );
        chargeEntry.addSupply(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[0]
        );
        chargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[0]
        );
        chargeEntry.clickAmountLabel();
        chargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[0].Amount
        );
        chargeEntry.clickAmountLabel();
        chargeEntry.selectRevenueCode(rCode);
        chargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[0].Balance
        );
        chargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[0].Debit
        );
        chargeEntry.clickBalanceLabel();
        chargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        // #endregion

        // #region Validating contract calculation for supply amount in Charge Entry

        cy.cGroupAsStep(
          'Validating contract calculation for supply amount in Charge Entry'
        );
        chargeEntry.addSupply(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[1]
        );
        chargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[1]
        );
        chargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[1].Amount
        );
        chargeEntry.clickAmountLabel();
        chargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[1].Balance
        );
        chargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[1].Debit
        );
        chargeEntry.clickBalanceLabel();
        chargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        // #endregion

        // #region Validating contract calculation for supply category type in Charge Entry

        cy.cGroupAsStep(
          'Validating contract calculation for supply of category type in Charge Entry'
        );
        chargeEntry.addSupply(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[2]
        );
        chargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[2]
        );
        chargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].Amount
        );
        chargeEntry.clickAmountLabel();
        chargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].Balance
        );
        chargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].Debit
        );
        chargeEntry.validateWriteOff(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].WriteOff
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 3);
        // #endregion

        // #region Validating contract calculation for supply item type in Charge Entry

        cy.cGroupAsStep(
          'Validating contract calculation for supply of supply item type in Charge Entry'
        );
        chargeEntry.addSupply(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[3]
        );
        chargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[3]
        );
        chargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[3].Amount
        );
        chargeEntry.clickAmountLabel();
        chargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[3].Balance
        );
        chargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[3].Debit
        );
        chargeEntry.clickBalanceLabel();
        chargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 4);
        // #endregion
      });
    });
  }

  chargeEntrySupplyFacesheet() {
    describe('Verify the When Supply charges are posted in FaeSheet of charge Entry and Calculations for each pricing type', () => {
      it('Verify the When Supply charges are posted in FaeSheet of charge Entry and Calculations for each pricing type', () => {
        // #region Validating Write-off, Balance and Debit for Patient case row in Charge Entry of facesheet

        cy.cGroupAsStep(
          'Navigating to global search open facesheet of the patient and click on the charge entry tracker'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          createCase1.patientCaseModel!.PatientDetails
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          0,
          td_charge_entry_supply_tcid_214240.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region Validating contract calculation for supply of revenue code type in Charge Entry of Facesheet

        cy.cGroupAsStep(
          'Validating contract calculation for supply of revenue code type in Charge Entry of Facesheet'
        );
        faceSheetChargeEntry.addSupplies(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[0]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[0]
        );

        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[0].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.selectRevenueCode(rCode);
        faceSheetChargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[0].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[0].Debit
        );
        faceSheetChargeEntry.clickBalanceLabel();
        faceSheetChargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        // #endregion

        // #region Validating contract calculation for supply amount in Charge Entry of Facesheet

        cy.cGroupAsStep(
          'Validating contract calculation for supply amount in Charge Entry of Facesheet'
        );
        faceSheetChargeEntry.addSupplies(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[1]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[1]
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[1].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[1].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[1].Debit
        );
        faceSheetChargeEntry.clickBalanceLabel();
        faceSheetChargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        // #endregion

        // #region Validating contract calculation for supply of category type in Charge Entry of Facesheet

        cy.cGroupAsStep(
          'Validating contract calculation for supply of category type in Charge Entry of Facesheet'
        );
        faceSheetChargeEntry.addSupplies(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[2]
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[2]
        );
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].Debit
        );
        faceSheetChargeEntry.validateWriteOff(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[2].WriteOff
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 3);
        // #endregion

        // #region Validating contract calculation for supply of item type in Charge Entry of Facesheet

        cy.cGroupAsStep(
          'Validating contract calculation for supply of supply item type in Charge Entry of Facesheet'
        );
        faceSheetChargeEntry.addSupplies(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[3]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_charge_entry_supply_tcid_214240.CptCodeInfo[3]
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[3].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.verifyBalance(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[3].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_charge_entry_supply_tcid_214240.AmountsProcedures[3].Debit
        );
        faceSheetChargeEntry.clickBalanceLabel();
        faceSheetChargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 4);
        // #endregion
      });
    });
  }
}
