import {
  ExpandOrCollapse,
  HierarchyOptions,
} from '../../../../../support/common-core-libs/application/common-core';
import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_ledger_billing_200160 } from '../../../../../fixtures/sis-office/facesheet/ledger-biling-tcid-200160.td';

import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import { Header, LedgerBilling, TransactionHeader } from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger-billing';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const ledgerBilling = new LedgerBilling();
const createCase = new CreateCase();
const transactions = new Transactions();
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const faceSheetCases = new FaceSheetCases();

/* const values */
const billingHistoryCharge = [
  'DOS',
  'CPT® /HCPCS',
  'Charge Amount',
  'Responsible Party',
  'Balance',
  'Output',
  'Paper Form',
  'Last Billed To',
  'Last Billed Date',
];
const billingHistoryTransaction = [
  'Billed Date',
  'Sent To',
  'Billed Amount',
  'Output',
  ' SMS',
];
const cpt = 120;
const index = [0, 1, 2, 3];

enum BillingMessages {
  billing_message = '1 Charge(s) sent to payer.',
  bill_selected_charge = 'Bill Selected Charges',
  print_selected_charge = 'Print Selected Charges',
}

export class LedgerBillingHistoryTcId266916 {
  verifyBillingHistoryInLedger() {
    describe('Verify Billing Form In Ledger from FaceSheet Tab', () => {
      it('Verify Billing Form In Ledger from FaceSheet Tab for patient 1 with insurance has electronic claim configured,', () => {
        // #region - Verify Billing History Header,Number of charges,Bill selected charges Button and Print Selected charges in Billing History

        cy.cGroupAsStep(
          'Verify Billing History Header,Number of charges,Bill selected charges Button and Print Selected charges in Billing History'
        );
        // for patient 1

        sisOfficeDesktop.pickPatient(
          td_ledger_billing_200160.PatientDetails[0]
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerBilling.verifyBillingHistoryHeader(billingHistoryCharge, Header);
        ledgerBilling.verifyBillSelectedCharges(
          BillingMessages.bill_selected_charge
        );
        ledgerBilling.verifyPrintSelectedCharges(
          BillingMessages.print_selected_charge
        );
        ledgerBilling.verifyNumberOfCharges(index[3]);
        // #endregion

        // #region - Verify Billing History Transaction,Billing Pop Up message and Number of charges Lines in Billing History

        cy.cGroupAsStep(
          'Verify Billing History Transaction HeaderBilling Pop Up message and Number of charges Lines in Billing History'
        );
        ledgerBilling.clickOnPlusIconBasedOnIndex(index[0]);
        ledgerBilling.verifyBillingHistoryHeader(
          billingHistoryTransaction, TransactionHeader
        );
        ledgerBilling.clickOnPlusIconBasedOnIndex(index[0]);
        ledgerBilling.verifyBillingTransactionRow();
        sisOfficeDesktop.clickCloseIcon();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(index[2]);
        ledgerBilling.clickOnBillSelectedCharges();
        ledgerBilling.verifyBillingPopUpMsg(BillingMessages.billing_message);
        ledgerBilling.clickOk();
        ledgerBilling.verifyBillingHistory();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerBilling.clickOnPlusIconBasedOnIndex(index[0]);
        ledgerBilling.verifyBilledRowsCount(index[2]);
        ledgerTabFaceSheet.closeBillingHistory();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });

      it('Verify Billing Form In Ledger from FaceSheet Tab for patient 2 with insurance has Paper claim configured,', () => {
        // #region - Verify Print Pop Up message in Billing History

        cy.cGroupAsStep('Verify Print Pop Up message in Billing History');
        // for patient 2

        sisOfficeDesktop.pickPatient(
          td_ledger_billing_200160.PatientDetails[1]
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(index[1]);
        ledgerBilling.clickOnPrintSelectedCharges();
        ledgerTabFaceSheet.verifyPrintPopup();
        ledgerBilling.closePrintPopup();
        ledgerTabFaceSheet.closePrintPopup();
        ledgerTabFaceSheet.closeBillingHistory();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });

      it('Verify Bill Patient Statement Dialog in Billing History In Ledger from FaceSheet Tab for patient 3 without the insurance,', () => {
        // #region - Verify Bill Patient Statement Dialog Billing History

        cy.cGroupAsStep(
          'Verify Bill Patient Statement Dialog in Billing History'
        );
        // patient 3

        sisOfficeDesktop.pickPatient(
          td_ledger_billing_200160.PatientDetails[2]
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(index[1]);
        ledgerBilling.clickOnBillSelectedCharges();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement(true);
        ledgerBilling.clickOk();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });

      it('Verify Print Pop Up message in Billing History In Ledger from FaceSheet Tab for patient 3 without the insurance,', () => {
        // #region - Verify Print Pop Up message in Billing History

        cy.cGroupAsStep('Verify Print Pop Up message in Billing History');
        // for patient3

        sisOfficeDesktop.pickPatient(
          td_ledger_billing_200160.PatientDetails[2]
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(index[1]);
        ledgerBilling.clickOnPrintSelectedCharges();
        ledgerTabFaceSheet.verifyPrintPopup();
        ledgerTabFaceSheet.closePrintPopup();
        ledgerTabFaceSheet.closeBillingHistory();
        ledgerBilling.verifyBillingHistory();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });

      it('Verify Billing Pop Up message,add Write off in Billing History In Ledger from FaceSheet Tab for patient 4 with two insurance,', () => {
        // #region - Verify Billing Pop Up message,add Write off and verify in Billing History

        cy.cGroupAsStep(
          'Verify Billing Pop Up message,add Write off and verify in Billing History'
        );
        // for patient5

        sisOfficeDesktop.pickPatient(
          td_ledger_billing_200160.PatientDetails[3]
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(index[1]);
        ledgerBilling.clickOnBillSelectedCharges();
        ledgerBilling.verifyBillingPopUpMsg(BillingMessages.billing_message);
        ledgerBilling.clickOk();
        sisOfficeDesktop.pickPatient(
          td_ledger_billing_200160.PatientDetails[3]
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(cpt);

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );
        chargeEntry.addingWriteoff(td_ledger_billing_200160.WriteOffInfo);

        sisOfficeDesktop.selectPersonIconInMyTasks();

        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerBilling.verifyBalanceAmount(
          td_ledger_billing_200160.WriteOffInfo.Balance
        );
        sisOfficeDesktop.clickCloseIcon();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });

      it('Verify in Billing History In Ledger for patient 5 with three procedures has different Insurances', () => {
        // #region - Remove Primary Insurance,Add Primary Insurance in Charge Entry and and Verify error messages in Billing History

        cy.cGroupAsStep(
          'Remove Primary Insurance,Add Primary Insurance in Charge Entry and and Verify error messages in Billing History'
        );
        // for patient6

        sisOfficeDesktop.pickPatient(
          td_ledger_billing_200160.PatientDetails[4]
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        sisOfficeDesktop.selectPersonIconInMyTasks();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 0);
        chargeEntry.removeInsurance(HierarchyOptions.primary);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 0);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.removeInsurance(HierarchyOptions.primary);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.selectPrimaryInsurance(
          td_ledger_billing_200160.WriteOffInfo.PrimaryInsurance
        );
        transactions.clickUpdateButton();
        sisOfficeDesktop.selectPersonIconInMyTasks();
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(index[0]);
        ledgerTabFaceSheet.selectChargesCheckBox(index[1]);
        ledgerBilling.clickOnBillSelectedCharges();
        ledgerBilling.verifyBillingErrorMSG(
          AppErrorMessages.required_guarantor_payer
        );
        ledgerBilling.clickOk();
        sisOfficeDesktop.clickCloseIcon();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(index[0]);
        ledgerTabFaceSheet.selectChargesCheckBox(index[1]);
        ledgerBilling.clickOnPrintSelectedCharges();
        ledgerBilling.verifyBillingErrorMSG(
          AppErrorMessages.required_guarantor_payer
        );
        ledgerBilling.clickOk();
        sisOfficeDesktop.clickCloseIcon();
        // #endregion
      });
    });
  }
}
