import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';
import { UPContextMenuOptions } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_ledger_allocation_tcid_278107 } from '../../../../../fixtures/sis-office/facesheet/unallocated-amount-sort-ledger-tcid-278107.td';

import { OR_REMITTANCE_POSTING } from '../../../../../app-modules-libs/sis-office/trackers/or/remittance-posting.or';

import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import RevenueCycleManagement from '../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import { RemittancePosting } from '../../../../../app-modules-libs/sis-office/trackers/remittance-posting';
import { ShowHidePayments } from '../../../../../app-modules-libs/sis-office/trackers/enums/revenue-cycle-management.enum';
/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_ledger_allocation_tcid_278107.PatientCase);
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const rcm = new RevenueCycleManagement();
const remittancePosting = new RemittancePosting();

/* const values */
const todayDate = CommonUtils.getTodayDate();
const pastDate = CommonUtils.getBeforeDate_mmddyyyy(5);
const fifteen = '15';

export class LedgerAutoAllocationInTcId278107 {
  autoAllocationUPAmount() {
    describe('Verify unassigned payment amount is not automatically allocated to the charge with different DOS', () => {
      it('Verify charge amount is not auto updated when allocating unassigned amount from Ledger, RCM, Remittance posting', () => {
        // #region - Navigate to Ledger screen and allocate the amount to a charge and verify amount allocation

        cy.cGroupAsStep(
          'Navigate to Ledger screen and allocate the amount to a charge and verify amount allocation'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_ledger_allocation_tcid_278107.UnassignedPayment
        );
        ledgerTabFaceSheet.selectContextMenu();
        ledgerTabFaceSheet.clickOnAllocate();
        rcm.unassignedPaymentAllocation(
          td_ledger_allocation_tcid_278107.UnAssignedAllocation
        );
        this.allocateAndVerifyUPAmount();
        ledgerTabFaceSheet.clickOnAllocateUnassignedPaymentDone();

        // #endregion

        // #region - Navigate to RCM and allocate the amount to a charge and verify amount allocation

        cy.cGroupAsStep(
          'Navigate to RCM and allocate the amount to a charge and verify amount allocation'
        );

        sisOfficeDesktop.selectSisLogo();
        rcm.clickOnRCMTracker();
        rcm.selectChargeBasedOnDOS(
          td_ledger_allocation_tcid_278107.PatientCase.PatientDetails.LastName,
          todayDate
        );
        rcm.selectResponsiblePartyTab(
          td_ledger_allocation_tcid_278107.RcmDetails.Subscriber
        );
        rcm.clickHideShowPayments(ShowHidePayments.show_payments);
        rcm.clickUPContextMenu(
          td_ledger_allocation_tcid_278107.PatientCase.PatientDetails.LastName
        );
        rcm.clickAllocate();
        rcm.unassignedPaymentAllocation(
          td_ledger_allocation_tcid_278107.UnAssignedAllocation
        );
        this.allocateAndVerifyUPAmount();
        rcm.clickDoneAllocation();

        // #endregion

        // #region - Navigate to Remittance posting and allocate the amount to a charge and verify amount allocation

        cy.cGroupAsStep(
          'Navigate to Remittance posting and allocate the amount to a charge and verify amount allocation'
        );

        sisOfficeDesktop.selectSisLogo();
        remittancePosting.clickOnRemittancePostingTracker();
        remittancePosting.selectManualRemittancePostingButton();
        remittancePosting.clickOnCalender(OR_REMITTANCE_POSTING.START_DOS[1]);
        remittancePosting.clickOnPreviousMonth();
        remittancePosting.selectDateInCalendar(fifteen);
        remittancePosting.selectCurrentDateInEndDateCalendar();
        remittancePosting.selectValueFromReceivedFromDropdown(
          td_ledger_allocation_tcid_278107.PatientCase.PatientDetails
            .InsuranceCoverage
        );
        remittancePosting.selectPeriodAndBatch(
          td_ledger_allocation_tcid_278107.Charges
        );
        remittancePosting.clickOnEllipsisBasedOnCpt(todayDate);
        remittancePosting.clickOnUPContextMenu(
          td_ledger_allocation_tcid_278107.PatientCase.PatientDetails.LastName
        );
        remittancePosting.clickOnUPContextMenuOptions(
          UPContextMenuOptions.allocate
        );
        this.allocateAndVerifyUPAmount();

        // #endregion
      });
    });
  }

  allocateAndVerifyUPAmount() {
    sisOfficeDesktop.amountAllocation(
      td_ledger_allocation_tcid_278107.UnAssignedAllocation.AmountAllocation,
      pastDate
    );
    sisOfficeDesktop.amountAllocation(
      td_ledger_allocation_tcid_278107.UnassignedPay.Amount,
      todayDate,
      false
    );
    sisOfficeDesktop.amountAllocation(
      td_ledger_allocation_tcid_278107.UnassignedPay.Unallocated,
      pastDate,
      false
    );
  }
}
