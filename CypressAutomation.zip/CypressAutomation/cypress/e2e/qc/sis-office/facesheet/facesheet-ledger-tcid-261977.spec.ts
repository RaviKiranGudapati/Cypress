import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { FaceSheetLedgerTcId261977 } from './scenarios/tcid-261977.sc';

/* instance variables */
const faceSheetLedger = new FaceSheetLedgerTcId261977();

/*****************Test Script Validation Details ***********************
 *1)Login the Application
 *2)Select the Patient from schedule grid and click on checkIn
 *3)Document the Amount collect in Billing & Payments
 *4)Navigate to Ledger and correct the above added Unassigned Payment
 *5)Navigate back to Billing and Payment, verify the period, batch and amount collected is Disabled
 *6)select patient from schedule grid, navigate to ledger add Unassigned Payment selecting period1 and batch1
 *7)Duplicate tab, navigate to balance reconciliation close period1 and batch1
 *8)Verify the period is closed and batch is closed warning in in Unassigned Payment Allocation
 *9)Add unassigned payment selecting period2 and batch1 and Duplicate tab, navigate to balance reconciliation , close period1 and batch1
 *10)Navigate back to ledger, click on the context menu (allocation) of the above added unassigned payment, verify the period and batch closed warning message
 *11)Navigate to transaction in cases tab, click on the unassigned payment context menu(view/edit), select period3 and batch1
 *12)Duplicate the tab, close the period3 and batch1, navigate back to pervious tab, click on done button, verify period and batch warning message
 *13)Close the Allocation edit popup Navigate to cases to tab Check print icon in Face Sheet > Gray Task Bar > Top Right
 *14)Verify that the Print icon should be displayed on Gray Task Bar on Top right,
 *15)Click on Print icon and check below options on Model window, Verify that the Print model window
 *16)Click on the Case Print Icon(Face sheet print beside the case). select on patient Estimate and click on preview button
 *17)Verify the print preview model opens
 *18)Logout the Application , Login the Application with user2 which does not have Financial modify permissions
 *19)Search for Patient1 in the Business Facesheet. Click on Transaction .Click on + Sign to Expand.Click on the context menu for the allocation
 *20)Verify that the user should not be able to edit the Allocation Correction amount as the user does not have the financial  Modify permissions.
 */

describe(
  'Verify the Warning Message in Ledger for Unassigned payment when Period/Batch is closed',
  { tags: ['facesheet-ledger', 'TC#261977', 'US#262533'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        faceSheetLedger.verifyPeriodAndBatchAreLocked();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
