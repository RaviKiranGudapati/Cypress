import {
  ExpandOrCollapse,
  HierarchyOptions,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_combined_coding_details_tcid_276354 } from '../../../../../fixtures/sis-office/ditl/combined-coding-details-tcid-276354.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import { ChargeAdjustment } from '../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import CombinedCoding from '../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import FaceSheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();
const facesheetCases = new FaceSheetCases();
const facesheetChargeEntry = new FaceSheetChargeEntry();

export class CombinedCodingTcId276354 {
  verifyAdditionDeletionOfFieldData() {
    it('Verification of Sort functionality in Combined Coding', () => {
      // #region - Verification of Sorting of headers in Combined Coding tracker page

      cy.cGroupAsStep(
        'Verification of Sorting of headers in Combined Coding tracker page'
      );
      sisOfficeDesktop.selectSisLogo();
      sisOfficeDesktop.selectTracker(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
      );
      combinedCoding.getTotalCasesCount();
      combinedCoding.clickOnHeadersToSort();
      combinedCoding.getTotalCasesCount();
      // #endregion
    });

    it('Adding and Removing of charge details and Verify the Balances after adding Discounts.', () => {
      addRemoveChargeDetails();
      addDiscountsAndVerifyBalances();
    });

    it('Verification of the Balances after adding Writeoffs and debits in the Adjustment details tab', () => {
      clickAdjustmentAndAddWriteOffAndVerifyBalances();
      addDebitsAndVerifyBalances();
    });

    it('Verification of Added cpt, diagnosis code from Facesheet Charge Entry', () => {
      verifyAddedChargeDetails();
    });

    it('Documenting Additional claim information from Facesheet Charge Entry.', () => {
      addUbAdditionalClaimInfo();
      addHcfaAdditionalClaimInfo();
    });

    it('Verification of documented Additional claim information from Combined coding tracker', () => {
      verifyUbAdditionalClaimInfo();
      verifyHcfaAdditionalClaimInfo();

      // #region - Perform Autosort and Verify the order of Procedures

      cy.cGroupAsStep('Perform Autosort and Verify the order of Procedures');
      combinedCoding.verifyOrderOfProcedure(
        td_combined_coding_details_tcid_276354.CptCode[0]
          .cptCPTCodeAndDescriptionCode
      );
      combinedCoding.clickOnAutoSort();
      combinedCoding.verifyOrderOfProcedure(
        td_combined_coding_details_tcid_276354.CptCode[1]
          .cptCPTCodeAndDescriptionCode
      );
      combinedCoding.clickReadyForBillAndDoneButton(true);
      combinedCoding.verifyPatientFallOffInCombinedCoding(
        td_combined_coding_details_tcid_276354.PatientCase.PatientDetails
          .PatientFullName
      );
      // #endregion
    });
  }
}

function addRemoveChargeDetails() {
  // #region - Adding and Removing of Charge Details

  cy.cGroupAsStep('Adding and Removing of Charge Details ');
  combinedCoding.selectCaseAndVerifyAndSelectProcedure(
    td_combined_coding_details_tcid_276354.ChargesInfo,
    td_combined_coding_details_tcid_276354.PatientCase,
    td_combined_coding_details_tcid_276354.PatientCase.CaseDetails
      .CptCodeInfo[0]
  );
  combinedCoding.clickAddProcedureButton();
  combinedCoding.searchAndSelectCptInProcedure(
    td_combined_coding_details_tcid_276354.PatientCase.CaseDetails
      .CptCodeInfo[1].CPTCodeAndDescription
  );
  combinedCoding.selectDiagnosisCode(
    td_combined_coding_details_tcid_276354.Charge[0]
  );
  combinedCoding.verifyBillingProcedureDescriptionField();
  combinedCoding.removePhysician();
  combinedCoding.removeReferringPhysician();
  combinedCoding.removePrimaryGuarantor();
  combinedCoding.selectPhysicianAndReferringPhysician(
    td_combined_coding_details_tcid_276354.PatientCase.CaseDetails
      .CptCodeInfo[0]
  );
  combinedCoding.selectMultipleModifiers(
    td_combined_coding_details_tcid_276354.Charge[0],
    4
  );
  combinedCoding.selectPeriodAndBatch(
    td_combined_coding_details_tcid_276354.ChargesInfo
  );
  combinedCoding.selectPrimaryAndSecondaryGuarantor(
    td_combined_coding_details_tcid_276354.PatientCase.BillingDetails
  );
  combinedCoding.clickGenerateBillCheckBoxInDetailsTable();
  // #endregion
}

function addDiscountsAndVerifyBalances() {
  // #region - Verification of Balance after adding Discounts

  cy.cGroupAsStep('Verification of Balance after adding Discounts ');
  combinedCoding.addDiscountsAndVerifyBalances(
    td_combined_coding_details_tcid_276354.Charge1
  );
  combinedCoding.verifyInsuranceValue(
    HierarchyOptions.primary,
    td_combined_coding_details_tcid_276354.Charge[0].PrimaryInsurance
  );
  combinedCoding.clickSelfPay(YesOrNo.yes);
  combinedCoding.verifyInsuranceValue(
    HierarchyOptions.primary,
    td_combined_coding_details_tcid_276354.Charge1[0].PrimaryInsurance!
  );
  combinedCoding.clickInsuranceDropDown(
    OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0]
  );
  combinedCoding.clickPrimaryInsuranceCarrierOption(
    td_combined_coding_details_tcid_276354.Charge[0].PrimaryInsurance
  );
  // #endregion
}

function clickAdjustmentAndAddWriteOffAndVerifyBalances() {
  // #region - Click on adjustment and Verification of Balances after adding Writeoffs

  cy.cGroupAsStep(
    'Click on adjustment and Verify Balances after adding Writeoffs  '
  );
  combinedCoding.addWriteOffAndVerifyBalances(
    td_combined_coding_details_tcid_276354.Adjustment,
    td_combined_coding_details_tcid_276354.Charge1[2],
    0
  );
  // #endregion
}

function addDebitsAndVerifyBalances() {
  // #region - Verification of Balances after adding Debits

  cy.cGroupAsStep('Verification of Balances after adding Debits ');
  combinedCoding.addDebitsAndVerifyBalances(
    td_combined_coding_details_tcid_276354.Adjustment,
    td_combined_coding_details_tcid_276354.Charge1[1],
    0
  );
  combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
  combinedCoding.clickOnDoneButton();
  // #endregion
}

function verifyAddedChargeDetails() {
  // #region - Verification of added procedure, diagnosis code from Facesheet Charge Entry

  cy.cGroupAsStep(
    'Verification of added procedure, diagnosis code from Facesheet Charge Entry '
  );
  sisOfficeDesktop.selectSisLogo();
  sisOfficeDesktop.sisOfficeGlobalSearchPatient(
    td_combined_coding_details_tcid_276354.PatientCase.PatientDetails
  );
  facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
  facesheetChargeEntry.verifyCPTProcedure(
    td_combined_coding_details_tcid_276354.PatientCase.CaseDetails
      .CptCodeInfo[1].CPTCodeAndDescription
  );
  sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
  facesheetChargeEntry.verifyDiagnosisCode(
    td_combined_coding_details_tcid_276354.Charge[0].DiagnosisCode
  );
  // #endregion
}

function addUbAdditionalClaimInfo() {
  // #region - Adding the data to the fields under UB tab in additional claim information popup from Facesheet Charge Entry.

  cy.cGroupAsStep(
    'Adding the data to the fields under UB tab in additional claim information popup from Facesheet Charge Entry.'
  );
  combinedCoding.clickAndVerifyUbAdditionalClaim(
    td_combined_coding_details_tcid_276354.UBAdditionalClaim[0]
      .UBInstitutional!,
    td_combined_coding_details_tcid_276354.UBAdditionalClaim[1].UBInstitutional!
  );
  combinedCoding.enterDataInUbFields(
    td_combined_coding_details_tcid_276354.UBAdditionalClaim[0]
  );
  combinedCoding.selectAdditionalClaimInfoDoneAndVerifyPopup();
  // #endregion
}

function addHcfaAdditionalClaimInfo() {
  // #region - Adding the data to the fields under HCFA tab in additional claim information popup from Facesheet Charge Entry.

  cy.cGroupAsStep(
    'Adding the data to the fields under HCFA tab in additional claim information popup from Facesheet Charge Entry.'
  );
  combinedCoding.clickAndVerifyHcfaAdditionalClaim(
    td_combined_coding_details_tcid_276354.HCFAAdditionalClaim[0]
      .HCFAProfessional!
  );
  combinedCoding.addHcfaAdditionalData(
    td_combined_coding_details_tcid_276354.HCFAAdditionalClaim[0]
  );
  combinedCoding.selectAdditionalClaimInfoDoneAndVerifyPopup();
  sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
  // #endregion
}

function verifyUbAdditionalClaimInfo() {
  // #region - Verification of the data for saved UB additional claim information from Combined coding

  cy.cGroupAsStep(
    'Verification of the data for saved UB additional claim information from Combined coding'
  );
  sisOfficeDesktop.selectSisLogo();
  sisOfficeDesktop.selectTracker(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
  );
  combinedCoding.selectCaseAndVerifyAndSelectProcedure(
    td_combined_coding_details_tcid_276354.ChargesInfo,
    td_combined_coding_details_tcid_276354.PatientCase,
    td_combined_coding_details_tcid_276354.PatientCase.CaseDetails
      .CptCodeInfo[1]
  );
  combinedCoding.clickAndVerifyUbAdditionalClaim(
    td_combined_coding_details_tcid_276354.UBAdditionalClaim[0]
      .UBInstitutional!,
    td_combined_coding_details_tcid_276354.UBAdditionalClaim[1].UBInstitutional!
  );
  combinedCoding.verifyUbAdditionalClaimData(
    td_combined_coding_details_tcid_276354.UBAdditionalClaim[0]
  );
  combinedCoding.selectAdditionalClaimInfoDoneAndVerifyPopup();
  // #endregion
}

function verifyHcfaAdditionalClaimInfo() {
  // #region - Verification of the data for saved HCFA additional claim information from Combined coding

  cy.cGroupAsStep(
    'Verification of the data for saved HCFA additional claim information from Combined coding'
  );
  combinedCoding.clickAndVerifyHcfaAdditionalClaim(
    td_combined_coding_details_tcid_276354.HCFAAdditionalClaim[0]
      .HCFAProfessional!
  );
  combinedCoding.verifyConditionCodesHCFA(
    td_combined_coding_details_tcid_276354.HCFAAdditionalClaim[0],
    0
  );
  combinedCoding.verifyHcfaAdditionalClaim(
    td_combined_coding_details_tcid_276354.HCFAAdditionalClaim[0]
  );
  combinedCoding.selectAdditionalClaimInfoDoneAndVerifyPopup();
  // #endregion
}
