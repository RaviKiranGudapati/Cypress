import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';

import { rcm_tcid_278282 } from '../../../../../fixtures/sis-office/ditl/rcm-tcid-278282.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_REVENUE_CYCLE_MANAGEMENT } from '../../../../../app-modules-libs/sis-office/trackers/or/revenue-cycle-management.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import { DictionaryItems } from '../../../../../app-modules-libs/shared/application-settings/enums/nursing-configuration.enum';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import RevenueCycleManagement from '../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';

import { RevenueCycleManagementApis } from '../../../../../app-modules-libs/sis-office/trackers/api/revenue-cycle-management.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const revenueCycleManagement = new RevenueCycleManagement();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const revenueCycleManagementApis = new RevenueCycleManagementApis();
const faceSheetCases = new FaceSheetCases();
const transactions = new Transactions();

/* const values */
const twentyNine = 29;
const oneFortySeven = 147;

export class RevenueCycleManagementTcId278282 {
  precondition() {
    it('Create rcm status in Dictionary from application settings', () => {
      // #region - Adding write off to the patient from facesheet transactions

      cy.cGroupAsStep(
        'Adding write off to the patient from facesheet transactions'
      );
      addWriteOff();
      // #endregion

      // #region - Add Rcm status from application settings

      cy.cGroupAsStep('Add Rcm status from application settings');
      addRcmStatus();
      // #endregion
    });
  }

  verifyChargeInRCMTracker() {
    it('Verify the charge in RCM tracker by modifying rcm status under RCM summary', () => {
      // #region - Navigate to RCM tracker, select responsible party verify the charge details in the rcm tracker

      cy.cGroupAsStep(
        'Navigate to RCM tracker, select responsible party verify the charge details in the rcm tracker'
      );
      verifyChargeDetailsInRcmTracker();
      // #endregion

      // #region - 'Verify RCM Status in RCM tracker after selecting it from RCM Summary

      cy.cGroupAsStep(
        'Verify RCM Status in RCM tracker after selecting it from RCM Summary'
      );
      verifyRcmStatusOfPatientInRcmTracker();
      // #endregion

      // #region - 'Verify the downloaded files

      cy.cGroupAsStep('Verify the downloaded files');
      selectPatientCheckBoxClickTurnoverCollection();
      verifyDownloadedFileForWriteOffNo();
      // #endregion

      // #region - Verify download file for write off all selected charges

      cy.cGroupAsStep(
        'Verify download file for write off all selected charges'
      );
      sisOfficeDesktop.selectTracker(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
      );
      sisOfficeDesktop.selectTracker(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
      );
      selectPatientCheckBoxClickTurnoverCollection();
      verifyDownloadedFileForWriteOffYes();
      // #endregion
    });
  }
}

function addWriteOff() {
  // #region - Add write off to the patient from facesheet transactions

  cy.cGroupAsStep('Add write off to the patient from facesheet transactions');
  sisOfficeDesktop.sisOfficeGlobalSearchPatient(
    rcm_tcid_278282.PatientDetails[0]
  );
  faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
  transactions.selectCPTCode(
    rcm_tcid_278282.CaseDetails?.CptCodeInfo[0].CPTCodeAndDescription
  );
  transactions.selectTransactionForCharge(OR_TRANSACTION.CHARGES.WRITE_OFFS[0]);
  documentWriteOffPopUp();
  // #endregion
}

function addRcmStatus() {
  // #region - Rcm status from application settings

  cy.cGroupAsStep('Add Rcm status from application settings');
  sisOfficeDesktop.selectOptionInUserMenuDropdown(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
  );
  nursingConfigurationLayout.selectConfiguration(
    OR_NURSING_CONFIGURATION.DICTIONARY.DICTIONARY[0]
  );
  nursingConfiguration.selectDictionary(DictionaryItems.rcm_status);
  nursingConfiguration.addRcmStatus(rcm_tcid_278282.AddRcMStatus);
  sisOfficeDesktop.selectSisLogo();
  // #endregion
}

function verifyChargeDetailsInRcmTracker() {
  // #region - navigate to RCM tracker, select responsible party verify the charge details in the rcm tracker

  cy.cGroupAsStep(
    'Navigate to RCM tracker, select responsible party verify the charge details in the rcm tracker'
  );
  sisOfficeDesktop.selectTracker(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
  );
  revenueCycleManagement.selectResponsibleParty(
    rcm_tcid_278282.RevenueCycleManagement.ResponsibleParty
  );
  revenueCycleManagement.verifyThePatientDetailsInRcm(
    rcm_tcid_278282.PatientDetails[0]
  );
  // #endregion
}

function verifyRcmStatusOfPatientInRcmTracker() {
  // #region - verify RCM Status in RCM tracker after selecting it from RCM Summary

  cy.cGroupAsStep(
    'Verify RCM Status in RCM tracker after selecting it from RCM Summary'
  );
  revenueCycleManagement.selectPatientRowInRCM(
    rcm_tcid_278282.PatientDetails[0].PatientFirstName!
  );
  revenueCycleManagement.selectRcmStatusInSummary(
    rcm_tcid_278282.SelectRcmStatusInSummary
  );
  revenueCycleManagement.clickDoneButton();
  sisOfficeDesktop.selectSisLogo();

  revenueCycleManagement.verifyThePatientDetailsInRcm(
    rcm_tcid_278282.PatientDetails[0]
  );
  // #endregion
}

function verifyDownloadedFileForWriteOffNo() {
  // #region - verify the downloaded file

  cy.cGroupAsStep('Verify the downloaded file');
  revenueCycleManagement.selectNewRcmStatus(
    rcm_tcid_278282.SelectRcmStatusInSummary.RcmStatus
  );
  revenueCycleManagement.selectWriteOffAllSelectedCharges(YesOrNo.no);
  sisOfficeDesktop.verifyDownloadFile(
    revenueCycleManagementApis.interceptVerifyDownloadFileApi(),
    OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
      .GENERATE_FILE_AND_DONE[1],
    rcm_tcid_278282.TurnOverToCollections[0].FileName!,
    twentyNine,
    oneFortySeven
  );
  // #endregion
}

function verifyDownloadedFileForWriteOffYes() {
  // #region - verify download file for write off all selected charges

  cy.cGroupAsStep('Verify the downloaded file');
  revenueCycleManagement.selectFieldsTurnOverToCollection(
    rcm_tcid_278282.TurnOverToCollections[2]
  );
  sisOfficeDesktop.verifyDownloadFile(
    revenueCycleManagementApis.interceptVerifyDownloadFileApi(),
    OR_REVENUE_CYCLE_MANAGEMENT.TURNOVER_TO_COLLECTION_POPUP
      .GENERATE_FILE_AND_DONE[1],
    rcm_tcid_278282.TurnOverToCollections[1].FileName!,
    twentyNine,
    oneFortySeven
  );
  // #endregion
}

function selectPatientCheckBoxClickTurnoverCollection() {
  // #region -selecting the check box click on turnover to collection button

  cy.cGroupAsStep(
    'Selecting the check box click on turnover to collection button'
  );
  revenueCycleManagement.clickPatientCheckBox(
    rcm_tcid_278282.PatientDetails[0].PatientFirstName!
  );
  revenueCycleManagement.clickOnTurnOverToCollection();
  // #endregion
}

function documentWriteOffPopUp() {
  // #region - document the details in writeoff of pop up in facesheet transactions

  cy.cGroupAsStep(
    'Document the details in writeoff of pop up in facesheet transactions'
  );
  transactions.transactionWriteoffPopupSelectDropdownValue(
    OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.PERIOD[0],
    rcm_tcid_278282.WriteOffInfo.Period
  );
  transactions.transactionWriteoffPopupSelectDropdownValue(
    OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.BATCH[0],
    rcm_tcid_278282.WriteOffInfo.Batch
  );
  transactions.transactionDebitEnterDebitAmount(
    rcm_tcid_278282.WriteOffInfo.WriteoffAmount
  );
  transactions.transactionWriteoffPopupSelectDropdownValue(
    OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.WRITEOFF_TRANS_CODE[0],
    rcm_tcid_278282.WriteOffInfo.WriteoffTransactionCode
  );
  transactions.transferToNextParty(YesOrNo.no);
  // #endregion
}
