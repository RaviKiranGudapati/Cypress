import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

import { td_manual_remittance_posting_tcid_265863 } from '../../../../../fixtures/sis-office/ditl/remittance-posting-tcid-265863.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { RemittancePosting } from '../../../../../app-modules-libs/sis-office/trackers/remittance-posting';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const remittancePosting = new RemittancePosting();

/* const values */
const checkAmountInputValue = '9999999999';
const paymentAmount = '999,999.00';
const transferTo = ['PI', 'PG'];
const days = 366;

export class RemittancePostingTcId265863 {
  verifyUiFieldsInManualRemittanceposting() {
    it('Verify values in dropdown and text fields', () => {
      verifyRemittancePostingLayout();
    });
  }

  verifyFieldsInTransactionGrid() {
    it('Verification of sort functionality and data verifications for mapped cases', () => {
      verifyRemitancePostingTransactionGrid();
    });
  }
}

function verifyRemittancePostingLayout() {
  // #region - Navigate Remittance posting and click Manual remittance posting

  cy.cGroupAsStep(
    'Navigate Remittance posting and click Manual remittance posting'
  );
  sisOfficeDesktop.selectTracker(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REMITTANCE_POSTING[0]
  );
  remittancePosting.selectManualRemittancePostingButton();
  // #endregion

  // #region - verify case date of service, start date, end date calenders and eter Date of service

  cy.cGroupAsStep(
    'Verify case date of service, start date, end date calenders and eter Date of service'
  );
  remittancePosting.verifyStartDate();
  remittancePosting.verifyEndDate();
  remittancePosting.verifyStartDateFormat();
  remittancePosting.verifyEndDateFormat();
  remittancePosting.selectCurrentDateInEndDateCalendar();
  remittancePosting.verifyCaseDateOfServiceAsMandatory();
  // #endregion

  // #region - Verify dropdown values of Recevied from, method of payment, Check amount maximum value and PaymentId value

  cy.cGroupAsStep(
    'Verify dropdown values of Recevied from, method of payment, Check amount maximum value and PaymentId value'
  );
  remittancePosting.selectValueFromReceivedFromDropdown(
    td_manual_remittance_posting_tcid_265863.TransactionDetails.ReceivedFrom
  );
  remittancePosting.selectStartDate(CommonUtils.getBeforeDate_mmddyyyy(days));
  remittancePosting.verifyReceivedFromDropDownValues(
    td_manual_remittance_posting_tcid_265863.TransactionDetails.ReceivedFrom
  );
  remittancePosting.verifyMethodOfPaymentAsDefaultValue();
  remittancePosting.verifyMethodOfPaymentDropDownValues();
  remittancePosting.enterCheckAmount(checkAmountInputValue);
  remittancePosting.verifyMaxAndMinValue();
  remittancePosting.enterPaymentId(
    td_manual_remittance_posting_tcid_265863.TransactionDetails.PaymentID
  );
  remittancePosting.verifypaymentIdValue(
    td_manual_remittance_posting_tcid_265863.TransactionDetails.PaymentID
  );
  // #endregion

  // #region - Verify Defaults, period dropdown values, batch dropdown values and Transaction date

  cy.cGroupAsStep(
    'Verify Defaults, period dropdown values, batch dropdown values and Transaction date'
  );
  remittancePosting.verifyDefaults(
    td_manual_remittance_posting_tcid_265863.Defaults.HideDefaults
  );
  remittancePosting.verifyPeriodDropDownValues(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting.Period
  );
  remittancePosting.verifyBatchDropDownValues(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting.Batch
  );
  remittancePosting.verifyDateFormatOfTransactionDate();
  remittancePosting.verifyAllMandatoryFields();
  remittancePosting.verifyTransactionDateAsTodayDate(
    td_manual_remittance_posting_tcid_265863.TransactionDetails.TransactionDate
  );
  // #endregion

  // #region - Verify dropdown values of payment transaction, Transfert to, generate bill, Grouper code and Reason code values

  cy.cGroupAsStep(
    'Verify dropdown values of payment transaction, Transfert to, generate bill, Grouper code and Reason code values'
  );
  remittancePosting.enterPaymentTransactionCode(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting
      .PaymentTransactionCode
  );
  remittancePosting.verifyPaymentTransactionCode(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting
      .PaymentTransactionCode
  );
  remittancePosting.verifyTransferToDefaultAsYes();
  remittancePosting.verifyGenerateBillDefaultAsYes();
  remittancePosting.verifyGenerateBillHelperText();
  remittancePosting.verifyAllGroupCodeDropdownValues();
  remittancePosting.verifyAllReasonCodeDropdownValues();
  // #endregion

  // #region - Verify dropdown values of Debit transaction

  cy.cGroupAsStep('Verify dropdown values of Debit transaction');
  remittancePosting.enterDebitTransactionCode(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting
      .DebitTransactionCode
  );
  remittancePosting.verifyDebitTransactionCode(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting
      .DebitTransactionCode
  );
  // #endregion

  // #region - Enter Recevied from, period, batch, check amount, PaymentId, grouper code reason code, verify writeoff1 and writeoff2

  cy.cGroupAsStep(
    'Document Recevied from, period, batch, check amount, PaymentId, grouper code, reason code, verify writeoff1 and writeoff2'
  );

  remittancePosting.enterDataInManualRemittancePosting(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting
  );
  remittancePosting.verifyWriteoff2TransactionCode(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting
      .WriteOffCode2
  );
  remittancePosting.verifyWriteoff1TransactionCode(
    td_manual_remittance_posting_tcid_265863.ManualRemittancePosting
      .WriteOffCode1
  );
  // #endregion
}

function verifyRemitancePostingTransactionGrid() {
  //  #region - Verify Transaction grid headers, patient order, Mrn sort and Dos sort

  cy.cGroupAsStep(
    'Verify Transaction grid headers, patient order, Mrn sort and Dos sort'
  );
  remittancePosting.verifyHeadersInTranasactionGrid();
  remittancePosting.verifyMrnIsSortable();
  remittancePosting.verifyPatientNamesOrder(
    td_manual_remittance_posting_tcid_265863.PatientCase
  );
  remittancePosting.verifyMrnByHovering(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName
  );
  remittancePosting.verifyDosIsSortable();
  remittancePosting.verifyDosFormatInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    td_manual_remittance_posting_tcid_265863.TransactionDetails.TransactionDate
  );
  // #endregion

  //  #region - Verify  Cpt codes, payment balank value and check maximun value in payment

  cy.cGroupAsStep(
    'Verify  Cpt codes, payment balank value and check maximun value in payment'
  );
  remittancePosting.verifyPaymentValueInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    ''
  );
  remittancePosting.verifyCptInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    td_manual_remittance_posting_tcid_265863.ChargeTransaction[0].CptCode
  );
  remittancePosting.verifyCasesCptCodes(
    td_manual_remittance_posting_tcid_265863.PatientCase,
    td_manual_remittance_posting_tcid_265863.ChargeTransaction
  );
  remittancePosting.enterPaymentInRemittance(
    td_manual_remittance_posting_tcid_265863.ChargeTransaction[0].CptCode,
    checkAmountInputValue
  );
  remittancePosting.verifyPaymentValueInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    paymentAmount
  );
  // #endregion

  //  #region - Verify  Writeoff1 value, Writeoff2 value, Debit value and Transfer to dropdown values

  cy.cGroupAsStep(
    'Verify  Writeoff1 value, Writeoff2 value, Debit value and Transfer to dropdown values'
  );
  remittancePosting.verifyWriteOff1ValueInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    ''
  );
  remittancePosting.verifyWriteOff2ValueInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    ''
  );
  remittancePosting.verifyDebitValueInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    ''
  );
  remittancePosting.verifyTransferToDropdownValuesInTransactionGrid(
    td_manual_remittance_posting_tcid_265863.PatientCase[0].PatientDetails
      .LastName,
    transferTo
  );
  remittancePosting.clickOnDefaults();
  remittancePosting.verifyDefaults(
    td_manual_remittance_posting_tcid_265863.Defaults.ShowDefaults
  );
  // #endregion
}
