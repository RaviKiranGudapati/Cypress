import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { VerifyTransactionsTcId276342 } from './scenarios/tcid-276342.sc';

/*Test Script Validation Details *****
 * The spec file have dependency on seed data.
 * Script Execution Approach -
 * Enter Application URL in browser and click enter key.
 * 1. Click Transactions icon >> Select the charge >> Click on the Payment icon >> Check the Window modal is opened.
 * 2. Document the Deductible/Coins/Copay as (100) >> Document the amount (2000) >> Document the Transaction Code >> Document the reason code >>Document Group code >> Document Remark code >>Document the Transfer to >> Click on done button.
 * 3. Check the Deductible/Coins/Copay amount will be displayed under "Pat.Resp" option under charge >> Click on Payment Content menu >> Click on View/ Eidt option >> Observe the modal window.
 * 4. Edit the data like amount (1000) >> Click on done
 * 5. Click on Payment Content menu >> Click on Correction option >> Payment Correction window will be open >> Period / Batch Transaction Date , Transaction Code, Payment Amount, Received From will be displayed >> New payment amount will be displayed >> New balance will displayed >> Select the Correction Code as "System correction" >> Enter New Payment Amount as "1000" >> Click on Done >> Check the Correction record will be displayed >> Check the payment content menu.
 * 6. Click on payment correction content menu >> Check View/ edit and delete option will is displayed >> Click on View/ Edit >> Check the Edit Payment Correction modal window will be displayed >> Edit the amount (750) >> click on done.
 * 7. Click on Delete option >> Delete Correction pop-up will be opened >> Click on Yes >> Click on No
 * 8. Check correction payment is deleted >> Click on payment content menu.
 * 9. Click on payment content menu >> Click on delete >> Payment deletion pop-up will be displayed >> Click on "Yes"/Click on No
 * 10. Select the charge >> Click on Write off >> Write off modal will be opened >> Period? batch Received From, Transaction Date, DOS, CPT®/HCPCS, Physician, Charge Amount, Balance Due will be auto populate >> Enter the Write off amount as (1000) >> Select the Write-Off Transaction Code >> Select the Transfer to the next party as "Yes" >> Click on Done.
 * 11. Click on Write off Content menu >> Click on Correction option >> Payment Correction window will be open >> Period / Batch Transaction Date , Transaction Code, Payment Amount, Received From will be displayed >> New write amount will be displayed >> New balance will displayed >> Select the Correction Code as "System correction" >> Enter New write Amount as "1000" >> Click on Done >> Check the Correction record will be displayed >> Check the write off content menu.
 * 12. Click on corrected Write -off content menu >> Check View/ edit and delete option will is displayed >> Click on View/ Edit >> Check the Edit Write Correction modal window will be displayed >> Edit the amount (750) >>click on done
 * 13. Click on Delete option >> Delete Correction will be opened >> Click on Yes/Click on No
 * 14. Check correction payment is deleted >> Click on payment content menu.
 * 15. Click on Write off content menu >> Click on delete >> Payment deletion pop-up will be displayed >> Click on "Yes"/Click On "No"
 * 16. Select the charge >> Click on Debit >> Debit modal will be opened >> Period? batch Received From, Transaction Date, DOS, CPT®/HCPCS, Physician, Charge Amount, Balance Due will be auto populate >> Enter the Debit amount as (1000) >> Select the debit Transaction Code >> Select the Transfer to the next party as "Yes" >> Click on Done.
 * 17. Click on Debit Content menu >> Click on Correction option >> Payment Correction window will be open >> Period / Batch Transaction Date , Transaction Code, Payment Amount, Received From will be displayed >> New write amount will be displayed >> New balance will displayed >> Select the Correction Code as "System correction" >> Enter New write Amount as "1000" >> Click on Done >> Check the Correction record will be displayed >> Check the write off content menu.
 * 18. Click on corrected Debit content menu >> Check View/ edit and delete option will is displayed >> Click on View/ Edit >> Check the Edit debit Correction modal window will be displayed >> Edit the amount (750) >>click on done
 * 19. Click on Delete option >> Delete Correction will be opened >> Click on Yes/Click on No
 * 20. Check correction payment is deleted >> Click on payment content menu >> Click on Debit content menu >> Click on delete >> Payment deletion pop-up will be displayed >> Click on "Yes" >> Click On "No"
 * 21. Select the charge >> Click on Debit >> Debit modal will be opened >> Period? batch Received From, Transaction Date, DOS, CPT®/HCPCS, Physician, Charge Amount, Balance Due will be auto populate >> Select the Transfer Transaction Code as "SG" >>Click on Done.
 * 22. Click on Transfer content menu >> Click on Delete option >> Delete transfer pop-up will be displayed >> Click on "Yes"/Click "No"
 ************************************************************************/

/* instance variables */
const verifyTransaction = new VerifyTransactionsTcId276342();

describe(
  'Verify the Transaction functionality for Payments, Write off, Debits, and Transfers to other Responsible parties.',
  { tags: ['ditl', 'transaction', 'US#278248', 'TC#276342'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_21[0],
        Password: UserList.GEM_USER_21[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_21, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        verifyTransaction.verifyTransactionFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
