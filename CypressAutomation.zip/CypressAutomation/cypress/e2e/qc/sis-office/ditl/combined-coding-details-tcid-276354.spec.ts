import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId276354 } from './scenarios/tcid-276354.sc';

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into SIS  Office application and Navigate to the combined Coding/Charge Entry Page.
 * 2. Verify the headers in the combined Coding/Charge Entry page and perform the actions on ascending/descending order on the header
 * 3. Select the checkbox and click on add selected to perform . Add a new procedure and search for cpt , diagnosis code.
 * 4. Remove and add the physician , preferring physician, modifiers from available list
 * 5. verify the generate bill checkbox, self pay toggle button and verify the increase /decrease in balance and total balance due on adding discounts
 * 6. Click on adjustment tab and verify the balance and total balance due on adding write offs and debits
 * 7. Navigate to facesheet charge entry and verify the cpt, diagnosis code, balance.
 * 8. Click and enter details in additional claim information and save.
 * 9. Navigate to combined coding and select the case and check the additional claim information.
 * 10. Verify the case should fall off the tracker after performing ready to bill.
 ************************************************************************/

/* instance variables */
const combinedCoding = new CombinedCodingTcId276354();

describe(
  'Verify the Charge Entry details from combinedCoding/Charge Entry',
  { tags: ['ditl', 'combined-coding', 'US#278217', 'TC#276354'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyAdditionDeletionOfFieldData();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
