import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { CaseCreationVerificationTcId276386 } from './scenarios/tcid-276386.sc';

/* instance variables */
const caseCreation = new CaseCreationVerificationTcId276386();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into application and navigate to Schedule grid.
 * 2. Verify and Create a new patient window fields.
 * 3. Billing Details tab, select the "Primary Insurance", Secondary Insurance and select the "Tertiary Insurance" and click on "Done" button.
 * 4. Click on "Patient" >> Edit  >> Case Details tab, change the "End Time" and Observe the duration >> Click on done.
 * 5. Navigate to scheduling grid >> Click on "Patient" >> Edit  >> Click on Add button >> In Add Preference Card popup, select a "Preference Card" >> Click on "Done".
 * 6. Navigate to scheduling grid >> Click on "Patient" >> Edit  >> Click on "Billing details" tab >> Click on "Primary Guarantor" drop down >> Click on "Add New Guarantor" >> Document the "First Name , Last Name, DOB" >> Click on "Done" button.
 * 7. Navigate to scheduling grid >> Click on "Patient" >> Edit >> Check the details Duration >> Room >> Start, end time >> Preference card along with mapped procedures, Equipment >> Click on "Done" button
 * 8. Navigate to scheduling grid >> Click on "Patient" >> Edit >> Check  whether the below details are displaying correctly or not Room DOS, Start time and End time
 * 9. Open the same case and update the below details >> Click on "Done" button Room, DOS, Start and end time.
 * 10. Navigate to scheduling grid >> Click on "Patient" >> Click on "Arrive".
 * 11. Navigate to scheduling grid >> Click on "Patient" >> Click on "Check-in" >> Go to Billing and payments tab >> Select Period, Batch >> Add some data in Amount collected, Payment id fields >> Click Done button.
 * 12. Logout from application
 */

describe(
  'Patient Intake and Case Management Process',
  { tags: ['ditl', 'case-create', 'TC#276386', 'US#277288'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_7[0],
        Password: UserList.GEM_USER_7[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_7, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        caseCreation.caseCreationVerification();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
