import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';
import { ProcedureVerificationTcId264333 } from '../charge-entry/scenarios/tcid-264333.sc';

// SHIFT + ALT + O - Organizing the import
/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify manually added new procedure and Total Amount field in Charge entry
 * Precondition -
 * Create 1 Insurance for 2nd Patient and 1 Guarantor for 3rd patient.
 * Create 3 Patient and link Insurance to 2nd Patient.
 * Login via user.
 *
 * Script Execution Approach -
 * 1. For Patient 1, navigate to facesheet charge entry, expand procedure 1 and verify the procedure details.
 * 2. Click Add Procedure and verify procedure details got auto-populated based on the existing procedure.
 * 3. Document cpt procedure for new procedure and verify user should modify all procedure details for the new procedure.
 * 4. Select Ready for Bill to No and click Done button in charge entry. Navigate to other page and come back to check updated procedure details are available for procedure 3 and self pay toggle button is by default Yes for new procedure.
 * 5. Delete Procedure 1 and 3. Expand Procedure 2 and modify the procedure details.
 * 6. Click Add Procedure and verify recently updated Procedure 2 details got auto-populated in the new procedure.
 * 7. Document all mandatory data and update ready for bill as Yes. Navigate to Transaction Page and check whether patient got updated in responsible column.
 * 8. For Patient 2, navigate to Charge Entry Tracker, expand procedure 1 details and modify all procedure details including insurances.
 * 9. Click Add Procedure and verify all the updated details including insurances got auto-populated for the new procedure.
 * 10. Complete Check-In for Patient 3 by adding New Guarantor Details.
 * 11. Navigate to Facesheet Transactions Page, expand the charge and verify Responsible column whether newly added guarantor got added there.
 * 12. Logout
 ************************************************************************/

/* instance variables */
const procedureVerification = new ProcedureVerificationTcId264333();

describe(
  'Verify contractual data WriteOff added to the contracts is correctly displayed on the Charge Entry Screen',
  { tags: ['charge-entry', 'US#268293', 'TC#264333'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        procedureVerification.verifyPrimaryProcedureFields();
        procedureVerification.verifyFieldValues();
        procedureVerification.verifyResponsibleWithGuarantor();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
