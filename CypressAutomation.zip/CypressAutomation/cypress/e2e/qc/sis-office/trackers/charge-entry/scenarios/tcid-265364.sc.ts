import { ExpandOrCollapse } from '../../../../../../support/common-core-libs/application/common-core';

import { td_additional_claim_tcid_269055 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/additional-claim-details-tcid-265364.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import { hcfaFields } from '../../../../../../app-modules-libs/sis-office/trackers/constants/combined-coding.const';

/* instance variables */
const createCase = new CreateCase(td_additional_claim_tcid_269055.PatientCase);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const combinedCoding = new CombinedCoding();

export class AdditionalClaimDetailsTcId265364 {
  additionalClaimDetailsInfo() {
    describe('Verify and add additional claim info data in charge entry', () => {
      it('Verifying and adding  additional claim info data', () => {
        // #region - Select patient in charge entry tracker and verify no data documented without adding data

        cy.cGroupAsStep(
          'Select patient in charge entry tracker and verify no data documented without adding datain Additional claim details'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(td_additional_claim_tcid_269055.ChargeDetails);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);

        /** To verify and click the additional Claim Information button */
        combinedCoding.verifyAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );

        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        // #endregion

        // #region - To verify the additional claim details once after enter the data in UB tab

        cy.cGroupAsStep(
          'To add and verify the additional claim data under UB tab'
        );
        /** Enter the Data in Conditional Code and Verifying the data */
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_INSTITUTIONAL[0]
        );
        combinedCoding.enterDataInUbFields(
          td_additional_claim_tcid_269055.UBAdditionalClaim[0]
        );

        combinedCoding.enterDataInUbFields(
          td_additional_claim_tcid_269055.UBAdditionalClaim[1]
        );

        combinedCoding.verifyUbAdditionalClaimData(
          td_additional_claim_tcid_269055.UBAdditionalClaim[0]
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_additional_claim_tcid_269055.UBAdditionalClaim[1]
        );

        // #endregion

        // #region - To verify the additional claim details once after enter the data in HCFA tab

        cy.cGroupAsStep(
          'To add and verify the data under HCFA tab in additional claim information popup'
        );
        /**  Select the HCFA Tab */
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.verifyHcfaProfessionalLabels(hcfaFields);

        /** Enter Conditional Code in HCFA and Data should be saved  */

        combinedCoding.addHcfaAdditionalClaimCodes(
          td_additional_claim_tcid_269055.HCFAAdditionalClaim[0]
        );

        combinedCoding.addHcfaAdditionalClaimSupplementalInfo(
          td_additional_claim_tcid_269055.HCFAAdditionalClaim[0]
        );
        combinedCoding.addHcfaAdditionalClaimNotesInfo(
          td_additional_claim_tcid_269055.HCFAAdditionalClaim[0]
        );

        combinedCoding.verifyConditionCodesHCFA(
          td_additional_claim_tcid_269055.HCFAAdditionalClaim[0],
          0
        );

        combinedCoding.verifyClaimSupplementalInfo(
          td_additional_claim_tcid_269055.HCFAAdditionalClaim[0]
        );
        combinedCoding.verifyClaimNoteInfo(
          td_additional_claim_tcid_269055.HCFAAdditionalClaim[0]
        );
        // #endregion
      });
    });
  }
}
