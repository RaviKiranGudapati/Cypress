import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { ChargeEntryTrackerTcId264581 } from './scenarios/tcid-264581.sc';

//SHIFT + ALT + O - Organizing the import
/*Test Script Validation Details *****
 * The spec file have dependency on seed data. Three patients are created through seed data with three different insurance and contract respectively.
 * All three cases are completed until ready for Bill
 * Script Execution Details -
 *1.Seed data needs to be executed.
 *2.Login to the application
 *3.Navigate to charge entry tracker.
 *4.Select period and batch and select the created patient.
 *5.click on add supplies button.
 *6.Verify the fields present.
 *7.Verify the fields present in medication.
 *8.Verify the saved data after providing data in all mandatory fields.
 *9.Verify the delete supplies functionality.
 ************************************************************************/

/* instance variables */
const chargeEntryTracker = new ChargeEntryTrackerTcId264581();

describe(
  'Verify add supplies functionality in charge entry',
  { 
    tags: ['charge-entry', 'US#269054', 'TC#264581'], 
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        chargeEntryTracker.verifyAddSuppliesFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
