import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import ChargeEntryTcId265365 from './scenarios/tcid-265365.sc';

/*Test Script Validation Details *****

 * The spec file have dependency on seed data. Three patients are created through seed data with three different insurance respectively.
 * All three cases are completed until ready for Bill
 * Script Execution Details -
 * 1. Login to the SISOffice with credentials Gem_user3, Gem_Org003
 * 2. Navigate to Charge Entry tracker and click on the Patient
 * 3. Click on the Additional Claim Information button and verify the fields  and update the values
 *    First Occurrence, Initial Treatment under HCFA tab
 *    Disability Status with Status as "None / Partial / Full" as a toggle
 *    Disability From Date, Disability Through Date
 * 4. Verify the Claim supplemental information with fields and max character length -
 *    “#” as column header.
 *    “Report To” as column header.
 *    “Transmission Code ” as column header.
 *    “Control ” as column header.
 * 5. Verify addition, update and delete for Claim supplemental information
 * 6. Verify and update data documented for Clinical Trial Number fields

 ************************************************************************/

/* instance variables */
const chargeEntry = new ChargeEntryTcId265365();

describe(
  'Verify the data in Additional Claim information screen',
  { tags: ['charge-entry', 'US#269249', 'TC#265365'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        chargeEntry.verifyFieldsInAdditionalClaimInfo();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
