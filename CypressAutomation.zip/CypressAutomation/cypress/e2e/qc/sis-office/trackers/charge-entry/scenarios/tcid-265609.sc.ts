import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import {
  ExpandOrCollapse,
  HierarchyOptions,
  ProcedureType,
} from '../../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_charge_entry_tcid_265609 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/charges-verification-tcid-265609.td';

import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import FaceSheetChargeEntry from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const chargeEntry = new ChargeEntry(td_charge_entry_tcid_265609.PatientCase);
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();

export class FaceSheetChargeEntryTcId265609 {
  verifyCharges() {
    describe('Verify Charges are posted with contracts in charge entry tracker', () => {
      it('Navigating to Nursing desktop and updating the procedure type in contracts from application settings', () => {
        // #region - Selecting procedure type from application settings contracts

        cy.cGroupAsStep(
          'Selecting procedure type from application settings contracts'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.CONTRACTS[0],
          true
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_265609.Contract[0]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_265609.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );

        // #endregion
      });

      it('Selecting patient from Masthead and verify writeoff and balance of procedure in charge entry', () => {
        // #region - Selecting patient from Masthead and verify writeoff and balance of procedure

        cy.cGroupAsStep(
          'Selecting patient from Masthead and verify writeoff and balance of procedure in charge entry'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(td_charge_entry_tcid_265609.Charges[0]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.selectDiscount(
          td_charge_entry_tcid_265609.Charges[0].Discounts!
        );
        chargeEntry.validateWriteOff(
          td_charge_entry_tcid_265609.Adjustment.WriteoffAmount
        );
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_265609.Charges[0].Balance!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        // #endregion

        // #region - Add procedure and verifying writeoff and balance in charge entry

        cy.cGroupAsStep(
          'Add procedure and verifying writeoff and balance in charge entry'
        );
        chargeEntry.clickAddProcedureButton();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        chargeEntry.addProcedure(td_charge_entry_tcid_265609.CPT[1]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_265609.Charges[1].Balance!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.removeInsurance(HierarchyOptions.primary);

        chargeEntry.addInsurance(
          HierarchyOptions.primary,
          td_charge_entry_tcid_265609.PatientCase.PatientDetails
            .InsuranceCoverage[2].InsuranceCarrier
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.verifyChargeAmount(
          td_charge_entry_tcid_265609.Charges[2].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        // #endregion
      });

      it('Drag and drop the procedures and verify writeoff and balance of procedure in charge entry', () => {
        // #region - Adding and verifying modifier by dragging and dropping the procedure in charge entry

        cy.cGroupAsStep(
          'Adding and verifying modifier by dragging and dropping the procedure in charge entry'
        );
        chargeEntry.dragAndDropCharges(
          td_charge_entry_tcid_265609.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription,
          td_charge_entry_tcid_265609.CPT[1].CPTCodeAndDescription
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.selectModifier(td_charge_entry_tcid_265609.Charges[0]);
        faceSheetChargeEntry.verifyModifier(
          td_charge_entry_tcid_265609.Charges[0].Modifier!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        // #endregion

        // #region - Verifying the Amount in charge entry by adding procedure

        cy.cGroupAsStep(
          'Adding procedure with zero amount and verifying the amount field'
        );
        chargeEntry.clickAddProcedureButton();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 3);
        chargeEntry.addProcedure(td_charge_entry_tcid_265609.CPT[2]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 3);
        chargeEntry.verifyChargeAmount(
          td_charge_entry_tcid_265609.Charges[1].Amount
        );
        // #endregion

        // #region - Expanding procedure and updating unit value and verifying Amount updated

        cy.cGroupAsStep('Updating unit value and verifying Amount updated');
        chargeEntry.updateUnit(td_charge_entry_tcid_265609.Charges[0], 3);
        chargeEntry.verifyChargeAmount(
          td_charge_entry_tcid_265609.Charges[1].Amount
        );

        // #endregion
      });
    });
  }
}
