import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { ChargeEntryTrackerTcId29389 } from './scenarios/tcid-29389.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

// SHIFT + ALT + O - Organizing the import
/*Test Script Validation Details *****
 * The spec file have dependency on seed data. Three patients are created through seed data with three different insurance and contract respectively.
 * All three cases are completed until ready for Bill
 * Script Execution Details -
 * 1. Navigate to Charge Entry screen, selecting patient1 and verifying the writeoff.
 * 2. Removing the primary insurance, verifying the writeoff and balance.
 * 3. Re-adding the Primary Insurance, verifying the writeoff and balance again.
 * 4. Expand the procedure2, verify the writeoff and balance. Completing the ready for bill for the patient.
 * 5. Navigate to Charge Entry screen, selecting patient2 and verifying the writeoff.
 * 6. Removing the primary insurance, verifying the writeoff and balance.
 * 7. Re-adding the Primary Insurance, verifying the writeoff and balance again.
 * 8. Expand the procedure2, verify the writeoff and balance. Completing the ready for bill for the patient.
 * 9. Navigate to Charge Entry screen, selecting patient3 and verifying the writeoff.
 * 10. Removing the primary insurance, verifying the writeoff and balance.
 * 11. Re-adding the Primary Insurance, verifying the writeoff and balance again.
 * 12. Expand the procedure2, verify the writeoff and balance. Completing the ready for bill for the patient.
 ************************************************************************/

/* instance variables */
const chargeEntryTracker = new ChargeEntryTrackerTcId29389();

describe(
  'Verify contractual data WriteOff added to the contracts is correctly displayed on the Charge Entry Screen',
  { tags: ['charge-entry', 'US#10056', 'US#49302', 'TC#29389'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_8[0],
        Password: UserList.GEM_USER_8[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        chargeEntryTracker.verifyWriteOffAndTotalCharge();
        chargeEntryTracker.verifyBalanceWriteOffAndTotalCharge();
        chargeEntryTracker.verifyWriteOffNotDisplayed();
        chargeEntryTracker.verifyWriteOffAndBalance();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
