import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { ChargeEntryTcId224705 } from './scenarios/tcid-224705.sc';

/* instance variables */
const chargeEntry = new ChargeEntryTcId224705();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Login to application, click on charge entry tracker select period and batch and click patient1.
 *2.Click on add selected to perform and expand procedure1, click on additional claim information button, verify Apply to All Charges.
 *3.verify no option is selected for apply all charges, and Document the data at the below fields
    Accident State, Accident date, Patient condition Due to
    Resubmission Frequency Code
    PI Document Ctrl #
    SI Document Ctrl #
    TI Document Ctrl #
    Document all data under UB/Institutional tab (Ex: Condition Codes, Occurrence Span Codes & Date Information, Occurrence Codes & Date Information...etc)
    Document all data under HCFA/Professional tab (Ex: First Occurrence, Date of Onset...etc)
 *4.Set apply to all charges no and click on done button. again click on additional claim information button
 *5.Observe that all fields data at both UB/Institutional and HCFA/Professional tabs are displayed correctly, close window of additional claim information.
 *6.Expand procedure2, click on additional claim information and verify fields should be empty, close the window without clicking on done button. Expand procedure1, click on additional claim information and Select Yes option for Apply to All charges toggle, Click Done button on the window. Expand procedure2, click on additional claim information and verify all the fields, close the window.
 *7.Click on add procedure button and search procedure and select it and verify additional claim information should be disable mode. Document mandatory data and collapse procedure and expand and verify additional claim information button should be enable mode. Document all the fields in Additional claim info and set apply to all charges to yes and click on cross icon.
 *8.Again click on additional claim info and verify all fields (should be empty), document all mandatory fields and  Select Yes option for Apply to All charges toggle, Click Done button.
 *9.collapse procedure3 and expand procedure1 and select additional claim information and verify all the fields, collapse procedure1. expand procedure3 and verify the documented data. Remove the data at Clinical trial number, Resubmission frequency code, PI, SI, TI document fields click yes and click on done button.
 *10.Navigate to schedule gird>>click on patient>>face sheet>>charge entry>>expand procedure3 and verify removed data and collapse procedure3.
 *11.Expand procedure1 and click on additional claim information and Select Yes option for Apply to All charges toggle, Click Done button. and collapse procedure1. Expand procedure3 click on additional claim information  and verify the documented fields, click on done button and collapse procedure3. Expand procedure2 and click on additional claim  information  and verify the documented fields(procedure1), and collapse procedure2.
 *12.Click on add supplies button search procedure and hcpcs and select it and verify additional claim information should be disable mode. Document mandatory data and collapse supplie and expand and verify additional claim information button should be enable mode, click on additional claim info and verify the fields should be empty and collapse supplie.
 *13.Expand procedure1 select additional claim information and Select Yes option for Apply to All charges toggle, Click Done button. and collapse procedure1. Expand supplie and verify fields that should match with procedure1, set ready for bill yes and click on done button.
 *14.Navigate to case to code and come back to charge entry. click on Add procedure and add procedure4, click on additional claim information and verify fields should be empty and collapse procedure4.
 *15.Expand procedure1 and Select Yes option for Apply to All charges toggle, Click Done button. Collapse procedure1, expand procedure4 and click on additional claim information and verify the fields should match with procedure1 and close additional claim information window(cross icon)
 *16.Log out from the application.
 */

describe(
  'Verify All charges toggle functionality Charge entry',
  { tags: ['charge-entry', 'US#269308', 'TC#224705'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        chargeEntry.verifyToggleFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
