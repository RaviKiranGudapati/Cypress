import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { td_add_supplies_charge_entry_tcid_264581 } from '../../../../../../fixtures/sis-office/case/check-in/forms-consents/td_add_supplies_charge_entry_tcid_264581.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';
import {
  headers,
  modifiers,
  unitsOfMeasure,
  writeOff,
} from '../../../../../../app-modules-libs/sis-office/trackers/constants/charge-entry.const';

/* instance variables */
const createCase = new CreateCase(
  td_add_supplies_charge_entry_tcid_264581.PatientCase[0]
);
const sisChartsDesktop = new SISChartsDesktop();
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const combinedCodings = new CombinedCoding();
const sisOfficeDesktop = new SISOfficeDesktop();
const index = [0, 1, 2];

export class ChargeEntryTrackerTcId264581 {
  verifyAddSuppliesFunctionality() {
    describe('Verify the add supplies functionality in charge entry by adding,deleting and updating the supplies', () => {
      it('Verify the mandatory fields present in the add supplies and the supplies deleting and updating functionality', () => {
        // #region  - Navigate to charge entry tracker and select Patient 1

        cy.cGroupAsStep(
          'Navigate to charge entry tracker and select Patient 1'
        );
        sisOfficeDesktop.selectSisLogo();
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );

        chargeEntry.verifyPatientRow(
          td_add_supplies_charge_entry_tcid_264581.PatientCase[0].PatientDetails
            .PatientFirstName
        );

        chargeEntry.selectCase(
          td_add_supplies_charge_entry_tcid_264581.ChargeDetails[0]
        );

        // #endregion

        // #region - Verify trash icon is visible by mouse hovering on the procedure row

        cy.cGroupAsStep(
          'Verify trash icon is visible by mouse hovering on the procedure row'
        );
        chargeEntry.verifyDeleteIconOnMouseOver(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[2]
            .CPTCodeAndDescription,
          index[0]
        );

        // #endregion

        // #region - Add new supply and verify mandatory fields

        cy.cGroupAsStep('Add new supply and verify mandatory fields');

        chargeEntry.clickAddSupplies();

        chargeEntry.verifySupplyWriteOffFields(writeOff);

        chargeEntry.verifySupplyDebitsFields();

        chargeEntry.verifySupplyRevenueFields();
        chargeEntry.verifySupplyChargeDetailsFields();
        chargeEntry.verifySupplyModifiersFields(modifiers);
        chargeEntry.verifySupplyInsurancesFields();
        chargeEntry.verifySupplyHeadersFields(headers);
        chargeEntry.verifySupplyTogglesAndAdditionalClaimFields();
        chargeEntry.verifyUnitsOfMeasure(unitsOfMeasure);

        // #endregion

        // #region  - verify and edit data in IOS field

        cy.cGroupAsStep('Verify and edit data in IOS field');

        chargeEntry.verifyHcpcsFreeText();
        chargeEntry.verifyDataInIosField(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[0]
        );

        chargeEntry.clearIosSupplyField();

        chargeEntry.verifyDataInIosField(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[1]
        );
        chargeEntry.selectIosSupply(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[1]
        );
        chargeEntry.removeIosFieldData(1);

        chargeEntry.updateIosSupplyField(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[0]
        );

        // #endregion

        // #region  - Remove physician from physician dropdown and verify dindex[1] button behavior

        cy.cGroupAsStep(
          'Clear and add physician from physician dropdown further more verify dindex[1] button behavior '
        );
        chargeEntry.removePhysician(2);
        combinedCodings.verifyFooterButtonEnableDisable(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
          true
        );
        chargeEntry.selectPhysicianDropdown(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[0].Physician!,
          index[2]
        );

        // #endregion

        // #region - Edit NDC number and verify trash icon for newly added supply

        cy.cGroupAsStep(
          'Edit NDC number and verify trash icon for newly added supply  '
        );
        chargeEntry.updateUnitsOfMeasure(unitsOfMeasure[1], index[1]);
        chargeEntry.editNDCField(
          td_add_supplies_charge_entry_tcid_264581.Charge,
          index[1]
        );
        chargeEntry.expandOrCollapseProcedure(1);

        chargeEntry.verifyDeleteIconOnMouseOver(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[2]
            .CPTCodeAndDescription,
          index[0]
        );

        // #endregion

        // #region - verify warning message on delete pop-up and delete newly added supply

        cy.cGroupAsStep(
          'Verify warning message on delete pop-up and delete newly added supply'
        );

        chargeEntry.deleteProcedure(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[2]
            .CPTCodeAndDescription,
          index[0]
        );
        chargeEntry.deleteProcedureMessage();
        chargeEntry.selectYesOrNoOnDeletePopUp(false);
        chargeEntry.deleteProcedure(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[2]
            .CPTCodeAndDescription,
          index[0]
        );
        chargeEntry.selectYesOrNoOnDeletePopUp(true);
        sisOfficeDesktop.selectSisLogo();

        // #endregion

        // #region - Logout and login with another user with same facility
        cy.cGroupAsStep(
          'Logout and login with another user with same facility to verify the delete procedure access for the user'
        );

        sisOfficeDesktop.logout();
        cy.reload();
        const login = new SISCompleteLogin();
        login.login(
          UserList.GEM_USER_NOD_FM[0],
          UserList.GEM_USER_NOD_FM[1],
          OrganizationList.GEM_ORG_3
        );

        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );

        chargeEntry.selectPeriodAddNewBatch(
          td_add_supplies_charge_entry_tcid_264581.ChargeDetails[1].Period,
          td_add_supplies_charge_entry_tcid_264581.ChargeDetails[1].Batch
        );
        chargeEntry.verifyPatientRow(
          td_add_supplies_charge_entry_tcid_264581.PatientCase[0].PatientDetails
            .PatientFirstName
        );

        chargeEntry.selectCase(
          td_add_supplies_charge_entry_tcid_264581.ChargeDetails[1]
        );
        chargeEntry.verifyDeleteIconOnMouseOver(
          td_add_supplies_charge_entry_tcid_264581.CptCodeInfo[3]
            .CPTCodeAndDescription,
          index[0]
        );
        // #endregion
      });
    });
  }
}
