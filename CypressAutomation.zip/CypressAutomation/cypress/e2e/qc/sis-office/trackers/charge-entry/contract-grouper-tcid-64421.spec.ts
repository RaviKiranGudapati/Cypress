import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { ContractGrouperTcId64421 } from './scenarios/tcid-64421.sc';

/* instance variables */
const contractGrouper = new ContractGrouperTcId64421();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into application and navigate to Schedule grid.
 * 2. Navigate to the chargeEntry and select the patient 1 Verify the Balance, Amount
 * 3. select the patient 2 and Verify the Balance, Amount
 * 4. select the patient 3 and Verify the Balance, Amount of all procedures
 * 5. Remove and re-add the insurance for two proceudres and Verify the Balance, Amount
 * 6. Logout from application
 */

describe(
  'Verify When Supply charges are posted in Facesheet and Calculations for each pricing type as follows',
  { tags: ['charge-entry', 'TC#64421', 'US#269086'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_4[0],
        Password: UserList.GEM_USER_4[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        contractGrouper.contractGrouper();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
