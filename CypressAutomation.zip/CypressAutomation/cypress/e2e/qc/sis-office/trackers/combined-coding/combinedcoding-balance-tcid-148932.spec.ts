import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId148932 } from './scenarios/tcid-148932.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId148932();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 *1.Login to the application and click on Patient1 case In combined coding/charge entry.
 *2.Click on Coding /Charge Entry Tracker and select period and batch and select patient1.
 *3.Select added procedure and Verify Amount and Balance in added procedure.
 *4.Click on Add procedure, select cpt and hcpcs and click on done button.
 *5.Click on SIS Desktop and select Coding /Charge Entry Tracker and select period and batch and select patient2.
 *6.Select added procedure and Verify Amount and Balance in added procedure.
 *7.Click on Add procedure, select cpt and hcpcs and click on next case button.
 *8.Click on SIS Desktop and select Coding /Charge Entry Tracker and select period and batch and select patient3.
 *9.Select added procedure and Verify Amount and Balance in added procedure.
 *10.Click on Add procedure, select cpt and hcpcs and click on done button.
 *11.Logout from the application.
 */

describe(
  'Verify balance issue in combined coding tracker',
  { tags: ['enterprise-dictionary', 'US#268500', 'TC#148932'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyBalanceIssue();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
