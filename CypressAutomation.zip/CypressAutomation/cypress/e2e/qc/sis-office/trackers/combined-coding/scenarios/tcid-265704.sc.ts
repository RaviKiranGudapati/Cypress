import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  HierarchyOptions,
  ProcedureType,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_charges_posted_tcid_265704 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/charges-posted-tcid-265704.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const chargeEntry = new ChargeEntry(
  td_charges_posted_tcid_265704.PatientCase[0]
);
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const combinedCoding = new CombinedCoding();

export class CombinedCodingTcId265704 {
  verifyChargesPosted() {
    describe('To verify charges posted in combined coding', () => {
      it('Navigate to Application settings select procedure and update type for contracts', () => {
        // #region - Navigate to Application settings Contracts and select procedure and type for contracts added

        cy.cGroupAsStep(
          'Navigate to Application settings Contracts and select procedure and type for contracts added'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.CONTRACTS[0],
          true
        );
        nursingConfiguration.searchContractOptions(
          td_charges_posted_tcid_265704.Contract[0]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charges_posted_tcid_265704.CptInfo[0].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.searchProcedureInContract(
          td_charges_posted_tcid_265704.CptInfo[1].CPTCodeAndDescription
        );
        nursingConfiguration.searchContractOptions(
          td_charges_posted_tcid_265704.Contract[1]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charges_posted_tcid_265704.CptInfo[0].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.no_write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_charges_posted_tcid_265704.CptInfo[1].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.no_write_off
        );
        nursingConfiguration.searchContractOptions(
          td_charges_posted_tcid_265704.Contract[2]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charges_posted_tcid_265704.CptInfo[0].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_charges_posted_tcid_265704.CptInfo[1].CPTCodeAndDescription
        );
        // #endregion;
      });

      it('Navigate to Combined coding/Charge Entry and verify the amounts ', () => {
        // #region - Select combined coding tracker and select procedure1 and verify write amount in adjustment tab, amount and balance in charge tab

        cy.cGroupAsStep(
          'Select combined coding tracker and select procedure1 and verify write amount in adjustment tab, amount and balance in charge tab'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );

        combinedCoding.selectCase(
          td_charges_posted_tcid_265704.Charges,
          td_charges_posted_tcid_265704.PatientCase[0]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmountValue('');
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyAmount(
          td_charges_posted_tcid_265704.ChargeDetails[0].Amount
        );
        combinedCoding.verifyBalanceAmount(
          td_charges_posted_tcid_265704.ChargeDetails[0].Balance
        );

        // #endregion

        // #region - Click on add procedure and verify writeoff amount in adjustment tab, balance in charge tab

        cy.cGroupAsStep(
          'Click on add procedure and verify writeoff amount in adjustment tab, balance in charge tab'
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.searchAndSelectCptInProcedure(
          td_charges_posted_tcid_265704.CptInfo[3].CPTCodeAndDescription
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_charges_posted_tcid_265704.Adjustment.WriteoffAmount[1]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyBalanceAmount(
          td_charges_posted_tcid_265704.ChargeDetails[2].Balance
        );

        // #endregion

        // #region - Select Procedure 1 and remove primary Insurance and add another insurance and verify writeoff amount in adjustment tab

        cy.cGroupAsStep(
          'Select Procedure 1 and remove primary Insurance and add another insurance and verify writeoff amount in adjustment tab'
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        combinedCoding.clickOnInsuranceCrossIcon();
        chargeEntry.addInsurance(
          HierarchyOptions.primary,
          td_charges_posted_tcid_265704.PatientCase[0].PatientDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmountValue('');
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        chargeEntry.addInsurance(
          HierarchyOptions.primary,
          td_charges_posted_tcid_265704.PatientCase[0].PatientDetails
            .InsuranceCoverage[2].InsuranceCarrier
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_charges_posted_tcid_265704.Adjustment.WriteoffAmount[2]
        );

        // #endregion

        // #region - Drag and drop the procedures and verify write off in adjustment tab and add modifier to procedure1

        cy.cGroupAsStep(
          'Drag and drop the procedures and verify write off in adjustment tab and add modifier to procedure1'
        );
        combinedCoding.dragAndDropCharges(
          td_charges_posted_tcid_265704.CptInfo[0].CPTCodeAndDescription,
          td_charges_posted_tcid_265704.CptInfo[1].CPTCodeAndDescription
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmountValue('');
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.selectModifiers(
          td_charges_posted_tcid_265704.Charges.Modifier1,
          1
        );
        combinedCoding.verifyPerformedItem();

        // #endregion

        // #region - Add procedure and drag and drop added procedure and verify amount and balance in charge tab

        cy.cGroupAsStep(
          'Add procedure and drag and drop added procedure and verify amount and balance in charge tab'
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.searchAndSelectCptInProcedure(
          td_charges_posted_tcid_265704.CptInfo[4].CPTCodeAndDescription
        );
        combinedCoding.dragAndDropCharges(
          td_charges_posted_tcid_265704.CptInfo[4].CPTCodeAndDescription,
          td_charges_posted_tcid_265704.CptInfo[0].CPTCodeAndDescription
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.CptInfo[2].CPTCodeAndDescription
        );
        combinedCoding.verifyAmount(
          td_charges_posted_tcid_265704.ChargeDetails[3].Amount
        );
        combinedCoding.enterUnits(td_charges_posted_tcid_265704.Charges.Unit);
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyAmount(
          td_charges_posted_tcid_265704.ChargeDetails[4].Amount
        );
        combinedCoding.verifyBalanceAmount(
          td_charges_posted_tcid_265704.ChargeDetails[4].Balance
        );
        combinedCoding.clickReadyForBillAndDoneButton();

        // #endregion

        // #region - Select patient1 and verify all charges amount and balance in charges tab

        cy.cGroupAsStep(
          'Select patient1 and verify all charges amount and balance in charges tab'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_charges_posted_tcid_265704.Charges,
          td_charges_posted_tcid_265704.PatientCase[0]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        combinedCoding.verifyAmount(
          td_charges_posted_tcid_265704.ChargeDetails[0].Amount
        );
        combinedCoding.verifyBalanceAmount(
          td_charges_posted_tcid_265704.ChargeDetails[2].Balance
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.PatientCase[0].CaseDetails
            .CptCodeInfo[1].CPTCodeAndDescription
        );
        combinedCoding.verifyAmount(
          td_charges_posted_tcid_265704.ChargeDetails[1].Amount
        );
        combinedCoding.verifyBalanceAmount(
          td_charges_posted_tcid_265704.ChargeDetails[1].Balance
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.CptInfo[3].CPTCodeAndDescription
        );
        combinedCoding.verifyAmount(
          td_charges_posted_tcid_265704.ChargeDetails[6].Amount
        );
        combinedCoding.verifyBalanceAmount(
          td_charges_posted_tcid_265704.ChargeDetails[6].Balance
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charges_posted_tcid_265704.CptInfo[4].CPTCodeAndDescription
        );
        combinedCoding.verifyAmount(
          td_charges_posted_tcid_265704.ChargeDetails[2].Amount
        );
        combinedCoding.verifyBalanceAmount(
          td_charges_posted_tcid_265704.ChargeDetails[2].Balance
        );
        combinedCoding.clickReadyForBillAndDoneButton(true);
        combinedCoding.verifyPatientFallOffInCombinedCoding(
          td_charges_posted_tcid_265704.PatientCase[0].PatientDetails
            .PatientFullName
        );

        // #endregion

        // #region - Verify patient 2 fall out off combined coding tracker and verify patient3 in patient panel

        cy.cGroupAsStep(
          'Verify patient 2 fall out off combined coding tracker and verify patient3 in patient panel'
        );

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_charges_posted_tcid_265704.Charges,
          td_charges_posted_tcid_265704.PatientCase[1]
        );
        combinedCoding.nextCaseButton();
        combinedCoding.verifyPatientInPatientPanel(
          td_charges_posted_tcid_265704.PatientCase[2].PatientDetails
            .PatientFullName
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.verifyPatientFallOffInCombinedCoding(
          td_charges_posted_tcid_265704.PatientCase[1].PatientDetails
            .PatientFullName
        );
        // #endregion
      });
    });
  }
}
