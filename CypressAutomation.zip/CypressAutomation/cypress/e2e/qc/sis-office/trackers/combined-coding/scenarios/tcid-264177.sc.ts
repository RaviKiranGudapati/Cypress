import {
  DoneOrCancel,
  HierarchyOptions,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_combined_coding_tcid_264177 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/code-charge-insurances-tcid-264177.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();

export class CombinedCodingTcId264177 {
  verifyBaseLayout() {
    describe('Verify Base layout for combined coding tracker', () => {
      it('Verifying base layout for the combined coding tracker', () => {
        // #region Navigating to combined coding tracker and verifying warning messages

        cy.cGroupAsStep(
          'Navigating to combined coding tracker and verifying warning messages for Period selection'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.verifyPeriodWarning(
          td_combined_coding_tcid_264177.PatientCase
        );

        // #endregion

        // #region Selecting the case and verifying Bill supplies and Add Selected Perform

        cy.cGroupAsStep(
          'Selecting the case and verifying Bill supplies and Add Selected Perform'
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_264177.Charges[0],
          td_combined_coding_tcid_264177.PatientCase
        );
        combinedCoding.verifyCPTInBillableSupplies(
          td_combined_coding_tcid_264177.Charges[0]
        );
        combinedCoding.verifyCPTInBillableSupplies(
          td_combined_coding_tcid_264177.Charges[1]
        );
        combinedCoding.verifyPerformedItems();
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[0].CPT
        );

        // #endregion

        // #region Selecting Charge option and verifying the default charge values

        cy.cGroupAsStep(
          'Selecting Charge option and verifying the default charge values'
        );
        combinedCoding.verifyChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyPerformedItemsHeader();
        combinedCoding.verifyChargeDefaultValues(
          td_combined_coding_tcid_264177.Charges[0]
        );
        combinedCoding.selectDiagnosisCode(
          td_combined_coding_tcid_264177.Charges[0]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[1].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[0].CPT
        );

        // #endregion
      });
    });
  }

  verifyInsuranceUpdate() {
    describe('Verify Insurances Update', () => {
      it('Verifying default insurance values and update', () => {
        // #region Removing insurance and verifying available insurances

        cy.cGroupAsStep(
          'Removing insurance and verifying available insurances'
        );
        combinedCoding.removeInsurance(HierarchyOptions.primary);
        combinedCoding.verifySelfPay(YesOrNo.yes);
        combinedCoding.clickInsuranceDropDown(
          OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0]
        );
        combinedCoding.clickPrimaryInsuranceCarrierOption(
          td_combined_coding_tcid_264177.Charges[0].PrimaryInsurance
        );
        combinedCoding.removeInsurance(HierarchyOptions.primary);
        combinedCoding.clickInsuranceDropDown(
          OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0]
        );
        combinedCoding.clickPrimaryInsuranceCarrierOption(
          td_combined_coding_tcid_264177.Charges[0].SecondaryInsurance
        );
        combinedCoding.removeInsurance(HierarchyOptions.primary);
        combinedCoding.clickInsuranceDropDown(
          OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0]
        );
        combinedCoding.clickPrimaryInsuranceCarrierOption(
          td_combined_coding_tcid_264177.Charges[0].TertiaryInsurance
        );

        // #endregion

        // #region Updating and verifying insurance values

        cy.cGroupAsStep('Updating and verifying insurance values');
        combinedCoding.clickInsuranceDropDown(
          OR_COMBINED_CODING.CHARGE.SECONDARY_INSURANCE[0]
        );
        combinedCoding.clickInsuranceCarrierOption(
          td_combined_coding_tcid_264177.Charges[0].SecondaryInsurance
        );
        combinedCoding.clickInsuranceDropDown(
          OR_COMBINED_CODING.CHARGE.TERTIARY_INSURANCE[0]
        );
        combinedCoding.clickInsuranceCarrierOption(
          td_combined_coding_tcid_264177.Charges[0].PrimaryInsurance
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[0].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[1].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[0].CPT
        );
        combinedCoding.clickReadyForBillAndDoneButton();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_264177.Charges[0],
          td_combined_coding_tcid_264177.PatientCase
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[0].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[1].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264177.Charges[0].CPT
        );
        combinedCoding.verifyInsuranceValue(
          HierarchyOptions.secondary,
          td_combined_coding_tcid_264177.Charges[0].SecondaryInsurance
        );
        combinedCoding.verifyInsuranceValue(
          HierarchyOptions.tertiary,
          td_combined_coding_tcid_264177.Charges[0].PrimaryInsurance
        );

        // #endregion
      });
    });
  }

  verifyChargesNotEditable() {
    describe('Verify Charges not editable for user with only view permission', () => {
      it('Verifying Charges not editable for user with view permission', () => {
        // #region Login with user2 with view permission

        cy.cGroupAsStep('Login with user2 with view permission');
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USERONLYV_FM[0],
          Password: UserList.GEM_USERONLYV_FM[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.scrollToLastRowInTracker();
        combinedCoding.selectPeriodAddNewBatch(
          td_combined_coding_tcid_264177.Charges[1].Period,
          td_combined_coding_tcid_264177.Charges[1].Batch
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_264177.Charges[0],
          td_combined_coding_tcid_264177.PatientCase
        );
        combinedCoding.verifyFooterButtonEnableDisable(DoneOrCancel.done, true);

        // #endregion
      });
    });
  }
}
