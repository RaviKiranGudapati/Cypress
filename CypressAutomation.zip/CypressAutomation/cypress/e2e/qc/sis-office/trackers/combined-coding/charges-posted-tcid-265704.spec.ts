import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId265704 } from './scenarios/tcid-265704.sc';

/*instance variables*/
const combinedCoding = new CombinedCodingTcId265704();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -

* 1. Login to the application and click on Patient1 case In combined coding/charge entry.
* 2.Navigate to combined coding tracker and select period and batch and select patient1.
* 3.Select Procedure 1 and verify write off amount in adjustment tab, Verify balance in charge tab.
* 4.Click on Add procedure and verify amount, balance in charge tab and write off in adjustment tab.
* 5.Select Procedure1 from Primary Insurance dropdown, remove Insurance1 Select Insurance2 and verify write Off amount (No write off amount should display)
* 6.From Primary Insurance dropdown, remove Insurance2 Select Insurance3 and verify write Off amount ( write off amount should display)
* 7.On Hover of the Procedure1 and drag and drop the charge at procedure 2 row and verify write off amount in Adjustment tab
* 8.Select Procedure1 in 2nd row add modifier value and verify modifier is under Scheduled Procedures/Billable Supplies' > Performed items section  
* 9.Click on add Procedure(procedure 5) and verify amount in charge tab (should be empty).
* 10.On Hover of the Procedure5 and drag and drop the charge at procedure 1 row and verify write off amount in Adjustment tab (should display empty)
* 11.Click on add procedure search for procedure3 and verify amount and balance in charge tab (4000)
* 12.Update units 2 in procedure3 and verify amount and balance in charge tab (8000).
* 13.Click on done button and select patient1 from tracker and verify amount and balance for all procedure in charge tab.
* 14.Select ready for bill yes and click on done button and verify patient out off combined coding tracker.
* 15.Navigate to combined coding tracker and verify patient2, patient3.
* 16.Select patient2 and select the patient and document mandatory fields and set ready for bill yes and click on next case button.
* 17.Verify Patient 3 after clicking on next case button.
* 18.Navigate to combined coding tracker and verify patient2 out off combined coding tracker.
* 19.Logout from the application.
 */

describe(
  'To verify charges posted in combined coding Tracker',
  { tags: ['combined-coding', 'US#270583', 'TC#265704'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyChargesPosted();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
