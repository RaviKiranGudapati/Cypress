import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId268507 } from './scenarios/tcid-82281.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId268507();

/*****************Test Script Validation Details **********************
 * 1. User credentials should be available Gemini User1 with all the permissions and Mapped to FASC).
 *2. Ensure Application Settings>>Department>>Recovery settings>>Phase1/Phase2 as off, Phase3 as off.
 *3. Ensure Combined Coding/Charge Entry Feature Flag should be enabled .
 *4. Ensure Application Settings>>Fee Schedule>>Procedures Procedure 1 should be configured with Amount as 4000.
 *5. Ensure Patient 1, patient 3 should be scheduled on current date with procedure 1 and document Op notes 1, Op Notes2, Op Notes 3,
 *and add Implants 1, Implants 2, Implants 3 , Implants 4 , Implants 5 for Patient1 and Patient2.
 *6. Ensure Patient 2 should be scheduled on current date with procedure 1 and DO NOT document any Op notes.
 *7. Ensure Patient 1, patient2,Patient3, patient4 and Patient5 under Recovery should be discharged outside facility with status as performed.
 *8.Ensure Period 1 and Batch 1 should be available and mapped to Patient1.
 *9.Ensure Op notes 1, Op Notes2, Op Notes 3 should be available.
 *10.Ensure Implants 1, Implants 2, Implants3 , Implants 4, Implants 5 should be available.
 *11. Ensure Patient4 case is created on current date and is having OR worklist with implants Implant1, Implant2 with quantity (3, 4) and Implant 3 without quantity
 *12. Ensure from Application settings>Add a Preference card1 with cpt codes and implants (with Implant4, Implant5 with quantity (5, 6) and Implant6 without quantity)
 *13. Ensure Patient5 case is created on current date with Preference card1
 *14. Ensure Patient4, Patient5 cases are discharged from FASC to Outside Facility with Case Status as Performed
 */

describe(
  'Verify the done button charge, along with the toggle button behavior under Combined Coding tracker',
  { tags: ['combined-coding', 'US#268507', 'TC#82281'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyOpNotesAndImplants();
        combinedCoding.verifyImplantsInCombineCoding();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
