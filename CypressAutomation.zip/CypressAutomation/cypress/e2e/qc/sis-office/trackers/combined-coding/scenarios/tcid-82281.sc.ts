import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';

import { td_op_notes_implants_tcid_82281 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/opnotes-implants-tcid-82281.td';

import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import { MyTaskFaceSheet } from '../../../../../../app-modules-libs/sis-charts/facesheet/mytask-facesheet';

import { SisOfficeScdlGridPrintTcId49238 } from '../../../case/print/scenarios/tcid-49238.sc';

/* instance variables */
const sisOfficeScdlGrid = new SisOfficeScdlGridPrintTcId49238();
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const myTaskFaceSheet = new MyTaskFaceSheet();
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCodings = new CombinedCoding();
const transactions = new Transactions();
const nursingConfLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const createCase = new CreateCase();
const faceSheetCases = new FaceSheetCases();

/* const values */
const worklist268507 = 'Worklist268507';
const department = ['PHYSICIAN', 'OPERATIVE'];
const opNotes = 'Op Notes';
const adjustment = 'Adjustment';
const worklistItemName = 'Implants and Prosthesis';

export class CombinedCodingTcId268507 {
  verifyOpNotesAndImplants() {
    describe('Verify Op notes and implants in Combine Coding', () => {
      it('Verify Op notes and implants in Combine Coding', () => {
        // #region - Navigating to Nursing Desktop add OpNotes,add ImplantsSign get Sign

        cy.cGroupAsStep(
          'Navigating to Nursing Desktop add OpNotes,add ImplantsSign get Sign'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfLayout.typeConfiguration(department[1]);
        nursingConfLayout.clickOnExistingWorkList(worklist268507);
        nursingConfLayout.modifyWorkListItemList(worklistItemName);
        sisOfficeScdlGrid.selectNursingDesktop();
        sisChartsDesktop.closeNotificationIcon();
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_op_notes_implants_tcid_82281.PatientDetails[0]
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.pre_operative);
        myTaskFaceSheet.selectDepartmentInMytask(department[0]);
        myTaskFaceSheet.closePopup();
        myTaskFaceSheet.selectTaskPanelInDepartment(opNotes);
        myTaskFaceSheet.selectPhysicianInAddOpNotes(
          td_op_notes_implants_tcid_82281.PreferenceCard.Physician
        );
        myTaskFaceSheet.selectOpNotes(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[0]
        );
        myTaskFaceSheet.clickOnAddOpNotes();
        myTaskFaceSheet.selectPhysicianInAddOpNotes(
          td_op_notes_implants_tcid_82281.PreferenceCard.Physician
        );
        myTaskFaceSheet.selectOpNotes(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[1]
        );
        myTaskFaceSheet.clickOnAddOpNotes();
        myTaskFaceSheet.selectPhysicianInAddOpNotes(
          td_op_notes_implants_tcid_82281.PreferenceCard.Physician
        );
        myTaskFaceSheet.selectOpNotes(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[2]
        );
        myTaskFaceSheet.selectDepartmentInMytask(department[1]);
        chartsCoverFaceSheet.addOperativeWorklist(worklist268507);
        chartsCoverFaceSheet.clickImplantsQuestionStatus(YesOrNo.yes);
        chartsCoverFaceSheet.addImplantsInWorklist(
          td_op_notes_implants_tcid_82281.Implant
        );
        myTaskFaceSheet.signDepartment();
        // #endregion

        // #region - Navigating to Business Desktop verify added OpNotes Combine Coding

        cy.cGroupAsStep(
          'Navigating to Business Desktop verify added OpNotes Combine Coding'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCodings.selectPeriodAndBatch(
          td_op_notes_implants_tcid_82281.Charge
        );
        sisOfficeDesktop.selectPatientRow(
          td_op_notes_implants_tcid_82281.PatientDetails[0].LastName,
          td_op_notes_implants_tcid_82281.PatientDetails[0].PatientFirstName
        );
        combinedCodings.selectAllProcedureCheckbox();
        combinedCodings.addSelectedToPerformed();
        combinedCodings.verifyDocumentationHeader(
          td_op_notes_implants_tcid_82281.OpNotes.Header
        );
        combinedCodings.verifyOpNotes(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[0]
        );
        combinedCodings.verifyOpNotes(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[1]
        );
        combinedCodings.verifyOpNotes(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[2]
        );
        combinedCodings.verifyProgressionBar();
        combinedCodings.verifyOpNotesUnderProgressBar(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[0]
        );
        // #endregion

        // #region - Verify added Implants details Combine Coding

        cy.cGroupAsStep('Verify added Implants details Combine Coding');
        combinedCodings.verifyImplantLog(
          td_op_notes_implants_tcid_82281.ImplantDetails.ImplantLog
        );
        combinedCodings.clickOnImplantLog(
          td_op_notes_implants_tcid_82281.ImplantDetails.ImplantLog
        );
        combinedCodings.verifyImplantScrollBar();
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.ImplantProsthetic
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Manufacturer
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Type
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Size
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Lot
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Expiration
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Serial
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Reference
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.Notes
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.Implant[2].Implant
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.Implant[0].Manufacturer
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.Implant[1].Manufacturer
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.Implant[2].Manufacturer
        );
        combinedCodings.verifyImplantText(
          td_op_notes_implants_tcid_82281.ImplantDetails.TypeOfImplant
        );
        // #endregion

        // #region - Select Second Patient verify OpNotes Combine Coding

        cy.cGroupAsStep('Select Second Patient verify OpNotes Combine Coding');
        // patient 2
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCodings.selectPeriodAndBatch(
          td_op_notes_implants_tcid_82281.Charge
        );
        sisOfficeDesktop.selectPatientRow(
          td_op_notes_implants_tcid_82281.PatientDetails[1].LastName,
          td_op_notes_implants_tcid_82281.PatientDetails[1].PatientFirstName
        );
        combinedCodings.verifyOpNotesNotExist(
          td_op_notes_implants_tcid_82281.OpNotes.Op_notes[0]
        );
        combinedCodings.verifyImplantLog(
          td_op_notes_implants_tcid_82281.ImplantDetails.ImplantLog
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion

        // #region - Select First Patient verify Implants Amount,Balance and Units in Combine Coding

        cy.cGroupAsStep(
          'Select First Patient verify Implants Amount,Balance and Units in Combine Coding'
        );
        // patient 3
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCodings.selectPeriodAndBatch(
          td_op_notes_implants_tcid_82281.Charge
        );
        sisOfficeDesktop.selectPatientRow(
          td_op_notes_implants_tcid_82281.PatientDetails[0].LastName,
          td_op_notes_implants_tcid_82281.PatientDetails[0].PatientFirstName
        );
        combinedCodings.selectAllProcedureCheckbox();
        combinedCodings.addSelectedToPerformed();
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[0].Amount ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[0].Balance ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[0].Units ?? ''
        );
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[1].Units ?? ''
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[1].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[1].Amount ?? ''
        );
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[2].Implant
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[2].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[2].Amount ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[2].Units ?? ''
        );
        // #endregion

        // #region - Select Implants Modify Units verify Amount in Combine Coding

        cy.cGroupAsStep(
          'Select Implants Modify Units verify Amount in Combine Coding'
        );
        // implant 1
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.enterUnits(
          td_op_notes_implants_tcid_82281.Charges[4].Units ?? ''
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[4].Units ?? ''
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[4].Balance ?? ''
        );
        // #endregion

        // #region - Add writeoff and verify Balance in Combine Coding

        cy.cGroupAsStep(
          'Add writeoff and verify Balance and Units in Combine Coding'
        );
        combinedCodings.selectChargeAdjustmentButton(adjustment);
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_op_notes_implants_tcid_82281.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCodings.selectChargeAdjustmentButton('Charge');
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[8].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[4].Amount ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[4].Units ?? ''
        );
        // #endregion

        // #region - Select Implants Modify Units verify Amount in Combine Coding

        cy.cGroupAsStep(
          'Select Implants Modify Units verify Amount in Combine Coding'
        );
        // implant3
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[2].Implant
        );
        combinedCodings.enterUnits(
          td_op_notes_implants_tcid_82281.Charges[5].Units ?? ''
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[2].Implant
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[5].Units ?? ''
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[5].Balance ?? ''
        );
        // #endregion

        // #region - Add writeoff and verify Balance in Combine Coding

        cy.cGroupAsStep('Add writeoff and verify Balance in Combine Coding');
        combinedCodings.selectChargeAdjustmentButton('Adjustment');
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_op_notes_implants_tcid_82281.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCodings.selectChargeAdjustmentButton('Charge');
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[9].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[5].Amount ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[5].Units ?? ''
        );
        // #endregion

        // #region - Clear HCPCS code and verify Balance and Amount
        cy.cGroupAsStep('Clear HCPCS code and verify Balance and Amount');
        // implant2
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.deleteHCPCS();
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[6].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[6].Amount ?? ''
        );
        // #endregion

        // #region - Enter back HCPCS code and verify Balance and Amount
        cy.cGroupAsStep('Enter back HCPCS code and verify Balance and Amount');
        // implant2
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.deleteHCPCS();
        combinedCodings.enterHCPCScode(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[7].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[7].Amount ?? ''
        );
        // #endregion
      });
    });
  }

  verifyImplantsInCombineCoding() {
    describe('Verify Implants which is added from Preference Card in Combine Coding', () => {
      it('Verify Implants which is added from Preference Card in Combine Coding', () => {
        // #region - Add Preference card in Application Settings with Implants

        cy.cGroupAsStep(
          'Add Preference card in Application Settings with Implants'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CONFIGURATION[0]
        );
        nursingConfiguration.clickOnAdd();
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0],
          td_op_notes_implants_tcid_82281.PreferenceCard
            .AvailablePreferenceCards[0]
        );
        nursingConfiguration.selectPhysicianInPreferenceCard(
          td_op_notes_implants_tcid_82281.Charges[12].Physician ?? ''
        );
        nursingConfiguration.addImplants(
          td_op_notes_implants_tcid_82281.ImplantData[0]
        );

        nursingConfiguration.addImplants(
          td_op_notes_implants_tcid_82281.ImplantData[1]
        );

        nursingConfiguration.addImplants(
          td_op_notes_implants_tcid_82281.ImplantData[2]
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        // #endregion

        // #region - Navigate to Business desktop Case Details,add preference card And Update

        cy.cGroupAsStep(
          'Navigate to Business desktop Case Details,add preference card And Update'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_op_notes_implants_tcid_82281.PatientDetails[2]
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);
        createCase.selectPreferenceCard(
          td_op_notes_implants_tcid_82281.PreferenceCard
        );
        transactions.clickUpdateButton();
        // #endregion

        // #region - Navigate to Nursing Desktop Sign Operative Department navigate back to Business Desktop

        cy.cGroupAsStep(
          'Navigate to Nursing Desktop Sign Operative Department navigate back to Business Desktop '
        );
        sisOfficeScdlGrid.selectNursingDesktop();
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_op_notes_implants_tcid_82281.PatientDetails[2]
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        myTaskFaceSheet.signDepartment();
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion

        // #region - Select patient and perform all charges in Combine Coding

        cy.cGroupAsStep(
          'Select patient and perform all charges in Combine Coding'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCodings.selectPeriodAndBatch(
          td_op_notes_implants_tcid_82281.Charge
        );
        sisOfficeDesktop.selectPatientRow(
          td_op_notes_implants_tcid_82281.PatientDetails[2].LastName,
          td_op_notes_implants_tcid_82281.PatientDetails[2].PatientFirstName
        );
        combinedCodings.selectAllProcedureCheckbox();
        combinedCodings.addSelectedToPerformed();
        // #endregion

        // #region - Select First Patient verify Implants Amount,Balance and Units in Combine Coding

        cy.cGroupAsStep(
          'Select First Patient verify Implants Amount,Balance and Units in Combine Coding'
        );
        // patient 3
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[10].Amount ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[10].Balance ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[10].Units ?? ''
        );
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[11].Units ?? ''
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[11].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[11].Amount ?? ''
        );
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[2].Implant
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[2].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[2].Amount ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[2].Units ?? ''
        );
        // #endregion

        // #region - Select Implants Modify Units verify Amount in Combine Coding

        cy.cGroupAsStep(
          'Select Implants Modify Units verify Amount in Combine Coding'
        );
        // implant 1
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.enterUnits(
          td_op_notes_implants_tcid_82281.Charges[4].Units ?? ''
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[4].Units ?? ''
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[4].Balance ?? ''
        );
        // #endregion

        // #region - Add writeoff and verify Balance in Combine Coding

        cy.cGroupAsStep(
          'Add writeoff and verify Balance and Units in Combine Coding'
        );
        combinedCodings.selectChargeAdjustmentButton('Adjustment');
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_op_notes_implants_tcid_82281.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCodings.selectChargeAdjustmentButton('Charge');
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[8].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[4].Amount ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[4].Units ?? ''
        );
        // #endregion

        // #region - Select Implants Modify Units verify Amount in Combine Coding

        cy.cGroupAsStep(
          'Select Implants Modify Units verify Amount in Combine Coding'
        );
        // implant3
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[2].Implant
        );
        combinedCodings.enterUnits(
          td_op_notes_implants_tcid_82281.Charges[5].Units ?? ''
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[2].Implant
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[5].Units ?? ''
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[5].Balance ?? ''
        );
        // #endregion

        // #region - Add writeoff and verify Balance in Combine Coding

        cy.cGroupAsStep('Add writeoff and verify Balance in Combine Coding');
        combinedCodings.selectChargeAdjustmentButton('Adjustment');
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_op_notes_implants_tcid_82281.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCodings.selectChargeAdjustmentButton('Charge');
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[9].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[5].Amount ?? ''
        );
        combinedCodings.verifyUnits(
          td_op_notes_implants_tcid_82281.Charges[5].Units ?? ''
        );
        // #endregion

        // #region - Clear HCPCS code and verify Balance and Amount

        cy.cGroupAsStep('Clear HCPCS code and verify Balance and Amount');
        // implant2
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.deleteHCPCS();
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[6].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[6].Amount ?? ''
        );
        // #endregion

        // #region - Enter back HCPCS code and verify Balance and Amount

        cy.cGroupAsStep('Enter back HCPCS code and verify Balance and Amount');
        // implant2
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[0].Implant
        );
        combinedCodings.clickOnPerformedItems(3);
        combinedCodings.verifyAndSelectProcedure(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.deleteHCPCS();
        combinedCodings.enterHCPCScode(
          td_op_notes_implants_tcid_82281.Implant[1].Implant
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_op_notes_implants_tcid_82281.Charges[7].Balance ?? ''
        );
        combinedCodings.verifyAmount(
          td_op_notes_implants_tcid_82281.Charges[7].Amount ?? ''
        );
        // #endregion
      });
    });
  }
}
