import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_combined_coding_207479 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/balance-calculation-tcid-207479.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import RecoveryDepartment from '../../../../../../app-modules-libs/sis-charts/departments/recovery/recovery';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const combinedCoding = new CombinedCoding();
const recoveryDepartment = new RecoveryDepartment(
  td_combined_coding_207479.RecoveryInfo
);
const createCase1 = new CreateCase(td_combined_coding_207479.PatientCase[0]);

/* const values */
const worklist207479 = 'Worklist207479';

export class CombinedCodingTcId207479 {
  verifyBalanceCalculation() {
    describe('To verify the balance amount for the supplies implants after adding write-off and procedures mapped with contracts', () => {
      it('Verifying balance amount for supplies implants and procedures mapped with contracts', () => {
        // #region - Navigating to the nursing desktop and adding supplies for patient 1

        cy.cGroupAsStep(
          'Navigating to the nursing desktop and adding supplies for patient 1'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase1.patientCaseModel!.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        chartsCoverFaceSheet.addOperativeWorklist(worklist207479);
        chartsCoverFaceSheet.clickSuppliesQuestionStatus(YesOrNo.yes);
        chartsCoverFaceSheet.addSuppliesInWorklist(
          td_combined_coding_207479.WorklistSuppliesInstruments
        );
        chartsCoverFaceSheet.addSuppliesInWorklist(
          td_combined_coding_207479.WorklistSuppliesInstruments
        );

        // #endregion

        // #region - Adding implants for Patient 1

        cy.cGroupAsStep('Adding implants for Patient 1');
        chartsCoverFaceSheet.clickImplantsQuestionStatus(YesOrNo.yes);
        chartsCoverFaceSheet.addImplantsInWorklist(
          td_combined_coding_207479.Implant
        );
        chartsCoverFaceSheet.addFreeTextImplant(
          td_combined_coding_207479.Implant
        );

        // #endregion

        // #region - Discharge patient 1 and navigate to business desktop

        cy.cGroupAsStep('Discharge patient 1 and navigate to business desktop');
        sisOfficeDesktop.selectSisLogo();
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase1.patientCaseModel!.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.recovery);
        recoveryDepartment.dischargePatientInOutsideFacility();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        // #endregion

        // #region - Navigate to combined coding then verify balance and write-off amounts for implant

        cy.cGroupAsStep(
          'Navigate to combined coding then verify balance and write-off amounts for implant'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_207479.Charges[0],
          td_combined_coding_207479.PatientCase[0]
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[0].CPT
        );
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_207479.Charges[0].Amount!
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_combined_coding_207479.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.verifyBalance(
          td_combined_coding_207479.Charges[0].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_207479.Charges[0].Amount!
        );

        // #endregion

        // #region - Verify balance amount as per contract for cpt procedure

        cy.cGroupAsStep(
          'Verify balance amount as per contract for cpt procedure'
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[1].CPT
        );
        combinedCoding.assertChargeDetail();

        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
          td_combined_coding_207479.Charges[1].Discounts!
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.verifyBalance(
          td_combined_coding_207479.Charges[1].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_207479.Charges[1].Amount!
        );
        combinedCoding.updateUnits(td_combined_coding_207479.Charges[2].Units!);
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.verifyBalance(
          td_combined_coding_207479.Charges[2].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_207479.Charges[2].Amount!
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.updateUnits(td_combined_coding_207479.Charges[1].Units!);
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.verifyBalance(
          td_combined_coding_207479.Charges[1].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_207479.Charges[1].Amount!
        );

        // #endregion
      });
    });
  }

  verifyWriteOff() {
    describe('To verify the balance amount and write-off amount for procedures mapped with contracts', () => {
      it('Verifying balance amount and write-off amount for procedures mapped with contracts', () => {
        // #region - Navigate to combined coding and verify balance amount and write-off amount for procedure 1

        cy.cGroupAsStep(
          'Navigate to combined coding and verify balance amount and write-off amount for procedure 1'
        );
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_207479.Charges[0],
          td_combined_coding_207479.PatientCase[1]
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[1].CPT
        );
        combinedCoding.assertChargeDetail();
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_207479.Charges[1].Amount!
        );
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
          td_combined_coding_207479.Charges[1].Discounts!
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.verifyBalance(
          td_combined_coding_207479.Charges[1].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_207479.Charges[1].Amount!
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_combined_coding_207479.Adjustment.WriteoffAmount[1]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();

        // #endregion

        // #region - Verifying balance amount and write-off amount for procedure 2

        cy.cGroupAsStep(
          'Verifying balance amount and write-off amount for procedure 2'
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[3].CPT
        );
        combinedCoding.assertChargeDetail();
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_207479.Charges[3].Amount!
        );
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
          td_combined_coding_207479.Charges[3].Discounts!
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.verifyBalance(
          td_combined_coding_207479.Charges[3].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_207479.Charges[3].Amount!
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_combined_coding_207479.Adjustment.WriteoffAmount[2]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();

        // #endregion

        // #region - Verifying balance amount and write-off amount for procedure 3

        cy.cGroupAsStep(
          'Verifying balance amount and write-off amount for procedure 3'
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[4].CPT
        );
        combinedCoding.assertChargeDetail();
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_207479.Charges[4].Amount!
        );
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
          td_combined_coding_207479.Charges[4].Discounts!
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();
        combinedCoding.verifyBalance(
          td_combined_coding_207479.Charges[4].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_207479.Charges[4].Amount!
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_combined_coding_207479.Adjustment.WriteoffAmount[1]
        );
        combinedCoding.dragAndDropCharges(
          td_combined_coding_207479.Charges[1].CPT,
          td_combined_coding_207479.Charges[4].CPT
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.assertChargeDetail();

        // #endregion
      });
    });
  }

  verifyNDCNumber() {
    describe('To verify the NDC number for ios supplies', () => {
      it('Verifying the NDC number for ios supplies', () => {
        // #region - Selecting patient 3 and adding medication with NDC number

        cy.cGroupAsStep(
          'Selecting patient 3 and adding medication with NDC number'
        );
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_207479.Charges[0],
          td_combined_coding_207479.PatientCase[2]
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[1].CPT
        );
        combinedCoding.clickAddSuppliesButton();
        combinedCoding.selectSupplies(
          td_combined_coding_207479.Charges[5].CPT,
          td_combined_coding_207479.Charges[5].CPT
        );
        combinedCoding.verifyNDCAmount(
          td_combined_coding_207479.Charges[5].NDC!
        );

        // #endregion

        // #region - Add medication without NDC number and verify data after clicking on Done button

        cy.cGroupAsStep(
          'Add medication without NDC number and verify data after clicking on Done button'
        );
        combinedCoding.clickAddSuppliesButton();
        combinedCoding.selectSupplies(
          td_combined_coding_207479.Charges[6].CPT,
          td_combined_coding_207479.Charges[6].CPT
        );
        combinedCoding.verifyNDCAmount(
          td_combined_coding_207479.Charges[6].NDC!
        );
        combinedCoding.selectDiagnosisCode(
          td_combined_coding_207479.Charges[0]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[2].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[3].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[4].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[5].CPT
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[6].CPT
        );
        combinedCoding.clickReadyForBillAndDoneButton();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_207479.Charges[0],
          td_combined_coding_207479.PatientCase[2]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[5].CPT
        );
        combinedCoding.verifyNDCAmount(
          td_combined_coding_207479.Charges[5].NDC!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_207479.Charges[6].CPT
        );
        combinedCoding.verifyNDCAmount(
          td_combined_coding_207479.Charges[6].NDC!
        );

        // #endregion
      });
    });
  }
}
