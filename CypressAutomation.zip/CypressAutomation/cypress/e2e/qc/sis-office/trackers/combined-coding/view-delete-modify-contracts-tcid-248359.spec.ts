import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId248359 } from './scenarios/tcid-248359.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId248359();

/*************** Test Script Validation Details **************
 * Script Execution Details -
 * Verifying base layout and insurances in combined coding tracker
 * Workflow:
 * TCID#264177 - Verify Combined coding Details Base Layout and checking insurances
 * Script Execution Approach -
 * 1. Verify the warning messages for Period and Batch selection
 * 2. Verify base layout UI elements for column headers, insurance dropdowns, toggle buttons
 * 3. Verify that insurance gets updated as per the selection
 * 4. Verify that user without modify access for financial management is not able to edit any charges
 */

describe(
  'Verifying the base layout and insurances update in combined coding tracker',
  { tags: ['trackers', 'combined-coding', 'US#268499', 'TC#248359'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyContractChargeAdminUser();
        combinedCoding.verifyContractChargeSisAdmin();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
