import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  Application,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_additional_claim_info_tcid_264191 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/additional-claim-info-tcid-264191.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const createCase = new CreateCase(
  td_additional_claim_info_tcid_264191.PatientCase
);
const facesheetCases = new FaceSheetCases();
const combinedCoding = new CombinedCoding();

export class CombinedCodingTcId264191 {
  verifyAdditionalClaimInfo() {
    describe('To verify additional claim information data in the UB and HCFA tabs', () => {
      it('Verifying the additional claim information data is saved correctly in UB and HCFA tabs ', () => {
        //#region - To add the additional claim information in Billing Details section.

        cy.cGroupAsStep(
          'To set the additional claim information data in Billing Details'
        );

        sisOfficeDesktop.pickPatient(
          td_additional_claim_info_tcid_264191.PatientCase.PatientDetails
        );

        /* Click on Payer Details under facesheet options */
        facesheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );

        /* Click on Worker Compensation Toggle Yes button */
        createCase.selectWorkerCompensation(YesOrNo.yes);

        /** Select the values in Addition Claim Information Details */
        createCase.selectAdditionalClaimInformation(
          td_additional_claim_info_tcid_264191.AdditionalClaimInfo
        );

        /** Click on the Update button */
        transactions.clickUpdateButton();

        /** Click on the SIS logo */
        sisOfficeDesktop.selectSisLogo();

        // #endregion

        //#region - To verify the additional claim details once after enter the data in UB tab

        cy.cGroupAsStep(
          'To add and verify the additional claim data under UB tab'
        );

        /** Click on the Combined/Coding Charge Entry tracker */
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );

        /** Select the period, batch and case selection  */
        cy.cRemoveMaskWrapper(Application.office);

        combinedCoding.selectCase(
          td_additional_claim_info_tcid_264191.CombinedCoding,
          createCase.patientCaseModel!
        );

        combinedCoding.verifyAndSelectProcedure(
          td_additional_claim_info_tcid_264191.CombinedCodingCharges.CPT
        );

        /** To verify and click the additional Claim Information button */
        combinedCoding.verifyAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );

        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );

        /** To verify the All the labels in UB tab under Additional Claim Information Popup */
        combinedCoding.verifyUbAdditionalClaimHeaders(
          td_additional_claim_info_tcid_264191.UBAdditionalClaim[0]
            .UBInstitutional!
        );

        combinedCoding.verifyUbAdditionalClaimLabels(
          td_additional_claim_info_tcid_264191.UBAdditionalClaim[1]
            .UBInstitutional!
        );

        /** Enter the Data in Conditional Code and Verifying the data */
        combinedCoding.enterDataInUbFields(
          td_additional_claim_info_tcid_264191.UBAdditionalClaim[0]
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_additional_claim_info_tcid_264191.UBAdditionalClaim[0]
        );
        combinedCoding.enterDataInUbFields(
          td_additional_claim_info_tcid_264191.UBAdditionalClaim[1]
        );

        /** Click on Done button in Additional Claim Information Popup */
        combinedCoding.selectAdditionalClaimInfoDone();
        combinedCoding.verifyAdditionClaimInformationPopup(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );

        // #endregion

        //#region - To verify the additional claim details once after enter the data in HCFA tab

        cy.cGroupAsStep(
          'To add/edit and verify the data & fields name under HCFA tab in additional claim information popup'
        );

        /** Click on Additional Claim Information button and Select the HCFA Tab */
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.verifyHcfaProfessionalLabels(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
            .HCFAProfessional
        );
        combinedCoding.enterDataInHcfaFields(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );
        combinedCoding.addHcfaAdditionalClaimCodes(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );
        combinedCoding.verifyConditionCodesHCFA(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0],
          0
        );
        combinedCoding.addHcfaAdditionalClaimCodes(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[1]
        );
        combinedCoding.verifyConditionCodesHCFA(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[1],
          0
        );
        combinedCoding.addHcfaAdditionalClaimSupplementalInfo(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );
        combinedCoding.verifyClaimSupplementalInfo(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );
        combinedCoding.addHcfaAdditionalClaimNotesInfo(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );
        combinedCoding.verifyClaimNoteInfo(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );

        combinedCoding.verifyHcfaDateFields();
        // #endregion

        //#region - To verify the additional claim details once after enter the data in HCFA tab

        cy.cGroupAsStep(
          'To edit and delete the claim data and verify the data under HCFA tab in Additional Claim Information popup'
        );

        combinedCoding.clickConditionCodeTrashIconInHcfa(0);

        combinedCoding.editConditionalCodeInHcfa(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.CONDITIONAL_CODES[0],
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0].Code!.toString(),
          0
        );
        combinedCoding.verifyHcfaAdditionalClaimData(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );
        combinedCoding.selectAdditionalClaimInfoDone();
        combinedCoding.verifyAdditionClaimInformationPopup(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.clickOnDoneButton();

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        cy.cRemoveMaskWrapper(Application.office);

        /** Select the period, batch and case selection  */
        combinedCoding.selectCase(
          td_additional_claim_info_tcid_264191.CombinedCoding,
          createCase.patientCaseModel!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_additional_claim_info_tcid_264191.CombinedCodingCharges.CPT
        );

        /** To verify and click the additional Claim Information button */
        combinedCoding.verifyAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.verifyHcfaAdditionalClaimData(
          td_additional_claim_info_tcid_264191.HCFAAdditionalClaim[0]
        );
        combinedCoding.selectAdditionalClaimInfoDone();

        //#endregion
      });
    });
  }
}
