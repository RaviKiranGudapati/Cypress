import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import { ShouldMethods } from '../../../../../support/common-core-libs/application/common-core';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();

enum EnumLocators260017 {
  sunday_l_date = '.p-datepicker-calendar tbody tr:nth-child(2) td:nth-child(1) span',
  saturday_l_date = '.p-datepicker-calendar :nth-child(2) > :nth-child(7) span',
  disabled = 'p-disabled',
}

enum EnumMonthYear {
  Month = 'month',
  Year = 'year',
}

export class ScheduleGridCalenderTcid260017 {
  verifyCalenderUI() {
    describe('Verify the month and year,today date and today button in Calendar Date picker', () => {
      it('Verify month and year,today date and today button is highlighted in schedule grid calender', () => {
        // #region - Verify the presence of calendar in schedule grid page
        cy.cGroupAsStep(
          'Verify the presence of calendar in schedule grid page'
        );

        /**Verify Presence of schedule grid calender*/
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.verifyCalendar();
        // #endregion

        // #region - Click on calendar in schedule grid page
        cy.cGroupAsStep('Click on calendar in schedule grid page');
        /**click schedule grid calender*/
        sisOfficeDesktop.clickCalendar();
        // #endregion

        // #region - Verify Month and Year displayed in calendar
        cy.cGroupAsStep('Verify Month and Year displayed in calendar');
        sisOfficeDesktop.verifyMonthAndYearVisible(
          EnumMonthYear.Month,
          CommonUtils.getCurrentMonthName()
        );
        sisOfficeDesktop.verifyMonthAndYearVisible(
          EnumMonthYear.Year,
          CommonUtils.getCurrentYear()
        );
        // #endregion

        // #region - Verify Today date is highlighted in calendar
        cy.cGroupAsStep('Verify Today date is highlighted in calendar');
        /**verify today date is highlighted in schedule grid calender*/
        sisOfficeDesktop.verifyCurrentDateHighlighted();
        // #endregion

        // #region - Verify the presence of today button in schedule grid page
        cy.cGroupAsStep(
          'Verify the presence of today button in schedule grid page'
        );
        /**verify today button in schedule grid calender*/
        sisOfficeDesktop.verifyTodayButtonVisible();
        // #endregion
      });
    });
  }

  verifyCalenderFunctionality() {
    describe('verify the month and year in schedule grid calender for previous and next month and other months date should be in light gray color and select different dates', () => {
      it('verify the month and year in schedule grid calender for previous and next month and other months date should be in light gray color and select different dates', () => {
        cy.cGroupAsStep('click previous button in calendar');
        /**click prev button and verify the month in calender*/
        // #region click prev button and verify the month in calender
        sisOfficeDesktop.clickPreviousBtn();

        cy.cGroupAsStep(
          'Verify previous month has been displayed in top of calendar'
        );
        sisOfficeDesktop.verifyMonthAndYearVisible(
          EnumMonthYear.Month,
          CommonUtils.getPreviousMonthName()
        );
        // #endregion

        cy.cGroupAsStep('Verify next button in calendar');
        // #region click next button and verify the month and year in calender
        sisOfficeDesktop.clickNextBtn();

        cy.cGroupAsStep(
          'Verify current month and year is displayed in calendar'
        );
        sisOfficeDesktop.verifyMonthAndYearVisible(
          EnumMonthYear.Month,
          CommonUtils.getCurrentMonthName()
        );
        sisOfficeDesktop.verifyMonthAndYearVisible(
          EnumMonthYear.Year,
          CommonUtils.getCurrentYear()
        );
        // #endregion

        cy.cGroupAsStep('Verify future dates are disabled in calendar');
        // #region other months date should be in light gray color in schedule grid calender
        sisOfficeDesktop.verifyDisabledDatesColor();
        // #endregion

        cy.cGroupAsStep(
          'Verify user is able to select different date in calendar'
        );
        // #region select dates in schedule grid calender
        sisOfficeDesktop.clickNextBtn();
        sisOfficeDesktop.selectDate(14);
        sisOfficeDesktop.clickCalendar();
        sisOfficeDesktop.selectDate(19);
        // #endregion
      });
    });
  }
  
  // Unselect the working days in the Schedule (Sunday, Saturday), User should able to see unselected working days are disabled on the calendar icon.
  verifyUnselectedWorkingDays() {
    describe('Verify the calendar functionality when Saturday and Sunday is unselected from working list in schedule', () => {
      it('Unselect Saturday and Sunday from working day list in schedule and Verify Saturday and Sunday is disabled in the schedule grid calender then reselect Saturday and Sunday from schedule', () => {
        cy.cGroupAsStep('Navigate to application settings');
        // #region Unselect the working days in the Schedule (Sunday, Saturday)
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        cy.cGroupAsStep('Select Schedule from configuration');
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.SCHEDULE.SCHEDULE[0]
        );

        cy.cGroupAsStep(
          'Unselect the working days in the Schedule (Sunday, Saturday)'
        );
        nursingConfiguration.scheduleClickWorkingDays(
          OR_NURSING_CONFIGURATION.SCHEDULE.WORKING_DAYS.SUNDAY[0],
          false
        );
        nursingConfiguration.scheduleClickWorkingDays(
          OR_NURSING_CONFIGURATION.SCHEDULE.WORKING_DAYS.SATURDAY[0],
          false
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.SCHEDULE.SCHEDULE[0]
        );
        cy.cGroupAsStep('Click on SIS Logo');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        cy.cGroupAsStep(
          'Click Calendar and verify Saturday and Sunday is disabled'
        );
        // #region Verify Saturday, Sunday dates are disabled
        sisOfficeDesktop.clickCalendar();
        cy.cGet(EnumLocators260017.sunday_l_date).should(
          ShouldMethods.class,
          EnumLocators260017.disabled
        );

        cy.cGet(EnumLocators260017.saturday_l_date).should(
          ShouldMethods.class,
          EnumLocators260017.disabled
        );
        // #endregion

        // #region Reselect Sunday, Saturday as working days in the Schedule,
        cy.cGroupAsStep('Navigate to application settings');
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        cy.cGroupAsStep('Select Schedule from configuration');
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.SCHEDULE.SCHEDULE[0]
        );

        cy.cGroupAsStep(
          'Select the working days in the Schedule (Sunday, Saturday)'
        );
        nursingConfiguration.scheduleClickWorkingDays(
          OR_NURSING_CONFIGURATION.SCHEDULE.WORKING_DAYS.SUNDAY[0],
          true
        );

        nursingConfiguration.scheduleClickWorkingDays(
          OR_NURSING_CONFIGURATION.SCHEDULE.WORKING_DAYS.SATURDAY[0],
          true
        );

        cy.cGroupAsStep('Click on SIS Logo');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        // #endregion
      });
    });
  }
}
