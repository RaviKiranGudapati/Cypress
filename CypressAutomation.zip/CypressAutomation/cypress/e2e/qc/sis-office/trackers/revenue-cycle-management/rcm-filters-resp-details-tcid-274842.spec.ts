import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { RcmTcId274842 } from './scenarios/tcid-274842.sc';

/* instance variables */
const rcm = new RcmTcId274842();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation, insurance ,RCM Status, Insurance Plan Types, charges
 * 1. Login to application with SIS Admin
 * 2. Navigate to RCM Tracker and Verify List items displayed under Aging Type filter dropdown
 * 3. Verify that List items displayed under Aging Category  filter dropdown
 * 4. Verify that List items displayed under Appointment Type  filter dropdown
 * 5. Verify that List items displayed under Physician  filter dropdown
 * 6. Verify that Insurance plan types which exists in the application should be displayed at Insurance plan type filter dropdown
 * 7. Verify that List items displayed under Payer Role filter dropdown
 * 8. Verify that Responsibility Party Contact Information
 * */

describe(
  'Verify new filters dropdown items and check new fields to the Responsible Party box on the Detail page in RCM tracker',
  {
    tags: ['rcm', 'TC#274842', 'US#106826'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        rcm.verifyColumnsFiltersInRCMTracker();
        rcm.verifyResponsiblePartyFieldValues();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
