import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { RcmTcId274841 } from './scenarios/tcid-274841.sc';

/* instance variables */
const rcm = new RcmTcId274841();
const sisOfficeDesktop = new SISOfficeDesktop();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation, insurance ,RCM Status, Insurance Plan Types, charges
 * 1. Login to application
 * 2. Navigate to RCM Tracker and Verify Show Defaults and Hide Defaults along with Expansion and Collapse symbol
 * 3. Verify default filters in RCM Tracker when Show Defaults option there
 * 4. Verify Remaining filters in RCM Tracker when Show Defaults option is Expanded
 * 5. Verify newly added filters along with Follow-Up Date, Patient Last Name (from, To Text boxes), MRN
 * 6. Verify newly added columns to RCM Tracker
 * 7. Verify bottom, Pagination section is displayed which is similar to Balance/Reconciliation tracker
 * 8. Verify Refresh, Clear all Filters buttons should be displayed at top right corner next to Follow update field
 * */

describe(
  'Verify Column Names, Filters, Text boxes, Refresh and Clear buttons in RCM tracker',
  {
    tags: ['rcm', 'TC#274841', 'US#106826'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisOfficeDesktop.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        rcm.verifyFiltersShowHideDefaultsInRCMTracker();
        rcm.verifyPaginationTextSearchInRCMTracker();
        rcm.verifyPaginationInRCMTracker();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
