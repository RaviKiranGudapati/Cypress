import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import {
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_inv_rec_tcid_270008 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/inv-rec-tcid-270008.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { FreeText } from '../../../../../../app-modules-libs/shared/application-settings/enums/nursing-configuration.enum';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import CasesToCode from '../../../../../../app-modules-libs/sis-office/trackers/cases-to-code';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import { LabelHeaders } from '../../../../../../app-modules-libs/sis-office/trackers/enums/inv-reconciliation.enum';

/* instance variables */
const createCase = new CreateCase(td_inv_rec_tcid_270008.PatientCase);
const inventoryReconciliation = new InventoryReconciliation(
  createCase.patientCaseModel?.PatientDetails!
);
const casesToCode = new CasesToCode(createCase.patientCaseModel!);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const sisChartsDesktop = new SISChartsDesktop();
const combinedCoding = new CombinedCoding();
const transactions = new Transactions();

export class InvRecFreeTextToIosItemTcId270008 {
  addFreeTextItemPreferenceCard() {
    describe('Add Free Text Implant and Free Text Supply for the Preference Card', () => {
      it('Add Free Text Implant and Free Text Supply for the Preference Card', () => {
        /*****************Test Begins***************/
        // #region - Navigate to Application Settings

        cy.cGroupAsStep('Navigate to Application Settings');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        // #endregion

        // #region - Search and Select Preference Card in Preference Card Configuration in Application Settings

        cy.cGroupAsStep(
          'Search and Select Preference Card in Preference Card Configuration in Application Settings'
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CONFIGURATION[0]
        );
        nursingConfiguration.searchAndSelectPreferenceCard(
          td_inv_rec_tcid_270008.PreferenceCards
        );
        // #endregion

        // #region - Add Free Text Implant in Preference Card

        cy.cGroupAsStep('Add Free Text Implant in Preference Card');

        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Add Free Text Supply in Preference Card

        cy.cGroupAsStep('Add Free Text Supply in Preference Card');

        nursingConfiguration.addSuppliesInPreferenceCard(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0],
          FreeText.free_text_item
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyFreeTextItemInOperative() {
    describe('Verify Implants and Supplies imported from preference card is displaying in Operative Department', () => {
      it('Verify Implants and Supplies imported from preference card is displaying in Operative Department', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Verify Implant Details in Worklist Tab in Operative Department

        cy.cGroupAsStep(
          'Verify Implant Details in Worklist Tab in Operative Department'
        );

        chartsCoverFaceSheet.verifyImplantInOperative(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0]
        );
        // #endregion

        // #region - Verify Supply Details in Worklist Tab in Operative Department

        cy.cGroupAsStep(
          'Verify Supply Details in Worklist Tab in Operative Department'
        );

        chartsCoverFaceSheet.verifySupplyInfo(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0]
        );
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        // #endregion

        // #region - Sign Operative Department

        cy.cGroupAsStep('Sign Operative Department');

        chartsCoverFaceSheet.signDepartment();
        // #endregion

        // #region - Click on Patient Face sheet Icon

        cy.cGroupAsStep('Click on Patient Face sheet Icon');

        chartsCoverFaceSheet.clickFaceSheetIcon();
        // #endregion

        // #region - Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0],
          YesOrNo.yes
        );
        // #endregion

        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );       
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInInventory() {
    describe('Verify Implants and Supplies imported from preference card is displaying in Inventory Reconciliation Tracker', () => {
      it('Verify Implants and Supplies imported from preference card is displaying in Inventory Reconciliation Tracker', () => {
        // #region - Navigate to Inventory Reconciliation tracker

        cy.cGroupAsStep('Navigate to Inventory Reconciliation tracker');
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .CASE_REQUESTS[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        // #endregion

        // #region - Verify Free Text Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Verify Free Text Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker'
        );

        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270008.PatientCase.PatientDetails.PatientFullName
        );
        inventoryReconciliation.verifyDepletionWarningMessage(
          td_inv_rec_tcid_270008.PatientCase.PatientDetails.LastName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0]
        );
        // #endregion

        // #region - Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Select Patient Case in Inventory Reconciliation Tracker'
        );

        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0]
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker'
        );
        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        // #endregion
      });
    });
  }

  updateFreeTextItemToIosInventoryItem() {
    describe('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Reconciliation Tracker', () => {
      it('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Reconciliation Tracker', () => {
        // #region - Update Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0]
        );
        // #endregion

        // #region - Update Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Depleting the Patient Case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Depleting the Patient Case in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.yes);
        // #endregion
      });
    });
  }

  updateExistingAndAddNewFreeTextItemInOperative() {
    describe('Update Used Quantity for Existing Free Text Implant and Supply and Add New Free Text Implant and Supply in Operative Department', () => {
      it('Update Used Quantity for Existing Free Text Implant and Supply and Add New Free Text Implant and Supply in Operative Department', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Un Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Un Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_UNSIGN[0],
          YesOrNo.yes
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - UnSign Operative Department for Patient Case

        cy.cGroupAsStep('UnSign Operative Department for Patient Case');

        chartsCoverFaceSheet.unSignDepartment(YesOrNo.yes);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[0].Implant
        );
        // #endregion

        // #region - Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Update Used Quantity for the Implant in Worklist Tab in Operative Department

        cy.cGroupAsStep(
          'Update Used Quantity for the Implant in Worklist Tab in Operative Department'
        );

        chartsCoverFaceSheet.selectImplant(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[0].Implant
        );
        chartsCoverFaceSheet.updateImplantUsedQuantity(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[0].Used
        );
        nursingConfiguration.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Verify Implant Details in Worklist Tab in Operative Department

        cy.cGroupAsStep(
          'Verify Implant Details in Worklist Tab in Operative Department'
        );

        chartsCoverFaceSheet.verifyImplantInOperative(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[0]
        );
        // #endregion

        // #region - Add Free Text Implant in Worklist In Operative Department

        cy.cGroupAsStep(
          'Add Free Text Implant in Worklist In Operative Department'
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Update Used Quantity for the Supply in Worklist Tab in Operative Department

        cy.cGroupAsStep(
          'Update Used Quantity for the Supply in Worklist Tab in Operative Department'
        );

        chartsCoverFaceSheet.selectSupply(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[0].SupplyName
        );
        chartsCoverFaceSheet.updateSupplyUsedQuantity(
          0,
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[0]
            .SisChartsSupply.Used
        );
        // #endregion

        // #region - Verify Supply Details in Worklist Tab in Operative Department

        cy.cGroupAsStep(
          'Verify Supply Details in Worklist Tab in Operative Department'
        );

        chartsCoverFaceSheet.verifySupplyInfo(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[0]
        );
        // #endregion

        // #region - Add Free Text Supply in Worklist In Operative Department

        cy.cGroupAsStep(
          'Add Free Text Supply in Worklist In Operative Department'
        );

        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        // #endregion

        // #region - Sign Operative Department

        cy.cGroupAsStep('Sign Operative Department');

        chartsCoverFaceSheet.signDepartment();
        // #endregion

        // #region - Click on Patient Face sheet Icon

        cy.cGroupAsStep('Click on Patient Face sheet Icon');

        chartsCoverFaceSheet.clickFaceSheetIcon();
        // #endregion

        // #region - Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0],
          YesOrNo.yes
        );
        // #endregion

        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyUpdatedImplantSuppliesInInventory() {
    describe('Verify Updated Implant and Supply with New Implant and Supply imported from SIS Charts', () => {
      it('Verify Updated Implant and Supply with New Implant and Supply imported from SIS Charts', () => {
        // #region - Navigate to Inventory Reconciliation tracker

        cy.cGroupAsStep('Navigate to Inventory Reconciliation tracker');
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .CASE_REQUESTS[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        // #endregion

        // #region - Verify Triangle Exclamatory Icon for Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Verify Triangle Exclamatory Icon for Patient Case in Inventory Reconciliation Tracker'
        );

        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270008.PatientCase.PatientDetails.PatientFullName
        );
        inventoryReconciliation.verifyTriangleExclamatoryIcon(
          td_inv_rec_tcid_270008.PatientCase.PatientDetails.LastName
        );
        // #endregion

        // #region - Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Select Patient Case in Inventory Reconciliation Tracker'
        );

        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[2]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[2]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Update Label with Tooltip Text for Update Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Update Label with Tooltip Text for Update Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[2].Implant,
          LabelHeaders.update
        );
        // #endregion

        // #region - Verify New Label with Tooltip Text for New Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify New Label with Tooltip Text for New Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant,
          LabelHeaders.new
        );
        // #endregion

        // #region - Verify Update Label with Tooltip Text for Update Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Update Label with Tooltip Text for Update Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[2].SupplyName,
          LabelHeaders.update
        );
        // #endregion

        // #region - Verify New Label with Tooltip Text for New Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify New Label with Tooltip Text for New Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1].SupplyName,
          LabelHeaders.new
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        // #endregion
      });
    });
  }

  updateNewFreeTextItemToIosInventoryItem() {
    describe('Update New Free Text imported From SIS Charts to IOS Inventory Item after 1st Depletion is completed', () => {
      it('Update New Free Text imported From SIS Charts to IOS Inventory Item after 1st Depletion is completed', () => {
        // #region - Update Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[3]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[1]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[1]
        );
        // #endregion

        // #region - Update Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[1].Implant,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270008.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Depleting the Patient Case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Depleting the Patient Case in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.yes);
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInCoding() {
    describe('Verify Implants and Supplies coming from Inventory Tracker or Face-sheet Inventory are displaying in Coding Tracker', () => {
      it('Verify Implants and Supplies coming from Inventory Tracker or Face-sheet Inventory are displaying in Coding Tracker', () => {
        // #region - Navigate to Cases to Code Tracker and Select Patient Case Row and Add Diagnosis Code for the Procedure

        cy.cGroupAsStep(
          'Navigate to Cases to Code Tracker and Select Patient Case Row and Add Diagnosis Code for the Procedure'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        casesToCode.addSelectedToPerformed();
        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.CasesToCodeDetails[0].SearchProcedureName!
        );
        casesToCode.enterDiagnosisCode(
          td_inv_rec_tcid_270008.CasesToCodeDetails[0]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify First Implant Details in Cases to Code Tracker

        cy.cGroupAsStep(
          'Verify First Implant Details in Cases to Code Tracker'
        );

        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.CasesToCodeDetails[1].SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270008.CasesToCodeDetails[1].Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270008.CasesToCodeDetails[1].HCPCS!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Second Implant Details in Cases to Code Tracker

        cy.cGroupAsStep(
          'Verify Second Implant Details in Cases to Code Tracker'
        );

        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.CasesToCodeDetails[2].SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270008.CasesToCodeDetails[2].Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270008.CasesToCodeDetails[2].HCPCS!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify First Supply Details in Cases to Code Tracker

        cy.cGroupAsStep('Verify First Supply Details in Cases to Code Tracker');

        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.CasesToCodeDetails[3].SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270008.CasesToCodeDetails[3].Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270008.CasesToCodeDetails[3].HCPCS!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Second Supply Details in Cases to Code Tracker

        cy.cGroupAsStep(
          'Verify Second Supply Details in Cases to Code Tracker'
        );
        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.CasesToCodeDetails[4].SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270008.CasesToCodeDetails[4].Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270008.CasesToCodeDetails[4].HCPCS!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Implant Details in Documentation section in Coding Screen

        cy.cGroupAsStep(
          'Verify Implant Details in Documentation section in Coding Screen'
        );

        casesToCode.verifyDocumentationImplantDetails(
          td_inv_rec_tcid_270008.CasesToCodeDetails[1].Documentation!
        );
        casesToCode.verifyDocumentationImplantDetails(
          td_inv_rec_tcid_270008.CasesToCodeDetails[2].Documentation!
        );
        // #endregion

        // #region - Make Case as Ready for Charge in Cases to Code Tracker

        cy.cGroupAsStep(
          'Make Case as Ready for Charge in Cases to Code Tracker'
        );

        casesToCode.clickReadyForChargeAndDoneButton();
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInChargeEntry() {
    describe('Verify Implants and Supplies coming from Coding Tracker are displaying in Charge Entry Tracker', () => {
      it('Verify Implants and Supplies coming from Coding Tracker are displaying in Charge Entry Tracker', () => {
        // #region - Navigate to Charge Entry Tracker and Verify Patient Case in Charge Entry Tracker

        cy.cGroupAsStep(
          'Navigate to Charge Entry Tracker and Verify Patient Case in Charge Entry Tracker'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270008.PatientCase.PatientDetails.PatientFullName
        );
        // #endregion

        // #region - Select Period, Batch and Patient Case Row in Charge Entry Tracker

        cy.cGroupAsStep(
          'Select Period, Batch and Patient Case Row in Charge Entry Tracker'
        );

        chargeEntry.selectCase(td_inv_rec_tcid_270008.Charges[0]);
        // #endregion

        // #region - Verify Procedure Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify Procedure Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.Charges[0].CPT
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify First Implant Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify First Implant Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.Charges[1].CPT
        );
        chargeEntry.verifyUnits(td_inv_rec_tcid_270008.Charges[1].Units!);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Second Implant Details in Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify Second Implant Details in Charge Entry Tracker'
        );

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.Charges[2].CPT
        );
        chargeEntry.verifyUnits(td_inv_rec_tcid_270008.Charges[2].Units!);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify First Supply Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify First Supply Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.Charges[3].CPT
        );
        chargeEntry.verifyUnits(td_inv_rec_tcid_270008.Charges[3].Units!);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Second Supply Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify Second Supply Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270008.Charges[4].CPT
        );
        chargeEntry.verifyUnits(td_inv_rec_tcid_270008.Charges[4].Units!);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Make Patient Case as Ready for Bill in Charge Entry Tracker

        cy.cGroupAsStep(
          'Make Patient Case as Ready for Bill in Charge Entry Tracker'
        );

        chargeEntry.clickReadyForBillAndDoneButton();
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInFaceSheetInventory() {
    describe('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
      it('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
        // #region - Search and Select Patient from global search

        cy.cGroupAsStep('Search and Select Patient from global search');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');

        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.PreferenceCardInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[1].SupplyName
        );
        // #endregion
      });
    });
  }

  verifyIosImplantSupplyInOperative() {
    describe('Verify IOS Inventory Item Description on mouse hover of Info icon for the free text item', () => {
      it('Verify IOS Inventory Item Description on mouse hover of info Icon for the free text item', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        /* Due to multiple navigation to different desktop, added reload to avoid white screen/loading issue*/
        cy.reload();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Un Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Un Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_UNSIGN[0],
          YesOrNo.yes
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        /* Due to multiple navigation to different desktop, added reload to avoid white screen/loading issue*/
        cy.reload();
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - UnSign Operative Department for Patient Case

        cy.cGroupAsStep('UnSign Operative Department for Patient Case');

        chartsCoverFaceSheet.unSignDepartment(YesOrNo.yes);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[0].Implant
        );
        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270008.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270008.FaceSheetInventoryInfo.Supplies[1].SupplyName
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        // #endregion

        // #region - Sign Operative Department

        cy.cGroupAsStep('Sign Operative Department');

        chartsCoverFaceSheet.signDepartment();
        // #endregion

        // #region - Click on Patient Face sheet Icon

        cy.cGroupAsStep('Click on Patient Face sheet Icon');

        chartsCoverFaceSheet.clickFaceSheetIcon();
        // #endregion

        // #region - Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0],
          YesOrNo.yes
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
