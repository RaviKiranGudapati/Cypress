/************Revision History
 * 15/07/22, Debasish, tests implemented
 ********************/

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { InvRecMedicationTcId76306 } from './scenarios/tcid-76306.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verifying Inventory Reconciliation Medications Table Layout
 * US - 16490 - Verify Medications Table Layout
 * Script Execution Approach -
 * 1. Navigating to Inventory Reconciliation
 * 2. Selecting Patient Row
 * 3. In Inventory, verifying Medications can take input in format {###,###.##}
 * 4. Under Medications, select any Medications
 * 5. Enter input in alphabets, verify input is not taken
 * 6. Enter input Alphanumeric , verify only numeric is taken
 * 7. Enter only 6 numerics before decimal and 2 numeric after decimal is allowed
 * 8. Follow the same all numeric input boxes -  Administered, Wasted and Usage Total
 * 9. Click Done Button
 */

/* instance variables */
const invRecMedication = new InvRecMedicationTcId76306();

describe(
  'Verifying Medications Table Layout In Inventory Reconciliation Tracker for Patient cases',
  {
    tags: [
      'trackers',
      'inventory-reconciliation',
      'medication',
      'US#16490',
      'TC#76306',
    ],
  },
  () => {
    //Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_22[0],
        Password: UserList.GEM_USER_22[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_ORDER_DISABLED_26, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        // Verify Medications Can't take alphabets and only accepts numerics
        invRecMedication.VerifyMedicationInputFieldValues();

        // Verify Administered allows only 6 digits before decimal & 2 digits after decimal and reformatted to ###,###.##
        invRecMedication.VerifyAdministeredForDigits();

        // Verify Waste and Used Total allows only 2 digits before decimal and 2 digits after decimal
        invRecMedication.VerifyWastedAndUsedTotalFields();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
