import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { VerifyBannerSendInventoryFeatureTcId272244 } from './scenarios/tcid-272244.sc';

/* instance variables */
const invRecImplantSupply = new VerifyBannerSendInventoryFeatureTcId272244();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify that the Inventory banner should display if the patient is not discharged when 'Send Inventory to tracker upon discharge' feature is enabled
 * US - 243610 - SIS Office - Inventory - Discharge of Patient to trigger Inventory
 * Script Execution Approach -
 * 1. Navigate to Enterprise Settings.
 * 2. Navigate to Facility Management
 * 3. Enable Send Inventory To Tracker Upon Discharge Feature and Verify Tooltip Text
 * 4. Navigate to Required Facility
 * 5. Navigating to Application Settings
 * 6. Navigate to Formulary Tab ad Search and Select Required Formulary Medication
 * 7. Edit Formulary Medication and Add Inventory Medication, Administration Amount and Usage Unit of Measure
 * 8. Select Compound Medication as Yes for One Medication and Click on Done
 * 9. Navigate to Anesthesia Desktop
 * 10. Selecting Patient Case One Row
 * 11. Click on Add Medication Button and Add Compound Medication
 * 12. Document Dose and Click On Done
 * 13. Navigate to Nursing Desktop
 * 14. Selecting Patient Case One Row
 * 15. Navigate to Operative Department
 * 16. Navigate to WorkList Task Panel in Operative Department
 * 17. Add Free Text, Ios Billable & Non-Billable Implant and Supplies
 * 18. Navigate to Orders Tab
 * 19. Add Simple Medication
 * 20. Administer the Medications and Document Dose and Click on Done
 * 21. Navigate to Inventory Tracker
 * 22. Select Patient Case Two Row
 * 23. Verify Banner Message
 * 24. Navigate to Business Desktop
 * 25. Selecting Patient Case One Row from Global Search
 * 26. Select Face-Sheet Inventory Task
 * 27. Verify Banner Message
 * 28. Navigate to Business Desktop
 * 29. Selecting Patient Case Two Row from Global Search
 * 30. Select Face-Sheet Inventory Task
 * 31. Verify Banner Message
 * 32. logout
 */

describe(
  'Verify that the Inventory banner should display if the patient is not discharged when Send Inventory to tracker upon discharge feature is enabled ',
  {
    tags: ['inventory-reconciliation', 'TC#272244', 'US#243610'],
  },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_8[0],
        Password: UserList.GEM_USER_8[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        invRecImplantSupply.navigateToFeaturesTab();
        invRecImplantSupply.editPatientFormularyMedication();
        invRecImplantSupply.addMedicationInAnesthesia();
        invRecImplantSupply.addImplantsSuppliesMedicationsInOperative();
        invRecImplantSupply.verifyBannerMessageInInventoryTracker();
        invRecImplantSupply.verifyBannerMessageInFaceSheetInventory();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
