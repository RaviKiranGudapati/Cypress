import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';

import { AppErrorMessages } from '../../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { td_verify_banner_send_inventory_feature_tcid_272244 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/verify-banner-send-inventory-feature-tcid-272244.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';
import { OR_LOGIN } from '../../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { IosTextItem, FreeText } from '../../../../../../app-modules-libs/shared/application-settings/enums/nursing-configuration.enum';

import EnterpriseConfiguration from '../../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import SISAnesthesiaDesktop from '../../../../../../app-modules-libs/sis-anesthesia/anesthesia';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import Transactions, {
  ContextMenu,
} from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import ChartsLogin from '../../../../../../app-modules-libs/sis-charts/login/login';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const sisAnesthesiaDesktop = new SISAnesthesiaDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const sisChartsDesktop = new SISChartsDesktop();
const enterpriseConfig = new EnterpriseConfiguration();
const scheduleGrid = new ScheduleGrid();
const chartsLogin = new ChartsLogin();
const transactions = new Transactions();
const inventoryReconciliation = new InventoryReconciliation(
  td_verify_banner_send_inventory_feature_tcid_272244.PatientCase.PatientDetails[1]
);

export class VerifyBannerSendInventoryFeatureTcId272244 {
  navigateToFeaturesTab() {
    describe('Enable Send Inventory to tracker upon discharge Feature', () => {
      it('Navigate to Feature Tab in Facility Management and Enable Send Inventory to tracker upon discharge Feature', () => {
        /*****************Test Begins***************/
        // #region - Navigate to Enterprise Settings

        cy.cGroupAsStep('Navigate to Enterprise Settings');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        // #endregion

        // #region - Navigate to Facility Management and Select Required Facility

        cy.cGroupAsStep(
          'Navigate to Facility Management and Select Required Facility'
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        // #endregion

        // #region - Click on Features Tab in Facility Management

        cy.cGroupAsStep('Click on Features Tab in Facility Management');

        enterpriseConfig.clickOnFeaturesTab();
        // #endregion

        // #region - Enable Send Inventory to Tracker upon Patient Discharge Feature and Verify Tooltip Text

        cy.cGroupAsStep(
          'Enable Send Inventory to Tracker upon Discharge Features Tab and Verify Tooltip Text'
        );

        enterpriseConfig.selectSendInventoryDischargeFeature();
        // #endregion

        // #region - Navigate to Business Desktop of the required Facility

        cy.cGroupAsStep(
          'Navigate to Business Desktop of the required Facility'
        );

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_8
        );
        scheduleGrid.scheduleGridEnable();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  editPatientFormularyMedication() {
    describe('Update Formulary Medication with Required Details in Application Settings', () => {
      it('Add Inventory Medication, Administration Amount, Unit Usage of Measure for Formulary Medication in Application Settings', () => {
        // #region - Navigate to Application Settings

        cy.cGroupAsStep('Navigate to Application Settings');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        // #endregion

        // #region - Search and Select Formulary Medication and Add Inventory Medication, Administration Amount, Unit Usage of Measure for Formulary Medication

        cy.cGroupAsStep(
          'Search and Select Formulary Medication and Add Inventory Medication, Administration Amount, Unit Usage of Measure for Formulary Medication'
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.FORMULARY.SUB_HEADER[0],
          true
        );
        nursingConfiguration.editFormularyMedication(
          td_verify_banner_send_inventory_feature_tcid_272244.Medication[0],
          ContextMenu.edit
        );
        nursingConfiguration.editFormularyMedication(
          td_verify_banner_send_inventory_feature_tcid_272244.Medication[1],
          ContextMenu.edit
        );
        // #endregion
      });
    });
  }

  addMedicationInAnesthesia() {
    describe('Add Medication in Anesthesia Desktop', () => {
      it('Add and Administer Medication for Patient Case in Anesthesia', () => {
        // #region - Navigate to Anesthesia Desktop

        cy.cGroupAsStep('Navigate to Anesthesia Desktop');

        sisAnesthesiaDesktop.selectAnesthesiaInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_ANESTHESIA_DESKTOP_BUTTON[0]
        );
        // #endregion

        // #region - Select Patient In Anesthesia Desktop

        cy.cGroupAsStep('Select Patient In Anesthesia Desktop');

        sisAnesthesiaDesktop.selectPatientInSearchBox(
          td_verify_banner_send_inventory_feature_tcid_272244.PatientCase
            .PatientDetails[0]
        );
        // #endregion

        // #region - Add and Administer Medication in Anesthesia

        cy.cGroupAsStep('Add and Administer Medication in Anesthesia');

        sisAnesthesiaDesktop.addAnesthesiaMedication(
          td_verify_banner_send_inventory_feature_tcid_272244.Medication[1]
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  addImplantsSuppliesMedicationsInOperative() {
    describe('Add Implant, Supplies and Medications in Nursing Desktop', () => {
      it('Add Implant, Supplies and Medications in Work-list Under Operative Department', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_verify_banner_send_inventory_feature_tcid_272244.PatientCase
            .PatientDetails[0]
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Select Yes Button for Implant Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Implant Questionnaire in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.clickImplantsQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Implants in Operative Department

        cy.cGroupAsStep('Add Implants in Operative Department');

        nursingConfiguration.addImplantsInPreferenceCard(
          td_verify_banner_send_inventory_feature_tcid_272244.Implant[0],
          FreeText.free_text_item
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_verify_banner_send_inventory_feature_tcid_272244.Implant[1],
          IosTextItem.ios_text_item
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_verify_banner_send_inventory_feature_tcid_272244.Implant[2],
          IosTextItem.ios_text_item
        );
        // #endregion

        // #region - Select Yes Button for Supply Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Supply Questionnaire in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.clickSuppliesQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Supplies in Operative Department

        cy.cGroupAsStep('Add Supplies in Operative Department');

        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_verify_banner_send_inventory_feature_tcid_272244.Supplies[0],
          IosTextItem.ios_text_item
        );
        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_verify_banner_send_inventory_feature_tcid_272244.Supplies[1],
          FreeText.free_text_item
        );
        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_verify_banner_send_inventory_feature_tcid_272244.Supplies[2],
          IosTextItem.ios_text_item
        );
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        // #endregion

        // #region - Add and Administer Medication in Orders Tab in Operative Department

        cy.cGroupAsStep(
          'Add and Administer Medication in Orders Tab in Operative Department'
        );

        chartsCoverFaceSheet.verifyAddMedicationBtn();
        nursingConfiguration.addMedicationPhysicianOrder(
          td_verify_banner_send_inventory_feature_tcid_272244.Medication[0],
          0,
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        nursingConfiguration.addMedicationPhysicianOrderDone();
        chartsCoverFaceSheet.departmentOrdersAdministerMedication(
          td_verify_banner_send_inventory_feature_tcid_272244.Medication[0]
        );
        // #endregion

        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion
      });
    });
  }

  verifyBannerMessageInInventoryTracker() {
    describe('Verify Inventory Banner Message in Inventory Reconciliation Tracker', () => {
      it('Verify Inventory Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is discharged and Inventory Details are not available in Inventory Reconciliation Tracker', () => {
        // #region - Navigate to Inventory Reconciliation Tracker

        cy.cGroupAsStep('Navigate to Inventory Reconciliation Tracker');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        // #endregion

        // #region - Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Select Patient Case in Inventory Reconciliation Tracker'
        );

        combinedCoding.verifyPatientRow(
          td_verify_banner_send_inventory_feature_tcid_272244.PatientCase
            .PatientDetails[1].PatientFullName
        );
        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is discharged and Inventory Details Not Available in Inventory Reconciliation Tracker
        cy.cGroupAsStep(
          'Verify Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is discharged and Inventory Details Not Available in Inventory Reconciliation Tracker'
        );

        inventoryReconciliation.verifyBannerMessageInFaceSheet(
          AppErrorMessages.patient_discharge_and_inventory_not_available
        );
        // #endregion

        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyBannerMessageInFaceSheetInventory() {
    describe('Verify Inventory Banner Message in FaceSheet Inventory', () => {
      it('Verify Inventory Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is not discharged in FaceSheet Inventory', () => {
        // #region - Search and Select Patient from global search

        cy.cGroupAsStep('Search and Select Patient from global search');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          td_verify_banner_send_inventory_feature_tcid_272244.PatientCase
            .PatientDetails[0]
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');

        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is not discharged in FaceSheet Inventory
        cy.cGroupAsStep(
          'Verify Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is not discharged in FaceSheet Inventory'
        );

        inventoryReconciliation.verifyBannerMessageInFaceSheet(
          AppErrorMessages.patient_not_discharge_and_send_inventory_upon_patient_enable
        );
        // #endregion

        // #region - Verify Implants are not appear on FaceSheet Inventory

        cy.cGroupAsStep(
          'Verify Implants are not appear on FaceSheet Inventory'
        );

        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Implant[0].Implant
        );
        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Implant[1].Implant
        );

        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Implant[2].Implant
        );
        // #endregion

        // #region - Verify Supplies are not appear on FaceSheet Inventory

        cy.cGroupAsStep(
          'Verify Supplies are not appear on FaceSheet Inventory'
        );

        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Supplies[0]
            .SupplyName
        );
        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Supplies[1]
            .SupplyName
        );

        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Supplies[2]
            .SupplyName
        );
        // #endregion

        // #region - Verify Medications are not appear on FaceSheet Inventory

        cy.cGroupAsStep(
          'Verify Medications are not appear on FaceSheet Inventory'
        );

        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .MEDICATIONS_TABLE.MEDICATIONS[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Medication[0]
            .Medication
        );
        inventoryReconciliation.verifyInventoryItemsNotAppearOnScreen(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .MEDICATIONS_TABLE.MEDICATIONS[0],
          td_verify_banner_send_inventory_feature_tcid_272244.Medication[1]
            .Medication
        );
        // #endregion

        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        // #endregion

        // #region - Search and Select Patient from global search

        cy.cGroupAsStep('Search and Select Patient from global search');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          td_verify_banner_send_inventory_feature_tcid_272244.PatientCase
            .PatientDetails[1]
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');

        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is discharged and Inventory Details are not available in FaceSheet Inventory
        cy.cGroupAsStep(
          'Verify Banner Message is Getting displayed when Send Inventory to tracker upon discharge and Patient Case is discharged and Inventory Details are not available in FaceSheet Inventory'
        );

        inventoryReconciliation.verifyBannerMessageInFaceSheet(
          AppErrorMessages.patient_discharge_and_inventory_not_available
        );
        // #endregion
      });
    });
  }
}
