import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { TransferInvItemsOnDischargeTcId272419 } from './scenarios/tcid-272419.sc';

/* instance variables */
const invRecImplantSupply = new TransferInvItemsOnDischargeTcId272419();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify the Inventory details are moving from Charts to Office on discharging the Patient with the status is Partially Performed Billable for a Recovery case
 * US - 243610 - SIS Office - Inventory - Discharge of Patient to trigger Inventory
 * Script Execution Approach -
 * 1. Navigate to Enterprise Settings.
 * 2. Navigate to Facility Management
 * 3. Enable Send Inventory To Tracker Upon Discharge Feature and Verify Tooltip Text
 * 4. Navigate to Required Facility
 * 5. Navigating to Application Settings
 * 6. Navigate to Formulary Tab ad Search and Select Required Formulary Medication
 * 7. Edit Formulary Medication and Add Inventory Medication, Administration Amount and Usage Unit of Measure
 * 8. Select Compound Medication as Yes for One Medication and Click on Done
 * 9. Navigate to Anesthesia Desktop
 * 10. Selecting Patient Row
 * 11. Click on Add Medication Button and Add Compound Medication
 * 12. Document Dose and Click On Done
 * 13. Navigate to Nursing Desktop
 * 14. Selecting Patient Row
 * 15. Navigate to Operative Department
 * 16. Navigate to WorkList Task Panel in Operative Department
 * 17. Add Free Text, Ios Billable & Non-Billable Implant and Supplies
 * 18. Navigate to Orders Tab
 * 19. Add Simple Medication
 * 20. Administer the Medications and Document Dose and Click on Done
 * 21. Navigate to Business Desktop
 * 22. Selecting Patient Row from Global Search
 * 23. Select Face-Sheet Inventory Task
 * 24. Verify Free Text, Ios Billable & Non-Billable Implant and Supply Name with Details
 * 25. Verify Medication Details
 * 26. Verify Free Text Tooltip
 * 27. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 28. Update Free Text Item to Ios Item for Supplies and Implants
 * 29. Verify Free Text Tooltip Description for Ios Inventory Item
 * 30. Verify Item Description, Item Number and Manufacturer Number for the updated inventory item
 * 31. Deplete the Patient Case by selecting Depletion Verified as No and clicking on update.
 * 32. Verify Ios Billable & Non-Billable Implant and Supply Name with Details
 * 33. Verify Medication Details
 * 34. Verify Free Text Tooltip Description for Ios Inventory Item
 * 35. Navigate to Nursing Desktop
 * 36. Selecting Patient Row
 * 37. Navigate to Operative Department
 * 38. Navigate to WorkList Task Panel in Operative Department
 * 39. Verify Ios Description for Free Text Supply and Implant
 * 40. logout
 */

describe(
  'Verify the Inventory details are moving from Charts to Office on discharging the Patient with the status is Partially Performed Billable for a Recovery case ',
  {
    tags: ['inventory-reconciliation', 'TC#272419', 'US#243610'],
  },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_8[0],
        Password: UserList.GEM_USER_8[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        invRecImplantSupply.navigateToFeaturesTab();
        invRecImplantSupply.editPatientFormularyMedication();
        invRecImplantSupply.addMedicationInAnesthesia();
        invRecImplantSupply.addImplantsSuppliesMedicationsInOperative();
        invRecImplantSupply.verifyImplantSuppliesMedicationsInFaceSheetInventory();
        invRecImplantSupply.verifyImplantSuppliesMedicationsInFaceSheetInventoryAfterDepletion();
        invRecImplantSupply.verifyIosImplantSupplyInOperative();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
