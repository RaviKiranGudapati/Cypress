import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import {
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_inv_rec_tcid_270009 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/inv-rec-tcid-270009.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import { FreeText } from '../../../../../../app-modules-libs/shared/application-settings/enums/nursing-configuration.enum';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CasesToCode from '../../../../../../app-modules-libs/sis-office/trackers/cases-to-code';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import { LabelHeaders } from '../../../../../../app-modules-libs/sis-office/trackers/enums/inv-reconciliation.enum';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

/* instance variables */
const createCase = new CreateCase(td_inv_rec_tcid_270009.PatientCase);
const inventoryReconciliation = new InventoryReconciliation(
  td_inv_rec_tcid_270009.PatientCase.PatientDetails
);
const casesToCode = new CasesToCode(createCase.patientCaseModel!);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const nursingConfiguration = new NursingConfiguration();
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const sisChartsDesktop = new SISChartsDesktop();
const combinedCoding = new CombinedCoding();

/* const values */
const codingUpdatedUsed =
  td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Supplies.InventorySupply
    .Billed -
  td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Supplies.InventorySupply
    .TotalDepleted;
const chargeEntryUpdatedUsed =
  td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Supplies
    .InventorySupply.Billed -
  td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Supplies
    .InventorySupply.TotalDepleted;

export class InvRecFreeTextToIosItemTcId270009 {
  addFreeTextItemInOperative() {
    describe('Add Free Text Implant and Free Text Supply in Work-list Under Operative Department', () => {
      it('Add Free Text Implant and Free Text Supply in Work-list Under Operative Department', () => {
        /*****************Test Begins***************/
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Select Yes Button for Implant Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Implant Questionnaire in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.clickImplantsQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Free Text Implant in Preference Card

        cy.cGroupAsStep('Add Free Text Implant in Preference Card');

        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0],
          FreeText.free_text_item
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Select Yes Button for Implant Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Implant Questionnaire in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.clickSuppliesQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Free Text Supply in Preference Card

        cy.cGroupAsStep('Add Free Text Supply in Preference Card');

        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0],
          FreeText.free_text_item
        );
        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        // #endregion

        // #region - Sign Operative Department

        cy.cGroupAsStep('Sign Operative Department');

        chartsCoverFaceSheet.signDepartment();
        // #endregion

        // #region - Click on Patient Face sheet Icon

        cy.cGroupAsStep('Click on Patient Face sheet Icon');

        chartsCoverFaceSheet.clickFaceSheetIcon();
        // #endregion

        // #region - Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0],
          YesOrNo.yes
        );
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInInventory() {
    describe('Verify Implants and Supplies imported from SIS Charts is displaying in Inventory Reconciliation Tracker', () => {
      it('Verify Implants and Supplies imported from SIS Charts is displaying in Inventory Reconciliation Tracker', () => {
        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion

        // #region - Navigate to Inventory Reconciliation tracker

        cy.cGroupAsStep('Navigate to Inventory Reconciliation tracker');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .CASE_REQUESTS[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        // #endregion

        // #region - Verify Free Text Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Verify Free Text Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker'
        );

        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270009.PatientCase.PatientDetails.PatientFullName
        );
        inventoryReconciliation.verifyDepletionWarningMessage(
          td_inv_rec_tcid_270009.PatientCase.PatientDetails.LastName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0]
        );
        // #endregion

        // #region - Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Select Patient Case in Inventory Reconciliation Tracker'
        );

        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        // #endregion
      });
    });
  }

  updateFreeTextItemToIosInventoryItem() {
    describe('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Reconciliation Tracker', () => {
      it('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Reconciliation Tracker', () => {
        // #region - Update First Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update First Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Update Second Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Second Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[1]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[1]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Update First Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update First Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Update Second Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Second Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Verify Implant Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[1].Implant,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270009.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Depleting the Patient Case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Depleting the Patient Case in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.yes);
        // #endregion
      });
    });
  }

  verifyAndUpdateImplantSuppliesInCoding() {
    describe('Verify Implants and Supplies coming from Inventory Tracker or Face-sheet Inventory are displaying in Coding Tracker and Update Units for Implant and Supplies', () => {
      it('Verify Implants and Supplies coming from Inventory Tracker or Face-sheet Inventory are displaying in Coding Tracker and Update Units for Implant and Supplies', () => {
        // #region - Navigate to Cases to Code Tracker and Select Patient Case Row and Add Scheduled Item to Performed Items and Add Diagnosis Code for the Procedure

        cy.cGroupAsStep(
          'Navigate to Cases to Code Tracker and Select Patient Case Row and Add Scheduled Item to Performed Items and Add Diagnosis Code for the Procedure'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        casesToCode.addSelectedToPerformed();
        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[0]
            .SearchProcedureName!
        );
        casesToCode.enterDiagnosisCode(
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[0]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Implant Details and Update Units in Cases to Code Tracker

        cy.cGroupAsStep(
          'Verify Implant Details and Update Units in Cases to Code Tracker'
        );

        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[1]
            .SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[1]
            .Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[1]
            .HCPCS!
        );
        casesToCode.enterUnits(
          td_inv_rec_tcid_270009.UpdateCodingInventoryInfo.CasesToCodeDetails[0]
            .Units!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Supply Details and Update Units in Cases to Code Tracker

        cy.cGroupAsStep(
          'Verify Supply Details and Update Units in Cases to Code Tracker'
        );

        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[2]
            .SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[2]
            .Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270009.VerifyCodingInventoryInfo.CasesToCodeDetails[2]
            .HCPCS!
        );
        casesToCode.enterUnits(
          td_inv_rec_tcid_270009.UpdateCodingInventoryInfo.CasesToCodeDetails[1]
            .Units!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Make Case as Ready for Charge in Cases to Code Tracker

        cy.cGroupAsStep(
          'Make Case as Ready for Charge in Cases to Code Tracker'
        );

        casesToCode.clickReadyForChargeAndDoneButton();
        // #endregion
      });
    });
  }

  verifyUpdatedCodingInventoryItemsInInventory() {
    describe('Verify Updated Implants and Supplies imported from Coding Tracker or Face-Sheet Coding is displaying in Inventory Reconciliation Tracker', () => {
      it('Verify Updated Implants and Supplies imported from Coding Tracker or Face-Sheet Coding is displaying in Inventory Reconciliation Tracker', () => {
        // #region - Navigate to Inventory Reconciliation tracker

        cy.cGroupAsStep('Navigate to Inventory Reconciliation tracker');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        // #endregion

        // #region - Verify Reconcile Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Verify Reconcile Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker'
        );

        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270009.PatientCase.PatientDetails.PatientFullName
        );
        inventoryReconciliation.verifyDepletionWarningMessage(
          td_inv_rec_tcid_270009.PatientCase.PatientDetails.LastName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .USED_AND_BILLED[0]
        );
        // #endregion

        // #region - Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Select Patient Case in Inventory Reconciliation Tracker'
        );

        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Implant
        );
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Implant.Implant
        );
        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant,
          LabelHeaders.update
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Supplies
        );
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Supplies.SupplyName
        );
        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          LabelHeaders.update
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Update Used Quantity and Verify Discrepancy Message is not visible for Implant in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Used Quantity and Verify Discrepancy Message is not visible for Implant in inventory reconciliation tracker'
        );

        inventoryReconciliation.enterUsedValueForImplant(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Implant.Implant,
          codingUpdatedUsed
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Implant.Implant,
          false
        );
        // #endregion

        // #region - Update Used Quantity and Verify Discrepancy Message is not visible for Supply in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Used Quantity and Verify Discrepancy Message is not visible for Supply in inventory reconciliation tracker'
        );

        inventoryReconciliation.enterUsedQuantityForSupply(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Supplies.SupplyName,
          codingUpdatedUsed
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedCodingInventoryInfo.Supplies.SupplyName,
          false
        );
        // #endregion

        // #region - Depleting the Patient Case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Depleting the Patient Case in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.yes);
        // #endregion
      });
    });
  }

  verifyAndUpdateImplantSuppliesInChargeEntry() {
    describe('Verify Implants and Supplies coming from Coding Tracker are displaying in Charge Entry Tracker', () => {
      it('Verify Implants and Supplies coming from Coding Tracker are displaying in Charge Entry Tracker', () => {
        // #region - Navigate to Charge Entry Tracker and Verify Patient Case in Charge Entry Tracker

        cy.cGroupAsStep(
          'Navigate to Charge Entry Tracker and Verify Patient Case in Charge Entry Tracker'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270009.PatientCase.PatientDetails.PatientFullName
        );
        // #endregion

        // #region - Select Period, Batch and Patient Case Row in Charge Entry Tracker

        cy.cGroupAsStep(
          'Select Period, Batch and Patient Case Row in Charge Entry Tracker'
        );

        chargeEntry.selectCase(
          td_inv_rec_tcid_270009.VerifyChargeEntryInventoryInfo.Charges[0]
        );
        // #endregion

        // #region - Verify Procedure Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify Procedure Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270009.VerifyChargeEntryInventoryInfo.Charges[0]
            .CPT[0]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Implant Details and Update Units in Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify Implant Details and Update Units in Charge Entry Tracker'
        );

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270009.VerifyChargeEntryInventoryInfo.Charges[1].CPT
        );
        chargeEntry.verifyUnits(
          td_inv_rec_tcid_270009.VerifyChargeEntryInventoryInfo.Charges[1]
            .Units!
        );
        chargeEntry.updateUnits(
          td_inv_rec_tcid_270009.UpdateChargeEntryInventoryInfo.Charges[0]
            .Units!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Supply Details and Updated Units in Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify Supply Details and Updated Units in Charge Entry Tracker'
        );

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270009.VerifyChargeEntryInventoryInfo.Charges[2].CPT
        );
        chargeEntry.verifyUnits(
          td_inv_rec_tcid_270009.VerifyChargeEntryInventoryInfo.Charges[2]
            .Units!
        );
        chargeEntry.updateUnits(
          td_inv_rec_tcid_270009.UpdateChargeEntryInventoryInfo.Charges[1]
            .Units!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Make Patient Case as Ready for Bill in Charge Entry Tracker

        cy.cGroupAsStep(
          'Make Patient Case as Ready for Bill in Charge Entry Tracker'
        );

        chargeEntry.clickReadyForBillAndDoneButton(true);
        // #endregion
      });
    });
  }

  verifyUpdatedChargeEntryInventoryItemsInInventory() {
    describe('Verify Updated Implants and Supplies imported from Charge Entry Tracker or Face-Sheet Charge Entry is displaying in Inventory Reconciliation Tracker', () => {
      it('Verify Updated Implants and Supplies imported from Charge Entry Tracker or Face-Sheet Charge Entry is displaying in Inventory Reconciliation Tracker', () => {
        // #region - Navigate to Inventory Reconciliation tracker

        cy.cGroupAsStep('Navigate to Inventory Reconciliation tracker');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        // #endregion

        // #region - Verify Reconcile Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Verify Reconcile Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker'
        );

        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270009.PatientCase.PatientDetails.PatientFullName
        );
        inventoryReconciliation.verifyDepletionWarningMessage(
          td_inv_rec_tcid_270009.PatientCase.PatientDetails.LastName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .USED_AND_BILLED[0]
        );
        // #endregion

        // #region - Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Select Patient Case in Inventory Reconciliation Tracker'
        );

        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Implant
        );
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Implant.Implant
        );
        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant,
          LabelHeaders.update
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Supplies
        );
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Supplies
            .SupplyName
        );
        inventoryReconciliation.verifyInventoryItemLabel(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          LabelHeaders.update
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Inventory reconciliation tracker'
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Update Used Quantity and Verify Discrepancy Message is not visible for Implant in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Used Quantity and Verify Discrepancy Message is not visible for Implant in inventory reconciliation tracker'
        );

        inventoryReconciliation.enterUsedValueForImplant(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Implant
            .Implant,
          chargeEntryUpdatedUsed
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Implant
            .Implant,
          false
        );
        // #endregion

        // #region - Update Used Quantity and Verify Discrepancy Message is not visible for Supply in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Used Quantity and Verify Discrepancy Message is not visible for Supply in inventory reconciliation tracker'
        );

        inventoryReconciliation.enterUsedQuantityForSupply(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Supplies
            .SupplyName,
          chargeEntryUpdatedUsed
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        inventoryReconciliation.verifyDiscrepancyWarningForInventoryItem(
          td_inv_rec_tcid_270009.UpdatedChargeEntryInventoryInfo.Supplies
            .SupplyName,
          false
        );
        // #endregion

        // #region - Depleting the Patient Case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Depleting the Patient Case in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.yes);
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInFaceSheetInventory() {
    describe('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
      it('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
        // #region - Search and Select Patient from global search

        cy.cGroupAsStep('Search and Select Patient from global search');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');
        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Implant Details in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Implant Details in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details In Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Supply Details In Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[1].SupplyName
        );
        // #endregion
      });
    });
  }

  verifyIosImplantSupplyInOperative() {
    describe('Verify IOS Inventory Item Description on mouse hover of Info icon for the free text item', () => {
      it('Verify IOS Inventory Item Description on mouse hover of info Icon for the free text item', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Un Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Un Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_UNSIGN[0],
          YesOrNo.yes
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - UnSign Operative Department for Patient Case

        cy.cGroupAsStep('UnSign Operative Department for Patient Case');

        chartsCoverFaceSheet.unSignDepartment(YesOrNo.yes);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[0].Implant
        );
        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270009.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270009.FaceSheetInventoryInfo.Supplies[1].SupplyName
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        // #endregion

        // #region - Sign Operative Department

        cy.cGroupAsStep('Sign Operative Department');

        chartsCoverFaceSheet.signDepartment();
        // #endregion

        // #region - Click on Patient Face sheet Icon

        cy.cGroupAsStep('Click on Patient Face sheet Icon');

        chartsCoverFaceSheet.clickFaceSheetIcon();
        // #endregion

        // #region - Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0],
          YesOrNo.yes
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
