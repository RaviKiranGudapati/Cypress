/************Revision History
 * 15/07/22, Debasish, tests implemented
 ********************/

import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  CommonUtils,
  StringType,
} from '../../../../../../support/common-core-libs/framework/common-utils';

import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';

import { td_inv_rec_medication_tcid_76306 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/inv-rec-medication-tcid-76306.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const inventoryReconciliation = new InventoryReconciliation(
  td_inv_rec_medication_tcid_76306.PatientInfo,
  undefined,
  td_inv_rec_medication_tcid_76306.MedicationInfo
);

/* const values */
const OR_TRACKERS = OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS;

export class InvRecMedicationTcId76306 {
  VerifyMedicationInputFieldValues() {
    let input = '',
      expectedTypedText = '',
      inputNum = '';
    describe('Verify Medications Layout Fields Cannot take alphabets and accepts only Numerics', () => {
      it('Verify Administered cant take alphabets and only numbers are accepted as input when alphanumeric values are passed to fields', () => {
        // #region - Enter and verify Administered in Inv Reconciliation tracker Medication module

        cy.cGroupAsStep(
          'Enter and verify Administered in Inv Reconciliation tracker Medication module'
        );

        /*****************Select Tracker Inventory Reconciliation***************/

        sisOfficeDesktop.selectTracker(OR_TRACKERS.INVENTORY_RECONCILIATION[0]);

        // Select The Patient
        inventoryReconciliation.selectPatientRow();

        // Enter Administered And Verify
        inventoryReconciliation.medicationModel!.forEach((medicationInfo) => {
          input = CommonUtils.generateUniqueString(6, StringType.ALPHABETS);
          inputNum = `${CommonUtils.generateUniqueString(
            2,
            StringType.ALPHABETS
          )}${CommonUtils.generateUniqueString(4, StringType.NUMERIC)}`;
          expectedTypedText = CommonUtils.getNumbersFromString(inputNum);
          inventoryReconciliation.enterAdministeredValueForMedications(
            medicationInfo.Medication!,
            input,
            10
          );
          inventoryReconciliation.verifyAdministeredValueForMedications(
            medicationInfo.Medication!,
            '',
            10
          );
          // #endregion

          // #region - Enter and verify Wasted in Inv Reconciliation tracker Medication module

          cy.cGroupAsStep(
            'Enter and verify Wasted in Inv Reconciliation tracker Medication module'
          );

          // Enter Wasted and Verify
          inventoryReconciliation.enterWastedValueForMedications(
            medicationInfo.Medication!,
            input
          );
          inventoryReconciliation.verifyWastedValueForMedications(
            medicationInfo.Medication!,
            ''
          );
          // #endregion

          // #region - Enter and verify Usage Total in Inv Reconciliation tracker Medication module

          cy.cGroupAsStep(
            'Enter and verify Usage Total in Inv Reconciliation tracker Medication module'
          );

          // Enter Usage Total and verify
          inventoryReconciliation.enterUsageTotalValueForMedications(
            medicationInfo.Medication!,
            input
          );
          inventoryReconciliation.verifyUsageTotalValueForMedication(
            medicationInfo.Medication!,
            ''
          );

          // #endregion

          // #region - Enter and verify Only Numbers from alphanumeric values has been accepted in Administered field

          cy.cGroupAsStep(
            'Enter and verify Only Numbers from alphanumeric values has been accepted in Administered field'
          );

          // Administered Takes only numbers as input
          inventoryReconciliation.enterAdministeredValueForMedications(
            medicationInfo.Medication!,
            inputNum,
            2
          );

          inventoryReconciliation.verifyAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${expectedTypedText}`,
            2
          );
          // #endregion

          // #region - Enter and verify Only Numbers from wasted values has been accepted in Administered field

          cy.cGroupAsStep(
            'Enter and verify Only Numbers from wasted values has been accepted in Administered field'
          );

          expectedTypedText = CommonUtils.getNumbersFromString(inputNum, 2);
          // Wasted Takes only numbers as input
          // Enter Wasted and Verify
          inventoryReconciliation.enterWastedValueForMedications(
            medicationInfo.Medication!,
            inputNum,
            2
          );

          inventoryReconciliation.verifyWastedValueForMedications(
            medicationInfo.Medication!,
            `${expectedTypedText}`,
            2
          );
          // #endregion

          // #region - Enter and verify Only Numbers from alphanumeric values has been accepted in Usage Total field

          cy.cGroupAsStep(
            'Enter and verify Only Numbers from alphanumeric values has been accepted in Usage Total field'
          );

          // Used Total Takes only numbers as input
          // Enter Used Total and verify
          inventoryReconciliation.enterUsageTotalValueForMedications(
            medicationInfo.Medication!,
            inputNum,
            2
          );
          inventoryReconciliation.verifyUsageTotalValueForMedication(
            medicationInfo.Medication!,
            `${expectedTypedText}`,
            2
          );
          // #endregion
        });
      });
    });
  }

  VerifyAdministeredForDigits() {
    let input = '',
      expectedTypedText = '',
      inputNum = '',
      expectedText = '';
    describe('Verify Administered input field in Medication Table allows only 6 digits before decimal', () => {
      it('Verify Administered allows only 6 digits before decimal separated by comma like ###,###', () => {
        // #region - Enter and verify Administered Takes 6 digits before dot and 2 digits after dot, format = ###,###.##
        // Test value after pressing 7 digits, it should be only first 6 digits before decimal and 2 digits after decimal

        cy.cGroupAsStep(
          'Enter and verify Administered Takes 6 digits before dot and 2 digits after dot, format = ###,###.##'
        );
        inventoryReconciliation.medicationModel!.forEach((medicationInfo) => {
          input = CommonUtils.generateUniqueString(7, StringType.NUMERIC);
          expectedTypedText = `${input.substring(0, 3)},${input.substring(
            3,
            6
          )}.00`;
          inputNum = CommonUtils.generateUniqueString(6, StringType.NUMERIC);
          expectedText = `${inputNum.substring(0, 3)},${inputNum.substring(
            3,
            6
          )}`;
          // Administered Takes 6 digits before dot and 2 digits after dot, format = ###,###.##
          inventoryReconciliation.enterAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${input}{enter}`,
            4
          );
          inventoryReconciliation.verifyAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${expectedTypedText}`,
            4
          );
          // Administered Takes 6 digits before dot and 2 digits after dot, format = ###,###.##
          inventoryReconciliation.enterAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${inputNum}.999{enter}`
          );
          inventoryReconciliation.verifyAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${expectedText}.99`
          );
          inventoryReconciliation.enterAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${inputNum}.001{enter}`
          );

          inventoryReconciliation.verifyAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${expectedText}.00`
          );
          inventoryReconciliation.enterAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${inputNum}.100{enter}`
          );

          inventoryReconciliation.verifyAdministeredValueForMedications(
            medicationInfo.Medication!,
            `${expectedText}.10`
          );
          // #endregion
        });
      });
    });
  }

  VerifyWastedAndUsedTotalFields() {
    let input = '',
      expectedTypedText = '';
    describe('Verify Wasted Input Field in Medication Layout accepts data in format ##.##', () => {
      it('Verify Wasted allows only 2 digits before decimal and 2 digits after decimal', () => {
        // #region - Enter and verify Wasted Takes 2 digits before dot and 2 digits after dot, format = ##.##

        inventoryReconciliation.medicationModel!.forEach((medicationInfo) => {
          input = CommonUtils.generateUniqueString(6, StringType.NUMERIC);
          expectedTypedText = `${input.substring(0, 2)}`;
          cy.cGroupAsStep(
            'Enter and verify Wasted Takes 2 digits before dot and 2 digits after dot, format = ##.##'
          );
          // Wasted Takes 2 digits before dot and 2 digits after dot, format = ##.##
          // Enter Wasted and Verify
          inventoryReconciliation.enterWastedValueForMedications(
            medicationInfo.Medication!,
            `${input}.09`
          );

          inventoryReconciliation.verifyWastedValueForMedications(
            medicationInfo.Medication!,
            `${expectedTypedText}.09`
          );
          // Wasted Takes 2 digits before dot and 2 digits after dot, format = ##.##
          // Enter Wasted and Verify
          inventoryReconciliation.enterUsageTotalValueForMedications(
            medicationInfo.Medication!,
            `${input}.099`
          );

          inventoryReconciliation.verifyUsageTotalValueForMedication(
            medicationInfo.Medication!,
            `${expectedTypedText}.09`
          );
          // #endregion
        });
      });
    });
  }
}
