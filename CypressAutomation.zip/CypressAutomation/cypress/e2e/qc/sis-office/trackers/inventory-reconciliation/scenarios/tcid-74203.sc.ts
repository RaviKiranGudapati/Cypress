/****Revision History **************
 * 20/06/22, Debasish, Updated and applied best practices to be followed during script development
 */

import {
  CommonUtils,
  StringType,
} from '../../../../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { SubRoutes } from '../../../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { td_inv_rec_implant_tcid_74203 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/inv-rec-implant-tcid-74203.td';

import { Implant } from '../../../../../../test-data-models/sis-office/trackers/inv-reconciliation.model';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';

import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const inventoryReconciliation = new InventoryReconciliation(
  td_inv_rec_implant_tcid_74203.PatientInfo,
  td_inv_rec_implant_tcid_74203.ImplantInfo
);

export class InvRecImplantTcId74203 {
  verifyInventoryReconImplantTable() {
    describe('Verifying Inventory Reconciliation Implant Table Layout for Pulling Implants in the Implants Modal Window', () => {
      it('Verifying Inventory Reconciliation Implant Table Layout for Pulling Implants in the Implants Modal Window', () => {
        /***Schema Reference as defined APPSO Constants*/
        let inventorySchema =
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY;

        let trackerSchema = OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS;

        // #region - Navigate to Inventory Reconciliation tracker

        cy.cGroupAsStep('Navigate to Inventory Reconciliation tracker');

        // Select The Tracker From Desktop API
        sisOfficeDesktop.selectTracker(
          trackerSchema.INVENTORY_RECONCILIATION[0]
        );
        // #endregion

        // #region - Select patient in inv reconciliation tracker

        cy.cGroupAsStep('Select patient in inv reconciliation tracker');

        // Select The Patient
        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implants Saved in work list are reflected on UI and updated after resetting implant info

        cy.cGroupAsStep(
          'Verify Implants Saved in work list are reflected on UI and updated after resetting implant info'
        );

        // Verify Implants Saved in work list are reflected on UI and updated after resetting implant info
        inventoryReconciliation.implantModel!.forEach((impRecord: Implant) => {
          let randUsedNumber = CommonUtils.generateUniqueString(
            3,
            StringType.NUMERIC
          );
          let expectedUsedNumber = randUsedNumber.substring(0, 2);
          inventoryReconciliation.verifyImplantsAppearOnScreen(
            td_inv_rec_implant_tcid_74203.ImplantInfo[0].Implant[0]
          );
          inventoryReconciliation.enterUsedValueForImplant(
            td_inv_rec_implant_tcid_74203.ImplantInfo[0].Implant[0],
            randUsedNumber
          );
          inventoryReconciliation.verifyUsedValueForImplant(
            td_inv_rec_implant_tcid_74203.ImplantInfo[0].Implant[0],
            expectedUsedNumber
          );
          inventoryReconciliation.enterUsedValueForImplant(
            td_inv_rec_implant_tcid_74203.ImplantInfo[0].Implant[0],
            impRecord.Used
          );
          inventoryReconciliation.selectImplant(
            td_inv_rec_implant_tcid_74203.ImplantInfo[0].Implant[0]
          );

          // Verify Quantity, which is same set in Used
          sisOfficeDesktop.verifyValue(
            inventorySchema.ADD_IMPLANTS_PROSTHETIC_POPUP.QUANTITY[1],
            inventorySchema.ADD_IMPLANTS_PROSTHETIC_POPUP.QUANTITY[0],
            impRecord.Used
          );
          // #endregion

          // #region - Add an implant and click Done Button

          cy.cGroupAsStep('Add an implant and click Done Button');

          inventoryReconciliation.addImplantOrProstheticInfo(impRecord);
          inventoryReconciliation.clickAddImplantProstheticDoneBtn();
          // #endregion

          // #region - Select the added implant, verify the fields and click done button

          cy.cGroupAsStep(
            'Select the added implant, verify the fields and click done button'
          );

          inventoryReconciliation.selectImplant(
            td_inv_rec_implant_tcid_74203.ImplantInfo[0].Implant[0]
          );
          inventoryReconciliation.verifyImplantOrProstheticInfo(impRecord);
          inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        });
        // #endregion

        // #region - Click Done Button in Inv Reconciliation tracker

        cy.cGroupAsStep('Click Done Button in Inv Reconciliation tracker');

        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region - Navigating back to schedule grid

        cy.cGroupAsStep('Navigating back to schedule grid');

        // Navigate back to schedule grid before logout
        cy.cWait(SubRoutes.case_request_get_pending_count);
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cWait(SubRoutes.case_request_get_pending_count);
        // #endregion
      });
    });
  }
}
