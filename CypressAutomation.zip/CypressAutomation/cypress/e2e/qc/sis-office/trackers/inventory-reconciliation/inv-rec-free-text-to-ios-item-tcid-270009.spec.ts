import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { InvRecFreeTextToIosItemTcId270009 } from './scenarios/tcid-270009.sc';

/* instance variables */
const invRecFreeTextToIosItem = new InvRecFreeTextToIosItemTcId270009();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify the modified units from Coding or Charge Entry Tracker are updating correctly in Inventory reconciliation tracker with iOS Item and quantity for General case
 * US - 263745 - Inventory Tracker - Free Text Items
 * Script Execution Approach -
 * 1. Navigate to Nursing Desktop
 * 2. Selecting Patient Row
 * 3. Navigate to Operative Department
 * 4. Navigate to WorkList Task Panel in Operative Department
 * 5. Add Free Text Implant and Supply
 * 6. Sign the Department and Patient Case.
 * 7. Navigate to Inventory Reconciliation Tracker
 * 8. Selecting Patient Row
 * 9. Verify Free Text Implant and Supply Name with Details
 * 10. Verify Free Text Tooltip Text
 * 11. Convert Free Text Implant and Supply to IOS Inventory Item
 * 12. Verify Inventory Item Tooltip Text
 * 13. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 14. Deplete the Patient Case by selecting Depletion Verified as Yes and clicking on Done.
 * 15. Navigate to Coding Tracker.
 * 16. Selecting Patient Row
 * 17. Verify Inventory Item with Units.
 * 18. Update Units for Inventory Items
 * 19. Make Case as Ready for Charge by clicking Yes and Done button
 * 20. Navigate to Inventory Reconciliation Tracker
 * 21. Selecting Patient Row
 * 22. Verify IOS Item which is converted from Free Text to IOS Item.
 * 23. Verify Update Label with Tooltip Text
 * 24. Verify Display icon with free text as description
 * 25. Verify Total Depleted, Used, Billed Quantity.
 * 26. Verify Discrepancy Warning Message where Used and Billed quantity are not same.
 * 27. Update Used quantity (Total Depleted + Used) which is equal to Billed quantity.
 * 27. Deplete the Patient Case by selecting Depletion Verified as Yes and clicking on Done.
 * 29. Navigate to Charge Entry Tracker.
 * 30. Selecting Patient Row
 * 31. Verify Inventory Item with Units
 * 32. Update Units for Inventory Items
 * 33. Make Case as Ready for Bill by clicking Yes and Done button
 * 34. Navigate to Inventory Reconciliation Tracker
 * 35. Selecting Patient Row
 * 36. Verify IOS Item which is converted from Free Text to IOS Item.
 * 37. Verify Update Label with Tooltip Text
 * 38. Verify Display icon with free text as description
 * 39. Verify Total Depleted, Used, Billed Quantity.
 * 40. Verify Discrepancy Warning Message where Used and Billed quantity are not same.
 * 41. Update Used quantity (Total Depleted + Used) which is equal to Billed quantity.
 * 42. Deplete the Patient Case by selecting Depletion Verified as Yes and clicking on Done.
 * 43. Navigate to Patient face-sheet.
 * 44. Navigate to Inventory Face-sheet Tab.
 * 45. Verify Inventory Item Tooltip Text
 * 46. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 47. Verify Tooltip Icon with Free Text as Description
 * 48. Navigate to Nursing Desktop
 * 49. Select Patient From Schedule Grid
 * 50. Select Operative Department
 * 51. Un-Sign Operative Department
 * 52. Verify Tooltip Text with IOS Inventory Item on mouse hover of Free Text Item
 * 53. Sign Operative Department
 * 54. Navigate to Home Page of Nursing Desktop
 * 55. logout
 */

describe(
  'Verify the modified units from Coding/charge entry tracker are updating correctly in Inventory reconciliation tracker with iOS Item and quantity ',
  {
    tags: ['inventory-reconciliation', 'TC#270009', 'US#263745'],
  },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_8[0],
        Password: UserList.GEM_USER_8[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        invRecFreeTextToIosItem.addFreeTextItemInOperative();
        invRecFreeTextToIosItem.verifyImplantSuppliesInInventory();
        invRecFreeTextToIosItem.updateFreeTextItemToIosInventoryItem();
        invRecFreeTextToIosItem.verifyAndUpdateImplantSuppliesInCoding();
        invRecFreeTextToIosItem.verifyUpdatedCodingInventoryItemsInInventory();
        invRecFreeTextToIosItem.verifyAndUpdateImplantSuppliesInChargeEntry();
        invRecFreeTextToIosItem.verifyUpdatedChargeEntryInventoryItemsInInventory();
        invRecFreeTextToIosItem.verifyImplantSuppliesInFaceSheetInventory();
        invRecFreeTextToIosItem.verifyIosImplantSupplyInOperative();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
