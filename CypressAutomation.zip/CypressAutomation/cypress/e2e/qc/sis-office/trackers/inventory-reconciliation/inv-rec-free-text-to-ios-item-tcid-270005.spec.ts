import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { InvRecFreeTextToIosItemTcId270005 } from './scenarios/tcid-270005.sc';

/* instance variables */
const invRecFreeTextToIosItem = new InvRecFreeTextToIosItemTcId270005();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify the Free text Item description is displaying on hovering from Inventory tracker for Business case
 * US - 263745 - Inventory Tracker - Free Text Items
 * Script Execution Approach -
 * 1. Navigating to Application Settings
 * 2. Select Preference Card in Preference Card Configuration
 * 3. Add Free Tex Implant and Free Text Supply
 * 4. Navigate to Schedule Grid in SIS Office
 * 5. Select Patient From Schedule Grid
 * 6. Click on Arrive Button
 * 7. Navigate to Clinical Documentation Tracker
 * 8. Selecting Patient Row
 * 9. Perform the Case.
 * 10. Navigate to Inventory Reconciliation Tracker
 * 11. Selecting Patient Row
 * 12. Verify Free Text Implant and Supply Name with Details
 * 13. Verify Free Text Tooltip Text
 * 14. Convert Free Text Implant and Supply to IOS Inventory Item
 * 15. Verify Inventory Item Tooltip Text
 * 16. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 17. Save the Patient Case by clicking on Done.
 * 18. Selecting Patient Row in Inventory Reconciliation Tracker
 * 19. Verify Inventory Item Tooltip Text and Verify Tooltip Icon with Free Text as Description
 * 20. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 21. Save the Patient Case by clicking on Done.
 * 23. Navigate to Coding Tracker.
 * 24. Selecting Patient Row
 * 25. Verify Inventory Item with Units.
 * 26. Make Case as Ready for Charge by clicking Yes and Done button
 * 27. Navigate to Charge Entry Tracker.
 * 28. Selecting Patient Row
 * 29. Verify Inventory Item with Units
 * 30. Make Case as Ready for Bill by clicking Yes and Done button
 * 31. Navigate to Patient face-sheet.
 * 32. Navigate to Inventory Face-sheet Tab.
 * 33. Verify Inventory Item Tooltip Text
 * 34. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 35. Verify Tooltip Icon with Free Text as Description
 * 36. logout
 */

describe(
  'Verify the Free text Item description is displaying on hovering from Inventory tracker for Business case ',
  {
    tags: ['inventory-reconciliation', 'TC#270005', 'US#263745'],
  },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_CDM1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        invRecFreeTextToIosItem.addFreeTextItemPreferenceCard();
        invRecFreeTextToIosItem.performPatientCase();
        invRecFreeTextToIosItem.verifyImplantSuppliesInInventory();
        invRecFreeTextToIosItem.updateFreeTextItemToIosInventoryItem();
        invRecFreeTextToIosItem.verifyUpdatedIosInventoryItem();
        invRecFreeTextToIosItem.verifyImplantSuppliesInCoding();
        invRecFreeTextToIosItem.verifyImplantSuppliesInChargeEntry();
        invRecFreeTextToIosItem.verifyImplantSuppliesInFaceSheetInventory();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
