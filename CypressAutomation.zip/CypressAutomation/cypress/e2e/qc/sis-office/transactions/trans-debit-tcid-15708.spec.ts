/**Revision History
 * 24/08/22, Praveen, Ravi, Prashanth, Spec to implement scenario - TCID - 15708, Verify debit information in Transaction page.
 */

import { transactionalAPIs } from '../../../../support/common-core-libs/application/transactional-apis';

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';
import { td_trans_debit_tcid_15708 } from '../../../../fixtures/sis-office/transactions/trans-debit-tcid-15708.td';

import { DebitTransactionTcId15708 } from './scenarios/tcid-15708.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const debitTransaction = new DebitTransactionTcId15708();

//SHIFT + ALT + O - Organizing the import
/*Test Script Validation Details *****
 * The spec file have dependency on seed data. Before executing the spec file,user should remove child transactions like debit,writeoff.. etc.,if present.
 * Script Execution Details -
 * Verifying UI content in debit modal window and debit transactions data.
 * Note: Two cases should be created through seed data. First case should be performed and Ready To Bill,Second case should be upto performed state.
 * Script Execution Approach -
 * 1. Search and select the first case in global search
 * 2. Navigate to transaction page and Verify warning text message “Please select a charge.” when not selected the charge.
 * 3. Verify the labels in Debit modal window on click Debits icon and close the Debit modal window.
 * 4. Select the charge and perform the debit transaction.
 * 5. Data should be saved and check Balance due amount in charge level.
 * 6. Search and select the second case in global search
 * 7. Navigate to Transaction page and verify the 'No charges are found' message is displayed.
 * 8. Verify that the Debit icon is disabled as there are no charges to select.
 ************************************************************************/

describe(
  'Verify Business Facesheet Transactions - Debit Icon, Debit popup and posting Debit Transaction',
  { tags: ['transactions', 'US#7882', 'US#11023', 'TC#15708'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_21[0],
        Password: UserList.GEM_USER_21[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_21, userLogin);
      transactionalAPIs
        .API_Login(
          UserList.GEM_USER_21[0],
          UserList.GEM_USER_21[1],
          OrganizationList.GEM_ORG_21
        )
        .then(() => {
          transactionalAPIs.API_DeleteTransaction(
            td_trans_debit_tcid_15708.PatientCase[0].PatientDetails
              .PatientFirstName,
            td_trans_debit_tcid_15708.PatientCase[0].PatientDetails.LastName,
            '2019-08-31',
            '2022-09-07'
          );
        });
    });

    //After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        //'Verify the warning text message in Debit popup'
        debitTransaction.verifyWarningMessageDebitPopup();

        //'Verify border color of Charges after selecting cpt code'
        debitTransaction.verifyBorderColor();

        //'Verify Debit Popup Label Names'
        debitTransaction.verifyDebitPopupLabelNames();

        //'Verify the balance due amount when user perform the debit transaction'
        debitTransaction.verifyBalanceAmount();

        //'Verify warning text when no charges found in transaction page'
        debitTransaction.verifyNoCharges();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
