import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';
import { WriteOffZeroBalanceTcId267775 } from './scenarios/tcid-267775.sc';

/* instance variables */
const writeOffZeroBalance = new WriteOffZeroBalanceTcId267775();

//SHIFT + ALT + O - Organizing the import
/*Test Script Validation Details *****
 * Script Execution Approach -
 * 1. Search and select the patient in global search and navigate to transactions screen
 * 2. Make payment for the charge-1 with zero balance, charge-2 with less than zero and charge-3 with greater than zero.
 * 3. Verify charge-1 and charge-2 is having banner in writeoff
 * 4. verify zero or less than zero charges should not allow payment for transaction type write-off.
 *  * ************************************************************************/

describe(
  'Verify to prevent addition of write-off to charge with $0 balance or credit balance',
  { tags: ['transactions', 'US#243416', 'TC#267775'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/

      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    //After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        writeOffZeroBalance.verifyWriteOffDisabled();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
