import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';

import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_trans_delete_edit_tcid_265829 } from '../../../../../fixtures/sis-office/transactions/trans-edit-delete-menu-tcid-265829.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import FacesheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import Transactions, {
  ContextMenu,
  TransactionsValues,
  TransactionHeaders,
} from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import SISCompleteLogin from '../../../../../app-modules-libs/sis-office/login/login';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const facesheetChargeEntry = new FacesheetChargeEntry();
const transactions = new Transactions();
const faceSheetCases = new FaceSheetCases(
  td_trans_delete_edit_tcid_265829.PatientCase[0]
);

/* const values */
const disabled = CoreCssClasses.Ng.loc_untouched_value;
const insuranceName = 'BCarrier265829';

export class EditAndDeletePaymentTcId265829 {
  verifyEditAndDeleteFunctionality() {
    describe('Verify the Delete and Edit functionality in Transaction', () => {
      it('Verify Edit and Delete Functionality for Payment, write-off, Debit in transaction', () => {
        // #region Verify Edit and Delete Functionality for Payment, write-off, Debit in transaction.

        cy.cGroupAsStep(
          'Search the patient 1 in global search and click on the Transaction Icon'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          td_trans_delete_edit_tcid_265829.PatientCase[0].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        // #endregion

        // #region Select Cpt and enter data in payment

        cy.cGroupAsStep('Select Cpt and enter data in payment');
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.paymentsPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Payments
        );
        transactions.clickDoneInPayment();
        // #endregion

        // #region User should be able to verify view/edit pop-up

        cy.cGroupAsStep('User should be able to verify view/edit pop-up');
        transactions.clickContextMenuOptionsItems(
          0,
          ContextMenu.delete
        );
        transactions.verifyTransactionDeletePopUp(
          TransactionsValues.payment,
          AppErrorMessages.transaction_delete_payment
        );
        // #endregion

        // #region -  User should be able to click Yes and No Button for delete Payment

        cy.cGroupAsStep(
          'User should be able to click Yes and No Button for delete Payment'
        );
        transactions.clickYesOrNoInDeletePopUp(YesOrNo.no);
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[0]
            .BalanceDue
        );
        transactions.clickContextMenuOptionsItems(
          0,
          ContextMenu.delete
        );
        transactions.clickYesOrNoInDeletePopUp(YesOrNo.yes);
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[0]
            .BalanceDue
        );
        // #endregion

        // #region -  Search the patient and enter the mandatory field in Debit

        cy.cGroupAsStep(
          'Search the patient and enter the mandatory field in Debit'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );
        transactions.transferToNextParty(YesOrNo.no);
        transactions.debitPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Debits[0]
        );
        // #endregion

        // #region -  User should able to perform yes or no for delete operation in debit

        cy.cGroupAsStep(
          'User should able to perform yes or no for delete operation in debit'
        );
        transactions.clickContextMenuOptionsItems(
          1,
          ContextMenu.delete
        );
        transactions.verifyTransactionDeletePopUp(
          TransactionsValues.debit,
          AppErrorMessages.transaction_delete_debit
        );
        transactions.clickYesOrNoInDeletePopUp(YesOrNo.no);
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[2]
            .BalanceDue
        );
        transactions.clickContextMenuOptionsItems(
          1,
          ContextMenu.delete
        );
        transactions.clickYesOrNoInDeletePopUp(YesOrNo.yes);
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[2]
            .BalanceDue
        );
        // #endregion

        // #region -  Search the patient and enter the mandatory field in Write off
        cy.cGroupAsStep(
          'Search the patient and enter the mandatory field in Write off'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );
        transactions.transferToNextParty(YesOrNo.no);
        transactions.writeoffPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs
        );
        // #endregion

        // #region -  User should able to perform yes or no for delete operation in Write off
        cy.cGroupAsStep(
          'User should able to perform yes or no for delete operation in Write off'
        );
        transactions.clickContextMenuOptionsItems(
          1,
          ContextMenu.delete
        );
        transactions.verifyTransactionDeletePopUp(
          TransactionsValues.writeoff,
          AppErrorMessages.transaction_delete_writeoff
        );
        transactions.clickYesOrNoInDeletePopUp(YesOrNo.no);
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[3]
            .BalanceDue
        );
        transactions.clickContextMenuOptionsItems(
          1,
          ContextMenu.delete
        );
        transactions.clickYesOrNoInDeletePopUp(YesOrNo.yes);
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[1]
            .BalanceDue
        );
        // #endregion

        // #region -  Search the patient2 go to transaction enter the payment field and make correction
        cy.cGroupAsStep(
          'Search the patient2 go to transaction enter the payment field and make correction'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        sisOfficeDesktop.pickPatient(
          td_trans_delete_edit_tcid_265829.PatientCase[1].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.paymentsPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Payments
        );
        transactions.clickDoneInPayment();
        transactions.clickContextMenuOptionsItems(
          0,
          ContextMenu.correction
        );
        transactions.enterNewAllocationAmount(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Payments
            .AllocationAmount
        );
        transactions.clickDoneButton();
        // #endregion

        // #region -  User should be able to enter data in Debit field and click on correction

        cy.cGroupAsStep(
          'User should be able to enter data in Debit field and click on correction'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );
        transactions.transferToNextParty(YesOrNo.no);
        transactions.debitPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Debits[0]
        );
        transactions.clickContextMenuOptionsItems(
          3,
          ContextMenu.correction
        );
        transactions.enterNewAllocationAmount(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Payments
            .AllocationAmount
        );
        transactions.clickDoneButton();
        // #endregion

        // #region -  User should be able to enter data in Write-Off and click on correction

        cy.cGroupAsStep(
          'User should be able to enter data in Write-Off and click on correction'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );
    
        transactions.transferToNextParty(YesOrNo.no);
        transactions.writeoffPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs
        );
        transactions.clickContextMenuOptionsItems(
          5,
          ContextMenu.correction
        );
        transactions.enterNewAllocationAmount(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Payments
            .AllocationAmount
        );
        transactions.clickDoneButton();
        // #endregion

        // #region -  Verifying the delete option in payment, Debit, Write-off

        cy.cGroupAsStep(
          'Verifying the delete option in payment, Debit, Write-off'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyTransactionContextMenuOptions(
          0,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          false
        );
        transactions.verifyTransactionContextMenuOptions(
          3,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          false
        );
        transactions.verifyTransactionContextMenuOptions(
          5,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          false
        );
        // #endregion

        // #region -  Search the patient3 and document all the data in Payment, Debit, Write-off and verify Delete option in Context Menu

        cy.cGroupAsStep(
          'Search the patient3 and document all the data in Payment, Debit, Write-off and verify Delete option in Context Menu'
        );
        cy.reload();
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        sisOfficeDesktop.pickPatient(
          td_trans_delete_edit_tcid_265829.PatientCase[2].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        cy.reload();
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.paymentsPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Payments
        );
        transactions.clickDoneInPayment();
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );
        transactions.transferToNextParty(YesOrNo.no);
     
        transactions.debitPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Debits[0]
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );
        transactions.transferToNextParty(YesOrNo.no);
    
        transactions.writeoffPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs
        );
        transactions.verifyTransactionContextMenuOptions(
          0,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          true
        );
        transactions.verifyTransactionContextMenuOptions(
          2,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          true
        );
        transactions.verifyTransactionContextMenuOptions(
          3,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          true
        );
        // #endregion

        // #region -  Click on Edit Debit Context Menu and Verify and Enter the field and click on Done button

        cy.cGroupAsStep(
          'Click on Edit Debit Context Menu and Verify and Enter the field and click on Done button'
        );
        transactions.clickContextMenuOptionsItems(
          2,
          ContextMenu.view_edit
        );
        transactions.verifyEditDebitHeader(TransactionHeaders.edit_debit);
        transactions.verifyEditDebitPopup(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Debits[0].Period
        );
        transactions.verifyEditDebitPopup(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Debits[0].Batch
        );
        transactions.verifyEditDebitPopup(insuranceName);
        transactions.verifyEditDebitPopup(
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[1]
            .BalanceDue
        );
        transactions.verifyEditDebitPopup(
          td_trans_delete_edit_tcid_265829.CaseTransaction.ChargesData[3]
            .BalanceDue
        );
        transactions.verifyEditDebitPopup(
          td_trans_delete_edit_tcid_265829.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.verifyTransferToNextPartyState(disabled);
        transactions.debitPopupPostTransaction(
          td_trans_delete_edit_tcid_265829.CaseTransaction.Debits[1], YesOrNo.none
        );
        cy.reload();
        // #endregion

        // #region -  Navigate to ledger tab and enter unassigned amount, allocated amount navigate to transaction and delete allocation amount

        cy.cGroupAsStep(
          'Navigate to ledger tab and enter unassigned amount, allocated amount navigate to transaction and delete allocation amount'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_trans_delete_edit_tcid_265829.UnassignedPayment
        );
        ledgerTabFaceSheet.clickOnContextMenu(
          td_trans_delete_edit_tcid_265829.UnassignedPayment
            .TransactionCode!,
          OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
        );
        /* Allocate the amount based on the cpt code and select the transaction code in Allocation popup */
        ledgerTabFaceSheet.amountAllocation(
          td_trans_delete_edit_tcid_265829.UnAssignedAllocationData
            .AmountAllocation,
          td_trans_delete_edit_tcid_265829.UnAssignedAllocationData.CPTHCPCSCode
        );
        ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
            .COLUMN_FOUR_TRANSACTION_CODE[0],
          td_trans_delete_edit_tcid_265829.UnAssignedAllocationData
            .TransactionCode
        );
        ledgerTabFaceSheet.clickOnAllocateUnassignedPaymentDone();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.pickPatient(
          td_trans_delete_edit_tcid_265829.PatientCase[2].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.clickContextMenuOptionsItems(
          4,
          ContextMenu.delete
        );
        transactions.clickYesOrNoInDeletePopUp(YesOrNo.yes);
        // #endregion

        // #region -  Correct the main charge and verify the delete option

        cy.cGroupAsStep('Correct the main charge and verify the delete option');
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.clickChargeContextMenuOption(0, OR_TRANSACTION.VIEW_EDIT);
        transactions.clickDoneButton();
        transactions.verifyTransactionContextMenuOptions(
          0,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          true
        );
        // #endregion

        // #region -  Navigate to Charge Entry add another procedure and delete billed procedure

        cy.cGroupAsStep(
          'Navigate to Charge Entry add another procedure and delete billed procedure'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.pickPatient(
          td_trans_delete_edit_tcid_265829.PatientCase[2].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        facesheetChargeEntry.addProcedure(
          td_trans_delete_edit_tcid_265829.CptCodeInfo[0]
        );
        facesheetChargeEntry.clickUpdateButton();
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        facesheetChargeEntry.deleteCharge(
          td_trans_delete_edit_tcid_265829.CptCodeInfo[1]
        );
        // #endregion
      });
    });
  }

  verifyDeleteOptionInTransactionContextMenu() {
    describe('Verifying the Delete option in transaction context menu', () => {
      it('Verify the delete option should not display in context menu as the user does not have the Delete Permission', () => {
        // #region - Logging into Business Desktop with Gem_userDNo_FM and verify Delete Option

        cy.cGroupAsStep(
          'Logging into Business Desktop with Gem_userDNo_FM and verify Delete Option'
        );
        cy.cLogOut();
        cy.reload();
        /**********Login To Application***********/
        const login = new SISCompleteLogin();
        login.login(
          UserList.GEM_USERVCMNO_D[0],
          UserList.GEM_USERVCMNO_D[1],
          OrganizationList.GEM_ORG_21
        );
        sisOfficeDesktop.pickPatient(
          td_trans_delete_edit_tcid_265829.PatientCase[1].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyTransactionContextMenuOptions(
          0,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          false
        );
        transactions.verifyTransactionContextMenuOptions(
          3,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          false
        );
        transactions.verifyTransactionContextMenuOptions(
          5,
          td_trans_delete_edit_tcid_265829.CaseTransaction.WriteOffs.Delete,
          false
        );
        sisChartsDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
