import { ExpandOrCollapse } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_trans_writeoff_zerobalance_tcid_267775 } from '../../../../../fixtures/sis-office/transactions/trans-writeoff-zerobalance.tcid-267775.td';

import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const faceSheetCases = new FaceSheetCases();

/* cons values */
const number200 = '200';
const number2 = 2;

export class WriteOffZeroBalanceTcId267775 {
  verifyWriteOffDisabled() {
    describe('Verify preventing addition of write-off to charge with $0 balance or credit balance in Facesheet Transactions', () => {
      it('Verify Warning Message appears in Write-Off pop-up and Write-Off value is disabled in payment for zero or less than zero charges ', () => {
        // #region - Make payment for the charges in Transactions

        cy.cGroupAsStep(
          'Make payment for the charges to make greater than, less than or zero in transactions.'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_trans_writeoff_zerobalance_tcid_267775.PatientCase[0]
            .PatientDetails
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.selectCPTCode(
          td_trans_writeoff_zerobalance_tcid_267775.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.paymentsPopupPostTransaction(
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction
            .PaymentInfo[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction
            .PaymentInfo[1]
        );
        transactions.selectTransactionValuesInPayments(
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction
            .PaymentInfo[2]
        );
        transactions.clickDoneInPayment();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        // #endregion

        // #region - Verify Warning message for less than or zero charges in Write-Off pop-up.
        cy.cGroupAsStep(
          'Verify Warning message for less than or zero charges in Write-Off pop-up.'
        );
        transactions.selectCPTCode(
          td_trans_writeoff_zerobalance_tcid_267775.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );

        transactions.verifyWarningMessageInWriteOff();
        transactions.verifyDoneButton();

        transactions.transactionDebitEnterDebitAmount(number200);
        transactions.transactionWriteoffPopupSelectDropdownValue(
          OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.WRITEOFF_TRANS_CODE[0],
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction.WriteOffInfo
            .WriteoffTransactionCode
        );
        transactions.verifyDoneButton();

        sisOfficeDesktop.clickCloseIcon();

        transactions.selectCPTCode(
          td_trans_writeoff_zerobalance_tcid_267775.PatientCase[0].CaseDetails
            .CptCodeInfo[1].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );

        transactions.verifyWarningMessageInWriteOff();
        transactions.verifyDoneButton();

        transactions.transactionDebitEnterDebitAmount(number200);
        transactions.transactionWriteoffPopupSelectDropdownValue(
          OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.WRITEOFF_TRANS_CODE[0],
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction.WriteOffInfo
            .WriteoffTransactionCode
        );
        transactions.verifyDoneButton();

        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        // #region - Verify Write-Off for all the charges in payment pop-up.
        cy.cGroupAsStep(
          'Verify Write-Off option disabled for zero or less than zero charges and enabled for greater than zero charge in payments'
        );

        transactions.selectCPTCode(
          td_trans_writeoff_zerobalance_tcid_267775.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.verifyTransactionTypeValueDisabledInPayment(
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction
            .PaymentInfo[0]
        );

        transactions.verifyTransactionTypeValueDisabledInPayment(
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction
            .PaymentInfo[1]
        );
        sisOfficeDesktop.clickCloseIcon();
        transactions.selectCPTCode(
          td_trans_writeoff_zerobalance_tcid_267775.PatientCase[0].CaseDetails
            .CptCodeInfo[2].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction
            .PaymentInfo[2]
        );
        transactions.clickDoneInPayment();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        transactions.verifyTypeCountForCharge(
          td_trans_writeoff_zerobalance_tcid_267775.PatientCase[0].CaseDetails
            .CptCodeInfo[2].CPTCodeAndDescription,
          td_trans_writeoff_zerobalance_tcid_267775.CaseTransaction
            .PaymentInfo[2].TransactionType,
          number2
        );
        // #endregion
      });
    });
  }
}
