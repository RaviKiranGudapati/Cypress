import { ExpandOrCollapse } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import BalanceReconciliation from '../../../../../app-modules-libs/sis-office/trackers/bal-reconciliation';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';

import { td_trans_balancedue_tcid_261981 } from '../../../../../fixtures/sis-office/transactions/trans-balancedue-tcid-261981.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(
  td_trans_balancedue_tcid_261981.PatientCase[0]
);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const transactions = new Transactions();
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const ledgerTabFacesheet = new LedgerTabFaceSheet();
const balanceReconciliation = new BalanceReconciliation();
const faceSheetCases = new FaceSheetCases(
  td_trans_balancedue_tcid_261981.PatientCase[0]
);
export class BalanceDueAndUnassignedPaymentTcId261981 {
  verifyBalanceDue() {
    describe('To verify the balance due of chare in Transaction page', () => {
      it('Verify the balance due of charge once after performs the transactions in transaction page', () => {
        // #region Verify balance due amount of the charge after payment transaction in Transaction Page.

        cy.cGroupAsStep(
          'Verify the balance due amount of charge while user performs the payments transaction'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_trans_balancedue_tcid_261981.PatientCase[0].PatientDetails
        );

        /* Verify Balance And Amount in ChargeEntry Page */
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        faceSheetChargeEntry.verifyBalanceAndAmount(
          td_trans_balancedue_tcid_261981.caseTransaction.DebitInfo.Amount1
        );

        /* Verify Total Payment and Writeoff in Transaction - Payments popup */
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        transactions.selectCPTCode(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.verifyTotalPaymentAndWriteOff(
          td_trans_balancedue_tcid_261981.caseTransaction.PaymentsInfo[0]
        );

        /* Verify Total Due after enter the amount and Balance due in Transaction Page */
        transactions.selectTransactionValuesInPayments(
          td_trans_balancedue_tcid_261981.caseTransaction.PaymentsInfo[0]
        );
        transactions.verifyChargeAmountValueInPayments(
          td_trans_balancedue_tcid_261981.caseTransaction.PaymentsInfo[0]
        );
        sisOfficeDesktop.clickCloseIcon();

        transactions.selectCPTCode(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.paymentsPopupPostTransaction(
          td_trans_balancedue_tcid_261981.caseTransaction.PaymentsInfo[0]
        );
        transactions.clickDoneInPayment();

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_balancedue_tcid_261981.caseTransaction.ChargesData[0]
            .BalanceDue
        );
        // #end region

        // #region Verify balance due amount of the charge after writeoff transaction in Transaction Page.

        cy.cGroupAsStep(
          'Verify the balance due amount of charge while user performs the write off transaction'
        );

        /* To verify the Balance Due Amount after perform the Writeoff transaction in transaction page */
        transactions.selectCPTCode(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );

        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );

        transactions.writeoffPopupPostTransaction(
          td_trans_balancedue_tcid_261981.caseTransaction.WriteOffInfo
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_balancedue_tcid_261981.caseTransaction.ChargesData[1]
            .BalanceDue
        );
        // #rend region

        // #region verify balance due amount after perform the debit transaction

        cy.cGroupAsStep(
          'Verify the balance due amount of charge while user performs the debit transaction'
        );

        /* To verify the Balance Due Amount after perform the Debit transaction in transaction page */
        transactions.selectCPTCode(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );

        transactions.debitPopupPostTransaction(
          td_trans_balancedue_tcid_261981.caseTransaction.DebitInfo
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        transactions.verifyBalanceDueBasedOnCpt(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_balancedue_tcid_261981.caseTransaction.ChargesData[0]
            .BalanceDue
        );
        // #endregion
      });
    });
  }
  verifyAgingDataAndAllocationAmount() {
    describe('To verify the aging details and allocation amounts in ledger page', () => {
      it('Verify the Account data values in again section and the unallocated amount after performing the unassigned payment and allocation', () => {
        // #region verify the account values in again section and unallocated amount in ledger page.

        cy.cGroupAsStep(
          'Verify aging data related to Accounts and unallocated amount after perform the allocation in ledger page'
        );

        /* To click on the Person Icon in My Tasks and Verify the user navigated to Face sheet page */
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.verifyFacesheetTitle(
          td_trans_balancedue_tcid_261981.PatientCase[0].PatientDetails
            .PatientFirstName
        );

        /* click on the ledger tab and Verify the Balance Due amount in ledger page */
        ledgerTabFacesheet.clickOnLedgerTab();

        ledgerTabFacesheet.verifyLedgerChargeBalanceDue(
          td_trans_balancedue_tcid_261981.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription,
          td_trans_balancedue_tcid_261981.caseTransaction.ChargesData[0]
            .BalanceDue
        );

        /* Verifying the Total Charges Amount in the below of Aging section */
        ledgerTabFacesheet.verifyTotalAmountsInAging(
          td_trans_balancedue_tcid_261981.ShowAgingData[0].TotalChargeLabels!,
          td_trans_balancedue_tcid_261981.ShowAgingData[0].TotalCharges!
        );

        /* Click on show Aging icon and verify the amounts of Account section */
        ledgerTabFacesheet.clickOnShowAging();
        ledgerTabFacesheet.verifyAmountsInAging(
          td_trans_balancedue_tcid_261981.ShowAgingData[0].AgingLabels!,
          td_trans_balancedue_tcid_261981.ShowAgingData[0].AccountData!
        );

        /* Click on Add button and Add the Unassigned payment */
        ledgerTabFacesheet.clickOnAddButton();

        ledgerTabFacesheet.unassignedPaymentDetails(
          td_trans_balancedue_tcid_261981.UnassignPayment[0]
        );

        /* Click on context menu and select the allocate option */
        ledgerTabFacesheet.clickOnContextMenu(
          td_trans_balancedue_tcid_261981.UnassignPayment[0].TransactionCode!,
          OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
        );

        /* Allocate the amount based on the cpt code and select the transaction code in Allocation popup */
        sisOfficeDesktop.amountAllocation(
          td_trans_balancedue_tcid_261981.UnAssignedAllocationData
            .AmountAllocation,
          td_trans_balancedue_tcid_261981.UnAssignedAllocationData.CPTHCPCSCode
        );

        ledgerTabFacesheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
            .COLUMN_FOUR_TRANSACTION_CODE[0],
          td_trans_balancedue_tcid_261981.UnAssignedAllocationData
            .TransactionCode
        );
        ledgerTabFacesheet.clickOnAllocateUnassignedPaymentDone();
        /* Verify the UnAllocated amount in Unassigned Payments section */
        ledgerTabFacesheet.verifyUnAllocatedAmount(
          td_trans_balancedue_tcid_261981.UnassignPayment[0].TransactionCode!,
          td_trans_balancedue_tcid_261981.UnassignPayment[0].Unallocated
        );
        // #endregion
      });
    });
  }

  verifyDeletedChargeAndUnallocatedAmount() {
    describe('To verify the cpt charges and unallocated amount in ledger and transaction pages', () => {
      it('Verify the deleted charges and allocation amount related transaction in pages and tracker', () => {
        // #region verify the deleted charges and allocation data in different pages and tracker.

        cy.cGroupAsStep(
          'Verify the deleted charges should not display in transaction and ledger page and allocation data not displayed in Balance/Reconciliation tracker'
        );

        /* Select the case from global search */
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_trans_balancedue_tcid_261981.PatientCase[0].PatientDetails
        );

        /* Select the charge entry option */
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);

        /* Add the new procedure in charge entry */
        faceSheetChargeEntry.addProcedure(
          td_trans_balancedue_tcid_261981.caseTransaction.CptCodeInfo[1]
        );
        faceSheetChargeEntry.clickUpdateButton();
        /* Navigate to other tasks to save the data */
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );

        /* Delete the charge in Charge entry page */
        faceSheetChargeEntry.verifyReadyForBill();

        faceSheetChargeEntry.deleteCharge(
          td_trans_balancedue_tcid_261981.caseTransaction.CptCodeInfo[0]
        );

        /* Navigate to transaction and verify the deleted charge should not present */
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        transactions.verifyCPTCharge(
          td_trans_balancedue_tcid_261981.caseTransaction.CptCodeInfo[0]
        );

        /* Select the person icon in My Tasks */
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();

        /* Navigate to Ledger page and check the unallocated amount after deleted allocated amount*/
        ledgerTabFacesheet.clickOnLedgerTab();
        cy.reload();
        ledgerTabFacesheet.verifyUnAllocatedAmount(
          td_trans_balancedue_tcid_261981.UnassignPayment[0].TransactionCode!,
          td_trans_balancedue_tcid_261981.UnassignPayment[1].Unallocated
        );

        /* verify the deleted charge should not display in ledger page */
        transactions.verifyCPTCharge(
          td_trans_balancedue_tcid_261981.caseTransaction.CptCodeInfo[0]
        );

        /* click on show again icon and verifying the account data */
        ledgerTabFacesheet.verifyLedgerCPTCharge(
          td_trans_balancedue_tcid_261981.caseTransaction.CptCodeInfo[1]
        );
        ledgerTabFacesheet.clickOnShowAging();

        ledgerTabFacesheet.verifyAmountsInAging(
          td_trans_balancedue_tcid_261981.ShowAgingData[0].AgingLabels!,
          td_trans_balancedue_tcid_261981.ShowAgingData[1].AccountData!
        );

        /* Click on SIS logo to navigate home page */
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        /* Click on Balance/Reconciliation tracker */
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BALANCE_OR_RECONCILIATION[0]
        );

        /* Select the period and batch in tracker */
        balanceReconciliation.selectPeriodAndBatch(
          td_trans_balancedue_tcid_261981.ChargesModel
        );

        /* verifying the Allocate amount is not displaying for the case  */
        balanceReconciliation.verifyTransactionType(
          td_trans_balancedue_tcid_261981.PatientCase[0].PatientDetails
            .LastName,
          OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
        );
      });
    });
  }
}
