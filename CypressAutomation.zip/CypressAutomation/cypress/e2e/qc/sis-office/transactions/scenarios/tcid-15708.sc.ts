import { ExpandOrCollapse } from '../../../../../support/common-core-libs/application/common-core';
import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { selectorFactory } from '../../../../../support/common-core-libs/framework/selector-factory';

import { td_trans_debit_tcid_15708 } from '../../../../../fixtures/sis-office/transactions/trans-debit-tcid-15708.td';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';

import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transaction = new Transactions(
  td_trans_debit_tcid_15708.PatientCase[0],
  td_trans_debit_tcid_15708.CaseTransaction
);
const faceSheetCases = new FaceSheetCases();

export class DebitTransactionTcId15708 {
  verifyWarningMessageDebitPopup() {
    describe('Verifying the warning text message and labels in Debit popup of Facesheet Transactions', () => {
      it('Verify Warning Message Appears without selecting the Charge in Transactions', () => {
        // #region - Verify Warning Message Appears without selecting the Charge in Transactions

        cy.cGroupAsStep(
          'Search and select the patient from global search list'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_trans_debit_tcid_15708.PatientCase[0].PatientDetails
        );

        cy.cGroupAsStep('Select the transaction option from facesheet');
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        cy.cGroupAsStep('Select the charge and click on debit icon');
        cy.cIsVisible(
          selectorFactory.selectChargeFromTransactionPage(
            td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
              .CPTCodeAndDescription
          ),
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        transaction.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );

        cy.cGroupAsStep(
          'Verify the warning text message when not selected the CPT code in Transaction page'
        );
        cy.cIncludeText(
          OR_TRANSACTION.CHARGES.WARNING_TEXT[1],
          OR_TRANSACTION.CHARGES.WARNING_TEXT[0],
          AppErrorMessages.charge_warning
        );
        // #endregion
      });
    });
  }

  verifyBorderColor() {
    describe('Verifying Warning Message not displayed and also Border Color of Charge after Selecting Charge based on CPT Code', () => {
      it('Verifying non existence of warning - to Select Charge', () => {
        // #region - Verifying Warning Message not displayed and also Border Color of Charge after Selecting Charge based on CPT Code

        cy.cGroupAsStep(
          'Verify the border color by selecting the CPT code in Transactions'
        );
        transaction.selectCPTCode(
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        transaction.verifyCptBorderColor();

        cy.cGroupAsStep(
          'Verifying the warning text message not existed when select the CPT Code in Transaction page'
        );
        cy.cNotExist(
          selectorFactory.getSmallText(AppErrorMessages.charge_warning),
          AppErrorMessages.charge_warning
        );
        // #endregion
      });
    });
  }

  verifyDebitPopupLabelNames() {
    describe('Verifying the Fields in Debit Popup in Facesheet Transactions', () => {
      it('Verifying Debit Icon and its labels in Transaction Page', () => {
        // #region - Verifying the Fields in Debit Popup in Facesheet Transactions

        cy.cGroupAsStep(
          'Verify Debit popup labels after selecting the Debit icon in Transactions'
        );
        transaction.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );
        transaction.verifyDebitPopupLabelNames(
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.labelNames,
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.labelNames1
        );

        cy.cGroupAsStep(
          'Verify Debit popup is closed after clicking on close icon'
        );
        sisOfficeDesktop.clickCloseIcon();
        cy.cNotExist(
          selectorFactory.getH3Text(
            td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Debit
          ),
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Debit
        );
        // #endregion
      });
    });
  }

  verifyBalanceAmount() {
    describe('Verifying the balance due amount when user perform the debit transaction in Facesheet Transactions', () => {
      it('Verifying Debit Information in Transaction Page for Debit Transaction', () => {
        // #region - Post the debit Transaction

        cy.cGroupAsStep(
          'Search and select the patient and navigate to debit transactions'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_trans_debit_tcid_15708.PatientCase[0].PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transaction.selectCPTCode(
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        transaction.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );

        cy.cGroupAsStep('Fill the mandatory values and add debit transactions');
        transaction.debitPopupPostTransaction(
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo
        );
        cy.cNotExist(
          selectorFactory.getH3Text(
            td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Debit
          ),
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Debit
        );
        // #endregion

        // #region - Verifying the Balance due amount based on the CPT Code after adding the Debit transaction

        cy.cGroupAsStep(
          'Verifying the Balance due amount based on the CPT Code after adding the Debit transaction'
        );
        transaction.verifyBalanceDueBasedOnCpt(
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription,
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Amount1
        );
        transaction.verifyDebitInfo(
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo
            .DebitTransactionCode,
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.DebitAmount
        );
        // #endregion

        // #region - Add the debit transaction for second time

        cy.cGroupAsStep('Add the debit transaction for second time');
        cy.cIsVisible(
          selectorFactory.selectChargeFromTransactionPage(
            td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
              .CPTCodeAndDescription
          ),
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        transaction.selectCPTCode(
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        transaction.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );
        transaction.debitPopupPostTransaction(
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo
        );
        // #endregion

        // #region - Verify the updated balance by selecting transaction based on cpt

        cy.cGroupAsStep(
          'Verify the updated balance by selecting transaction based on cpt'
        );
        transaction.selectCPTCode(
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        cy.cNotExist(
          selectorFactory.getH3Text(
            td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Debit
          ),
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Debit
        );
        transaction.verifyBalanceDueBasedOnCpt(
          td_trans_debit_tcid_15708.PatientCase[0].CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription,
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.Amount2
        );
        // #endregion

        // #region - Verifying the debit information details

        cy.cGroupAsStep('Verifying the debit information details');
        transaction.verifyDebitInfo(
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo
            .DebitTransactionCode,
          td_trans_debit_tcid_15708.CaseTransaction.DebitInfo.DebitAmount
        );
        // #endregion
      });
    });
  }

  verifyNoCharges() {
    describe('Verify warning text when no charges found in transaction page', () => {
      it('Verify No Transaction Details text message when no charges available', () => {
        // #region - Verify No charges displayed for second patient with no transactions added

        cy.cGroupAsStep(
          'Verify No charges displayed for second patient with no transactions added'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_trans_debit_tcid_15708.PatientCase[1].PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        cy.cIncludeText(
          OR_TRANSACTION.NO_CHARGES_TEXT[1],
          OR_TRANSACTION.NO_CHARGES_TEXT[0],
          OR_TRANSACTION.NO_CHARGES_TEXT[0]
        );
        cy.cIncludeText(
          OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1],
          OR_TRANSACTION.TRANSACTION_DETAILS_DATA[0],
          OR_TRANSACTION.TRANSACTION_DETAILS_DATA[0]
        );
        // #endregion
      });
    });
  }
}
