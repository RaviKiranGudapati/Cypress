/**Revision History
 * 06/12/2022, Praveen, Spec to implement scenario - TCID - 261981, Verify balance due amount in transaction page and checking the aging, unassigned payment data in ledger page.
 */
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { BalanceDueAndUnassignedPaymentTcId261981 } from './scenarios/tcid-261981.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

//SHIFT + ALT + O - Organizing the import
/*Test Script Validation Details *****
 * The spec file have dependency on seed data.
 * Script Execution Approach -
 * 1. Search and select the case in global search
 * 2. Navigate to Charge Entry page and Expand the charge, verify the amount and balance.
 * 3. Navigate to transaction page and select the charge
 * 4. Click on Payments icon and verify the Total write-off and Due amount in Payments popup
 * 5. Perform the payments transaction and click on Done button.
 * 6. Select the charge and perform the Debit and Write-Off transactions.
 * 7. Verify the balance due amount for the selected charge.
 * 8. click on the Person icon in My Tasks and Navigate to Ledger tab
 * 9. click on Show Again icon and verify the Total Amount data.
 * 10. Perform the unassigned payment and allocate the amount.
 * 11. verify the allocated amount for the charge in ledger page.
 * 12. Search and select from global search and Navigate charge entry page.
 * 13. Add a new charge and Delete the existing charge and click on update button.
 * 14. Verify the deleted charge should not present in transaction and ledger page.
 * 15. Verify the allocation related transaction should not in the balance/reconciliation page.
 ************************************************************************/

/* instance variables */
const balanceDueAndUnassignedPayment =
  new BalanceDueAndUnassignedPaymentTcId261981();

describe(
  'Verify Balance Due Amount and Delete charges in Transaction and Ledger page, ',
  { tags: ['facesheet', 'US#262537', 'TC#261981'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    //After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        balanceDueAndUnassignedPayment.verifyBalanceDue();
        balanceDueAndUnassignedPayment.verifyAgingDataAndAllocationAmount();
        balanceDueAndUnassignedPayment.verifyDeletedChargeAndUnallocatedAmount();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
