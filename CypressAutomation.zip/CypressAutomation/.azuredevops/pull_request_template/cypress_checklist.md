Thank you for your contribution to the Cypress Project

Please make sure to check the below points

- [ ] Make sure all best practices are implemented
- [ ] all Code is formatted (No unnecessary spaces, no dead code or unnecessary commented code)
- [ ] All AC of the story is met
- [ ] all test cases related to the story are passing
- [ ] all test cases are also passing (this makes sure that we did not break any of the old test cases)
