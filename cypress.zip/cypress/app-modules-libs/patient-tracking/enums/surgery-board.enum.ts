/* enum values */
export enum BoardSettingsHeaders {
  discharged_cases = 'Discharged Cases',
  unarrived_cases = 'Unarrived Cases',
}
