import {
  CommonGetLocators,
} from '../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../support/common-core-libs/core-css-classes';
import { selectorFactory } from '../../support/common-core-libs/framework/selector-factory';

import { OR_PATIENT_TRACKING } from './or/tracking-board.or';

import TrackingBoardApi from './api/tracking-board.api';

export class TrackerBoard {
  private trackingBoardApi = new TrackingBoardApi();

  /**
   * @details -To select the tracker in patient tracking board list
   * @param trackerName - in-order to select the tracker in patient tracking
   * @param view - select the view for the surgery board if multiple views exist
   * @API - API's are not available
   * @author Divya
   */
  selectPatientTrackingBoard(trackerName: string, view?: string) {
    cy.cIsVisible(OR_PATIENT_TRACKING.TRACKER_SELECTION[1], '');
    cy.cClick(selectorFactory.getSpanText(trackerName), '');
    this.clickLaunch();
    this.selectView(view);
  }

  /**
   * @details -To click on launch in patient tracking board list
   * @API - API's are not available
   * @author Divya
   */
  clickLaunch() {
    const interceptCollection = this.trackingBoardApi.interceptClickLaunch();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(OR_PATIENT_TRACKING.LAUNCH[0]), '');
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details -To click on hamburger menu
   * @API - API's are not available
   * @author Divya
   */
  clickOnHamburgerMenu() {
    cy.cClick(CoreCssClasses.Bars.loc_bars_icon, '');
  }

  /**
   * @details -To logout from patient tracking boards
   * @API - API's are not available
   * @author Divya
   */
  logout() {
    this.clickOnHamburgerMenu();
    cy.cClick(
      selectorFactory.getAText(OR_PATIENT_TRACKING.LOGOUT[0]),
      OR_PATIENT_TRACKING.LOGOUT[0]
    );
  }

  /**
   * @details -To select view in Surgery board tracker
   * @param view - select the view for the surgery board if multiple views exist.
   * @API - API's are not available
   * @author Divya
   */
  selectView(view: string = OR_PATIENT_TRACKING.DEFAULT_VIEW[0]) {
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (
        body.find(selectorFactory.getH3Text(OR_PATIENT_TRACKING.SELECT_VIEW[0]))
          .length > 0
      ) {
        cy.cClick(selectorFactory.getSpanText(view), '');
      }
    });
  }
}
