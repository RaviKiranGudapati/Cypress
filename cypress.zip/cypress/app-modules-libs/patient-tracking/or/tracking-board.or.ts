export const OR_PATIENT_TRACKING = {
  TRACKER_SELECTION: ['Tracker Selection', 'body .tracker-selection'],
  LAUNCH: ['Launch'],
  DEFAULT_VIEW: ['Default View'],
  SELECT_VIEW: ['Select View'],
  LOGOUT: ['Logout'],
};
