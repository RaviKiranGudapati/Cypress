import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../support/common-core-libs/application/constants/sub-routes.constants';

export default class SISAnesthesiaDesktopApi {
  /**
   * @details - api after Select the consent from list to edit
   * @author - chandrika
   */
  interceptSelectCaseConsentApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_dictionary,
        'Dictionary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_anesthesia_consent_clinical,
        'AnesthesiaConsentClinical',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_is_signed,
        'IsSigned',
        200
      ),
    ];
  }

  /**
   * @details - api after Select the consent from list to edit
   * @author - chandrika
   */
  interceptClickPreAndPostOpTabApi(): ApiEndpoint[] {
    return [new ApiEndpoint(WaitMethods.get, SubRoutes.get_api, 'Api', 200)];
  }

  /**
   * @details - APIs after Navigating to Anesthesia Desktop
   * @Author - Vamshi
   */
  interceptNavigatingAnesthesiaApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_CurrentUser,
        'CurrentUser',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.security_get_feature_by_org,
        'FeatureByOrg',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_facility_access,
        'UserFacilityAccess',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.config_schedule_anesthesia,
        'GetConfigScheduleMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_business_entity_get_image,
        'GetImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_scheduling,
        'AnesthesiaScheduling',
        200
      ),
    ];
  }

  /**
   * @details - APIs after selecting patient in Anesthesia Desktop
   * @Author - Vamshi
   */
  interceptSelectPatientAnesthesiaApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_image,
        'GetImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.time_notations,
        'TimeNotations',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.nurse_note, 'NurseNote', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_procedure_by_case,
        'GetProcedureByCase',
        200
      ),
    ];
  }

  /**
   * @details - APIs after closing preop slide out
   * @Author - Arushi
   */
  interceptClosePreOpSlideOut() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_basic_module,
        'AnestheticModule',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_profile,
        'AnesthesiaProfile',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_anesthesia_type_documentation,
        'AnesthesiaDocumentation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_speciality_by_case,
        'SpecialityByCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.post_security,
        'Security',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_area_care_info,
        'AnesthesiaCareInfo',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_configuration_toggle_map,
        'ToggleMap',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - APIs after clicking done button in administer medication
   * @Author - Arushi
   */
  interceptAdministerMedication() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.post_security,
        'Security',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_basic_module,
        'BasicModule',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - APIs after adding medication
   * @Author - Arushi
   */
  interceptAnesthesiaMedication() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.formulary_medication_template_get,
        'FormularyMedication',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - APIs for searching by MRN
   * @Author - Arushi
   */
  interceptSearchNyMrn() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_scheduling,
        'AnesthesiaScheduling',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - APIs for clicking done while adding administer medication
   * @Author - Arushi
   */
  interceptDoneAdministerMedication() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_administer_medication_done,
        'MedicationDone',
        200
      ),
    ];
    return endpoints;
  }
}
