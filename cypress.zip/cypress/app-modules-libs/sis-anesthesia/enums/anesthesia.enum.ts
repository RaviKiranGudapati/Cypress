export enum AnesthesiaCaseLabels {
    attachments = 'Attachments',
    pre_op_exam = 'Pre-Op Exam',
    block_notes = 'Block Notes',
    consents = 'Consents',
    orders = 'Orders',
  }