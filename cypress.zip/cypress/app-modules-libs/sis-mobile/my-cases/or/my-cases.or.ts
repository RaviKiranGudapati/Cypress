import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_SIS_MOBILE_MY_CASES = {
  CALENDER_HEADER: {
    FORWARD_ICON: ['Forward', '.pull-right'],
    BACKWARD_ICON: ['Backward', '.pull-left'],
  },
  PATIENT: ['Patient', '.patient'],
  CASE_ATTACHMENT: ['Case Attachment', '.attachment'],
  CASE_CONSENTS: {
    HEADER: ['Case Consents'],
    SIGN: [
      'SIGN',
      CommonUtils.concatenate(
        CoreCssClasses.Icon.loc_pencil_icon,
        CoreCssClasses.Icon.loc_sign_icon
      ),
    ],
  },
};
