import { CommonGetLocators } from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_SIS_MOBILE_MY_CASES } from './or/my-cases.or';

export default class MyCases {
  /**
   * @details - To navigate forward and backward dates
   * @param forwardBackward
   * @param n - e.g 4 ( to move 4 times backward/forward based on selection)
   * @API - API's are available - Not Implemented
   */
  clickNavigateButtons(forwardBackward: string, n: number = 1) {
    for (let i = 1; i <= n; i++) {
      switch (forwardBackward) {
        case OR_SIS_MOBILE_MY_CASES.CALENDER_HEADER.FORWARD_ICON[0]:
          //TODO: Need to implement API
          cy.cClick(
            OR_SIS_MOBILE_MY_CASES.CALENDER_HEADER.FORWARD_ICON[1],
            OR_SIS_MOBILE_MY_CASES.CALENDER_HEADER.FORWARD_ICON[0]
          );
          break;
        case OR_SIS_MOBILE_MY_CASES.CALENDER_HEADER.BACKWARD_ICON[0]:
          //TODO: Need to implement API
          cy.cClick(
            OR_SIS_MOBILE_MY_CASES.CALENDER_HEADER.BACKWARD_ICON[1],
            OR_SIS_MOBILE_MY_CASES.CALENDER_HEADER.BACKWARD_ICON[0]
          );
          break;
        default:
          break;
      }
    }
  }

  /**
   * @details - To select patient
   * @param patientName
   * @API - API's are available - Not Implemented
   */
  selectPatient(patientName: string) {
    //TODO: Need to implement API
    cy.cClick(
      selectorFactory.getMobilePatient(patientName),
      patientName,
      false,
      true
    );
  }

  /**
   * @details - To select Case Consents
   * @param consentName
   * @API - API's are available - Not Implemented
   */
  selectCaseConsents(consentName: string) {
    //TODO: Need to implement API
    cy.cGet(
      selectorFactory.getSpanText(
        OR_SIS_MOBILE_MY_CASES.CASE_CONSENTS.HEADER[0]
      )
    )
      .parents(CommonGetLocators.section)
      .find(OR_SIS_MOBILE_MY_CASES.CASE_ATTACHMENT[1])
      .first()
      .within(() => {
        cy.cClick(
          selectorFactory.getDivText(consentName),
          consentName,
          false,
          true
        );
      });
  }

  /**
   * @details - To verify procedures in case consents
   * @param consentName
   * @param procedureName
   */
  verifyProceduresInCaseConsents(consentName: string, procedureName: string) {
    cy.cGet(selectorFactory.getDivText(consentName))
      .parents(CommonGetLocators.app_consents)
      .within(($consent) => {
        cy.wrap($consent)
          .find(selectorFactory.getDivText(procedureName))
          .contains(procedureName);
      });
  }

  /**
   * @details - To check the consent statement
   * @param statement
   * @API - API's are available - Not Implemented
   */
  signConsentStatement(statement: string) {
    cy.cClick(
      selectorFactory.mobileConsentStatementCheckbox(statement),
      statement
    );
    //TODO: Need to implement API
    cy.cClick(
      OR_SIS_MOBILE_MY_CASES.CASE_CONSENTS.SIGN[1],
      OR_SIS_MOBILE_MY_CASES.CASE_CONSENTS.SIGN[0]
    );
    cy.cIsVisible(
      selectorFactory.mobileConsentStatementCheckbox(statement),
      statement
    );
  }

  /**
   * @details - To verify procedures in case consents
   * @param consentName - Consent name to in consent pop-up
   * @param isDisplayed - Boolean condition to verify consents is displayed
   * @API - API's are not available
   */
  verifyCaseConsents(consentName: string, isDisplayed: boolean = true) {
    if (isDisplayed) {
      cy.cIsVisible(selectorFactory.getDivText(consentName), consentName);
    } else {
      cy.cNotExist(selectorFactory.getDivText(consentName), consentName);
    }
  }
}
