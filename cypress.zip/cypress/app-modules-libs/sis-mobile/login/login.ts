import { ShouldMethods } from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_SIS_MOBILE_LOGIN } from './or/login.or';

import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

class SISMobileLogin {
  /**
   * @details - login to application using user credentials and business entity provided
   * @param username
   * @param password
   * @param loginLocation
   * @APIs are available - Not Implemented
   */
  login(username: string, password: string, loginLocation?: string) {
    sisOfficeDesktop.pageTitle.should(
      ShouldMethods.include,
      OR_SIS_MOBILE_LOGIN.LOGIN.LOGIN_WEB_TITLE
    );
    cy.cType(
      OR_SIS_MOBILE_LOGIN.LOGIN.USER_NAME[1],
      OR_SIS_MOBILE_LOGIN.LOGIN.USER_NAME[0],
      username
    );
    cy.cType(
      OR_SIS_MOBILE_LOGIN.LOGIN.PASSWORD[1],
      OR_SIS_MOBILE_LOGIN.LOGIN.PASSWORD[0],
      password
    );
    //TODO : Need to Implement API
    cy.cClick(
      OR_SIS_MOBILE_LOGIN.LOGIN.SIGN_IN[1],
      OR_SIS_MOBILE_LOGIN.LOGIN.SIGN_IN[0]
    );

    if (loginLocation !== undefined) {
      //TODO : Need to Implement API
      cy.cClick(selectorFactory.getSpanText(loginLocation), loginLocation);
    }
  }

  /**
   * @details - to logout from sis mobile url
   * @APIs are available - Not Implemented
   */
  logout() {
    cy.cClick(
      OR_SIS_MOBILE_LOGIN.LOGOUT.INFO_ICON[1],
      OR_SIS_MOBILE_LOGIN.LOGOUT.INFO_ICON[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(OR_SIS_MOBILE_LOGIN.LOGOUT.LOGOUT[0]),
      OR_SIS_MOBILE_LOGIN.LOGOUT.LOGOUT[0]
    );
    cy.cGet(
      OR_SIS_MOBILE_LOGIN.LOGOUT.CONFIRM_DIALOG[1],
      OR_SIS_MOBILE_LOGIN.LOGOUT.CONFIRM_DIALOG[0]
    ).within(() => {
      //TODO : Need to Implement API
      cy.cClick(
        selectorFactory.getButtonText(
          OR_SIS_MOBILE_LOGIN.LOGOUT.LOGOUT_CAPS[0]
        ),
        OR_SIS_MOBILE_LOGIN.LOGOUT.LOGOUT_CAPS[0]
      );
    });
  }
}

export default SISMobileLogin;
