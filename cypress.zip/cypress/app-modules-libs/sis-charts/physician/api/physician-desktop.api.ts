import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class SISPhysicianDesktopApi {
  /**
   * @details  - select Task In My Task
   * @author - Madhu Kiran
   */
  interceptSelectTaskInMyTak(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_worklist_case_details,
        'GetCaseDetails',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.nurse_note, 'NurseNote', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.consent_clinical,
        'ConsentClinical',
        200
      ),
      new ApiEndpoint(WaitMethods.post, SubRoutes.date_range, 'DateRange', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_summary_information,
        'CaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_documentation_state,
        'DocumentationState',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_order_documentation,
        'PhysicianOrdersDocumentation',
        200
      ),
    ];
  }
}
