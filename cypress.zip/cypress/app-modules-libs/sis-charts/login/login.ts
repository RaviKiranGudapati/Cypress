import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { OR_LOGIN } from './or/login.or';
import LoginApi from './api/login.api';

export default class ChartsLogin {
  private loginApi = new LoginApi();

  /**
   * Function Details - To select login location from Change Login Location Popup*
   * @param loginLocation
   * @APIs are available - Not Implemented
   */
  selectChangeLoginLocation(loginLocation: string) {
    cy.cGet(OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[1])
      .first()
      .within(() => {
        //TODO : Need to Implement API
        cy.cClick(loginLocation, loginLocation, true);
      });
  }

  /**
   * @details - To select login location from Change Login Location from Enterprise
   * @param loginLocation
   * @API - API's are available - Not Implemented
   */
  selectChangeLoginLocationFromEnterprise(loginLocation: string) {
    cy.cGet(OR_LOGIN.LOGIN_LOCATION_FROM_ENTERPRISE.LOGIN_LOCATION_WINDOW[1])
      .first()
      .within(() => {
        //TODO : Need to Implement API
        cy.cClick(loginLocation, loginLocation, true);
      });
  }

  /**
   * @details - To login to the Patient Tracking where Web page title is SIS-Charts
   * @param username - To enter username
   * @param password - To enter password
   * @param loginLocation - To select the login location from list of items
   * @API -  API's are available - Partially Implemented
   * @author - Divya
   */
  login(username: string, password: string, loginLocation?: string) {
    const interceptCollection = this.loginApi.interceptPatientTracking();
    cy.cType(
      OR_LOGIN.LOGIN.USER_NAME[1],
      OR_LOGIN.LOGIN.USER_NAME[0],
      username
    );
    cy.cType(OR_LOGIN.LOGIN.PASSWORD[1], OR_LOGIN.LOGIN.PASSWORD[0], password);
    cy.cIntercept(interceptCollection);
    cy.cClick(OR_LOGIN.LOGIN.LOGIN_BUTTON[1], OR_LOGIN.LOGIN.LOGIN_BUTTON[0]);
    cy.cWaitApis(interceptCollection);

    if (loginLocation !== undefined) {
      cy.cClick(
        selectorFactory.getSpanText(loginLocation),
        OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0]
      );
    }
  }
}
