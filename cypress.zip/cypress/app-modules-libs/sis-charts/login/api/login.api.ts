import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export default class LoginApi {
  /**
   * @details - Login selection for patient tracking
   * @author - Praveen
   */
  interceptPatientTracking(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_tracking_user_org_map,
        'OrgMap',
        200
      ),
    ];
  }
}
