import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_LOGIN = {
  LOGIN_LOCATION: {
    LOGIN_LOCATION_WINDOW: [
      'Select Login Location',
      CommonUtils.concatenate(
        '#orgSelectionScroll ',
        CoreCssClasses.ScrollPanel.loc_p_scrollpanel_component
      ),
    ],
  },
  LOGIN_LOCATION_FROM_ENTERPRISE: {
    LOGIN_LOCATION_WINDOW: [
      'Select Login Location',
      CommonUtils.concatenate(
        '#orgSelectionScroll ',
        CoreCssClasses.ScrollPanel.loc_p_scrollpanel_component
      ),
    ],
  },
  LOGIN: {
    USER_NAME: ['User Name', '#username'],
    PASSWORD: ['Password', '#password'],
    LOGIN_BUTTON: ['Login', '#LoginButton'],
  },
};
