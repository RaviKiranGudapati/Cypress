import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const OR_CHARTS_SCHEDULE_PRINT = {
  PRINT_ICON: ['Print Icon', '#iconPrint'],
  SCHEDULE_GRID: ['Schedule Grid'],
  PICK_LIST: ['Pick List'],
  PREVIEW: ['Preview'],
  SCHEDULE_GRID_POPUP: {
    VIEW: {
      TOGGLE_BUTTON: [
        'View',
        CommonUtils.concatenate(
          CoreCssClasses.Row.loc_physician_row,
          ' > ',
          CoreCssClasses.Toggle.loc_dual_switch,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_label,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_inner
        ),
      ],
      PHYSICIAN: ['Physician'],
      ROOM: ['Room'],
    },
    GROUP_BY: ['Group By', `#groupby_id span[ng-if*=selected]`],
    LAYOUT: {
      TOGGLE_BUTTON: [
        'Layout',
        CommonUtils.concatenate(
          '.col-md-3 >',
          CoreCssClasses.Toggle.loc_dual_switch,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_label,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_inner
        ),
      ],
      PORTRAIT: ['Portrait'],
      LANDSCAPE: ['Landscape'],
    },
    PAGE_BREAK: {
      TOGGLE_BUTTON: [
        'Page Break',
        CommonUtils.concatenate(
          ':nth-child(2) > ',
          CoreCssClasses.Toggle.loc_dual_switch,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_label,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_inner
        ),
      ],
    },
    REMOVE_PATIENT_INFO: {
      TOGGLE_BUTTON: [
        'Remove Patient Info',
        CommonUtils.concatenate(
          ':nth-child(3) > ',
          CoreCssClasses.Toggle.loc_dual_switch,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_label,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_inner
        ),
      ],
    },
    INCLUDE_ESTIMATED_REVENUE: {
      TOGGLE_BUTTON: [
        'Include Estimated Revenue',
        CommonUtils.concatenate(
          ':nth-child(4) > ',
          CoreCssClasses.Toggle.loc_dual_switch,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_label,
          ' > ',
          CoreCssClasses.Toggle.loc_on_off_switch_inner
        ),
      ],
    },
    REFRESH_BUTTON: ['Refresh', '#refresh_btn'],
    PRINT: ['Print', `button[ng-click*='print()']`],
    CLOSE_ICON: ['Close X mark', CoreCssClasses.Icon.loc_close],
  },
};
