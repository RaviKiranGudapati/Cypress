export enum NursingDept {
    pre_operative = 'Pre-Operative',
    operative = 'Operative',
    recovery = 'Recovery',
    consents = 'Consents',
    phase1 = 'Phase1',
    phase2 = 'Phase2',
    phase3 = 'Phase3',
  }
  
  export enum MyTasks {
    documents = 'DOCUMENTS',
    physician = 'PHYSICIAN',
    pre_admit = 'PRE_ADMIT',
    pre_op = 'PRE-OP',
    operative = 'OPERATIVE',
    recovery = 'RECOVERY',
    post_op_qx = 'POST-OP QX',
  }
  