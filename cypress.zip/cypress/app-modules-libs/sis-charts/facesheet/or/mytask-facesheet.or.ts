import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_MY_TASK_FACE_SHEET = {
  CLOSE_POPUP: ['Close Pop Up', 'i[class*="close"]'],
  ADD_OPNOTES: ['Add OpNotes', '#opn_addnew_btn'],
  ADD_IMPLANTS: ['Add Implants', '#btn_addNew_'],
  PENCIL_ICON: ['Pencil Icon', 'i[class*="pencil"]'],
  SIGN_BUTTON: ['Sign Button ', 'button[class*="sign"]'],
  OVERRIDE_BUTTON: ['Override Button', 'button[data-test-id*="override"]'],
  ADD_NEW_OPNOTES_POPUP: ['Add New Op Note', '.opnote-modal-title'],
  DEPARTMENT: ['Department'],
  TASKS: ['Task'],
  OP_NOTES: ['Op Notes'],
  SELECT_PHYSICIAN: [
    'Select Physician',
    CommonUtils.concatenate(
      '#aonp_physicians_select ',
      selectorFactory.getSpanText('Select Physician')
    ),
  ],
  SHOW_ALL: [
    'Show All',
    CommonUtils.concatenate(
      '#aonp_physicians_select ',
      selectorFactory.getSpanText('Show All')
    ),
  ],
};
