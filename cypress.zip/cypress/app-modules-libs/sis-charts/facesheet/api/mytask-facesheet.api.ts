import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class MyTaskFaceSheetApi {
  /**
   *@details - API's for click on add OpNotes
   *@author - Madhu Kiran
   */
  interceptAddOpNotes(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.op_note_documentation,
        'OpNotesDocumentation',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.get_staff, 'Staff', 200),
    ];
  }

  /**
   *@details - API's for click on OpNotes task
   *@author - Madhu Kiran
   */
  interceptOpNotesTask(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.op_note_documentation,
        'OpNotesDocumentation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.nurse_note,
        'NursingNote',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.get_staff, 'Staff', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_op_template_names_and_physcians,
        'GetOpTemplateNamesAndPhyscians',
        200
      ),
    ];
  }

  /**
   *@details - API's for Orders task
   *@author - Madhu Kiran
   */
  interceptOrderTask(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.nurse_note,
        'NursingNote',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_worklist_case_details,
        'GetCaseDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.physician_orders_documentation,
        'PhysicianOrdersDocumentation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_documentation_state,
        'DocumentationState',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.get_staff, 'Staff', 200),
    ];
  }

  /**
   *@details - API's for Worklist task
   *@author - Madhu Kiran
   */
  interceptWorklistTask(): ApiEndpoint[] {
    return [new ApiEndpoint(WaitMethods.get, SubRoutes.get_api, 'Api', 200)];
  }

  /**
   *@details - API's for Select OpNote
   *@author - Madhu Kiran
   */
  interceptSelectOpNote(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.op_note_documentation,
        'OpNoteDocumentation',
        200
      ),
    ];
  }
}
