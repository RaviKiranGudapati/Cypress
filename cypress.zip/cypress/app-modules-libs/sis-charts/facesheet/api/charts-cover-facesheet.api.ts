import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export default class ChartsCoverFaceSheetApi {
  /**
   * @details - Api collection after clicking add worklist in my tasks
   * @author - Praveen
   */
  addedWorklistApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.dictionary_name,
        'DictionaryName',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for adding worklist template for a case
   * @author - Praveen
   */
  addWorklistTemplateCaseApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_templates_for_case,
        'GetTemplatesForCase',
        200
      ),
    ];
  }

  /**
   * @details - After selecting recovery in nursing desktop
   * @author - Arushi
   */
  interceptRecoveryApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_form_by_name,
        'FormByName',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_worklist_case_details,
        'WorklistCaseDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_documentation_state,
        'DocumentationState',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_order_documentation,
        'PhysicianOrderDocumentation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_speciality_by_case,
        'SpecialityByCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_neuro_exam_configuration,
        'NeuroExamConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_last_recovery_intake,
        'LastRecoveryIntake',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_vital_sign,
        'VitalSign',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for adding worklist template for all case
   * @author - Praveen
   */
  addWorklistTemplateAllApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_templates_all_case,
        'GetTemplatesAllCase',
        200
      ),
    ];
  }

  /**
   * @details - After selecting operative in nursing desktop
   * @author - Arushi
   */
  interceptOperativeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_staff,
        'PrimaryPhysicianCaseOperative',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_facesheet_info,
        'PatientFacesheetInfo',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_basic_module_info,
        'BasicModuleInfo',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_summary,
        'CaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_configuration_toggle_map,
        'ConfigurationToggleMap',
        200
      ),
    ];
  }

  /**
   * @details - After selecting consent in nursing desktop
   * @author - Arushi
   */
  interceptConsentApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_record,
        'PatientRecord',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_procedure_by_case,
        'ProcedureByCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_record_by_summary_id,
        'PatientRecordBySummaryId',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_diagnosis_by_case_and_procedure,
        'GetDiagnosisCaseAndProcedure',
        200
      ),
    ];
  }

  /**
   * @details - API calls - search for supply item while search in worklist.
   * @authot - Praveen
   */
  interceptSearchSupplyWorklistApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_inventory,
        'SearchSupply',
        200
      ),
    ];
  }

  /**
   *@details - API's for click on Worklist Icon
   *@author - Madhu Kiran
   */
  interceptWorklistIcon(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_templates_for_case,
        'GetTemplatesForCase',
        200
      ),
    ];
  }

  /**
   *@details - API's for Select Worklist
   *@author - Madhu Kiran
   */
  interceptSelectWorklist(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.copy_worklist_from_config,
        'CopyWorklistFromConfig',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.dictionary_name,
        'WorklistDictionary',
        200
      ),
    ];
  }

  /**
   * @details - API calls -click on order in department
   * @author - Arushi
   */
  interceptOrderInDepartment() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_worklist_case_details,
        'WorklistCaseDetails',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.nurse_note, 'NurseNotes', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_order_documentation,
        'PhysicianOrderDocumentation',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.get_staff, 'GetStaff', 200),
    ];
    return endpoints;
  }

  /**
   * @details - API calls - sign department.
   * @author - Arushi
   */
  interceptSignDepartmentPencilIcon() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.post_security,
        'Security',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_specimen_entry_sign,
        'SpecimenEntry',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.has_other_case_lock,
        'HasOtherCaseLock',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.has_other_case_lock,
        'HasOtherCaseLock',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_basic_module_info,
        'GetBasicModuleInfoByCaseSummaryId',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API calls -click on sign button
   * @author - Arushi
   */
  interceptSignButton() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_configuration_toggle_map,
        'ToggleMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_worklist_case_details,
        'WorklistCaseDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_documentation_state,
        'DocumentationState',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_order_documentation,
        'PhysicianOrder',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API calls -Case details Unsigned
   * @author - Arushi
   */
  interceptCaseDetailsUnsignApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_basic_module_info,
        'GetBasicModuleInfoByCaseSummaryId',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API calls -clicking facesheet icon
   * @author - Arushi
   */
  interceptFacesheetIcon() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(WaitMethods.get, SubRoutes.get_staff, 'GetStaff', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_anesthesia_type_documentation,
        'AnesthesiaTypeDocumentation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_case_info,
        'AnesthesiaCaseInfo',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API calls -Unsigned department
   * @author - Arushi
   */
  interceptUnsignDepartmentApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.anesthesia_basic_module,
        'ModuleInfoSignature',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_configuration_toggle_map,
        'ConfigurationToggle',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API calls - department order medication addition
   * @author - Arushi
   */
  interceptDepartmentOrderMedication() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_physician_order_documentation,
        'PhysicianOrder',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API calls -click on department order button
   * @author - Arushi
   */
  interceptDepartmentOrders() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.get_physician_order_documentation,
        'PhysicianOrder',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API Calls - Click on the Phase1
   * @author - Praveen
   */
  interceptPhase1DeptApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_summary,
        'CaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.banner_info,
        'BannerInformation',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API Calls - Click on the Phase2
   * @author - Praveen
   */
  interceptPhase2DeptApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.config_case_summary,
        'ConfigCaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.banner_info,
        'BannerInformation',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - API Calls - Click on the Phase3
   * @author - Praveen
   */
  interceptPhase3DeptApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.config_case_summary,
        'ConfigCaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.banner_info,
        'BannerInformation',
        200
      ),
    ];
    return endpoints;
  }
}
