import {
  CommonGetLocators,
  YesOrNo,
} from '../../../../support/common-core-libs/application/common-core';
import SISChartsDesktop from '../../../../support/common-core-libs/application/sis-charts-desktop';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

import { CommonDepartmentInformation } from '../../../../test-data-models/sis-charts/sis-charts-department-model';

import { NursingDept } from '../../facesheet/enums/charts-cover-facesheet.enum';

import { OR_PRE_OPERATIVE } from './or/pre-operative.or';

/* const values */
const sisChartsDesktop = new SISChartsDesktop();

export default class PreOperativeDepartment {
  private OR_IN_OUT_TIME_POP_UP = OR_PRE_OPERATIVE.ENTER_IN_OUT_TIME_POP_UP;

  /**
   * @details - To enter admission time
   * @param deptInfo - using AdmissionTime and Room in CommonDepartmentInformation
   * @API - API's are not available
   * @author Divya
   */
  enterAdmissionTimeRoom(deptInfo: CommonDepartmentInformation) {
    sisChartsDesktop.clickEnterInOutTIme();
    sisChartsDesktop.enterAdmissionTime(
      NursingDept.pre_operative,
      deptInfo.AdmissionTime!
    );
    if (deptInfo.Room != undefined) {
      sisChartsDesktop.selectRoom(NursingDept.pre_operative, deptInfo.Room!);
    }
  }

  /**
   * @details - click on yes or no toggle in ready for transfer
   * @param yesNo - to click yes or no toggle
   * @API - API's are not available
   * @author Divya
   */
  clickYesNoInReadyForTransfer(yesNo: string = YesOrNo.no) {
    cy.cGet(this.OR_IN_OUT_TIME_POP_UP.PATIENT_READY_FOR_TRANSFER[1]).then(
      ($ele) => {
        if (
          (yesNo == YesOrNo.yes && $ele.hasClass(CommonGetLocators.empty)) ||
          (yesNo == YesOrNo.no && $ele.hasClass(CommonGetLocators.not_empty))
        ) {
          cy.cIsVisible(
            selectorFactory.getLabelText(
              this.OR_IN_OUT_TIME_POP_UP.PATIENT_READY_FOR_TRANSFER[0]
            ),
            ''
          )
            .parent()
            .find(CoreCssClasses.Toggle.loc_on_off_switch_label)
            .click();
        }
      }
    );
  }
}
