import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const OR_PRE_OPERATIVE = {
  PRE_OPERATIVE_PANEL: ['Pre-Operative', '#preOperative-tmp'],
  ENTER_IN_OUT_BUTTON: ['Enter In/Out Time', '.department-btn'],
  ENTER_IN_OUT_TIME_POP_UP: {
    ADMISSION_TIME: ['Admission Time', '#preOperative-tmp #_showtime'],
    ROOM_DROPDOWN: [
      'Room',
      CommonUtils.concatenate(
        '#pop_preOperativeRoomsList_select ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
    PATIENT_READY_FOR_TRANSFER: [
      'Patient Ready for Transfer',
      '#readyfortransfer_preop',
    ],
    TRANSFER: ['Transfer', '#preop_transfer_btn'],
    PATIENT_HAND_OFF: {
      SUB_HEADER: ['Patient Handoff'],
      WITHIN_FACITLITY: ['Within Facility'],
      TRANSFER_DATE_TIME_NOW_BUTTON: [
        'Transfer Date Time Now Button',
        '#time_dir_btn',
      ],
      DONE: ['Done', '#handsoff_save_btn'],
    },
  },
};
