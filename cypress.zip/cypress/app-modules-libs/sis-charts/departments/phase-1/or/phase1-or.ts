import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const OR_PHASE1 = {
  PHASE1_PANEL: ['Phase 1', '#phase1-tmp'],
  ENTER_IN_OUT_TIME_POP_UP: {
    ADMISSION_TIME: ['Admission Time', '#phase1-tmp #_showtime'],
    ROOM_DROPDOWN: [
      'Room',
      CommonUtils.concatenate(
        '#phase1-tmp #aocp_recoveryRoomsList_select ',
        CoreCssClasses.DropDown.loc_dropdown_btn
      ),
    ],
  },
};
