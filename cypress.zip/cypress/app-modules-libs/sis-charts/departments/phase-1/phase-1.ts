import SISChartsDesktop from '../../../../support/common-core-libs/application/sis-charts-desktop';

import { CommonDepartmentInformation } from '../../../../test-data-models/sis-charts/sis-charts-department-model';

import { NursingDept } from '../../facesheet/enums/charts-cover-facesheet.enum';

/* instance variables */
const sisChartsDesktop = new SISChartsDesktop();

export default class Phase1Department {
  /**
   * @details - To enter admission time
   * @param deptInfo - using AdmissionTime and Room in CommonDepartmentInformation
   * @API - API's are not available
   * @author Divya
   */
  enterAdmissionTimeRoom(deptInfo: CommonDepartmentInformation) {
    sisChartsDesktop.clickEnterInOutTIme();
    sisChartsDesktop.enterAdmissionTime(
      NursingDept.phase1,
      deptInfo.AdmissionTime!
    );
    if (deptInfo.Room != undefined) {
      sisChartsDesktop.selectRoom(NursingDept.phase1, deptInfo.Room!);
    }
  }
}
