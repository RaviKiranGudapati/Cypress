import {
  SubRoutes,
  WaitMethods,
} from '../../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../../support/common-core-libs/framework/api-endpoint';

export default class WorklistApi {
  /**
   * @details - After clicking in/out button in nursing desktop
   * @author - Arushi
   */
  interceptClickAddInOrOutButtonApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_monitor_configuration,
        'PatientMonitorConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_summary_information,
        'CaseSummaryInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.dic_items_all_get,
        'DictionaryV2',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - After entering admission time in nursing desktop
   * @author - Dharani
   */
  interceptEnterAdmissionTimeApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_area_care_information,
        'GetAreaCareInformation',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - After selecting value from room dropdown in nursing desktop
   * @author - Dharani
   */
  interceptSelectRoomDropdownApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_area_care_staff_details,
        'GetAreaCareStaffDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.update_area_care_information,
        'UpdateAreaCareInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_update_case_status,
        'UpdateCaseStatus',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - After click on Operative Time Out Button in nursing desktop
   * @author - Dharani
   */
  interceptClickOperativeTimeOutApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_operative_timeout,
        'GetOperativeTimeout',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.record_header,
        'RecordHeader',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - After Clicking Sign Button in Operative Time Out Popup in nursing desktop
   * @author - Dharani
   */
  interceptClickSignInOperativeTimeoutApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_operative_timeout_sign,
        'OperativeTimeoutSign',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - After Clicking Done Button in Operative Time Out Popup in nursing desktop
   * @author - Dharani
   */
  interceptClickDoneInOperativeTimeoutApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.put_operative_timeout_update,
        'OperativeTimeoutUpdate',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - After click on transfer button in nursing desktop
   * @author - Dharani
   */
  interceptClickTransferApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_handoff,
        'GetPatientHandoff',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_patient_related_dictionaries,
        'PatientRelatedDictionaries',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_summary_info,
        'GetCaseSummaryInfo',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_staff_for_organization,
        'GetStaffForOrganization',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_combined_role_group_staff,
        'GetCombinedRoleGroupStaff',
        200
      ),
    ];
    return endpoints;
  }
}
