import { ApiEndpoint } from '../../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../../support/common-core-libs/application/constants/sub-routes.constants';

export default class ConsentsTaskApi {
  /**
   * @details - After selecting added consent in nursing desktop
   * @author -Arushi
   */
  interceptAddedConsentApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_consent_clinical,
        'ConsentClinical',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_health_information_exchange_list,
        'HealthInformationExchangeList',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Save Consents
   * @author -Madhu Kiran
   */
  interceptSaveConsents(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_consent_clinical,
        'ConsentClinical',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.security_release_lock,
        'ReleaseLock',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_consent_summary,
        'ConsentSummary',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Procedure Reload Button
   * @author -Madhu Kiran
   */
  interceptProcedureReloadButton(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.schedule_info_details_by_case_summary_id,
        'ScheduleInfoDetailsByCaseSummaryId',
        200
      ),
    ];
  }
}
