import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../../support/common-core-libs/application/sis-office-desktop';

import { Consents } from '../../../../test-data-models/sis-office/case/patient-case.model';

import { OR_NURSING_CONSENTS } from './or/consents.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_CASE_CHECK_IN } from '../../../sis-office/case-check-in/or/patient-check-in.or';

import ConsentsTaskApi from './api/consents.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

export default class ConsentsTask {
  private or_ConsentsPopUp = OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP;
  private consentsTaskApi = new ConsentsTaskApi();

  /**
   * @details - Select the consent from list to edit
   * @param - consentName
   * @APIs are available - Implemented completely
   * @author -Arushi
   **/
  selectCaseConsent(consentName: string) {
    const interceptCollection = this.consentsTaskApi.interceptAddedConsentApi();
    this.verifyConsentHeaderFields();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getTdText(consentName), consentName, false, true);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on Performing Physician Dropdown and select Physicians and close dropdown in consents
   * @param consent - using PerformingPhysician from Consents Model
   * @APIs are not available
   */
  selectPerformingPhysicians(consent: Consents) {
    sisOfficeDesktop.selectValueFromDropdown(
      this.or_ConsentsPopUp.PERFORMING_PHYSICIAN[1],
      this.or_ConsentsPopUp.PERFORMING_PHYSICIAN[0],
      CoreCssClasses.List.loc_list_item,
      consent.PerformingPhysician!,
      true
    );
  }

  /**
   * @details - Save the updated consents
   * @APIs are available - Implemented completely
   * @author -Madhu Kiran
   */
  saveConsents() {
    const interceptCollection = this.consentsTaskApi.interceptSaveConsents();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getButtonText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
      ),
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
      false,
      false,
      { force: true }
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify selected Performing Physician Dropdown in consents
   * @param consent - using PerformingPhysician from Consents Model
   * @APIs are not available
   */
  verifyPerformingPhysicians(consent: Consents) {
    consent.PerformingPhysician!.forEach((val: string) => {
      cy.cIsVisible(selectorFactory.nursingConsentAddedPhysician(val), val);
    });
  }

  /**
   * @details - Verify Procedures in consents
   * @param procedureNames - To check the procedure names in consents
   * @APIs are not available
   */
  verifyProcedure(procedureNames: string) {
    cy.cHasValue(
      this.or_ConsentsPopUp.PROCEDURES_TEXTBOX[1],
      this.or_ConsentsPopUp.PROCEDURES_TEXTBOX[0],
      procedureNames
    );
  }

  /**
   * @details click on physician sign
   * @APIs are not available
   */
  clickPhysicianSign() {
    cy.cClick(
      this.or_ConsentsPopUp.PHYSICIAN_SIGN[1],
      this.or_ConsentsPopUp.PHYSICIAN_SIGN[0],
      false,
      true
    );
  }

  /**
   * @details click on procedure reload button
   * @APIs are available - Implemented completely
   * @author -Madhu Kiran
   */
  clickProcedureReloadButton() {
    const interceptCollection =
      this.consentsTaskApi.interceptProcedureReloadButton();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.or_ConsentsPopUp.PROCEDURE_RELOAD_BUTTON[1],
      this.or_ConsentsPopUp.PROCEDURE_RELOAD_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
    // Adding assertion for the procedure to be load
    const fields = [
      this.or_ConsentsPopUp.PERFORMING_PHYSICIAN[1],
      OR_PATIENT_CASE_CHECK_IN.FORMS_CONSENTS.EDIT_CONSENT[1],
    ];
    fields.forEach((field) => {
      cy.shouldBeEnabled(field);
    });
  }

  /**
   * @details - To verify consents fields in nursing desktop consents field
   * @APIs are not available
   */
  verifyConsentHeaderFields() {
    const consHeaders = [
      OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP.ADD_CONSENTS[1],
      OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP.CONSENT_NAME_HEADER[1],
      OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP.EXPIRATION_DATE[1],
      OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP.REQUIRED_SIGNATURE[1],
    ];
    consHeaders.forEach((consHeadersList) => {
      cy.shouldBeEnabled(consHeadersList);
    });
  }

  /**
   * @details click on cross icon in consents popup.
   * @APIs are not available
   * @author - Praveen
   */
  clickConsentsCrossIcon() {
    cy.cClick(
      OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP.CROSS_ICON[1],
      OR_NURSING_CONSENTS.CASE_CONSENTS.CONSENTS_POPUP.CROSS_ICON[0]
    );
  }
}
