import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const OR_NURSING_CONSENTS = {
  CASE_CONSENTS: {
    CONSENTS_POPUP: {
      PERFORMING_PHYSICIAN: [
        'Performing Physician',
        CommonUtils.concatenate(
          '#btn_csi_sp_consent ',
          CoreCssClasses.DropDown.loc_fa_dropdown_arrow
        ),
      ],
      PROCEDURES_TEXTBOX: ['Procedure Textbox', '#ta_csi_spi_consent'],
      PROCEDURE_RELOAD_BUTTON: ['Procedure Relaod Button', '.procedure-reload'],
      SCHEDULED_PROCEDURE_TOOLTIP: ['Procedure ToolTip', '.custom-tooltip'],
      PHYSICIAN_SIGN: ['Physician Sign', '#btn_S_stf_sign'],
      EDIT_CONSENTS_EDITOR: ['Consent Editor', '[id^=cke_editor] div div p'],
      CONSENT_NAME_HEADER: ['consent name-header', '.consent-name-header'],
      ADD_CONSENTS: ['Add Consents', '#btn_add_consent_case'],
      REQUIRED_SIGNATURE: ['Required Signature', '.req-sign-header'],
      EXPIRATION_DATE: ['Expiration date', '.exp-date-header'],
      CROSS_ICON: [
        'Cross Icon',
        CommonUtils.concatenate('span', CoreCssClasses.Button.loc_fa_close),
      ],
    },
  },
};
