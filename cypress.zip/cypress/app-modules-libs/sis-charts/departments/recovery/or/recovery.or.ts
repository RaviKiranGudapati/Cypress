import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

export const OR_RECOVERY = {
  RECOVERY: {
    RECOVERY_PANEL: ['Recovery', '#phase1-tmp'],
    ENTER_IN_OUT_BUTTON: ['Enter In/Out Time', '.department-btn'],
    LABEL: 'Admission Time',
    HEADER: ['Title', '.navbar'],
    RECOVERY_ENTER_IN_OUT_POPUP: {
      ROOM_DROPDOWN: [
        'Room',
        CommonUtils.concatenate(
          '#aocp_recoveryRoomsList_select ',
          CoreCssClasses.DropDown.loc_dropdown_btn
        ),
      ],
      ROOM_NAME: ['Room Name', '#aocp_recoveryRoomsList_select span'],
      ADMISSION_TIME: ['Admission Time', '#phase1-tmp #_showtime'],
      ADMISSION_TIME_NOW_BUTTON: ['Now', '#aocp1_time_dir_btn'],
      TRANSFER_BUTTON: ['Transfer', '#aocp1_transfertime_btn'],
      TRANSFER_POPUP: {
        DISCHARGED_TO: [
          'Discharged To',
          '#phf_dischargeto_select .dropdown-btn',
        ],
        DISCHARGE_NOW_BUTTON: [
          'Discharge Date/Time Now',
          '.OutsideFacility .time-dir-btn > .button-primary-small',
        ],
        DISCHARGE_TIME: [
          'Discharge Date/Time',
          'div[class*="patienthandoff"] input#_showtime',
        ],
        OUTSIDE_FACILITY: ['Outside Facility'],
        WITHIN_FACILITY: ['Within Facility'],
        DONE_BUTTON: ['Done', '#handsoff_save_btn'],
        CASE_STATUS: [
          'Case Status',
          CommonUtils.concatenate(
            `#phf_caseStatusList_select div`,
            CoreCssClasses.DropDown.loc_dropdown_btn
          ),
        ],
      },
    },
  },
};
