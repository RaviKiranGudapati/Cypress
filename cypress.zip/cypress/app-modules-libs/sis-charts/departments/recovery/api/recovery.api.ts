import { ApiEndpoint } from '../../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../../support/common-core-libs/application/constants/sub-routes.constants';

export default class RecoveryDepartmentApi {
  /**
   * @details - after clicking enter and in and out time
   * @author - chandrika
   */
  interceptEnterInAndOutTimeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_monitor_configuration,
        'PatientMonitorConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_staff,
        'GetStaffByRole',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_summary_info,
        'GetCaseSummaryInfo',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_module_by_case_id,
        'GetModulesBycaseId',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_area_care_staff_details,
        'GetAreaofCareStaffDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_security_lock,
        'Security',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_staff_list,
        'StaffList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_staff_organization,
        'GetStaffForOrganization',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_area_care_information,
        'AreaCareInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_speciality_by_case,
        'GetSpecialityByCase',
        200
      ),
    ];
  }

  /**
   * @details - entering Time after clicking in and out time
   * @author - chandrika
   */
  interceptEnterTimeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_area_care_staff_details,
        'AreaOfCareStaffEntry',
        200
      ),
    ];
  }

  /**
   * @details - api after selecting room in department information
   * @author - chandrika
   */
  interceptRoomApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_area_care_staff_details,
        'AreaOfCareStaffEntry',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.update_area_care_information,
        'UpdateAreaCareInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_summary_info,
        'GetCaseSummaryInfo',
        200
      ),
    ];
  }

  /**
   * @details - api after clicking transfer in department information
   * @author - chandrika
   */
  interceptTransferApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_hand_off,
        'PatientHandOff',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_patient_related_dictionary,
        'PatientRelatedDictionary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_staff_organization,
        'GetStaffForOrganization',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_staff_list,
        'GetCombinedRoleGroupStaff',
        200
      ),
    ];
  }

  /**
   * @details - api after clicking Done button in department information
   * @author - chandrika
   */
  interceptDoneApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_area_care_staff_details,
        'GetAreaofCareStaffDetails',
        200
      ),
    ];
  }
}
