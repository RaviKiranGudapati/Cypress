import SISChartsDesktop from '../../../../support/common-core-libs/application/sis-charts-desktop';

import { CommonDepartmentInformation } from '../../../../test-data-models/sis-charts/sis-charts-department-model';

import { OR_PHASE3 } from './or/phase-3.or';

import { NursingDept } from '../../facesheet/enums/charts-cover-facesheet.enum';

/* instance variables */
const sisChartsDesktop = new SISChartsDesktop();

export default class Phase3Department {
  /**
   * @details - To enter admission time
   * @param deptInfo - using AdmissionTime and Room in CommonDepartmentInformation
   * @API - API's are not available
   * @author Divya
   */
  enterAdmissionTimeRoom(deptInfo: CommonDepartmentInformation) {
    sisChartsDesktop.clickEnterInOutTIme();
    sisChartsDesktop.enterAdmissionTime(
      NursingDept.phase3,
      deptInfo.AdmissionTime!
    );
    if (deptInfo.Room != undefined) {
      sisChartsDesktop.selectRoom(NursingDept.phase3, deptInfo.Room!);
    }
  }

  /**
   * @details - click on transfer button
   * @API - API's are not available
   * @author Divya
   */
  clickOnTransfer() {
    cy.cClick(
      OR_PHASE3.ENTER_IN_OUT_TIME_POP_UP.TRANSFER_BUTTON[1],
      '',
      false,
      true
    );
  }
}
