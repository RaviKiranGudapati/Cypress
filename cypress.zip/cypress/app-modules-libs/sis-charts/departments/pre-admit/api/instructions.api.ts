import { ApiEndpoint } from '../../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../../support/common-core-libs/application/constants/sub-routes.constants';

export default class InstructionsApi {
  /**
   * @details - To click on the instructions in pre-admit
   * @author - Praveen
   */
  interceptInstructionsApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_templates_for_case,
        'GetTemplatesForCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_worklist_case_details,
        'GetWorklistCaseDetails',
        200
      ),      
      new ApiEndpoint(WaitMethods.get, SubRoutes.nurse_note, 'NurseNote', 200),    
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.documentation_state,
        'DocumentState',
        200
      ), 
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.worklist_clinical,
        'WorklistClinical',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_order_documentation,
        'PhysicianOrderDocumentation',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - To check the api calls while select the worklist
   * @author - Praveen
   */
  interceptWorklistApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.worklist_clinical,
        'WorklistClinical',
        200
      ),
    ];
    return endpoints;
  }

   /**
   * @details - To click on the instructions in pre-admit
   * @author - Praveen
   */
   interceptWorklistIconApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.worklist_clinical,
        'WorklistClinical',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.worklist_clinical,
        'WorklistClinical',
        200
      ), 
    ];
    return endpoints;
  }
}
