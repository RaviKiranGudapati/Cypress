import {
  CommonGetLocators,
  InvokeMethods,
  ShouldMethods,
  TriggerAttributes,
  YesOrNo,
} from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

import { OR_INSTRUCTIONS } from './or/instructions.or';

import InstructionsApi from './api/instructions.api';

export class PreAdmitInstructions {
  private instructionsApi = new InstructionsApi();

  /**
   * @details - To click on instructions
   * @API - API's are available - Implemented Completely
   * @author - Divya
   */
  clickInstructions() {
    const interceptCollection = this.instructionsApi.interceptInstructionsApi();
    cy.cIntercept(interceptCollection);
    cy.cGet(selectorFactory.getDivText(OR_INSTRUCTIONS.PRE_ADMIT.SUB_HEADER[0]))
      .parents(OR_INSTRUCTIONS.PRE_ADMIT.PANEL[1])
      .contains(OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.SUB_HEADER[0])
      .click();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To select the worklist
   * @param name - Used to select the desired worklist
   * @API - API's are available - Implemented Completely
   * @author - Divya
   */
  selectWorklistInPopUp(name: string) {
    const interceptCollection = this.instructionsApi.interceptWorklistApi();
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.WORKLIST_POPUP[1],
        ' ',
        selectorFactory.getSpanText(name)
      )
    )
      .eq(0)
      .invoke(InvokeMethods.show)
      .click({ force: true });

    cy.cGet(CommonGetLocators.body).then((body) => {
      if (
        body.find(OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.ERROR_MESSAGE[1])
          .length > 0
      ) {
        cy.cIntercept(interceptCollection);
        cy.cGet(
          OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.OVERRIDE_WORKLIST_POPUP[1]
        )
          .find(selectorFactory.getButtonText(YesOrNo.yes))
          .should(ShouldMethods.visible)
          .click({ force: true });
        cy.cWaitApis(interceptCollection);
      }
    });
    cy.cNotExist(
      OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.WORKLIST_POPUP[1],
      OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.WORKLIST_POPUP[0]
    );
  }

  /**
   * @details - To edit the added item in documents and disclosure
   * @param item - Used to select which item to be edited
   * @param editItem - Used to edit the selected item
   * @API - API's are not available
   * @author - Divya
   */
  editAddedItemInDocumentsAcknowledged(item: string, editItem: string) {
    cy.cGet(selectorFactory.getSpanText(item), item)
      .trigger(TriggerAttributes.mousemove)
      .click();
    cy.cType(
      OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.EDIT_TEXT[1],
      OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.EDIT_TEXT[0],
      editItem
    );
  }

  /**
   * @details - To delete the added item in documents and disclosure
   * @param item - Used to delete the item
   * @API - API's are not available
   * @author - Divya
   */
  deleteAddedItem(item: string) {
    cy.cGet(selectorFactory.getSpanText(item), item).as('ele');
    cy.cGet('@ele')
      .trigger(TriggerAttributes.mousemove)
      .then(() => {
        cy.cGet('@ele')
          .parents(CommonGetLocators.td)
          .find(CoreCssClasses.Trash.loc_trash_icon)
          .invoke(InvokeMethods.show)
          .click();
      });
  }

  /**
   * @details - To click on Worklist Icon
   * @API - API's are available and partially implemented
   * @author - Divya
   */
  clickWorkListIcon() {
    const interceptCollection = this.instructionsApi.interceptWorklistIconApi();
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (
        body.find(OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.WORKLIST_POPUP[1])
          .length == 0
      ) {
        cy.cIntercept(interceptCollection);

        cy.cGet(
          OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS.WORKLIST_ICON[1]
        ).click();
        cy.cWaitApis(interceptCollection);
      }
      cy.cIsVisible(
        selectorFactory.getSpanText(
          OR_INSTRUCTIONS.PRE_ADMIT.INSTRUCTIONS
            .PRE_ADMIT_INSTRUCTIONS_WORKLISTS[0]
        ),
        ''
      );
    });
  }
}
