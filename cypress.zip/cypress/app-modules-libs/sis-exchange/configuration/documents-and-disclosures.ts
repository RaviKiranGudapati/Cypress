import {
    CommonGetLocators,
    DoneOrCancel,
    InvokeAttributes,
    InvokeMethods,
    ShouldMethods,
    TriggerAttributes,
  } from '../../../support/common-core-libs/application/common-core';
  import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
  import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
  import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
  
  import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';
  import {
    SubRoutes,
    WaitMethods,
  } from '../../../support/common-core-libs/application/constants/sub-routes.constants';
  
  import { OR_DOCUMENTS_AND_DISCLOSURES } from './or/documents-and-disclosures.or';
  
  /* constant values */
  const number100 = '100';
  const number1000 = '1000';
  
  export class DocumentsAndDisclosures {
    /**
     * @details - To upload the file
     * @param filePath - using file path to upload file from framework.
     * @API - API's are available and partially implemented
     * @author - Divya
     */
    uploadFile(filePath: string) {
      const fileLoc = CommonUtils.concatenate('files-to-upload/', filePath);
      CommonUtils.concatenate(
        OR_DOCUMENTS_AND_DISCLOSURES.ADD_DOCUMENT_POPUP[1],
        OR_DOCUMENTS_AND_DISCLOSURES.BROWSE[1]
      );
      cy.cGet(
        CommonUtils.concatenate(
          OR_DOCUMENTS_AND_DISCLOSURES.ADD_DOCUMENT_POPUP[1],
          OR_DOCUMENTS_AND_DISCLOSURES.BROWSE[1]
        )
      ).attachFile(fileLoc);
  
      cy.intercept(WaitMethods.post, SubRoutes.facility_disclosure_item).as(
        'Disclosure'
      );
  
      this.clickDoneInAddDocumentPopup();
  
      cy.wait('@Disclosure')
        .its('response.statusCode')
        .should(ShouldMethods.eq, 202);
    }
  
    /**
     * @details - To click on add button to upload file
     * @API - API's are not available
     * @author - Divya
     */
    clickAddButton() {
      cy.cClick(
        selectorFactory.getButtonText(OR_DOCUMENTS_AND_DISCLOSURES.ADD_BUTTON[0]),
        OR_DOCUMENTS_AND_DISCLOSURES.ADD_BUTTON[0]
      );
    }
  
    /**
     * @details - To verify browse for the selected file
     * @API - API's are not available
     * @author - Divya
     */
    verifyBrowseForFile() {
      cy.cNotExist(
        selectorFactory.getpHeaderText(
          OR_DOCUMENTS_AND_DISCLOSURES.ADD_DOCUMENT[0]
        ),
        '',
        false,
        true
      );
      cy.cIsEnabled(OR_DOCUMENTS_AND_DISCLOSURES.BROWSE[1], '');
    }
  
    /**
     * @details - To verify and click on show inactive
     * @param isYes - to click on yes or no
     * @API - API's are not available
     * @author - Divya
     */
    showInactive(isYes: boolean) {
      cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.INACTIVE_ROW[1]).as('Inactive');
      cy.cGet('@Inactive')
        .find(CommonGetLocators.h5)
        .should(
          ShouldMethods.include_text,
          OR_DOCUMENTS_AND_DISCLOSURES.SHOW_INACTIVE[0]
        );
  
      cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.SHOW_INACTIVE[1])
        .invoke(InvokeMethods.attribute, InvokeAttributes.data_test_id)
        .then(($val) => {
          if (
            (isYes == true && $val == InvokeAttributes.unchecked) ||
            (isYes == false && $val == InvokeAttributes.checked)
          ) {
            cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.SHOW_INACTIVE[1]).click();
          }
        });
    }
  
    /**
     * @details - To click on cross icon
     * @API - API's are not available
     * @author - Divya
     */
    clickCrossIcon() {
      cy.cClick(
        CoreCssClasses.Button.loc_close_icon,
        OR_DOCUMENTS_AND_DISCLOSURES.CLOSE[0],
        false,
        true
      );
    }
  
    /**
     * @details - To verify preview of the file
     * @API - API's are not available
     * @author - Divya
     */
    verifyPreviewFile() {
      cy.cClick(
        selectorFactory.getH5Text(OR_DOCUMENTS_AND_DISCLOSURES.PREVIEW_FILE[0]),
        OR_DOCUMENTS_AND_DISCLOSURES.PREVIEW_FILE[0]
      );
      cy.cIsVisible(OR_DOCUMENTS_AND_DISCLOSURES.PREVIEW_FILE[1], '');
      this.clickCrossIcon();
    }
  
    /**
     * @details - To delete the added item
     * @param item - used as string to delete the added item
     * @API - API's are not available
     * @author - Divya
     */
    deleteAddedItem(item: string) {
      cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.ITEMS_LIST[1], item)
        .find(selectorFactory.getSpanText(item))
        .as('ele');
      cy.cGet('@ele')
        .trigger(TriggerAttributes.mousemove)
        .then(() => {
          cy.cGet('@ele')
            .parent(CommonGetLocators.li)
            .invoke(InvokeMethods.show)
            .find(CommonGetLocators.i)
            .click();
        });
    }
  
    /**
     * @details - To verify the file name from the list of files
     * @param name - used as string to verify name
     * @API - API's are not available
     * @author - Divya
     */
    verifyAddedFile(name: string) {
      cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.ITEMS_LIST[1], name)
        .find(selectorFactory.getSpanText(name))
        .should(ShouldMethods.include_text, name);
    }
  
    /**
     * @details - To verify the maximum size and supported file format
     * @API - API's are not available
     * @author - Divya
     */
    verifyMaximumSizeAndSupportedFile() {
      cy.cIncludeText(
        OR_DOCUMENTS_AND_DISCLOSURES.MAX_FILE_SIZE_INFO[1],
        '',
        AppErrorMessages.maximum_file_size
      );
      cy.cIncludeText(
        OR_DOCUMENTS_AND_DISCLOSURES.FILE_TYPE_INFO[1],
        '',
        AppErrorMessages.supported_file_type
      );
    }
  
    /**
     * @details - To click on done button
     * @API - API's are available - Implemented Completely
     * @author - Divya
     */
    clickDoneInAddDocumentPopup() {
      cy.intercept(WaitMethods.get, SubRoutes.facility_disclosure_addkey).as(
        'AddKey'
      );
      cy.intercept(WaitMethods.post, SubRoutes.facility_disclosure_item).as(
        'Disclosure'
      );
  
      cy.cClick(
        selectorFactory.getButtonText(DoneOrCancel.done),
        DoneOrCancel.done
      );
      cy.wait('@AddKey').its('response.statusCode').should(ShouldMethods.eq, 200);
      cy.wait('@Disclosure')
        .its('response.statusCode')
        .should(ShouldMethods.eq, 202);
    }
  
    /**
     * @details - To verify the maximum length for file length and statement
     * @API - API's are not available
     * @author - Divya
     */
    verifyMaxLengthForFileNameAndStatement() {
      cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.FILE_NAME[1]).invoke(
        InvokeMethods.attribute,
        InvokeAttributes.maxlength,
        number100
      );
      cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.STATEMENT_AREA[1]).invoke(
        InvokeMethods.attribute,
        InvokeAttributes.maxlength,
        number1000
      );
    }
  
    /**
     * @details - To search and select file
     * @param name - file name that needs to be searched and to verify
     * @API - API's are not available
     * @author - Divya
     */
    searchAndSelectFile(name: string) {
      cy.cType(
        OR_DOCUMENTS_AND_DISCLOSURES.SEARCH[1],
        OR_DOCUMENTS_AND_DISCLOSURES.SEARCH[0],
        name
      );
      cy.cGet(OR_DOCUMENTS_AND_DISCLOSURES.DOCUMENT_ITEM[1])
        .eq(0)
        .click()
        .should(ShouldMethods.include_text, name);
    }
  }
  