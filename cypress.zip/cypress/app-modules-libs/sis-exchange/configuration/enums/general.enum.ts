/* enum values */
export enum generalEnableText {
    general_enable_text = 'Enable Editing Booked Appointments',
  }