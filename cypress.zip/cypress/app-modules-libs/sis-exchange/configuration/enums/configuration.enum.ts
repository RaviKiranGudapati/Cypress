export enum SisLinkSettingsOptions {
    general = 'General',
    users = 'Users',
    mandatory_fields = 'Mandatory Fields',
    sis_link_notifications = 'SIS-Link Notifications',
  }
  
  export enum FacilityOptions {
    branding = 'Branding',
    contact_settings = 'Contact Settings',
    documents_and_disclosures = 'Documents and Disclosures',
  }
  
  export enum PreOpNotificationsOptions {
    general_reminders = 'General Reminders',
    speciality_specific_reminders = 'Speciality-Specific-Reminders',
    welcome_messages = 'Welcome Messages',
  }
  
  export enum PostOpNotificationsOptions {
    general_reminders = 'General Reminders',
    speciality_specific_reminders = 'Speciality-Specific-Reminders',
    post_op_messages = 'Post-Op Messages',
  }
  
  export enum WorklistOptions {
    pre_admission_qx = 'Pre-Admission Qx',
    pre_admission_instructions = 'Pre-Admission Instructions',
    post_operative_qx = 'Post-Operative Qx',
  }
  