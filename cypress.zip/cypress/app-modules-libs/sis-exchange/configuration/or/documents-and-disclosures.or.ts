export const OR_DOCUMENTS_AND_DISCLOSURES = {
    SEARCH: ['Search', `[data-test-id="filter-text-input"]`],
    INACTIVE_ROW: ['Inactive Row', '.items-list-inactivate-row'],
    DOCUMENT_ITEM: [`Document Item`, `[data-test-id*="document-item"]`],
    ADD_BUTTON: ['Add'],
    ADD_DOCUMENT: ['Add Document'],
    ADD_DOCUMENT_POPUP: ['Document Pop-up', '.ui-shadow '],
    BROWSE: ['Browse', `input[type='file']`],
    MAX_FILE_SIZE_INFO: [
      'Max File Size Info',
      `[data-test-id='max-file-size-info-modal']`,
    ],
    SHOW_INACTIVE: ['Show Inactive', 'body .switch-slider'],
    FILE_NAME: ['File Name', `[data-test-id="file-name-input"]`],
    PREVIEW_FILE: ['Preview File', `[data-test-id="image-preview"]`],
    STATEMENT_AREA: ['Statement Area', `[data-test-id="statement-textarea"]`],
    FILE_TYPE_INFO: ['File Type Info', `[data-test-id='file-type-info-modal']`],
    ITEMS_LIST: ['Items List', '.items-list-items-list li'],
    CLOSE: ['Close'],
  };
  