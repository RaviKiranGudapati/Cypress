import { selectorFactory } from "../../../../support/common-core-libs/framework/selector-factory";

export const OR_EXCHANGE_CONFIGURATION = {
  USER_MENU: ['SIS Exchange User Menu', '.user-info .userName'],
  USER_MENU_DROPDOWN: {
    MY_SETTINGS: ['My Settings'],
    APPLICATION_SETTINGS: ['Application Settings'],
    USER_SETTINGS: ['User Settings'],
    CHANGE_LOGIN_LOCATION: ['Change Login Location'],
    SCHEDULING_DESKTOP: ['Scheduling Desktop'],
    ANESTHESIA_BILLING_DESKTOP: ['Anesthesia Billing Desktop'],
    LOGOUT: ['Logout', '.success .logout'],
  },
  LOGOUT_CONFIRMATION: {
    YES: ['Yes'],
    NO: ['No'],
  },
  SIS_LINK_SETTINGS: {
    GENERAL: ['General', '[href="#/asc/application-settings/general"]'],
    USERS: ['Users', '[href="#/asc/application-settings/users"]'],
    MANDATORY_FIELDS: [
      'Mandatory Fields',
      '[href="#/asc/application-settings/appointment-settings"]',
    ],
    SIS_LINK_NOTIFICATIONS: [
      'SIS-Link Notifications',
      '[href="#/asc/application-settings/sis-link-notifications"]',
    ],
    TOGGLE: ['Toggle', '.switch-slider'],
    CONTACT_SETTINGS: ['Contact Settings'],
    PRE_ADMISSION_INSTRUCTIONS: ['Pre-Admission Instructions'],
    DOCUMENTS_AND_DISCLOSURES: ['Documents and Disclosures'],
  },
  PATIENT_STATEMENTS: ['Patient Statements', '#Patient Statements_link'],

  CONFIG_ADD_ON_FEATURES: {
    ADD_ON_FEATURES: ['Add On Features', '#Add.On.Features_btn'],
    PATIENT_STATEMENT_INCLUDE_INSURANCE: [
      'Patient Statement Include Insurances CSV Changes',
      'label[for = "configFeaturesPatient Statement Include Insurances CSV Changes"] span',
    ],
  },

  PHYSICIAN_NOTIFICATION: [
    'Physician Notification',
    '[href="#/asc/application-settings/physician-notifications"]',
  ],
  DICTIONARIES: [
    'Dictionaries',
    '[href="#/asc/application-settings/dictionaries"]',
  ],
  FACILITY: {
    BRANDING: ['Branding', '[href="#/asc/application-settings/branding"]'],
    CONTACT_SETTINGS: [
      'Contact Settings',
      '[href="#/asc/application-settings/contact"]',
    ],
    DOCUMENTS_AND_DISCLOSURES: [
      'Documents and Disclosures',
      '[href="#/asc/application-settings/facility-disclosure"]',
    ],
  },
  PRE_OP_NOTIFICATIONS: {
    DATE_PICKER: ['Date Picker', 'input.datepicker'],
    DISABLE_PORTAL_REQUEST_TOGGLE: [
      '',
      `.notifications-item:contains('Send Patient Portal requests?') .notifications-button-checked:contains('No')`,
    ],
    ENABLE_PORTAL_REQUEST_YES: [
      '',
      `.notifications-item:contains('Send Patient Portal requests?') .notifications-group:contains('Yes')`,
    ],
    SEND_REQUEST_PRE_OP: [
      'Send patient portal request',
      selectorFactory.getH5Text('Send Patient Portal requests?'),
    ],
    GENERAL_REMINDERS: [
      'General Reminders',
      '[href="#/asc/application-settings/pre-op-general-settings"]',
    ],
    SPECIALITY_SPECIFIC_REMINDERS: [
      'Speciality-Specific Reminders',
      '[href="#/asc/application-settings/pre-op-speciality-specific-settings"]',
    ],
    WELCOME_MESSAGES: [
      'Welcome Messages',
      '[href="#/asc/application-settings/welcome-messages"]',
    ],
  },

  POST_OP_NOTIFICATIONS: {
    GENERAL_REMINDERS: [
      'General Reminders',
      '[href="#/asc/application-settings/post-op-general-settings"]',
    ],
    SPECIALITY_SPECIFIC_REMINDERS: [
      'Speciality-Specific Reminders',
      '[href="#/asc/application-settings/post-op-speciality-specific-settings"]',
    ],
    POST_OP_MESSAGES: [
      'Post-op Messages',
      '[href="#/asc/application-settings/post-op-messages"]',
    ],

    APPOINTMENT_TYPE_HEADERS: ['Appointment Type', '.appointment-types-header'],
  },

  WORKLISTS: {
    PRE_ADMISSION_QX: [
      'Pre-Admission QX',
      '[href="#/asc/application-settings/pre-admission-qx"]',
    ],
    PRE_ADMISSION_INSTRUCTIONS: [
      'Pre-Admission Instructions',
      '[href="#/asc/application-settings/pre-admission-instructions"]',
    ],
    POST_OPERATIVE_QX: [
      'Post-Operative Qx',
      '[href="#/asc/application-settings/post-operative-qx"]',
    ],
  },
  USER_SETTINGS: {
    DONE: ['Done', '.done-button'],
    CHANGE_PASSWORD: ['Change Password', '[label="Change Password"]'],
  },
};
