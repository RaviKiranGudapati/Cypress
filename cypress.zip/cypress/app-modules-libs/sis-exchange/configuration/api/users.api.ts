import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export default class UsersApi {
  /**
   * @details - Api collection for user Configuration
   * @author - Madhu Kiran
   */
  interceptUserConfiguration(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.password_settings,
        'PasswordSettings',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.practice_management,
        'PracticeManagement',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.current_user,
        'CurrentUser',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.application_map,
        'ApplicationMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.config_toggle_map,
        'GetMultiFactorAuthenticationConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.practice_management_staff,
        'Configuration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_configuration,
        'Staff',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Mandatory Field Configuration
   * @author - Madhu Kiran
   */
  interceptMandatoryFieldsConfiguration(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.mandatory_fields,
        'MandatoryFields',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Selecting Physician in user Configuration
   * @author - Madhu Kiran
   */
  interceptSelectPhysician(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.practice_management,
        'PracticeManagement',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.config_toggle_map,
        'GetMultiFactorAuthenticationConfiguration',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after adding user by clicking done button user Configuration
   * @author - Dharani
   */
  interceptClickDoneInAdd() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.admin_application_map,
        'AdminApplicationMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.practice_management,
        'PracticeManagement',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_access,
        'GetPhysicianAccess',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - Api collection after searching the user
   * @author - Dharani
   */
  interceptSearchUser() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.practice_management,
        'PracticeManagement',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - Api collection after selecting the user
   * @author - Dharani
   */
  interceptSelectUser() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_access,
        'GetPhysicianAccess',
        200
      ),
    ];
    return endpoints;
  }
}
