import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export default class ConfigurationApi {
  /**
   * @details - Api collection for select the option in user menu dropdown.
   * @author - Praveen
   */
  interceptSchedulingDesktopApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_data_ppe,
        'SchedulingData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.ppe_scheduling_desktop,
        'PPEDataRange',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting General Reminders option in Pre-Op Notifications
   * @author - Arushi
   */
  interceptPreOpGeneralReminder(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_notification_configuration,
        'NotificationConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_appointment_types,
        'AppointmentTypes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_features,
        'GetFeatures',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Specialty-Specific Reminders option in Pre-Op Notifications
   * @author - Arushi
   */
  interceptPreOpSpecialitySpecificReminder(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_speciality_notification_configuration,
        'SpecialityNotificationConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_post_op_notification_configuration,
        'PostOpNotificationConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_specialities,
        'GetSpecialities',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Welcome Messages option in Pre-Op Notifications
   * @author - Arushi
   */
  interceptPreOpWelcomeBackMessages(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_configuration_ppe,
        'GetConfigurationPpe',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_notification_template,
        'NotificationTemplate',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting General Reminders option in Post-Op Notifications
   * @author - Arushi
   */
  interceptPostOpGeneralReminder(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_post_op_notification_configuration,
        'PostOpNotification',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_appointment_types,
        'AppointmentTypes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_configuration_ppe,
        'ConfigurationPpe',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Specialty-Specific Reminders option in Post-Op Notifications
   * @author - Arushi
   */
  interceptPostOpSpecialitySpecificReminder(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_speciality_notification,
        'SpecialityNotification',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_post_op_notification_configuration,
        'PostOpNotificationConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_specialities,
        'GetSpecialities',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Post-Op Messages option in Post-Op Notifications
   * @author - Arushi
   */
  interceptPostOpMessages(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_notification_template_post_op,
        'NotificationTemplate',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_configuration_ppe,
        'ConfigurationPpe',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Pre-Admission Instructions option in Worklists
   * @author - Arushi
   */
  interceptPreAdmissionInstruction(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_specialities,
        'Specialities',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_worklist_template_name,
        'TemplateName',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Physician Notifications in Configuration
   * @author - Arushi
   */
  interceptPhysicianNotification(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_configuration,
        'Configuration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.post_physician_notification,
        'PhysicianNotification',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting general option in sis-link settings
   * @author - Dharani
   */
  interceptSisLinkGeneral(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_general_sis_link_settings,
        'GeneralSisLinkSettings',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.practice_management_staff,
        'PracticeManagementStaff',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting users option in sis-link settings
   * @author - Dharani
   */
  interceptSisLinkUsers(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.password_settings,
        'PasswordSettings',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.practice_management,
        'PracticeManagementStaff',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.application_map,
        'ApplicationMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_current_case,
        'GetCurrentCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.config_toggle_map,
        'ConfigToggleMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_configuration,
        'GetConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.config_toggle_map,
        'ConfigToggleMap',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.ppe_get_allow_bypassing_mfa,
        'GetAllowBypassingMfa',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.password_settings,
        'PasswordSettings',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting mandatory fields option in sis-link settings
   * @author - Dharani
   */
  interceptSisLinkMandatoryFields(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.mandatory_fields,
        'MandatoryFields',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting sis link notifications option in sis-link settings
   * @author - Dharani
   */
  interceptSisLinkNotifications(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.push_notifications_configurations,
        'PushNotificationsConfigurations',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting Dictionaries in Configuration
   * @author - Dharani
   */
  interceptDictionaries(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.ppe_get_dictionaries,
        'GetDictionaries',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting branding option in facility
   * @author - Dharani
   */
  interceptFacilityBranding(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facility_branding_settings,
        'FacilityBrandingSettings',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting contact settings option in facility
   * @author - Dharani
   */
  interceptFacilityContactSettings(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_facility_branding_settings,
        'FacilityBrandingSettings',
        202
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facility_settings,
        'FacilitySettings',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting documents and disclosures option in facility
   * @author - Dharani
   */
  interceptFacilityDocumentsAndDisclosures(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_facility_settings,
        'FacilitySettings',
        202
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facility_disclosure,
        'FacilityDisclosure',
        200
      ),
    ];
  }

  /*
   * @details - Api collection after clicking Done Button in User settings.
   * @author - Dharani
   */
  interceptClickDoneApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.user_settings,
        'UserSettings',
        202
      ),
    ];
  }
}
