import {
  CommonGetLocators,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { generalEnableText } from './enums/general.enum';

import { OR_PPE_GENERAL } from './or/general.or';

export default class General {
  /**
   * @details - Enabling editing booked appointment .
   * @param yesNo - To select yes or no toggle
   * @API - API's are not available
   * @author - Suneetha
   */
  enableEditingBookedAppointmentsToggle(yesNo: string = YesOrNo.yes) {
    cy.cGet(selectorFactory.getH5Text(generalEnableText.general_enable_text))
      .parent()
      .within(() => {
        cy.cClick(selectorFactory.getSpanText(yesNo), yesNo, false, true, {
          force: true,
        });
      });
  }

  /**
   * @details - To select physician
   * @param names - To select physician name in drop down
   * @API - API's are not available
   * @author - Suneetha
   */
  selectPhysician(names: string[]) {
    cy.cGet(OR_PPE_GENERAL.ALL_PHYSICIAN[1])
      .find(OR_PPE_GENERAL.PHYSICIAN_DROPDOWN[1])
      .click();
    names.forEach((name) => {
      cy.cGet(CommonGetLocators.body).then(($body) => {
        if ($body.find(OR_PPE_GENERAL.SELECTED_PHYSICIANS[1]).length > 0) {
          cy.cGet(OR_PPE_GENERAL.SELECTED_PHYSICIANS[1]).then(($ele) => {
            if (!$ele.text().includes(name)) {
              cy.cGet(OR_PPE_GENERAL.PHYSICIAN_DROPDOWN_LIST[1])
                .find(selectorFactory.getLabelText(name))
                .click();
            }
          });
        } else {
          cy.cGet(OR_PPE_GENERAL.PHYSICIAN_DROPDOWN_LIST[1])
            .find(selectorFactory.getLabelText(name))
            .click();
        }
      });
    });
  }

  /**
   * @details - Select general options from menu dropdown in ppe configuration page
   * @API - API's are not available
   * @author - Suneetha
   */
  selectGeneralInConfiguration() {
    cy.cGet(selectorFactory.getAText(OR_PPE_GENERAL.GENERAL[0])).eq(0).click();
  }
}
