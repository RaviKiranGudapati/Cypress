import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export default class PpeAppointmentRequestApi {
  /**
   * @details - after selecting time slot in scheduling desktop
   * @author - chandrika
   */
  interceptSelectTimeSlotApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_schedule,
        'Schedule',
        200
      ),
    ];
  }

  /**
   * @details - After clicking done button in appointment popup
   * @author - chandrika
   */
  interceptDoneButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_appointment_request,
        'AppointmentRequests',
        201
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.ppe_rooms_desktop,
        'UserSettings',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_schedule_map,
        'ScheduleMap',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.get_room_active, 'Room', 200),
      new ApiEndpoint(WaitMethods.post, SubRoutes.get_data_ppe, 'Data', 200),
      new ApiEndpoint(WaitMethods.post, SubRoutes.get_schedule, 'Block', 200),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_data_range,
        'DataRange',
        200
      ),
    ];
  }

  /**
   * @details - After clicking next and previous button in procedure details and attachments in appointment popup
   * @author - chandrika
   */
  interceptNextAndPreviousButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_dictionary_ppe,
        'Dictionary',
        200
      ),
    ];
  }

  /**
   * @details - entering procedure details in appointment request popup
   * @author - chandrika
   */
  interceptProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_search_fee_schedule,
        'FeeSchedules',
        200
      ),
    ];
  }

  /**
   * @details - entering DOB in appointment request popup
   * @author - chandrika
   */
  interceptDobApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_search_name_by_dob,
        'SearchByNameAndDob',
        200
      ),
    ];
  }

  /**
   * @details - entering Zip code in appointment request popup
   * @author - spoorthy
   */
  interceptZipCodeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.zip_code,
        'SearchByZipCode',
        200
      ),
    ];
  }

  /**
   * @details - To select Patient In Surgery Scheduling
   * @author - spoorthy
   */
  interceptSelectPatientInSurgerySchedulingApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(WaitMethods.post, SubRoutes.get_data_ppe, 'Data', 200),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_schedule,
        'Schedule',
        200
      ),
    ];
  }

  /**
   * @details - entering diagnosis code in appointment request
   * @author - Arushi
   */
  interceptPreOpDiagnosisCodeSearch(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_search_diagnosis_code,
        'SearchDiagnosisCode',
        200
      ),
    ];
  }

  /**
   * @details - after clicking done button in add attachment in appointment request
   * @author - Arushi
   */
  interceptDoneButtonAddAttachment(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_storage,
        'GetStorage',
        200
      ),
    ];
  }

  /**
   * @details - selecting patient details tab in appointment request
   * @author - Arushi
   */
  interceptSelectPatientDetailsTabInAppointmentRequest(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_search_name_by_dob,
        'SearchByNameAndDob',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_dictionary_ppe,
        'DictionaryPpe',
        200
      ),
    ];
  }

  /**
   * @details - after appointment history in side panel options
   * @author - Arushi
   */
  interceptSelectAppointmentHistoryApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_cpt_modifiers,
        'CptModifiers',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_general_sis_link_settings,
        'SisLinkSettings',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_physician_access,
        'PhysicianAddress',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_room_active,
        'GetRoomActive',
        200
      ),
    ];
  }

  /**
   * @details - after case coordination in side panel options
   * @author - Arushi
   */
  interceptSelectCaseCoordinationApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_user_access_details,
        'UserAccessDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.ppe_app_request,
        'PpeAppRequest',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_general_sis_link_settings,
        'GeneralSisLinkSettings',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_configuration,
        'GetConfiguration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_tracker_data,
        'GetTrackerData',
        200
      ),
    ];
  }
}
