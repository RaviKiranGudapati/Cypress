export const checkboxLabels = [
  'booked',
  'pending',
  'block',
  'changes',
  'denied',
];

export const caseStatus = ['Booked', 'Pending', 'Block', 'Denied'];
export const appointmentRequestTabs = [
  'Procedure Details',
  'Patient Details',
  'Attachments',
  'Case Coordination',
];
export const appointmentFields = [
  'Date*',
  'Requested Start*',
  'Requested End*',
  'Duration',
  'Referring Physician',
];
export const procedureFields = [
  'CPT® Code and Description',
  'Modified Procedure Description',
  'Surgeon',
  'Body Side',
  'Pre-Op Diagnosis Code',
];

export const maritalStatus = [
  'Divorced',
  'Legally Separated',
  'Life Partner',
  'Married',
];

export const schedulingTrackerOptions = [
  'Surgery Scheduling',
  'Appointment History',
  'Case Coordination',
];

export const patientDetailsFields = [
  'First Name*',
  'Middle Initial',
  'Last Name*',
  'Sex*',
  'Gender Identity',
  'Pronouns',
  'DOB',
  'SSN',
  'Marital Status',
  'Primary Phone',
  'Mobile Phone',
  'Email',
];

export const patientAddressDetailsFields = [
  'Preferred Name',
  'Address 1',
  'Address 2',
  'City',
  'State',
  'Zip Code',
  'County',
];

export const insuranceFields = [
  'Insurance Name',
  'Insured Last Name',
  'Insured First Name',
  'Relationship to Subscriber',
  'ID',
  'Group Name',
  'Group Number',
  'Phone',
];

export const guarantorFields = [
  'Last Name',
  'First Name',
  'DOB',
  'Relationship to Patient',
  'Phone',
  'Address 1',
  'Address 2',
  'City',
  'State',
  'Zip Code',
];