/* enum values */
export enum AddOnFeaturesOptions {
  enterprise_build_contracts = 'Enterprise Build – Contracts',
}

export enum HelperText {
  search_field_text = ' Search by CPT®/HCPCS Code or Description',
  disclaimer_text_cpt = 'CPT only © 2022 American Medical Association. All Rights Reserved.',
  disclaimer_text_cdt = 'Current Dental Terminology © 2022 American Dental Association. All Rights Reserved.',
  inactivate_procedure = 'Inactivate Procedure',
  about_to_inactivate = 'You are about to inactivate',
  are_you_sure_to_continue = 'Are you sure you want to continue?',
  dictionaries_insurance_plan_type = "Linked to the 'Insurance Plan Type' dropdown in the Plan Details section when editing a plan on the 'Insurance' tab of Application Settings",
  cpt_label = 'CPT® Code and Description',
  transaction_code_name = 'Transaction Code Name',
  delete_transaction_code = 'Delete Transaction Code',
  about_to_delete = 'You are about to delete',
  transactionCode_cannot_be_saved_without_name = 'Transaction Code cannot be saved without a name.',
  discount_search_field_text = 'Discount Name',
  you_cannot_delete = 'You cannot delete',
  transaction_code_is_currently_in_use = 'The transaction code is currently in use.',
  contract_name = 'Contract Name',
  do_not_modify_existing_contract = 'Create a new contract for updated contract terms, do not modify an existing contract.',
  disclaimer_text_ppe_cpt = 'CPT only © 2022 American Medical Association. All rights reserved.',
  generate_bill = 'Set the GB checkbox for the new responsible party.',
}

export enum InfoText {
  include_in_enterprise_items_text = "Shows all Enterprise items at the facility level. Users are able to inactivate anything they don't want to see.",
  allow_add_to_configuration_text = 'Allows facilities to add to the configurations below. New entries will not be added to the Enterprise Configurations and can only be seen in that facility.',
  include_enterprise_items_dict_text = "Shows all Enterprise items at the facility level. Users are able to inactivate anything they don't want to see.",
  allow_add_to_dict_text = 'Allows facilities to add to the dictionaries below. New entries will not be added to the Enterprise Dictionary and can only be seen in that facility.',
  business_configuration_screen_default_text = 'Please select an existing item or create a new item.',
  send_inventory_to_tracker_upon_discharge = 'Enabling this option will result in inventory initially being sent to the tracker upon patient discharge',
}

export enum ConfigurationsLists {
  fee_schedule = 'Fee Schedule',
  transaction_code = 'Transaction Codes',
  dictionaries = 'Dictionaries',
  discounts = 'Discounts',
  add_on_features = 'Add On Features',
  cbo_management = 'CBO Management',
  contracts = 'Contracts',
}

export enum TypeDropdownOptions {
  allocation = 'Allocation',
  correction = 'Correction',
  debit = 'Debit',
  payment = 'Payment',
  transfer = 'Transfer',
  unassigned = 'Unassigned Payment',
  write_off = 'Write-Off',
}

export enum ManagementSettingsList {
  facility_management = 'Facility Management',
  profiles = 'Profiles',
  roles = 'Roles',
  users = 'Users',
  non_users = 'Non-Users',
  login_acknowledgement = 'Login Acknowledgement',
  support_contacts = 'Support Contacts',
  security = 'Security',
  add_on_features = 'Add On Features',
}

export enum ContractHeaders {
  PostingOption = 'Posting Option',
  ImportRates = 'Import Rates',
  MultipleProcedures = 'Multiple Procedures',
  ReviewEdit = 'Review/Edit',
  Supplies = 'Supplies',
}

export enum AddNewOrCreateCopy {
  AddNew = 'Add New',
  CreateCopy = 'Create Copy',
}

export enum AddOnFeaturesItems {
  RevenueCycleManagement = 'Revenue Cycle',
  Collections = 'Collections',
}

export enum MFAIP {
  IpFrom = 'IPFrom',
  IpTo = 'IPTo',
}
