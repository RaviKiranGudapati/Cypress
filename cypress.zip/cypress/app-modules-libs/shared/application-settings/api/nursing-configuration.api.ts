import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class NursingConfigurationApis {
  /**
   * @details - Api for contract searched procedure
   */
  interceptContractSearchedProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.review_edit_procedure_type,
        'GetInsuranceContractReviews',
        200
      ),
    ];
  }

  /**
   * @details - Api for contract procedure type
   */
  interceptContractSaveProcedureTypeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.save_insurance_contract_review,
        'SaveInsuranceContractReview',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting fee schedule in nursing configuration
   * @author Arushi
   */
  interceptFeeScheduleApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_fee_schedules,
        'GetFeeSchedules',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_procedures,
        'GetAllProcedures',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_revenue_code_list,
        'GetRevenueCodeList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.allow_add_items,
        'AllowAddItems',
        200
      ),
    ];
  }

  /**
   * @details - Api for added contract
   * @author Arushi
   */
  selectContractApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_posting_options,
        'GetInsuranceContractPostingOption',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_record_lock,
        'GetRecordLocksByType',
        200
      ),
    ];
  }

  /**
   * @details - clicking on done button in add transaction code popup
   */
  interceptAddTransactionCodePopUpApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_upsert_transaction_code,
        'UpsertTransactionCode',
        200
      ),
    ];
  }

  /**
   * @details - search contracts in application settings
   * @author Arushi
   */
  interceptSearchContractsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_contract_posting_option,
        'GetInsuranceContractPostingOption',
        200
      ),
    ];
  }

  /**
   * @details - Select an existing insurance
   * @author Arushi
   */
  interceptSelectInsuranceApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_insurance_plans,
        'GetInsurancePlans',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.insurance_contract,
        'InsuranceContract',
        200
      ),

      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.transaction_code,
        'TransactionCode',
        200
      ),

      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.write_off_reason_list,
        'WriteOffReasonList',
        200
      ),

      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.write_off_group_list,
        'WriteOffGroupList',
        200
      ),
    ];
  }

  /**
   * @details - Clicking on ContextMenu option and select edit
   * @author Arushi
   */
  interceptClickContextMenuApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_claim_office,
        'GetInsuranceClaimOffice',
        200
      ),
    ];
  }

  /**
   * @details - selecting dropdown value in Posting option tab
   * @author Arushi
   */
  interceptContractPostingOptApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.save_insurance_contract_posting_option,
        'SaveInsuranceContractPostingOption',
        200
      ),
    ];
  }

  /**
   * @details - selecting yes in exempt field in review/edit of contracts after selecting contract from list
   * @author Arushi
   */
  interceptExemptContractApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.save_insurance_contract_review,
        'ContractReview',
        200
      ),
    ];
  }

  /**
   * @details - selecting yes in exempt field in review/edit of contracts after selecting contract from list
   * @author Arushi
   */
  interceptRCMApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_rcm_config,
        'RcmConfig',
        200
      ),
    ];
  }

  /**
   * @details - selecting value of procedure display dropdown in consents in application settings
   * @author Arushi
   */
  interceptProcedureDisplay(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_configuration_toggle_map,
        'ConfigurationToggleMap',
        200
      ),
    ];
  }

  /**
   * @details - clicking on done button while adding fee schedule procedure in application settings
   * @author Arushi
   */
  interceptFeeScheduleDone(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insert_fee_schedule,
        'InsertFeeSchedule',
        200
      ),
    ];
  }

  /**
   * @details - clicking on done button while adding fee schedule procedure in application settings
   * @author Arushi
   */
  interceptFeeScheduleStatusUpdate(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_update_fee_schedule,
        'UpdateFeeSchedule',
        200
      ),
    ];
  }

  /**
   * @details - clicking on done button while adding fee schedule procedure in application settings
   * @author Arushi
   */
  interceptSelectDictionary(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_select_dictionary,
        'SelectDictionary',
        200
      ),
    ];
  }

  /**
   * @details - clicking on done button while adding fee schedule procedure in application settings
   * @author Arushi
   */
  interceptDictionaryAdd(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_dictionary_add,
        'AddDictionary',
        200
      ),
    ];
  }

  /**
   * @details - clicking on done button while editing insurance in application settings
   * @author Arushi
   */
  interceptEditInsuranceDone(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.put_insurance_plan,
        'SaveInsurance',
        200
      ),
    ];
  }

  /**
   * @details - clicking on configuration in preference card in application settings
   * @author Arushi
   */
  interceptSelectPreferenceCardConfiguration(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_preference_card_configList,
        'PreferenceCardConfigList',
        200
      ),
    ];
  }

  /**
   * @details - selecting specialaity in preference card configuration in application settings
   * @author Arushi
   */
  interceptSelectSpecialityPeferenceCard(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.put_case_speciality_preference_card,
        'PreferenceCardUpdate',
        200
      ),
    ];
  }

  /**
   * @details - selecting transaction code in discounts configuration in application settings
   * @author Arushi
   */
  interceptSelectTransactionCode(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.put_transaction_code_discounts,
        'TransactionCodeDiscount',
        200
      ),
    ];
  }

  /**
   * @details - procedure search in contract in application settings
   * @author Arushi
   */
  interceptProcedureSearchContract(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.review_edit_procedure_type,
        'ProcedureType',
        200
      ),
    ];
  }

  /**
   * @details - select existing block in application settings
   * @author Arushi
   */
  interceptExistingBlock(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_block_schedule_config_data,
        'BlockScheduleConfig',
        200
      ),
    ];
  }

  /**
   * @details - add preference card in case creation and click on done button
   * @author Arushi
   */
  interceptCaseCreationPreferenceCardDone(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_all_pref_card_equipment,
        'PreferenceCardEquipment',
        200
      ),
    ];
  }

  /**
   * @details - add procedure while preference card creation
   * @author Arushi
   */
  interceptProcedureSearchPreferenceCard(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_procedure_search,
        'ProcedureSearch',
        200
      ),
    ];
  }

  /**
   * @details - click on done in add block in application settings
   * @author Arushi
   */
  interceptDoneCreateBlock(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.upsert_block_schedule_config,
        'BlockSchedule',
        200
      ),
    ];
  }

  /**
   * @details - click on working dys in schedule in application settings
   * @author Arushi
   */
  interceptWorkingDays(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_config_schedule,
        'ConfigSchedule',
        200
      ),
    ];
  }

  /**
   * @details - click on default toggle in insurance in application settings
   * @author Arushi
   */
  interceptDefaultInsurance(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.put_insurance_plan,
        'InsurancePlan',
        200
      ),
    ];
  }

  /**
   * @details - API call after selecting the Discount option in configuration list
   * @author Praveen
   */
  interceptDiscountSelectionApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_source_of_revenueList,
        'RevenueList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_writeoff_reason_list,
        'WriteOffReasonList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_writeoff_group_list,
        'WriteOffGroupList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_transaction_code_list_by_type,
        'TransactionCodeList',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting rcm status in dictionary
   * @author - Rakesh Donakonda
   */
  interceptAddRcmStatusApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_dictionary_add,
        'DictionaryAdd',
        200
      ),
    ];
  }

  /**
   * @details Api collection for searching medication in inventory
   * @author Arushi
   */
  interceptSearchInventory() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.inventory_name_get,
        'InventoryName',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for searching and selecting preference card
   * @author Arushi
   */
  interceptSelectPreferenceCard() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.dic_items_all_get,
        'AllItems',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_equipments,
        'GetEquipments',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.preference_card,
        'PreferenceCard',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for searching supply in preference card
   * @author Arushi
   */
  interceptPreferenceCardSupply() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.inventory_name_get,
        'InventoryName',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for searching supply in preference card
   * @author Arushi
   */
  interceptSelectContextMenuFormularyMedication() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.formulary_medication_template_get,
        'FormularyMedication',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for updating formulary medication
   * @author Arushi
   */
  interceptEditFormularyMedication() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.put,
        SubRoutes.edit_formulary_medication_template_done,
        'EditFormularyMedication',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.formulary_medication_template_get,
        'FormularyMedicationGet',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for adding formulary inventory medication
   * @author Arushi
   */
  interceptAddFormularyInventory() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.inventory_name_get,
        'InventoryName',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for searching and selecting physician order
   * @author Arushi
   */
  interceptSearchAndSelectPhysicianOrder() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.physician_order_get,
        'GetPhysicianOrder',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_staff_organization,
        'StaffOrganization',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for adding anaesthesia plan
   * @author Arushi
   */
  interceptAddAnaesthesiaPlan() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_anesthesia_plan,
        'GetAnaesthesiaPlan',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for searching and selecting anaesthesia plan
   * @author Arushi
   */
  interceptSearchAndSelectAnaesthesiaPlan() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_anesthesia_plan,
        'GetAnaesthesiaPlan',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_dictionary,
        'GetDictionary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_plan_consciousness_levels,
        'GetAnaesthesiaPlanConciousnessLevel',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_plan_patient_position,
        'PatientPosition',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.anesthesia_plan_controlled_ventilation_type,
        'ControlledVentilation',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for searching and selecting anaesthesia plan
   * @author Arushi
   */
  interceptSearchMedicationAnaesthesia() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.formulary_medication_template_get,
        'FormularyMedication',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for adding physician order
   * @author Arushi
   */
  interceptAddPhysicianOrder() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.formulary_medication_template_get,
        'FormularyMedication',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for searching and selecting medication in anaesthesia plan
   * @author Arushi
   */
  interceptAddMedicationInAnesthesiaPlan() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_anesthesia_plan_medication,
        'AnaesthesiaPlan',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for adding pre admission worklist
   * @author Divya
   */
  interceptAddPreAdmissionWorklist() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.create_worklist,
        'CreateWorklist',
        201
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.worklist_configuration,
        'WorklistConfiguration',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details Api collection for selecting pre admission instruction
   * @author Divya
   */
  interceptSelectPreAdmissionInstruction() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.worklist_configuration,
        'WorklistConfiguration',
        200
      ),
    ];
    return endpoints;
  }
}
