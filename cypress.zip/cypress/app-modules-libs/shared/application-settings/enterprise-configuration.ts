import AbstractPage, {
  Application,
  CommonClassAttributes,
  CommonGetLocators,
  CommonTypeValues,
  defaultTimeOut,
  DoneOrCancel,
  EnableOrDisable,
  FilterMethods,
  InvokeAttributes,
  InvokeMethods,
  ShouldMethods,
  ShowOrHide,
  TriggerAttributes,
  TrueOrFalse,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

import { AppColors } from '../../../support/common-core-libs/application/constants/app-colors.constants';
import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import {
  AddOnFeatures,
  CBODetails,
  CBOManagement,
  Profiles,
  UserDetails,
  UserManagement,
} from '../../../test-data-models/shared/enterprise-configuration/enterprise.model';
import {
  AddFeeGroup,
  Contracts,
  FeeSchedule,
  ProcedureDetailsInReviewEdit,
} from '../../../test-data-models/shared/enterprise-configuration/enterprise.model';

import { OR_ENTERPRISE_CONFIGURATION } from '../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_LOGIN } from '../../sis-office/login/or/login.or';

import EnterpriseConfigurationApi from './api/enterprise-configuration.api';

import {
  AddNewOrCreateCopy,
  ConfigurationsLists,
  ContractHeaders,
  HelperText,
  InfoText,
  ManagementSettingsList,
  MFAIP,
} from './enums/enterprise-configuration.enum';

import { typeDropDownOptionValues } from './constants/enterprise-configuration.const';

/* instance variables */
const color = require('onecolor');
const sisOfficeDesktop = new SISOfficeDesktop();

/* const values */
const Enable = 'Enable';
const Disable = 'Disable';

export default class EnterpriseConfiguration extends AbstractPage {
  private enterpriseConfigurationApi = new EnterpriseConfigurationApi();

  /**
   * @details - type on search of enterprise configuration
   * @param configName
   * @Api - API's are not available
   */
  enterpriseConfigurationSearch(configName: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_CONFIGURATION
        .ENTERPRISE_CONFIGURATION_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_CONFIGURATION
        .ENTERPRISE_CONFIGURATION_SEARCH[0],
      configName
    );
  }

  /**
   * @details - select search value in enterprise configuration
   * @param configName
   * @API - API's are available - Implemented Completely in internal method clickOnConfigItem()
   * @Author Harsh
   */
  enterpriseSelectConfiguration(
    configName: string,
    isSelectionBasedOnBackgroundColor: boolean = false
  ) {
    this.enterpriseConfigurationSearch(configName);
    if (isSelectionBasedOnBackgroundColor) {
      cy.contains(configName)
        .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
        .then(($col) => {})
        .should(($colorValue) => {
          switch (String(color($colorValue).hex())) {
            case AppColors.component_on_selection:
              break;
            case AppColors.component_before_selection:
              this.clickOnConfigItem(configName);
              break;
            default:
              break;
          }
        });
    } else {
      this.clickOnConfigItem(configName);
    }
  }

  /**
   * @details - To select the feature tab in Facility Management section
   * @param tabName as string reference to pass in the function.
   * @Api - API's are not available
   */
  selectFeatureTab(tabName: string) {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FACILITY_DETAILS[1]
    ).each(() => {
      cy.cClick(selectorFactory.getSpanText(tabName), tabName, false, true, {
        multiple: true,
      });
    });
  }

  /**
   * @details - To verify the CDT Code feature state
   * @param tabName as string reference to pass in the function.
   */
  verifyCDTCodeFeature(tabName: string) {
    this.selectFeatureTab(tabName);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
        .FEATURE_CDT_CODE_DISABLE[1]
    )
      .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
      .then(($disableValue) => {
        if ($disableValue == TrueOrFalse.false) {
          cy.cGet(
            OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
              .FEATURE_CDT_CODE_ENABLE[1]
          )
            .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
            .then(($enableValue) => {
              expect($enableValue).to.be.equal(TrueOrFalse.true);
            });
        }
      });
  }

  /**
   * @details To select the CDT Code feature in Feature tab
   * @param tabName as string reference in the function
   * @Api - API's are available - Implemented Completely
   * @Author Harsh
   */
  selectCDTCodeFeature(tabName: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptFacilityManagementFeatureEnableDisableApi();
    this.selectFeatureTab(tabName);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURE_CDT_CODE_ENABLE[1]
    )
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .then(($background) => {
        const hex = String(color($background.toString()).hex()).toUpperCase();

        if (
          hex ==
          AppColors.component_enabled_toggle_button_not_selected.toUpperCase()
        ) {
          cy.cIntercept(interceptCollection);
          cy.cClick(
            OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
              .FEATURE_CDT_CODE_ENABLE[1],
            OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
              .FEATURE_CDT_CODE_ENABLE[0]
          );
          cy.cWaitApis(interceptCollection);
        }
      });
  }

  /**
   * @details To select the facility in Facility Management
   * @param facilityName as string reference in the function
   * @API - API's are available - Implemented Completely
   */
  selectFacilityInFacilityManagement(facilityName: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.selectFacilityInFacilityManagementApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FACILITY_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FACILITY_SEARCH[0],
      facilityName
    );
    cy.cClick(selectorFactory.getDivTitle(facilityName), facilityName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To select the enterprise option in Enterprise popup
   * @param titleName - Select Login Location
   * @param buttonName Enterprise of FacilityName
   * @API - API's are available - Implemented Completely
   */
  selectEnterpriseInPopup(titleName: string, buttonName: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.selectEnterpriseApi();
    cy.cIsVisible(selectorFactory.getSpanText(titleName), titleName);
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.selectEnterprise(buttonName), buttonName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To toggle switches in internal tab
   * @param toggleSwitchName as string reference in the function
   * @param option as string reference in the function
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  togglesInInternalTab(toggleSwitchName: string, option: string) {
    let locator: string = '';
    cy.cIsVisible(
      selectorFactory.getLabelText(toggleSwitchName),
      toggleSwitchName
    );
    switch (toggleSwitchName) {
      case OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .SHARED_DICTIONARIES_CONFIGURATIONS[0]:
        locator = selectorFactory.toggleSwitchInInternalTab(option);
        cy.cGet(locator)
          .parent()
          .then(($body) => {
            if (!$body.hasClass(CoreCssClasses.Panel.loc_p_highlight)) {
              // Added double click for the save of the show toggle
              const interceptCollection =
                this.enterpriseConfigurationApi.togglesInInternalTabApi();
              cy.cIntercept(interceptCollection);
              cy.cGet(locator).dblclick();
              cy.cWaitApis(interceptCollection);
            }
          });
        break;
      case OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
        .CBO_CENTRALIZED_VIEWS[0]:
        locator = selectorFactory.toggleCboViews(option);
        const interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectCboManagementShowApi();
        option == ShowOrHide.show
          ? interceptCollection
          : this.enterpriseConfigurationApi.interceptSelectCboManagementHideApi();
        cy.cGet(locator)
          .parent()
          .then(($body) => {
            if (!$body.hasClass(CoreCssClasses.Panel.loc_p_highlight)) {
              cy.cIntercept(interceptCollection);
              cy.cGet(locator).dblclick();
              cy.cWaitApis(interceptCollection);
            }
          });
        break;
      default:
        break;
    }
  }

  /**
   * @details to click on any tab after selecting the desired facility
   * @param tabName as string reference in the function on which user needs to click
   * @API - API's are not available
   */
  clickOnTab(tabName: string) {
    const locator: string = selectorFactory.getSpanText(tabName);
    cy.cGet(locator).scrollIntoView().click();
  }

  /**
   * @details to click on any tab after selecting the desired facility
   * @API - API's are not available
   * @author - Jayasree
   */
  clickOnUserDetailsTab() {
    const interceptCollection =
      this.enterpriseConfigurationApi.selectUserDetailsTabApi();
    cy.cIntercept(interceptCollection);

    this.clickOnTab(
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To verify enterprise build visibility in the management settings on the basis of toggle selection in shared dictionaries
   * @param flag as string reference in the function
   * @API - API's are not available
   */
  verifyEnterpriseBuild(flag: boolean = true) {
    cy.cNotExist(
      selectorFactory.getLabelText(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.ENTERPRISE_BUILD_LABEL[0]
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.ENTERPRISE_BUILD_LABEL[0],
      flag
    );
  }

  /**
   * @details To verify if the particular option is visible under Enterprise Build
   * @param option as string reference in the function
   * @API - API's are not available
   */
  verifyItemInEnterpriseBuild(option: string) {
    // Added Assertion to verify the option is enabled
    cy.shouldBeEnabled(selectorFactory.itemInEnterpriseBuild(option));
    cy.cIsVisible(
      selectorFactory.itemInEnterpriseBuild(option),
      option,
      false,
      true
    );
  }

  /**
   * @details To verify visibility and click on any available sub menu option under enterprise configuration
   * @param option as string reference in the function
   * @API - API's are available - Implemented Completely
   */
  clickOnSubMenuItem(option: string) {
    let interceptCollection: ApiEndpoint[] = [];
    switch (option) {
      case ConfigurationsLists.fee_schedule:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildFeeScheduleApi();
        break;
      case ConfigurationsLists.transaction_code:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildTransactionCodeApi();
        break;
      case ConfigurationsLists.dictionaries:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildDictionariesApi();
        break;
      case ConfigurationsLists.discounts:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildDiscountApi();
        break;
      case ConfigurationsLists.contracts:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildContractsApi();
        break;
      default:
        break;
    }
    // Removed button validation step as we are clicking on the same so this step is not required
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.itemInEnterpriseBuild(option), option);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click on add button in fee schedule for adding new procedure and clicking on text field in order to type code
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  clickOnAddInFeeSchedule() {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptFeeScheduleAddButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_TEXT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_TEXT[0],
      false,
      true
    );
  }

  /**
   * @details To verify the helper text of the search procedure field when any code is not written in it
   */
  verifySearchHelperText() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_TEXT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_TEXT[0],
      false,
      true
    );

    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_SEARCH[0],
      CommonClassAttributes.placeholder,
      HelperText.search_field_text
    );
  }

  /**
   * @details - Adding new procedure from fee schedule
   * @param code
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  addProcedure(code: string | number) {
    const interceptTypeInAddProcedureApiCollection =
      this.enterpriseConfigurationApi.interceptTypeInAddProcedureApi();

    this.clickOnAddInFeeSchedule();
    cy.cIntercept(interceptTypeInAddProcedureApiCollection);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ADD_PROCEDURE_SEARCH[0],
      code
    );
    cy.cWaitApis(interceptTypeInAddProcedureApiCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .PROCEDURE_SEARCH_RESULT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .PROCEDURE_SEARCH_RESULT[0]
    );
    const interceptAddProcedureDoneButtonApiCollection =
      this.enterpriseConfigurationApi.interceptAddProcedureDoneButtonApi();
    cy.cIntercept(interceptAddProcedureDoneButtonApiCollection);
    sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptAddProcedureDoneButtonApiCollection);
  }

  /**
   * @details - selecting the already added procedure from list in fee schedule tab
   * @param option
   * @API - API's are not available
   */
  selectAddedProcedure(option: string) {
    cy.cSelectListItem(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .SELECT_ADDED_PROCEDURE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .SELECT_ADDED_PROCEDURE[0],
      option
    );
  }

  /**
   * @details - Verifying the default behavior of include in state report for different type of procedures
   * @param state -
   */
  verifyDefaultStateOfIncludeInStateReport(state: string) {
    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .INCLUDE_IN_STATE_REPORT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .INCLUDE_IN_STATE_REPORT[0],
      InvokeAttributes.aria_label,
      state
    );
  }

  /**
   * @details - verifying the presence of fields once the procedure is added
   */
  verifyOptionsInProcedure() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.SEARCH_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.SEARCH_FIELD[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.PRINT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.PRINT[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[0]
    );
    this.verifyDefaultStateOfIncludeInStateReport(YesOrNo.yes);
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.STATUS[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.STATUS[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.REVENUE_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.REVENUE_CODE[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.HISTORY[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.HISTORY[0]
    );
  }

  /**
   * @details - clicking on the status drop down post addition of code
   * @API - API's are not available
   */
  clickStatusDropDown() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.STATUS[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.STATUS[0]
    );
  }

  /**
   * @details - verifying the presence of options in the status drop down
   * @param values -Verifying the drop down values
   */
  verifyStatusDropDownValues(values: string[]) {
    this.clickStatusDropDown();
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getSpanText(el), el);
    });
  }

  /**
   * @details - verifying the default values for Revenue Code and Type of Bill as they are populated automatically
   */
  verifyDefaultValuesForRevCodeAndTypeOfBill(
    revCode: string,
    typeOfBill: string
  ) {
    cy.cRemoveMaskWrapper(Application.office);
    this.clickStatusDropDown();
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.REVENUE_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.REVENUE_CODE[0],
      revCode
    );
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0],
      typeOfBill
    );
  }

  /**
   * @details - verifying the disclaimer text available in the procedure screen
   */
  verifyDisclaimerText() {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DISCLAIMER_TEXT_CPT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DISCLAIMER_TEXT_CPT[0],
      HelperText.disclaimer_text_cpt
    );
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DISCLAIMER_TEXT_CDT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DISCLAIMER_TEXT_CDT[0],
      HelperText.disclaimer_text_cdt
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - verifying the column visibility in the configurations tab in facility management post selecting facility
   */
  verifyColumnsInConfigurationsTab() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .CONFIGURATION_VIEWS_HEADER[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .CONFIGURATION_VIEWS_HEADER[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .BUILD_SECTION[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .BUILD_SECTION[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .INCLUDE_ENTERPRISE_ITEMS[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .INCLUDE_ENTERPRISE_ITEMS[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .ALLOW_ADD_TO_CONFIGURATION[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .ALLOW_ADD_TO_CONFIGURATION[0]
    );
  }

  /**
   * @details - verifying the mouse hover text for options(Include entrprise items and Allow add to configuration) visible under configurations tab
   */
  verifyMouseHoverTextInConfigurationsTab() {
    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .I_ICON_NEXT_TO_INCLUDE_ENTERPRISE_ITEM[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .I_ICON_NEXT_TO_INCLUDE_ENTERPRISE_ITEM[0],
      InvokeAttributes.p_tool_tip,
      InfoText.include_in_enterprise_items_text
    );

    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .I_ICON_NEXT_TO_ALLOW_ADD_TO_CONFIGURATION[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .I_ICON_NEXT_TO_ALLOW_ADD_TO_CONFIGURATION[0],
      InvokeAttributes.p_tool_tip,
      InfoText.allow_add_to_configuration_text
    );
  }

  /**
   * @details - verifying if toggle button is present in all the options in configuration link
   * @param - Configuration item name
   */
  verifyTogglesInConfiguration(configurationItem: string) {
    cy.cIsVisible(
      CommonUtils.concatenate(
        selectorFactory.getTdText(configurationItem),
        OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
          .INCLUDE_ENTERPRISE_ITEMS_TOGGLE[1]
      ),
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .INCLUDE_ENTERPRISE_ITEMS_TOGGLE[0]
    );
    cy.cIsVisible(
      CommonUtils.concatenate(
        selectorFactory.getTdText(configurationItem),
        OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
          .ALLOW_ADD_TO_CONFIGURATION_TOGGLE[1]
      ),
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .ALLOW_ADD_TO_CONFIGURATION_TOGGLE[0]
    );
  }

  /**
   * @details - clicking on 'X' button in procedure name field
   * @API - API's are not available
   */
  clickOnAutoCompleteClear() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DELETE_PROCEDURE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DELETE_PROCEDURE[0],
      false,
      false,
      { force: true }
    );
  }

  /**
   * @details - verifying procedure text warning post clicking 'X' button
   */
  verifyProcedureWarning() {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .PROCEDURE_WARNING[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .PROCEDURE_WARNING[0],
      AppErrorMessages.procedure_name_warning,
      false,
      true
    );
  }

  /**
   * @details - updating the code from procedure name field
   * @param code
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  updateCodeFromProcedure(code: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptSearchProcedureApi();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.PROCEDURE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.PROCEDURE[0]
    );
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.PROCEDURE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.PROCEDURE[0],
      code
    );
    cy.cWaitApis(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .PROCEDURE_SEARCH_RESULT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .PROCEDURE_SEARCH_RESULT[0]
    );
  }

  /**
   * @details - selecting the status value from dropdown
   * @param option
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  selectStatusValue(option: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateProcedureDetailsApi();
    this.clickStatusDropDown();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getDropdownValues(option), option);
    cy.cWaitApis(interceptCollection);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - clearing modified procedure description field
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  clearModifiedProcedureDescription() {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateProcedureDetailsApi();
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[1]
    )
      .click()
      .clear();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - updating the data in modified procedure field
   * @param desc
   * @API - API's are available - Implemented Completely
   * @Author HArsh
   */
  enterModifiedProcedureDescription(desc: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateModifiedProcedureDescriptionApi();
    this.clearModifiedProcedureDescription();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[0]
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[1]
    ).clear();
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[0],
      desc
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - updating the revenue code by clicking on the drop down and passing the desired value
   * @param code
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  updateRevenueCode(code: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateProcedureDetailsApi();
    this.clickRevenueCodeDropDown();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .REVENUE_CODE_SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .REVENUE_CODE_SEARCH_INPUT[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .REVENUE_CODE_SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .REVENUE_CODE_SEARCH_INPUT[0],
      code
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .SELECT_SEARCHED_REVENUE_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .SELECT_SEARCHED_REVENUE_CODE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - updating the type of bill by passing the desired value
   * @param input - provide the value to be entered
   * @API - API's are available - Implemented Completely
   * @Author HArsh
   */
  updateTypeOfBill(input: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateProcedureDetailsApi();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0]
    );
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0],
      input
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - clicking on the revenue code drop down
   * @API - API's are not available
   */
  clickRevenueCodeDropDown() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.REVENUE_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.REVENUE_CODE[0]
    );
  }

  /**
   * @details - entering the amount in the amount field and clicking on other field and adding amount again to save the data
   * @param input
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  enterAmount(input: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateProcedureDetailsApi();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[0],
      input
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0]
    );
    cy.cWaitApis(interceptCollection);

    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[0],
      input
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - clicking on the history button
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  clickHistory() {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptFeeScheduleHistoryButtonApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.HISTORY[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.HISTORY[1]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verifying the data visible in history and click on done button
   * @param values - to pass string array to verify the labels in history pop-up
   */
  verifyHistory(values: string[]) {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .FEE_SCHEDULE_HISTORY_TEXT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .FEE_SCHEDULE_HISTORY_TEXT[0]
    );
    values.forEach((el) => {
      cy.cIsVisible(selectorFactory.getThText(el), el);
    });
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.HISTORY_DONE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.HISTORY_DONE[0]
    );
  }

  /**
   * @details - verifying the document data for any code
   * @param description as string reference in the function for the description to be verified
   * @param statusValue as string reference in the function for the statusVlaue to be verified
   * @param amount as string reference in the function for the amount to be verified
   * @param typeOfBill as string reference in the function for the typeOfBill to be verified
   */
  verifyDocumentedDataForProcedurecode(
    description: string,
    statusValue: string,
    amount: string,
    typeOfBill: string
  ) {
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .MODIFIED_PROCEDURE_DESCRIPTION[0],
      description
    );

    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.STATUS[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.STATUS[0],
      statusValue
    );

    cy.cRemoveMaskWrapper(Application.office);

    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.AMOUNT[0],
      amount
    );

    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0],
      typeOfBill
    );
  }

  /**
   * @details - verifying the visibility and the text of the duplicate procedure warning
   */
  verifyDuplicateProcedureErrorMessage() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DUPLICATE_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DUPLICATE_CODE[0]
    );
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DUPLICATE_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .DUPLICATE_CODE[0],
      AppErrorMessages.duplicate_procedure_name
    );
  }

  /**
   * @details - verifying the visibility and clicking on the cancel button in add procedure pop-up
   * @Api - API's are not available
   */
  clickOnCancel() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
  }

  /**
   * @details - Verifying trying to add duplicate procedure and the warning displayed after addition
   * @param code
   */
  verifyAddDuplicateCode(code: string) {
    this.addProcedure(code);
    this.verifyDuplicateProcedureErrorMessage();
    this.clickOnCancel();
  }

  /**
   * @details To inactivate procedure item in enterprise -> fee schedule screen
   * @param code as string reference in the function for the code to be inactivated
   * @param option as string reference in the function for the option as Yes/No, to inactivate or not
   * @Api - API's are available - Implemented Completely
   * @Author Harsh [This method is used in only one spec 262407 which is excluded from execution]
   */

  inactivateProcedureItem(code: string, option: string) {
    const locator = selectorFactory.inactivateProcedureItem(code);
    this.searchProcedureItem(code);
    this.verifyProcedureItemExists(code, true);
    cy.cGet(
      locator,
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TRASH_ICON[0]
    )
      .invoke(InvokeMethods.show)
      .click();
    this.verifyInactivateProcedurePopupText(code);
    const interceptCollection =
      option === YesOrNo.yes
        ? this.enterpriseConfigurationApi.interceptDeleteProcedureApi()
        : [];
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getButtonSpanText(option), option);
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(
      selectorFactory.getH2Text(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
          .FEE_SCHEDULE_LABEL[0]
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .FEE_SCHEDULE_LABEL[0]
    );
  }

  /**
   * @details To verify if the visibility or existence of the searched procedure code
   * @param code - As string reference in the function for the code to be searched in the search field text area
   * @param option - As string reference in the function for the code to be searched in the search field text area
   */
  verifyProcedureItemExists(code: string, option: boolean) {
    this.searchProcedureItem(code);
    option
      ? cy.cIsVisible(selectorFactory.getDivTitle(code), code)
      : cy.cNotExist(selectorFactory.getDivTitle(code), code);
  }

  /**
   * @details To search procedure item in enterprise -> fee schedule screen
   * @param code as string reference in the function for the code to be searched in the search field text area
   * @Api - API's are available - Implemented Completely
   * @Author - Harsh
   */
  searchProcedureItem(code: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptSearchProcedureApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.SEARCH_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.SEARCH_FIELD[0],
      code
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify the toggle behavior for provided configuration item and type of flag(Ex. 'Include Enterprise Items'/'Allow Add to Dictionary')
   * @param item -> Configuration item (Ex. Fee Schedule, Language, Appointment Type etc.)
   * @param option -> To verify whether the option is selected as Yes/No
   * @param toggleSwitch -> Include Enterprise Items'/'Allow Add to Dictionary   *
   */
  verifyToggleBehaviorInDictionariesORConfiguration(
    item: string,
    option: string,
    toggleSwitch: string
  ) {
    let i;
    toggleSwitch.toUpperCase() ==
    OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
      .INCLUDE_ENTERPRISE_ITEMS[0]
      ? (i = 0)
      : (i = 1);
    cy.cGet(selectorFactory.verifyDefaultBehaviorToggleSwitch(item))
      .parent(CommonGetLocators.td)
      .siblings()
      .eq(i)
      .find(selectorFactory.verifyToggleOption(option))
      .should(ShouldMethods.visible);
  }

  /**
   * @details - To verify the default toggle behavior for provided configuration item (Ex. 'Include Enterprise Items'/'Allow Add to Dictionary')
   * @param item -> Configuration item (Ex. Fee Schedule, Language, Appointment Type etc.)
   */
  verifyDefaultBehaviorToggleSwitch(item: string) {
    cy.cGet(selectorFactory.verifyDefaultBehaviorToggleSwitch(item))
      .parent(CommonGetLocators.td)
      .siblings()
      .eq(0)
      .find(selectorFactory.toggleHighlight)
      .should(ShouldMethods.visible);

    cy.cGet(selectorFactory.divDataTable(item))
      .parent(CommonGetLocators.td)
      .siblings()
      .eq(1)
      .find(selectorFactory.toggleDisabled)
      .should(ShouldMethods.visible);
  }

  /**
   * @details - To verify the tab (Ex. Feature, Internal, etc) is visible or not under Facility Management Settings for a selected facility as per the user(Admin/Non-admin) login
   * @param tabName -> To provide tab name (Ex. Feature, Internal, etc)
   * @param option -> To provide true/false to verify the visibility of the tab name
   */
  verifyTabs(tabName: string, option: boolean) {
    const locator = selectorFactory.verifyTabs(tabName);
    option ? cy.cIsVisible(locator, tabName) : cy.cNotExist(locator, tabName);
  }

  /**
   * @details - To verify the text available in Inactivate procedure pop up window
   * @param code -> To provide cpt/hspcs/gcode (Ex. 00100, G1000, etc)
   */
  verifyInactivateProcedurePopupText(code: string) {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .INACTIVATE_PROCEDURE_POPUP[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .INACTIVATE_PROCEDURE_POPUP[0]
    );
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ABOUT_TO_INACTIVATE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .ABOUT_TO_INACTIVATE[0],
      HelperText.about_to_inactivate
    );
    cy.cGet(selectorFactory.getDialogSpan)
      .eq(1)
      .should(ShouldMethods.contain_text, HelperText.are_you_sure_to_continue);
    cy.cGet(selectorFactory.getDialogLi).should(
      ShouldMethods.contain_text,
      code
    );
  }

  /**
   * @details - To select the Dictionary from enterprise build dictionaries lists.
   * @Api - API's are available - Implemented Completely
   * @Author Harsh
   */
  selectDictionaryInDictionaries() {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptSelectDictionaryApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .ENTERPRISE_DICTIONARIES[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .ENTERPRISE_DICTIONARIES[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To add new dictionary items in enterprise dictionaries configuration
   * @param itemName
   * @Api - API's are available - Implemented Completely
   */
  addEnterpriseDictionaries(itemName: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAddDictionariesItemsApi();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ADD_BUTTON[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .DICTIONARY_ITEM_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .DICTIONARY_ITEM_NAME[0],
      itemName
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ITEMS_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ITEMS_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify show inactive button is by default inactive
   * @param flag
   */
  verifyShowInactive(flag: boolean = true) {
    if (flag) {
      cy.cIsVisible(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
          .SHOW_INACTIVE_NO[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
          .SHOW_INACTIVE_NO[0]
      );
    } else {
      cy.cNotExist(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
          .SHOW_INACTIVE_NO[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
          .SHOW_INACTIVE_NO[0]
      );
    }
  }

  /**
   * @details - verify warning message when consent window close button is clicked
   */
  verifyWarningMessage() {
    cy.cHasText(
      selectorFactory.getSpanText(
        AppErrorMessages.duplicate_enterprise_dict_items
      ),
      selectorFactory.getSpanText(
        AppErrorMessages.duplicate_enterprise_dict_items
      ),
      AppErrorMessages.duplicate_enterprise_dict_items
    ).then(() => {
      cy.cClick(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.OK_BUTTON[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.OK_BUTTON[0]
      );
    });
  }

  /**
   * @details - verifying the mouse hover text for options(Include entrprise items and Allow add to Dictionary) visible under configurations tab
   */
  verifyMouseHoverTextInDictionariesTab() {
    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .I_ICON_NEXT_TO_INCLUDE_ENTERPRISE_ITEM[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .I_ICON_NEXT_TO_INCLUDE_ENTERPRISE_ITEM[0],
      InvokeAttributes.p_tool_tip,
      InfoText.include_enterprise_items_dict_text
    );

    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .I_ICON_NEXT_TO_ALLOW_ADD_TO_DICTIONARY[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .I_ICON_NEXT_TO_ALLOW_ADD_TO_DICTIONARY[0],
      InvokeAttributes.p_tool_tip,
      InfoText.allow_add_to_dict_text
    );
  }

  /**
   * @details - verifying the column visibility in the dictionaries tab in facility management post selecting facility
   */
  verifyColumnsInDictionariesTab() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .DICTIONARIES_VIEWS_HEADER[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .DICTIONARIES_VIEWS_HEADER[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .DICTIONARY[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .DICTIONARY[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .INCLUDE_ENTERPRISE_ITEMS[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .INCLUDE_ENTERPRISE_ITEMS[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .ALLOW_ADD_TO_DICTIONARY[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARY_VIEWS
        .ALLOW_ADD_TO_DICTIONARY[0]
    );
  }

  /**
   * @details - To verify total items and shown counts at the bottoms of dictionaries tab
   * @param value
   */
  verifyTotalItems(value: string) {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ITEMS_LABEL[1]
    ).then(($value) => {
      cy.log($value.text().replace(/\n/g, '').trim().toLowerCase());
      expect($value.text().replace(/\n/g, '').trim().toLowerCase()).to.includes(
        value
      );
    });
  }

  /**
   * @details To rename the dictionary item names
   * @param itemName
   * @Api - API's are available - Implemented Completely
   */
  renameDictionaryItem(itemName: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAddDictionariesItemsApi();
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .DICTIONARY_ITEM_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .DICTIONARY_ITEM_NAME[0],
      itemName
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ITEMS_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ITEMS_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To select show inactive toggle button under Enterprise build dictionaries.
   * @param YesOrNo
   * @Api - API's are not available
   */
  selectShowInactiveToggle(YesOrNo: string) {
    let loc: string = '';
    switch (YesOrNo) {
      case OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .SHOW_INACTIVE_YES[0]:
        loc =
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
            .SHOW_INACTIVE_YES[1];
        break;
      case OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .SHOW_INACTIVE_NO[0]:
        loc =
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
            .SHOW_INACTIVE_NO[0];
        break;
      default:
        break;
    }
    cy.cClick(loc, YesOrNo);
  }

  /**
   * @details - Add Dictionary item with active or inactive status
   * @param YesOrNo
   * @param itemName
   * @Api - API's are available - Implemented Constant
   * @Author Harsh
   */
  addInactiveAndActiveDictItem(YesOrNo: string, itemName: string) {
    const loc = selectorFactory.dictionaryItemStatus(YesOrNo);
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAddDictionariesItemsApi();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ADD_BUTTON[0]
    );
    cy.cClick(loc, YesOrNo);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .DICTIONARY_ITEM_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .DICTIONARY_ITEM_NAME[0],
      itemName
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ITEMS_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY.ITEMS_LABEL[0]
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
        .DUPLICATE_DICTIONARY[1]
    )
      .should(ShouldMethods.visible)
      .then(($ele) => {
        if ($ele.is(FilterMethods.visible)) {
          this.verifyWarningMessage();
        } else {
          cy.cWaitApis(interceptCollection);
        }
      });
  }

  /**
   * @details - to verify dictionaries helper text messages on heading
   * @param  textToVerify
   */
  verifyDictionariesHelperText(textToVerify: string) {
    cy.cIsVisible(textToVerify, ' ', true);
  }

  /**
   * @details - To perform click operation on the Add button in Transaction Code screen
   * @Api - API's are not available
   */
  clickOnAddButtonInTransactionCode() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0]
    );
  }

  /**
   * @details - To perform click operation on the Cancel button in Transaction Code add window
   * @Api - API's are not available
   */
  clickOnCancelButtonInTransactionCodeAddWindow() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
  }

  /**
   * @details - To verify the text on add transaction code popup
   * @Api - API's are not available
   */
  verifyAddPopUpWindow() {
    this.clickOnAddButtonInTransactionCode();
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
    cy.cIsVisible(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[0]
    );
    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[0],
      CommonClassAttributes.placeholder,
      HelperText.transaction_code_name
    );
    this.clickOnCancelButtonInTransactionCodeAddWindow();
  }

  /**
   * @details - To add new transaction code
   * @param input -To write the code to be added
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  addTransactionCode(input: string) {
    this.clickOnAddButtonInTransactionCode();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .ADD_TRANSACTION_CODE_SEARCH[0],
      input
    );
    //Removed the code to click on done button in order to implement api (for duplicate or system default transaction code done button api is not coming)
  }

  /**
   * @details - To search transaction code from the search input
   * @param code -> to provide the transaction code to be searched
   */
  searchTransactionCode(code: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[0],
      code,
      false,
      true
    );
  }

  /**
   * @details - To verify that transaction code exists in the list
   * @param code -> to provide the transaction code to be searched
   * @param option -> to provide boolean true or false
   * @API - API's are not available
   */
  verifyTransactionCodeExists(code: string, option: boolean = true) {
    this.searchTransactionCode(code);
    option
      ? cy.cIsVisible(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .EXISTING_TRANSACTION_CODES[1],
          code
        )
      : cy.cNotExist(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .EXISTING_TRANSACTION_CODES[1],
          code
        );
  }

  /**
   * @details - To click on code drop down and verify its visible
   * @API - API's are not available
   */
  clickTransactionCodeTypeDropdown() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TYPE_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TYPE_DROPDOWN[0],
      false,
      true
    );
  }

  /**
   * @details - To verify values in code drop down after adding the code
   */
  verifyTransactionCodeTypeItems() {
    this.clickTransactionCodeTypeDropdown();
    typeDropDownOptionValues.forEach(($el) => {
      cy.cIncludeText(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TYPE_DROPDOWN_VALUES[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TYPE_DROPDOWN_VALUES[0],
        $el
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.clickTransactionCodeTypeDropdown();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To verify the max length of transaction code name
   * @param option - To provide the name of transaction code
   * @Api - API's are available - Implemented Completely
   * @author Harsh
   */
  verifyTransactionCodeNameLength(option: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAddTransactionCodeApi();
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[0],
      option
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[0],
      option
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[0],
      option
    );
  }

  /**
   * @details To search and select the transaction code from the list
   * @param transactionCode
   * @Api - API's are not available
   */
  searchAndSelectTransactionCode(transactionCode: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[0],
      transactionCode
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TRANSACTION_CODE_ITEM[1],
        selectorFactory.getDivText(transactionCode)
      ),
      transactionCode,
      false,
      true
    );
  }

  /**
   * @details - Verifying the transaction type after searching the added transaction code and selecting
   * @param code - to provide the transaction code for which type is to be verified
   * @param type - to provide the type value that is expected to be selected for the transaction code
   */
  verifyTransactionType(code: string, type: string) {
    this.searchAndSelectTransactionCode(code);
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SELECTED_TRANSACTION_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SELECTED_TRANSACTION_TYPE[0],
      type
    );
  }

  /**
   * @details - To select the transaction code type from the single select control
   * @param transactionType
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  selectTransactionCodeTypeItem(transactionType: string) {
    this.clickTransactionCodeTypeDropdown();
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TYPE_DROPDOWN_VALUES[1]
    ).within(() => {
      cy.cGet(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TYPE_DROPDOWNITEM[1]
      ).each(($val) => {
        if ($val.text().trim() === transactionType) {
          cy.wrap($val).within(() => {
            const interceptCollection =
              this.enterpriseConfigurationApi.interceptAddTransactionCodeApi();
            cy.cIntercept(interceptCollection);
            cy.cGet(selectorFactory.getSpanText(transactionType)).click();
            cy.cWaitApis(interceptCollection);
          });
        }
      });
    });
  }

  /**
   * @details - verify the text in input field on selecting the transaction code
   * @param transactionCode
   */
  verifyTextInTransactionCode(transactionCode: string) {
    this.searchAndSelectTransactionCode(transactionCode);
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[0],
      transactionCode
    );
  }

  /**
   * @details - verify the text in input field on selecting the transaction code
   * @param code to provide the transaction code that needs to be updated
   * @param name to provide updated transaction code name
   * @API - API's are available - Implemented Completely
   * @author Harsh
   */
  updateTransactionCodeName(code: string, name: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAddTransactionCodeApi();
    this.searchAndSelectTransactionCode(code);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[0],
      name,
      false,
      true
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To update the transaction code
   * @param input - To enter the code to be updated
   * @param option -To select the transaction type
   */
  updateTransactionCode(input: string, option: string) {
    this.addTransactionCode(input);
    this.clickAddTransactionDone(DoneOrCancel.done);
    this.selectTransactionCodeTypeItem(option);
    this.updateTransactionCodeName(
      input,
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_ITEM[0]
    );
    this.verifyTextInTransactionCode(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_ITEM[0]
    );
    this.verifyTransactionType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_ITEM[0],
      option
    );
  }

  /**
   * @details - To delete the transaction code
   * @param code -To enter the code to be deleted
   * @param option -To select yes/no in pop-up
   * @Api - API's are available - Implemented Completed
   */
  deleteTransactionCode(code: string, option: string) {
    this.searchTransactionCode(code);
    this.verifyTransactionCodeExists(code);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DELETE_CODE_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DELETE_CODE_ICON[0],
      false,
      false,
      { force: true }
    );

    this.verifyDeletePopUpWindow(code);
    const interceptCollection =
      option === YesOrNo.yes
        ? this.enterpriseConfigurationApi.interceptDeleteTransactionCodeApi()
        : [];
    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(selectorFactory.getSpanText(option)),
      option,
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(
      selectorFactory.getH2Text(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TRANSACTION_CODE_LABEL[0]
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_LABEL[0]
    );
  }

  /**
   * @details - To verify the details in delete pop-up window
   * @param code -To verify the code to be deleted text is present in the pop-up
   */
  verifyDeletePopUpWindow(code: string) {
    cy.cHasText(
      selectorFactory.getSpanText(HelperText.delete_transaction_code),
      HelperText.delete_transaction_code,
      HelperText.delete_transaction_code,
      false,
      true
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE.DIALOG[1]
    )
      .eq(0)
      .should(ShouldMethods.contain_text, HelperText.about_to_delete);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE.DIALOG[1]
    )
      .eq(1)
      .should(ShouldMethods.contain_text, HelperText.are_you_sure_to_continue);
    cy.cGet(selectorFactory.getLiText(code)).should(
      ShouldMethods.contain_text,
      code
    );
  }

  /**
   * @details - To clear the text from the transaction code name input field
   * @Api - API's are not available
   */
  clearTransactionCodeName() {
    cy.cClear(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[1]
    );
    cy.cClick(
      selectorFactory.getH2Text(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TRANSACTION_CODE_LABEL[0]
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_LABEL[0]
    );
  }

  /**
   * @details - To verify the warning pop up message when clearing the name from input field
   */
  verifyTransactionCodeNameWarning() {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .WARNING_MESSAGE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .WARNING_MESSAGE[0],
      HelperText.transactionCode_cannot_be_saved_without_name,
      false,
      true
    );
  }

  /**
   * @details - To verify the warning message displayed when adding a duplicate transaction code
   * @param type - false for system added codes, true for default duplicate message
   */
  verifyDuplicateWarningMessage(type: boolean = true) {
    type
      ? cy.cIncludeText(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .ADD_WARNING_MESSAGE[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .ADD_WARNING_MESSAGE[0],
          AppErrorMessages.duplicate_transaction_codes
        )
      : cy.cIncludeText(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .ADD_WARNING_MESSAGE[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .ADD_WARNING_MESSAGE[0],
          AppErrorMessages.duplicate_system_codes
        );
    this.clickOnCancelButtonInTransactionCodeAddWindow();
  }

  /**
   * @details - verify tick mark for the selected Transaction Code
   * @param code - to provide the transaction code
   */
  observeTickMarkForSelectedTransactionCode(code: string) {
    this.searchAndSelectTransactionCode(code);
    this.clickOnSearchFieldInTransactionCode();
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .CHECK_MARK[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .CHECK_MARK[0]
    );
  }

  /**
   * @details verifying add button, search field , Text 'Please select an existing item or create a new item.
   */
  verifyTransactionCodeOptions() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0]
    );
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DEFAULT_TEXT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DEFAULT_TEXT[0],
      InfoText.business_configuration_screen_default_text
    );
  }

  /**
   * @details select yes/no option for the toggle in Include Enterprise Item
   * @param option
   * @param configurations
   * @API - API's are available -Implemented Completely
   * @author Harsh
   */
  selectYesNoForIncludeEnterpriseItems(option: string, configurations: string) {
    const selector =
      selectorFactory.enabledIncludeEnterpriseConfigurationToggle(
        configurations,
        option
      );
    const locator = selectorFactory.includeEnterpriseConfigurationToggle(
      configurations,
      option
    );
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptIncludeEnterpriseNoApi();
    cy.cIntercept(interceptCollection);
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (body.find(selector).length <= 0) {
        cy.cClick(locator, option);
        cy.cWaitApis(interceptCollection);
      }
    });
  }

  /**
   * @details select yes/no option form the toggle in Allow IncludeEnterpriseItems
   * @param option
   * @param configurations
   * @param isEnable
   */
  verifyYesNoIsEnabledForIncludeEnterpriseItems(
    option: string,
    configurations: string,
    isEnable: boolean = true
  ) {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .CONFIGURATION_LISTS[1]
    )
      .contains(configurations)
      .parents(CommonGetLocators.tr)
      .first()
      .within(() => {
        cy.cGet(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
            .INCLUDE_ENTERPRISE_ITEMS_WITHIN_ROW[1]
        )
          .first()
          .within(() => {
            cy.cGet(`${selectorFactory.getSpanText(option)}`)
              .parent(CommonGetLocators.div)
              .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
              .then(($value) => {
                expect($value).to.be.equal(
                  isEnable === true ? TrueOrFalse.true : TrueOrFalse.false
                );
              });
          });
      });
  }

  /**
   * @details select yes/no option form the toggle in Allow Add To Configuration
   * @param option
   * @param configurations
   * @API - API's are available - Implemented Completely
   * @author Harsh
   */
  selectYesNoForAllowAddToConfiguration(
    option: string,
    configurations: string
  ) {
    const selector = selectorFactory.allowAddToConfigurationToggle(
      configurations,
      option
    );
    const locator = selectorFactory.enabledAllowAddToConfigurationsToggle(
      configurations,
      option
    );
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAllowAddToConfigurationYesApi();
    cy.cIntercept(interceptCollection);
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (body.find(locator).length <= 0) {
        cy.cClick(selector, option);
        cy.cWaitApis(interceptCollection);
      }
    });
  }

  /**
   * @details verify the Yes or No button is enabled or disabled in AllowAddToConfiguration
   * @param option YES / NO
   * @param configurations
   * @param isEnable
   */
  verifyYesNoIsEnabledForAllowAddToConfiguration(
    option: string,
    configurations: string,
    isEnable: boolean = true
  ) {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .CONFIGURATION_LISTS[1]
    )
      .contains(configurations)
      .parents(CommonGetLocators.tr)
      .first()
      .within(() => {
        cy.cGet(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
            .ALLOW_ADD_TO_ENTERPRISE_WITH_IN_ROW[1]
        )
          .first()
          .within(() => {
            cy.cGet(`${selectorFactory.getSpanText(option)}`)
              .parent(CommonGetLocators.div)
              .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
              .then(($value) => {
                expect($value).to.be.equal(
                  isEnable === true ? TrueOrFalse.true : TrueOrFalse.false
                );
              });
          });
      });
  }

  /**
   * @details - enter the transactionCode in transactionCodeFiled
   * @param transactionCode
   */
  enterNameInTransactionCodeNameField(transactionCode: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME[0],
      transactionCode
    );
    this.clickOnSearchFieldInTransactionCode();
  }

  /**
   * @details - To perform click operation on Search Field in Transaction code search box
   */
  clickOnSearchFieldInTransactionCode() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[0]
    );
  }

  /**
   * @details - verify that system default transaction codes are available
   * @param codes - to provide the array of system default codes
   */
  verifySystemDefaultCodes(codes: string[]) {
    codes.forEach((val) => {
      this.verifyTransactionCodeExists(val, false);
      this.addTransactionCode(val);
      cy.cClick(
        selectorFactory.getButtonSpanText(DoneOrCancel.done),
        DoneOrCancel.done,
        false,
        true
      );
      this.verifyDuplicateWarningMessage(false);
    });
  }

  /**
   * @details - To click on the config item Under Management setting and Enterprise build in enterprise configuration list and clear the search
   * @param configName - to provide the config item name
   * @Api - API's are available - Implemented Completely
   * @Author Harsh
   */
  clickOnConfigItem(configName: string) {
    let interceptCollection: ApiEndpoint[] = [];
    switch (configName) {
      case ManagementSettingsList.facility_management:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptFacilityManagementApi();
        break;
      case ManagementSettingsList.profiles:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptProfilesApi();
        break;
      case ManagementSettingsList.users:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptUsersApi();
        break;
      case ManagementSettingsList.non_users:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptNonUserApi();
        break;
      case ManagementSettingsList.roles:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptRolesApi();
        break;
      case ManagementSettingsList.login_acknowledgement:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptLoginAcknowledgementsApi();
        break;
      case ManagementSettingsList.support_contacts:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSupportContactsApi();
        break;
      case ManagementSettingsList.security:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSecurityApi();
        break;
      case ConfigurationsLists.fee_schedule:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildFeeScheduleApi();
        break;
      case ConfigurationsLists.transaction_code:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildTransactionCodeApi();
        break;
      case ConfigurationsLists.dictionaries:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildDictionariesApi();
        break;
      case ConfigurationsLists.discounts:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildDiscountApi();
        break;
      case ConfigurationsLists.add_on_features:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectAddOnFeaturesApi();
        break;
      case ConfigurationsLists.cbo_management:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptCboManagementApi();
        break;
      case ConfigurationsLists.contracts:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildContractsApi();
        break;
      case ManagementSettingsList.add_on_features:
        interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectEnterpriseBuildAddOnFeaturesApi();
        break;
      default:
        break;
    }
    cy.cIntercept(interceptCollection);
    cy.cClick(configName, configName, true);
    cy.cWaitApis(interceptCollection);
    cy.cClear(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_CONFIGURATION
        .ENTERPRISE_CONFIGURATION_SEARCH[1]
    );
  }

  /**
   * @details - Method to verify Outbound CCDA Feature flag in Enterprise settings
   */
  verifyOutboundCCDAFeature(flag: boolean = false) {
    const [ccdaVisible, toggleVisible] = [
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERFACES
        .OUTBOUND_CCDA,
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERFACES
        .TOGGLE,
    ];

    flag
      ? cy.cIsVisible(ccdaVisible[0], ccdaVisible[0], true)
      : cy.cNotExist(ccdaVisible[1], ccdaVisible[0]);
    flag
      ? cy.cIsVisible(toggleVisible[1], toggleVisible[0])
      : cy.cNotExist(toggleVisible[1], toggleVisible[0]);
  }

  /**
   * @details - To verify the Outbound CCDA feature state
   * @param tabName as string reference to pass in the function.
   */
  verifyOutboundCCDAState() {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERFACES
        .DISABLE[1]
    )
      .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
      .then(($disableValue) => {
        if ($disableValue == TrueOrFalse.false) {
          cy.cGet(
            OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERFACES
              .ENABLE[1]
          )
            .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
            .then(($enableValue) => {
              expect($enableValue).to.be.equal(TrueOrFalse.true);
            });
        }
      });
  }

  /**
   * @details To toggle feature flags in interfaces section in internal tab
   * @param toggleSwitchName as string reference in the function
   * @param featureId as number ref in the function : (feature_btn_76) 76
   * @param option as string reference in the function :Enable or Disable
   * @Api - API's are available - Implemented Completely
   * @author Harsh
   */
  togglesFeaturesInInterfacesInternalTab(
    toggleSwitchName: string,
    option: string
  ) {
    const loc = selectorFactory.toggleInterfacesSwitchInInternalTab(
      toggleSwitchName,
      option
    );
    const interceptCollection =
      this.enterpriseConfigurationApi.togglesInInternalTabApi();
    cy.cIntercept(interceptCollection);
    cy.cGet(loc)
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .then(($background) => {
        const hex = String(color($background.toString()).hex()).toUpperCase();

        if (
          hex ==
          AppColors.component_enabled_toggle_button_not_selected.toUpperCase()
        ) {
          cy.cClick(loc, toggleSwitchName);
          cy.cWaitApis(interceptCollection);
        }
      });
  }

  /**
   * @details - Change login location to Facility from Enterprise
   * @param facilityName as string reference to pass in the function.
   * @Api - API's are available - Implemented Completely
   * @author Harsh
   */
  switchToFacilityFromEnterprise(facilityName: string) {
    const interceptChangeLoginLocationApiCollection =
      this.enterpriseConfigurationApi.interceptChangeLoginLocationApi();
    cy.cIntercept(interceptChangeLoginLocationApiCollection);
    sisOfficeDesktop.selectOptionInUserMenuDropdown(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
    );
    cy.cWaitApis(interceptChangeLoginLocationApiCollection);
    const interceptSelectFacilityChangeLoginLocationApiCollection =
      this.enterpriseConfigurationApi.interceptSelectFacilityChangeLoginLocationApi();
    cy.cIntercept(interceptSelectFacilityChangeLoginLocationApiCollection);
    cy.cClick(
      selectorFactory.getSpanText(facilityName),
      OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0]
    );
    cy.cWaitApis(interceptSelectFacilityChangeLoginLocationApiCollection);
  }

  /**
   * @details click on Add button in Discounts feature
   * @Api - API's are not available
   */
  clickOnAddButton() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0]
    );
  }

  /**
   * @details click on cancel button in add popup window of discount
   * @Api - API's are not available
   */
  clickOnCancelButton() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
  }

  /**
   * @details verify Cancel,Done and search field placeholder text in Discount Add popup window
   */
  verifyDiscountAddPopup() {
    this.clickOnAddButton();
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
    cy.cIsVisible(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.NOTE_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.NOTE_ICON[0]
    );
    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[0],
      CommonClassAttributes.placeholder,
      HelperText.discount_search_field_text
    );
    this.clickOnCancelButton();
  }

  /**
   * @details -To add new discount
   * @param input  -To write the discount name
   * @param option -To click done or cancel in popup window
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  addDiscount(input: string, option: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateDiscountDetailsApi();
    this.clickOnAddButton();
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[0],
      input
    );
    if (option === DoneOrCancel.done) {
      cy.cIntercept(interceptCollection);
      cy.cClick(
        selectorFactory.getButtonSpanText(DoneOrCancel.done),
        DoneOrCancel.done
      );
      cy.cGet(CommonGetLocators.body).then((body) => {
        if (
          body.find(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
              .DUPLICATE_WARNING_MESSAGE[1]
          ).length > 0
        ) {
          this.verifyDuplicateWarningMessageInDiscountPopup();
          cy.cClick(
            selectorFactory.getButtonSpanText(DoneOrCancel.cancel),
            DoneOrCancel.cancel
          );
        } else {
          cy.cWaitApis(interceptCollection);
        }
      });
    } else {
      cy.cClick(
        selectorFactory.getButtonSpanText(DoneOrCancel.cancel),
        DoneOrCancel.cancel
      );
    }
  }

  /**
   * @details -To search the discount from search field
   * @param code -To provide the discount to be search
   * @API - API's are not available
   */
  searchDiscountFromSearchField(code: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[0],
      code,
      false,
      true
    );
  }

  /**
   * @details -To verify the discounts exists or not in the lists
   * @param code -To provide the discount to be search
   * @param option -To provide boolean true or false
   * @API - API's are not available
   */
  verifyDiscountExists(code: string, option: boolean = true) {
    this.searchDiscountFromSearchField(code);
    option
      ? cy.cIsVisible(selectorFactory.getTransactionItem(code), code)
      : cy.cNotExist(selectorFactory.getTransactionItem(code), code);
  }

  /**
   * @details -To search and select the discount from the list
   * @param discountName - Pass the discount to be select
   * @API - API's are not available
   */
  searchAndSelectDiscount(discountName: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[0],
      discountName
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
          .DISCOUNTS_LISTS[1],
        selectorFactory.getDivText(discountName)
      ),
      discountName
    );
  }

  /**
   * @details -To perform click operation on Search Field in Discount
   * @API - API's are not available
   */
  clickOnSearchFieldInDiscounts() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[0]
    );
  }

  /**
   * @details -To verify the checkmark/Tick mark for selected discount
   * @param discountName -selected discount name in the list
   */
  verifyTickMark(discountName: string) {
    this.searchAndSelectDiscount(discountName);
    this.clickOnSearchFieldInDiscounts();
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.CHECK_MARK[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.CHECK_MARK[0]
    );
  }

  /**
   * @details -verify the text in input field on selecting the discount
   * @param discountName -Name of the discount
   */
  verifyDiscountNameField(discountName: string) {
    this.searchAndSelectDiscount(discountName);
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[0],
      discountName
    );
  }

  /**
   * @details -To verify the transaction code dropdown placeholder value in discount screen
   * @param type -To provide the type value that is expected to be selected for the discount
   */
  verifyTransactionCodeInDiscount(type: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_TRANSACTION_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_TRANSACTION_DROPDOWN[0],
      type
    );
  }

  /**
   * @details -To verify the writeoff group code dropdown placeholder value in discount screen
   * @param type -To provide the writeoff group code value that is expected to be selected for the discount
   */
  verifyWriteOffGroupCodeInDiscount(type: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_GROUPCODE_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_GROUPCODE_DROPDOWN[0],
      type
    );
  }

  /**
   * @details -To verify the writeoff reason code dropdown placeholder value in discount screen
   * @param type -To provide the writeoff reason code value that is expected to be selected for the discount
   */
  verifyWriteOffReasonCodeInDiscount(type: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_REASONCODE_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_REASONCODE_DROPDOWN[0],
      type
    );
  }

  /**
   * @details -To verify transactionCodeDropDown is enabled after page load
   */
  verifyTransactionCodeEnable() {
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
          .SELECTED_TRANSACTION_DROPDOWN[1],
        ' ',
        CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
      )
    );
  }

  /**
   * @details -To click transaction code dropdown in discount screen
   * @Api Api's are available, not implemented
   */
  clickTransactionCodeInDiscount() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_TRANSACTION_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_TRANSACTION_DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    this.verifyTransactionCodeEnable();
  }

  /**
   * @details -To verify transaction code dropdown values
   * @param values -Values to be verify in transaction code dropdown
   */
  verifyTransactionCodeListsInDiscount(values: string[]) {
    this.clickTransactionCodeInDiscount();
    values.forEach((el) => {
      cy.cIsVisible(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
          .TRANSACTION_DROPDOWN_VALUES[1],
        el
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.clickTransactionCodeInDiscount();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details -To verify WriteOffGroupCodeDropDown is enabled after page load
   */
  verifyWriteOffDropdownEnable() {
    cy.shouldBeEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .WRITE_OFF_DROPDOWN_ICON[1]
    );
  }

  /**
   * @details -To click writeoff group code dropdown in discount screen
   * @Api Api's are available,not implemented
   */
  clickWriteOffGroupCodeInDiscount() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_GROUPCODE_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_GROUPCODE_DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    this.verifyWriteOffDropdownEnable();
  }

  /**
   * @details -To verify writeoff group code dropdown values
   * @param values -Values to be verify in writeoff group code dropdown
   */
  verifyWriteOffGroupCodeListsInDiscount(values: string[]) {
    this.clickWriteOffGroupCodeInDiscount();
    values.forEach((el) => {
      cy.cIsVisible(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
          .GROUPCODE_DROPDOWN_VALUES[1],
        el
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.clickWriteOffGroupCodeInDiscount();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details -To click writeoff reason code dropdown in discount screen
   * @Api Api's are available,Not implemented
   */
  clickWriteOffReasonCodeInDiscount() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_REASONCODE_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .SELECTED_WRITEOFF_REASONCODE_DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    this.verifyWriteOffDropdownEnable();
  }

  /**
   * @details -To verify writeoff group code dropdown values
   * @param values -Values to be verify in writeoff group code dropdown
   */
  verifyWriteOffReasonCodeListsInDiscount(values: string[]) {
    this.clickWriteOffReasonCodeInDiscount();
    values.forEach((el) => {
      cy.cIsVisible(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
          .REASONCODE_DROPDOWN_VALUES[1],
        el
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.clickWriteOffReasonCodeInDiscount();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Check the Done and Cancel button in add popup of discount before entering discount name
   */
  verifyAddDiscountStateBeforeInputs() {
    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
    cy.cIsEnabled(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
      false,
      false
    );
  }

  /**
   * @details - Check the Done and Cancel button in add popup of discount after entering discount name
   */
  verifyAddDiscountStateAfterInputs(input: string) {
    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_DISCOUNT_SEARCH_FIELD[0],
      input
    );
    cy.cIsEnabled(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    this.clickOnCancelButton();
  }

  /**
   * @details - Check the Add button and Dropdown states, after removing name field in discounts
   */
  verifyStatesOfFieldsInDiscountScreen() {
    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0],
      false,
      false
    );
    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_PERCENT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_PERCENT[0],
      false,
      false
    );
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISABLE_TRANSACTION_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISABLE_TRANSACTION_CODE[0],
      CommonClassAttributes.pdisabled
    );
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISABLE_GROUP_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISABLE_GROUP_CODE[0],
      CommonClassAttributes.pdisabled
    );
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISABLE_REASON_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISABLE_REASON_CODE[0],
      CommonClassAttributes.pdisabled
    );
  }

  /**
   * @details - verify the length of discount name field
   * @param option - enter the name that length need to be verify
   */
  verifyDiscountNameFieldLength(option: string) {
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[0],
      option
    );
  }

  /**
   * @details Enter value in Discount percentage field
   * @param option Value to be type in discount percentage field
   * @API - API's are available - Implemented Completely
   * @author Harsh
   */
  enterDiscountPercentage(option: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateDiscountDetailsApi();
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_PERCENT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_PERCENT[0],
      option
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Enter name in discount name field
   * @param option Name to be update in name field
   * @API - API's are available - Implemented Completely
   */
  enterTextInNameField(option: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateDiscountDetailsApi();
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[0],
      option
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .TRANSACTION_CODE_NAME_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Verify value in Discount percentage field
   * @param value Value to be verify in discount percentage field
   */
  verifyDiscountPercentage(value: string) {
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_PERCENT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_PERCENT[0],
      value
    );
  }

  /**
   * @details Select the value from Transaction code dropdown in discount
   * @param transactionType - Value to be selected from Transaction code dropdown in Discount
   * @API - API's are available - Implemented Completely
   * @Author HArsh
   */
  selectTransactionCodeInDiscount(transactionType: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateDiscountDetailsApi();
    this.clickTransactionCodeInDiscount();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(transactionType), transactionType);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Select the value from Group code dropdown in discount
   * @param groupCode - Value to be selected from Group code dropdown in Discount
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  selectGroupCodeInDiscount(groupCode: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateDiscountDetailsApi();
    this.clickWriteOffGroupCodeInDiscount();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(groupCode), groupCode);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details Select the value from Reason code dropdown in discount
   * @param reasonCode - Value to be selected from Reason code dropdown in Discount
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  selectReasonCodeInDiscount(reasonCode: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateDiscountDetailsApi();
    this.clickWriteOffReasonCodeInDiscount();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(reasonCode), reasonCode);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify duplicate warning message by adding existing discount in add popup
   */
  verifyDuplicateWarningMessageInDiscountPopup() {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DUPLICATE_WARNING_MESSAGE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DUPLICATE_WARNING_MESSAGE[0],
      AppErrorMessages.duplicate_discounts
    );
  }

  /**
   * @details clear discount name field
   * @Api Api's are not available
   */
  clearDiscountName() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[0]
    );
    cy.cClear(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .DISCOUNT_NAME_FIELD[1]
    );
  }

  /**
   * @details verify warning banner by removing discount name field
   */
  verifyWaringBannerByClearingName() {
    this.clearDiscountName();
    this.clickOnAddButton();
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_WARNING_MESSAGE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
        .ADD_WARNING_MESSAGE[0],
      AppErrorMessages.disclaimer_discount_warning
    );
  }

  /**
   * @details click X mark in discount search field
   * @Api Api's are not available
   */
  clickXMarkInDiscountSearch() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.X_MARK[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.X_MARK[0]
    );
  }

  /**
   * @details - To verify the details in delete pop-up of Transaction when it is already in use at Enterprise
   * @API - API's are not available
   */
  deleteMappedTransactionCode(code: string, option: string) {
    this.searchTransactionCode(code);
    this.verifyTransactionCodeExists(code);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DELETE_CODE_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DELETE_CODE_ICON[0],
      false,
      false,
      { force: true }
    );
    this.verifyDeletePopUpWindow(code);
    cy.cClick(
      CommonUtils.concatenate(selectorFactory.getSpanText(option)),
      option,
      false,
      true
    );
    cy.cHasText(
      selectorFactory.getSpanText(HelperText.delete_transaction_code),
      HelperText.delete_transaction_code,
      HelperText.delete_transaction_code,
      false,
      true
    );
    cy.cGet(OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.DIALOG[1]);
    HelperText.you_cannot_delete;
    HelperText.transaction_code_is_currently_in_use;
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.OK_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.OK_BUTTON[0]
    );
  }

  /**
   * @details verifying Discounts add button, search field , Text 'Please select an existing item or create a new item.
   */
  verifyDiscountScreenOptions() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.SEARCH_INPUT[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0]
    );
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.DEFAULT_TEXT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS.DEFAULT_TEXT[0],
      InfoText.business_configuration_screen_default_text
    );
  }

  /**
   * @details Verifying feature flag under SIS Office Internal tab.
   * @param flag Flag label value
   * @param state Show/Hide as selected state
   */
  verifyFeatureFlag(flag: string, state: string) {
    cy.cIsVisible(selectorFactory.getFeatureUsingID(flag), flag);
    cy.cGet(selectorFactory.getFeatureUsingID(flag))
      .find(
        CommonUtils.concatenate(
          CommonGetLocators.div,
          CoreCssClasses.Button.loc_p_button,
          CoreCssClasses.Style.loc_p_highlight
        )
      )
      .should(ShouldMethods.attribute, InvokeAttributes.aria_label, state);
  }

  /**
   * @details Verifying CBO User toggle under CBO details
   * @param flag true boolean by default
   * @param option to provide as Yes or No
   */
  verifyCBOUserToggle(flag: boolean = true, option: string) {
    flag
      ? cy.cClick(selectorFactory.getCBOToggle(option), option)
      : cy.cNotExist(selectorFactory.getCBOToggle(option), option);
  }

  /**
   * @details Search and select the item from the list
   * @param searchString to provide the search input as string
   * @param item Item as string reference
   */
  searchAndSelectItem(searchString: string, item: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[0],
      searchString
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TRANSACTION_CODE_ITEM[1],
        selectorFactory.getDivText(item)
      ),
      item,
      false,
      true
    );
  }

  /**
   * @details Verifying CBO details tab under user
   * @param tab UserManagement model as parameter
   * @param flag true boolean by default
   */
  verifyCBODetailsTab(tab: UserManagement, flag: boolean = true) {
    flag
      ? cy.cIsVisible(selectorFactory.verifyTabs(tab.TabName), tab.TabName)
      : cy.cNotExist(selectorFactory.verifyTabs(tab.TabName), tab.TabName);
  }

  /**
   * @details Adding a new CBO entity under CBO Management
   * @param cbo CBO Management model as a parameter
   * @param option Done or Cancel as a parameter
   */
  addCBOEntity(cbo: CBOManagement, option: string) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.ADD_BUTTON[0]
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ADD_SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ADD_SEARCH_INPUT[0]
    )
      .click()
      .type(cbo.CBOEntity);
    cy.cClick(selectorFactory.getButtonSpanText(option), option, false, true);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[0]
    )
      .click()
      .type(cbo.Acronym);
  }

  /**
   * @details Map facilities to a CBO entity under CBO Management
   * @param cbo CBO Management model to provide as parameter
   */
  mapUnMapFacilityToCBO(cbo: CBOManagement) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.FACILITIES_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.FACILITIES_DROPDOWN[0]
    );
    cbo.FacilitiesIncluded.forEach((val) => {
      cy.cClick(selectorFactory.getSpanText(val), val);
    });
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.FACILITIES_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.FACILITIES_DROPDOWN[0],
      false,
      false,
      {
        force: true,
      }
    );
  }

  /**
   * @details Mapping CBO entity and profile to the user under User Management
   * @param cbo CBOManagement model to be provided
   * @param profile Profiles model to be provided
   */
  mapCBOEntityAndProfile(cbo: CBOManagement, profile: Profiles) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.USERS.CBO_DETAILS_ADD_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.USERS.CBO_DETAILS_ADD_ICON[0]
    );
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(selectorFactory.getSpanText(cbo.CBOEntity), cbo.CBOEntity);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_PROFILE_DROPDOWN[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_PROFILE_DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getSpanText(profile.ProfileName),
      profile.ProfileName
    );
  }

  /**
   * @details Verifying CBO entity details under Login location Window
   * @param cbo CBO entity as string to be provided
   */
  verifyCBODetailsInLoginWindow(cbo: string) {
    cy.cIsVisible(selectorFactory.getSpanText(cbo), cbo);
  }

  /**
   * @details To search the CBO entity under CBO Management screen
   * @param cbo CBO Management model as a parameter
   */
  searchCBOEntity(cbo: CBOManagement) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[0],
      cbo.CBOEntity
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TRANSACTION_CODE_ITEM[1],
        selectorFactory.getDivText(cbo.CBOEntity)
      ),
      cbo.CBOEntity,
      false,
      true
    );
  }

  /**
   * @details To update name and acronym from CBO entity
   * @param cbo CBO Management model as parameter
   * @Api Api's are available,Not implemented
   */
  updateCBOEntity(cbo: CBOManagement) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_NAME_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_NAME_INPUT[0],
      cbo.CBOEntity
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[0],
      cbo.Acronym
    );
  }

  /**
   * @details To verify the name and acronym for CBO Entity
   * @param cbo CBO Management model as parameter
   */
  verifyCBOEntityNameAcronym(cbo: CBOManagement) {
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_NAME_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_NAME_INPUT[0],
      cbo.CBOEntity
    );
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[0],
      cbo.Acronym
    );
  }

  /**
   * @details To verify the facilities mapped to the CBO entity
   * @param cbo CBO Management model as parameter
   */
  verifyFacilitiesIncluded(cbo: CBOManagement) {
    cbo.FacilitiesIncluded.forEach((val) => {
      cy.cIsVisible(selectorFactory.getFacilityIncludedText(val), val);
    });
  }

  /**
   * @details To verify duplicate warning message while adding CBO
   * @param cbo CBO Management model as parameter
   */
  verifyDuplicateWarningCBO(cbo: CBOManagement) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.ADD_BUTTON[0]
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ADD_SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ADD_SEARCH_INPUT[0]
    )
      .click()
      .type(cbo.CBOEntity);
    cy.cClick(
      selectorFactory.getButtonSpanText(DoneOrCancel.done),
      DoneOrCancel.done,
      false,
      true
    );
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_DUPLICATE_WARNING[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_DUPLICATE_WARNING[0],
      AppErrorMessages.duplicate_cbo_entity_names,
      false,
      true
    );
    cy.cClick(
      selectorFactory.getSpanText(DoneOrCancel.cancel),
      DoneOrCancel.cancel
    );
  }

  /**
   * @details To verify warning message when saving CBO entity without name
   * @param cbo CBO Management model as parameter
   */
  verifyBlankCBOEntityWarning(cbo: CBOManagement) {
    this.searchCBOEntity(cbo);
    cy.cClear(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_NAME_INPUT[1]
    );
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.ACRONYM_TEXT_INPUT[0]
    );
    cy.cIsVisible(
      selectorFactory.getSpanText(AppErrorMessages.cbo_entity_name_warning),
      AppErrorMessages.cbo_entity_name_warning
    );
  }

  /**
   * @details To delete CBO entity from CBO management screen
   * @param cbo CBO Management model as parameter
   * @param option Yes or No as string parameter
   * @Api Api's are available,Not implemented
   */
  deleteCBOEntity(cbo: CBOManagement, option: string) {
    this.searchCBOEntity(cbo);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DELETE_CODE_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .DELETE_CODE_ICON[0],
      false,
      false,
      { force: true }
    );
    this.verifyCBODeletePopUpWindow(cbo);
    cy.cClick(
      CommonUtils.concatenate(selectorFactory.getSpanText(option)),
      option,
      false,
      true
    );
  }

  /**
   * @details To verify the delete window pop up for CBO Entity
   * @param cbo CBOManagement model as parameter
   */
  verifyCBODeletePopUpWindow(cbo: CBOManagement) {
    cy.cGet(selectorFactory.getSpanText(cbo.CBOEntity)).should(
      ShouldMethods.contain_text,
      cbo.CBOEntity
    );
  }

  /**
   * @details To verify the list of CBO details mapped in CBO details
   * @param cbo CBODetails model as parameter
   */
  verifyCBOListInCBODetails(cbo: CBODetails) {
    cbo.CBOEntity.forEach((val) => {
      cy.cIsVisible(selectorFactory.getSpanText(val), val);
    });
  }

  /**
   * @details Select the facility from Add On Features
   * @param facility To provide facility value as string
   * @Api Api's are available,Not implemented
   */
  selectFacilityAddOnFeatures(facility: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
        .SEARCH_INPUT[0],
      facility
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
          .TRANSACTION_CODE_ITEM[1],
        selectorFactory.getDivText(facility)
      ),
      facility,
      false,
      true
    );
  }

  /**
   * @details Select the facility from Add On Features
   * @param feature To provide feature value as string
   */
  searchAddOnFeature(feature: AddOnFeatures) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ADD_ON_FEATURES.FEATURE_NAME_SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ADD_ON_FEATURES.FEATURE_NAME_SEARCH_INPUT[0],
      feature.FeatureName
    );
  }

  /**
   * @details To verify if the particular option is visible under Enterprise Build
   * @param option as string reference in the function
   * @param flag boolean set to true by default
   */
  verifyMenuInEnterpriseConfig(option: string, flag: boolean = true) {
    const item = selectorFactory.itemInEnterpriseBuild(option);
    flag
      ? cy.cIsVisible(item, option, false, true)
      : cy.cNotExist(item, option);
  }

  /**
   * @detail Assertion to load configuration tab verify yes/no option form the toggle in Allow Add To Configuration
   * @param - option - values Yes or No will be passed
   * @param - configurations - like transaction codes in the submenu items
   *
   */
  assertToLoadConfigurationTab(option: string, configurations: string) {
    this.verifyMouseHoverTextInConfigurationsTab();
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
        .CONFIGURATION_LISTS[1]
    )
      .contains(configurations)
      .parents(CommonGetLocators.tr)
      .first()
      .within(() => {
        cy.cGet(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.CONFIGURATION_VIEWS
            .INCLUDE_ENTERPRISE_ITEMS_WITHIN_ROW[1]
        )
          .first()
          .within(() => {
            cy.shouldBeEnabled(`${selectorFactory.getSpanText(option)}`);
          });
      });
  }

  /**
   * @details verifying add button, search field , Text 'Please select an existing item or create a new item.
   */
  verifyContractScreenOptions() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0]
    );
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.DEFAULT_TEXT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.DEFAULT_TEXT[0],
      InfoText.business_configuration_screen_default_text
    );
  }

  /**
   * @details - To click on Done or Cancel button in add contract pop up model
   * @param button - Done or Cancel should be passed using DoneOrCancel
   */
  clickOnDoneOrCancelInAddContractPopUp(button: DoneOrCancel) {
    const buttonSelector =
      button === DoneOrCancel.done
        ? OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON
        : OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .CANCEL_BUTTON;
    cy.cClick(buttonSelector[1], buttonSelector[0]);
  }

  /**
   * @details - To click on Add New or Create Copy in add contract pop up  window
   * @param button - AddNew or CreateCopy has to be passed using
   */
  clickOnAddNewOrCreateCopy(button: AddNewOrCreateCopy) {
    const buttonSelector =
      button === AddNewOrCreateCopy.AddNew
        ? OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_NEW
        : OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CREATE_COPY;
    cy.cClick(buttonSelector[1], buttonSelector[0]);
  }

  /**
   * @details - To verify fields in the add contract pop up window when clicked on add button in contract screen
   */
  verifyAddContractPopUpWindow() {
    this.clickOnAddButton();
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_NEW[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_NEW[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CREATE_COPY[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CREATE_COPY[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
    cy.cIsVisible(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.NOTE_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.NOTE_ICON[0]
    );
    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[0],
      CommonClassAttributes.placeholder,
      HelperText.contract_name
    );
    this.clickOnDoneOrCancelInAddContractPopUp(DoneOrCancel.cancel);
  }

  /**
   * @details - To verify the default dropdown items in Create Copy in Add Contract popup,
   * And to verify the done button is enabled or not
   * @param copyContractDD - The default selected dropdown value as to be passed to verify it
   * @param enabled - Pass true to verify the done is enable and vice versa
   */
  verifyCopyContractFields(copyContractDD: string, enabled: boolean = true) {
    this.clickOnAddButton();
    this.clickOnAddNewOrCreateCopy(AddNewOrCreateCopy.CreateCopy);
    cy.cIncludeText(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .CREATE_COPY_DD[1],
        ' ',
        selectorFactory.getSpanText(copyContractDD)
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CREATE_COPY_DD[0],
      copyContractDD
    );
    cy.cHasAttribute(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[0],
      CommonClassAttributes.placeholder,
      HelperText.contract_name
    );
    /**
     * verifying the done button is enabled or not
     */
    cy.cIsEnabled(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
      false,
      enabled
    );
    this.clickDoneOrCancelInAddContractPopUp(DoneOrCancel.cancel);
  }

  /**
   * @details - To add contract in contract screen
   * @param contractInfo - enter the name of the contract to be added
   * @param option - click the option done or cancel
   */
  addContract(contractInfo: Contracts, option: string) {
    this.clickOnAddButton();
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[0],
      contractInfo.ContractName
    );
    cy.cClick(selectorFactory.getButtonSpanText(option), option, false, true);
  }

  /* * @details - To Click on done button in add new transaction code pop-up and to verify any  warning message the method is implemented internally in the same method
   * @param option -To select done or cancel in the popup window
   * @API - API's are available - Implemented Completely
   * @Author Harsh
   */
  clickAddTransactionDone(option: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAddTransactionCodeApi();
    if (option === DoneOrCancel.done) {
      cy.cIntercept(interceptCollection);
      cy.cClick(
        selectorFactory.getButtonSpanText(DoneOrCancel.done),
        DoneOrCancel.done,
        false,
        true
      );
      cy.cGet(CommonGetLocators.body).then((body) => {
        if (
          body.find(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
              .WARNING_MESSAGE[1]
          ).length > 0
        ) {
          this.verifyTransactionCodeNameWarning();
        } else if (
          body.find(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
              .ADD_WARNING_MESSAGE[1]
          ).length > 0
        ) {
          this.verifyDuplicateWarningMessage(true);
        } else {
          cy.cWaitApis(interceptCollection);
        }
      });
    }
  }

  /**
   * @details - To verify the Contract exists or not in the list
   * @param contractInfo -> to provide the contract name to be searched
   * @param option -> to provide boolean true or false
   */
  verifyContractExist(contractInfo: Contracts, option: boolean = true) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[0],
      contractInfo.ContractName
    );
    option
      ? cy
          .get(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON
              .FIRST_OPTION_IN_LIST[1]
          )
          .then(($list) => {
            if ($list.text().includes(contractInfo.ContractName)) {
              return true;
            }
            return false;
          })
      : cy.cNotExist(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON
            .FIRST_OPTION_IN_LIST[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON
            .FIRST_OPTION_IN_LIST[0]
        );
  }

  /**
   * @details - Select First Option in List under Enterprise build
   */
  selectConfigurationFirstTemplate() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON
        .FIRST_OPTION_IN_LIST[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON
        .FIRST_OPTION_IN_LIST[0]
    );
  }

  /**
   * @details - type Contract name in search input
   * @param contractInfo - enter Contract name in the search field
   */
  searchAndSelectContract(contractInfo: Contracts) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[0],
      contractInfo.ContractName
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON
        .FIRST_OPTION_IN_LIST[1]
    ).then(($list) => {
      if ($list.text().includes(contractInfo.ContractName)) {
        return true;
      }
      return false;
    });
    this.selectConfigurationFirstTemplate();
  }

  /**
   * @details -verify the text in input field on selecting the contract
   * @param contractInfo -Name of the contract should be passed.
   */
  verifyContractNameField(contractInfo: Contracts) {
    this.searchAndSelectContract(contractInfo);
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .CONTRACT_NAME_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .CONTRACT_NAME_FIELD[0],
      contractInfo.ContractName
    );
  }

  /**
   * @details - To select Effective date while creating contact.
   * @param contractInfo - Need to pass Contracts model which contains effective date.
   */
  contractEffectiveDate(contractInfo: Contracts) {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EFFECTIVE_DATE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EFFECTIVE_DATE[0]
    ).then(() => {
      cy.cType(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EFFECTIVE_DATE[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EFFECTIVE_DATE[0],
        contractInfo.EffectiveDate
      );
    });
  }

  /**
   * @details - To select Expiration date while creating contact.
   * @param contractInfo - need to pass Contracts model which contains Expiration date.
   */
  contractExpirationDate(contractInfo: Contracts) {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EXPIRATION_DATE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EXPIRATION_DATE[0]
    ).then(() => {
      cy.cType(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EXPIRATION_DATE[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EXPIRATION_DATE[0],
        contractInfo.ExpirationDate
      );
    });
  }

  /**
   * @details - To verify the contract type dropdown options in contracts
   * @param contractType - need pass array of dropdown values which need to verified
   */
  verifyContractTypeValues(contractType: string[]) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[0]
    );
    contractType.forEach(($values) => {
      cy.cIncludeText(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .CONTRACT_TYPE_DD[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .CONTRACT_TYPE_DD[0],
        $values
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[0]
    );
  }

  /**
   * @details - To verify date of the selected Effective date in contracts.
   * @param contractInfo - Contracts model as to passed which contains Effective date to be verified
   */
  verifyContractEffectiveDate(contractInfo: Contracts) {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EFFECTIVE_DATE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EFFECTIVE_DATE[0]
    ).then(() => {
      cy.cHasValue(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EFFECTIVE_DATE[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EFFECTIVE_DATE[0],
        contractInfo.EffectiveDate
      );
    });
  }

  /**
   * @details - To verify date of the selected Expiration date in contracts.
   * @param contractInfo - Contracts model as to passed which contains Expiration date to be verified
   */
  verifyContractExpirationDate(contractInfo: Contracts) {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EXPIRATION_DATE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EXPIRATION_DATE[0]
    ).then(() => {
      cy.cHasValue(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EXPIRATION_DATE[1],
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .EXPIRATION_DATE[0],
        contractInfo.ExpirationDate
      );
    });
  }

  /**
   * @details - To select the contract type while creating contract.
   * @param contractInfo - Contracts model as to passed which contains contact type to be selected.
   */
  selectContractType(contractInfo: Contracts) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[0]
    );
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .CONTRACT_TYPE_DD[1],
        ' ',
        selectorFactory.getSpanText(contractInfo.ContractType!)
      )
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE_DD[1]
    )
      .contains(contractInfo.ContractType!)
      .click();
  }

  /**
   * @details - To verify the Tab Headings in contracts screen.
   * @param tabHeaders - Array of Tab Headings need to be passed which are to be verified.
   */
  verifyTabHeadingInContracts(tabHeaders: string[]) {
    tabHeaders.forEach(($tab, index) => {
      cy.cGet(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .TABS_UNDER_CONTRACTS[1]
      )
        .eq(index)
        .should(ShouldMethods.include_text, $tab);
    });
  }

  /**
   * @details - To select the tabs in contracts
   * @param tabHeading - Tab heading to be selected should be passed
   */
  selectTabHeadingInContracts(tabHeading: string) {
    if (tabHeading === ContractHeaders.ReviewEdit) {
      const interceptCollection =
        this.enterpriseConfigurationApi.interceptSelectTabHeadingInContractsApi();
      cy.cIntercept(interceptCollection);
      cy.cClick(
        CommonUtils.concatenate(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .TABS_UNDER_CONTRACTS[1],
          ' ',
          selectorFactory.getSpanText(tabHeading)
        ),
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .TABS_UNDER_CONTRACTS[0]
      );
      cy.cWaitApis(interceptCollection);
      cy.cRemoveMaskWrapper(Application.office);
    } else {
      cy.cClick(
        CommonUtils.concatenate(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .TABS_UNDER_CONTRACTS[1],
          ' ',
          selectorFactory.getSpanText(tabHeading)
        ),
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .TABS_UNDER_CONTRACTS[0]
      );
      cy.cRemoveMaskWrapper(Application.office);
    }
  }

  /**
   * @details - To verify the Fee Group table is available in contracts screen under Posting options where contract type is grouper
   */
  verifyFeeGroup() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.FEE_GROUP[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.FEE_GROUP[0]
    );
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.PLUS_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.PLUS_ICON[0]
    );
  }

  /**
   *
   * @param dropdown - Need to pass dropdown value to be clicked
   * @details - To just click on the dropdown item in posting options
   */
  clickDropdownInPostingOptions(dropdown: string) {
    const dropdownProperties = {
      [OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .ADJUSTMENT_TIME[0]]: {
        selector:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .ADJUSTMENT_TIME[1],
        logicalName:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .ADJUSTMENT_TIME[0],
      },
      [OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[0]]: {
        selector:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DEFAULT_WRITEOFF_TRANSACTION_CODE[1],
        logicalName:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DEFAULT_WRITEOFF_TRANSACTION_CODE[0],
      },
      [OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[0]]: {
        selector:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DEFAULT_WRITEOFF_GROUP_CODE[1],
        logicalName:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DEFAULT_WRITEOFF_GROUP_CODE[0],
      },
      [OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[0]]: {
        selector:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DEFAULT_WRITEOFF_REASON_CODE[1],
        logicalName:
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DEFAULT_WRITEOFF_REASON_CODE[0],
      },
    };

    const dropdownData = dropdownProperties[dropdown];
    if (!dropdownData) {
      return;
    }

    const dropdownSelector = dropdownData.selector;
    const dropdownLogicalName = dropdownData.logicalName;
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, dropdownLogicalName);
  }

  /**
   * @details - To verify the dropdown options of Adjustment Time Options under Posting options in contract screen.
   * @param options - Array of dropdown options to be passed which are to be verified.
   */
  verifyAdjustmentTimeOptions(options: string[]) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .ADJUSTMENT_TIME[0]
    );
    options.forEach(($option) => {
      cy.cIncludeText(
        CommonUtils.concatenate(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText($option)
        ),
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
        $option
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.selectTabHeadingInContracts(ContractHeaders.PostingOption);
  }

  /**
   * @details - To verify the dropdown options of Default WriteOff TransactionCode Options under Posting options in contract screen.
   * @param options - Array of dropdown options to be passed which are to be verified.
   */
  verifyDefaultWriteOffTransactionCodeOptions(options: string[]) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[0]
    );
    options.forEach(($option) => {
      cy.cGet(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .DROPDOWN_COMPONENT[1]
      ).then(($body) => {
        if (
          $body.find(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
              .POSTING_OPTIONS.DROPDOWN_COMPONENT_INPUT_FIELD[1]
          ).length
        ) {
          cy.cType(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
              .POSTING_OPTIONS.DROPDOWN_COMPONENT_INPUT_FIELD[1],
            '',
            $option
          );
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
                .POSTING_OPTIONS.POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
              ' ',
              selectorFactory.getSpanText($option)
            ),
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
              .POSTING_OPTIONS.POSTING_OPTIONS_DROPDOWN_WRAPPER[0],
            $option
          );
        } else {
          cy.cIncludeText(
            CommonUtils.concatenate(
              OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
                .POSTING_OPTIONS.POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
              ' ',
              selectorFactory.getSpanText($option)
            ),
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
              .POSTING_OPTIONS.POSTING_OPTIONS_DROPDOWN_WRAPPER[0],
            $option
          );
        }
      });
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.selectTabHeadingInContracts(ContractHeaders.PostingOption);
  }

  /**
   * @details - To verify the dropdown options of Default WriteOff GroupCode Options under Posting options in contract screen.
   * @param options - Array of dropdown options to be passed which are to be verified.
   */
  verifyDefaultWriteOffGroupCodeOptions(options: string[]) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[0]
    );
    options.forEach(($option) => {
      cy.cIncludeText(
        CommonUtils.concatenate(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText($option)
        ),
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[0],
        $option
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.selectTabHeadingInContracts(ContractHeaders.PostingOption);
  }

  /**
   * @details - To verify the dropdown options of Default WriteOff Reason Options under Posting options in contract screen.
   * @param options - Array of dropdown options to be passed which are to be verified.
   */
  verifyDefaultWriteOffReasonCodeOptions(options: string[]) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[0]
    );
    options.forEach(($option) => {
      cy.cIncludeText(
        CommonUtils.concatenate(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText($option)
        ),
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[0],
        $option
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    this.selectTabHeadingInContracts(ContractHeaders.PostingOption);
  }

  /**
   * @details - To add Fee Group under Posting options in contract screen.
   * @param feeGroups - Need to AddFeeGroup which contains Index and Reimbursement
   */
  addFeeGroup(feeGroups: AddFeeGroup) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptAddFeeGroupApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.PLUS_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.PLUS_ICON[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.DROPDOWN_COMPONENT[1]
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.DROPDOWN_COMPONENT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.DROPDOWN_COMPONENT[0]
    );
    cy.shouldBeEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.SEARCH[1]
    );
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.SEARCH[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.SEARCH[0],
      feeGroups.Index
    );

    cy.cClick(selectorFactory.getOptionInFeeGroupDropdown(feeGroups.Index), '');
    cy.cWaitApis(interceptCollection);
    cy.cGet(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .FEE_GROUPS.ROW_WITH_IN_FEE_GROUP[1],
        ' ',
        selectorFactory.getSpanText(feeGroups.Index)
      )
    )
      .parents(CommonGetLocators.tr)
      .within(() => {
        cy.cGet(CommonGetLocators.td)
          .eq(1)
          .click()
          .type(feeGroups.Reimbursement);
      });
    this.selectTabHeadingInContracts(ContractHeaders.PostingOption);
  }

  /**
   * @details - To verify the column names under Review/Edit tab in contract screen.
   * @param values - Array of column names has to be passed which are to verified.
   */
  verifyColumnsNameUnderReviewEdit(values: string[]) {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .HEADERS_ROW[1]
    )
      .first()
      .within(() => {
        Array.from({ length: values.length }).forEach(($val, $index) => {
          cy.cGet(`${selectorFactory.getThText(values[$index])}`);
        });
      });
  }

  /**
   *  @details -To click on  searched procedure in contracts review/edit
   */
  clickOnSearchedProcedureInContract(procedure: string) {
    cy.cGet(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
        ' ',
        selectorFactory.getDivText(procedure)
      ),

      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[0]
    ).dblclick();
  }

  /**
   * @details - To search procedure in contracts in review/edit
   * @param value - as searching the procedure in contracts in review/edit
   * @Api Apis are available,Implemented completely
   */
  searchProcedureInContracts(value: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .SEARCH_PROCEDURE_IN_CONTRACTS[1]
    )
      .focus()
      .click({ force: true })
      .then(() => {
        const interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectTabHeadingInContractsApi();
        cy.cIntercept(interceptCollection);
        cy.cType(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .SEARCH_PROCEDURE_IN_CONTRACTS[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .SEARCH_PROCEDURE_IN_CONTRACTS[0],
          value
        );
        cy.cWaitApis(interceptCollection);
      });
    this.selectTabHeadingInContracts(ContractHeaders.ReviewEdit);
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
        ' ',
        selectorFactory.getDivText(value)
      )
    );
    cy.cGet(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
        ' ',
        selectorFactory.getDivText(value)
      ),

      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[0]
    ).dblclick({ force: true });
    this.clickOnSearchedProcedureInContract(value);
  }

  /**
   * @details - Enter % of Billed Charges at Posting options where Contract type is % of Billed Charge
   * @param value - Value to be entered should be passed as value
   */
  enterContractPercentage(value: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .PERCENTAGE_OF_ALLOWED[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .PERCENTAGE_OF_ALLOWED[0],
      value
    );
  }

  /**
   * @details - To verify the value in the % of Billed Charge input filed at Posting options under Review/Edit tab where contract type is % of Billed Charge.
   * @param value - value to be verified should be passed.
   */
  verifyContractPercentage(value: string) {
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .PERCENTAGE_OF_ALLOWED[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .PERCENTAGE_OF_ALLOWED[0],
      value
    );
  }

  /**
   * @details - To verify the maximum length of text in contracts Name in contract screen
   * @param maxLength - max length should be passed as param
   */
  verifyMaxLengthOfContractName(maxLength: number) {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .CONTRACT_NAME_FIELD[1]
    ).then(($val) => {
      const text = $val.text().length;
      cy.wrap(text).should(ShouldMethods.lessThan, maxLength);
    });
  }

  /**
   * @details - To add notes in Contracts in contracts screen
   * @param contract - Contracts model should be passed which contains notes.
   */
  addNotesInContract(contract: Contracts) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_NOTES[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_NOTES[0],
      contract.Notes
    );
  }

  /**
   * @details - To verify the maximum length of text in contracts notes in contract screen
   * @param maxLength - max length should be passed as param
   */
  verifyMaxLengthOfTextInContractNotes(maxLength: number) {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_NOTES[1]
    ).then(($val) => {
      const text = $val.text().length;
      cy.wrap(text).should(ShouldMethods.lessThan, maxLength);
    });
  }

  /**
   * @details - To verify the warning message under Posting options in contracts screen
   */
  verifyWarningTextUnderPostingOptions() {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .WARNING_TEXT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .WARNING_TEXT[0],
      HelperText.do_not_modify_existing_contract
    );
  }

  /**
   * @details - To select dropdown option for Adjustment Time dropdown under Posting options in contract screen.
   * @param option - option to be selected from the dropdown should be passed.
   */
  selectAdjustmentTimeDropdown(option: string) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .ADJUSTMENT_TIME[0]
    );
    cy.shouldBeEnabled(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
        ' ',
        selectorFactory.getSpanText(option)
      )
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .POSTING_OPTIONS_DROPDOWN_WRAPPER[1]
    )
      .contains(option)
      .click();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To select dropdown option for DefaultWriteOffGroupCode under Posting options in contract screen.
   * @param option - option to be selected from the dropdown should be passed.
   */
  selectDefaultWriteOffGroupCode(option: string) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptWriteOffDropDownApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
        ' ',
        selectorFactory.getSpanText(option)
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .POSTING_OPTIONS_DROPDOWN_WRAPPER[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To select dropdown option for DefaultWriteOffReasonCode under Posting options in contract screen.
   * @param option - option to be selected from the dropdown should be passed.
   */
  selectDefaultWriteOffReasonCode(option: string) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[0]
    );
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptWriteOffDropDownApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
        ' ',
        selectorFactory.getSpanText(option)
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .POSTING_OPTIONS_DROPDOWN_WRAPPER[1]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To select dropdown option for DefaultWriteOffTransactionCode under Posting options in contract screen.
   * @param option - option to be selected from the dropdown should be passed.
   */
  selectDefaultWriteOffTransactionCode(option: string) {
    this.clickDropdownInPostingOptions(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[0]
    );
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DROPDOWN_COMPONENT[1]
    ).then(($body) => {
      if (
        $body.find(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DROPDOWN_COMPONENT_INPUT_FIELD[1]
        ).length
      ) {
        cy.cType(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DROPDOWN_COMPONENT_INPUT_FIELD[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .DROPDOWN_COMPONENT_INPUT_FIELD[0],
          option
        );
        const interceptCollection =
          this.enterpriseConfigurationApi.interceptWriteOffDropDownApi();
        cy.cIntercept(interceptCollection);
        cy.cClick(
          CommonUtils.concatenate(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
              .POSTING_OPTIONS.POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
            ' ',
            selectorFactory.getSpanText(option)
          ),
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .POSTING_OPTIONS_DROPDOWN_WRAPPER[0]
        );
        cy.cWaitApis(interceptCollection);
      } else {
        const interceptCollection =
          this.enterpriseConfigurationApi.interceptWriteOffDropDownApi();
        cy.cIntercept(interceptCollection);
        cy.cClick(
          CommonUtils.concatenate(
            OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
              .POSTING_OPTIONS.POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
            ' ',
            selectorFactory.getSpanText(option)
          ),
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .POSTING_OPTIONS_DROPDOWN_WRAPPER[0]
        );
        cy.cWaitApis(interceptCollection);
      }
    });
  }

  /**
   * @details - To verify the procedure details under Review/Edit for a specific procedure tab in contracts screen.
   * @param procedureDetails - procedure details values to be verified should be passed.
   */
  verifyProcedureDetailsUnderReviewEdit(
    procedureDetails: ProcedureDetailsInReviewEdit
  ) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .SEARCH_PROCEDURE_IN_CONTRACTS[1]
    )
      .focus()
      .click({ force: true })
      .then(() => {
        const interceptCollection =
          this.enterpriseConfigurationApi.interceptSelectTabHeadingInContractsApi();
        cy.cIntercept(interceptCollection);
        cy.cType(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .SEARCH_PROCEDURE_IN_CONTRACTS[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .SEARCH_PROCEDURE_IN_CONTRACTS[0],
          procedureDetails.CptHcpsc
        );
        cy.cWaitApis(interceptCollection);
      });
    let i: number;
    procedureDetails.ImportedAmt !== undefined ? (i = 1) : (i = 0);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .ROW_WITH_IN_PROCEDURE_TABLE[1]
    )
      .eq(0)
      .within(() => {
        cy.cIncludeText(
          selectorFactory.getDivText(procedureDetails.CptHcpsc),
          ' ',
          procedureDetails.CptHcpsc
        );
      });

    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .ROW_WITH_IN_PROCEDURE_TABLE[1]
    )
      .eq(1)
      .within(() => {
        cy.cIncludeText(
          selectorFactory.getDivText(procedureDetails.StandardFee),
          ' ',
          procedureDetails.StandardFee
        );
      });

    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .ROW_WITH_IN_PROCEDURE_TABLE[1]
    )
      .eq(2)
      .within(() => {
        cy.cIncludeText(
          selectorFactory.getDivText(procedureDetails.Type),
          ' ',
          procedureDetails.Type
        );
      });

    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .ROW_WITH_IN_PROCEDURE_TABLE[1]
    )
      .eq(3)
      .within(() => {
        let option: string;
        i === 0
          ? (option = procedureDetails.Details!)
          : (option = procedureDetails.ImportedAmt!);
        cy.cIncludeText(selectorFactory.getDivText(option), '', option);
      });

    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .ROW_WITH_IN_PROCEDURE_TABLE[1]
    )
      .eq(4)
      .within(() => {
        let option: string;
        i === 0
          ? (option = procedureDetails.AllowedAmount!)
          : (option = procedureDetails.Details!);
        cy.cIncludeText(selectorFactory.getDivText(option), '', option);
      });

    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .ROW_WITH_IN_PROCEDURE_TABLE[1]
    )
      .eq(5)
      .within(() => {
        let option: string;
        i === 0
          ? (option = procedureDetails.Exempt!)
          : (option = procedureDetails.AllowedAmount!);
        cy.cIncludeText(selectorFactory.getDivText(option), ' ', option);
      });
    if (i !== 0) {
      cy.cGet(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
          .ROW_WITH_IN_PROCEDURE_TABLE[1]
      )
        .eq(6)
        .within(() => {
          cy.cIncludeText(
            selectorFactory.getDivText(procedureDetails.Exempt!),
            ' ',
            procedureDetails.Exempt!
          );
        });
    }
  }

  /**
   * @details - To verify the type options under Review/Edit in contracts screen for a particular procedure.
   * @param procedure - Procedure to be selected should be passed.
   * @param reviewTypeOptions - Options to be verified under type options should be passed.
   */
  verifyTypeOptionsInReviewEdit(
    procedure: string,
    reviewTypeOptions: string[]
  ) {
    this.searchProcedureInContracts(procedure);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .REVIEW_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .REVIEW_TYPE[0]
    );
    reviewTypeOptions.forEach(($value) => {
      cy.cIncludeText(
        CommonUtils.concatenate(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText($value)
        ),
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[0],
        $value
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To verify the Exempt options under Review/Edit in contracts screen for a particular procedure.
   * @param procedure - Procedure to be selected should be passed.
   * @param options - Options to be verified under type options should be passed.
   */
  verifyExemptOptionsInReviewEdit(procedure: string, options: string[]) {
    this.searchProcedureInContracts(procedure);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .EXEMPT_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .EXEMPT_TYPE[0]
    );
    options.forEach(($values) => {
      cy.cIncludeText(
        CommonUtils.concatenate(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
            .POSTING_OPTIONS_DROPDOWN_WRAPPER[1],
          ' ',
          selectorFactory.getSpanText($values)
        ),
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .POSTING_OPTIONS_DROPDOWN_WRAPPER[0],
        $values
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - To verify the state (enabled or disabled) of contract type dropdown
   * @param enable - To verify the dropdown is enabled pass true, To verify the dropdown is disabled pass flase.
   */
  verifyStateOfContractType(enable: boolean = true) {
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[0],
      CommonClassAttributes.pdisabled,
      false,
      !enable
    );
  }

  /**
   * @details - To verify the duplicate warning message in contract screen when the contract name is duplicated with existing contract name
   */
  duplicateWarningInContractAddPopup() {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .ADD_DUPLICATE_WARNING[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .ADD_DUPLICATE_WARNING[0],
      AppErrorMessages.duplicate_contracts
    );
    cy.cClick(
      selectorFactory.getButtonSpanText(DoneOrCancel.cancel),
      DoneOrCancel.cancel,
      false,
      true
    );
  }

  /**
   * @details - Clear contract name field in contract screen.
   */
  clearContractName() {
    cy.cClear(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .CONTRACT_NAME_FIELD[1]
    );
  }

  /**
   * @details Enter name in contract name field
   * @param contractInfo Name to be update in contract name field
   */
  enterContractNameField(contractInfo: Contracts) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .CONTRACT_NAME_FIELD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .CONTRACT_NAME_FIELD[0],
      contractInfo.ContractName
    );
  }

  /**
   * @details - To verify the warning banner when contract name is duplicated or empty , and verify the add button,
   *  effective date, expiration date and contract type is disabled.
   * - if Contract model is passed it will verify for the duplicate warning message, if Contract model
   *   is not passed it will verify the warning banner for empty contract name.
   * @param contractInfo - Contract model which contains contract name should be passed.
   */
  verifyWarningBannerByClearingOrDuplicateContractName(
    contractInfo?: Contracts
  ) {
    contractInfo?.ContractName === undefined
      ? this.clearContractName()
      : this.enterContractNameField(contractInfo);
    this.clickOnAddButton();
    contractInfo?.ContractName === undefined
      ? cy.cIncludeText(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .WARNING_BANNER[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .WARNING_BANNER[0],
          AppErrorMessages.disclaimer_contract_warning
        )
      : cy.cIncludeText(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .WARNING_BANNER[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .WARNING_BANNER[0],
          AppErrorMessages.duplicate_contracts
        );
    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0],
      false,
      false
    );

    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EFFECTIVE_DATE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EFFECTIVE_DATE[0],
      false,
      false
    );

    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EXPIRATION_DATE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.EXPIRATION_DATE[0],
      false,
      false
    );
  }

  /**
   * @details - This method used to reduce the complexity in verifyStateOfPercentageOfBilledCharge,
   * verifyStateOfDetailsInputFieldUnderReviewEdit methods , this method is not used in any scenariou file.
   */
  verifyStateOfConfigOption(enabled: boolean, option: any[]) {
    return enabled
      ? cy.cIsEnabled(option[1], option[0])
      : cy.cIsEnabled(option[1], option[0], false, false);
  }

  /**
   * @details - To verify state( enabled or disabled ) of DetailsInput field under Review/Edit tab in contracts.
   * @param enabled - need to pass true to verify the input field is enabled, need to pass false to verify the input field is disabled.
   */
  verifyStateOfPercentageOfBilledCharge(enabled: boolean = true) {
    return this.verifyStateOfConfigOption(
      enabled,
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .PERCENTAGE_OF_ALLOWED
    );
  }

  /**
   * @details - To verify state( enabled or disabled ) of DetailsInput field under Review/Edit tab in contracts
   * @param enabled - need to pass true to verify the input field is enabled, need to pass false to verify the input field is disabled.
   */
  verifyStateOfDetailsInputFieldUnderReviewEdit(enabled: boolean = true) {
    return this.verifyStateOfConfigOption(
      enabled,
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .DETAILS_FOR_BILLING_CHARGE
    );
  }

  /**
   * @details - To verify the state (enabled or disabled) of DefaultWriteOffReason code under Posting options in contracts.
   * @param enabled - need to pass true to verify the dropdown is enabled, need to pass false to verify the dropdown is disabled.
   */
  verifyStateOfDefaultWriteOffReasonCode(enabled: boolean = true) {
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[0],
      CommonClassAttributes.pdisabled,
      false,
      !enabled
    );
  }

  /**
   * @details - To verify the state (enabled or disabled) of DefaultWriteOffTransaction code under Posting options in contracts.
   * @param enabled - need to pass true to verify the dropdown is enabled, need to pass false to verify the dropdown is disabled.
   */
  verifyStateOfDefaultWriteOffTransactionCode(enabled: boolean = true) {
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[0],
      CommonClassAttributes.pdisabled,
      false,
      !enabled
    );
  }

  /**
   * @details - To verify the state (enabled or disabled) of DefaultWriteOffGroup code under Posting options in contracts.
   * @param enabled - need to pass true to verify the dropdown is enabled, need to pass false to verify the dropdown is disabled.
   */
  verifyStateOfDefaultWriteOffGroupCode(enabled: boolean = true) {
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[0],
      CommonClassAttributes.pdisabled,
      false,
      !enabled
    );
  }

  /**
   * @details - To verify the state (disabled or enabled )of the type dropdown for the procedures under Review/Edit tab.
   * @param enable - need to pass true to verify the type is enabled, need to pass false to verify the type is disabled.
   */
  verifyStateOfTypeUnderReviewEdit(enable: boolean = true) {
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .REVIEW_TYPE_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .REVIEW_TYPE_INPUT[0],
      CommonClassAttributes.pdisabled,
      false,
      !enable
    );
  }

  /**
   * @details - To verify the state (disabled or enabled )of the details dropdown for the procedures under Review/Edit tab.
   * @param enabled - need to pass true to verify the details is enabled, need to pass false to verify the details is disabled.
   */
  verifyStateOfDetailsDropdownUnderReviewEdit(enabled: boolean = true) {
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .DETAILS_FOR_GROUPER_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .DETAILS_FOR_GROUPER_TYPE[0],
      CommonClassAttributes.pdisabled,
      false,
      !enabled
    );
  }

  /**
   * @details - To verify the state (disabled or enabled )of the exempt dropdown for the procedures under Review/Edit tab.
   * @param enable - need to pass true to verify the exempt is enabled, need to pass false to verify the exempt is disabled.
   */
  verifyStateOfExemptUnderReviewEdit(enable: boolean = true) {
    cy.cHasClass(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .EXEMPT_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .EXEMPT_TYPE[0],
      CommonClassAttributes.pdisabled,
      false,
      !enable
    );
  }

  /**
   * @details - To verify the default selected Contract in createCopy pop up under contracts.
   * @param defaultContractOption - contract to be verified should be passed as defaultContractOption.
   */
  verifyDefaultSelectedContractOptionUnderCreateCopy(
    defaultContractOption: string
  ) {
    cy.cHasText(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
          .SELECT_ITEM_DROPDOWN[1],
        ' ',
        selectorFactory.getSpanText(defaultContractOption)
      ),
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .SELECT_ITEM_DROPDOWN[0],
      defaultContractOption
    );
  }

  /**
   * @details - To verify the text, in the input field in createCopy pop up, in contracts, after clicking add button.
   * @param contractName - contractName to be verified should be passed.
   */
  verifyTextFieldUnderCreateCopy(contractName: string) {
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[0],
      contractName
    );
  }

  /**
   * @details - To edit the Text field in createCopy pop up in contacts , after clicking add button in contracts.
   * @param contractName - Contract name to be entered should be passed.
   */
  editTextFieldUnderCreateCopy(contractName: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_CONTRACT[0],
      contractName
    );
  }

  /**
   * @details - To verify the whether the contract type under contracts.
   * @param ContractType - Type of contract should be passed.
   */
  verifyContractType(ContractType: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CONTRACT_TYPE[0],
      ContractType
    );
  }

  /**
   * @details - To add the Reimbursement to the specified group for contacts under Posting options tab.
   * @param index - To which group the reimbursement to be added should be passed as index.
   * @param num - The Reimbursement value to be entered should be passed as num.
   */
  enterReimbursement(feeGroup: AddFeeGroup) {
    cy.cGet(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
          .FEE_GROUPS.ROW_WITH_IN_FEE_GROUP[1],
        ' ',
        selectorFactory.getSpanText(feeGroup.Index)
      )
    )
      .parents(CommonGetLocators.tr)
      .within(() => {
        cy.cGet(CommonGetLocators.td)
          .eq(1)
          .click()
          .clear()
          .type(feeGroup.Reimbursement);
      });
  }

  /**
   * @details - To clear the Configuration search field in transaction codes, contracts, fee schedule, Dictionaries, Discounts under Enterprise Build.
   */
  clearConfigurationSearch() {
    cy.cClear(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[1]
    );
  }

  /**
   * @details - To select the index value from details dropdown for contract type as grouper under ReviewEdit.
   * @param index - option to be selected should be passed.
   */
  selectDetailsInReviewEdit(index: string) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .DETAILS_FOR_GROUPER_TYPE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.REVIEW_EDIT
        .DETAILS_FOR_GROUPER_TYPE[0]
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .FEE_GROUPS.SEARCH[0],
      index
    );
    cy.cClick(selectorFactory.getOptionInFeeGroupDropdown(index), '');
  }

  /**
   * @details - To clear the search procedure filed in Review/Edit tab in contract screen.
   */
  clearProcedureSearchInContract() {
    cy.cClear(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
        .SEARCH_PROCEDURE_IN_CONTRACTS[1]
    );
  }

  /**
   * @details - To create a copy contract, based on the required contract
   * @param contractInfo - contractInfo is the contract name which has to be selected
   * @param CopyContractName - CopyContractName is passed to verify the name which is present in input field of copyContract pop up
   */
  addCopyContract(contractInfo: Contracts, CopyContractName: string) {
    this.searchAndSelectContract(contractInfo);
    this.selectConfigurationFirstTemplate();
    this.clickOnAddButton();
    this.clickOnAddNewOrCreateCopy(AddNewOrCreateCopy.CreateCopy);
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CREATE_COPY_DD[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.CREATE_COPY_DD[0],
      contractInfo.ContractName
    );
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.NOTE_ICON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.NOTE_ICON[0]
    );
    cy.cHasValue(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.ADD_NAME[0],
      CopyContractName
    );
    this.clickOnDoneOrCancelInAddContractPopUp(DoneOrCancel.done);
  }

  /**
   * @details - To verify the selected adjustment time in adjustment time dropdown under Posting options
   * @param value - option to be verified should be passed
   */
  verifySelectedAdjustmentTimeInContracts(value: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .ADJUSTMENT_TIME[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .ADJUSTMENT_TIME[0],
      value
    );
  }

  /**
   * @details - To verify the selected Transaction code in default_writeoff_transaction_code dropdown under Posting options
   * @param value - option to be verified should be passed
   */
  verifySelectedTransactionCodeInContracts(value: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[0],
      value
    );
  }

  /**
   * @details - To verify the selected group code in default_writeoff_group_code dropdown under Posting options
   * @param value - option to be verified should be passed
   */
  verifySelectedGroupCodeInContracts(value: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[0],
      value
    );
  }

  /**
   * @details - To verify the selected Reason code in default_writeoff _reason_code dropdown under Posting options
   * @param value - option to be verified should be passed
   */
  verifySelectedReasonCodeInContracts(value: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[0],
      value
    );
  }

  addFeeSchedule(feeSchedule: FeeSchedule) {
    this.addProcedure(feeSchedule.CptProcedure!);
    this.enterAmount(feeSchedule.Amount!);
    this.selectStatusValue(feeSchedule.StatusDropDownValue!);
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptUpdateProcedureDetailsApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.TYPE_OF_BILL[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.reload();
    this.clickOnAddInFeeSchedule();
    this.clickDoneOrCancel(DoneOrCancel.cancel);
  }

  clickDoneOrCancel(option: DoneOrCancel) {
    option === DoneOrCancel.done
      ? sisOfficeDesktop.clickDoneButton()
      : cy.cClick(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .CANCEL_BUTTON[1],
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .CANCEL_BUTTON[0]
        );
  }

  /**
   * @details To select the facility in Add On Features
   * @param facilityName as string reference in the function
   * @API - API's are available - Implemented Completely
   */
  selectFacilityInAddOnFeatures(facilityName: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptSelectFacilityInAddOnFeaturesApi();
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FACILITY_SEARCH[1],
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FACILITY_SEARCH[0],
      facilityName
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getDivTitle(facilityName), facilityName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To Enable or Disable the Feature Name under Add On Features in Enterprise Build
   * @param featureName - The Feature Name to be enabled or disabled should be passed
   * @param state - enable or disable state should be passed
   * @author - Rakesh Donakonda
   */
  selectEnableOrDisableFeatureName(featureName: string, state: string) {
    state == EnableOrDisable.enable ? (state = Enable) : (state = Disable);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.SYSTEM_SETTINGS.FEATURE_NAME_SEARCH_FILTER[1],
      ' ',
      featureName
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.SYSTEM_SETTINGS
          .FIRST_ROW_UNDER_ADD_ON_FEATURE_FILTER[1],
        ' ',
        '[',
        InvokeAttributes.aria_label,
        '="',
        state,
        '"]'
      ),
      ' '
    );
    cy.reload();
  }

  /**
   * @details - verifying the status of the Shared Dictionaries/ConfigurationsState in Enterprise
   * @param  - status - value will pass are true or false
   * @API - API's are not available
   */
  verifySharedDictionariesConfigurationsState(status: string) {
    cy.cGet(selectorFactory.toggleSwitchInInternalTab(ShowOrHide.show))
      .parent()
      .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
      .should(ShouldMethods.include, status);
  }

  /**
   * @details - verify the MFA header in security of enterprise
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyMFAHeader() {
    cy.cIncludeText(
      CoreCssClasses.Text.loc_label_text,
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_HEADER[0],
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_HEADER[0]
    );
  }

  /**
   * @details - verify the Enable flag of MFA button in security of enterprise
   * @param - value - sending the value for the  mfa button to verify
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyMFAbutton(value: string) {
    const buttonConfig =
      value === EnableOrDisable.enable
        ? OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_DISABLE_BUTTON
        : OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_DISABLE_BUTTON;

    cy.cHasAttribute(
      buttonConfig[1],
      buttonConfig[0],
      InvokeAttributes.class,
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_HIGHLIGHT[1]
    );
  }

  /**
   * @details - Enter email in User details tab of enterprise
   * @param - emailId - Email should be enter in  user details tab(Testuser@sisfirst.com)
   * @API - API's are not available
   * @author - Jayasree
   */
  enterEmailInUserDetailsTab(emailId: string) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[1],
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[0]
    );
    cy.cGet(OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[1])
      .click()
      .type(CommonTypeValues.select_all)
      .type(CommonTypeValues.back_space);
    cy.cClear(OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[1]);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[1],
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[0]
    ).dblclick();
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[1],
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_EMAIL[0],
      emailId
    );
  }

  /**
   * @details - Verify Invalid Text in Tooltip For Email
   * @param - errorMessage - message that needs to be verified(invalid text)
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyInvalidTextInTooltip(errorMessage: string) {
    cy.cIsVisible(selectorFactory.getSpanText(errorMessage), errorMessage);
  }

  /**
   * @details -Click on Ok in Tooltip
   * @API - API's are not available
   * @author - Jayasree
   */
  clickOnOk() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CLICK_ON_OK.CLICK_ON_OK_IN_TOOLTIP[1],
      OR_ENTERPRISE_CONFIGURATION.CLICK_ON_OK.CLICK_ON_OK_IN_TOOLTIP[0]
    );
  }

  /**
   * @details -Click on Create copy user in user popup of enterprise
   * @API - API's are available - Implemented Completely
   * @author - Jayasree
   */
  clickCreateCopyUser() {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptClickCreateCopyUserApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CLICK_CREATE_COPY_USER.CREATE_COPY_USER[1],
      OR_ENTERPRISE_CONFIGURATION.CLICK_CREATE_COPY_USER.CREATE_COPY_USER[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verify the un presence of MFA and SSO header in security of enterprise
   * @param isVisible - sending to  enable or disable  for the  mfa header to verify
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyMFASSOHeader(isVisible: boolean = false) {
    const headerText = OR_ENTERPRISE_CONFIGURATION.SECURITY.MFASSO_HEADER[0];
    const headerSelector = selectorFactory.getH4Text(headerText);

    isVisible
      ? cy.cIsVisible(headerSelector, headerText)
      : cy.cNotExist(headerSelector, headerText);
  }

  /**
   * @details - verify the MFA header in security of enterprise
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyBypassingMFAHeader() {
    cy.cIncludeText(
      CoreCssClasses.Text.loc_label_text,
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_BYPASSING_HEADER[0],
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_BYPASSING_HEADER[0]
    );
  }

  /**
   * @details - verify the flag of Bypassing MFA button in security of enterprise
   * @param - value - sending the value for the Bypassing MFA button to verify
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyBypassingMFAbutton(value: string) {
    const buttonConfig =
      value === YesOrNo.yes
        ? OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_BYPASSING_YES_BUTTON
        : OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_BYPASSING_NO_BUTTON;

    cy.cHasAttribute(
      buttonConfig[1],
      buttonConfig[0],
      InvokeAttributes.class,
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_HIGHLIGHT[1]
    );
  }

  /**
   * @details - click the flag of Bypassing MFA button in security of enterprise
   * @param - value - sending the value for the Bypassing MFA button to select
   * @param - isSelectionBasedOnBackgroundColor - sending boolean value to verify based on background color
   * @flag - value - true or false - true means MFA button and false means MFA Bypassing button
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  clickMFAAndBypassingMFAbutton(
    value: string,
    isSelectionBasedOnBackgroundColor: boolean = false,
    flag: boolean
  ) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptClickMfaButtonApi();
    let buttonConfig: string[];
    if (flag) {
      buttonConfig =
        value === EnableOrDisable.enable
          ? OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_ENABLE_BUTTON
          : OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_DISABLE_BUTTON;
    } else {
      buttonConfig =
        value === YesOrNo.yes
          ? OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_BYPASSING_YES_BUTTON
          : OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_BYPASSING_NO_BUTTON;
    }

    if (isSelectionBasedOnBackgroundColor) {
      cy.cGet(buttonConfig[1]).should('not.have.class');

      cy.cGet(buttonConfig[1]).then(($body) => {
        if (!$body.hasClass(CoreCssClasses.Panel.loc_p_highlight)) {
          cy.cClickAndWaitApis(buttonConfig[1], interceptCollection);
        }
      });
    } else {
      cy.cClickAndWaitApis(buttonConfig[1], interceptCollection);
    }
  }

  /**
   * @details - verify the IP Range header in security of enterprise
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyIPRangeHeader() {
    cy.cIncludeText(
      CoreCssClasses.Text.loc_label_text,
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_RANGE_HEADER[0],
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_RANGE_HEADER[0]
    );
  }

  /**
   * @details - verify IP range TextBox in security of enterprise
   * @param  - isEnabled - sending to true or false to verify the text box state
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyIPRangeTextBox(isEnabled: boolean = true) {
    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_RANGE_TEXT_BOX[0],
      false,
      isEnabled
    );
  }

  /**
   * @details - Creating user in users popup of enterprise
   * @param - createUserDetails - First name , Last name should be enter in new user popup(First name:Test , LastName:Last name:User)
   * @API - API's are not available
   * @author - Jayasree
   */
  createUser(createUserDetails: UserDetails) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.FIRST_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.FIRST_NAME[0],
      createUserDetails.FirstName
    );
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.LAST_NAME[1],
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.LAST_NAME[0],
      createUserDetails.LastName
    );
  }

  /**
   * @details -Enter Email in Add user popup
   * @param  - createUserDetails - Email should be enter in create user details tab(Testuser12@sisfirst.com)
   * @API - API's are not available
   * @author - Jayasree
   */
  enterEmail(createUserDetails: UserDetails) {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[1],
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[0]
    );
    cy.cGet(OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[1])
      .click()
      .type(CommonTypeValues.select_all)
      .type(CommonTypeValues.back_space);
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[1],
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[0]
    ).dblclick();
    cy.cClear(OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[1]);
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[1],
      OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.EMAIL[0],
      createUserDetails.EMail
    );
  }

  /**
   * @details - verify the email in user popup
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyEmail() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.USERS_TAB.VALIDATE_EMAIL[1],
      OR_ENTERPRISE_CONFIGURATION.USERS_TAB.VALIDATE_EMAIL[0]
    );
  }

  /**
   * @details -verifying Email is mandatory field in User details tab
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyEmailAsterisk() {
    cy.cIsVisible(
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.EMAIL_ASTERISK[1],
      OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.EMAIL_ASTERISK[0]
    );
  }

  /**
   * @details -click on Add button in the configuration item
   * @API - API's are not available
   * @author - Jayasree
   */
  clickAddButton() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.ADD_BUTTON[0]
    );
  }

  /**
   * @details - verify the password warning after the MFA enable
   * @param - passwordWarning - message that needs to be verified(password warning text)
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyPasswordWarning(passwordWarning: string) {
    cy.cIncludeText(
      CoreCssClasses.Text.loc_label_text,
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_HEADER[0],
      passwordWarning
    );
  }

  /**
   * @details -click on cancel button in user popup of enterprise
   * @API - API's are not available
   * @author - Jayasree
   */
  clickCancelButton() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
        .CANCEL_BUTTON[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE.CANCEL_BUTTON[0]
    );
  }

  /**
   * @details - type on password strength of minimum length field
   * @param - minLen -  minimum length password should be 7
   * @API - API's are not available
   * @author - Vamshi
   */
  minimumLength(minLen: Number) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MINIMUM_LENGTH[1],
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MINIMUM_LENGTH[0],
      minLen
    );
  }

  /**
   * @details - verify the toolTip message of the Bypassing MFA icon
   * @API - API's are not available
   * @author - Vamshi
   */
  toolTipBypassingMFA() {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.SECURITY.MFA_BYPASSING_TOOL_TIP[1]
    ).should(
      InvokeMethods.attribute,
      InvokeAttributes.p_tool_tip,
      AppErrorMessages.security_mfa_tooltip
    );
  }

  /**
   * @details - Click on the add icon in the IP range
   * @API - API's are not available
   * @author - Vamshi
   */
  addIcon() {
    cy.cClick(
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_RANGE_TEXT_BOX[1],
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_RANGE_TEXT_BOX[0]
    );
  }

  /**
   * @details - Enter value IP range in the IP Form field
   * @param -  ipFrom - entering Data in ip ranges in IPFrom field(19.25.35.45)
   * @param - rowNo - entering Data in ip ranges in rowNo field(19.25.35.45)
   * @API - API's are not available
   * @author - Vamshi
   */
  enterIpFrom(ipFrom: string, rowNo: string) {
    cy.cType(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_FROM[1],
        rowNo
      ),
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_FROM[0],
      ipFrom
    );
  }

  /**
   * @details - enter value on IP to in the IP range
   * @param - ipTo - entering data in ip ranges in IPTO field(19.25.35.45)
   * @param - rowNo - it used to determine, to which row for entering the data
   * @API - API's are not available
   * @author - Vamshi
   */
  enterIpTo(ipTo: String, rowNo: string) {
    cy.cType(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_TO[1],
        rowNo
      ),
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_TO[0],
      ipTo
    );
  }

  /**
   * @details - click on IP from in the IP range field
   * @param - rowNo -ip from Field next row should be click
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  clickIpFromTo(rowNo: string, mfaip: MFAIP) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptClickIpFromToApi();
    const button =
      mfaip == MFAIP.IpFrom
        ? CommonUtils.concatenate(
            OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_FROM_DATA[1],
            rowNo,
            OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_DATA_END[1]
          )
        : CommonUtils.concatenate(
            OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_TO_DATA[1],
            rowNo,
            OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_DATA_END[1]
          );
    cy.cClickAndWaitApis(button, interceptCollection);
  }

  /**
   * @details - Verify the Ip from warning message
   * @param - errorMessage - message that needs to be verified(Invalid)
   * @API - API's are not available
   * @author - Vamshi
   */
  verifyIpFromToWarning(errorMessage: string) {
    cy.cIncludeText(
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_FROM_TO_WARNING[1],
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_FROM_TO_WARNING[0],
      errorMessage
    );
  }

  /**
   * @details - click on IP from and to delete icon in the IP range
   * @param - rowNo - IP from should be click and delete
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  clickIpFromToDelete(rowNo: string) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptClickIpFromToApi();
    cy.cGet(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_FROM_TO_DELETE[1],
        rowNo
      )
    )
      .invoke(
        InvokeMethods.css,
        InvokeAttributes.visibility,
        CommonClassAttributes.visible
      )
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible);
    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_FROM_TO_DELETE[1],
        rowNo
      ),
      OR_ENTERPRISE_CONFIGURATION.SECURITY.IP_TO[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify Invalid Email For Email
   * @param -  errorMessage - message that needs to be verified(Invalid)
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyInvalidEmail(errorMessage: string) {
    cy.cIsVisible(selectorFactory.getSpanText(errorMessage), errorMessage);
  }

  /**
   * @details - verify the change password button is disabled
   * @param - isDisabled - sending to  enable or disable to verify change password is disabled
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyChangePassword(isDisabled: boolean = false) {
    cy.cIsEnabled(
      OR_ENTERPRISE_CONFIGURATION.CHANGE_PASSWORD.ENTERPRISE_DISABLE[1],
      OR_ENTERPRISE_CONFIGURATION.CHANGE_PASSWORD.ENTERPRISE_DISABLE[0],
      false,
      isDisabled
    );
  }

  /**
   * @details - click on delete icon of the user
   * @API - API's are not available
   * @author - Vamshi
   */
  clickUserToDelete() {
    cy.cGet(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.DELETE[1]
      )
    )
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible)
      .click();
  }

  /**
   * @details Click on the Active Toggle for the User
   * @param -  value - Activate user inactive to active(EX:Gem_user1)
   * @API - API's are not available
   * @author - Vamshi
   */
  clickActiveToggle(value: string) {
    let selector: string = '';

    if (
      value == OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.ACTIVE_YES[0]
    ) {
      selector = OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.ACTIVE_YES[1];
    } else {
      selector = OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.ACTIVE_NO[1];
    }
    cy.cClick(selector, value);
  }

  /**
   * @details - click on Inactive toggle of the delete user
   * @API - API's are not available
   * @author - Vamshi
   */
  clickUserToInactive() {
    cy.cGet(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.CREATE_USER_DETAILS.DELETE[1]
      )
    )
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.visible)
      .click();
  }

  /**
   * @details - search Configuration Item in users of enterprise
   * @param - value - Search for user in search box(Gem_user3)
   * @API - API's are not available
   * @author - Jayasree
   */
  searchConfigurationItem(value: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[1],
      OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.COMMON.SEARCH_INPUT[0],
      value
    );
  }

  /**
   * @details - verify the username in user search
   * @param - createUserDetails - verifying user FirstName in search list
   * @API - API's are not available
   * @author - Jayasree
   */
  verifyUser(createUserDetails: UserDetails) {
    cy.cIsVisible(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.USERS_TAB.USER_DATA[1],
        selectorFactory.getDivText(createUserDetails.FirstName ?? '')
      ),
      createUserDetails.FirstName ?? ''
    );
  }

  /**
   * @details - select user name in  configuration list
   * @param - value - user able to select user name in configuration item
   * @API - API's are not available
   * @author - Jayasree
   */
  selectUserName(value: string) {
    cy.cClick(
      CommonUtils.concatenate(
        OR_ENTERPRISE_CONFIGURATION.USERS_TAB.USER_DATA[1],
        selectorFactory.getDivText(value)
      ),
      value
    );
  }

  /**
   * @details - To select login location from Change Login Location Popup In Enterprise*
   * @param - loginLocation - user select login location from Enterprise side
   * @API - API's are not available
   * @author - Jayasree
   */
  selectFacilityInChangeLoginLocation(loginLocation: string) {
    cy.cGet(selectorFactory.getSpanText(loginLocation)).first().click();
  }

  /**
   * @details - To click on Done or Cancel button in add contract pop up when Create Copy is selected
   * @param button - Done or Cancel should be passed using DoneOrCancel
   * @API - API's are available - Implemented Completely
   * @author - Rakesh Donakonda
   */
  clickDoneOrCancelInAddContractPopUp(button: DoneOrCancel) {
    const interceptCollection =
      this.enterpriseConfigurationApi.interceptClickDoneOrCancelInAddContractPopUp();
    const buttonSelector =
      button === DoneOrCancel.done
        ? OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON
        : OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .CANCEL_BUTTON;

    if (button === DoneOrCancel.done) {
      cy.cIntercept(interceptCollection);
      cy.cClick(buttonSelector[1], buttonSelector[0]);
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cClick(buttonSelector[1], buttonSelector[0]);
    }
  }

  /**
   * @details To Select the Send Inventory to tracker upon discharge feature in Feature tab
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectSendInventoryDischargeFeature() {
    cy.cGet(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
        .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.SUB_HEADER[1]
    ).within(() => {
      cy.cIsVisible(
        OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
          .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.ENABLE[1],
        OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
          .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.ENABLE[0]
      );
      this.verifyAndClickEnableBtn(
        OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
          .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.ENABLE[1],
        OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
          .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.ENABLE[1]
      );
    });
    this.verifyTooltipTextForFeature(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
        .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.SUB_HEADER[0],
      InfoText.send_inventory_to_tracker_upon_discharge
    );
  }

  /**
   * @details To Verify Tooltip Text for feature in Feature tab
   * @param featureName - Pass Feature Name available in Feature Tab
   * @param toolTipText - Pass Tooltip Text to Verify
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyTooltipTextForFeature(featureName: string, toolTipText: string) {
    const featureToolTip =
      featureName ===
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
        .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.SUB_HEADER[0]
        ? OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES
            .SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE.INFO_ICON[1]
        : '';

    cy.cGet(featureToolTip)
      .should(ShouldMethods.visible)
      .trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .then((tooltipValue) => {
        const textValue = tooltipValue.text().replace('\t', '');
        expect(textValue).to.contains(toolTipText);
      });
    cy.cGet(featureToolTip).trigger(TriggerAttributes.mouseleave);
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      CoreCssClasses.ToolTipText.loc_p_tooltip_text
    );
  }

  /**
   * @details To click on Feature tab after selecting the desired facility
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clickOnFeaturesTab() {
    cy.cClick(
      selectorFactory.getAText(
        OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES.FEATURES_TAB[0]
      ),
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.FEATURES.FEATURES_TAB[0],
      false,
      true
    );
  }

  /**
   * @details To click on Enable Button for the Desired Feature
   * @param selector - passing feature locator
   * @param selectorLogicalName - passing logical name
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyAndClickEnableBtn(selector: string, selectorLogicalName: string) {
    cy.cGet(selector)
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .then(($background) => {
        const hex = String(color($background.toString()).hex()).toUpperCase();

        if (
          hex ==
          AppColors.component_enabled_toggle_button_not_selected.toUpperCase()
        ) {
          cy.cClick(selector, selectorLogicalName);
        } else if (hex == null || hex === undefined) {
          throw new Error(
            'Background color for Send Inventory to tracker upon discharge is either null or undefined'
          );
        }
      });
  }

  /**
   * @detail To verify feature name in add on feature
   * @param name - verify feature name in add on feature
   * @API - API's are not available
   * @author - Divya
   */
  verifyFeatureNameInAddOnFeature(name: string) {
    cy.cType(
      OR_ENTERPRISE_CONFIGURATION.ADD_ON_FEATURES.FEATURE_NAME_SEARCH_INPUT[1],
      ' ',
      name
    );
    cy.cHasLength(
      CommonUtils.concatenate(
        CommonGetLocators.tbody,
        ' ',
        CommonGetLocators.tr
      ),
      '',
      1
    );
    cy.contains(name).cIsVisible(selectorFactory.getLabelText(name), '');

    cy.cIsVisible(
      selectorFactory.getSpanText(EnableOrDisable.enable),
      EnableOrDisable.enable
    );
    cy.cIsVisible(
      selectorFactory.getSpanText(EnableOrDisable.disable),
      EnableOrDisable.disable
    );
  }

  /**
   * @detail To select enable disable toggle
   * @param enableDisable - To select enable or disable toggle
   * @API - API's are not available
   * @author - Divya
   */
  selectEnableDisableToggle(enableDisable: string = EnableOrDisable.enable) {
    cy.cGet(selectorFactory.getAriaLabel(enableDisable))
      .invoke(InvokeMethods.attribute, InvokeAttributes.ariaPressed)
      .then(($value) => {
        if ($value == TrueOrFalse.false) {
          cy.cClick(selectorFactory.getSpanText(enableDisable), enableDisable);
        }
      });
  }

  /**
   * @details click on done button in add user
   * @API - Apis's are available,Not implemented
   * @author - Jayasree
   */
  clickOnUserDoneButton() {
    const interceptAddUserDoneButtonApiCollection =
      this.enterpriseConfigurationApi.newUserDoneApi();
    cy.cIntercept(interceptAddUserDoneButtonApiCollection);
    sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptAddUserDoneButtonApiCollection);
  }

  /**
   * @details Mapping CBO entity to the user
   * @param cbo CBOManagement model to be provided
   * @API - API's are available - Implemented
   * @author - Nikitan
   */
  mapCBOEntities(cbo: CBODetails) {
    const interceptCollection =
      this.enterpriseConfigurationApi.selectCboEntity();

    cbo.CBOEntity.forEach((val) => {
      cy.cClick(
        OR_ENTERPRISE_CONFIGURATION.USERS.CBO_DETAILS_ADD_ICON[1],
        OR_ENTERPRISE_CONFIGURATION.USERS.CBO_DETAILS_ADD_ICON[0]
      );
      cy.cGet(OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_ENTITY_DROPDOWN[1])
        .last()
        .click();
      cy.cRemoveMaskWrapper(Application.office);
      cy.cIntercept(interceptCollection);
      cy.cClick(selectorFactory.getSpanText(val), val);
      cy.cWaitApis(interceptCollection);
    });
  }
}
