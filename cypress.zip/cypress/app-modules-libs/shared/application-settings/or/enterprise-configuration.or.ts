import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_ENTERPRISE_CONFIGURATION = {
  ENTERPRISE_CONFIGURATION: {
    ENTERPRISE_CONFIGURATION_HEADER: [
      'Enterprise Configuration',
      `#div[class*='desktop-header']`,
    ],
    ENTERPRISE_CONFIGURATION_SEARCH: ['Search', '#searchString'],
    PROFILES: ['Profiles'],
  },
  FACILITY_MANAGEMENT: {
    FACILITY_MANAGEMENT_HEADER: ['Facility Management'],
    FACILITY_SEARCH: ['Facility Search', '#txtConsentFilter'],
    FEATURE_CDT_CODE_ENABLE: [
      'CDTCode_Enable',
      `#feature_btn_103 div[aria-label^='Enable']`,
    ],
    FEATURE_CDT_CODE_DISABLE: [
      'CDTCode_Disable',
      `#feature_btn_103 div[aria-label^='Disable']`,
    ],
    FACILITY_DETAILS: [
      'Facility Details Tab',
      'div[class*=facilityDetailsContainer] li a',
    ],
    FEATURES: {
      FEATURES_TAB: ['Features'],
      INFO_ICON: ['Info Icon', CoreCssClasses.Button.loc_fa_info_circle],
      SEND_INVENTORY_TO_TRACKER_UPON_DISCHARGE: {
        SUB_HEADER: [
          'Send Inventory to tracker upon discharge',
          CommonUtils.concatenate(
            CommonGetLocators.div,
            '.row',
            `:contains('Send Inventory to tracker upon discharge')`
          ),
        ],
        DISABLE: [
          'Disable',
          selectorFactory.getFeatureEnableDisableBtn('Disable'),
        ],
        ENABLE: [
          'Enable',
          selectorFactory.getFeatureEnableDisableBtn('Enable'),
        ],
        INFO_ICON: ['Info Icon', `[data-test-id="iconCircle_156"]`],
      },
    },
    INTERNAL: {
      INTERNAL_TAB: ['Internal'],
      CONFIGURATIONS_TAB: ['Configurations'],
      SIS_OFFICE: {
        SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT: [
          'Shared Dictionaries/Configurations',
        ],
        CBO_CENTRALIZED_VIEWS: ['CBO Centralized Views'],
      },
      INTERFACES: {
        OUTBOUND_CCDA: [
          'Outbound CCDA',
          selectorFactory.getLabelText('Outbound CCDA'),
        ],
        TOGGLE: ['Toggle', '#feature_btn_146'],
        DISABLE: ['Disable', '#feature_btn_146 div[aria-label="Disable"]'],
        ENABLE: ['Enable', '#feature_btn_146 div[aria-label="Enable"]'],
      },
      SURGERY_BOARD_TRACKER: {
        HEADER: ['Surgery Board Tracker'],
      },
    },
    DICTIONARIES: {
      DICTIONARIES_TAB: ['Dictionaries'],
      CONFIGURATIONS_TAB: ['Configurations'],
      SIS_OFFICE: {
        SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT: [
          'Shared Dictionaries/Configurations',
        ],
      },
    },
    CONFIGURATION_VIEWS: {
      CONFIGURATION_VIEWS_HEADER: [
        'Configuration Views Header',
        selectorFactory.getSpanText('Configuration Views'),
      ],
      BUILD_SECTION: [
        'Build Section',
        selectorFactory.getThText('Build Section'),
      ],
      INCLUDE_ENTERPRISE_ITEMS: [
        'INCLUDE ENTERPRISE ITEMS',
        CommonUtils.concatenate(
          '#enterpriseConfigViewsTable ',
          selectorFactory.getThText('Include Enterprise Items')
        ),
      ],
      ALLOW_ADD_TO_CONFIGURATION: [
        'ALLOW ADD TO CONFIGURATION',
        selectorFactory.getThText('Allow Add to Configuration'),
      ],
      I_ICON_NEXT_TO_INCLUDE_ENTERPRISE_ITEM: [
        'i icon next to include enterprise item',
        '#enterpriseConfigViewsTable i[data-test-id="inEntItemsHelpText"]',
      ],
      I_ICON_NEXT_TO_ALLOW_ADD_TO_CONFIGURATION: [
        'i icon next to allow add to configuration',
        '#enterpriseConfigViewsTable i[data-test-id="alloAddDicHelpText"]',
      ],
      INCLUDE_ENTERPRISE_ITEMS_TOGGLE: [
        'Include enterprise items toggle',
        '~td sis-select-button[name="includeEnterItems"] [aria-pressed="false"] ',
      ],
      ALLOW_ADD_TO_CONFIGURATION_TOGGLE: [
        'Allow add to configuration toggle',
        '~td sis-select-button[id="allowAddToEnterpriseConfig"] .p-highlight[aria-label="Yes"]',
      ],
      SHARED_DICTIONARIES_CONFIGURATIONS: [
        'Shared Dictionaries/Configurations',
      ],
      CONFIGURATION_LISTS: [
        'Configuration Name',
        '#enterpriseConfigViewsTable p-table tr',
      ],
      INCLUDE_ENTERPRISE_ITEMS_WITHIN_ROW: [
        'toggle with in row',
        '#includeEnterItems',
      ],
      ALLOW_ADD_TO_ENTERPRISE_WITH_IN_ROW: [
        'toggle with in row',
        '#allowAddToEnterpriseConfig',
      ],
    },
    DICTIONARY_VIEWS: {
      DICTIONARIES_VIEWS_HEADER: [
        'Dictionary Views',
        selectorFactory.getSpanText('Dictionary Views'),
      ],
      DICTIONARY: [
        'Dictionary',
        CommonUtils.concatenate(
          selectorFactory.getThText('Dictionary'),
          ':nth-child(1)'
        ),
      ],
      INCLUDE_ENTERPRISE_ITEMS: [
        'Include Enterprise Items',
        CommonUtils.concatenate(
          '#dictionaryViewsTable ',
          selectorFactory.getThText('Include Enterprise Items')
        ),
      ],
      ALLOW_ADD_TO_DICTIONARY: [
        'Allow Add To Dictionary',
        selectorFactory.getThText('Allow Add to Dictionary'),
      ],
      I_ICON_NEXT_TO_INCLUDE_ENTERPRISE_ITEM: [
        'i icon next to include enterprise items',
        '#dictionaryViewsTable i[data-test-id="inEntItemsHelpText"]',
      ],
      I_ICON_NEXT_TO_ALLOW_ADD_TO_DICTIONARY: [
        'i icon next to allow add to Dictionary',
        '#dictionaryViewsTable i[data-test-id="alloAddDicHelpText"]',
      ],
    },
  },
  ENTERPRISE_BUILD: {
    ENTERPRISE_BUILD_LABEL: ['Enterprise Build'],
    FEE_SCHEDULE: {
      FEE_SCHEDULE_LABEL: [
        'Fee Schedule',
        CommonUtils.concatenate(
          'div[class*="submenu"]',
          selectorFactory.getDivText('Fee Schedule')
        ),
      ],
      ADD_BUTTON: ['Add Button', '#btnAdd'],
      ADD_PROCEDURE_SEARCH: [
        'Add Procedure Search',
        'div[class*="modal-body"] input[role="searchbox"]',
      ],
      ADD_PROCEDURE_TEXT: [
        'Add procedure text',
        selectorFactory.getH3Text('Add Procedure'),
      ],
      SEARCH_FIELD: ['Search field', '#txtConsentFilter'],
      CANCEL_BUTTON: ['Cancel Button', '#btnCancel'],
      PROCEDURE: ['Procedure', '#procedureSearch input'],
      MODIFIED_PROCEDURE_DESCRIPTION: [
        'Modified Procedure Description',
        'div[class*="right-hand-panel ng-star-inserted"] #fsModifiedProcedureDescription',
      ],
      STATUS: ['Status', '#fsStatusDropdown'],
      REVENUE_CODE: ['Revenue Code', '#fsRevenueCodeDropdown'],
      AMOUNT: ['Amount', '#fsAmount input'],
      AMOUNT_LABEL: ['Amount', '#fsAmountLabel'],
      TYPE_OF_BILL: ['Type Of Bill', 'input[id="fsTypeOfBill"]'],
      HISTORY: ['History', '#fsHistoryBtn'],
      PRINT: ['Print', '#fsPrintIcon'],
      PROCEDURE_SEARCH_RESULT: [
        'Search Result',
        '[role="listbox"] li:nth-child(1)',
      ],
      SELECT_ADDED_PROCEDURE: [
        'Select added procedure',
        'p-scrollpanel[id="configDirctscrollPanel"] li',
      ],
      CPT_ITEM_TO_BE_SELECTED: [
        'Cpt item to be selected',
        selectorFactory.getDivText('BLOOD PRESSURE MEASURED'),
      ],
      HCPS_CODE_ITEM_TO_BE_SELECTED: [
        'HCPS item to be selected',
        selectorFactory.getDivText('Ctlso milwauke initial model'),
      ],
      INCLUDE_IN_STATE_REPORT: [
        'Include in state report',
        'div[role="button"][class*="p-highlight"]',
      ],
      SELECT_NO_IN_INCLUDE_STATE_REPORT: [
        'Select no in include state report',
        selectorFactory.getSpanText('No'),
      ],
      DISCLAIMER_TEXT_CPT: ['Disclaimer text CPT', '#fsCptText'],
      DISCLAIMER_TEXT_CDT: ['Disclaimer text CDT', '#fsCdtText'],
      DELETE_PROCEDURE: ['Delete Procedure', '#btnAutoCompleteClear'],
      PROCEDURE_WARNING: ['Procedure Warning', 'span.ellipsis'],
      FEE_SCHEDULE_HISTORY_TEXT: [
        'Fee schedule history',
        selectorFactory.getH3Text('Fee Schedule Amount History'),
      ],
      HISTORY_DONE: ['History Done', '#btnPost'],
      DUPLICATE_CODE: ['Duplicate Code', '#warning_duplicate_feeschedule_name'],
      REVENUE_CODE_SEARCH_INPUT: [
        'Revenue code search input',
        'div[class*="p-dropdown"] input[class*="p-input"] ',
      ],
      SELECT_SEARCHED_REVENUE_CODE: [
        'Select searched revenue code',
        'div[class*="p-dropdown"] ul[role="listbox"] li',
      ],
      TRASH_ICON: ['Trash Icon', ''],
      INACTIVATE_PROCEDURE_POPUP: [
        'Inactivate Procedure',
        'div[class*="dialog"] span[class*="title"]',
      ],
      ABOUT_TO_INACTIVATE: [
        'about to inactivate',
        CommonUtils.concatenate(
          CoreCssClasses.Dialog.loc_confirm_dialog_message,
          ' > :nth-child(1)'
        ),
      ],
    },
    DICTIONARY: {
      DICTIONARY_LABEL: [
        'Dictionaries',
        CommonUtils.concatenate(
          'div[class*="submenu"]',
          selectorFactory.getDivText('Dictionaries')
        ),
      ],
      ENTERPRISE_DICTIONARIES: [
        'Insurance Plan Type',
        selectorFactory.enterpriseDictionaryItems('Insurance Plan Type'),
      ],
      ADD_BUTTON: ['Add Button', '#add_btn'],
      SHOW_INACTIVE_YES: [
        'Yes',
        CommonUtils.concatenate(
          CoreCssClasses.Style.loc_p_highlight,
          ` `,
          selectorFactory.getSpanText('Yes')
        ),
      ],
      SHOW_INACTIVE_NO: [
        'NO',
        CommonUtils.concatenate(
          CoreCssClasses.Style.loc_p_highlight,
          ` `,
          selectorFactory.getSpanText('No')
        ),
      ],
      DICTIONARY_ITEM_NAME: ['Item', '#dictionary_text'],
      OK_BUTTON: ['Ok', '#btnOk'],
      ITEMS_LABEL: ['Total Item', '.total-items label'],
      DUPLICATE_DICTIONARY: [
        'DUPLICATE ITEM',
        CommonUtils.concatenate(
          CoreCssClasses.Dialog.loc_dialog_title,
          ':contains("Duplicate Item")'
        ),
      ],
    },

    TRANSACTION_CODE: {
      TRANSACTION_CODE_LABEL: ['Transaction Codes'],
      SEARCH_INPUT: ['Search', '#txtConsentFilter'],
      ADD_TRANSACTION_CODE_SEARCH: [
        'Add transaction code search',
        '#tcNameNew',
      ],
      TYPE_DROPDOWN: ['Type dropdown', '#tcTypeDropdown'],
      TYPE_DROPDOWN_VALUES: [
        'Type dropdown values',
        CommonUtils.concatenate(
          '[role="listbox"]',
          CoreCssClasses.DropDown.loc_p_dropdown_items
        ),
      ],
      TYPE_DROPDOWNITEM: [
        'Dropdownitem',
        CoreCssClasses.DropDown.loc_p_dropdown_item_tag,
      ],
      TRANSACTION_CODE_NAME: ['Transaction code name', '#tcModifiedName'],
      TRANSACTION_CODE_NAME_LABEL: ['Transaction Code Name', '#tcName'],
      SELECTED_TRANSACTION_TYPE: [
        'Selected Transaction Type',
        '#tcTypeDropdown',
      ],
      WARNING_MESSAGE: [
        'Warning message',
        'div[class*="warning-banner"] span[class*="text"]',
      ],
      ADD_WARNING_MESSAGE: [
        'Add warning message',
        'small[class*="warning-text"]',
      ],
      DELETE_CODE_ICON: ['Delete Transaction code', 'div[class*="trash-icon"]'],
      DELETE_POP_UP_MESSAGE: [
        'Delete error warning',
        'div[class*="error-message"]',
      ],
      DEFAULT_TEXT: [
        'Please select an existing item or create a new item.',
        CommonUtils.concatenate(
          '.default-text',
          CoreCssClasses.Ng.loc_star_inserted
        ),
      ],
      CHECK_MARK: ['Check mark', 'div.check-icon'],
      TRANSACTION_CODE_ITEM: [
        'Transaction Code Item',
        'div[class*="config-selector-list-item-container"] ',
      ],
      DIALOG: ['Dialog', 'span[class*="dialog-message"] span'],
      EXISTING_TRANSACTION_CODES: [
        'existing transaction codes',
        '#configDirctscrollPanel .flex-grow',
      ],
    },
    DISCOUNTS: {
      WRITE_OFF_DROPDOWN_ICON: [
        'Write-Off dropdown icon',
        CommonUtils.concatenate(
          '#source-of-revenue-wgc-dropdown ',
          CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
        ),
      ],
      DISCOUNTS_LABEL: ['Discounts'],
      SUB_HEADER: ['Discounts', 'h4.sor_title'],
      SEARCH_INPUT: ['Search', '#txtConsentFilter'],
      X_MARK: ['Add Button', '#iconSearchInput'],
      OK_BUTTON: ['Ok', '#war_btn'],
      DEFAULT_TEXT: [
        'Default text',
        CommonUtils.concatenate(
          '.default-text',
          CoreCssClasses.Ng.loc_star_inserted
        ),
      ],
      NOTE_ICON: ['Note icon', '.fa.caution-icon.fa-file-text-o'],
      ADD_DISCOUNT_SEARCH_FIELD: ['Add discount search field', '#disc_name'],
      DISCOUNTS_LISTS: [
        'discounts item lists',
        'div[class*="config-selector-list-item-container"]',
      ],
      CHECK_MARK: ['Check mark', 'div.check-icon'],
      ADD_WARNING_MESSAGE: [
        'Add warning message',
        'div[class*="warning-banner"] span[class*="text"]',
      ],
      DUPLICATE_WARNING_MESSAGE: [
        'Duplicate warning message',
        '#warning_duplicate_discount_name',
      ],
      SELECTED_TRANSACTION_DROPDOWN: [
        'Transaction Code Dropdown',
        '#source-of-revenue-tc-dropdown',
      ],
      SELECTED_WRITEOFF_GROUPCODE_DROPDOWN: [
        'Writeoff group code Dropdown',
        '#source-of-revenue-wgc-dropdown',
      ],
      SELECTED_WRITEOFF_REASONCODE_DROPDOWN: [
        'Reason Code Dropdown',
        '#source-of-revenue-wrc-dropdown',
      ],
      DISCOUNT_PERCENT: ['Discount Percent', '#numericInput'],
      DISCOUNT_NAME_FIELD: ['Discount name', '#source-of-revenue-name'],
      TRANSACTION_DROPDOWN_VALUES: [
        'Type dropdown values',
        CommonUtils.concatenate(
          '[role="listbox"]',
          CoreCssClasses.DropDown.loc_p_dropdown_items
        ),
      ],
      GROUPCODE_DROPDOWN_VALUES: [
        'Writeoff Group Code dropdown values',
        CommonUtils.concatenate(
          '[role="listbox"]',
          CoreCssClasses.DropDown.loc_p_dropdown_items
        ),
      ],
      REASONCODE_DROPDOWN_VALUES: [
        'Writeoff Reason dropdown values',
        CommonUtils.concatenate(
          '[role="listbox"]',
          CoreCssClasses.DropDown.loc_p_dropdown_items
        ),
      ],
      DISABLE_TRANSACTION_CODE: [
        'Transaction code',
        CommonUtils.concatenate(
          '#source-of-revenue-tc-dropdown div',
          CoreCssClasses.Style.loc_p_disabled
        ),
      ],
      DISABLE_GROUP_CODE: [
        'Group code',
        CommonUtils.concatenate(
          '#source-of-revenue-wgc-dropdown div',
          CoreCssClasses.Style.loc_p_disabled
        ),
      ],
      DISABLE_REASON_CODE: [
        'Reason code',
        CommonUtils.concatenate(
          '#source-of-revenue-wrc-dropdown div',
          CoreCssClasses.Style.loc_p_disabled
        ),
      ],
      DIALOG: ['Dialog', 'span[class*="dialog-message"]'],
    },
    COMMON: {
      FIRST_OPTION_IN_LIST: [
        'First List Item',
        '.list-group-item:nth-child(1)',
      ],
      SEARCH_INPUT: ['Search', '#txtConsentFilter'],
      ADD_BUTTON: ['Add Button', '#btnAdd'],
      CANCEL_BUTTON: ['Cancel Button', '#btnAddCopyCancel'],
      DONE_BUTTON: ['Done', '#btnAddCopyDone'],
      DEFAULT_TEXT: [
        'Please select an existing item or create a new item.',
        CommonUtils.concatenate(
          '.default-text',
          CoreCssClasses.Ng.loc_star_inserted
        ),
      ],
      CHECK_MARK: [
        'Check mark',
        CommonUtils.concatenate(
          CommonGetLocators.div,
          CoreCssClasses.Icon.check_icon
        ),
      ],
      NOTE_ICON: [
        'Note icon',
        CommonUtils.concatenate(
          CoreCssClasses.Icon.loc_fa_caution_icon,
          CoreCssClasses.Icon.loc_fa_file_text_o
        ),
      ],
    },
    CONTRACTS: {
      CONTRACTS_LABEL: ['Contracts'],
      CONTRACT_NAME_FIELD: ['Contract name', '#contractName'],
      CONTRACT_NOTES: ['Contract Notes', '#contractsNotes'],
      ADD_NEW: [
        'Add New',
        CommonUtils.concatenate(
          '#tab ',
          selectorFactory.getLabelText('Add New')
        ),
      ],
      CREATE_COPY: [
        'Create Copy',
        CommonUtils.concatenate(
          '#tab ',
          selectorFactory.getLabelText('Create Copy')
        ),
      ],
      SUB_HEADER: ['Contracts', ' '],
      ADD_CONTRACT: ['Add Contract', '#addcontracts'],
      EFFECTIVE_DATE: ['Effective Date', '#effectiveDate input'],
      EXPIRATION_DATE: ['Expiration Date', '#expirationDate input'],
      CONTRACT_TYPE: [
        'Contract Type',
        CommonUtils.concatenate(
          '#contractTypeDropdown ',
          CommonGetLocators.div,
          ' ',
          CommonGetLocators.div,
          CoreCssClasses.DropDown.loc_p_dropdown
        ),
      ],
      CONTRACT_TYPE_DD: [
        'Contract Type',
        CommonUtils.concatenate(
          CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper,
          ' ',
          CommonGetLocators.ul
        ),
      ],
      TABS_UNDER_CONTRACTS: [
        'Tabs under contracts',
        CommonUtils.concatenate(
          CoreCssClasses.Tabs.loc_p_tabview,
          ' ',
          CoreCssClasses.Tabs.loc_p_tabview_nav_content,
          ' ',
          CommonGetLocators.ul,
          ' ',
          CommonGetLocators.li
        ),
      ],
      ADD_DUPLICATE_WARNING: [
        'Duplicate warning message',
        '[data-test-id="warning_duplicate_contract_names"]',
      ],
      WARNING_BANNER: [
        'Warning Banner',
        CommonUtils.concatenate(
          '.contracts-container ',
          CoreCssClasses.Text.loc_warning_banner
        ),
      ],
      POSTING_OPTIONS: {
        POSTING_OPTIONS: ['PostingOptions', '#tab_posting_option'],
        PERCENTAGE_OF_ALLOWED: ['% Allowed', '#numericInput'],
        POSTING_OPTIONS_DROPDOWN_WRAPPER: [
          'Dropdown Wrapper',
          CommonUtils.concatenate(
            CommonGetLocators.div,
            ' ',
            CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper
          ),
        ],
        ADJUSTMENT_TIME: ['Adjustment Time', '#adjustTimeDropdown'],
        DEFAULT_WRITEOFF_TRANSACTION_CODE: [
          'DefaultWrite-OffTransactionCode',
          CommonUtils.concatenate(
            '#transactionCodeDropdown',
            ' ',
            CommonGetLocators.div,
            ' ',
            CommonGetLocators.div,
            CoreCssClasses.DropDown.loc_p_dropdown
          ),
        ],
        DEFAULT_WRITEOFF_GROUP_CODE: [
          'DefaultWrite-OffGroupCode',
          CommonUtils.concatenate(
            '#writeOffGroupDropdown',
            ' ',
            CommonGetLocators.div,
            ' ',
            CommonGetLocators.div,
            CoreCssClasses.DropDown.loc_p_dropdown
          ),
        ],
        DEFAULT_WRITEOFF_REASON_CODE: [
          'DefaultWrite-OffReasonCode',
          CommonUtils.concatenate(
            '#writeOffReasonDropdown',
            ' ',
            CommonGetLocators.div,
            ' ',
            CommonGetLocators.div,
            CoreCssClasses.DropDown.loc_p_dropdown
          ),
        ],
        ADJUSTMENT_TIME_ITEM_LIST: [
          'AdjustmentTimeItemList',
          CommonUtils.concatenate(
            '#nonGrouperAdjTimeId',
            ' ',
            CoreCssClasses.List.loc_dictionary_items
          ),
        ],
        DEFAULT_WRITEOFF_TRANSACTION_CODE_LIST_ITEM: [
          'DefaultWriteOffTransactionCodeListItem',
          CommonUtils.concatenate(
            '#popt_transaction_codes',
            ' ',
            CoreCssClasses.List.loc_dictionary_items,
            ' ',
            '#ssTxt_'
          ),
        ],
        FEE_GROUPS: {
          FEE_GROUP: ['Fee Group', '#feeGroups'],
          DROP_DOWN: ['Drop down', '#contractTypeDropdown'],
          DROP_DOWN_LIST: [
            'Drop down list',
            CoreCssClasses.List.loc_dictionary_items,
          ],
          REIMBURSEMENT: ['Reimbursement', '#numericInput'],
          REIMBURSEMENT_FIELD: ['Reimbursement field', 'td:nth-child(2)'],
          ITEMS: ['Items', CoreCssClasses.DropDown.loc_dropdown_item],
          SEARCH: [
            'Search',
            CommonUtils.concatenate(
              CoreCssClasses.DropDown.loc_p_dropdown_filter_container,
              ' ',
              'input'
            ),
          ],
          PLUS_ICON: ['Plus Icon', 'td.add-new-row'],
          DROPDOWN_COMPONENT: [
            'Dropdown component',
            CommonUtils.concatenate(
              '#feeGroups',
              ' ',
              '#contractTypeDropdown',
              ' ',
              CoreCssClasses.DropDown.loc_p_dropdown_tag,
              ' ',
              CommonGetLocators.div,
              CoreCssClasses.DropDown.loc_p_dropdown,
              ' ',
              'span:nth-child(2)'
            ),
          ],
          ROW_WITH_IN_FEE_GROUP: [
            'Row In Fee Group',
            'tbody tr td.group-number-container',
          ],
        },
        WARNING_TEXT: [
          'Warning Text',
          CommonUtils.concatenate(
            '#postingOption',
            ' ',
            CoreCssClasses.Text.loc_warning_text
          ),
        ],
        DROPDOWN_COMPONENT: [
          'Dropdown Component',
          CommonUtils.concatenate(
            CoreCssClasses.DropDown.loc_p_dropdown_panel_p_component
          ),
        ],
        DROPDOWN_COMPONENT_INPUT_FIELD: [
          'Dropdowm Input Field',
          CommonUtils.concatenate(
            CoreCssClasses.DropDown.loc_dropdown_header,
            ' ',
            'input'
          ),
        ],
      },

      IMPORT_RATES: {
        IMPORT_RATES: ['Import Rates', ''],
      },
      MULTIPLE_PROCEDURES: {
        MULTIPLE_PROCEDURES: ['Multiple Procedures', ''],
      },
      REVIEW_EDIT: {
        REVIEW_EDIT: ['Review/Edit', '#tab_review_edit'],
        SEARCH_CPT: ['Search cpt', 'input[placeholder*="Search by CPT"]'],
        REVIEW_TYPE: ['ReviewType', '.contract-type #contractTypeDropdown'],
        REVIEW_EDIT_PROCEDURE_ROW: [
          'Procedure row',
          CommonUtils.concatenate(
            CoreCssClasses.ScrollPanel.table_scroll_review_tr
          ),
        ],
        REVIEW_TYPE_INPUT: [
          'Review Type Dropdown',
          CommonUtils.concatenate(
            '.type-field #contractTypeDropdown',
            ' ',
            CoreCssClasses.DropDown.loc_p_dropdown
          ),
        ],
        EXEMPT_TYPE: [
          'Exempt Dropdown',
          CommonUtils.concatenate(
            '#contractExemptDropdown',
            ' ',
            CoreCssClasses.DropDown.loc_p_dropdown
          ),
        ],
        DETAILS_FOR_GROUPER_TYPE: [
          'Details',
          CommonUtils.concatenate(
            '#detailsDropdown',
            ' ',
            CoreCssClasses.DropDown.loc_p_dropdown
          ),
        ],
        DETAILS_FOR_BILLING_CHARGE: ['Details Input Field ', '#numericInput'],
        HEADERS_ROW: [
          'Headers',
          '.procedure-table-container table .p-datatable-thead tr',
        ],
        ROW_WITH_IN_PROCEDURE_TABLE: [
          'Row In Procedure Table',
          CommonUtils.concatenate(
            '.procedure-table-container',
            ' ',
            CoreCssClasses.Button.loc_p_element,
            '.p-datatable-tbody tr:nth-child(1) td'
          ),
        ],
      },
      SUPPLIES: {
        SUPPLIES: ['Supplies', ''],
      },
      ADD_CONTRACT_INPUT: ['Contract Name', '#addConsents'],
      SELECT_ITEM_DROPDOWN: ['Select Item', `#itemDropdown`],
      SEARCH_ITEM_IN_DROPDOWN: ['Search', '#ssTxt_addCopy'],
      FIRST_ITEM_IN_LIST: [
        'Select Item',
        CommonUtils.concatenate(
          '#addCopy_temp_select',
          ' ',
          CoreCssClasses.List.loc_dictionary_items,
          ' ',
          CoreCssClasses.ScrollPanel.scroller,
          ' ',
          CoreCssClasses.List.loc_dictionary_item,
          ':nth-child(1)'
        ),
      ],
      SEARCH_PROCEDURE_IN_CONTRACTS: ['Procedure in contract', '#cptSearch'],
      SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS: [
        'Selecting Procedure',
        CommonUtils.concatenate(
          '#e-contracts-config-cpt-table table tbody',
          CoreCssClasses.Button.loc_p_element,
          '.p-datatable-tbody tr:nth-child(1)'
        ),
      ],
      TYPE_DROPDOWN_CONTRACTS: [
        'Dropdown type',
        CommonUtils.concatenate(
          '#review_type  #ssDiv_',
          ' ',
          CoreCssClasses.DropDown.loc_fa_lg
        ),
      ],
      CREATE_COPY_DD: ['Select Item', '#itemDropdown'],
      ADD_NAME: ['Add', '#addcontracts'],
    },
  },
  CBO_MANAGEMENT: {
    CBO_MANAGEMENT_LABEL: ['CBO Management'],
    CBO_ENTITY_NAME_WARNING: [' Warning Message', 'span[class*="ellipsis"]'],
    CBO_DUPLICATE_WARNING: [
      'Warning Message',
      '[data-test-id="warning_duplicate_cbo_entity_names"]',
    ],
    ADD_SEARCH_INPUT: ['CBO Add Search', '[data-test-id="addcboEntities"]'],
    CBO_ENTITY_NAME_INPUT: ['CBO Entity Name', '[data-test-id="CBOEntity"]'],
    ACRONYM_TEXT_INPUT: ['Acronym', '[data-test-id="AcronymField"]'],
    CBO_DELETE_ICON: ['CBO Delete Icon', '[data-test-id="iconCBORowDelete0"]'],
    FACILITIES_DROPDOWN: [
      'Select Multiple Facilities',
      CommonUtils.concatenate(
        '[data-test-id="facilities_MultiSelect"] ',
        CoreCssClasses.MultiSelect.loc_p_multiselect_tag
      ),
    ],
    CBO_ENTITY_DROPDOWN: [
      'Select Single CBO Entity',
      '[data-test-id*="filteredCBOEntityDropdown"]',
    ],
    CBO_PROFILE_DROPDOWN: [
      'Select Single Profile',
      '[data-test-id*="profileLevelCBODropdown"]',
    ],
  },
  USERS: {
    USERS: ['Users'],
    USERS_LIST: ['Users List', '.adminConfigTemplate li'],
    CBO_DETAILS_ADD_ICON: ['Add Icon', '[header="CBO Details"] .add-icon'],
  },
  ADD_ON_FEATURES: {
    ADD_ON_FEATURES_LABEL: ['Add On Features'],
    FEATURE_NAME_SEARCH_INPUT: ['Feature Name', '[data-test-id="featureName"]'],
  },
  SYSTEM_SETTINGS: {
    ADD_ON_FEATURES: ['Add On Features'],
    ADD_ON_FEATURES_SEARCH: ['Add On Features Search', '#txtConsentFilter'],
    FIRST_ROW_UNDER_ADD_ON_FEATURE_FILTER: [
      'First Row Under Add On Features',
      CommonUtils.concatenate(
        'tbody',
        CoreCssClasses.Button.loc_p_element,
        CoreCssClasses.Text.loc_datatable_tbody,
        CommonGetLocators.tr,
        CommonGetLocators.td
      ),
    ],
    FEATURE_NAME_SEARCH_FILTER: ['Feature Name', '#featureName'],
  },
  SECURITY: {
    SECURITY_SECTION: ['Security'],
    MINIMUM_LENGTH: ['Minimum Length', '#txtMinimumLength'],
    MFASSO_HEADER: ['Multi-Factor Authentication and Single-Sign On'],
    MFA_HEADER: ['Multi-Factor Authentication'],
    MFA_ENABLE_BUTTON: [
      'Enable',
      '[data-test-id="mfaSwitch"] [aria-label="Enable"]',
    ],
    MFA_DISABLE_BUTTON: [
      'Disable',
      '[data-test-id="mfaSwitch"] [aria-label="Disable"]',
    ],
    MFA_BYPASSING_HEADER: ['Allow Bypassing MFA'],
    MFA_BYPASSING_YES_BUTTON: [
      'Yes',
      '[data-test-id="bypassMfaSwitch"] [aria-label="Yes"]',
    ],
    MFA_BYPASSING_NO_BUTTON: [
      'No',
      '[data-test-id="bypassMfaSwitch"] [aria-label="No"]',
    ],
    MFA_BYPASSING_TOOL_TIP: [
      'Allow Bypassing MFA TOOL TIP',
      CoreCssClasses.Button.loc_fa_info_circle,
    ],
    IP_RANGE_HEADER: ['IP Range for Multi-Factor Authentication Bypass'],
    IP_RANGE_TEXT_BOX: [
      'IP Range for Multi-Factor Authentication Bypass',
      '.add-icon',
    ],
    IP_FROM: ['From', '#rangeStart-'],
    IP_TO: ['To', '#rangeEnd-'],
    IP_FROM_DATA: ['From', '[for="rangeStart-'],
    IP_DATA_END: ['From And To End', '"]'],
    IP_TO_DATA: ['To', '[for="rangeEnd-'],
    IP_FROM_TO_WARNING: [
      'From and To warning Text',
      CoreCssClasses.Text.loc_warning_text,
    ],
    IP_FROM_TO_DELETE: ['Delete ICON', '#iconRowDelete'],
    MFA_HIGHLIGHT: [
      'Multi-Factor Authentication',
      CoreCssClasses.Panel.loc_p_highlight,
    ],
  },
  USERS_TAB: {
    USERS_SECTION: [
      'Users',
      '.submenu-itemdesktop-nav-buttonng-star-insertedactive',
    ],
    USER_SEARCH: ['Search', '#txtConsentFilter'],
    VALIDATE_EMAIL: ['Email', '[for="email"]'],
    USER_DATA: ['Verifying User Data', '.config-selector-list-item-container>'],
  },
  CREATE_USER_DETAILS: {
    FIRST_NAME: ['First Name', '[id="firstName"]'],
    LAST_NAME: ['Last Name', '[id="lastName"]'],
    EMAIL: ['Email', '[id="email"]'],
    DELETE: [
      'Delete',
      CommonUtils.concatenate(CommonGetLocators.li, ' .trash-icon'),
    ],
    ACTIVE_YES: ['Yes', '[data-test-id="sbtnshowInActive"] [aria-label="Yes"]'],
    ACTIVE_NO: ['No', '[data-test-id="sbtnshowInActive"] [aria-label="No"]'],
  },
  USER_DETAILS: {
    USER_DETAILS_TAB: ['User Details'],
    EMAIL_ASTERISK: ['Email', '[data-test-id="email-mandatory-asterisk"]'],
    USER_DETAILS_EMAIL: ['Email', '#emailAddress'],
    EMAIL_VALIDATION_TEXT_IN_TOOLTIP: [
      'Email validation',
      CommonUtils.concatenate('span', CoreCssClasses.Text.loc_validation_text),
    ],
  },
  CLICK_ON_OK: {
    CLICK_ON_OK_IN_TOOLTIP: [
      'Tooltip ok button',
      CommonUtils.concatenate(
        '#btnYes ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],
  },
  CLICK_CREATE_COPY_USER: {
    CREATE_COPY_USER: ['Create copy', '[data-test-id="create-copy"]'],
  },
  CHANGE_PASSWORD: {
    ENTERPRISE_DISABLE: ['Change password', '#btnChangePassword'],
  },
};
