import CommonCore, {
  Application,
  CommonClassAttributes,
  CommonGetLocators,
  defaultTimeOut,
  DoneOrCancel,
  EnableOrDisable,
  FilterMethods,
  InvokeAttributes,
  InvokeMethods,
  LeftOrRight,
  ShouldMethods,
  TriggerAttributes,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../support/common-core-libs/application/application-settings';

import { AppColors } from '../../../support/common-core-libs/application/constants/app-colors.constants';
import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import {
  AddRcmStatus,
  Implant,
  Medication,
} from '../../../test-data-models/sis-office/trackers/inv-reconciliation.model';
import {
  Contract,
  TransactionCode,
  RevenueCycleManager,
  Discount,
  Insurance,
  FeeSchedule,
  BlockScheduling,
  Supplies,
  PhysicianOrders,
} from '../../../test-data-models/shared/application-settings/application-settings.model';
import {
  Consents,
  Cpt,
} from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_PATIENT_CASE_CREATION } from '../../sis-office/case-creation/or/create-case.or';
import { OR_NURSING_CONFIGURATION } from './or/nursing-configuration.or';
import { OR_SCHEDULE_GRID } from '../../sis-office/case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../sis-office/trackers/or/combined-coding.or';

import { NursingConfigurationApis } from './api/nursing-configuration.api';
import { ContextMenu } from '../../sis-office/facesheet/facesheet-transactions';
import {
  Formulary,
  FreeText,
  HelpText,
  ImplantHeaders,
  IosTextItem,
  ShowPatients,
  SupplyHeaders,
} from './enums/nursing-configuration.enum';

/* locators */
const duplicate_l_insc = CommonUtils.concatenate(
  CoreCssClasses.ClassPrefix.loc_fa_fa,
  `-exclamation-circle']`
);
const duplicate_l_msg = '.ellipsis.ng-binding';

/* instance variables */
const color = require('onecolor');
const number = 3000;

/* enum values */
enum Existence {
  exist = 'Exist',
}

enum ItemShow {
  item = 'Items',
  shown = 'Shown',
}

export default class NursingConfiguration extends CommonCore {
  /* instance variables */
  private sisOfficeDesktop = new SISOfficeDesktop();
  private nursingConfigurationLayout = new NursingConfigurationLayout();
  private nursingConfigApis = new NursingConfigurationApis();

  private DiscountInfo!: Discount;
  private InsuranceInfo!: Insurance;
  private RCMInfo!: RevenueCycleManager;
  private TransactionInfo!: TransactionCode;
  private ContractInfo!: Contract;
  private BlocScheduleInfo!: BlockScheduling;

  /* const values */
  private OR_RCM = OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER;
  private OR_DISC = OR_NURSING_CONFIGURATION.DISCOUNTS;
  private OR_INSC = OR_NURSING_CONFIGURATION.INSURANCE;
  private OR_COMMON = OR_NURSING_CONFIGURATION.COMMON;
  private OR_BLOCK_SCHEDULING = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING;
  private OR_TRANS_CODE = OR_NURSING_CONFIGURATION.TRANSACTION_CODES;
  private OR_FEE_SCHEDULE = OR_NURSING_CONFIGURATION.FEE_SCHEDULE;

  // Declaring Max_Size allowed in Name Field
  MAX_SIZE = 80;

  /**
   * @details - add data entities to block scheduling
   * @param BlocScheduleInfo
   */
  get BlockSchedulingModel(): BlockScheduling {
    return this.BlocScheduleInfo;
  }

  /**
   * @details - add data entities to Revenue Cycle Manager
   * @param RCMInfo
   * @Api API's are available - Not Implemented
   */
  get RevenueCycleManagerModel(): RevenueCycleManager {
    return this.RCMInfo;
  }

  get TransactionCodeModel(): TransactionCode {
    return this.TransactionInfo;
  }

  /**
   *@details Method for adding RCM in application settings
   *@param RCMInfo- model needs to be passed with necessary fields
   *@Api API's are available - Implemented Completely
   *@author Arushi
   */
  addRevenueCycleManager(RCMInfo: RevenueCycleManager) {
    const interceptCollection = this.nursingConfigApis.interceptRCMApi();
    this.RCMInfo = RCMInfo;

    /** Refresh layout */
    this.nursingConfigurationLayout.selectConfiguration(
      this.OR_RCM.SUB_HEADER[0],
      true
    );
    //  Click Add Button, Enter Name and Click Done Button
    cy.cClick(this.OR_COMMON.ADD_BUTTON[1], this.OR_COMMON.ADD_BUTTON[0]);
    cy.cType(
      this.OR_COMMON.ADD.ADD_NAME[1],
      this.OR_COMMON.ADD.ADD_NAME[0],
      this.RCMInfo.Name
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.OR_COMMON.ADD.DONE_BUTTON[1],
      this.OR_COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (body.find(this.OR_COMMON.ADD.DUPLICATE_MESSAGE[1]).length > 0) {
        cy.cGet(this.OR_COMMON.ADD.DUPLICATE_MESSAGE[1])
          .invoke(InvokeMethods.text)
          .then(($txt) => {
            throw `${AppErrorMessages.expected_errors} - ${$txt}`;
          });
      }
    });
    // Selecting Classification
    cy.cIntercept(interceptCollection);
    cy.cSelectDropdown(
      this.OR_RCM.CLASSIFICATION[1],
      this.OR_RCM.CLASSIFICATION[0],
      this.RCMInfo.Classification!,
      true
    );
    cy.cWaitApis(interceptCollection);
    // Entering Days From Post Or Transfer
    cy.cType(
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[1],
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[0],
      this.RCMInfo.DaysFromPostOrTransfer
    );
  }

  /**
   * @Api API's are available - Not Implemented
   */
  verifyRevenueCycleManager() {
    let name = this.RCMInfo.Name;
    /** Refresh layout */
    this.nursingConfigurationLayout.typeConfiguration(
      this.OR_RCM.SUB_HEADER[0]
    );
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.REVENUE_CYCLE_MANAGER[1]
    )
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .then(($col) => {
        switch (String($col)) {
          case AppColors.component_on_selection:
            break;
          case AppColors.component_before_selection:
            cy.cClick(
              OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
                .REVENUE_CYCLE_MANAGER[1],
              OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
                .REVENUE_CYCLE_MANAGER[0]
            );
            break;
          default:
            break;
        }
      });
    cy.cType(
      this.OR_COMMON.SEARCH[1],
      this.OR_COMMON.SEARCH[0],
      this.RCMInfo.Name
    );
    // verify name should not appear in list if size of Name > MAX_SIZE
    if (this.RCMInfo.Name!.length > this.MAX_SIZE) {
      cy.cNotExist(
        this.RCMInfo.Name!,
        this.OR_COMMON.ALL_LIST_OPTIONS[0],
        true
      );
    }

    // verify Name of MAX_SIZE is save, which can be filtered
    if (this.RCMInfo.Name!.length > this.MAX_SIZE) {
      name = this.RCMInfo.Name!.substring(0, this.MAX_SIZE);
      cy.cType(this.OR_COMMON.SEARCH[1], this.OR_COMMON.SEARCH[0], name);
      cy.cIncludeText(
        this.OR_COMMON.ALL_LIST_OPTIONS[1],
        this.OR_COMMON.ALL_LIST_OPTIONS[0],
        name
      );
    }

    // on selection related information should be reflected on page
    //TODO: Need to implement API
    cy.cClick(
      this.OR_COMMON.ALL_LIST_OPTIONS[1],
      this.OR_COMMON.ALL_LIST_OPTIONS[0]
    );

    // Verifying the name after clicking on the newly added data
    cy.cHasValue(
      this.OR_COMMON.NAME[1],
      this.OR_COMMON.NAME[0],
      this.RCMInfo.Name!.substring(0, this.MAX_SIZE)
    );

    //  Verifying the Classification after clicking on the newly added data
    this.sisOfficeDesktop.validateMultiSelectDropdown(
      this.OR_RCM.CLASSIFICATION[1],
      this.OR_RCM.CLASSIFICATION[0],
      this.RCMInfo.Classification!
    );

    // Verifying the days from post/transfer after clicking on the newly added data
    cy.cHasValue(
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[1],
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[0],
      this.RCMInfo.DaysFromPostOrTransfer
    );
  }

  /**
   * @Api API's are available - Not Implemented
   */
  searchRevenueCycleManager(name: string) {
    // Type the name in search box
    cy.cType(this.OR_COMMON.SEARCH[1], this.OR_COMMON.SEARCH[0], name);
    cy.contains(name).then(($element) => {
      if (Cypress.dom.isAttached($element!)) {
        //TODO: Need to implement API
        cy.cClick(name, name, true);
      }
    });
  }

  /**
   * @Api API's are available - Not Implemented
   */
  editRevenueCycleManager(rcmInfo: RevenueCycleManager) {
    this.searchRevenueCycleManager(rcmInfo.Name!.substring(0, this.MAX_SIZE));
    //TODO: Need to implement API
    cy.cSelectDropdown(
      this.OR_RCM.CLASSIFICATION[1],
      this.OR_RCM.CLASSIFICATION[0],
      rcmInfo.Classification!,
      true
    );
    // Entering Days From Post Or Transfer
    cy.cType(
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[1],
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[0],
      123
    );
    // Clicking on name field to save entered days from post/transfer field
    //TODO: Need to implement API
    cy.cClick(this.OR_COMMON.NAME[1], this.OR_COMMON.NAME[0]);
    //  Validating Days From Post/Transfer before navigating to different configuration
    cy.cHasValue(
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[1],
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[0],
      123
    );
    // Selecting Insurance in configuration
    //TODO: Need to implement API
    this.nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.INSURANCE[0],
      true
    );
    // Selecting RCM again in configuration
    //TODO: Need to implement API
    this.nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.REVENUE_CYCLE_MANAGER[0],
      true
    );
    //  Searching for the specific rcm in list and selecting it
    this.searchRevenueCycleManager(rcmInfo.Name!.substring(0, this.MAX_SIZE));
    //  Verifying the Classification after clicking on the newly added data
    this.sisOfficeDesktop.validateMultiSelectDropdown(
      this.OR_RCM.CLASSIFICATION[1],
      this.OR_RCM.CLASSIFICATION[0],
      rcmInfo.Classification!,
      false
    );
    //  Verifying the days from post/transfer after clicking on the newly added data
    cy.cHasValue(
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[1],
      this.OR_RCM.DAYS_FROM_POST_TRANSFER[0],
      123
    );
  }

  /**
   *@details Adding for Discounts in application settings
   *@Api API's are available - Not Implemented
   */
  addDiscountApp(discountInfo: Discount) {
    this.DiscountInfo = discountInfo;
    /** Refresh layout */
    //TODO: Need to implement API
    this.nursingConfigurationLayout.selectConfiguration(
      this.OR_DISC.SUB_HEADER[0]
    );
    // Enter name
    //TODO: Need to implement API
    cy.cClick(this.OR_COMMON.ADD_BUTTON[1], this.OR_COMMON.ADD_BUTTON[0]);
    cy.cType(
      this.OR_COMMON.ADD.ADD_NAME[1],
      this.OR_COMMON.ADD.ADD_NAME[0],
      this.DiscountInfo.Discounts
    );
    //TODO: Need to implement API
    cy.cClick(
      this.OR_COMMON.ADD.DONE_BUTTON[1],
      this.OR_COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (body.find(this.OR_COMMON.ADD.DUPLICATE_MESSAGE[1]).length > 0) {
        cy.cGet(this.OR_COMMON.ADD.DUPLICATE_MESSAGE[1])
          .invoke(InvokeMethods.text)
          .then(($txt) => {
            throw `${AppErrorMessages.duplicate_discounts} - ${$txt}`;
          });
        cy.cClick(
          this.OR_COMMON.ADD.CANCEL_BUTTON[1],
          this.OR_COMMON.ADD.CANCEL_BUTTON[0]
        );
      }
    });

    if (!this.verifyAndCancelDuplicateMsgPopup()) {
      // need to add click on label after entering the value
      cy.cType(
        this.OR_DISC.DISCOUNT_PERCENT[1],
        this.OR_DISC.DISCOUNT_PERCENT[0],
        this.DiscountInfo.DiscountPercent
      );
      //TODO: Need to implement API
      this.selectDropdownValueInAppSettings(
        this.OR_DISC.TRANSACTION_CODE[1],
        this.OR_DISC.TRANSACTION_CODE[0],
        this.DiscountInfo.TransactionCode!
      );
      //TODO: Need to implement API
      this.selectDropdownValueInAppSettings(
        this.OR_DISC.WRITEOFF_GROUP_CODE[1],
        this.OR_DISC.WRITEOFF_GROUP_CODE[0],
        this.DiscountInfo.WriteoffGroupCode!
      );
      //TODO: Need to implement API >>for this method all calls are same
      this.selectDropdownValueInAppSettings(
        this.OR_DISC.WRITEOFF_REASON_CODE[1],
        this.OR_DISC.WRITEOFF_REASON_CODE[0],
        this.DiscountInfo.WriteoffReasonCode!
      );
    }
  }

  /**
   * @details - Adding for Transactions code in application settings
   * @param transactionInfo
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  addTransactionCode(transactionInfo: TransactionCode) {
    const interceptCollection =
      this.nursingConfigApis.interceptAddTransactionCodePopUpApi();
    this.TransactionInfo = transactionInfo;
    cy.cClick(this.OR_COMMON.ADD_BUTTON[1], this.OR_COMMON.ADD_BUTTON[0]);
    cy.cType(
      this.OR_COMMON.ADD.ADD_NAME[1],
      this.OR_COMMON.ADD.ADD_NAME[0],
      this.TransactionInfo.TransactionCodeName
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.OR_COMMON.ADD.DONE_BUTTON[1],
      this.OR_COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);

    /* Check for duplicate transaction code popup */
    if (!this.verifyAndCancelDuplicateMsgPopup()) {
      this.selectDropdownValueInAppSettings(
        this.OR_TRANS_CODE.TYPE[1],
        this.OR_TRANS_CODE.TYPE[0],
        this.TransactionInfo.Type
      );
    }
  }

  /**
   * @details - Adding for Insurance in application settings
   * @param insuranceInfo
   * @Api API's are available - Not Implemented
   */
  addInsuranceApp(insuranceInfo: Insurance) {
    this.InsuranceInfo = insuranceInfo;

    /** Refresh layout */
    this.nursingConfigurationLayout.selectConfiguration(
      this.OR_INSC.SUB_HEADER[0]
    );

    // Enter name
    //TODO: Need to implement API
    cy.cClick(this.OR_COMMON.ADD_BUTTON[1], this.OR_COMMON.ADD_BUTTON[0]);
    cy.cType(
      this.OR_INSC.INSURANCE_NAME[1],
      this.OR_INSC.INSURANCE_NAME[0],
      this.InsuranceInfo.InsuranceCarrierName
    );
    cy.cClick(
      this.OR_INSC.INSURANCE_ADD_PLAN_BUTTON[1],
      this.OR_INSC.INSURANCE_ADD_PLAN_BUTTON[0]
    );

    // Checking if insurance is duplicate
    cy.cGet(CommonGetLocators.body).then((body) => {
      // Check for duplicate massage if duplicate then search insurance and

      if (body.find(duplicate_l_insc).length > 0) {
        cy.cGet(duplicate_l_msg)
          .invoke(InvokeMethods.text)
          .then(($txt) => {
            throw `${AppErrorMessages.duplicate_insurance} - ${$txt}`;
          });
        // Add insurance if its not duplicate
      } else {
        cy.cType(
          this.OR_INSC.INSURANCE_PLAN_NAME[1],
          this.OR_INSC.INSURANCE_PLAN_NAME[0],
          this.InsuranceInfo.InsurancePlanName
        );
        cy.cType(
          this.OR_INSC.PAYER_CODE[1],
          this.OR_INSC.PAYER_CODE[0],
          this.InsuranceInfo.PayerCode
        );
        //TODO: Need to implement API
        cy.cClick(
          this.OR_INSC.INSURANCE_CLASSIFICATION[1],
          this.OR_INSC.INSURANCE_CLASSIFICATION[0]
        );

        cy.cGet(
          selectorFactory.getDropdownValueInConfigurations(
            this.InsuranceInfo.InsuranceClassification
          )
        )
          .parent()
          .click();
        cy.cGet(this.OR_INSC.ACCEPT_ASSIGNMENT_YES[1]).parent().click();
        cy.cGet(this.OR_INSC.GENERATE_BILL_YES[1]).parent().click();
        this.selectDropdownValueInAppSettings(
          this.OR_INSC.CONTRACT[1],
          this.OR_INSC.CONTRACT[0],
          this.InsuranceInfo.Contract!
        );

        cy.cClick(
          this.OR_INSC.ADD_CLAIM_OFFICE_NAME[1],
          this.OR_INSC.ADD_CLAIM_OFFICE_NAME[0]
        );
        cy.cType(
          this.OR_INSC.CLAIM_OFFICE_NAME[1],
          this.OR_INSC.CLAIM_OFFICE_NAME[0],
          this.InsuranceInfo.ClaimOfficeName
        );
        cy.cType(
          this.OR_INSC.ADDRESS[1],
          this.OR_INSC.ADDRESS[0],
          this.InsuranceInfo.Address
        );
        cy.cType(
          this.OR_INSC.CITY[1],
          this.OR_INSC.CITY[0],
          this.InsuranceInfo.City
        );
        cy.cClick(this.OR_INSC.STATE[1], this.OR_INSC.STATE[0]);
        cy.cGet(
          selectorFactory.getDropdownStateValuesInConfigurations(
            this.InsuranceInfo.State
          )
        )
          .parent()
          .click();

        cy.cType(
          this.OR_INSC.ZIP[1],
          this.OR_INSC.ZIP[0],
          this.InsuranceInfo.Zip
        );
        //TODO: Need to implement API
        cy.cClick(
          this.OR_INSC.CLAIM_OFFICE_DONE[1],
          this.OR_INSC.CLAIM_OFFICE_DONE[0]
        );
        //TODO: Need to implement API
        cy.cClick(
          this.OR_INSC.INSURANCE_DONE[1],
          this.OR_INSC.INSURANCE_DONE[0]
        );
      }
    });
  }

  /**
   * @Api API's are not available
   */
  verifyAndCancelDuplicateMsgPopup(): number {
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (body.find(this.OR_COMMON.ADD.DUPLICATE_MESSAGE[1]).length > 0) {
        cy.cGet(this.OR_COMMON.ADD.DUPLICATE_MESSAGE[1])
          .invoke(InvokeMethods.text)
          .then(($txt) => {
            throw `${AppErrorMessages.expected_errors} - ${$txt}`;
          });
        return 1;
      }
    });
    return 0;
  }

  /**
   * @Api API's are not available
   */
  searchContract(contractInfo: Contract) {
    this.ContractInfo = contractInfo;
    // Type the name in search box
    cy.cType(
      this.OR_COMMON.SEARCH[1],
      this.OR_COMMON.SEARCH[1],
      this.ContractInfo.ContractName
    );

    cy.cGet(this.OR_COMMON.FIRST_OPTION_IN_LIST[1]).then(($list) => {
      if ($list.text().includes(contractInfo.ContractName)) {
        return true;
      }
      return false;
    });
  }

  /**
   * @Api API's are available - Not Implemented
   */
  addContract(contractInfo: Contract) {
    this.ContractInfo = contractInfo;
    this.nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONTRACTS.SUB_HEADER[0]
    );
    // Enter name
    cy.cClick(this.OR_COMMON.ADD_BUTTON[1], this.OR_COMMON.ADD_BUTTON[0]);
    cy.cType(
      this.OR_COMMON.ADD.ADD_NAME[1],
      this.OR_COMMON.ADD.ADD_NAME[0],
      this.ContractInfo.ContractName
    );
    //TODO: Need to implement API
    cy.cClick(
      this.OR_COMMON.ADD.DONE_BUTTON[1],
      this.OR_COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cGet(CommonGetLocators.body).then(($body) => {
      if (
        $body.find(this.OR_COMMON.ADD.ADD_POPUP_DUPLICATE_MESSAGE[1]).length > 0
      ) {
        cy.cGet(this.OR_COMMON.ADD.ADD_POPUP_DUPLICATE_MESSAGE[1])
          .invoke(InvokeMethods.text)
          .then(($txt) => {
            cy.cClick(
              this.OR_COMMON.ADD.CANCEL_BUTTON[1],
              this.OR_COMMON.ADD.CANCEL_BUTTON[0]
            );
          });
      } else {
        // Enter Effective Date
        cy.cType(
          OR_NURSING_CONFIGURATION.CONTRACTS.EFFECTIVE_DATE[1],
          OR_NURSING_CONFIGURATION.CONTRACTS.EFFECTIVE_DATE[0],
          this.ContractInfo.EffectiveDate!
        );
        // Enter Expiration Date
        cy.cType(
          OR_NURSING_CONFIGURATION.CONTRACTS.EXPIRATION_DATE[1],
          OR_NURSING_CONFIGURATION.CONTRACTS.EXPIRATION_DATE[0],
          this.ContractInfo.ExpirationDate!
        );
        cy.cClick(
          OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_TYPE[1],
          OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_TYPE[0]
        );
        //TODO: Need to implement API
        cy.cClick(
          selectorFactory.getDropdownValueInConfigurations(
            this.ContractInfo.ContractType
          ),
          this.ContractInfo.ContractType
        );
      }
    });
  }

  /**
   * @details - Search a contract in application settings
   * @param contractInfo
   * @API - API's are available - Implemented Completely
   * @author Arushi
   */
  searchContractOptions(contractInfo: Contract) {
    const interceptselectContractApiCollection =
      this.nursingConfigApis.selectContractApi();

    this.nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONTRACTS.SUB_HEADER[0]
    );
    //  Searching for the Contract name
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0],
      contractInfo.ContractName
    );
    // Clicking on the contract name
    cy.cIntercept(interceptselectContractApiCollection);
    this.selectConfigurationFirstTemplate();
    cy.cWaitApis(interceptselectContractApiCollection);
    // Clicking on the Review contract
    const interceptCollection =
      this.nursingConfigApis.interceptContractSearchedProcedureApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.REVIEW_EDIT.REVIEW_EDIT[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.REVIEW_EDIT.REVIEW_EDIT[0]
    ).then(() => {
      cy.cHasBackgroundColor(
        OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.POSTING_OPTIONS[1],
        OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.POSTING_OPTIONS[0],
        AppColors.component_enabled_toggle_button_selected
      );
      cy.cHasBackgroundColor(
        OR_NURSING_CONFIGURATION.CONTRACTS.REVIEW_EDIT.REVIEW_EDIT[1],
        OR_NURSING_CONFIGURATION.CONTRACTS.REVIEW_EDIT.REVIEW_EDIT[0],
        AppColors.component_tab_array_selection
      );
    });
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Adding Contract  posting options
   * @param contractInfo
   * @Api API's are available - Partially Implemented
   * @author Arushi
   */
  addContractPostingOptions(contractInfo: Contract) {
    const interceptSearchContractsApiCollection =
      this.nursingConfigApis.interceptSearchContractsApi();
    // Searching for the Contract name
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0],
      contractInfo.ContractName
    );
    // Clicking on the contract name
    cy.cIntercept(interceptSearchContractsApiCollection);
    this.selectConfigurationFirstTemplate();
    cy.cWaitApis(interceptSearchContractsApiCollection);
    // Add % allowed
    cy.cType(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .PERCENTAGE_OF_ALLOWED[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .PERCENTAGE_OF_ALLOWED[0],
      contractInfo.PercentageOfAllowed
    );
    // Select adjustment time
    const interceptCollection =
      this.nursingConfigApis.interceptContractPostingOptApi();
    cy.cIntercept(interceptCollection);
    cy.cVerifySelectedDropdownValueAppSettings(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.ADJUSTMENT_TIME[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.ADJUSTMENT_TIME[0],
      contractInfo.AdjustmentTime!
    );
    cy.cWaitApis(interceptCollection);

    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_TRANSACTION_CODE[0]
    );
    cy.cGet(
      selectorFactory.getDropdownValueInConfigurations(
        contractInfo.DefaultWriteOffTransactionCode!
      )
    )
      .parent()
      .click();
    cy.cWaitApis(interceptCollection);
    this.selectDropdownValueInAppSettings(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_GROUP_CODE[0],
      contractInfo.DefaultWriteOffGroupCode!
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS
        .DEFAULT_WRITEOFF_REASON_CODE[0]
    );
    cy.cIntercept(interceptCollection);
    cy.cGet(
      selectorFactory.getDropdownValueInConfigurations(
        contractInfo.DefaultWriteOffReasonCode!
      )
    )
      .parent()
      .click();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To verify the CDT results displayed while adding the CDT Code in Fee Schedule page.
   * @param feeScheduleInfo
   * @Api API's are not available
   */
  verifyCDTSearchResults(feeScheduleInfo: FeeSchedule) {
    this.nursingConfigurationLayout.selectConfiguration(
      this.OR_FEE_SCHEDULE.SUB_HEADER[0]
    );
    this.clickAddInFeeSchedule();
    cy.cType(
      this.OR_FEE_SCHEDULE.ADD_PROCEDURE_SEARCH[1],
      '',
      feeScheduleInfo.ProcedureName[0]
    );
    cy.cNotExist(this.OR_FEE_SCHEDULE.CPT_SELECT[1], '');
    cy.cClick(this.OR_FEE_SCHEDULE.CANCEL[1], '');
  }

  /**
   * @details - To add the new CDT Code in Fee Schedule page
   * @param feeScheduleInfo
   */
  addCDTCode(feeScheduleInfo: FeeSchedule) {
    this.nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.FEE_SCHEDULE.SUB_HEADER[0]
    );
    feeScheduleInfo.ProcedureName.forEach((procedureName) => {
      this.addMultipleCDTCode(procedureName, feeScheduleInfo);
    });
  }

  /**
   * @details - To adding multiple CDT Codes in Fee Schedule page
   * @param -CDTCode
   * @param feeScheduleInfo
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  addMultipleCDTCode(cdtCode: string, feeScheduleInfo: FeeSchedule) {
    const interceptFeeScheduleDoneCollection =
      this.nursingConfigApis.interceptFeeScheduleDone();

    this.clickAddInFeeSchedule();
    cy.cType(this.OR_FEE_SCHEDULE.ADD_PROCEDURE_SEARCH[1], '', cdtCode);
    cy.cClick(
      CommonUtils.concatenate(
        this.OR_FEE_SCHEDULE.PROCEDURE_LIST[1],
        selectorFactory.getDivText(cdtCode)
      ),
      '',
      false,
      true
    );
    cy.cIntercept(interceptFeeScheduleDoneCollection);

    this.sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptFeeScheduleDoneCollection);
    cy.cType(
      this.OR_FEE_SCHEDULE.AMOUNT[1],
      '',
      feeScheduleInfo.Amount,
      false,
      true
    );
    const interceptCollection =
      this.nursingConfigApis.interceptFeeScheduleStatusUpdate();
    cy.cIntercept(interceptCollection);

    this.feeScheduleStatusDropdown(feeScheduleInfo.Status!);
    cy.cWaitApis(interceptCollection);
  }
  /**
   * @details - Select First Option in List
   * @api Api are not available
   */
  selectConfigurationFirstTemplate() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.FIRST_OPTION_IN_LIST[1],
      OR_NURSING_CONFIGURATION.COMMON.FIRST_OPTION_IN_LIST[0]
    );
  }

  /**
   * @details - Enter And Verify Input Field Values
   * @Api API's are not available
   */
  enterAndVerifyInput(
    selector: string,
    logicalName: string,
    text: string,
    value: string
  ) {
    cy.cIsEnabled(selector, logicalName).then(() => {
      cy.cType(selector, logicalName, text, false, true, {
        force: true,
      }).cHasValue(selector, logicalName, value);
    });
  }

  /**
   * @details - Verify Duplicate Message in Add popup window and click on cancel button
   * @param name
   * @param message
   * @Api API's are not available
   */
  verifyDuplicateMessage(name: string, message: string) {
    // Click on Add button
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );

    // Enter the Duplicate RCM Name and Click on Done Button
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0],
      name
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0]
    );

    // Verify Duplicate Message
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DUPLICATE_MESSAGE[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DUPLICATE_MESSAGE[0],
      message
    );

    // Click Cancel Button to close add popup
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[0]
    );
  }

  /**
   * @details - Verify Page Load Text of Business Items
   * @Api API's are not available
   */
  verifyHelperText() {
    cy.cGet(CommonGetLocators.body).then(($body) => {
      if (
        $body.find(OR_NURSING_CONFIGURATION.COMMON.ALL_LIST_OPTIONS[1]).length >
        0
      ) {
        cy.cIncludeText(
          OR_NURSING_CONFIGURATION.COMMON.HELPER_TEXT[1],
          OR_NURSING_CONFIGURATION.COMMON.HELPER_TEXT[0],
          HelpText.business_with_list
        );
      } else {
        cy.cIncludeText(
          OR_NURSING_CONFIGURATION.COMMON.HELPER_TEXT[1],
          OR_NURSING_CONFIGURATION.COMMON.HELPER_TEXT[0],
          HelpText.business_without_list
        );
      }
    });
  }

  /**
   * @details - Verify Field Labels in Nursing Configuration
   * @Api API's are not available
   */
  verifyFieldLabels(selector: string, logicalName: string, label: string) {
    cy.cIncludeText(selector, logicalName, label);
  }

  /**
   * @details - Verify Header in Nursing Configuration
   * @Api API's are not available
   */
  verifyHeader(selector: string, logicalName: string, header: string) {
    cy.cHasText(selector, logicalName, header);
  }

  /**
   * @details - Verify Done Button is disabled by default in add popup in Nursing Configuration
   * @Api API's are not available
   */
  verifyDoneButtonDisableInAddPopup() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );
    // Verify Done Button is Disabled by default in add popup
    cy.cIsEnabled(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0],
      false,
      false
    );
  }

  /**
   * @details - Click Cancel button in add popup and Verify add popup has been closed
   * @Api API's are not available
   */
  verifyCancelInAddPopup() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[0]
    );
    cy.cNotExist(
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_POPUP_WINDOW[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_POPUP_WINDOW[0]
    );
  }

  /**
   * @details - Click working days in schedule in ap settings
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  scheduleClickWorkingDays(day: string, check: boolean) {
    const interceptCollection = this.nursingConfigApis.interceptWorkingDays();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(day), day);
    cy.cWaitApis(interceptCollection);
    if (check) {
      cy.cIsVisible(selectorFactory.workingDayCheckMark(day), day);
    } else {
      cy.cIsVisible(
        selectorFactory.workingDayUnselected(check,day),
        ''
      );
    }
  }

  /**
   * @details - Add Block Scheduling
   * @param value
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  addBlockScheduling(value: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptDoneCreateBlock();
    cy.cClick(this.OR_COMMON.ADD_BUTTON[1], this.OR_COMMON.ADD_BUTTON[0]);
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0],
      value
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      this.OR_COMMON.ADD.DONE_BUTTON[1],
      this.OR_COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select Default plan in configuration - Insurance
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  selectDefaultPlan() {
    const interceptCollection =
      this.nursingConfigApis.interceptDefaultInsurance();
    cy.cGet(this.OR_INSC.DEFAULT_PLAN[1])
      .invoke(InvokeMethods.css, InvokeAttributes.backgroundColor)
      .then(($background) => {
        const hex = String(color($background.toString()).hex()).toUpperCase();
        if (
          hex ==
          AppColors.component_enabled_toggle_button_not_selected.toUpperCase()
        ) {
          cy.cIntercept(interceptCollection);
          cy.cClick(this.OR_INSC.DEFAULT_PLAN[1], this.OR_INSC.DEFAULT_PLAN[0]);
          cy.cWaitApis(interceptCollection);
        }
      });
  }

  /**
   * @details - To edit the insurance plan and click on Done button.
   * @API - API's are available - Implemented Completely
   */
  editInsurance(insuranceName: string, option: string) {
    const interceptEditInsuranceDoneCollection =
      this.nursingConfigApis.interceptEditInsuranceDone();

    this.nursingConfigurationLayout.selectConfiguration(
      this.OR_INSC.SUB_HEADER[0]
    );
    cy.cType(this.OR_COMMON.SEARCH[1], this.OR_COMMON.SEARCH[0], insuranceName);
    /**
     * @Issue: Sometimes Normal click didn't populated the plan details of the insurance
     * @Resolution: Added few assertions and re click on the insurance
     */
    const interceptSelectInsuranceApiCollection =
      this.nursingConfigApis.interceptSelectInsuranceApi();
    cy.cIntercept(interceptSelectInsuranceApiCollection);
    cy.cGet(selectorFactory.getDivTitle(insuranceName)).click();
    this.assertionClaimButton();
    cy.cGet(selectorFactory.getDivTitle(insuranceName)).click();
    cy.cWaitApis(interceptSelectInsuranceApiCollection);
    cy.cClick(
      this.OR_INSC.INSURANCE_PLAN_CONTEXT_ICON[1],
      this.OR_INSC.INSURANCE_PLAN_CONTEXT_ICON[0]
    );
    const interceptClickContextMenuApiCollection =
      this.nursingConfigApis.interceptClickContextMenuApi();
    cy.cIntercept(interceptClickContextMenuApiCollection);
    cy.cClick(selectorFactory.getAText(option), option);
    cy.cWaitApis(interceptClickContextMenuApiCollection);
    this.selectDefaultPlan();
    cy.cIntercept(interceptEditInsuranceDoneCollection);
    cy.cClick(this.OR_INSC.INSURANCE_DONE[1], this.OR_INSC.INSURANCE_DONE[0]);
    cy.cWaitApis(interceptEditInsuranceDoneCollection);
    this.sisOfficeDesktop.selectSisLogo();
  }

  /**
   * @details - Enter value in text fields
   * @param locLogicalName
   * @param value
   * @Api - API's are not available
   */
  enterBlockDetails(locLogicalName: string, value: any) {
    let locator: string = '';

    switch (locLogicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[1];
        break;
      default:
        break;
    }
    cy.cType(locator, locLogicalName, value);
  }

  /**
   * @details - select Dropdown In Block Scheduling
   * @param logicalName
   * @param value
   * @Api - API's are not available
   */
  selectDropdownInBlockScheduling(logicalName: any, value: any) {
    let loc = '';
    switch (logicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[1];

        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTH_ON[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTH_ON[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[1];
        break;
      default:
        break;
    }

    if (logicalName == OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0]) {
      cy.cClick(loc, logicalName);
      cy.cClick(
        selectorFactory.getDropdownValueInConfigurations(value),
        logicalName
      );
      cy.cRemoveMaskWrapper(Application.office);
    } else if (
      logicalName == OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0]
    ) {
      cy.cClick(loc, logicalName);
      cy.cClick(
        selectorFactory.getDropdownValueInConfigurations(value),
        logicalName
      );
      cy.cRemoveMaskWrapper(Application.office);
    } else {
      cy.cSelectDropdown(loc, logicalName, value, true);
    }
  }

  /**
   * @details - Select block out toggle button
   * @param logicalName
   * @Api - API's are not available
   */
  selectBlockOutToggleButton(logicalName: string) {
    let loc = '';
    switch (logicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_OUT[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_OUT[1];
        break;
      default:
        break;
    }
    cy.cClick(loc, logicalName);
  }

  /**
   * @details - select Monthly Week Days Dropdown In Block Scheduling
   * @param selectMonthlyWeekDays
   * @Api - API's are not available
   */
  selectMonthlyWeekDays(value: any) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTH_ON[1],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTH_ON[0]
    );
    let valueArray: any = value;
    valueArray.forEach((val: string) => {
      cy.cGet(OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTHLY_WEEKDAYS[1])
        .contains(val)
        .click({
          force: true,
        });
    });
    cy.cRemoveMaskWrapper(Application.charts);
    cy.cClick(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTH_ON[1],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTH_ON[0]
    );
  }

  /**
   * @details - click on add button to create new preference card
   * @Api - API's are not available
   */
  clickOnAdd() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );
  }

  /**
   * @details - Select preference card verify Duplicate Message PreferenceCardName
   * @param name - Pass Duplicate Preference Card Name
   * @param message - Duplicate Preference Card Message
   * @Api - API's are not available
   */
  verifyDuplicateMessagePreferenceCardName(name: string, message: string) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0],
      name
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DUPLICATE_MESSAGE[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DUPLICATE_MESSAGE[0],
      message
    ).cIsVisible(
      selectorFactory.getSmallText(AppErrorMessages.duplicate_preference_card),
      AppErrorMessages.duplicate_preference_card
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[0]
    );
  }

  /**
   * @details - Select preference card verify Copy PreferenceCard Name
   * @param copyPreferenceCardName
   * @Api API's are not available
   */
  VerifyPreferenceCardCopy(copyPreferenceCardName: string) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.CREATE_COPY[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.CREATE_COPY[0]
    );
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_DROP_DOWN[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_DROP_DOWN[0]
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0]
    ).cHasValue(
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0],
      copyPreferenceCardName
    );
    cy.cClear(OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1]);
    cy.cIsEnabled(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0],
      false,
      false
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.CANCEL_BUTTON[0]
    );
  }

  /**
   * @details - Select preference card Verify PreferenceCard Banner
   * @param   - preferenceCardWarningBanner
   * @Api API's are not available
   */
  VerifyPreferenceCardBanner(preferenceCardWarningBanner: string) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_SELECTED_ITEM[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_SELECTED_ITEM[0]
    );
    cy.cClear(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_NAME[1]
    );
  }

  /**
   * @details - click On Duration And Verify
   * @param duration
   * @Api API's are not available
   */
  clickOnDurationBoxAndVerify(duration: any) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[0]
    );
    cy.cHasValue(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[0],
      duration
    ).cClear;
  }

  /**
   * @details - click On CleanUpTime And Verify
   * @param cleanUpTime
   * @Api API's are not available
   */
  clickOnCleanUpTimeBoxAndVerify(cleanUpTime: any) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CLEAN_UP_TIME[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CLEAN_UP_TIME[0]
    );
    cy.cHasValue(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CLEAN_UP_TIME[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CLEAN_UP_TIME[0],
      cleanUpTime
    );
  }

  /**
   * @details - click On CleanUpTime text And Verify
   * @param   - minutesText
   * @Api API's are not available
   */
  clickOnCleanUpTimeTextAndVerify(minutesText: any) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .CLEAN_UP_MINS_TEXT[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .CLEAN_UP_MINS_TEXT[0]
    );
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .CLEAN_UP_MINS_TEXT[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .CLEAN_UP_MINS_TEXT[0],
      minutesText
    );
  }

  /**
   * @details - click On Duration text And Verify
   * @param   - minutesText
   * @Api API's are not available
   */
  clickOnDurationMinutesTextAndVerify(minutesText: any) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .DURATION_MINS_TEXT[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .DURATION_MINS_TEXT[0]
    );
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .DURATION_MINS_TEXT[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .DURATION_MINS_TEXT[0],
      minutesText
    );
  }

  /**
   * @details - clickOn CPT Trademark Text And Verify
   * @param   - CPTTrademark
   * @Api API's are not available
   */
  clickOnCPTTrademarkTextAndVerify(CPTTrademark: any) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CPT_TRADEMARK[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CPT_TRADEMARK[0]
    );
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CPT_TRADEMARK[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CPT_TRADEMARK[0],
      CPTTrademark
    );
  }

  /**
   * @details - Enter value in text fields
   * @param locLogicalName
   * @param value
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  preferenceCardText(locLogicalName: string, value: any) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectSpecialityPeferenceCard();
    let locator: string = '';
    switch (locLogicalName) {
      case OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0]:
        locator = OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1];
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[0]:
        locator =
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[1];
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .CLEAN_UP_TIME[0]:
        locator =
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CLEAN_UP_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PHYSICIAN_PREFERENCES[0]:
        locator =
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[1];
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[0]:
        locator =
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[1];
        break;
      default:
        break;
    }
    cy.cType(locator, locLogicalName, value);

    if (locator == OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1]) {
      cy.cIntercept(interceptCollection);
      cy.cClick(
        OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
        OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0]
      );
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - Click on caseSpecialty DopDown
   * @Api API's are not available
   */
  clickOnCaseSpecialtyDropdown() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CASE_SPECIALTY[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CASE_SPECIALTY[0]
    );
  }

  /**
   * @details - Click on AppointmentType DopDown
   */
  clickOnAppointmentTypeDropdown() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .APPOINTMENT_TYPE[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .APPOINTMENT_TYPE[0]
    );
  }

  /**
   * @details - Click on Anesthesia DopDown
   */
  clickOnAnesthesiaDropdown() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .ANESTHESIA_TYPE[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ANESTHESIA_TYPE[0]
    );
  }

  /**
   * @details - Click on Physician DropDown
   */
  clickOnPhysicianDropdown() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0]
    );
  }

  /**
   * @details - click On Existing PreferenceCard and verify
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  clickOnExistingPreferenceCard() {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectPreferenceCardConfiguration();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CONFIGURATION[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CONFIGURATION[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .EXISTING_PREFERENCE_CARD[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .EXISTING_PREFERENCE_CARD[0]
    );
  }

  /**
   * @details - click On Procedure SelectedItem And Verify
   * @param value
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  clickOnProcedureSelectedItemAndVerify(value: any) {
    const interceptCollection =
      this.nursingConfigApis.interceptProcedureSearchPreferenceCard();
    cy.cType(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[0],
      value
    );
    cy.cIntercept(interceptCollection);
    cy.contains(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[0],
      value
    ).click();
    cy.cWaitApis(interceptCollection);
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[0],
      value
    );
  }

  /**
   * @details - select And Verify CaseSpecialty ListItem(
   * @param value
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  selectAndVerifyCaseSpecialtyListItem(value: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectSpecialityPeferenceCard();
    cy.cIntercept(interceptCollection);
    cy.cSelectListItem(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CASE_SPECIALTY[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.CASE_SPECIALTY[0],
      value
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select CaseSpecialty ListItem(
   * @param caseSpecialty
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  preferenceCardcaseSpecialtyItem(caseSpecialty: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectSpecialityPeferenceCard();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getDropdownSpecialtyValuesInConfigurations(caseSpecialty),
      caseSpecialty
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select CaseSpecialty ListItem(
   * @param appointmentType
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  preferenceCardAppointmentTypeDropdownItem(appointmentType: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectSpecialityPeferenceCard();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getDropdownValueInConfigurations(appointmentType),
      appointmentType
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select Anesthesia ListItem(
   * @param anesthesia
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  preferenceCardAnesthesiaDropdownItem(anesthesia: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectSpecialityPeferenceCard();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getDropdownValueInConfigurations(anesthesia),
      anesthesia
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select Physician ListItem(
   * @param physician
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  preferenceCardPhysicianDropdownItem(physician: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectSpecialityPeferenceCard();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getDropdownValueInConfigurations(physician),
      physician
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click Add And Verify Procedure ListItem(
   * @param procedure SelectedItem
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  clickAddAndVerifyProcedure(procedure: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptCaseCreationPreferenceCardDone();
    cy.cClick(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .ADD_PREFERENCE_CARD.ADD_BUTTON[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .ADD_PREFERENCE_CARD.ADD_BUTTON[0]
    );
    cy.cIsVisible(selectorFactory.getSpanText(procedure), procedure);
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .ADD_PREFERENCE_CARD.DONE_BUTTON[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS
        .ADD_PREFERENCE_CARD.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Method to verify text and check visibility of element
   * @param logicalName
   * @pram value
   * @Api API's are not available
   */
  verifyPreferenceCardFieldData(logicalName: string, value: string) {
    let locator: string = '';
    switch (logicalName) {
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .CASE_SPECIALTY[0]:
        locator =
          selectorFactory.getDropdownSpecialtyValuesInConfigurations(value);
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0]:
        locator = selectorFactory.getDropdownValueInConfigurations(value);
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .ANESTHESIA_TYPE[0]:
        locator = selectorFactory.getDropdownValueInConfigurations(value);
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .APPOINTMENT_TYPE[0]:
        locator = selectorFactory.getDropdownValueInConfigurations(value);
        break;
      case OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PHYSICIAN_PREFERENCES[0]:
        locator =
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[1];
        break;
      default:
        break;
    }

    if (
      logicalName ==
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PHYSICIAN_PREFERENCES[0]
    ) {
      cy.cHasValue(locator, logicalName, value);
    } else {
      cy.cIsVisible(locator, logicalName);
    }
  }

  /**
   * @details - Method to verify text and check visibility of element
   * @Api API's are not available
   */
  verifyTrashIcon() {
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_SELECTED_ITEM[1]
    ).trigger(TriggerAttributes.mouseover);
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.TRASH_ICON[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.TRASH_ICON[0]
    );
  }

  /**
   * @details - Method to verify Procedure and check visibility of element
   * @param procedure
   * @Api API's are not available
   */
  verifyProcedure(procedure: string) {
    cy.contains(procedure).click();
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PROCEDURE_SELECTED_ITEM[1]
    )
      .contains(procedure)
      .should(ShouldMethods.visible);
  }

  /**
   * @details - Select Preference Card from the list and Mouse hover on the Preference Card in the list
   * @param value
   * @Api API's are not available
   */
  selectAndVerifyPreferenceCardListItem(value: string) {
    cy.cSelectListItem(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_SELECTED_ITEM[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_SELECTED_ITEM[0],
      value
    );
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_SELECTED_ITEM[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
        .PREFERENCE_CARD_SELECTED_ITEM[0]
    );
  }

  /**
   * @details - Select all dropdown values
   * @param logicalName
   * @param value
   * @Api API's are not available
   */
  enterBlockDetailsInBlockScheduling(logicalName: any, value: any) {
    let loc = '';
    switch (logicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[1];
        break;
      default:
        break;
    }

    if (logicalName == OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0]) {
      cy.cClick(loc, logicalName);
      cy.cClick(
        selectorFactory.getDropdownValueInConfigurations(value),
        logicalName
      );
      cy.cRemoveMaskWrapper(Application.office);
    } else if (
      logicalName == OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0]
    ) {
      cy.cClick(loc, logicalName);
      cy.cClick(
        selectorFactory.getDropdownValueInConfigurations(value),
        logicalName
      );
      cy.cRemoveMaskWrapper(Application.office);
    } else {
      cy.cSelectDropdown(loc, logicalName, value, true);
    }
  }

  /**
   * @details - add data entities to block scheduling
   * @param locLogicalName
   * @param value
   * @Api API's are not available
   */
  blockSchedulingText(locLogicalName: string, value: any) {
    let locator: string = '';

    switch (locLogicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[1];
        break;
      default:
        break;
    }
    cy.cType(locator, locLogicalName, value);
  }

  /**
   * @details - VerifyBlockScheduleErrors
   * @param type (Exist or notExist), Error
   * @Api API's are not available
   */
  VerifyBlockScheduleErrors(type: string, Error: any) {
    if (type == Existence.exist) {
      cy.cIsVisible(Error, ' ', true);
    } else {
      cy.cNotExist(Error, ' ', true);
    }
  }

  /**
   * @details - Select from existing block
   * @param blockName
   * @Api API's are not available
   */
  selectExistingBlock(blockName: any) {
    cy.cType(this.OR_COMMON.SEARCH[1], this.OR_COMMON.SEARCH[0], blockName);
    cy.cGet(this.OR_BLOCK_SCHEDULING.SELECT_BLOCK_SCHEDULE[1])
      .contains(blockName)
      .click();
  }

  /**
   * @details - Select all dropdown values
   * @param logicalName
   * @param value
   * @Api API's are not available
   */
  enterBlockDetailsInBlockSchedulingDropdowns(logicalName: any, value: any) {
    let loc = '';
    switch (logicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[1];
        break;
      default:
        break;
    }

    if (logicalName == OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0]) {
      cy.cClick(loc, logicalName);
      cy.cClick(
        selectorFactory.getDropdownValueInConfigurations(value),
        logicalName
      );
      cy.cRemoveMaskWrapper(Application.office);
    } else if (
      logicalName == OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0]
    ) {
      cy.cClick(loc, logicalName);
      cy.cClick(
        selectorFactory.getDropdownValueInConfigurations(value),
        logicalName
      );
      cy.cRemoveMaskWrapper(Application.office);
    } else if (
      logicalName ==
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0]
    ) {
      cy.cClick(loc, logicalName);
      value.forEach((val: string[]) => {
        cy.cClick(
          selectorFactory.getMonthlyWeekdaysDropdown(val),
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0]
        );
      });
      cy.cRemoveMaskWrapper(Application.charts);
      cy.cClick(loc, logicalName);
    } else {
      cy.cSelectDropdown(loc, logicalName, value, true);
    }
  }

  /**
   * @details - add data entities to block scheduling
   * @param locLogicalName
   * @param value
   * @Api API's are not available
   */
  blockSchedulingTextInputField(locLogicalName: string, value: any) {
    let locator: string = '';

    switch (locLogicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[1];
        break;
      default:
        break;
    }
    cy.cType(locator, locLogicalName, value);
    cy.cClick(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
      true
    );
  }

  /**
   * @details - add data entities to block scheduling
   * @param locLogicalName
   * @param value
   * @Api API's are not available
   */
  verifyBlockSchedulingTextInputFieldValue(locLogicalName: string, value: any) {
    let locator: string = '';

    switch (locLogicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[0]:
        locator = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[1];
        break;
      default:
        break;
    }
    cy.cHasValue(locator, locLogicalName, value);
  }

  /**
   * @details - Select Weekly And Monthly Radio Button in block scheduling page
   * @param logicalName
   * @Api API's are not available
   */
  selectWeeklyAndMonthlyRadioButton(logicalName: string) {
    let loc = '';
    switch (logicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTHLY[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTHLY[1];
        break;
      default:
        break;
    }
    cy.cClick(loc, logicalName);
  }

  /**
   * @details - Select Monthly week days dropdown in block scheduling
   * @param value
   * @Api API's are not available
   */
  selectMonthlyWeeKDays(value: string[]) {
    cy.cSelectDropdown(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[1],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
      value,
      true
    );
  }

  /**
   * @Api API's are not available
   */
  blockScheduleVerifyDropdownValuesDisplayed(logicalName: string, value: any) {
    let loc = '';
    switch (logicalName) {
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_COLOR[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[1];
        break;
      case OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0]:
        loc = OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[1];
        break;
      default:
        break;
    }
    cy.cClick(loc, logicalName);
    cy.cIncludeText(
      selectorFactory.getNurConfMultiselectDropdownItems(),
      logicalName,
      value
    );
    cy.cRemoveMaskWrapper(Application.charts);
    cy.cClick(loc, logicalName);
  }

  /**
   * Method to click block schedule subheader to focus away from specific field
   */
  clickBlockScheduleSubheader() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SUB_HEADER[1],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SUB_HEADER[0]
    );
  }

  /**
   * @details - Verify dictionary UI
   * @param element
   */
  verifyDictionaryUI(element: any) {
    let locator: string = '';

    switch (element) {
      case OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE[0]:
        locator = OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE[1];
        break;
      case OR_NURSING_CONFIGURATION.DICTIONARY.ADD_ITEM[0]:
        locator = OR_NURSING_CONFIGURATION.DICTIONARY.ADD_ITEM[1];
        break;
      case OR_NURSING_CONFIGURATION.DICTIONARY.ITEM_HEADER[0]:
        locator = OR_NURSING_CONFIGURATION.DICTIONARY.ITEM_HEADER[1];
        break;
      case OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_HEADER[0]:
        locator = OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_HEADER[1];
        break;
      case OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[0]:
        locator = OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[1];
        break;
      case OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[0]:
        locator = OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[1];
        break;
      default:
        break;
    }

    cy.cIsVisible(locator, element);
  }

  /**
   * @details - Verify Dictionary Items
   * @param dictionaryItem : dictionary Item Name
   */
  verifyDictionaryItem(dictionaryItem: string) {
    cy.cIsVisible(dictionaryItem, dictionaryItem, true);
  }

  /**
   * @details - click Dictionary Items
   * @param dictionaryItem : dictionary Item Name
   * @Api API's are not available
   */
  clickDictionaryItem(dictionaryItem: string) {
    cy.cGet(OR_NURSING_CONFIGURATION.DICTIONARY.ITEM_CONTAINER[1])
      .contains(dictionaryItem)
      .parent()
      .click();
  }

  /**
   * @details - Verify item Shown Count
   * @param item : total item count
   * @param shown : total Shown count
   * @param showInActive : show inactive toggle (yes= true, no= false)
   */
  itemShownCount(showInActive: boolean, item: any, shown?: any) {
    if (showInActive === false) {
      let text: string = CommonUtils.concatenate(
        item,
        ItemShow.item,
        shown,
        ItemShow.shown
      );
      cy.cIsVisible(text, text, true);
    } else {
      let text: string = CommonUtils.concatenate(item, ItemShow.item);
      cy.cIsVisible(text, text, true);
    }
  }

  /**
   * @details - click dictionary add item
   * @Api API's are not available
   */
  addItemBtn() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARY.ADD_ITEM[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.ADD_ITEM[0]
    );
  }

  /**
   * @details -To click on  searched procedure in contracts review/edit
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  clickOnSearchedProcedureInContract() {
    const interceptCollection =
      this.nursingConfigApis.interceptContractSearchedProcedureApi();
    cy.cRemoveMaskWrapper(Application.office);
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1]
    );

    cy.cIntercept(interceptCollection);
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[0]
    ).dblclick({ force: true });
    cy.cWaitApis(interceptCollection);
    // Added Additional click because the user interface was taking some time to complete even after the API had finished.
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONTRACTS.PROCEDURES_LABEL[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.PROCEDURES_LABEL[0]
    ).click({ force: true });
  }

  /**
   * @details -To select procedure type in contracts review/edit
   * @param - value as selecting the value of the procedure type
   * @Api API's are available - Implemented Completely
   */
  selectProcedureTypeInContract(value: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptContractSaveProcedureTypeApi();
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[0]
    ).dblclick({ force: true });
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[0],
      false,
      false,
      { force: true }
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.TYPE_DROPDOWN_CONTRACTS[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.TYPE_DROPDOWN_CONTRACTS[0],
      false,
      false,
      { force: true }
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_NURSING_CONFIGURATION.CONTRACTS.REVIEW_TYPE[1],
        selectorFactory.getSpanText(value)
      ),
      OR_NURSING_CONFIGURATION.CONTRACTS.REVIEW_TYPE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To search procedure in contracts in review/edit
   * @param - value as searching the procedure in contracts in review/edit
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  searchProcedureInContract(value: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptProcedureSearchContract();
    cy.cRemoveMaskWrapper(Application.office);
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.CONTRACTS.SEARCH_PROCEDURE_IN_CONTRACTS[1]
    );
    cy.cGet(OR_NURSING_CONFIGURATION.CONTRACTS.SEARCH_PROCEDURE_IN_CONTRACTS[1])
      .focus()
      .click({ force: true })
      .then(() => {
        cy.cIntercept(interceptCollection);
        cy.cType(
          OR_NURSING_CONFIGURATION.CONTRACTS.SEARCH_PROCEDURE_IN_CONTRACTS[1],
          OR_NURSING_CONFIGURATION.CONTRACTS.SEARCH_PROCEDURE_IN_CONTRACTS[0],
          value
        );
        cy.cWaitApis(interceptCollection);
      });
    this.clickOnSearchedProcedureInContract();
  }

  /**
   * @details - Method to verify Outbound CCDA flag in Add On Features
   */
  verifyOutboundCCDAFlag() {
    cy.cGet(OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.OUTBOUND_CCDA.FLAG[1])
      .trigger(TriggerAttributes.mouseover)
      .should(ShouldMethods.visible);
  }

  /**

   * @details - Add item in inout text field
   * @param text : input text
   * @Api API's are not available
   */
  addItemInput(text: string) {
    cy.cType(
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[0],
      text
    );
    this.confirmWarningDialog();
  }

  /**
   * @details - Click Active Yes No toggle
   * @param - activeToggle
   * @Api API's are not available
   */
  selectActiveToggle(isActive: string) {
    const toggleSelector = selectorFactory.dicActiveToggle(
      isActive ? YesOrNo.yes : YesOrNo.no
    );
    const toggleText = isActive ? YesOrNo.yes : YesOrNo.no;
    cy.cClick(toggleSelector, toggleText);
  }

  /**
   * @details - Click Show Inactive Yes No toggle
   * @param - toggle
   * @api API's are not available
   */
  selectShowInactiveToggle(toggle: boolean) {
    this.confirmWarningDialog();
    if (toggle == true) {
      cy.cClick(
        selectorFactory.dicShowInactiveToggle(YesOrNo.yes),
        YesOrNo.yes
      );
    } else {
      cy.cClick(selectorFactory.dicShowInactiveToggle(YesOrNo.no), YesOrNo.no);
    }
  }

  /**
   * @details - Verify active dictionary toggle
   * @param - toggleName,toggleButton
   */
  verifyDictionaryActiveToggle(toggleName: string, toggleButton: string) {
    let loc = '';
    switch (toggleName) {
      case OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE[0]:
        loc = selectorFactory.dicShowInactiveToggle(toggleButton);
        break;

      case OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[0]:
        loc = selectorFactory.dicActiveToggle(toggleButton);
        break;
      default:
        break;
    }
    cy.cHasClass(loc, toggleName, CommonClassAttributes.phighlight);
  }

  /**
   * @details - Verify confirm Warning Dialog
   * @Api API's are not available
   */
  confirmWarningDialog() {
    cy.cGet(CommonGetLocators.body).then((body) => {
      if (
        body.find(OR_NURSING_CONFIGURATION.DICTIONARY.CONFIRM_DIALOG[1])
          .length > 0
      ) {
        cy.cIsVisible(AppErrorMessages.duplicate_gender_identity, ' ', true);
        cy.cClick(
          OR_NURSING_CONFIGURATION.DICTIONARY.CONFIRM_DIALOG[1],
          OR_NURSING_CONFIGURATION.DICTIONARY.CONFIRM_DIALOG[0]
        );
      }
    });
  }
  /**
   * @details - Method to verify Outbound CCDA state in SIS gateway
   * @param state - Enable or Disable state to be verified
   */
  verifyGatewayConfigState(state: string) {
    state === EnableOrDisable.disable
      ? cy.cIsVisible(
          OR_NURSING_CONFIGURATION.SIS_GATEWAY_CONFIG.OUTBOUND_CCDA.DISABLE[1],
          OR_NURSING_CONFIGURATION.SIS_GATEWAY_CONFIG.OUTBOUND_CCDA.DISABLE[0]
        )
      : cy.cIsVisible(
          OR_NURSING_CONFIGURATION.SIS_GATEWAY_CONFIG.OUTBOUND_CCDA.ENABLE[1],
          OR_NURSING_CONFIGURATION.SIS_GATEWAY_CONFIG.OUTBOUND_CCDA.ENABLE[0]
        );
  }

  /**
   * @details - Method to verify Tobacco Use item in Reporting Codes
   * @param value - Item to be verified
   * @param flag - Presence or Un-presence
   */
  verifyTobaccoInReportingCodes(value: string, flag: boolean) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0],
      value
    );

    flag ? cy.cIsVisible(value, value, true) : cy.cNotExist(value, value);
  }

  /**
   * @details - Method to verify CCDA Code column in Reporting Codes
   * @param value - CCDA Code or State Code
   * @param flag - Presence or Un-presence
   */
  verifyCCDACodeCol(value: string, flag: boolean) {
    const loc = selectorFactory.getDivText(value);
    flag ? cy.cIsVisible(value, value, true) : cy.cNotExist(loc, value);
  }

  /**
   * @details - Method to verify Entered CCDA Code in Reporting Codes
   * @param value - State or CCDA Code to be verified
   */
  verifyStateOrCCDACode(value: string) {
    const loc = selectorFactory.getDivText(value);
    cy.cGet(loc).contains(value).should(ShouldMethods.visible);
  }

  /**
   * @details - verifying the mouse hover text for options
   * @param code - CCDA Code displayed
   * @param val - On hover text to be verified
   */
  verifyCCDACodeOnHoverText(code: string, val: string) {
    const loc = selectorFactory.getSpanText(code);
    cy.cHasAttribute(
      loc,
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[0],
      InvokeAttributes.text,
      val
    );
  }

  /**
   * @details - Select an item from Reporting codes list
   * @param itemName - Dictionary item name in Reporting codes
   * @Api API's are not available
   */
  selectReportingCodesItem(itemName: string) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0],
      itemName
    );
    cy.cClick(itemName, itemName, true, true);
  }

  /**
   * @details - Add new dictionary item for any Dictionary
   * @param dicItem - Dictionary name
   * @param itemName - Dictionary item name to be added
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  addDictionaryItem(dicItem: string, itemName: string) {
    const interceptCollection = this.nursingConfigApis.interceptDictionaryAdd();
    this.selectDictionary(dicItem);
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARIES.ADD_ITEM[1],
      OR_NURSING_CONFIGURATION.DICTIONARIES.ADD_ITEM[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.DICTIONARIES.ITEM[1],
      OR_NURSING_CONFIGURATION.DICTIONARIES.ITEM[0],
      itemName,
      false,
      true
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARIES.SHOW_INACTIVE[1],
      OR_NURSING_CONFIGURATION.DICTIONARIES.SHOW_INACTIVE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify new dictionary item added in Dictionaries in Reporting codes
   * @param dicItem - Dictionary name
   * @param itemName - Dictionary item name to be verified
   */
  verifyNewDicItemsInReportingCodes(dicName: string, itemName: string) {
    this.selectReportingCodesItem(dicName);
    const loc = selectorFactory.getSpanText(itemName);
    cy.cIsVisible(loc, itemName);
  }

  /**
   * @details - Select an item from Dictionaries List
   * @param dicItem - Dictionary name
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  selectDictionary(dicItem: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectDictionary();
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARIES.SEARCH_FIELD[1],
      OR_NURSING_CONFIGURATION.DICTIONARIES.SEARCH_FIELD[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.DICTIONARIES.SEARCH_FIELD[1],
      OR_NURSING_CONFIGURATION.DICTIONARIES.SEARCH_FIELD[0],
      dicItem
    );
    cy.cIntercept(interceptCollection);
    Array.from({ length: 3 }).forEach(() => {
      cy.cClick(dicItem, dicItem, true, true);
    });
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify show inactive labels
   * @param - item
   * @api API's are not available
   */
  verifyShowInActiveLabels(item: string) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE_LABEL[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE_LABEL[0]
    );
    cy.contains(item)
      .parents(OR_NURSING_CONFIGURATION.DICTIONARY.ROW_ID[1])
      .within(($ele) => {
        cy.wrap($ele)
          .cGet(CommonGetLocators.td)
          .eq(1)
          .should(ShouldMethods.contain_text, YesOrNo.yes);
      });
  }

  /**
   * @details - Expand Unreleased feature
   * @Api API's are not available
   */
  expandUnreleased() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.ADD_ON_FEATURE[1],
      OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.ADD_ON_FEATURE[0]
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.UNRELEASED_FEATURE[1],
      OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.UNRELEASED_FEATURE[0]
    );
  }

  /**
   * @details - To verify CCDA Col and CCDA Codes in Reporting Codes
   * @param itemName - Dictionary name
   * @param rowName - Dictionary item name the list
   * @param codeName - CCDA Code Name to be verified
   * @param value - On hover text to be verified.
   * @Api API's are available - Not Implemented
   */
  verifyCCDAColAndCodesReportingCodes(
    itemName: string,
    rowName: string,
    codeName: string,
    value: string
  ) {
    const search_input = '%%%';
    const number = 2000;
    this.selectReportingCodesItem(itemName);
    this.verifyCCDACodeCol(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[0],
      true
    );

    // Selecting a row, always focus is on state code. Clicking twice. First one to focus on row and second click is to click on element
    //TODO: Need to implement API
    cy.cClick(rowName, itemName, true);
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[1],
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[0]
    );
    cy.cClick(rowName, itemName, true);
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[1],
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[0]
    );

    cy.cClick(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[1],
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[1],
      OR_NURSING_CONFIGURATION.REPORTING_CODES.CCDA_CODE[0],
      search_input
    );
    cy.cWaitForElementToDisappear(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.ICON_IN_PROGRESS[1],
      OR_SCHEDULE_GRID.LOADING_SPINNER[0],
      number
    );
    cy.cClick(value, value, true);
    cy.cClick(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.REPORTING_CODES[1],
      OR_NURSING_CONFIGURATION.REPORTING_CODES.REPORTING_CODES[0]
    );
    this.verifyStateOrCCDACode(codeName);
    this.verifyCCDACodeOnHoverText(codeName, value);
  }

  /**
   * @details - To verify the add button state in transaction in application setting
   * @param enable - To check the done button is enabled we need to pass enable true, or else pass false
   * @API - API's are not available
   */
  verifyStateOfAddButton(enable: boolean = true) {
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );
    cy.cIsEnabled(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0],
      false,
      enable
    );
    if (enable === false) {
      cy.cGet(
        OR_NURSING_CONFIGURATION.TRANSACTION_CODES.ADD_BUTTON_WHEN_DISABLED[1]
      )
        .trigger(TriggerAttributes.mouseover)
        .should(ShouldMethods.visible)
        .invoke(InvokeMethods.attribute, InvokeAttributes.title)
        .then(($text) => {
          expect($text).to.contains(HelpText.on_hover_add_when_disabled);
        });
    }
  }

  /**
   * @details - click on add button in discount screen at application settings
   *  @Api API's are not available
   */
  clickOnAddInDiscount() {
    cy.cClick(this.OR_COMMON.ADD_BUTTON[1], this.OR_COMMON.ADD_BUTTON[0]);
  }

  /**
   * @details -To add new discount
   * @param input  -To write the discount name
   * @param option -To click done or cancel in popup window
   * @API - API's are available - Implemented Completely
   * @author Arushi
   */
  addDiscount(input: string, option: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectTransactionCode();
    this.clickOnAddInDiscount();
    cy.cClick(
      OR_NURSING_CONFIGURATION.DISCOUNTS.ADD_DISCOUNT_SEARCH_FIELD[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.ADD_DISCOUNT_SEARCH_FIELD[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.DISCOUNTS.ADD_DISCOUNT_SEARCH_FIELD[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.ADD_DISCOUNT_SEARCH_FIELD[0],
      input
    );
    switch (option) {
      case DoneOrCancel.done:
        cy.cIntercept(interceptCollection);
        cy.cClick(
          selectorFactory.getAddDiscountsFooter(option),
          option,
          false,
          true
        );
        cy.cWaitApis(interceptCollection);
        break;

      case DoneOrCancel.cancel:
        cy.cClick(
          selectorFactory.getAddDiscountsFooter(option),
          option,
          false,
          true
        );
        break;
      default:
        break;
    }
  }

  /**
   * @details -To enter value in discount percentage field
   * @param option -Discount value to be enter in percentage field
   * @API - API's are not available
   */
  enterValuesInDiscountPercentField(option: string) {
    cy.cType(
      OR_NURSING_CONFIGURATION.DISCOUNTS.DISCOUNT_PERCENT[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.DISCOUNT_PERCENT[0],
      option
    );
  }

  /**
   * @details -To search the discount from search field
   * @param code -To provide the discount to be search
   * @Api API's are not available
   */
  searchDiscount(code: string) {
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0],
      code,
      false,
      true
    );
  }

  /**
   * @details -To verify the discounts exists or not in the lists
   * @param code -To provide the discount to be search
   * @param option -To provide boolean true or false
   * @API - API's are not available
   */
  verifyDiscountExists(code: string, option: boolean = true) {
    this.searchDiscount(code);
    option
      ? cy.cIsVisible(selectorFactory.getTransactionItem(code), code)
      : cy.cNotExist(selectorFactory.getTransactionItem(code), code);
  }

  /**
   * @details -To search and select the discount from the list
   * @param discountName - Pass the discount to be select
   * @API - API's are not available
   */
  searchAndSelectDiscount(discountName: string) {
    this.searchDiscount(discountName);
    cy.cClick(
      CommonUtils.concatenate(
        OR_NURSING_CONFIGURATION.DISCOUNTS.DISCOUNTS_LISTS[1],
        selectorFactory.getDivText(discountName)
      ),
      discountName,
      false,
      true
    );
  }

  /**
   * @details - verify the source field in discount
   * @param value - enter data to be verified
   *  @API - API's are not available
   */
  verifyDiscountSourceField(value: string) {
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.DISCOUNTS.SOURCE_FIELD_IN_DISCOUNT[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.SOURCE_FIELD_IN_DISCOUNT[0],
      value
    );
  }

  /**
   * @details -To verify the transaction code dropdown placeholder value in discount screen
   * @param type -To provide the type value that is expected to be selected for the discount
   *  @API - API's are not available
   */
  verifyTransactionCodeField(type: string) {
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.DISCOUNTS.TRANSACTION_CODE[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.TRANSACTION_CODE[0],
      type
    );
  }

  /**
   * @details -To verify the writeoff group code dropdown placeholder value in discount screen
   * @param type -To provide the writeoff group code value that is expected to be selected for the discount
   *  @API - API's are not available
   */
  verifyWriteOffGroupCodeField(type: string) {
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.DISCOUNTS.WRITEOFF_GROUP_CODE[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.WRITEOFF_GROUP_CODE[0],
      type
    );
  }

  /**
   * @details -To verify the writeoff reason code dropdown placeholder value in discount screen
   * @param type -To provide the writeoff reason code value that is expected to be selected for the discount
   *  @API - API's are not available
   */
  verifyWriteOffReasonCodeField(type: string) {
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.DISCOUNTS.WRITEOFF_REASON_CODE[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.WRITEOFF_REASON_CODE[0],
      type
    );
  }

  /**
   * @details -To verify the discount percentage field
   * @param value -enter the value to be verify
   *  @API - API's are not available
   */
  verifyDiscountPercentField(value: string) {
    cy.cHasValue(
      OR_NURSING_CONFIGURATION.DISCOUNTS.DISCOUNT_PERCENT[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.DISCOUNT_PERCENT[0],
      value
    );
  }

  /**
   * @details -To click transaction code dropdown
   */
  clickTransactionCodeInDiscount() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.DISCOUNTS.TRANSACTION_CODE[1],
      OR_NURSING_CONFIGURATION.DISCOUNTS.TRANSACTION_CODE[0]
    );
  }

  /**
   * @details - select option from transaction code dropdown in discount at application setting
   * @param transactionType - dropdown value to be selected
   * @API - API's are available -Implemented Completely
   * @author Arushi
   */
  selectDiscountTransactionCode(transactionType: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectTransactionCode();
    this.clickTransactionCodeInDiscount();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getSpanText(transactionType),
      transactionType,
      false,
      true,
      { force: true }
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select Yes or No for Include Insurance Charges toggle under Patient Statements
   * @param value - yes/no needs to be passed in order to enable or disable
   * @Api API's are available - Not Implemented
   */
  selectIncludeInsuranceCharges(value: string) {
    cy.cWaitForElementToDisappear(
      selectorFactory.getH4Text(ShowPatients.show_patients),
      ShowPatients.show_patients,
      number
    );
    cy.cGet(
      OR_NURSING_CONFIGURATION.INCLUDE_CHARGES_UNASSIGNED_PAY_TOGGLE[1]
    ).each(($element) => {
      const cls = $element.attr(InvokeAttributes.class)?.toString();
      if (cls?.includes(value)) {
        //TODO: Need to implement API
        cy.cClick(
          OR_NURSING_CONFIGURATION.ENABLE_INCLUDE_INSURANCE[1],
          OR_NURSING_CONFIGURATION.ENABLE_INCLUDE_INSURANCE[0]
        );
      }
    });
  }

  /**
   * @details - Verify Dictionary labels
   */
  verifyDictionaryLabels() {
    cy.cNotExist(
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[0]
    );
    cy.cNotExist(
      OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[0]
    );
  }

  /**
   * @details - Click dictionary show in active labels
   * @Api API's are not available
   */
  clickDictionaryInActiveLabel() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE_LABEL[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE_LABEL[0]
    );
  }

  /**
   * @details - Verify max length in dictionary
   * @param - num
   * @Api API's are not available
   */
  verifyMaxLength(num: number) {
    cy.cHasAttribute(
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[0],
      InvokeAttributes.maxlength,
      num
    );
  }

  /**
   * @details - Click on Include Insurance in Add on feature
   * @Api API's are available - Not Implemented
   * @author Arushi
   */

  clickOnIncludeInsurance(isEnabled: boolean = true) {
    cy.cGet(OR_NURSING_CONFIGURATION.PATIENT_STATEMENT_INSURANCE_CSV[1]).then(
      ($element) => {
        const cls = $element.attr(InvokeAttributes.class)?.toString();
        const shouldClick = isEnabled
          ? cls?.includes(CommonGetLocators.empty)
          : cls?.includes(CommonGetLocators.not_empty);

        if (shouldClick) {
          //TODO: Need to implement API
          cy.cClick(
            OR_NURSING_CONFIGURATION.INCLUDE_INSURANCE_ADDON[1],
            OR_NURSING_CONFIGURATION.INCLUDE_INSURANCE_ADDON[0]
          );
        }
      }
    );
  }

  /**
   * @details Search and select the consents value in search field
   * @param name - to pass the consents value
   * @Api API's are available -Not Implemented
   */
  searchConsentsValue(name: string) {
    // Type the name in search box
    cy.cType(this.OR_COMMON.SEARCH[1], this.OR_COMMON.SEARCH[0], name);
    cy.contains(name).then(($element) => {
      if (Cypress.dom.isAttached($element!)) {
        cy.cClick(name, name, true);
      }
    });
  }

  /**
   * @details Insert the variables in the consents template
   * @param consentTemplate - E.g. 0, 1 based on the index
   * @param consentsInfo - using insert variable from consents model
   * @Api API's are not available
   *
   */
  insertVariablesInConsentTemplate(
    consentTemplate: number,
    consentsInfo: Consents
  ) {
    if (consentTemplate == 0) {
      this.nursingConfigurationLayout.selectConfiguration(
        OR_NURSING_CONFIGURATION.CONSENTS.SUB_HEADER[0]
      );
      this.searchConsentsValue(consentsInfo.ConsentName);
    }
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONSENTS.INSERT_VARIABLES.EDITOR_CONTAINER[1]
    )
      .eq(consentTemplate)
      .then(($element) => {
        cy.wrap($element).within(() => {
          cy.cClick(
            CommonGetLocators.p,
            OR_NURSING_CONFIGURATION.CONSENTS.INSERT_VARIABLES.TEXT_AREA[0],
            false,
            true,
            { force: true }
          );
          cy.cType(
            CommonGetLocators.p,
            OR_NURSING_CONFIGURATION.CONSENTS.INSERT_VARIABLES.TEXT_AREA[0],
            consentsInfo.ConsentName
          );
          cy.cClick(
            OR_NURSING_CONFIGURATION.CONSENTS.INSERT_VARIABLES.DROP_DOWN[1],
            OR_NURSING_CONFIGURATION.CONSENTS.INSERT_VARIABLES.DROP_DOWN[0]
          );
          consentsInfo.InsertVariable!.forEach((variableName) => {
            cy.cClick(selectorFactory.getSpanText(variableName), variableName);
          });
          cy.cClick(
            OR_NURSING_CONFIGURATION.CONSENTS.INSERT_VARIABLES.INSERT_BUTTON[1],
            OR_NURSING_CONFIGURATION.CONSENTS.INSERT_VARIABLES.INSERT_BUTTON[0]
          );
        });
      });
  }

  /**
   * @details To clear the Modified Procedure in Fee Schedule
   * @param feeScheduleInfo
   *  @Api API's are available - Not Implemented
   *
   */
  clearModifiedProcedure(feeScheduleInfo: FeeSchedule) {
    this.nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.FEE_SCHEDULE.SUB_HEADER[0]
    );
    feeScheduleInfo.ProcedureName.forEach((proc) => {
      cy.cType(this.OR_COMMON.SEARCH[1], this.OR_COMMON.SEARCH[0], proc);
      cy.cClick(proc, proc, true, true);
    });
    cy.cClear(
      OR_NURSING_CONFIGURATION.FEE_SCHEDULE.MODIFIED_PROCEDURE_DESCRIPTION[1]
    );
    //TODO: Need to implement API
    //Click on any label after clearing the field
  }

  /**
   * @details To verify primary procedure only
   * @api API's are not available
   */
  verifyPrimaryProcedureOnly() {
    const primaryProcOnly =
      OR_NURSING_CONFIGURATION.CONSENTS.PRIMARY_PROCEDURE_ONLY_LABEL[0];
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONSENTS.PRIMARY_PROCEDURE_ONLY_LABEL[1]
    ).within(() => {
      cy.cHasText(
        selectorFactory.getLabelText(primaryProcOnly),
        primaryProcOnly,
        primaryProcOnly
      );
    });
  }

  /**
   * @details To verify single select dropdown
   * @Api API's are not available
   */
  verifySingleSelectDropDown() {
    cy.cGet(OR_NURSING_CONFIGURATION.CONSENTS.SINGLE_SELECT[1])
      .invoke(InvokeMethods.attribute, InvokeAttributes.ng_enabled)
      .then(($data) => {
        expect($data).to.contains(
          OR_NURSING_CONFIGURATION.CONSENTS.SINGLE_SELECT[0]
        );
      });
  }

  /**
   * @details To select primary procedure only
   * @param enableDisable - to provide either user wants to select Enable or Disable
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  selectPrimaryProcedureOnly(enableDisable: string = EnableOrDisable.enable) {
    const interceptCollection =
      this.nursingConfigApis.interceptProcedureDisplay();
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONSENTS.PRIMARY_PROCEDURE_ONLY_SWITCH[1]
    ).then(($ele) => {
      if (
        (enableDisable == EnableOrDisable.enable &&
          $ele.hasClass(CommonGetLocators.empty)) ||
        (enableDisable == EnableOrDisable.disable &&
          $ele.hasClass(CommonGetLocators.not_empty))
      ) {
        cy.cIntercept(interceptCollection);
        cy.cGet(CoreCssClasses.Toggle.loc_on_off_switch_label).click();
        cy.cWaitApis(interceptCollection);
      }
    });
  }

  /**
   * @details To verify procedure display dropdown values
   * @param consentsInfo
   * @api API's are not available
   */
  verifyProcedureDisplayAndDropdownValues(consentsInfo: Consents) {
    const procedureDisplay =
      OR_NURSING_CONFIGURATION.CONSENTS.PROCEDURE_DISPLAY;
    cy.cGet(procedureDisplay.DROP_DOWN[1]).within(() => {
      this.clickProcedureDisplayDropdown();
      consentsInfo.ProcedureDisplay?.forEach((proc) => {
        cy.contains(procedureDisplay.DROP_DOWN_VALUES[1], proc);
      });
    });
  }

  /**
   * @details To click on procedure display dropdown
   * @Api API's are not available
   */
  clickProcedureDisplayDropdown() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONSENTS.PROCEDURE_DISPLAY
        .DROP_DOWN_ARROW_ICON[1],
      OR_NURSING_CONFIGURATION.CONSENTS.PROCEDURE_DISPLAY
        .DROP_DOWN_ARROW_ICON[0]
    );
  }

  /**
   * @details To select procedure display from dropdown values
   * @param option
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  selectProcedureDisplay(option: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptProcedureDisplay();
    const procedureDisplay =
      OR_NURSING_CONFIGURATION.CONSENTS.PROCEDURE_DISPLAY;
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONSENTS.PROCEDURE_DISPLAY.DROP_DOWN[1]
    ).within(() => {
      cy.cGet(procedureDisplay.DROP_DOWN_TEXT[1])
        .invoke(InvokeMethods.text)
        .then(($val) => {
          if ($val.trim().toLowerCase() != option.trim().toLowerCase()) {
            this.clickProcedureDisplayDropdown();
            cy.cIntercept(interceptCollection);
            cy.cGet(selectorFactory.getProcedureDisplayOptions(option))
              .eq(0)
              .click({ force: true });
            cy.cWaitApis(interceptCollection);
          }
        });
    });
  }

  /**
   * @details -To select Exempt type in contracts review/edit
   * @param - value as Exempt type in the contract
   * @Api API's are available - Implemented Completely
   * @author Arushi
   */
  selectExemptTypeInContract(value: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptExemptContractApi();
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.EXEMPT_DROPDOWN_CONTRACTS[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.EXEMPT_DROPDOWN_CONTRACTS[0],
      false,
      false,
      { force: true }
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      CommonUtils.concatenate(
        OR_NURSING_CONFIGURATION.CONTRACTS.EXEMPT[1],
        selectorFactory.getSpanText(value)
      ),
      OR_NURSING_CONFIGURATION.CONTRACTS.EXEMPT[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Enter Details for the procedure in the contract review/edit tab
   * @param - value as entering the amount in the details
   * @api API's are not available
   */
  enterDetails(value: string) {
    cy.cType(
      OR_NURSING_CONFIGURATION.CONTRACTS.DETAILS[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.DETAILS[0],
      value
    );
  }

  /**
   * @details - verify the source field in transaction code
   * @param value - source field value to be verified should be passed.
   * @api API's are not available
   */
  verifySourceFieldInTransactionCode(value: string) {
    cy.cIsEnabled(
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SOURCE_FIELD_IN_TRANSACTION[1],
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SOURCE_FIELD_IN_TRANSACTION[0],
      false,
      false
    );
    cy.cHasValue(
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SOURCE_FIELD_IN_TRANSACTION[1],
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SOURCE_FIELD_IN_TRANSACTION[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - click on the add button in transaction code
   * @Api API's are not available
   */
  clickOnAddButtonInTransactionCode() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );
  }

  /**
   * @details - search the transaction code
   * @param code - Transaction code to be searched should be passed.
   * @api API's are not available
   */
  searchTransactionCode(code: string) {
    cy.cType(
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SEARCH[1],
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SEARCH[0],
      code,
      false,
      true
    );
  }

  /**
   * @details - verify the transaction code exists
   * @param code - Transaction code to be verified should be passed as code
   * @param exists - To verify exists or not exists
   * @api API's are not available
   */
  verifyTransactionCodeExists(code: string, exists = true) {
    this.searchTransactionCode(code);
    exists
      ? cy.cIsVisible(selectorFactory.getDivTitle(code), code)
      : cy.cNotExist(selectorFactory.getDivTitle(code), code);
  }

  /**
   * @details - search and select the transaction code
   * @param transactionCode - Transaction code to be selected should be passed.
   * @Api API's are not available
   */
  searchAndSelectTransactionCode(transactionCode: string) {
    cy.cType(
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SEARCH[1],
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SEARCH[0],
      transactionCode
    );
    cy.cClick(selectorFactory.getDivTitle(transactionCode), transactionCode);
  }

  /**
   * @details - verify the text in transaction code
   * @param transactionCode - Transaction code to be verified should be passed.
   * @Api API's are not available
   */
  verifyTextInTransactionCode(transactionCode: string) {
    this.searchAndSelectTransactionCode(transactionCode);
    cy.cHasValue(
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.TRANSACTION_CODE_NAME[1],
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.TRANSACTION_CODE_NAME[0],
      transactionCode
    );
  }

  /**
   * @details - verify the type of the transaction code
   * @param code - Transaction code to be verified should be passed.
   * @param type - Type of transaction code to be verified should be passed.
   * @api API's are not available
   */
  verifyTransactionType(code: string, type: string) {
    this.searchAndSelectTransactionCode(code);
    cy.cIncludeText(
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SELECTED_TRANSACTION_TYPE[1],
      OR_NURSING_CONFIGURATION.TRANSACTION_CODES.SELECTED_TRANSACTION_TYPE[0],
      type
    );
  }

  /**
   * @details - verify the buttons after the search and select in the application settings
   * @api API's are not available
   */
  assertionClaimButton() {
    const buttons = [
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
        .ELECTRONIC_CLAIM_CONFIGURATION[1],
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
        .PAPER_CLAIM_CONFIGURATION[1],
    ];
    buttons.forEach((button) => {
      cy.shouldBeEnabled(button);
    });
  }

  /**
   * @details - select Contract type in Contracts
   * @param contractInfo - will pass the Name of the Contract
   * @param contractType - passed to select Contract type
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  selectContractType(contractInfo: Contract, contractType: string) {
    this.nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONTRACTS.SUB_HEADER[0]
    );
    //  Searching for the Contract name
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0],
      contractInfo.ContractName
    );
    // Clicking on the contract name
    this.selectConfigurationFirstTemplate();
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_TYPE_DROPDOWN[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_TYPE_DROPDOWN[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(contractType),
      OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_TYPE_DROPDOWN[0],
      false,
      false,
      {
        force: true,   // added force true in dashboard it is getting failed
      }
    );
  }

  /**
   * @details - add implants in preference Card
   * @param implantInfo - To add Implant to Preference Card.
   */
  addImplants(implantInfo: Implant) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .ADD_IMPLANT_BUTTON[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .ADD_IMPLANT_BUTTON[0],
      false,
      false,
      {
        force: true,
      }
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .IMPLANTS_SEARCH_FIELD[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .IMPLANTS_SEARCH_FIELD[0],
      implantInfo.Implant ?? '',
      false,
      true,
      { force: true }
    );
    cy.cClick(
      selectorFactory.getSpanText(implantInfo.ImplantDescription!),
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .IMPLANT_DESCRIPTION[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(implantInfo.Manufacturer!),
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .MANUFACTURER[0],
      false,
      true,
      {
        force: true,
      }
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .QUANTITY[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .QUANTITY[0],
      implantInfo.Quantity!
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.ADD_IMPLANTS
        .DONE_BUTTON[0]
    );
  }

  /**
   * @details - select Contract Grouper ID in Review/Edit
   * @param value- value passed to select Id in Drop Down
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  selectContractGrouperId(value: string) {
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
      OR_NURSING_CONFIGURATION.CONTRACTS
        .SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[0]
    ).dblclick({ force: true });
    cy.cClick(
      OR_NURSING_CONFIGURATION.CLICK_ON_DETAILS[1],
      OR_NURSING_CONFIGURATION.CLICK_ON_DETAILS[0]
    );
    cy.cClick(
      selectorFactory.getGrouperDetailsDropDown(value),
      OR_NURSING_CONFIGURATION.CLICK_ON_DETAILS[0]
    );
  }

  /**
   * @details - Select Physician in preference Card
   * @param - physicianName passed to select Physician
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectPhysicianInPreferenceCard(physicianName: string) {
    this.clickOnPhysicianDropdown();
    cy.cClick(
      selectorFactory.getSpanClassText(physicianName),
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0]
    );
  }

  /**
   * @details - Method to add Free text name in the Fee schedule
   * @APIs are not Available
   */
  clickOnKeyboard() {
    cy.cClickAndWait(
      this.OR_FEE_SCHEDULE.KEY_BOARD_ICON[1],
      this.OR_FEE_SCHEDULE.KEY_BOARD_ICON[0]
    );
  }

  /**
   * @details - To select contract tab headings
   * @param tabHeading - To select the tabs in the contracts
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  selectTabHeadingInContracts(tabHeading: string) {
    cy.cClick(selectorFactory.getTabHeadingTagText(tabHeading), tabHeading);
  }

  /**
   * @details - To select values from list in review/edit tab for grouper contract
   * @param index - To send the values as 0,1 for the CPTs
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  selectValueFromList(index: string) {
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS.DROP_DOWN[1]
    );

    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS
        .DROP_DOWN[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS.DROP_DOWN[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS.SEARCH[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS.SEARCH[0],
      index
    );
    cy.cGet(
      CommonUtils.concatenate(
        OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS.ITEMS[1],
        ' ',
        selectorFactory.getSpanText(index)
      )
    )
      .first()
      .click({ multiple: true });
  }

  /**
   * @details - To add reimbursement for grouper contract
   * @param value- providing number/value for reimbursement
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  enterReimbursement(value: string) {
    cy.cType(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS
        .REIMBURSEMENT[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS
        .REIMBURSEMENT[0],
      value
    );
  }

  /**
   * @details - To add fee group values for grouper contract
   * @param index-adding index for reimbursement
   * @param num-adding number for reimbursement
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  addFeeGroup(index: string, num: string) {
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.PLUS_ICON[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.PLUS_ICON[0]
    );
    cy.cGet(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS.FEE_GROUP[1]
    ).within(() => {
      this.selectValueFromList(index);
      cy.cGet(
        OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.FEE_GROUPS
          .DATA_COLUMN[1]
      )
        .first()
        .click();
      this.enterReimbursement(num);
    });
    cy.cClick(
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.PLUS_ICON[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.PLUS_ICON[0]
    );
  }

  /**
   * @details - Method to add Procedure in the Fee schedule
   * @param value - enter cpt value in add procedure search box
   */
  addProcedure(value: string) {
    cy.cClick(
      this.OR_FEE_SCHEDULE.ADD_PROCEDURE_SEARCH[1],
      this.OR_FEE_SCHEDULE.ADD_PROCEDURE_SEARCH[0]
    ).type(value);
  }

  /**
   * @details - Method to search and select status of the Fee Schedule
   * @param value - to select fee schedule status
   * @APIs are Available - Implemented Completely
   */
  feeScheduleStatusDropdown(value: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptFeeScheduleStatusUpdate();
    cy.cIntercept(interceptCollection);
    cy.cClick(this.OR_FEE_SCHEDULE.STATUS_DROPDOWN[1], '', false, false, {
      force: true,
    });

    cy.cGet(this.OR_FEE_SCHEDULE.STATUS_DROPDOWN_LIST[1]).each(($element) => {
      if ($element.text().trim() === value) {
        cy.wrap($element).within(() => {
          if (
            !$element
              .find(CoreCssClasses.Checkbox.loc_pi_check)
              .is(FilterMethods.visible)
          ) {
            cy.cClick(selectorFactory.getSpanText(value), value);
          }
        });
        return false;
      }
    });
    cy.cWaitApis(interceptCollection);
  }
  /**
   * @details - Method to click on Done Button In Application Settings Template creation
   * @APIs are Available - Implemented Completely
   */
  clickDoneButton() {
    const interceptCollection =
      this.nursingConfigApis.interceptFeeScheduleDone();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Method to verify given CPT text in Review/Edit in the Contracts Configuration
   * @param procedure - cpt code name
   * @APIs are not Available
   */
  verifyCptTextInReviewOrEdit(procedure: string) {
    cy.cGet(CoreCssClasses.DataTable.loc_table).within(() => {
      cy.cGet(CommonGetLocators.tr).each(($row) => {
        if ($row.text().includes(procedure))
          expect($row.text().trim()).to.includes(procedure);
      });
    });
  }

  /**
   * @details - To Search the added CPT code in the procedure search box
   * @param cptData - to enter CPTCodeAndDescription to search
   * @APIs are Available - Implemented Completely
   * @Author Sai Swarup
   */
  procedureSearchBox(cptData: Cpt) {
    const interceptCollection =
      this.nursingConfigApis.interceptContractSearchedProcedureApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.PROCEDURES_SEARCH_BOX[1],
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.PROCEDURES_SEARCH_BOX[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To enter fee schedule free text in cpt description
   * @param freeText - To enter cpt description with free text
   * @APIs are not Available
   * @author - Sai Swarup
   */
  enterFeeScheduleFreeText(freeText: String) {
    cy.shouldBeEnabled(this.OR_FEE_SCHEDULE.PROCEDURE_FREE_TEXT_BOX[1]);
    cy.cType(
      this.OR_FEE_SCHEDULE.PROCEDURE_FREE_TEXT_BOX[1],
      this.OR_FEE_SCHEDULE.PROCEDURE_FREE_TEXT_BOX[0],
      freeText
    );
  }

  /**
   * @details - select fee schedules in nursing configuration
   * @Api -API's are available - Implemented Completely
   * @author Arushi
   */
  selectFeeScheduleConfiguration() {
    const interceptCollection =
      this.nursingConfigApis.interceptFeeScheduleApi();
    cy.cIntercept(interceptCollection);
    this.nursingConfigurationLayout.selectConfiguration(
      this.OR_FEE_SCHEDULE.SUB_HEADER[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To select Exempt in review/edit and configure amount
   * @param value of the contract that needs to be passed
   * @Api - Apis are not needed at exempt as it is only verifying the value and performing the next action
   * @author Arushi
   */
  selectExemptAndConfigureAmount(value: string) {
    cy.cClick(
      OR_COMBINED_CODING.SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[1],
      OR_COMBINED_CODING.SELECT_SEARCHED_PROCEDURE_IN_CONTRACTS[0],
      false,
      false,
      { force: true }
    )
      .then(() => {
        cy.cClick(
          OR_COMBINED_CODING.EXEMPT_DROPDOWN[1],
          OR_COMBINED_CODING.EXEMPT_DROPDOWN[0],
          false,
          false,
          { force: true }
        );
        cy.cGet(
          CommonUtils.concatenate(
            OR_COMBINED_CODING.EXEMPT_DROPDOWN_VALUES[1],
            selectorFactory.getSpanText(YesOrNo.yes)
          )
        );
      })
      .then(() => {
        cy.cClick(
          OR_COMBINED_CODING.AMOUNT_DETAILS_REVIEW_EDIT[1],
          OR_COMBINED_CODING.AMOUNT_DETAILS_REVIEW_EDIT[0],
          false,
          false,
          { force: true }
        ).then(() => {
          cy.cType(
            OR_COMBINED_CODING.AMOUNT_DETAILS_REVIEW_EDIT[1],
            OR_COMBINED_CODING.AMOUNT_DETAILS_REVIEW_EDIT[0],
            value
          );
        });
      });
  }

  /**
   * @details To select the discount in configuration search
   * @param  configName - To provide the configuration name for user selection from search list in configuration page
   * @param isBackGroundColor - To pass the true,false values, based on the background color to select the option from search list
   * @author Praveen
   */
  selectDiscountInSearchList(configName: string, isBackGroundColor: boolean) {
    const interceptCollection =
      this.nursingConfigApis.interceptDiscountSelectionApi();
    cy.cIntercept(interceptCollection);
    this.nursingConfigurationLayout.selectConfiguration(
      configName,
      isBackGroundColor
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - add RCM Status
   * @param rcmStatus - name of the rcm status has to be passed
   * @Api -API's are available - Implemented Completely
   * @author - Rakesh Donakonda
   */
  addRcmStatus(rcmStatus: AddRcmStatus) {
    const interceptCollection =
      this.nursingConfigApis.interceptAddRcmStatusApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARY.ADD_ITEM[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.ADD_ITEM[0]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.DIC_ITEM_NEW[0],
      rcmStatus.RcmStatus
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[1],
        ' ',
        selectorFactory.getSpanText(rcmStatus.Active)
      ),
      OR_NURSING_CONFIGURATION.DICTIONARY.ACTIVE_TOGGLE[0]
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE_LABEL[1],
      OR_NURSING_CONFIGURATION.DICTIONARY.SHOW_INACTIVE_LABEL[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Search and Select Required Preference Card
   * @param preferenceCardName - To Pass Preference Card Name in Search Box
   * @API - API's are available and Implemented Completely
   * @author - Arushi
   */
  searchAndSelectPreferenceCard(preferenceCardName: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectPreferenceCard();
    cy.shouldBeEnabled(OR_NURSING_CONFIGURATION.COMMON.SEARCH[1]);
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[1],
      OR_NURSING_CONFIGURATION.COMMON.SEARCH[0],
      preferenceCardName,
      false,
      true
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.selectPreferenceCard(preferenceCardName),
      preferenceCardName,
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Add Implant in Preference Card
   * @param implantDetails - Implant Details like Implant Name, Manufacturer, Quantity, Size, Lot, Serial, Expiration, Reference, Notes Value
   * @param implantHeader - Implant Header like Implant Name, Manufacturer, Quantity, Size, Lot, Serial, Expiration, Reference, Notes
   * @API - API's are not available
   * @author - Sai Swarup
   */
  addImplantsInPreferenceCard(implantDetails: Implant, implantHeader: string) {
    const implantPopUpDetails =
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC;
    let implantHeaderDetails: string;

    this.preferenceCardAddImplantOrProsthetic();

    if (implantHeader == FreeText.free_text_item) {
      this.preferenceCardImplantKeyBoard();
    }
    this.preferenceCardImplant(
      implantHeader,
      implantDetails.Implant ?? '',
      implantDetails.Manufacturer ?? ''
    );
    Object.entries(implantDetails).forEach((entry) => {
      const [key, value] = entry;

      if (CommonUtils.isDefinedAndNotEmpty(value)) {
        implantHeaderDetails =
          key === ImplantHeaders.implant
            ? implantPopUpDetails.IMPLANT[0]
            : key === ImplantHeaders.manufacturer
            ? implantPopUpDetails.MANUFACTURER[0]
            : key === ImplantHeaders.used
            ? implantPopUpDetails.QUANTITY[0]
            : key === ImplantHeaders.size
            ? implantPopUpDetails.SIZE[0]
            : key === ImplantHeaders.lot
            ? implantPopUpDetails.LOT_NO[0]
            : key === ImplantHeaders.serial
            ? implantPopUpDetails.SERIAL_NO[0]
            : key === ImplantHeaders.expiration
            ? implantPopUpDetails.EXPIRATION[0]
            : key === ImplantHeaders.reference
            ? implantPopUpDetails.REFERENCE_NO[0]
            : implantPopUpDetails.NOTES[0];

        if (
          !(
            key === ImplantHeaders.implant ||
            key === ImplantHeaders.manufacturer
          )
        ) {
          this.addImplantOrProstheticInfo(implantHeaderDetails, value);
        }
      }
    });
    this.clickAddImplantProstheticDoneBtn();
  }

  /**
   * @details - Click on Add Implant or Prosthetic Button in Preference Card
   * @API - API's are not available
   * @author - Sai Swarup
   */
  preferenceCardAddImplantOrProsthetic() {
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[1]
    );
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[0]
    )
      .trigger(TriggerAttributes.mousedown)
      .should(ShouldMethods.visible)
      .then(() => {
        cy.cClick(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[0]
        );
        cy.shouldBeEnabled(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.NOTES[1]
        );
      });
  }

  /**
   * @details - Click Implant Key Board Icon in Add Implant Prosthetic PopUp in Preference Card
   * @API - API's are not available
   * @author - Sai Swarup
   */
  preferenceCardImplantKeyBoard() {
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.ADD_IMPLANT_OR_PROSTHETIC_POPUP[1]
    ).within(() => {
      cy.cClick(
        OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
          .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT_KEYBOARD_ICON[1],
        OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
          .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT_KEYBOARD_ICON[0]
      );
      cy.cClick(
        OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
          .ADD_IMPLANT_OR_PROSTHETIC.MANUFACTURER_KEYBOARD_ICON[1],
        OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
          .ADD_IMPLANT_OR_PROSTHETIC.MANUFACTURER_KEYBOARD_ICON[0]
      ).then(() => {
        cy.cClick(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[0]
        );
        cy.cIsVisible(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[0]
        );
      });
    });
  }

  /**
   * @details - Add Implant, Manufacturer in Preference Card
   * @param inventoryType - Pass Inventory Type Free Text or Ios Item
   * @param implantName - Pass Implant Name
   * @param manufacturerName - Pass Manufacturer Name
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  preferenceCardImplant(
    inventoryType: string,
    implantName: string,
    manufacturerName: string
  ) {
    const interceptCollection =
      this.nursingConfigApis.interceptSearchInventory();

    if (inventoryType == FreeText.free_text_item) {
      cy.cGet(
        OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
          .ADD_IMPLANT_OR_PROSTHETIC.ADD_IMPLANT_OR_PROSTHETIC_POPUP[1]
      ).within(() => {
        cy.cType(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[0],
          implantName,
          false,
          true
        );
        cy.cType(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.MANUFACTURER[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.MANUFACTURER[0],
          manufacturerName,
          false,
          true
        );
      });
    }

    if (inventoryType == IosTextItem.ios_text_item) {
      cy.cGet(
        OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
          .ADD_IMPLANT_OR_PROSTHETIC.ADD_IMPLANT_OR_PROSTHETIC_POPUP[1]
      ).within(() => {
        cy.cIntercept(interceptCollection);
        cy.cType(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .ADD_IMPLANT_OR_PROSTHETIC.IMPLANT[0],
          implantName,
          false,
          true
        );
      });
      cy.cWaitApis(interceptCollection);
      cy.cClick(
        selectorFactory.getSpanText(implantName),
        implantName,
        false,
        true
      );
      cy.cClick(
        selectorFactory.getImplantManufacturerText(manufacturerName),
        manufacturerName,
        false,
        true
      );
    }
  }

  /**
   * @details - Configuring Used, Size, Lot, Serial, Expiration, Reference, Notes for an Implant in Preference Card
   * @param implantHeader - To Pass Implant Header Text like Implant, Manufacturer, Quantity, Size, Lot, Serial, Expiration, Reference, Notes
   * @param implantData - To Pass Implant Details like Implant, Manufacturer, Quantity, Size, Lot, Serial, Expiration, Reference, Notes value
   * @API - API's are not available
   * @author - Sai Swarup
   */
  addImplantOrProstheticInfo(
    implantHeader: string,
    implantData: string | number
  ) {
    const implantPopupInfo =
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC;
    const implantInfo =
      implantHeader === implantPopupInfo.IMPLANT[0]
        ? implantPopupInfo.IMPLANT[1]
        : implantHeader === implantPopupInfo.MANUFACTURER[0]
        ? implantPopupInfo.MANUFACTURER[1]
        : implantHeader === implantPopupInfo.QUANTITY[0]
        ? implantPopupInfo.QUANTITY[1]
        : implantHeader === implantPopupInfo.SIZE[0]
        ? implantPopupInfo.SIZE[1]
        : implantHeader === implantPopupInfo.LOT_NO[0]
        ? implantPopupInfo.LOT_NO[1]
        : implantHeader === implantPopupInfo.SERIAL_NO[0]
        ? implantPopupInfo.SERIAL_NO[1]
        : implantHeader === implantPopupInfo.EXPIRATION[0]
        ? implantPopupInfo.EXPIRATION[1]
        : implantHeader === implantPopupInfo.REFERENCE_NO[0]
        ? implantPopupInfo.REFERENCE_NO[1]
        : implantPopupInfo.NOTES[1];

    cy.cType(implantInfo, implantHeader, implantData, false, true);
  }

  /**
   * @details - Add Implant or Prosthetic Done Button in Preference Card
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clickAddImplantProstheticDoneBtn() {
    cy.cIsEnabled(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.DONE[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.DONE[0]
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.DONE[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.DONE[0]
    );
    cy.cNotExist(
      selectorFactory.getH2Text(
        OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
          .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[0]
      ),
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[0]
    );
  }

  /**
   * @details - Add Supplies in Preference Card
   * @param supplyInfo - Supply Details like Supply Name, Pre-Op, Op, Recovery Open and Hold Value
   * @param supplyHeader - Supply Header like Supply Name, Pre-Op, Op, Recovery Open and Hold
   * @API - API's are not available
   * @author - Sai Swarup
   */
  addSuppliesInPreferenceCard(supplyInfo: Supplies, supplyHeader: string) {
    const preferenceCardSupply = supplyInfo.PreferenceCardSupply ?? '';
    let supplyKeyDetails: number;

    if (supplyHeader == FreeText.free_text_item) {
      this.preferenceCardFreeTextSupply(supplyInfo.SupplyName ?? '');
      this.clickSupplyItem(supplyInfo.SupplyName ?? '');
    }

    if (supplyHeader == IosTextItem.ios_text_item) {
      this.preferenceCardSupply(supplyInfo.SupplyName!);
    }
    Object.entries(preferenceCardSupply).forEach((entry) => {
      const [key, value] = entry;

      if (CommonUtils.isDefinedAndNotEmpty(value)) {
        supplyKeyDetails =
          key === SupplyHeaders.pre_op_open
            ? 0
            : key === SupplyHeaders.pre_op_hold
            ? 1
            : key === SupplyHeaders.or_open
            ? 2
            : key === SupplyHeaders.or_hold
            ? 3
            : key === SupplyHeaders.recovery_open
            ? 4
            : 5;
        this.preferenceCardSupplyQuantity(supplyKeyDetails, value);
      }
    });

    if (CommonUtils.isDefinedAndNotEmpty(supplyInfo.Notes ?? '')) {
      this.preferenceCardSupplyNotes(supplyInfo.Notes ?? '');
    }
    this.sisOfficeDesktop.clickPatientSearchIcon();
  }

  /**
   * @details - Add Free Text Supplies in Preference Card
   * @param value - To Pass Free Text Supply name
   * @API - API's are not available
   * @author - Sai Swarup
   */
  preferenceCardFreeTextSupply(value: string) {
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[1]
    );
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.SUPPLY[1]
    )
      .trigger(TriggerAttributes.mousedown)
      .then(() => {
        cy.cClick(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .SUPPLIES_AND_INSTRUMENTS.KEYBOARD_ICON[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .SUPPLIES_AND_INSTRUMENTS.KEYBOARD_ICON[0],
          false,
          true
        );
        cy.shouldBeEnabled(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .SUPPLIES_AND_INSTRUMENTS.SUPPLY[1]
        );
        cy.cType(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .SUPPLIES_AND_INSTRUMENTS.SUPPLY[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .SUPPLIES_AND_INSTRUMENTS.SUPPLY[0],
          value
        );
      });
  }

  /**
   * @details - Click Supply Item in Preference Card
   * @param supplyName - To Pass Supply Name Value
   * @param rowSequence - To Pass Supply Row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clickSupplyItem(supplyName: string, rowSequence: number = 0) {
    const supplyItemLoc = CommonUtils.concatenate(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.CLICK_SUPPLY_ITEM[1],
      ' ',
      selectorFactory.getSpanText(supplyName)
    );

    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.QUANTITY[1]
    )
      .eq(rowSequence)
      .click();
    cy.shouldBeEnabled(supplyItemLoc);
    cy.cClick(supplyItemLoc, supplyName, false, true);
    cy.shouldBeEnabled(CoreCssClasses.Icon.loc_keyboard_icon_on);
    cy.cGet(CoreCssClasses.Icon.loc_keyboard_icon_on)
      .should(ShouldMethods.css, InvokeAttributes.border)
      .then(($val) => {
        const col = String($val).split(CommonClassAttributes.solid)[1];
        const hexValue = String(color(col).hex()).toLowerCase();
        expect(hexValue).to.equal(
          AppColors.component_enabled_toggle_button_selected
        );
      });
  }

  /**
   * @details - Add Ios Supply in Preference Card
   * @param value - Supply Name should be passed as value
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  preferenceCardSupply(value: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptPreferenceCardSupply();
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .ADD_IMPLANT_OR_PROSTHETIC.SUB_HEADER[1]
    );
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.SUPPLY[1]
    )
      .trigger(TriggerAttributes.mousedown)
      .then(() => {
        cy.cIntercept(interceptCollection);
        cy.cType(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .SUPPLIES_AND_INSTRUMENTS.SUPPLY[1],
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
            .SUPPLIES_AND_INSTRUMENTS.SUPPLY[0],
          value
        );
        cy.cWaitApis(interceptCollection);
        cy.cClick(selectorFactory.getSpanText(value), value, false, true);
      });
  }

  /**
   * @details - Add Supplies Quantity in Preference Card
   * @param index - To Pass Index of Pre-Op, Op, Recovery Open and Hold
   * @param value - To Pass Value of Pre-Op, Op, Recovery Open and Hold
   * @API - API's are not available
   * @author - Sai Swarup
   */
  preferenceCardSupplyQuantity(index: number, value: number) {
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.QUANTITY[1]
    )
      .eq(index)
      .should(ShouldMethods.visible)
      .click()
      .clear()
      .type(value.toString());
  }

  /**
   * @details - Add Supplies Notes for Supply Item in Preference Card
   * @param supplyNotes - To Pass Supply Notes Value
   * @API - API's are not available
   * @author - Sai Swarup
   */
  preferenceCardSupplyNotes(supplyNotes: string) {
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.NOTES[1]
    )
      .first()
      .click()
      .clear()
      .type(supplyNotes);
    cy.cClick(
      OR_SCHEDULE_GRID.GLOBAL_SEARCH.SEARCH[1],
      OR_SCHEDULE_GRID.GLOBAL_SEARCH.SEARCH[0]
    );
  }

  /**
   * @details - Search and Select Formulary Medication
   * @param medicationTemplateName - Medication Template Name
   * @API - API's are not available
   * @author - Sai Swarup
   */
  searchAndSelectFormularyMedication(medicationTemplateName: string) {
    cy.shouldBeEnabled(OR_NURSING_CONFIGURATION.FORMULARY.SEARCH_MEDICATION[1]);
    cy.cType(
      OR_NURSING_CONFIGURATION.FORMULARY.SEARCH_MEDICATION[1],
      OR_NURSING_CONFIGURATION.FORMULARY.SEARCH_MEDICATION[0],
      medicationTemplateName,
      false,
      true
    );
    cy.cIsVisible(
      selectorFactory.getTrText(medicationTemplateName),
      medicationTemplateName
    );
  }

  /**
   * @details - Edit Formulary Medication Template Name
   * @param medicationInfo - Pass Medication Model as a Reference
   * @param contextMenu - Pass Context Menu option  as Edit, Delete, Duplicate
   * @API - API's are not available
   * @author - Sai Swarup
   */
  editFormularyMedication(medicationInfo: Medication, contextMenu: string) {
    this.searchAndSelectFormularyMedication(
      medicationInfo.FormularyMedication?.MedicationTemplateName ?? ''
    );
    this.selectContextMenuFormularyMedication(
      medicationInfo.FormularyMedication?.MedicationTemplateName ?? '',
      contextMenu
    );

    if (contextMenu == ContextMenu.edit) {
      this.editFormularyMedicationTemplate(medicationInfo);
    }
  }

  /**
   * @details - Select Context Menu Option for Formulary Medication
   * @param medicationTemplateName - Medication Template Name
   * @param contextType - Pass Context Type as Edit, Delete, Duplicate
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  selectContextMenuFormularyMedication(
    medicationTemplateName: string,
    contextType: string
  ) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectContextMenuFormularyMedication();
    const contextMenuBtn = CommonUtils.concatenate(
      selectorFactory.getTrText(medicationTemplateName),
      ' ',
      CommonGetLocators.td,
      ' ',
      CoreCssClasses.Icon.loc_fa_chevron_circle
    );

    cy.cGet(contextMenuBtn).scrollIntoView().click();
    cy.shouldBeEnabled(selectorFactory.getAText(contextType));

    if (contextType == ContextMenu.edit) {
      cy.cIntercept(interceptCollection);
      cy.cClick(selectorFactory.getAText(contextType), contextType);
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cClick(selectorFactory.getAText(contextType), contextType);
    }
  }

  /**
   * @details - Edit Formulary Medication and add required details
   * @param medicationDetails - Medication Model as a Reference
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  editFormularyMedicationTemplate(medicationDetails: Medication) {
    const interceptCollection =
      this.nursingConfigApis.interceptEditFormularyMedication();
    const formularyDetails = medicationDetails.FormularyMedication ?? '';

    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.SUB_HEADER[1]
    );
    Object.entries(formularyDetails).forEach((entry) => {
      const [key, value] = entry;

      if (CommonUtils.isDefinedAndNotEmpty(value)) {
        if (key === Formulary.compound_medication) {
          this.selectCompoundMedicationToggle(value);
        }

        if (key === Formulary.administration_amount) {
          this.addFormularyAdministrationAmount(value);
        }

        if (key === Formulary.usage_unit_of_measure) {
          this.addFormularyUsageUnitOfMeasure(value);
        }

        if (key === Formulary.ios_inventory_medication) {
          this.addFormularyInventoryMedication(value);
        }
      }
    });
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.DONE[1],
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.DONE[1],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
    cy.cNotExist(
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.DONE[1],
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.DONE[1]
    );
  }

  /**
   * @details - Add Inventory Medication for Formulary Medication Template Name
   * @param inventoryMedication - Inventory Medication Name
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  addFormularyInventoryMedication(inventoryMedication: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptAddFormularyInventory();
    cy.cType(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .INVENTORY_IOS_TEXT[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .INVENTORY_IOS_TEXT[0],
      inventoryMedication,
      false,
      true
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getSpanText(inventoryMedication),
      inventoryMedication,
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Add Administration Amount for Formulary Medication Template Name
   * @param administrationAmount - Administration Amount
   * @API - API's are not available
   * @author - Sai Swarup
   */
  addFormularyAdministrationAmount(administrationAmount: number) {
    cy.cType(
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.ADMINISTRATION_AMOUNT[1],
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.ADMINISTRATION_AMOUNT[0],
      administrationAmount
    );
  }

  /**
   * @details - Add Usage Unit Of Measure for Formulary Medication Template Name
   * @param measure - Usage Unit Of Measure
   * @API - API's are not available
   * @author - Sai Swarup
   */
  addFormularyUsageUnitOfMeasure(measure: number) {
    cy.cType(
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.USAGE_UNIT_OF_MEASURE[1],
      OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.USAGE_UNIT_OF_MEASURE[0],
      measure
    );
  }

  /**
   * @details - Select Compound Medication Toggle as Yes or No for Formulary Medication Template Name
   * @param compoundMedication - Compound Medication choice as Yes or No
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectCompoundMedicationToggle(compoundMedication: string) {
    const compoundToggle =
      compoundMedication === YesOrNo.yes
        ? OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE
            .COMPOUND_MEDICATION_YES[1]
        : OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE
            .COMPOUND_MEDICATION_NO[0];

    cy.cClick(compoundToggle, compoundMedication);
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .INVENTORY_IOS_TEXT[1]
    );
    /**
     * Waiting for Medication Locator to attach to DOM
     */
    cy.get(OR_NURSING_CONFIGURATION.FORMULARY.EDIT_TEMPLATE.MEDICATION[1], {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
  }

  /**
   * @details - Edit Physician Order
   * @param physicianOrder - Pass Physician Orders Model as a Reference
   * @param medicationDetails - Medication Model as a Reference
   * @param departmentType - Pass Department Type as Pre-Operative or Operative or Recovery Row Number
   * @API - API's are not available
   * @author - Sai Swarup
   */
  editPhysicianOrder(
    physicianOrder: PhysicianOrders,
    medicationDetails: Medication,
    departmentType: number
  ) {
    this.searchAndSelectPhysicianOrder(physicianOrder.OrderName ?? '');
    this.addMedicationPhysicianOrder(
      medicationDetails,
      departmentType,
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
    );
    this.addMedicationPhysicianOrderDone();
  }

  /**
   * @details - Search and Select Physician Order
   * @param orderName - Pass Physician Orders Name
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  searchAndSelectPhysicianOrder(orderName: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSearchAndSelectPhysicianOrder();
    const orderList = CommonUtils.concatenate(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.LIST[1],
      ' ',
      selectorFactory.getDivTitle(orderName)
    );

    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_SEARCH_BOX[1]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_SEARCH_BOX[1],
      OR_NURSING_CONFIGURATION.CONTRACTS.CONTRACT_SEARCH_BOX[0],
      orderName
    );
    cy.shouldBeEnabled(orderList);
    cy.cIntercept(interceptCollection);
    cy.cClick(orderList, orderName);
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ORDERS_NAME[1]
    );
    cy.cHasValue(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ORDERS_NAME[1],
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ORDERS_NAME[0],
      orderName
    );
  }

  /**
   * @details - Add Formulary Medication for Physician Order
   * @param medicationOrder - Pass Physician Order Add Medication as a Model for reference
   * @param rowSequence - Pass Department Type as Pre-Operative or Operative or Recovery Row Number
   * @param desktopType - Pass Nursing Configuration or Pre-Op, Op, Recovery Department
   * @API - API's are available Implemented Completely
   * @author - Sai Swarup
   */
  addMedicationPhysicianOrder(
    medicationOrder: Medication,
    rowSequence: number,
    desktopType: string
  ) {
    const interceptCollection =
      this.nursingConfigApis.interceptAddPhysicianOrder();
    const availableMedication = CommonUtils.concatenate(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION
        .AVAILABLE_MEDICATION_LIST[1],
      ' ',
      selectorFactory.getSpanText(
        medicationOrder.FormularyMedication?.MedicationTemplateName ?? ''
      )
    );
    const addMedicationLoc =
      desktopType ===
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.SWITCH_TO_NURSING_DESKTOP[0]
        ? OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION.SUB_HEADER[1]
        : OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION_ORDER[1];
    cy.cIntercept(interceptCollection);
    cy.cGet(addMedicationLoc).eq(rowSequence).click();
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION.NOTES[1]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION
        .SEARCH_AVAILABLE_MEDICATIONS[1],
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION
        .SEARCH_AVAILABLE_MEDICATIONS[0],
      medicationOrder.FormularyMedication?.MedicationTemplateName
    );
    cy.cClick(
      availableMedication,
      medicationOrder.FormularyMedication?.MedicationTemplateName ?? '',
      false,
      true
    );
  }

  /**
   * @details - Click on Done for Add Medication Popup for Physician Order
   * @API - API's are not available
   * @author - Sai Swarup
   */
  addMedicationPhysicianOrderDone() {
    cy.cClick(
      selectorFactory.getButtonText(DoneOrCancel.done),
      DoneOrCancel.done
    );
    cy.cNotExist(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION.NOTES[1],
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION.NOTES[0]
    );
  }

  /**
   * @details - Add Anesthesia Plan
   * @param plan - Pass Anesthesia Plan Name
   * @API - API's are available Implemented Completely
   * @author - Sai Swarup
   */
  addAnesthesiaPlan(plan: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptAddAnaesthesiaPlan();
    cy.shouldBeEnabled(OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1]);
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD_BUTTON[0]
    );
    cy.shouldBeEnabled(OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1]);
    cy.cType(
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0],
      plan,
      false,
      true
    );
    cy.cIsEnabled(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
    cy.cNotExist(
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[1],
      OR_NURSING_CONFIGURATION.COMMON.ADD.DONE_BUTTON[0]
    );
  }

  /**
   * @details - Search and Select Anesthesia Plan
   * @param anesthesiaPlanName - Anesthesia Plan Name
   * @API - API's are available Implemented Completely
   * @author - Sai Swarup
   */
  searchAndSelectAnesthesiaPlan(anesthesiaPlanName: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSearchAndSelectAnaesthesiaPlan();
    cy.cType(
      OR_NURSING_CONFIGURATION.PLANS.SEARCH_BOX[1],
      OR_NURSING_CONFIGURATION.PLANS.SEARCH_BOX[0],
      anesthesiaPlanName
    );
    cy.shouldBeEnabled(selectorFactory.getDivTitle(anesthesiaPlanName));
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getDivTitle(anesthesiaPlanName),
      anesthesiaPlanName,
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(OR_NURSING_CONFIGURATION.PLANS.PLAN_NAME[1]);
    cy.cHasValue(
      OR_NURSING_CONFIGURATION.PLANS.PLAN_NAME[1],
      OR_NURSING_CONFIGURATION.PLANS.PLAN_NAME[0],
      anesthesiaPlanName
    );
  }

  /**
   * @details - Add Formulary Medication in Anesthesia Plan
   * @param medicationTemplateName - Medication Template Name
   * @param medicationName - Medication Name
   * @API - API's are available Implemented Completely
   * @author - Sai Swarup
   */
  addMedicationInAnesthesiaPlan(
    medicationTemplateName: string,
    medicationName: string
  ) {
    const interceptCollectionSearchMedication =
      this.nursingConfigApis.interceptSearchMedicationAnaesthesia();
    const interceptCollectionAddMedicationDone =
      this.nursingConfigApis.interceptAddMedicationInAnesthesiaPlan();
    const availableMedication = CommonUtils.concatenate(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION
        .AVAILABLE_MEDICATION_LIST[1],
      ' ',
      selectorFactory.getSpanText(medicationTemplateName)
    );

    cy.shouldBeEnabled(CoreCssClasses.Icon.loc_plus_circle);

    cy.cIntercept(interceptCollectionSearchMedication);
    cy.cGet(CoreCssClasses.Icon.loc_plus_circle)
      .trigger(TriggerAttributes.mouseenter)
      .click();
    cy.cWaitApis(interceptCollectionSearchMedication);
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION
        .SEARCH_AVAILABLE_MEDICATIONS[1]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION
        .SEARCH_AVAILABLE_MEDICATIONS[1],
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION
        .SEARCH_AVAILABLE_MEDICATIONS[0],
      medicationTemplateName,
      false,
      true
    );
    cy.cClick(availableMedication, medicationTemplateName, false, true);
    cy.cIntercept(interceptCollectionAddMedicationDone);
    cy.cClick(
      selectorFactory.getButtonText(DoneOrCancel.done),
      DoneOrCancel.done
    );
    cy.cWaitApis(interceptCollectionAddMedicationDone);
    cy.cNotExist(
      selectorFactory.getH3Text(
        OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION.SUB_HEADER[0]
      ),
      OR_NURSING_CONFIGURATION.PHYSICIAN_ORDERS.ADD_MEDICATION.SUB_HEADER[0]
    );
    cy.shouldBeEnabled(selectorFactory.getSpanText(medicationName));
    cy.cIsVisible(selectorFactory.getSpanText(medicationName), medicationName);
  }

  /**
   * @detail To verify feature in add on feature section
   * @param name - To verify the name in add on features
   * @API - API's are not available
   * @author - Divya
   */
  verifyFeatureInAddOnFeaturesSection(name: string) {
    cy.cIsVisible(
      CommonUtils.concatenate(
        OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.FEATURE_SECTION[1],
        ' ',
        selectorFactory.getH2Text(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.SUB_HEADER[0]
        )
      ),
      ''
    );
    cy.cGet(selectorFactory.getLabelText(name))
      .should(ShouldMethods.visible)
      .parent(OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.LABEL[1])
      .next()
      .find(OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.ENABLE_DISABLE_TOGGLE[1])
      .should(ShouldMethods.visible);
  }

  /**
   * @detail To verify tracker in patient tracking
   * @param name - To verify the name in add on features
   * @API - API's are not available
   * @author - Divya
   */
  verifyTrackerInPatientTracking(name: string) {
    cy.cGet(selectorFactory.getH4Text(name))
      .should(ShouldMethods.visible)
      .parent()
      .within(() => {
        cy.cGet(OR_NURSING_CONFIGURATION.PATIENT_TRACKING.TRACKER_PANEL[1])
          .find(
            selectorFactory.getLabelText(
              OR_NURSING_CONFIGURATION.PATIENT_TRACKING.TRACKING_BOARD_URL[0]
            )
          )
          .should(ShouldMethods.visible);
      });
  }

  /*
   * @details - To add the pre-admission Worklist
   * @param name - To have worlist name.
   * @API - API's are available - Implemented Completely
   * @author - Divya
   */
  addPreAdmissionWorklist(name: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptAddPreAdmissionWorklist();
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.ADD[1]
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.ADD[1],
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.ADD[0],
      false,
      true,
      { force: true }
    );
    cy.shouldBeEnabled(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.WORKLIST_NAME[1]
    );
    cy.cType(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.WORKLIST_NAME[1],
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.WORKLIST_NAME[0],
      name
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.getButtonText(DoneOrCancel.done),
      DoneOrCancel.done
    );
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(selectorFactory.getSpanText(name), '');
  }

  /**
   * @details - To click on the plus icon in the worklist template
   * @param leftRight - Click plus icon in template based on left or right
   * @API - API's are not available
   * @author - Divya
   */
  clickPlusIconInPreAdmissionInstructions(leftRight: string) {
    const value =
      leftRight.trim().toUpperCase() === LeftOrRight.left.trim().toUpperCase()
        ? 0
        : 1;

    cy.cGet(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.WORKLIST_OPTIONS[1]
    )
      .eq(value)
      .find(OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.PLUS_ICON[1])
      .click();
  }

  /**
   * @details - To select the item in the worklist template
   * @param worklist - Selecting the worklist which is used as parameter
   * @API -API's are not available
   * @author - Divya
   */
  selectWorkListItemInPreAdmissionInstructions(worklist: string) {
    cy.cGet(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.WORKLIST_SECTION[1]
    ).within(() => {
      cy.cType(
        OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.SEARCH[1],
        OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.SEARCH[0],
        worklist
      );
      cy.cClick(worklist, worklist, true, true);
    });
  }

  /**
   * @details - To select yes or no in the worklist template
   * @param yesNo - used as parameter to select
   * @API - API's are not available
   * @author - Divya
   */
  clickYesNoInDocumentsAcknowledged(yesNo: string = YesOrNo.yes) {
    cy.cGet(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.DOCUMENTS_ACKNOWLEDGED
        .YES_NO[1]
    ).within(() => {
      cy.cClick(selectorFactory.getSpanText(yesNo), yesNo, false, true);
    });
    cy.shouldBeEnabled(
      selectorFactory.getH4Text(
        OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS
          .DOCUMENTS_ACKNOWLEDGED.SUB_HEADER[0]
      )
    );
  }

  /**
   * @details - To verify search and add button in documents and disclosure
   * @param exist - used as parameter to verify the presence
   * @API - API's are not available
   * @author - Divya
   */
  verifySearchAndButtonInDocumentsAcknowledged(exist: boolean = false) {
    const OR_DOCUMENTS_ACKNOWLEDGED =
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS
        .DOCUMENTS_ACKNOWLEDGED;
    cy.cNotExist(
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_INPUT[1],
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_INPUT[0],
      exist
    );

    cy.cNotExist(
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_BUTTON[1],
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_BUTTON[0],
      exist
    );
  }

  /**
   * @details - To add items in documents and disclosure
   * @param text - used as parameter to enter the text
   * @API - API's are not available
   * @author - Divya
   */
  addItemsToDocumentsAcknowledged(text: string) {
    const OR_DOCUMENTS_ACKNOWLEDGED =
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS
        .DOCUMENTS_ACKNOWLEDGED;
    cy.cType(
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_INPUT[1],
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_INPUT[0],
      text,
      false,
      true
    );
    cy.cClick(
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_BUTTON[1],
      OR_DOCUMENTS_ACKNOWLEDGED.ADD_ITEM_BUTTON[0],
      false,
      true
    );
  }

  /**
   * @details - To add configurable questions in pre admission instructions
   * @param name - used as parameter to add question to the worklist
   * @API - API's are not available
   * @author - Divya
   */
  addConfigurableQuestions(name: string) {
    const loc = CommonUtils.concatenate(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.CONFIGURABLE_QUESTIONS
        .SELECT_ITEM[1],
      ' ',
      selectorFactory.getSpanText(
        OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS
          .CONFIGURABLE_QUESTIONS.SELECT_ITEM[0]
      )
    );
    cy.cClick(loc, '');
    cy.cClick(selectorFactory.getSpanText(name), name, false, true);
  }

  /**
   * @details - To search and select pre admission instructions in worklist
   * @param name - used to search worklist
   * @API -API's are available - Implemented Completely
   * @author - Divya
   */
  searchAndSelectPreAdmissionInstructionsWorklist(name: string) {
    const interceptCollection =
      this.nursingConfigApis.interceptSelectPreAdmissionInstruction();
    cy.cType(
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.WORKLIST_SEARCH[1],
      OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.WORKLIST_SEARCH[0],
      name
    );
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(name), name);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To click on add in fee schedule
   * @Api API's are not available
   * @author - Divya
   */
  clickAddInFeeSchedule() {
    cy.cClick(selectorFactory.getDataTestId(this.OR_FEE_SCHEDULE.ADD[1]), '');
  }
}
