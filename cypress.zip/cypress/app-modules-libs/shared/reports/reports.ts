import { OR_REPORTS } from './or/reports.or';

export default class Reports {
  /**
   * @details - enter MRN in audit trail reports
   * @param mrn
   */
  enterMRN(mrn: number) {
    cy.cType(OR_REPORTS.AUDIT_TRAIL.MRN[1], OR_REPORTS.AUDIT_TRAIL.MRN[0], mrn);
  }

  /**
   * @details - select Area in audit trail reports
   * @param area -string array
   */
  selectAreaValues(area: string) {
    cy.switchToIframeBody(OR_REPORTS.AUDIT_TRAIL.IFRAME[1])
      .find(OR_REPORTS.AUDIT_TRAIL.AREA[1])
      .click();
    cy.switchToIframeBody(OR_REPORTS.AUDIT_TRAIL.IFRAME[1]).find(area).click();
  }

  /**
   * @details - click on view report in audit trail reports
   * @APIs are available - Not Implemented
   */
  clickViewReport() {
    //TODO : Need to Implement API
    cy.switchToIframeBody(OR_REPORTS.AUDIT_TRAIL.IFRAME[1])
      .find(OR_REPORTS.AUDIT_TRAIL.VIEW_REPORT[1])
      .click();
  }

  /**
   * @details - verify the data displayed in audit trail reports
   * @param value - to verify data in reports
   * @APIs are not available
   */
  verifyValueInReports(value: string) {
    cy.switchToIframeBody(OR_REPORTS.AUDIT_TRAIL.IFRAME[1]).contains(value);
  }

  /**
   * @details - select Configuration From Reports Configuration
   * @param configName
   * @APIs are available - Not Implemented
   */
  selectReportConfiguration(configName: string) {
    cy.cIsVisible(OR_REPORTS.REPORTS.SEARCH[1], OR_REPORTS.REPORTS.SEARCH[0]);
    cy.cType(
      OR_REPORTS.REPORTS.SEARCH[1],
      OR_REPORTS.REPORTS.SEARCH[0],
      configName
    );
    //TODO : Need to Implement API
    cy.cClick(configName, configName, true);
  }
}
