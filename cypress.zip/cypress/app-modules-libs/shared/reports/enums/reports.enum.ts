export enum Area {
    all = 'All',
    anesthesia = 'Anesthesia',
    facesheet = 'Face Sheet',
  }