import {
  Application,
  CommonClassAttributes,
  ShouldMethods,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';

import { OR_SCHEDULE_GRID } from './or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_CASE_CREATION } from './or/create-case.or';

import { ScheduleGridApis } from './api/schedule-grid.api';

export default class ScheduleGrid {
  /* instance variables */
  private scheduleGridApis = new ScheduleGridApis();

  private sisOfficeDesktop: SISOfficeDesktop;

  /**
   * @details - Self Initialization For NewPatientInfo
   * @details - Page Initialization For SISOfficeDesktop
   */
  constructor() {
    this.sisOfficeDesktop = new SISOfficeDesktop();
  }

  /**
   * @details - Verify Room Dropdown is visible in schedule Grid
   * @API - API's are not available
   */
  verifyRoomInScheduleGrid() {
    cy.cIsVisible(
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[1],
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[0]
    );
    cy.cIsVisible(
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[0],
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[0],
      true,
      true
    );
  }

  /**
   * @details - Select Room in schedule Grid from Sho All Dropdown
   * @param room - Schedule, Tracker, Yes, No
   * @API - API's are not available
   */
  selectRoomInScheduleGrid(room: string) {
    cy.cClick(
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[1],
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[0],
      false,
      true,
      { force: true }
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(OR_SCHEDULE_GRID.ROOM_FILTER[1], OR_SCHEDULE_GRID.ROOM_FILTER[0]);
    cy.cGet(selectorFactory.getMultiselectDropdownItems(room)).should(
      ShouldMethods.length,
      1
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(selectorFactory.getMultiselectDropdownItems(room), room);
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[1],
      OR_SCHEDULE_GRID.SHOW_ALL_DROPDOWN[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.shouldBeEnabled(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CREATE_A_CASE_TAB[1]
    );
    // Removed case pending request api due to latency issue and added create case tab should be enable verification
  }

  /**
   * @details - Select patient in schedule Grid
   * @param patientName
   * @API - API's are not available
   */
  selectPatientCase(patientName: string) {
    cy.cClick(
      selectorFactory.patientCaseTileInScheduleGrid(patientName),
      patientName
    );
  }

  /**
   * @details - To click on the Block in Schedule grid.
   * @param blockName - Block Name which has to be selected to be passed.
   * @API - API's are available - Implemented Completely
   * @Author - Rakesh Donakonda.
   */
  clickBlockNameInSchedule(blockName: string) {
    const interceptCollection =
      this.scheduleGridApis.interceptOpenBlockInScheduleGridApi();
    cy.cIntercept(interceptCollection);
    this.selectBlockName(blockName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To click on the Block in Block Schedule.
   * @param blockName - Block Name which has to be selected to be passed.
   * @API - API's are available - Implemented Completely
   * @Author - Rakesh Donakonda.
   */
  clickBlockNameInBlockSchedule(blockName: string) {
    const interceptCollection =
      this.scheduleGridApis.interceptOpenBlockInBlockScheduleApi();
    cy.cIntercept(interceptCollection);
    this.selectBlockName(blockName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select Block Name in schedule Grid
   * @param block - blockName
   * @API -API's are available - Implemented Completely
   * @author Madhu Kiran
   */
  selectBlockName(blockName: string) {
    cy.cClick(selectorFactory.blockNameInScheduleGrid(blockName), blockName);
  }

  /**
   * @details - Select any Button (ex: Default View, Show Cancelled Cases) in  User Settings Popup
   * @param icon - passed Face sheet, Edit, Check-In, Cancel icons to select
   * @param patientName - passed Patient details
   * @API - API's are available - Implemented Completely
   */
  selectPatientAndClickOnIconInCaseDetailsPopup(
    patientName: string,
    icon: string
  ) {
    let interceptCollection: ApiEndpoint[] = [];
    let locator: string = '';
    cy.cRemoveMaskWrapper(Application.office);
    this.selectPatientCase(patientName);
    switch (icon) {
      case OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]:
        locator = OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[1];
        interceptCollection =
          this.scheduleGridApis.interceptFaceSheetIconApis();
        break;
      case OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]:
        locator = OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[1];
        interceptCollection = this.scheduleGridApis.interceptEditIconApis();
        break;
      case OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]:
        locator = OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[1];
        interceptCollection = this.scheduleGridApis.interceptCheckInIconApis();
        break;
      case OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_ICON[0]:
        locator = OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_ICON[1];
        break;
      case OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVE_BUTTON[0]:
        locator = OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVE_BUTTON[1];
        break;
      default:
        break;
    }
    cy.cIntercept(interceptCollection);
    cy.cClick(locator, icon, false, true);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on Print Icon in schedule grid page
   * @API - API's are not available
   */
  clickPrintIcon() {
    cy.cClick(OR_SCHEDULE_GRID.PRINT_ICON[1], OR_SCHEDULE_GRID.PRINT_ICON[0]);
  }

  /**
   * @details - Select Yes or No as per value for Show Cancelled Cases In User Settings Popup
   * @API - API's are not available
   */
  selectShowCancelledCase(value: string) {
    if (value === YesOrNo.yes) {
      cy.cClick(
        OR_SCHEDULE_GRID.USER_SETTINGS_POPUP.SHOW_CANCELLED_CASES.YES_BUTTON[1],
        OR_SCHEDULE_GRID.USER_SETTINGS_POPUP.SHOW_CANCELLED_CASES.YES_BUTTON[0]
      );
    } else {
      cy.cClick(
        OR_SCHEDULE_GRID.USER_SETTINGS_POPUP.SHOW_CANCELLED_CASES.NO_BUTTON[1],
        OR_SCHEDULE_GRID.USER_SETTINGS_POPUP.SHOW_CANCELLED_CASES.NO_BUTTON[0]
      );
    }
  }

  /**
   * @details - Select Patient and Cancel the case
   * @param - patient
   * @param - CancelReason
   * @API - API's are available - Implemented Completely
   */
  selectPatientAndCancelCase(patient: string, CancelReason: string) {
    const interceptCollection =
      this.scheduleGridApis.interceptCancelDoneButtonApis();
    this.selectPatientAndClickOnIconInCaseDetailsPopup(
      patient,
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_ICON[0]
    );
    cy.cIsVisible(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]
    );
    cy.cClick(
      OR_SCHEDULE_GRID.CANCEL_CASE_POPUP.SELECT_REASON_DROPDOWN[1],
      OR_SCHEDULE_GRID.CANCEL_CASE_POPUP.SELECT_REASON_DROPDOWN[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(CancelReason),
      OR_SCHEDULE_GRID.CANCEL_CASE_POPUP.SELECT_REASON_VALUE[0]
    );

    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.clickDoneButton();

    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verify the patient case is not displayed in Schedule Grid
   * @param - patient
   * @API - API's are not available
   */
  verifyPatientCaseUnpresence(patient: string) {
    cy.cNotExist(
      selectorFactory.patientCaseTileInScheduleGrid(patient),
      OR_SCHEDULE_GRID.PATIENT_CASE_TILE[0]
    );
  }

  /**
   * @details - verify Icons State In Cancelled Case
   * @API - API's are not available
   */
  verifyIconsStateInCancelledCase() {
    cy.cIsVisible(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[0],
      false,
      true
    );
    cy.cHasClass(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0],
      CommonClassAttributes.disabled,
      false,
      false
    );
    cy.cHasClass(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0],
      CommonClassAttributes.disabled,
      false,
      true
    );
    cy.cHasClass(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0],
      CommonClassAttributes.disabled,
      false,
      true
    );
    cy.cHasClass(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[0],
      CommonClassAttributes.disabled,
      false,
      false
    );
    cy.cIsVisible(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_REASON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_REASON[0],
      false,
      true
    );
    cy.cIsVisible(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCELLED_AT[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCELLED_AT[0],
      false,
      true
    );
  }

  /**
   * @details - verify Cancel Reason In Case Details Popup
   * @API - API's are not available
   */
  verifyCancelReasonInCaseDetailsPopup(Reason: string) {
    cy.cIncludeText(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_REASON_TEXT[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_REASON_TEXT[0],
      Reason,
      false,
      true
    );
  }

  /**
   * @details - Click  On Reinstate Button
   * @API - API's are available
   * @Author -Spoorthy,Praveen
   */
  clickOnReinstateButton() {
    const interceptCollection = this.scheduleGridApis.interceptReinstateApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verify Icons State In Reinstate Case
   * @API - API's are not available
   */
  verifyIconsStateInReinstateCase() {
    cy.cIsVisible(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_ICON[0],
      false,
      true
    );
    cy.cHasClass(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0],
      CommonClassAttributes.disabled,
      false,
      false
    );
    cy.cHasClass(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0],
      CommonClassAttributes.disabled,
      false,
      false
    );
    cy.cNotExist(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.REINSTATE_ICON[0],
      true
    );
    cy.cNotExist(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCELLED_AT[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCELLED_AT[0],
      true
    );
    cy.cNotExist(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_REASON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CANCEL_REASON[0],
      true
    );
  }

  /**
   * @details - To verify the patient case is displayed in Schedule Grid
   * @param  patient - Patient name
   * @API - API's are not available
   */
  verifyPatientCase(patient: string) {
    cy.cIsVisible(
      selectorFactory.patientCaseTileInScheduleGrid(patient),
      OR_SCHEDULE_GRID.PATIENT_CASE_TILE[0]
    );
  }

  /**
   * @details - Search and select the patient  in Schedule Grid Global search field
   * @param searchStr - Text to search the patient name
   * @param patientName - Patient first name
   * @API - API's are available - Implemented Completely
   * @author -Madhu Kiran
   */
  globalSearch(searchStr: string, patientName: string) {
    const interceptCollection =
      this.scheduleGridApis.interceptFaceSheetIconApis();
    cy.cClick(
      OR_SCHEDULE_GRID.GLOBAL_SEARCH.SEARCH[1],
      OR_SCHEDULE_GRID.GLOBAL_SEARCH.SEARCH[0]
    );
    cy.cType(OR_SCHEDULE_GRID.GLOBAL_SEARCH.SEARCH[1], searchStr, searchStr);
    cy.cIntercept(interceptCollection);
    cy.cGet(OR_SCHEDULE_GRID.GLOBAL_SEARCH.SEARCH_RESULTS[1])
      .contains(patientName)
      .click();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify if the schedule grid is enabled
   * @API - API's are not available
   */
  scheduleGridEnable() {
    cy.shouldBeEnabled(
      selectorFactory.getDivText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
          .SCHEDULE_GRID[0]
      )
    );
  }

  /**
   * @details - Select Arrive Button in User Settings Popup
   * @param patientName - patient name needs to be passed
   * @API - API's are available - Implemented Completely
   * @author Bindhu
   */
  clickArriveButton(patientName: string) {
    const interceptCollection = this.scheduleGridApis.interceptArriveApi();
    this.selectPatientCase(patientName);
    cy.cClickAndWaitApis(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVE_BUTTON[1],
      interceptCollection
    );
  }

  /**
   * @details - Click Arrive Button in Case Details Popup of Patient Case
   * @param patientName - Patient first name
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectPatientAndClickOnArriveButtonInCaseDetailsPopup(patientName: string) {
    this.selectPatientCase(patientName);
    cy.cClick(
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVE_BUTTON[1],
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVE_BUTTON[0],
      false,
      true
    );
    /**
     * Waiting for Arrival Time Locator to attach to DOM
     */
    cy.get(OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVAL_TIME[1], {
      timeout: Cypress.config('defaultCommandTimeout'),
    }).should(ShouldMethods.visible);
    this.sisOfficeDesktop.selectSisLogo();
  }
}
