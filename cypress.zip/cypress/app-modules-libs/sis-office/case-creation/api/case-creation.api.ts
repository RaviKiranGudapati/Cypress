import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export class CaseCreationApis {
  /**
   * @details - Preference Card Add API Calls
   */
  interceptAddPreferenceCardApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.preference_card_procedure_list,
        'PreferenceCardProcedureList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.preference_card_request_template,
        'PreferenceCardRequestTemplate',
        200
      ),
    ];
  }

  /*
   * @details - click on insurance done button
   */
  interceptClickOnInsuranceDoneButtonApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(WaitMethods.post, SubRoutes.insert, 'Insert', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPatientInsurancesByPatientId ',
        200
      ),
    ];
  }

  /**
   * @details - Click On done button
   */
  interceptClickOnDoneButtonApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_duplicate_patients,
        'GetDuplicatePatients',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient,
        'GetPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_current_facility_address,
        'GetCurrentFacilityAddresses',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting billing details
   */
  interceptBillingDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPatientInsurancesByPatientId',
        200
      ),

      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
    ];
  }

  /**
   * @details - Clicking the Done button in the create case window
   */
  CreateCaseDoneApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.upsert_case_summary,
        'UpsertCaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.create_patient,
        'CreatePatient',
        200
      ),
    ];
  }

  /**
   * @details - Click On guarantor popup Done Button
   */
  interceptGuarantorPopUpDoneButtonApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.save_patient_guarantor,
        'SavePatientGuarantor',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
    ];
  }

  /**
   * @details - click on next button after entering patient details
   */
  interceptCaseDetailsApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_app_type_casepack_map_data,
        'GetAppTypeCasePackMapData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_equipments,
        'GetEquipments',
        200
      ),
    ];
  }

  /**
   * @details - Click On Insurance Add Button
   */
  interceptInsuranceAddButtonApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_carriers,
        'GetInsuranceCarriers',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_current_facility_address,
        'GetCurrentFacilityAddresses',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting form and consent in check-in
   */
  interceptSelectFormsAndConsentsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
    ];
  }

  /**
   * @details - click on previous button after entering case details
   * @author -Arushi
   */
  interceptPatientDetailsApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetInsurancesByPatientID',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after clicking billing and payments in checkIn
   * @author - chandrika
   */
  interceptBillingAndPaymentsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'PatientGuarantor',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurance_by_id,
        'Insurance',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting Patient after searching in Create Case tab
   * @author -Madhu Kiran
   */
  interceptSelectPatientInPatientSearchResult(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'GetPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.request_lock,
        'RequestLock',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Done button after creating patient in My Task
   * @author -Madhu Kiran
   */
  interceptDoneButtonInMyTaskFooter(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.create_patient,
        'CreatePatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.upsert_case_summary,
        'UpsertCaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.request_lock,
        'RequestLock',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.payer_eligibility,
        'PayerEligibility',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.scdl_grid_gemini_get,
        'GetSchedulingData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.block_schedule_get,
        'GetBlockScheduleData',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Done button in check-in
   * @author -Madhu Kiran
   */
  interceptForDoneButtonCheckIn(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.scdl_grid_gemini_get,
        'GetSchedulingData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.block_schedule_get,
        'GetBlockScheduleData',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Delete Insurance
   * @author -Madhu Kiran
   */
  interceptDeleteInsuranceApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.delete,
        SubRoutes.insurance_gemini_Delete,
        'Delete',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPatientInsurancesByPatientId',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Clear Room
   * @author -Madhu Kiran
   */
  interceptClearRoom(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_case_conflicts_minimal,
        'GetCaseConflictsMinimal',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for enter CPT code
   * @author -Madhu Kiran
   */
  interceptEnterCptCode(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule,
        'Search',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Select Secondary Guarantor No
   * @author -Madhu Kiran
   */
  interceptSecondaryGuarantorNo(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after clicking print receipt in  billing and payments
   * @author - chandrika
   */
  interceptPrintReceiptApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(WaitMethods.post, SubRoutes.post_reports, 'Reports', 200),
    ];
  }

  /**
   * @details - Api collection after clicking create case tab
   * @author - chandrika
   */
  interceptCreateCaseTabApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_eligibility_config_for_org,
        'EligibilityConfig',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Select Guarantor
   * @author -Madhu Kiran
   */
  interceptSelectGuarantor(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
    ];
  }

  /**
   * @details - Equipment api
   * @author - vamshi
   */
  interceptEquipmentApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_equipment_used,
        'GetEquipmentUsed',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after clicking create case tab
   * @author - chandrika
   */
  interceptLossDataApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.security_release_lock,
        'Security',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Add New Guarantor
   * @author - vamshi
   */
  interceptAddNewGuarantor(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.facility_address,
        'GetCurrentFacilityAddresses',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for click done button in edit insurance
   * @author -Madhu Kiran
   */
  interceptEditInsuranceDone(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.insurance_gemini_update,
        'Update',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.insurance,
        'GetPatientInsurancesByPatientId',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting insurance dropdown value in insurance popup
   * @author - chandrika
   */
  interceptSelectInsuranceDropdownValueApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_insurance_plans,
        'InsurancePlan',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Select Secondary Guarantor Yes
   * @author -Madhu Kiran
   */
  interceptSecondaryGuarantorYes(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_current_facility_address,
        'GetCurrentFacilityAddresses',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting patient Details tab in the edit Case
   * @author -Spoorthy
   */
  interceptSelectPatientDetailsInEditApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'PatientInsurances',
        200
      ),
    ];
  }

  /**
   * @details - Api collection to click on existing Insurance name in
   * @author -Spoorthy
   */
  interceptExistingInsuranceNameApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_carriers,
        'InsurancesCarriers',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_plan,
        'InsurancePlan',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_claim_office,
        'InsuranceClaim',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting cases details while creating case
   * @author -Spoorthy
   */
  interceptClickOnCasesDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_app_type_casepack_map_data,
        'CasePack',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_equipments,
        'Equipment',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting Attachment in Check-in
   * @author -Spoorthy
   */
  interceptAttachmentInCheckInApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'PatientGuarantor',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.all_attachment,
        'Attachment',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting guarantor self in billing details
   * @author -Spoorthy
   */
  interceptSecondaryGuarantorApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'PatientGuarantors',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for selecting guarantor in billing details
   * @author -Spoorthy
   */
  interceptSecondaryGuarantorDropdownApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_current_facility_addresses,
        'CurrentFacility',
        200
      ),
    ];
  }

  /*
   * @details - click on insurance done button
   */
  interceptDoneInInsuranceCoverage(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPatientInsurancesByPatientId ',
        200
      ),
    ];
  }
}
