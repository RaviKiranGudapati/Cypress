import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export class ScheduleGridApis {
  /**
   * @details - click on done button after canceling case
   * @author Madhu Kiran
   */
  interceptCancelDoneButtonApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.upsert_case_status,
        'UpsertCaseStatus',
        200
      ),
    ];
  }

  /**
   * @details - Api Collection for check-in icon
   * @author -Madhu Kiran
   */
  interceptCheckInIconApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_registrations,
        'GetCaseRegistration',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_data,
        'GetPatient',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.gemini, ' Gemini', 200),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_summary,
        'GetSpecialtyByCase',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPatientInsurancesByPatientId',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_guarantors,
        'GetPatientGuarantors',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.all_api, 'AllApi', 200),
    ];
  }

  /**
   * @details -  Api Collection for Face Sheet icon
   * @author -Madhu Kiran
   */
  interceptFaceSheetIconApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'GetPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_image,
        'GetPatientImage',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_faceSheet_case_list_by_patient,
        'GetFaceSheetCaseListByPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_coordination,
        'CaseCoordination',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_unbillable_inventory,
        'GetUnbillableInventoryItems',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_user_preferences,
        'GetUserPreferences',
        200
      ),
    ];
  }

  /**
   * @details -  Api Collection for Edit icon
   * @author -Madhu Kiran
   */
  interceptEditIconApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_request_data_by_case_summary_id,
        'GetCaseRequestDataByCaseSummaryId',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_data,
        'GetPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_eligibility_config_for_org,
        'GetEligibilityConfigForOrg',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_details,
        'GetAllCaseDetails',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_app_type_casepack_map_data,
        'GetAppTypeCasePackMapData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_equipments,
        'GetEquipments',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_all_pref_card_equipment,
        'GetAllPrefCardEquipment',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_case_conflicts_minimal,
        'GetCaseConflictsMinimal',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_block_utilization,
        'GetBlockUtilization',
        200
      ),
      new ApiEndpoint(WaitMethods.get, SubRoutes.all_api, 'AllApi', 200),
    ];
  }

  /**
   * @details - Api collection after selecting block in Block Schedule.
   * @author - Rakesh Donakonda
   */
  interceptOpenBlockInBlockScheduleApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_packs,
        'GetCasePacks',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_color_themes,
        'GetAllColorThemes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.block_schedule_conflict_check,
        'GetBlockConflicts',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after selecting block in Schedule Grid
   * @author - Rakesh Donakonda
   */
  interceptOpenBlockInScheduleGridApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_eligibility_config_for_org,
        'GetEligibility',
        200
      ),
    ];
  }

  /**
   *@details API calls on click Reinstate button in schedule grid page.
   *@author Praveen
   */
  interceptReinstateApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.upsert_case_status,
        'UpsertCaseStatus',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.scdl_grid_gemini_get,
        'GetSchedulingData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.block_schedule_get,
        'GetBlockSchedule',
        200
      ),
    ];
  }

  /**
   *@details API calls on click on arrive in schedule grid page.
   *@author Bindhu
   */
  interceptArriveApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.arrive,
        'ScheduleGridArrive',
        200
      ),
    ];
  }
}
