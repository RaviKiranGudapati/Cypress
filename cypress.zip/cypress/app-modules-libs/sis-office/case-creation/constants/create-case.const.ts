export const newPatientLabelValues = [
  'Patient First Name*',
  'Last Name*',
  'Middle Initial',
  'DOB',
  'Suffix',
];
export const caseDetailsLabels = [
  'Operating Room*',
  'Case Notes',
  'Date of Service*',
  'End Time*',
  'Duration',
  'Clean-Up Time',
  'Referring Physician',
  'Appointment Type*',
  'Anesthesia Type',
  'Preference Cards',
  'Equipment',
];
export const insurancePopupLabels = [
  'First Name*',
  'Last Name*',
  'MI',
  'Group Name',
  'Group Number',
  'Employer',
  'Suffix',
];
export const procedureAndCaseDetailLabels = [
  'CPT® Code and Description',
  'Modified Proc. Description',
  'Physician',
  'Laterality',
  'Pre-Op Diagnosis Code',
];
