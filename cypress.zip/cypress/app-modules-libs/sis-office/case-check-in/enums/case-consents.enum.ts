export enum CaseConsentsHeader {
    other_user = 'Other User',
    sign = 'Sign',
    addendum_sign = 'Addendum Physician Sign',
    addendum_other_user = 'Addendum Other Sign',
    all = 'All',
    content_editable = 'contenteditable',
    li = 'li',
  }
  