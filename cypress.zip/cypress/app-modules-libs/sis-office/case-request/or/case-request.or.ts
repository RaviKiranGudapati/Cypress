import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_CASE_REQUEST = {
  CASE_REQUEST: {
    DENY: ['Deny', '#btnDenyRequest'],
    CANCEL: ['Cancel', '#btnCancel'],
    DENY_REQUEST_DROPDOWN: [
      'Deny Request',
      CommonUtils.concatenate(
        '#itemsDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        `:contains('Select Item')`
      ),
    ],
    DENY_DROPDOWN: [
      'Deny Dropdown',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown,
        '-panel ',
        CoreCssClasses.DropDown.loc_p_dropdown_items
      ),
    ],
    DENY_HEADER: [
      'Deny Request',
      CommonUtils.concatenate(CoreCssClasses.Dialog.loc_dialog_title, ' h3'),
    ],
    DENY_DONE: [
      'Done',
      CommonUtils.concatenate(CoreCssClasses.Panel.loc_p_footer, ' #btnDone'),
    ],
    DENY_REQUEST_REASON_TEXT: [
      'Deny Request Reason Text',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_box_content,
        ' .addnew_content .padding-bottom'
      ),
    ],
    PREVIOUS: ['Previous', '#btnPrevious'],
    DONE: ['Done', '.case-request-sticky-footer-container #btnDone'],
    CASE_REQUEST_ROW: ['', `tbody[class="p-element p-datatable-tbody"]`],
  },
  REQUEST_DETAILS: {
    REQUEST_INFORMATION: ['Request Information'],
    CASE_HEADERS_LABELS: [
      'Case',
      '.case-component .inside-div label:not(.text-result)',
    ],
    CASE_HEADER_VALUES: [
      'Case',
      '.case-component .inside-div label.text-result',
    ],
    CASE_HEADER_NOTE_LABELS: [
      'Case Notes',
      '.case-component .case-component label',
    ],
    CASE_HEADER_NOTE_VALUES: [
      'Case Notes Values',
      `.case-component .case-component div[class*='div-container']`,
    ],
    PROCEDURE_HEADER: [
      'Procedure',
      CommonUtils.concatenate(
        '.procedure-component ',
        CoreCssClasses.List.loc_p_data_table,
        '-thead ',
        CommonGetLocators.th
      ),
    ],
    PROCEDURE_VALUE: [
      'Procedure',
      CommonUtils.concatenate(
        '.procedure-component ',
        CoreCssClasses.List.loc_p_data_table,
        ' ',
        CommonGetLocators.tr,
        ' ',
        CommonGetLocators.div,
        ' ',
        CommonGetLocators.span
      ),
    ],
    PATIENT_INFO_HEADER: [
      'Patient Info',
      '.patient-info-block .inside-div label:not(.text-result)',
    ],
    PATIENT_ADDRESS_HEADER: [
      'Patient Address',
      '.address-block .inside-div label:not(.text-result)',
    ],
    PATIENT_ADDRESS_VALUES: [
      'Patient Address',
      '.address-block .inside-div label.text-result',
    ],
    PATIENT_INFO_VALUES: [
      'Patient info',
      '.patient-info-block .inside-div label.text-result',
    ],
    PRIMARY_INSURANCE_HEADERS: [
      'Primary Insurance',
      '.insurance-div .grouping-data label:not(.text-result)',
    ],
    PRIMARY_INSURANCE_VALUES: [
      'Primary Insurance',
      '.insurance-div .grouping-data label.text-result',
    ],
    PRIMARY_GUARANTOR_HEADERS: [
      'Primary Guarantor',
      '.guarantor-div .grouping-data label:not(.text-result)',
    ],
    PRIMARY_GUARANTOR_VALUES: [
      'Primary Guarantor',
      '.guarantor-div .grouping-data label.text-result',
    ],
  },
  CASE_ATTACHMENT: {
    CASE_ATTACHMENT_TAB: ['Case Attachments'],
    FILE_NAME: [
      'File Name',
      CommonUtils.concatenate(
        '#expanded_ .file-name-col ',
        CommonGetLocators.span
      ),
    ],
  },
};
