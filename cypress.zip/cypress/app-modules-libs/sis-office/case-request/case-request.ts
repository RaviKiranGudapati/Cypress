import {
  CommonClassAttributes,
  ShouldMethods,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import { RequestInformation } from '../../../test-data-models/sis-office/case-requests/case-request.model';

import { OR_CASE_REQUEST } from './or/case-request.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import CreateCase from '../case-creation/create-case';

import { CaseRequestApis } from './api/case-request.api';
import {
  caseRequestLabels,
  caseRequestNoteLabels,
  patientAddressInfoLabels,
  patientInfoLabels,
  primaryGuarantorLabels,
  primaryInsuranceLabels,
  procedureRequestLabels,
} from './constants/case-request.const';

/* instance variables */
const createCase = new CreateCase();
const sisOfficeDesktop = new SISOfficeDesktop();

export default class CaseRequest {
  private caseRequestApis = new CaseRequestApis();

  /**
   * @details To click on Deny button in case request
   * @Api - API's are not available
   * @author - Praveen
   */
  clickDeny() {
    cy.cClick(
      OR_CASE_REQUEST.CASE_REQUEST.DENY[1],
      OR_CASE_REQUEST.CASE_REQUEST.DENY[0],
      false,
      true
    );
  }

  /**
   * @details To click on deny request done button
   * @Api - API's are not available
   * @author - Praveen
   */
  clickDenyRequestDone() {
    cy.cClick(
      OR_CASE_REQUEST.CASE_REQUEST.DENY_DONE[1],
      OR_CASE_REQUEST.CASE_REQUEST.DENY_DONE[0]
    );
  }

  /**
   * @details To click on deny request header
   * @param - titleName - To provide the title name of the popup -Deny Request
   * @Api - API's are not available
   * @author - Praveen
   */
  clickDenyRequestHeader(titleName: string) {
    cy.cClick(selectorFactory.getH3Text(titleName), titleName);
  }

  /**
   * @details To click on deny reason from dropdown
   * @param - value - To provide the deny reason based on the value
   * @Api - API's are available,Implemented completely
   * @author - Praveen
   */
  selectDenyReason(value: string) {
    const interceptCollection =
      this.caseRequestApis.interceptDenyDictionaryApi();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_CASE_REQUEST.CASE_REQUEST.DENY_REQUEST_DROPDOWN[1],
      OR_CASE_REQUEST.CASE_REQUEST.DENY_REQUEST_DROPDOWN[0],
      false,
      true,
      { force: true }
    );
    cy.cGet(OR_CASE_REQUEST.CASE_REQUEST.DENY_DROPDOWN[1]).within(() => {
      cy.cClick(
        selectorFactory.getSpanText(value),
        OR_CASE_REQUEST.CASE_REQUEST.DENY_REQUEST_DROPDOWN[0]
      );
    });
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To click on cancel button in Deny Popup
   * @Api - API's are not available
   * @author - Praveen
   */
  clickCancel() {
    cy.cClick(
      OR_CASE_REQUEST.CASE_REQUEST.CANCEL[1],
      OR_CASE_REQUEST.CASE_REQUEST.CANCEL[1]
    );
  }

  /**
   * @details To verify the Deny Request title
   * @param - titleName - To provide the title name of the Deny Request popup
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyDenyRequestTitle(titleName: string) {
    cy.cGet(OR_CASE_REQUEST.CASE_REQUEST.DENY_HEADER[1]).then(($title) => {
      expect($title.text()).to.contain(titleName);
    });
  }

  /**
   * @details To verify the Deny Request Reason text
   * @param - reasonText - To provide the reason text value
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyDenyRequestReasonText(reasonText: string) {
    cy.cGet(OR_CASE_REQUEST.CASE_REQUEST.DENY_REQUEST_REASON_TEXT[1]).then(
      ($reasonVal) => {
        expect($reasonVal.text()).to.contain(reasonText);
      }
    );
  }

  /**
   * @details To verify the header labels under case section
   * @param - headerLabels - Header label names to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyRequestInfoCaseHeaders(headerLabels: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.CASE_HEADERS_LABELS[1]).each(
      ($labels, index) => {
        expect($labels.text()).to.contain(headerLabels[index]);
      }
    );
  }

  /**
   * @details To verify the header values under case section
   * @param - headerValues - Header values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyRequestInfoCaseValues(headerValues: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.CASE_HEADER_VALUES[1]).each(
      ($values, index) => {
        expect($values.text()).to.contain(headerValues[index]);
      }
    );
  }

  /**
   * @details To verify the header labels Notes under case section
   * @param - headerNoteLabels - Header values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyCaseRequestNoteLabels(headerNoteLabels: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.CASE_HEADER_NOTE_LABELS[1]).each(
      ($labels, index) => {
        expect($labels.text()).to.contain(headerNoteLabels[index]);
      }
    );
  }

  /**
   * @details To verify the header labels Notes under case section
   * @param - headerNoteValues - Header values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyCaseRequestNoteValues(headerNoteValues: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.CASE_HEADER_NOTE_VALUES[1]).each(
      ($values, index) => {
        expect($values.text()).to.contain(headerNoteValues[index]);
      }
    );
  }

  /**
   * @details To verify the header labels under Procedure section
   * @param  - procedureLabels - Header values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyProcedureRequestLabels(procedureLabels: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PROCEDURE_HEADER[1]).each(
      ($labels, index) => {
        expect($labels.text()).to.contain(procedureLabels[index]);
      }
    );
  }

  /**
   * @details To verify the procedure values under Procedure section
   * @param - procedureValues - Procedure values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyProcedureRequestValues(procedureValues: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PROCEDURE_VALUE[1]).each(
      ($values, index) => {
        expect($values.text()).to.contain(procedureValues[index]);
      }
    );
  }

  /**
   * @details To verify the patient info labels under Patient section
   * @param - patientInfoLabels - Patient info labels to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPatientInfoRequestLabels(patientInfoLabels: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PATIENT_INFO_HEADER[1]).each(
      ($labels, index) => {
        expect($labels.text()).to.contain(patientInfoLabels[index]);
      }
    );
  }

  /**
   * @details To verify the patient address labels under Patient section
   * @param  - patientAddressLabels - Patient address labels to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPatientAddressInfoRequestLabels(patientAddressLabels: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PATIENT_ADDRESS_HEADER[1]).each(
      ($labels, index) => {
        expect($labels.text()).to.contain(patientAddressLabels[index]);
      }
    );
  }

  /**
   * @details To verify the patient address values under Patient section
   * @param - patientAddressValues - Patient address values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPatientAddressRequestValues(patientAddressValues: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PATIENT_ADDRESS_VALUES[1]).each(
      ($values, index) => {
        expect($values.text()).to.contain(patientAddressValues[index]);
      }
    );
  }

  /**
   * @details To verify the patient info values under Patient section
   * @param - patientInfoValues - Patient info values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPatientRequestInfoValues(patientInfoValues: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PATIENT_INFO_VALUES[1]).each(
      ($values, index) => {
        expect($values.text()).to.contain(patientInfoValues[index]);
      }
    );
  }

  /**
   * @details To verify the primary insurance labels under Primary Insurance section
   * @param - primaryInsuranceLabels - Patient info values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPrimaryInsuranceLabels(primaryInsuranceLabels: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PRIMARY_INSURANCE_HEADERS[1]).each(
      ($labels, index) => {
        expect($labels.text()).to.contain(primaryInsuranceLabels[index]);
      }
    );
  }

  /**
   * @details To verify the primary insurance values under Primary Insurance section
   * @param - primaryInsuranceValues - Primary insurance values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPrimaryInsuranceValues(primaryInsuranceValues: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PRIMARY_INSURANCE_VALUES[1]).each(
      ($values, index) => {
        expect($values.text()).to.contain(primaryInsuranceValues[index]);
      }
    );
  }

  /**
   * @details To verify the primary guarantor labels under Primary Insurance section
   * @param - primaryGuarantorLabels - Primary guarantor labels to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPrimaryGuarantorLabels(primaryGuarantorLabels: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PRIMARY_GUARANTOR_HEADERS[1]).each(
      ($labels, index) => {
        expect($labels.text()).to.contain(primaryGuarantorLabels[index]);
      }
    );
  }

  /**
   * @details To verify the primary guarantor values under Primary Insurance section
   * @param - primaryGuarantorValues - Primary guarantor values to provide while using the function
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPrimaryGuarantorValues(primaryGuarantorValues: string[]) {
    cy.cGet(OR_CASE_REQUEST.REQUEST_DETAILS.PRIMARY_GUARANTOR_VALUES[1]).each(
      ($values, index) => {
        expect($values.text()).to.contain(primaryGuarantorValues[index]);
      }
    );
  }

  /**
   * @details To verify the previous button state in Request Information tab
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyPreviousButtonState() {
    cy.cGet(OR_CASE_REQUEST.CASE_REQUEST.PREVIOUS[1]).should(
      ShouldMethods.attribute,
      CommonClassAttributes.disabled,
      CommonClassAttributes.disabled
    );
  }

  /**
   * @details To verify the Done button state in Request Details page
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyDoneButtonState() {
    cy.cGet(OR_CASE_REQUEST.CASE_REQUEST.DONE[1]).should(
      ShouldMethods.attribute,
      CommonClassAttributes.disabled,
      CommonClassAttributes.disabled
    );
  }

  /**
   * @details To verify select the tab names in Request Details
   * @param - tabName -To provide the tab names like Case Attachments, Request Information under Request Details page.
   * @Api - API's are not available
   * @author - Praveen
   */
  selectRequestDetailsTab(tabName: string) {
    cy.cClick(selectorFactory.getSpanText(tabName), tabName, false, true);
  }

  /**
   * @details To verify the file name of the attachment
   * @param - fileName - To provide the file name of the case.
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyFileNameInAttachments(fileName: string) {
    cy.cGet(OR_CASE_REQUEST.CASE_ATTACHMENT.FILE_NAME[1]).then(($fileText) => {
      expect($fileText.text()).to.contain(fileName);
    });
  }

  /**
   * @details To verify the case details under the Request Information tab in Case Request
   * @param denyText - To provide the deny text in the popup
   * @param headerName -To provide the header name of the deny popup
   * @Api - API's are not available
   * @author - Praveen
   */
  verifyDenyPopupDetails(headerName: string, denyText: string) {
    this.clickDeny();
    this.verifyDenyRequestTitle(headerName);
    this.verifyDenyRequestReasonText(denyText);
    this.clickCancel();
  }

  /**
   * @details To verify the case details under the Request Information tab in Case Request
   * @param denyReason - To provide the deny reason
   * @param headerName -To provide the header name of the deny popup
   * @Api - API's are available,Implemented completely
   * @author - Praveen
   */
  denySelection(denyReason: string, headerName: string) {
    this.clickDeny();
    this.selectDenyReason(denyReason);
    this.clickDenyRequestHeader(headerName);
    this.clickDenyRequestDone();
  }

  /**
   * @details To verify the button state
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyButtonsState() {
    this.verifyPreviousButtonState();
    this.verifyDoneButtonState();
  }

  /**
   * @details To verify the information in case request information
   * @param requestInfo -RequestInformation model values needs to be passed
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyRequestInformation(requestInfo: RequestInformation) {
    this.verifyRequestInfoCaseValues(requestInfo.CaseDetails!);
    this.verifyCaseRequestNoteValues(requestInfo.CaseDetailsNotes!);
    this.verifyProcedureRequestValues(requestInfo.Procedures!);
    this.verifyPatientRequestInfoValues(requestInfo.Patient!);
    this.verifyPatientAddressRequestValues(requestInfo.PatientAddress!);
    this.verifyPrimaryInsuranceValues(requestInfo.PrimaryInsurance!);
    this.verifyPrimaryGuarantorValues(requestInfo.PrimaryGuarantor!);
    this.verifyButtonsState();
  }

  /**
   * @details To verify the labels in case request information
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyRequestInformationLabels() {
    this.verifyRequestInfoCaseHeaders(caseRequestLabels);
    this.verifyCaseRequestNoteLabels(caseRequestNoteLabels);
    this.verifyProcedureRequestLabels(procedureRequestLabels);
    this.verifyPatientInfoRequestLabels(patientInfoLabels);
    this.verifyPatientAddressInfoRequestLabels(patientAddressInfoLabels);
    this.verifyPrimaryInsuranceLabels(primaryInsuranceLabels);
    this.verifyPrimaryGuarantorLabels(primaryGuarantorLabels);
  }

  /**
   * @details To verify the deny popup labels and perform the deny action.
   * @param denyReason - To provide the deny reason text as parameter
   * @API API's are available - Implemented
   * @author - Praveen
   */
  performDeny(denyReason: string) {
    this.verifyDenyPopupDetails(
      OR_CASE_REQUEST.CASE_REQUEST.DENY_HEADER[0],
      AppErrorMessages.deny_reason_text
    );
    this.denySelection(denyReason, OR_CASE_REQUEST.CASE_REQUEST.DENY_HEADER[0]);
  }

  /**
   * @details To accept the case request
   * @param appointmentType - appointment type value should be passed
   * @Api - API's are available, Implemented completely
   * @author - Arushi
   */
  acceptCaseRequest(appointmentType: string) {
    createCase.clickNewPatientButtonForCaseRequest();
    createCase.clickDoneButton();
    createCase.next();
    createCase.selectAppointmentType(appointmentType);
    sisOfficeDesktop.clickOnDoneAcceptCaseRequest();
  }

  /**
   * @details To verify patient fall off from case request after request being accepted or denied
   * @param patient -last name of patient needs to be passed
   * @Api - API's are not available
   * @author - Arushi
   */
  verifyPatientFallOffFromCaseRequest(patient: string) {
    sisOfficeDesktop.selectScheduleType(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE.CASE_REQUESTS[0]
    );
    cy.cGet(
      CommonUtils.concatenate(
        OR_CASE_REQUEST.CASE_REQUEST.CASE_REQUEST_ROW[1],
        selectorFactory.getTdText(patient)
      )
    ).should(ShouldMethods.not_exist);
  }
}
