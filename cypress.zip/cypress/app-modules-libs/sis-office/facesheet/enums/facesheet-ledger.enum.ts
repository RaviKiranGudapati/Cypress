export enum UnassignedHeaderText {
  unassigned_payment_allocation = 'Unassigned Payment Allocation',
  unassigned_payment_details = 'Unassigned Payment Details',
  charge_to_allocate = 'Charge to Allocate',
}
