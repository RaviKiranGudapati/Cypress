import {
  Application,
  CommonClassAttributes,
  CommonGetLocators,
  InvokeAttributes,
  InvokeMethods,
  ShouldMethods,
  PlusOrMinus,
  confirmation,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

import {
  BillingHistoryTransaction,
  UnAssignedCorrection,
  UnAssignedAllocation,
  UnassignedPay,
} from '../../../test-data-models/sis-office/facesheet/facesheet-ledger.model';
import { Cpt } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_PATIENT_CASE_CREATION } from '../case-creation/or/create-case.or';
import { OR_FACESHEET_LEDGER_TAB } from './or/facesheet-ledger.or';
import { OR_TRANSACTION } from './or/facesheet-transactions.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import Transactions from './facesheet-transactions';

import { FacesheetLedgerApis } from './api/facesheet-ledger.api';
import { ApiEndpoint } from '../../../support/common-core-libs/framework/api-endpoint';
import { HelperText } from '../../shared/application-settings/enums/enterprise-configuration.enum';
import { UnassignedHeaderText } from './enums/facesheet-ledger.enum';


/* instance variables */
const transaction = new Transactions();

/**
 * Class for Ledger tab in Facesheet
 */
export default class LedgerTabFaceSheet {
  /* instance variables */
  private facesheetLedger = new FacesheetLedgerApis();

  /**
   * @details - Click on ledger tab
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickOnLedgerTab() {
    const interceptCollection =
      this.facesheetLedger.interceptLedgerTabSelection();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.LEDGER[1],
      OR_FACESHEET_LEDGER_TAB.LEDGER[0],
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on Add button in ledger tab
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickOnAddButton() {
    const interceptCollection =
      this.facesheetLedger.interceptAddUnassignedPaymentApis();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.ADD_BUTTON[1],
      OR_FACESHEET_LEDGER_TAB.ADD_BUTTON[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Enter amount in unassigned payment popup
   * @param - payment as model reference in function
   * @API - API's are not available
   */
  enterAmountCollected(payment: UnassignedPay) {
    cy.cType(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.AMOUNT_COLLECTED[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.AMOUNT_COLLECTED[0],
      payment.AmountCollected
    );
  }

  /**
   * @details - Select the values from dropdown  in unassigned payment  popup.
   * @param - dropdown and valueToSelect - as parameters in function
   * @API - API's are not available
   */
  paymentSelectDropdownValue(dropdown: string, valueToSelect: string) {
    let dropdownSelector = '';
    let value = selectorFactory.getDropdownValues(valueToSelect);
    let dropdownLogicalName = '';
    switch (dropdown) {
      case OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PERIOD[0]:
        dropdownSelector = OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PERIOD[1];
        dropdownLogicalName =
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PERIOD[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.BATCH[0]:
        dropdownSelector = OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.BATCH[1];
        dropdownLogicalName =
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.BATCH[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.CASE[0]:
        dropdownSelector = OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.CASE[1];
        dropdownLogicalName =
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.CASE[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_CODE[0]:
        dropdownSelector =
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_CODE[1];
        dropdownLogicalName =
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_CODE[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.METHOD_OF_PAYMENT[0]:
        dropdownSelector =
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.METHOD_OF_PAYMENT[1];
        dropdownLogicalName =
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.METHOD_OF_PAYMENT[0];
        break;
      default:
        break;
    }
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, dropdownLogicalName);
    cy.cClick(value, value, false, false, { force: true });
  }

  /**
   * @details - enter notes in Unassigned Payment popup
   * @param notes
   * @API - API's are not available
   */
  enterNotesInUnassignedPayment(notes: string) {
    cy.cType(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.NOTES[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.NOTES[0],
      notes
    );
  }

  /**
   * @details - Enter  details in unassigned payment
   * @param - payment as model reference inside the function
   * @API - API's are not available
   */
  unassignedPaymentDetails(payment: UnassignedPay) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();

    if (payment.AmountCollected !== undefined) {
      this.enterAmountCollected(payment);
    }

    if (payment.Period !== undefined) {
      this.paymentSelectDropdownValue(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PERIOD[0],
        payment.Period!
      );
    }

    if (payment.Batch !== undefined) {
      this.paymentSelectDropdownValue(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.BATCH[0],
        payment.Batch!
      );
    }

    if (payment.Case !== undefined) {
      this.paymentSelectDropdownValue(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.CASE[0],
        payment.Case!
      );
    }

    if (payment.Notes !== undefined) {
      this.enterNotesInUnassignedPayment(payment.Notes);
    }

    if (payment.MethodOfPayment !== undefined) {
      this.paymentSelectDropdownValue(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.METHOD_OF_PAYMENT[0],
        payment.MethodOfPayment
      );
    }

    if (payment.TransactionCode !== undefined)
      this.paymentSelectDropdownValue(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_CODE[0],
        payment.TransactionCode
      );
    this.clickOnAddUnassignedPaymentDone();
  }

  /**
   * @details - Select the values from dropdown  in unassigned allocation  popup.
   * @param - dropdown
   * @param - valueToSelect
   * @API - API's are not available
   */
  unassignedPaymentAllocationSelectDropdown(
    dropdown: string,
    valueToSelect: string
  ) {
    let dropdownSelector = '';
    let value = selectorFactory.getDropdownValues(valueToSelect);
    let dropdownLogicalName = '';
    switch (dropdown) {
      case OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0]:
        dropdownSelector = OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[1];
        dropdownLogicalName = OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0]:
        dropdownSelector = OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[1];
        dropdownLogicalName = OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0]:
        dropdownSelector =
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[1];
        dropdownLogicalName =
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0];
        break;
      default:
        break;
    }
    cy.cClick(dropdownSelector, dropdownLogicalName);
    cy.cClick(value, value);
  }

  /**
   * @details - Enter amount in allocation popup
   * @param amount - as parameter inside the function
   * @param rowNo
   * @API - API's are not available
   */
  enterAllocationAmount(amount: number, rowNo: string) {
    cy.cClick(
      CommonUtils.concatenate(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[2],
        rowNo,
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[1]
      ),
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[0]
    );
    cy.cType(
      CommonUtils.concatenate(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[2],
        rowNo,
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[1]
      ),
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[0],
      amount
    );
  }

  /**
   * @details click on Done button in Allocation Popup
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickOnDone() {
    cy.cClick(
      selectorFactory.getSpanText(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DONE_BUTTON[0]
      ),
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DONE_BUTTON[0]
    );
  }

  /**
   * @details - Enter the details in allocation popup
   * @param allocation - values of the allocation model need to be added
   * @param rowno - For which row payment needs to be allocated (ex: 0,1)
   * @API - API's are not available
   */
  unassignedPaymentAllocation(allocation: UnAssignedAllocation, rowno: string) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    this.unassignedPaymentAllocationSelectDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0],
      allocation.Period!
    );
    this.unassignedPaymentAllocationSelectDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0],
      allocation.Batch!
    );
    this.enterAllocationAmount(allocation.AmountAllocation, rowno);
    this.unassignedPaymentAllocationSelectDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0],
      allocation.TransactionCode
    );
    this.clickOnAddUnassignedPaymentDone();
  }

  /**
   * @details -Click on Show aging in ledger tab
   * @API - API's are not available
   */
  clickOnShowAging() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.SHOW_AGING[1],
      OR_FACESHEET_LEDGER_TAB.SHOW_AGING[0],
      false,
      true
    );
    cy.cIsVisible(
      OR_FACESHEET_LEDGER_TAB.HIDE_AGING[1],
      OR_FACESHEET_LEDGER_TAB.HIDE_AGING[0]
    );
  }

  /**
   * @details -To click on the Hide aging in ledger tab.
   * @API - API's are not available
   */
  clickOnHideAging() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.HIDE_AGING[1],
      OR_FACESHEET_LEDGER_TAB.HIDE_AGING[0],
      false,
      true
    );
    cy.cIsVisible(
      OR_FACESHEET_LEDGER_TAB.SHOW_AGING[1],
      OR_FACESHEET_LEDGER_TAB.SHOW_AGING[0]
    );
  }

  /**
   * @details -Click on allocate in ledger tab
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickOnAllocate() {
    const interceptCollection =
      this.facesheetLedger.interceptAllocateUnassignedPayment();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.ALLOCATE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details -verify the amount in show aging
   * @param - agingLabels
   * @param - accountValues
   * @API - API's are not available
   */
  verifyAmountsInAging(agingLabels: string[], accountValues: string[]) {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.AMOUNT_AGING[1])
      .each(($labels, index) => {
        expect($labels.text().replace(/\n/g, '').trim()).to.contain(
          agingLabels[index]
        );
      })
      .then(() => {
        cy.cGet(OR_FACESHEET_LEDGER_TAB.SHOW_AGING_BOTTOM_ROW[1])
          .eq(1)
          .first()
          .within(() => {
            cy.cGet(CommonGetLocators.span).each(($labelVals, index) => {
              expect($labelVals.text()).to.contain(accountValues[index]);
            });
          });
      });
  }

  /**
   * @details click on Context Menu in Unassigned Payment Rows
   * @param - transactionCode
   * @param - menuOption
   * @API - API's are not available
   */
  clickOnContextMenu(transactionCode: string, menuOption: string) {
    cy.cGet(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .CONTEXT_MENU_UNASSIGNED_PAYMENT_ROW[1]
    )
      .contains(transactionCode)
      .parents(
        OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
          .COLUMN_FOUR_TRANSACTION_CODE[1]
      )
      .siblings(
        OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.COLUMN_EIGHT_CONTEXT_MENU[1]
      )
      .children()
      .children()
      .click();
    cy.cGet(OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.CONTEXT_MENU_OPTIONS[1])
      .contains(menuOption)
      .click();
  }

  /**
   * @details Allocation Amount in Unassigned Payment Allocation Popup
   * @param - amount
   * @param - cpt
   * @API - API's are not available
   */
  amountAllocation(amount: string, cpt: string) {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.ALLOCATION.CHARGE_TO_ALLOCATE_ROW[1])
      .contains(cpt)
      .parent()
      .siblings(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.COLUMN_SIX_CHARGE_TO_ALLOCATE[1]
      )
      .children()
      .children()
      .clear({ force: true })
      .focus()
      .type(amount, { force: true });
  }

  /**
   * @details -Click on print icon in ledger tab of masthead
   * @API - API's are not available
   */
  clickOnPrintIconInMasthead() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.PRINT_ICON_MASTHEAD[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_ICON_MASTHEAD[0]
    );
  }

  /**
   * @details To verify the un-allocation amount in Unassigned table.
   * @param - transactionCode as parameter in function
   * @param - amount as parameter in function
   * @API - API's are not available
   */
  verifyUnAllocatedAmount(transactionCode: string, amount: string) {
    cy.cNotExist(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CLOSE_ICON[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CLOSE_ICON[0]
    );
    cy.cNotExist(
      selectorFactory.getH3Text(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_ROW[0]
      ),
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_ROW[0]
    );
    cy.cGet(OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_ROW[1]).each(
      ($values) => {
        if ($values.text().includes(transactionCode)) {
          cy.cGet(CommonGetLocators.td)
            .eq(7)
            .first()
            .within(($unAllocatedAmount) => {
              expect($unAllocatedAmount.text()).to.include(amount);
            });
        }
      }
    );
  }

  /**
   * @details -Click on View Edit in up of ledger tab
   * @param text - as parameter in function
   * @API - API's are not available
   */
  verifyChartConsentInPrint(text: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CHART_CONSENT[1],
      OR_FACESHEET_LEDGER_TAB.CHART_CONSENT[0],
      text
    );
  }

  /**
   * @details -select context menu in ledger tab
   * @param - flag as parameter in function
   * @API - API's are not available
   */
  selectContextMenu(flag: boolean = true) {
    if (flag) {
      cy.cClick(
        OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU[1],
        OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU[0]
      );
    } else {
      cy.cNotExist(
        OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU[1],
        OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU[0]
      );
    }
  }

  /**
   * @details -select print icon in cases tab
   * @API - API's are not available
   */
  selectPrintIconInCasesTab() {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.PRINT_ICON[1]).eq(0).click();
  }

  /**
   * @details - Verify print option in ledger tab
   * @param - dataValues - as parameter in function
   * @API - API's are not available
   */
  verifyPrintOption(dataValues: string[]) {
    dataValues.forEach(($ele, index) => {
      cy.cGet(OR_FACESHEET_LEDGER_TAB.PRINT_OPTION[1])
        .eq(index)
        .should(ShouldMethods.include_text, $ele);
    });
  }

  /**
   * @details -Click on View Edit in up of ledger tab
   * @API -  API's are available - Implemented Completely
   */
  clickViewEdit() {
    const interceptCollection =
      this.facesheetLedger.interceptViewEditeUnassignedPayment();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.VIEW_EDIT[1],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.VIEW_EDIT[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details -Click on View Edit in ledger tab
   * @API -  API's are available - Implemented Completely
   */
  clickDelete() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.DELETE[1],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.DELETE[0]
    );
  }

  /**
   * @details - verify the charges text found NO CHARGES TEXT
   * @API - API's are not available
   */
  verifyNoCharge() {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.NO_CHARGES_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.NO_CHARGES_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.NO_CHARGES_TEXT[0]
    );
  }

  /**
   * @details - verify the Labels text for unassigned payment
   * @API - API's are not available
   */
  verifyLabelsUnassignedPayments() {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DOS_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DOS_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DOS_TEXT[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_DATE_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_DATE_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_DATE_TEXT[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PHYSICIAN_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PHYSICIAN_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PHYSICIAN_TEXT[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_Code_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_Code_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_Code_TEXT[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.AMOUNT_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.AMOUNT_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.AMOUNT_TEXT[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.RECEIVED_FROM_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.RECEIVED_FROM_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.RECEIVED_FROM_TEXT[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.UNALLOCATED_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.UNALLOCATED_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.UNALLOCATED_TEXT[0]
    );
  }

  /**
   * @details - verify the DOS text for unassigned payment
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyDOSUP(unassignedPayment: UnassignedPay) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .COLUMN_ONEIN_WHICH_CONTEXT_MENU_HAS[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DOS_TEXT[0],
      unassignedPayment.DOS
    );
  }

  /**
   * @details - verify the Transaction Date text for unassigned payment
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyTransactionDateUP(unassignedPayment: UnassignedPay) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .COLUMN_TWOIN_WHICH_CONTEXT_MENU_HAS[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_DATE_TEXT[0],
      unassignedPayment.TransactionDate
    );
  }

  /**
   * @details - verify the Physician text for unassigned payment
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyPhysicianUP(unassignedPayment: UnassignedPay) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .COLUMN_THREEIN_WHICH_CONTEXT_MENU_HAS[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PHYSICIAN_TEXT[0],
      unassignedPayment.Physician
    );
  }

  /**
   * @details - verify the Transaction Code text for unassigned payment
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyTransactionCodeUP(unassignedPayment: UnassignedPay) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .COLUMN_FOUR_TRANSACTION_CODE[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.TRANSACTION_Code_TEXT[0],
      unassignedPayment.TransactionCode
    );
  }

  /**
   * @details - verify the Amount text for unassigned payment
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyAmountUP(unassignedPayment: UnassignedPay) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .COLUMN_FIVEIN_WHICH_CONTEXT_MENU_HAS[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.AMOUNT_TEXT[0],
      unassignedPayment.AmountCollected
    );
  }

  /**
   * @details - verify the Received From text for unassigned payment
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyReceivedFromUP(unassignedPayment: UnassignedPay) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .COLUMN_SIXIN_WHICH_CONTEXT_MENU_HAS[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.RECEIVED_FROM_TEXT[0],
      unassignedPayment.ReceivedFrom
    );
  }

  /**
   * @details - verify the Unallocated text for unassigned payment
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyUnallocatedUP(unassignedPayment: UnassignedPay) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .COLUMN_SEVENIN_WHICH_CONTEXT_MENU_HAS[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.UNALLOCATED_TEXT[0],
      unassignedPayment.Unallocated!
    );
  }

  /**
   * @details - verify the Charges text for unassigned payment
   * @param - headerName as parameter in function
   * @API - API's are not available
   */
  verifyChargeHeader(headerName: string) {
    cy.cIsVisible(selectorFactory.getSpanText(headerName), headerName);
  }

  /**
   * @details - verify the Labels text for options of unassigned payment
   * @API - API's are not available
   */
  verifyOptionLabelsUnassignedPayments() {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATE[0],
      OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.CORRECTION[1],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.CORRECTION[0],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.CORRECTION[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.VIEW_EDIT[1],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.VIEW_EDIT[0],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.VIEW_EDIT[0]
    );
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.DELETE[1],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.DELETE[0],
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.DELETE[0]
    );
  }

  /**
   * @details - verify amount collected in checkin
   * @param - unassignedPayment as model reference in function
   * @API - API's are not available
   */
  verifyAmountCollected(unassignedPayment: UnassignedPay) {
    cy.cHasValue(
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.PAYMENT
        .AMOUNT_COLLECTED[1],
      OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.PAYMENT
        .AMOUNT_COLLECTED[0],
      unassignedPayment.AmountCollected
    );
  }

  /**
   * @details - verify amount collected in checkin
   * @API - API's are not available
   */
  clickLossOfData() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.LOSS_OF_DATA[1],
      OR_FACESHEET_LEDGER_TAB.LOSS_OF_DATA[0]
    );
  }

  /**
   * @details - verify the charges text found NO CHARGES TEXT
   * @API - API's are not available
   */
  verifyNoUnassignedPayment() {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.NO_UNASSIGNED_PAYMENT_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.NO_UNASSIGNED_PAYMENT_TEXT[0],
      OR_FACESHEET_LEDGER_TAB.NO_UNASSIGNED_PAYMENT_TEXT[0]
    );
  }

  /**
   * @details To verify the total amounts in Aging section.
   * @param - labels
   * @param - totalValues
   * @API - API's are not available
   */
  verifyTotalAmountsInAging(labels: string[], totalValues: string[]) {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.AGING_LABELS[1])
      .each(($labels, index) => {
        expect($labels.text().replace(/\n/g, '').trim()).to.contain(
          labels[index]
        );
      })
      .then(() => {
        cy.cGet(OR_FACESHEET_LEDGER_TAB.AGING_AMOUNT[1]).each(
          ($data, index) => {
            expect($data.text().replace(/\n/g, '').trim()).to.includes(
              totalValues[index]
            );
          }
        );
      });
  }

  /**
   * @details - click the popup window
   * @param -valueToSelect  as parameter in function
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickConfirm(valueToSelect: string) {
    const interceptCollection =
      this.facesheetLedger.interceptDeleteUnassignedPayment();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      selectorFactory.selectYesNo(valueToSelect),
      valueToSelect,
      false,
      true
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - verify the ledger tab
   * @API - API's are not available
   */
  verifyLedgerTab() {
    cy.cHasClass(
      OR_FACESHEET_LEDGER_TAB.LEDGER_TAB[1],
      OR_FACESHEET_LEDGER_TAB.LEDGER_TAB[0],
      CommonClassAttributes.pdisabled
    );
  }

  /**
   * @details - open Billing History
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickOnBillingHistory() {
    const interceptCollection =
      this.facesheetLedger.interceptForBillingHistory();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[1],
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select Charges in the billing history
   * @param- index of the charge to be selected
   * @API - API's are not available
   */
  selectChargesCheckBox(index: number) {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_CHARGE_CHECKBOX[1])
      .eq(index)
      .click();
  }

  /**
   * @details - Print selected patient statements
   * @API - API's are not available
   */
  clickPrintSelectedPatientStatement() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.PRINT_SELECTED_PATIENT_STATEMENT[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_SELECTED_PATIENT_STATEMENT[0]
    );
  }

  /**
   * @details - verify print pop-up
   * @API - API's are not available
   */
  verifyPrintPopup() {
    cy.cIsVisible(
      selectorFactory.getH3Text(OR_FACESHEET_LEDGER_TAB.PREVIEW[0]),
      OR_FACESHEET_LEDGER_TAB.PREVIEW[0]
    );
    cy.cIsVisible(
      selectorFactory.getSpanClassText(OR_FACESHEET_LEDGER_TAB.PRINT[0]),
      OR_FACESHEET_LEDGER_TAB.PRINT[0]
    );
  }

  /**
   * @details - close print pop-up
   * @API - API's are not available
   */
  closePrintPopup() {
    cy.get(OR_FACESHEET_LEDGER_TAB.CLOSE_PRINT_PREVIEW[1], {
      timeout: Cypress.config('responseTimeout'),
    }).click({ force: true });
  }

  /**
   * @details - close billing history pop-up
   * @API - API's are not available
   */
  closeBillingHistory() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.CLOSE_BILLING_HISTORY[1],
      OR_FACESHEET_LEDGER_TAB.CLOSE_BILLING_HISTORY[0]
    );
  }

  /**
   * @details - click on bill selected patient statement
   * @API - API's are not available
   */
  clickBillSelectedPatientStatement() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT[1],
      OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT[0],
      false,
      true
    );
  }

  /**
   * @details - click on yes or no in bill selected patient statement confirmation dialog
   * @option - option to be clicked on
   * @API - API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickYesOrNoBillSelectedPatientStatement(option = true) {
    let locator = '';
    const interceptCollection =
      this.facesheetLedger.interceptForBillSelectedChargeYesOrNo();
    option
      ? (locator =
          OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT_YES[1])
      : (locator =
          OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT_NO[1]);
    cy.cIntercept(interceptCollection);
    cy.cGet(locator).eq(0).click({ force: true });
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(OR_FACESHEET_LEDGER_TAB.OK_BUTTON[1]);
  }

  /**
   * @details - Verify Bill Selected Patient Dialog confirmation with Yes or No options
   * @API - API's are not available
   */
  verifyBillPatientStatementDialog() {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_POPUP_HEADER[1])
      .eq(0)
      .should(
        ShouldMethods.include_text,
        OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_POPUP_HEADER[0]
      );

    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_TEXT[1])
      .eq(0)
      .should(ShouldMethods.include_text, confirmation.confirmation_text);

    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT_YES[1])
      .eq(0)
      .should(
        ShouldMethods.include_text,
        OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT_YES[0]
      );

    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT_NO[1])
      .eq(0)
      .should(
        ShouldMethods.include_text,
        OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_PATIENT_STATEMENT_NO[0]
      );
  }

  /**
   * @details - Verify Bill Selected Patient Dialog Bill Sent confirmation
   * @API - API's are not available
   */
  verifyStatementSentDialog() {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_POPUP_HEADER[1])
      .eq(0)
      .should(
        ShouldMethods.include_text,
        OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_POPUP_HEADER[0]
      );

    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_TEXT[1])
      .eq(0)
      .should(ShouldMethods.include_text, confirmation.statement_sent);

    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[1],
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[0],
      false,
      true
    );
  }

  /**
   * @details - Verify Bill Sent to patient
   * @param index - index value of the charge
   * @param status - boolean, default true
   * @API - API's are not available
   * @author - Nikitan
   */
  verifyEmailSent(index: number, status = true) {
    if (status) {
      cy.cHasAttribute(
        selectorFactory.getBillChargedCircle(index),
        OR_FACESHEET_LEDGER_TAB.WAY_STAR_ICON[0],
        InvokeAttributes.class,
        confirmation.circle
      );
    } else {
      cy.cIsVisible(
        selectorFactory.getBillChargedCircle(index),
        OR_FACESHEET_LEDGER_TAB.WAY_STAR_ICON[0],
        false,
        false
      );
    }
  }

  /**
   * @details - Verify Billed checkbox is checked as per index
   * @param index - To provide the charge index value
   * @param option - To verify whether the box ix checked or not, true or false
   * @API - API's are not available
   */
  verifyBilledCheckbox(index: number, option: string) {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILLED_CHECKBOX[1])
      .eq(index)
      .should(ShouldMethods.attribute, InvokeAttributes.aria_checked, option);
  }

  /**
   * @details - To click on the buttons in ledger page
   * @param option - Based on the user option to select the button
   * @API -API's are available - Implemented Completely
   * @author - Madhu Kiran
   */
  clickButtonsInLedger(option: string) {
    let interceptCollection: ApiEndpoint[] = [];
    let locator: string = '';
    switch (option) {
      case OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[0]:
        locator = OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[1];
        interceptCollection = this.facesheetLedger.interceptForBillingHistory();
        break;
      case OR_FACESHEET_LEDGER_TAB.NOTES[0]:
        locator = OR_FACESHEET_LEDGER_TAB.NOTES[1];
        interceptCollection = this.facesheetLedger.interceptForNotes();
        break;
      case OR_FACESHEET_LEDGER_TAB.CLAIM_STATUS[0]:
        locator = OR_FACESHEET_LEDGER_TAB.CLAIM_STATUS[1];
        interceptCollection = this.facesheetLedger.interceptForClaimStatus();
        break;
      default:
        break;
    }
    cy.cIntercept(interceptCollection);
    cy.cClick(locator, option);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To click on the plus icon based on the CPT row
   * @param cpt - as parameter using in the function
   * @API - API's are not available
   */
  clickPlusIconBasedOnCPT(cpt: string) {
    cy.cClick(
      selectorFactory.getThText(
        OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.CHARGE_AMOUNT[0]
      ),
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.CHARGE_AMOUNT[0],
      false,
      true
    );
    cy.cWaitForElementToBeAttached(
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.CHARGE_ROW[1],
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.CHARGE_ROW[0]
    );
    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.CHARGE_ROW[1])
      .should(ShouldMethods.visible)
      .each(($ele) => {
        if ($ele.text().indexOf(cpt) > -1) {
          cy.wrap($ele)
            .first()
            .within(() => {
              cy.cClick(
                OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.PLUS_ICON[1],
                OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.PLUS_ICON[0],
                false,
                true
              );
            });
        }
      });
  }

  /**
   * @details - To verify the billing history data related to Transaction
   * @param billingHistTrans - as parameter using in the function
   * @API - API's are not available
   */
  verifyBillHistoryTransactions(billingHistTrans: BillingHistoryTransaction) {
    let index = 0;
    cy.cGet(
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.TRANSACTION_HEADER[1]
    ).should(ShouldMethods.length, 9);
    for (const [key, value] of Object.entries(billingHistTrans)) {
      cy.cGet(
        OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.TRANSACTION_HEADER[1]
      )
        .eq(index)
        .then(($ele) => {
          expect(
            $ele
              .text()
              .replace(/\n /g, '')
              .replace(/ /g, '')
              .replace(/kr$/, '')
              .trim()
          ).contains(key);
        });
      cy.cGet(OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.TRANSACTION_BODY[1])
        .eq(index)
        .then(($data) => {
          expect($data.text().trim()).contains(value);
        });
      index++;
    }
  }

  /**
   * @details Verify the balance due amount based on the cpt code in facesheet ledger page
   * @param - cpt
   * @param - amount
   * @API - API's are not available
   */
  verifyLedgerChargeBalanceDue(cpt: string, amount: string) {
    transaction.selectChargeByCPT(cpt);
    cy.cGet(OR_TRANSACTION.BALANCE_DUE_LEDGER[1])
      .eq(1)
      .first()
      .within(($value) => {
        expect($value.text()).to.contains(amount);
      });
  }

  /**
   * @details - To select plus or minus icon under ledger tab charges list according to cpt code.
   * @param cpt
   * @API - API's are not available
   */
  expandOrCollapseCptRow(cpt: string) {
    cy.cClick(
      selectorFactory.getLedgerChargesPlusIconAccordingToCptRow(cpt),
      PlusOrMinus.plus
    );
  }

  /**
   * @details - Verify text mapped to charges under face sheet ledger tab
   * @param text
   * @API - API's are not available
   */
  verifyTextInChargesTable(text: string) {
    cy.cIsVisible(selectorFactory.getTextInLimitTextContainer(text), text);
  }

  /**
   * @details - To verify the System Billed Icon and tooltip related to Transaction
   * @param value
   * @API - API's are not available
   */
  verifySystemBilledInfoIcon(value: string) {
    cy.cGet(
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP.TRANSACTION_ROW[1]
    ).each(($row) => {
      cy.wrap($row)
        .first()
        .within(() => {
          cy.cGet(CommonGetLocators.td)
            .eq(7)
            .first()
            .within(() => {
              cy.cGet(CommonGetLocators.i).should(
                InvokeMethods.attribute,
                InvokeAttributes.p_tool_tip,
                value
              );
            });
        });
    });
  }

  /**
   * @details To verify the CPT code under charges in ledger tab.
   * @param - cptData as model reference passed as argument in function
   * @API - API's are not available
   */
  verifyLedgerCPTCharge(cptData: Cpt) {
    cy.contains(
      selectorFactory.selectChargeFromTransactionPage(
        cptData.CPTCodeAndDescription
      ),
      cptData.CPTCodeAndDescription
    );
  }

  /**
   * @details To check the header name of the billing history popup
   * @param headerName as parameter passed as argument in function
   * @API - API's are not available
   */
  verifyBillingHistoryHeader(headerName: string) {
    cy.contains(selectorFactory.getH3Text(headerName), headerName);
  }

  /**
   * @details - verify the options in context menu,
   * Description of method:- first cy.cGet will select the row containing transactionCode, then
   * parents(CommonGetLocators.td) will take to the parent where we have td
   * next parent() will take into complete row, within the row we can find i(context menu icon)
   * @param options - options in context menu to be verified
   * @param transactionCode - pass Transaction code in which row context menu to be selected
   * @API - API's are not available
   */
  verifyContextMenuOptions(options: string[], transactionCode: string) {
    cy.cGet(
      OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
        .CONTEXT_MENU_UNASSIGNED_PAYMENT_ROW[1]
    )
      .contains(transactionCode)
      .parents(CommonGetLocators.td)
      .parent()
      .within(() => {
        cy.cClick(CommonGetLocators.i, OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU[0]);
      });
    options.forEach(($val) => {
      cy.cGet(
        OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.CONTEXT_MENU_OPTIONS[1]
      ).contains($val);
    });
  }

  /**
   * @details - verify header name in Allocation PopUp
   * @param headerName
   * @API - API's are not available
   */
  verifyHeaderInAllocationPopUp(headerName: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TITLE_WINDOW[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TITLE_WINDOW[0],
      headerName
    );
  }

  /**
   * @details - verify subheader in Allocation PopUp
   * @param subHeader
   * @API - API's are not available
   */
  verifySubHeaderInAllocationPopUp(subHeader: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.SUB_HEADER_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.SUB_HEADER_TEXT[0],
      subHeader
    );
  }

  /**
   * @details - click on subheader label in Allocation PopUp
   * @API - API's are not available
   */
  clickOnSubHeaderInAllocationPopUp() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.SUB_HEADER_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.SUB_HEADER_TEXT[0]
    );
  }

  /**
   * @details - verify transaction date in Allocation PopUp
   * @param transaction
   * @API - API's are not available
   */
  verifyTransactionDateInAllocationPopUp(transaction: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_DATE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_DATE[0],
      transaction
    );
  }

  /**
   * @details - verify the method of payment in Allocation PopUp
   * @param methodOfPayment
   * @API - API's are not available
   */
  verifyMethodOfPaymentInAllocationPopUp(methodOfPayment: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.METHOD_OF_PAYMENT[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.METHOD_OF_PAYMENT[0],
      methodOfPayment
    );
  }

  /**
   * @details - verify allocated amount in Allocation PopUp
   * @param allocatedAmount
   * @API - API's are not available
   */
  verifyAllocatedAmountInAllocationPopUp(allocatedAmount: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATED_AMOUNT[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATED_AMOUNT[0],
      allocatedAmount
    );
  }

  /**
   * @details - verify unallocated amount in Allocation PopUp
   * @param unallocated
   * @API - API's are not available
   */
  verifyUnallocated(unallocated: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.UNALLOCATED[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.UNALLOCATED[0],
      unallocated
    );
  }

  /**
   * @details - verify case in Allocation PopUp
   * @param cases
   * @API - API's are not available
   */
  verifyCaseInAllocationPopUp(cases: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CASE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CASE[0],
      cases
    );
  }

  /**
   * @details - verify received from in Allocation PopUp
   * @param receivedFrom
   * @API - API's are not available
   */
  verifyReceivedFromInAllocationPopUp(receivedFrom: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.RECEIVED_FROM[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.RECEIVED_FROM[0],
      receivedFrom
    );
  }

  /**
   * @details - verify notes in Allocation PopUp
   * @param notes
   * @API - API's are not available
   */
  verifyNotesInAllocationPopUp(notes: string) {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.NOTES[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.NOTES[0],
      notes
    );
  }

  /**
   * @details - verify period in Allocation PopUp
   * @param period
   * @API - API's are not available
   */
  verifyPeriodInAllocationPopUp(period: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0],
      period
    );
  }

  /**
   * @details - verify batch in Allocation PopUp
   * @param batch
   * @API - API's are not available
   */
  verifyBatchInAllocationPopUp(batch: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0],
      batch
    );
  }

  /**
   * @details - verify charge to allocate header in Allocation PopUp
   * @API - API's are not available
   */
  verifyChargeToAllocateHeaderInAllocationPopUp() {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.SUB_HEADER_CHARGE_TO_ALLOCATE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.SUB_HEADER_CHARGE_TO_ALLOCATE[0],
      UnassignedHeaderText.charge_to_allocate
    );
  }

  /**
   * @details - verify the DOS(Date Of Surgery) in Allocation PopUp
   * @param dos
   * @API - API's are not available
   */
  verifyDosInAllocationPopUp(dos: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.DOS[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.DOS[0],
      dos
    );
  }

  /**
   * @details - verify CptHcpcs in Allocation PopUp
   * @param cptCode
   * @API - API's are not available
   */
  verifyCptHcpcsInAllocationPopUp(cptCode: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CPTHCPCS[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CPTHCPCS[0],
      cptCode
    );
  }

  /**
   * @details - verify physician in Allocation PopUp
   * @param physician
   * @API - API's are not available
   */
  verifyPhysicianInAllocationPopUp(physician: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PHYSICIAN[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PHYSICIAN[1],
      physician
    );
  }

  /**
   * @details - verify charge amount in Allocation PopUp
   * @param chargeAmount
   * @API - API's are not available
   */
  verifyChargeAmountInAllocationPopUp(chargeAmount: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CHARGE_AMOUNT[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.CHARGE_AMOUNT[0],
      chargeAmount
    );
  }

  /**
   * @details - verify Due amount in Allocation PopUp
   * @param due
   * @API - API's are not available
   */
  verifyDueInAllocationPopUp(due: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.DUE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.DUE[0],
      due
    );
  }

  /**
   * @details - verify copy right in Allocation PopUp
   * @API - API's are not available
   */
  verifyCopyRightInAllocationPopUp() {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.COPY_RIGHT[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.COPY_RIGHT[0],
      HelperText.disclaimer_text_cpt
    );
  }

  /**
   * @details - verify fields in Unassigned Payment Allocation PopUp
   * @param unassignedAllocation
   * @API - API's are not available
   */
  verifyUnassignedPaymentAllocationFieldsPopUp(
    unassignedAllocation: UnAssignedAllocation
  ) {
    this.verifyHeaderInAllocationPopUp(unassignedAllocation.HeaderName!);
    this.verifySubHeaderInAllocationPopUp(unassignedAllocation.SubHeaderName!);
    this.verifyTransactionDateInAllocationPopUp(
      unassignedAllocation.TransactionDate!
    );
    this.verifyMethodOfPaymentInAllocationPopUp(
      unassignedAllocation.MethodOfPayment!
    );
    this.verifyAllocatedAmountInAllocationPopUp(
      unassignedAllocation.AllocatedAmount!
    );
    this.verifyUnallocated(unassignedAllocation.Unallocated!);
    this.verifyCaseInAllocationPopUp(unassignedAllocation.Case!);
    this.verifyReceivedFromInAllocationPopUp(
      unassignedAllocation.ReceivedFrom!
    );
    this.verifyNotesInAllocationPopUp(unassignedAllocation.Notes!);
    this.verifyPeriodInAllocationPopUp(unassignedAllocation.Period!);
    this.verifyBatchInAllocationPopUp(unassignedAllocation.Batch!);
    this.verifyChargeToAllocateHeaderInAllocationPopUp();
    this.verifyDosInAllocationPopUp(unassignedAllocation.Dos!);
    this.verifyCptHcpcsInAllocationPopUp(unassignedAllocation.CptCode);
    this.verifyPhysicianInAllocationPopUp(unassignedAllocation.Physician!);
    this.verifyChargeAmountInAllocationPopUp(
      unassignedAllocation.ChargeAmount ?? ''
    );
    this.verifyDueInAllocationPopUp(unassignedAllocation.Due!);
    this.verifyCopyRightInAllocationPopUp();
  }

  /**
   * @details - selecting period and batch Labels in Ledger
   * @API - @API - API's are not available
   */
  clickPeriodAndBatchLabel() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getLabelText(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0]
      ),
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getLabelText(OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0]),
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0],
      false,
      true
    );
  }

  /**
   * @details - Click Billed checkbox is checked as per index
   * @param index - To provide the charge index value
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickBilledCheckbox(index: number) {
    const interceptCollection =
      this.facesheetLedger.interceptForBilledCheckbox();
    cy.cIntercept(interceptCollection);
    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILLED_CHECKBOX[1])
      .eq(index)
      .click({ force: true });
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - click on bill selected insurance charge and then click on OK button
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickBillSelectedInsuranceCharge() {
    const interceptCollectionBill =
      this.facesheetLedger.interceptForBillSelectedInsuranceCharge();
    const interceptCollectionOK =
      this.facesheetLedger.interceptForLedgerCharges();
    cy.cIntercept(interceptCollectionBill);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_INSURANCE_CHARGE[1],
      OR_FACESHEET_LEDGER_TAB.BILL_SELECTED_INSURANCE_CHARGE[0]
    );
    cy.cWaitApis(interceptCollectionBill);
    cy.cIntercept(interceptCollectionOK);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[1],
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[0]
    );
    cy.cWaitApis(interceptCollectionOK);
  }

  /**
   * @details - click on Print selected Insurance Charge
   * @API - API's are available and implemented completely
   * @author - Nikitan
   */
  clickPrintSelectedInsuranceCharge() {
    const interceptCollection =
      this.facesheetLedger.interceptForPrintInsuranceCharge();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.PRINT_SELECTED_INSURANCE_CHARGE[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_SELECTED_INSURANCE_CHARGE[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To select dropdown in Unassigned Payment Correction
   * @param dropdown - Name of the dropdown to selected
   * @param valueToSelect - Value in the dropdown to be selected in dropdown
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  unassignedPaymentCorrectionSelectDropdown(
    dropdown: string,
    valueToSelect: string
  ) {
    const dropdownProperties = {
      [OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0]]: {
        selector: OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[1],
        logicalName:
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0],
      },
      [OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0]]: {
        selector: OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[1],
        logicalName:
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0],
      },
      [OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_CORRECTION
        .CORRECTION_CODE[0]]: {
        selector:
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_CORRECTION
            .CORRECTION_CODE[1],
        logicalName:
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_CORRECTION
            .CORRECTION_CODE[0],
      },
    };

    const dropdownData = dropdownProperties[dropdown];

    if (!dropdownData) {
      return;
    }

    const dropdownSelector = dropdownData.selector;
    const dropdownLogicalName = dropdownData.logicalName;
    const value = selectorFactory.getDropdownValues(valueToSelect);

    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, dropdownLogicalName);
    cy.cClick(value, value, false, false, { force: true });
  }

  /**
   * @details - To enter NewUP Amount in Unassigned Payment Correction in ledger
   * @param amount - Amount to entered
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  enterNewUpAmount(amount: string) {
    cy.cType(
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_CORRECTION.NEW_UP_AMOUNT[1],
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_CORRECTION.NEW_UP_AMOUNT[0],
      amount
    );
  }

  /**
   * @details - Used to correct the added unassigned payment
   * @param correction - values of the unassigned correction model needs to be passed
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  unassignedPaymentCorrection(correction: UnAssignedCorrection) {
    if (correction.Period ?? '')
      this.unassignedPaymentCorrectionSelectDropdown(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PERIOD_DROPDOWN[0],
        correction.Period ?? ''
      );

    if (correction.Batch ?? '')
      this.unassignedPaymentCorrectionSelectDropdown(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BATCH_DROPDOWN[0],
        correction.Batch ?? ''
      );

    if (correction.NewUpAmount!) {
      this.enterNewUpAmount(correction.NewUpAmount);
    }

    if (correction.CorrectionCode ?? '')
      this.unassignedPaymentCorrectionSelectDropdown(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT_CORRECTION
          .CORRECTION_CODE[0],
        correction.CorrectionCode ?? ''
      );
    this.clickOnDone();
  }

  /**
   * @details - To verify print icon on the top right corner in facesheet is visible in grey background
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyPrintIcon() {
    cy.cIsVisible(
      OR_FACESHEET_LEDGER_TAB.PRINT_ICON_MASTHEAD[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_ICON_MASTHEAD[0]
    );
  }

  /**
   * @details - To verify the  print popup model which is on the top right corner
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyPrintPopUpModel() {
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.PRINT[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.PRINT[0],
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.PRINT[0]
    );
    cy.cIsVisible(
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.CLOSE_ICON[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.CLOSE_ICON[0]
    );
    cy.cHasText(
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.PREVIEW[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.PREVIEW[0],
      OR_FACESHEET_LEDGER_TAB.PRINT_POP_UP_MODEL.PREVIEW[0]
    );
  }

  /**
   * @details - To select print icon on the top right corner in facesheet
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  selectPrintIcon() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.PRINT_ICON_MASTHEAD[1],
      OR_FACESHEET_LEDGER_TAB.PRINT_ICON_MASTHEAD[0]
    );
  }

  /**
   * @details - Click OK Button in popup in facesheet ledger
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  clickOkButton() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[1],
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[0],
      false,
      true
    );
  }

  /**
   * @details click on Done button in Allocation Unassigned Payment pop up
   * @author - Madhu Kiran
   * @API - API's are available - Implemented Completely
   */
  clickOnAllocateUnassignedPaymentDone() {
    const interceptCollection =
      this.facesheetLedger.interceptDoneAllocationUnassignedPayment();
    cy.cIntercept(interceptCollection);
    this.clickOnDone();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details click on Done button in Add Unassigned Payment pop up
   * @author - Madhu Kiran
   * @API - API's are available - Implemented Completely
   */
  clickOnAddUnassignedPaymentDone() {
    const interceptCollection =
      this.facesheetLedger.interceptDoneAddUnassignedPayment();
    cy.cIntercept(interceptCollection);
    this.clickOnDone();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details To verify the amount for a charge allocated in Allocation window
   * @param amount To pass the amount to be verified in string format
   * @param cpt To pass the cpt code for which amount to be verified in string format
   * @API - API's are not available
   * @author Nikitan
   */
  verifyAmountAllocationInPopUp(amount: string, cpt: string) {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.ALLOCATION.CHARGE_TO_ALLOCATE_ROW[1])
      .contains(cpt)
      .parents(CommonGetLocators.tr)
      .find(
        CommonUtils.concatenate(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.COLUMN_SIX_CHARGE_TO_ALLOCATE[1],
          ' ',
          CommonGetLocators.input
        )
      )
      .should(ShouldMethods.value, amount);
  }
}
