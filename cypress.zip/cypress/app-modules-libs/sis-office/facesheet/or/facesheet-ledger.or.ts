import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_FACESHEET_LEDGER_TAB = {
  LEDGER: ['Ledger', '#Ledger'],
  LEDGER_TAB: [
    'Ledger',
    CommonUtils.concatenate(
      '.p-tabmenuitem.p-disabled',
      CoreCssClasses.Ng.loc_star_inserted
    ),
  ],
  ADD_BUTTON: ['Add button', '#btnAdd'],
  UNASSIGNED_PAYMENT: {
    PERIOD: ['Period', '#periodDropdownperiodBatch'],
    BATCH: ['Batch', '#batchDropdownperiodBatch'],
    CASE: ['Case', '#caseDOSProc'],
    AMOUNT_COLLECTED: ['Amount collected', '#numericInput'],
    TRANSACTION_CODE: ['Transaction code', '#transactionCode'],
    METHOD_OF_PAYMENT: ['Method of Payment', '#methodOfPayment'],
    DONE_BUTTON: ['Done', '#btnDone1'],
    DOS_TEXT: [
      'DOS',
      CommonUtils.concatenate(CoreCssClasses.Ng.loc_star_inserted, '> .col1'),
    ],
    TRANSACTION_DATE_TEXT: [
      'Transaction Date',
      CommonUtils.concatenate(CoreCssClasses.Ng.loc_star_inserted, '> .col2'),
    ],
    PHYSICIAN_TEXT: [
      'Physician',
      CommonUtils.concatenate(CoreCssClasses.Ng.loc_star_inserted, '> .col3'),
    ],
    TRANSACTION_Code_TEXT: [
      'Transaction Code',
      CommonUtils.concatenate(CoreCssClasses.Ng.loc_star_inserted, '> .col4'),
    ],
    AMOUNT_TEXT: [
      'Amount',
      CommonUtils.concatenate(CoreCssClasses.Ng.loc_star_inserted, '> .col5'),
    ],
    RECEIVED_FROM_TEXT: [
      'Received From',
      CommonUtils.concatenate(CoreCssClasses.Ng.loc_star_inserted, '> .col6'),
    ],
    UNALLOCATED_TEXT: [
      'Unallocated',
      CommonUtils.concatenate(CoreCssClasses.Ng.loc_star_inserted, '> .col7'),
    ],
    NOTES: ['Notes', '#notes'],
    PERIOD_IS_CLOSED_WARNING_MESSAGE: [
      'Period is closed.',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        ' ',
        CoreCssClasses.Text.loc_period_is_closed
      ),
    ],
    BATCH_IS_CLOSED_WARNING_MESSAGE: [
      'Batch is closed.',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        ' ',
        CoreCssClasses.Text.loc_batch_is_batch
      ),
    ],
    BATCH_PERIOD_IS_CLOSED_BY_ANOTHER_USER: [
      'Batch/Period closed by another user.Changes will not be saved',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        ' ',
        CoreCssClasses.Text.loc_error_label
      ),
    ],
  },
  SHOW_AGING: ['Show Aging', `.p-menuitem-text:contains('Show Aging')`],
  HIDE_AGING: ['Hide Aging', `.p-menuitem-text:contains('Hide Aging')`],
  PRINT_ICON_MASTHEAD: ['Print icon Masthead', '.print-icon > i'],
  CHART_CONSENT: ['Chart Consents', 'div.report-row:nth-child(1)'],

  UNASSIGNED_ALLOCATION: {
    TRANSACTION_CODE_UNASSIGNED: [
      'Transaction code',
      '#transactionCodeDropdown loc_dropdown_label ',
    ],
    ALLOCATION_AMOUNT: ['Allocation amount', '#numericInput'],
    DONE: [
      'Done button',
      CommonUtils.concatenate(
        '.button-prime >',
        CoreCssClasses.Button.loc_button_label,
        ':nth-child(1)'
      ),
    ],
  },
  UNASSIGNED_PAYMENT_CORRECTION: {
    CORRECTION_CODE: ['Correction Code', '#correctionTransactionCodeDropdown'],
    NEW_UP_AMOUNT: ['New UP Amount', '#newAmount input'],
  },
  ALLOCATION: {
    PERIOD: ['Period', '#periodDropdown'],
    PERIOD_VERIFY: [
      'Period Verify',
      CommonUtils.concatenate(
        '#periodDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        ':nth-child(1)'
      ),
    ],
    BATCH: ['Batch', '#batchDropdown'],
    TRANSACTION_CODE: ['Transaction Code', '#transactionCodeDropdown'],
    ALLOCATION_AMOUNT: [
      'allocation amount input',
      '> #numericInput',
      '#txtAllowedAmount',
    ],
    ALLOCATION_AMOUNT_VERIFY: ['Allocation Amount', '#numericInput'],
    BATCH_VERIFY: [
      'Batch Verify',
      CommonUtils.concatenate(
        '#batchDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        ':nth-child(1)'
      ),
    ],
    TRANSACTION_CODE_VERIFY: [
      'Transaction Code Verify',
      CommonUtils.concatenate(
        '#transactionCodeDropdown ',
        CoreCssClasses.DropDown.loc_p_dropdown,
        ':nth-child(1)'
      ),
    ],
    CHARGE_TO_ALLOCATE_ROW: [
      'Allocate Amount',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    COLUMN_SIX_CHARGE_TO_ALLOCATE: ['Allocate', '.col6'],
    CLOSE_ICON: ['Close', '#iconClose'],
    ROW_IN_CHARGE_TO_ALLOCATE: [
      'Row context menu to Allocate',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    TITLE_WINDOW: [
      'Unassigned Payment Allocation',
      CommonUtils.concatenate(CoreCssClasses.Dialog.loc_dialog_header, ' h3'),
    ],
    SUB_HEADER_TEXT: [
      'Unassigned Payment Details',
      '[class = unassigned-payment-allocation-model] > [class = sub-header-up]',
    ],
    TRANSACTION_DATE: [
      'Transaction Date',
      '[class = "up-header"] ~ div .row1-width.up-data',
    ],
    METHOD_OF_PAYMENT: [
      'Method Of Payment',
      '[class = "up-header"] ~ div .row3-width.up-data',
    ],
    ALLOCATED_AMOUNT: [
      'Allocated Amount',
      '[class = "up-header"] ~ div .row2-width-sub1.up-data',
    ],
    UNALLOCATED: [
      'Unallocated',
      '[class = "up-header"] ~ div .row2-width-sub1.up-color',
    ],
    CASE: ['Case', '.sub-up-row-1.up-header div div .row1-width span'],
    RECEIVED_FROM: [
      'Received From',
      '.sub-up-row-1.up-header div div .row3-width.up-data span',
    ],
    NOTES: [
      'Notes',
      '.sub-up-row-1.up-header div div .row2-width.up-data span',
    ],
    SUB_HEADER_CHARGE_TO_ALLOCATE: [
      'Charge to Allocate',
      'div .sub-header-up.charge-top-padding',
    ],
    DOS: [
      'DOS',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted,
        ' .col1'
      ),
    ],
    CPTHCPCS: [
      'CPT/HCPCS',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted,
        ' .col2',
        ' span'
      ),
    ],
    PHYSICIAN: [
      'physician',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted,
        ' .col3',
        ' span'
      ),
    ],
    CHARGE_AMOUNT: [
      'Charge Amount',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted,
        ' .col4'
      ),
    ],
    DUE: [
      'Due',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted,
        ' .col5'
      ),
    ],
    COPY_RIGHT: [
      'Copy right',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_footer,
        ' sis-cpt-copy-right'
      ),
    ],
  },
  CONTEXT_MENU: [
    'Context menu',
    CommonUtils.concatenate(
      '.col8 > ',
      CoreCssClasses.Ng.loc_star_inserted,
      '> .fa'
    ),
  ],
  ALLOCATE: [
    'Allocate',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_p_dropdown_list,
      '> :nth-child(1)',
      '>',
      CoreCssClasses.DropDown.loc_p_dropdown_link,
      '>',
      CoreCssClasses.DropDown.loc_dropdown_list
    ),
  ],
  PRINT_ICON: ['Print icon', '#iconPrint'],
  PRINT_OPTION: ['Print option', 'div.report-row'],
  AMOUNT_AGING: ['Amount aging', '.aging-vertical-spacer-top .aging-title'],
  AGING_LABELS: ['Aging Label', 'sis-aging-total .aging-title-global div'],
  AGING_AMOUNT: ['Aging Amount', 'sis-aging-total .aging-total-data div'],
  UNASSIGNED_PAYMENT_ROW: [
    'Unassigned Payment',
    '#tblUnassignedPaymentsData p-table tbody tr',
  ],
  SHOW_AGING_BOTTOM_ROW: [
    'Show Aging Bottom Row',
    'body .aging-vertical-spacer-bottom > div',
  ],
  CONTEXT_MENU_ITEMS: {
    CONTEXT_MENU_UNASSIGNED_PAYMENT_ROW: [
      'Unassigned Payment Row',
      CommonUtils.concatenate(
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    CONTEXT_MENU_OPTIONS: [
      'Context Menu Options',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_dropdown_list,
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    COLUMN_FOUR_TRANSACTION_CODE: ['Transaction Code', '.col4'],
    COLUMN_EIGHT_CONTEXT_MENU: ['Context Menu', '.col8'],
    COLUMN_ONEIN_WHICH_CONTEXT_MENU_HAS: ['DOS Value', '.col1'],
    COLUMN_TWOIN_WHICH_CONTEXT_MENU_HAS: ['Transaction Date	Value', '.col2'],
    COLUMN_THREEIN_WHICH_CONTEXT_MENU_HAS: ['Physician Value', '.col3'],
    COLUMN_FIVEIN_WHICH_CONTEXT_MENU_HAS: ['Amount Value', '.col5'],
    COLUMN_SIXIN_WHICH_CONTEXT_MENU_HAS: ['Received From Value', '.col6'],
    COLUMN_SEVENIN_WHICH_CONTEXT_MENU_HAS: ['Unallocated Value', '.col7'],
    VIEW_EDIT: [
      'View/Edit',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown_list,
        '> :nth-child(2)',
        '> ',
        CoreCssClasses.DropDown.loc_p_dropdown_link,
        '>',
        CoreCssClasses.DropDown.loc_dropdown_list
      ),
    ],
    DELETE: [
      'Delete',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown_list,
        '> :nth-child(3)',
        '> ',
        CoreCssClasses.DropDown.loc_p_dropdown_link,
        '>',
        CoreCssClasses.DropDown.loc_dropdown_list
      ),
    ],
    CORRECTION: [
      'Correction',
      CommonUtils.concatenate(
        CoreCssClasses.DropDown.loc_p_dropdown_list,
        '> :nth-child(4)',
        '> ',
        CoreCssClasses.DropDown.loc_p_dropdown_link,
        '>',
        CoreCssClasses.DropDown.loc_dropdown_list
      ),
    ],
  },

  ROW_IN_WHICH_CONTEXT_MENU_HAS: [
    'Row context menu',
    CommonUtils.concatenate(
      CoreCssClasses.Row.loc_p_selectable_row,
      CoreCssClasses.Ng.loc_star_inserted
    ),
  ],
  OPTIONS_IN_CONTEXT_MENU: [
    'Option in Context Menu',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_dropdown_list,
      CoreCssClasses.Ng.loc_star_inserted
    ),
  ],
  LOSS_OF_DATA: [
    'Loss of Data popup yes',
    CommonUtils.concatenate(
      '#btnAction>',
      CoreCssClasses.Button.loc_button_label
    ),
  ],
  NO_CHARGES_TEXT: ['No Charges found', '.td-no-hover'],
  NO_UNASSIGNED_PAYMENT_TEXT: ['No Unassigned Payments found', '.td-no-hover'],
  BILLING_HISTORY: ['Billing History', '#billingBtn'],
  BILLING_HISTORY_CHARGE_CHECKBOX: [
    'Billing hstory charge checkbox',
    CommonUtils.concatenate('#charges ', CoreCssClasses.Checkbox.loc_checkbox),
  ],
  PRINT_SELECTED_PATIENT_STATEMENT: [
    'Print selected patient statement',
    '#btnPrintStm',
  ],
  CLOSE_PRINT_PREVIEW: [
    'Close print preview',
    CommonUtils.concatenate(
      CoreCssClasses.Dialog.loc_dialog_header,
      '-close-icon'
    ),
  ],
  CLOSE_BILLING_HISTORY: ['Close billing history', '#iconClose'],
  BILL_SELECTED_PATIENT_STATEMENT: [
    'Bill selected patient statement',
    '#btnBillStm',
  ],
  BILL_SELECTED_PATIENT_STATEMENT_YES: ['Yes', '#btnConfirmYes span'],
  BILL_SELECTED_PATIENT_STATEMENT_NO: ['No', '#btnConfirmNo span'],
  OK_BUTTON: ['OK', 'button[label="OK"]'],
  PREVIEW: ['Preview'],
  PRINT: ['Print'],
  BILL_CONFIRMATION_POPUP_HEADER: [
    'Confirmation',
    CommonUtils.concatenate(
      CoreCssClasses.Dialog.loc_confirm_dialog,
      ' ',
      CoreCssClasses.Dialog.loc_dialog_title
    ),
  ],
  BILL_CONFIRMATION_TEXT: [
    'Bill confirmation text',
    CommonUtils.concatenate(
      'span',
      CoreCssClasses.Dialog.loc_confirm_dialog_message
    ),
  ],
  WAY_STAR_ICON: ['Way star icon'],
  WAIT_RESPONSIBLE_PARTY: ['multi', '#rpMultiSelect #msItems'],
  BILLED_CHECKBOX: ['Billed Checkbox', `input[type="checkbox"]`],
  NOTES: ['Notes', '#notesBtn'],
  BILLING_HISTORY_POPUP: {
    CHARGE_AMOUNT: ['Charge Amount'],
    CHARGE_ROW: [
      'Charge Row',
      `#pat-charge-with-history-table table tbody >tr`,
    ],
    PLUS_ICON: ['Plus Icon', 'td span i'],
    TRANSACTION_HEADER: [
      'Transaction Header',
      '#ondemand-billing_expanded .expansion-header th',
    ],
    TRANSACTION_BODY: [
      'Transation Body',
      '#ondemand-billing_expanded .expansion-body td',
    ],
    TRANSACTION_ROW: [
      'Transaction Row',
      '#ondemand-billing_expanded .expansion-body',
    ],
    BILLING_HISTORY_TABLE: [
      'Billing History Table',
      '#pat-charge-with-history-table ',
    ],
    BILLING_TRANSACTION_HEADER: [
      'Billing Transaction Row',
      '#ondemand-billing_expanded ',
    ],
    BILLING_TRANSACTION_ROW: [
      'Billing Transaction Row',
      CommonUtils.concatenate(
        CommonGetLocators.td,
        ' #ondemand-billing_expanded'
      ),
    ],
    BILL_SELECTED_CHARGES: ['Bill Selected Charges', '#btnBill'],
    PRINT_SELECTED_CHARGES: ['Print Selected Charges', '#btnPrint'],
    BILLED_CHARGE_ROWS: [
      'Billed Charge Lines',
      CommonUtils.concatenate(
        '#ondemand-billing_expanded ',
        CommonGetLocators.tr
      ),
    ],
    CLOSE_PRINT_MESSAGE: [
      'Close Icon',
      CoreCssClasses.Icon.loc_header_close_icon,
    ],
  },
  CLAIM_STATUS: ['Claim Status', '#claimHistoryBtn'],
  CHARGES_PLUS_ICON: [
    '+',
    CommonUtils.concatenate(
      '#chargesScrollPanel ',
      CoreCssClasses.ClassPrefix.loc_fa_fa,
      '-plus'
    ),
  ],
  BILL_SELECTED_INSURANCE_CHARGE: [
    'Bill selected insurance charge',
    '#btnBill',
  ],
  PRINT_SELECTED_INSURANCE_CHARGE: [
    'Print Selected Insurance Charge',
    '#btnPrint',
  ],
  PRINT_POP_UP_MODEL: {
    PRINT: [
      'Print',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        CoreCssClasses.Dialog.loc_dialog_header,
        ' h3'
      ),
    ],
    CLOSE_ICON: [
      'Close Icon',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        CoreCssClasses.Dialog.loc_dialog_header,
        ' i'
      ),
    ],
    PREVIEW: [
      'Preview',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_footer,
        ' ',
        selectorFactory.getSpanText('Preview')
      ),
    ],
  },
  BALANCE: ['Balance', '.balance-col .limittext-container'],
};
