import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_FACE_SHEET_CHARGE_ENTRY = {
  ADD_PROCEDURE: ['Add Procedure', '#btnAddProcedure'],
  PROCEDURE_SEARCH: [
    'Procedure Search',
    CommonUtils.concatenate(
      'div:last-child .',
      CoreCssClasses.Panel.loc_p_panel,
      '-content #procedureAutoComplete input'
    ),
  ],
  PROCEDURE_SELECTION: [
    'Procedure Selection',
    CoreCssClasses.List.loc_procedure_item,
  ],
  UPDATE: ['Update', '#btnUpdate'],
  SEARCH_BOX: ['Search Box', `input[placeholder*='Search Procedure']`],
  BALANCE: ['Balance'],
  BALANCE_AMOUNT: [
    'Balance',
    CommonUtils.concatenate(
      '.tppadding2rem ',
      CoreCssClasses.Text.loc_label_text
    ),
  ],
  AMOUNT_LABEL: ['Amount', `strong[class*='red-asterisk']`],
  YES: ['Yes', '#btnChargeYes'],
  TOTAL_AMOUNT: ['Total Amount', '#txtAmount0 input'],
  CPT_CHARGE_ROW: [
    'CPT Charge Row',
    CommonUtils.concatenate(
      CoreCssClasses.Panel.loc_p_header,
      `[id*=chargeRow] span.row`
    ),
  ],
  TRASH_ICON: ['Trash Icon', `i[id*='iconTrash']`],
  MODIFIER_DROPDOWN: ['Modifier 1', '#modifiersListDropdown1'],
  UPDATE_UNITS: ['Units', '#txtUnits2'],
  CONTRACT: ['Contract', '#adminconfig_search'],

  PROCEDURES_SEARCH_BOX: [
    'ProceduresSearchBox',
    '.right-inner-addon .full-input',
  ],
  MODIFIER_SEARCH_BOX: ['Modifier Search Box', 'input.p-dropdown-filter'],
  MODIFIER_VALUE: ['Modifier Value', '[role="option"] .limittext-holder'],
  PERFORMED_ITEMS: ['Performed Items', '#cpiPerformedList .SubTitle'],
  ADD_SUPPLIES: ['Add supplies', '#btnAddSupplies'],
  SEARCH_SUPPLIES: [
    'Supply selection',
    `input[placeholder*=' Search by name or inv #']`,
  ],
  SUPPLIES_SELECTION: ['Supply selection', `li[role='option']`],
  CHARGE_AMOUNT: ['Charge amount', `[id^='txtAmount'] #numericInput`],
  WRITE_OFF: ['Write off amount', '#txtWOAmount0 input'],
  AUTO_SORT: ['Auto sort', '#autoSortBtn'],
  CPT_ROW: ['Cpt', `[id^='chargeRow']`],
  DEBIT_AMOUNT: ['Debit amount', `[id^='txtDebitAmount'] #numericInput`],
  PLUS_ICON: [
    'Plus icon',
    CommonUtils.concatenate(
      '#btnAdd1 >',
      CoreCssClasses.Icon.loc_p_button_icon
    ),
  ],
  READY_BILL: [
    'Ready for bill',
    CommonUtils.concatenate('span', CoreCssClasses.Text.loc_label_text),
  ],
  HCPCS: ['HCPCS', '[id^="hcpcsInput"]'],
  WRITEOFF_AMOUNT: ['Writeoff Amount', '#amount'],
  NO_RESULTS: ['No records found', '#dtCEWriteOffs .td-no-hover div'],
  REVENUE_CODE: [
    'Revenue Code',
    CommonUtils.concatenate(
      '[id^="revenueCodeDropdown"] ',
      CoreCssClasses.DropDown.loc_p_dropdown
    ),
  ],
  CONTRACT_SEARCH_BOX: ['Search box', '#txt_cs_'],
  REVIEW_EDIT: ['ReviewOrEdit', '#tab_review_edit'],
  REVIEW_TYPE: ['ReviewType', '#review_type'],
  CONTRACTS_TITLE: ['Contracts Title', '.ins-contract-title'],
  CONTRACTS_CROSS_ICON: ['Contracts cross icon', '#i_cs_'],
  PRIMARY_INSURANCE: [
    'Primary Insurance',
    '[id*="primaryInsuranceDropdown"]',
  ],
  PHYSICIAN_DROPDOWN_ICON: [
    'Physician Dropdown Icon',
    CommonUtils.concatenate(
      '[id*="staffSingleSelectphysicianListDropdown"] ',
      CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
    ),
  ],
  PERIOD_DROPDOWN_ICON: [
    'Period Dropdown Icon',
    CommonUtils.concatenate(
      '[id*="periodDropdown"] ',
      CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
    ),
  ],
  BATCH_DROPDOWN_ICON: [
    'Batch Dropdown Icon',
    CommonUtils.concatenate(
      '[id*="batchDropdown"] ',
      CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
    ),
  ],
  REVENUE_CODE_DROPDOWN_ICON: [
    'Revenue Code Dropdown Icon',
    CommonUtils.concatenate(
      '[id*="revenueCodeDropdown"] ',
      CoreCssClasses.DropDown.loc_p_dropdown_trigger_icon
    ),
  ],
  MODIFIER_1: ['Modifier 1', selectorFactory.getStrongText('Modifier 1')],
};
