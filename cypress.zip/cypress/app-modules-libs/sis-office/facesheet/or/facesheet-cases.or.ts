import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_FACESHEET_CASE_PAGE = {
  CASE_HEADER: ['sis-case-header'],
  SIS_CASE: ['Sis Case', 'sis-case'],
  CASE_HEADER_MRN: ['MRN', '.patient-mrn > .data-value'],
  MRN: ['MRN', '.patient-info [tooltipposition=bottom] .limittext-container '],
  NOTES_BUTTON: ['Notes', '#notesBtn'],
  PAST_CASE_PLUS_ICON: ['+', '[id*="p-panel-0-label"]'],
  NOTES: {
    DIALOG_BOX: ['Notes Dialog', 'div.notesContainer-modal'],
    NOTES_BUTTON: ['Notes', '.button-area > #notesBtn'],
    NOTES_TEXT: ['Notes Text', '#noteText'],
    ADDED_NOTES: ['Added Notes', '.notesArea-inner'],
  },
  CASE_STATUS: [
    'FaceSheet Case Status',
    `div[class*='case-middle case-circle']`,
  ],
  FACE_SHEET_TITLE: [
    'FaceSheet Title',
    `div.page-container div[class='title']`,
  ],
  FORMS_AND_CONSENTS: {
    PRIMARY_PROCEDURE_PANEL: [
      'Primary Procedure',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_panel,
        ' .primary-procedure'
      ),
    ],
  },
  PATIENT_LABELS: ['Patient Labels', 'div[data-test-id="Patient Labels"]'],
  APPEAL_LETTERS: ['Appeal Letters'],
  PATIENT_DEMOGRAPHICS_FORM: [
    'Patient Demographics Form',
    'div[data-test-id="Patient Demographics Form"]',
  ],
  PREVIEW_BUTTON: ['Preview', '#rptChooserPreview'],
  PRINT: [
    'Print',
    CommonUtils.concatenate('div', CoreCssClasses.Dialog.loc_dialog_header),
  ],
  PATIENT_LABELS_POPUP: {
    LABEL_PATIENT_INPUT: [
      '# of label/patient',
      `[name^='labelsPerPatient'] input`,
    ],
    BEGIN_ROW: ['Begin Row', `[name^='beginRow'] input`],
    BEGIN_COLUMN: ['Begin Column', `[name^='beginColumn'] input`],
    PATIENT_LABEL_BLOCK: ['Patient Block', `[id^='LabelBlock']`],
    CLOSE_ICON: ['Close X mark', CoreCssClasses.Button.loc_close_icon],
    PATIENT_DETAILS: ['Patient details', 'table.label-data'],
    PREVIEW: [
      'Preview',
      CommonUtils.concatenate('span', CoreCssClasses.Dialog.loc_dialog_title),
    ],
    PATIENT_NAME: ['Patient name', 'label.patient-name'],
  },
  PRINT_PREVIEW_MODEL: {
    PREVIEW_TEXT: [
      'Preview',
      CommonUtils.concatenate(
        CoreCssClasses.Dialog.loc_dialog_title,
        ' ',
        CoreCssClasses.Panel.loc_p_header,
        ' ',
        selectorFactory.getH3Text('Preview')
      ),
    ],
    CLOSE_ICON: ['Close Icon', CoreCssClasses.Icon.loc_header_close_icon],
  },
};
