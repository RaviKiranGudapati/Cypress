import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { OR_FACESHEET_LEDGER_TAB } from './or/facesheet-ledger.or';

/* const values */
export const Header = 'Header';
export const TransactionHeader = 'TransactionHeader';

export class LedgerBilling {
  private orBillingHistoryPopup = OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY_POPUP;

  /**
   * @details - Verifying Billing History Header in Billing from Ledger tab
   * @param - values passed to verify Billing History Headers or Billing History Transaction Header in Billing History pop up
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBillingHistoryHeader(values: string[], option: string) {
    let locator: string = '';
    if (option == Header) {
      locator = this.orBillingHistoryPopup.BILLING_HISTORY_TABLE[1];
    } else {
      locator = this.orBillingHistoryPopup.BILLING_TRANSACTION_HEADER[1];
    }
    values.forEach((el) => {
      cy.cIsVisible(
        CommonUtils.concatenate(locator, selectorFactory.getThText(el)),
        el
      );
    });
  }

  /**
   * @details - Verifying BillSelectedCharges button in Billing from Ledger tab
   * @param- billingMsg passed to verify message in Bill selected charge pop up
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBillSelectedCharges(billingMsg: string) {
    cy.cIncludeText(
      this.orBillingHistoryPopup.BILL_SELECTED_CHARGES[1],
      this.orBillingHistoryPopup.BILL_SELECTED_CHARGES[0],
      billingMsg
    );
  }

  /**
   * @details - Verifying PrintSelectedCharges button in Billing from Ledger tab
   * @param- billingMsg passed passed to verify message in Print selected charge pop up
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyPrintSelectedCharges(billingMsg: string) {
    cy.cIncludeText(
      this.orBillingHistoryPopup.PRINT_SELECTED_CHARGES[1],
      this.orBillingHistoryPopup.PRINT_SELECTED_CHARGES[0],
      billingMsg
    );
  }

  /**
   * @details - Verify Number Of Charges present in Billing History
   * @param- count of charges to verify charges in Billing History pop up
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyNumberOfCharges(count: number) {
    cy.cHasLength(
      this.orBillingHistoryPopup.PLUS_ICON[1],
      this.orBillingHistoryPopup.PLUS_ICON[0],
      count
    );
  }

  /**
   * @details - Click On Plus Icon of charge in Billing History Based On Index
   * @param- index of the charge passed as parameter to click
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  clickOnPlusIconBasedOnIndex(index: number) {
    cy.cGet(this.orBillingHistoryPopup.PLUS_ICON[1]).eq(index).click();
  }

  /**
   * @details - Verify Billing Transaction Row is Disappear in Billing History
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBillingTransactionRow() {
    cy.cNotExist(
      this.orBillingHistoryPopup.BILLING_TRANSACTION_ROW[1],
      this.orBillingHistoryPopup.BILLING_TRANSACTION_ROW[1]
    );
  }

  /**
   * @details - Click On BillSelectedCharges in Billing History
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  clickOnBillSelectedCharges() {
    cy.cClick(
      this.orBillingHistoryPopup.BILL_SELECTED_CHARGES[1],
      this.orBillingHistoryPopup.BILL_SELECTED_CHARGES[0]
    );
  }

  /**
   * @details - Click On PrintSelectedCharges in Billing History
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  clickOnPrintSelectedCharges() {
    cy.cClick(
      this.orBillingHistoryPopup.PRINT_SELECTED_CHARGES[1],
      this.orBillingHistoryPopup.PRINT_SELECTED_CHARGES[0]
    );
  }

  /**
   * @details - Verify Billing PopUp MSG in Billing History
   * @param- billingMsg passed to verify message in Bill selected charge pop up
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBillingPopUpMsg(billingMsg: string) {
    cy.cIncludeText(
      OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_TEXT[1],
      OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_TEXT[0],
      billingMsg
    );
  }

  /**
   * @details - Verify Billing Error MSG in Billing History
   * @param- value passed to verify Billing Error MSG in pop up
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBillingErrorMSG(value: string) {
    cy.cGet(OR_FACESHEET_LEDGER_TAB.BILL_CONFIRMATION_TEXT[1]).then(
      ($value) => {
        expect($value.text().replace(/\s\s+/g, '')).to.includes(value);
      }
    );
  }

  /**
   * @details - Click Ok Billing History Statement
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  clickOk() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[1],
      OR_FACESHEET_LEDGER_TAB.OK_BUTTON[0]
    );
  }

  /**
   * @details - Verify Billing History in Ledger Tab
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBillingHistory() {
    cy.cIsVisible(
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[1],
      OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[0]
    );
  }

  /**
   * @details - Verify Billing Lines in Billing History
   * @param- count passed as parameter to verify number of Billed charges
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBilledRowsCount(count: number) {
    cy.cHasLength(
      this.orBillingHistoryPopup.BILLED_CHARGE_ROWS[1],
      this.orBillingHistoryPopup.BILLED_CHARGE_ROWS[0],
      count
    );
  }

  /**
   * @details - Verify Balance Amount in Billing History
   * @param- amount passed as parameter to verify balance
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  verifyBalanceAmount(amount: string) {
    cy.cIncludeText(
      selectorFactory.getTdText(amount),
      OR_FACESHEET_LEDGER_TAB.BALANCE[0],
      amount
    );
  }

  /**
   * @details - Click on Close Print PopUP
   * @Api - API's are Not Yet Identified
   * @author MadhuKiran
   */
  closePrintPopup() {
    cy.cClick(
      this.orBillingHistoryPopup.CLOSE_PRINT_MESSAGE[1],
      this.orBillingHistoryPopup.CLOSE_PRINT_MESSAGE[0]
    );
  }
}
