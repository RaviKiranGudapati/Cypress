import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import {
  Application,
  CommonClassAttributes,
  CommonGetLocators,
  FilterMethods,
  InvokeAttributes,
  InvokeMethods,
  ShouldMethods,
  confirmation,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

import { SubRoutes } from '../../../support/common-core-libs/application/constants/sub-routes.constants';
import { AppColors } from '../../../support/common-core-libs/application/constants/app-colors.constants';
import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import {
  caseTransaction,
  Debits,
  WriteOffs,
  Payments,
  Transfers,
} from '../../../test-data-models/sis-office/facesheet/case-transaction.model';
import { PatientCase, Cpt } from '../../../test-data-models/sis-office/case/patient-case.model';
import { AllocationCorrection } from '../../../test-data-models/sis-office/facesheet/facesheet.model';
import { ILocatorValue } from '../../../test-data-models/core/locator.model';
import { UnAssignedAllocation } from '../../../test-data-models/sis-office/facesheet/facesheet-ledger.model';

import { OR_TRANSACTION } from './or/facesheet-transactions.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_CHARGE_ENTRY } from '../trackers/or/charge-entry.or';
import { OR_FACESHEET_LEDGER_TAB } from './or/facesheet-ledger.or';

import FaceSheetCases from './facesheet-cases';

import { FaceSheetOptions } from './enums/facesheet-cases.enum';

import { FacesheetTransactionsApis } from './api/facesheet-transaction.api';

/* instance variables */
const color = require('onecolor');
const faceSheetCases = new FaceSheetCases();

/* const values */
const addNewItem = 'Add New Item';

/* enum values */
export enum TransactionsValues {
  payment = 'Payment',
  debit = 'Debit',
  writeoff = 'Write-Off',
  transfer = 'Transfer',
  correction = 'Correction',
}

export enum ContextMenu {
  denial_history = 'Denial History',
  view_edit = 'View/Edit',
  delete = 'Delete',
  correction = 'Correction',
  transactions = 'Transactions',
  edit = 'Edit',
  duplicate = 'Duplicate',
}

export enum TransactionHeaders {
  charge_correction = 'Charge Correction',
  transaction_type = 'Transaction Type',
  edit_debit = 'Edit Debit',
}

export enum ViewDeleteCorrection {
  view_delete_correction = 'View/Edit Delete Correction',
}

export enum TransactionsTypes {
  payments = 'Payments',
  debits = 'Debits',
  writeoffs = 'Write-Offs',
  transfers = 'Transfers',
}

export default class Transactions {
  /* instance variables */
  private facesheetTransactionApis = new FacesheetTransactionsApis();
  private sisOfficeDesktop: SISOfficeDesktop;

  /* object repositories */
  private orTransactionAllocation = OR_TRANSACTION.ALLOCATION_CORRECTION_POP_UP;
  private orSisOffice = OR_SIS_OFFICE_DESKTOP.SIS_OFFICE;
  private orTransactionDebitWriteOff =
    OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF;
  private orTransactionTransfer = OR_TRANSACTION.CHARGES_TRANSFER;
  private orTransactionPayments = OR_TRANSACTION.CHARGES_PAYMENTS;
  private orCharges = OR_TRANSACTION.CHARGES;

  constructor(
    private patientCase?: PatientCase,
    private caseTransactionInfo?: caseTransaction
  ) {
    this.sisOfficeDesktop = new SISOfficeDesktop();
  }

  get PatientCaseModel(): PatientCase {
    return this.patientCase!;
  }

  get caseTransactionModel(): caseTransaction {
    return this.caseTransactionInfo!;
  }

  /**
   * @details - select Charges row based on the cpt code passed
   * @param - cpt
   * @API - API's are not available
   */
  selectCPTCode(cpt: any) {
    const selector = selectorFactory.selectChargeFromTransactionPage(cpt);
    cy.cNotExist(
      OR_TRANSACTION.TRANSACTION_POPUP[1],
      OR_TRANSACTION.TRANSACTION_POPUP[0]
    ).then(() => {
      cy.cGet(selector).click();
    });
    cy.cClick(selector, cpt, false, true);
  }

  /**
   * @details - select debit/writeoff/payment/transfer icon
   * @param optionSelected - to pass the selection from Debit, Writeoff, Payment or Transfer
   * @API - API's are available - Implemented Completely
   * @author Praveen
   */
  selectTransactionForCharge(optionSelected: any) {
    const transactions = [
      {
        logicalName: this.orCharges.PAYMENTS[0],
        locator: this.orCharges.PAYMENTS[1],
        interceptCollection:
          this.facesheetTransactionApis.interceptPaymentTransactionalApi(),
      },
      {
        logicalName: this.orCharges.WRITE_OFFS[0],
        locator: this.orCharges.WRITE_OFFS[1],
        interceptCollection:
          this.facesheetTransactionApis.interceptWriteoffTransactionalApi(),
      },
      {
        logicalName: this.orCharges.DEBITS[0],
        locator: this.orCharges.DEBITS[1],
        interceptCollection:
          this.facesheetTransactionApis.interceptDebitTransactionalApi(),
      },
      {
        logicalName: this.orCharges.TRANSFERS[0],
        locator: this.orCharges.TRANSFERS[1],
        interceptCollection:
          this.facesheetTransactionApis.interceptTransferTransactionalApi(),
      },
    ];

    const selectedTransaction = transactions.find(
      (item) => item.logicalName === optionSelected
    );

    if (selectedTransaction) {
      const { locator, interceptCollection } = selectedTransaction;
      cy.cClickAndWaitApis(locator, interceptCollection);
    }
  }

  /**
   * @details - select dropdown from charges debit popup
   * @param - dropdown
   * @param - valueToSelect
   * @API - API's are not available
   */
  selectDropdownValueInDebitPopup(dropdown: string, valueToSelect: string) {
    const dropdowns = [
      {
        logicalName: this.orTransactionDebitWriteOff.PERIOD[0],
        locator: this.orTransactionDebitWriteOff.PERIOD[1],
      },
      {
        logicalName: this.orTransactionDebitWriteOff.BATCH[0],
        locator: this.orTransactionDebitWriteOff.BATCH[1],
      },
      {
        logicalName: this.orTransactionDebitWriteOff.DEBIT_TRANS_CODE[0],
        locator: this.orTransactionDebitWriteOff.DEBIT_TRANS_CODE[1],
      },
      {
        logicalName: this.orTransactionDebitWriteOff.GROUP_CODE[0],
        locator: this.orTransactionDebitWriteOff.GROUP_CODE[1],
      },
      {
        logicalName: this.orTransactionDebitWriteOff.REASON_CODE[0],
        locator: this.orTransactionDebitWriteOff.REASON_CODE[1],
      },
      {
        logicalName: this.orTransactionDebitWriteOff.REMARK_CODE[0],
        locator: this.orTransactionDebitWriteOff.REMARK_CODE[1],
      },
    ];

    const selectedDropdown = dropdowns.find(
      (item) => item.logicalName === dropdown
    );

    if (selectedDropdown) {
      const value = selectorFactory.getDropdownValues(valueToSelect);
      const { locator, logicalName } = selectedDropdown;
      cy.cRemoveMaskWrapper(Application.office);
      cy.cClick(locator, logicalName);
      cy.cClick(value, value);
    }
  }

  /**
   * @details - click Transfer to next party debit/writeoff/payment/transfer popup
   * @param yesNo Either pass Yes or No as an argument
   * @API - API's are not available
   * @author Bindhu
   */
  transferToNextParty(yesNo: string) {
    cy.cClick(
      CommonUtils.concatenate(
        this.orTransactionDebitWriteOff.TRANSFER_TO_NEXT_PARTY[1],
        ' ',
        selectorFactory.getSpanText(yesNo)
      ),
      this.orTransactionDebitWriteOff.TRANSFER_TO_NEXT_PARTY[0]
    );
  }

  /**
   * @details - Enter amount in debit popup debit amount
   * @param - amount
   * @API - API's are not available
   */
  transactionDebitEnterDebitAmount(amount: string) {
    cy.cType(
      this.orTransactionDebitWriteOff.AMOUNT[1],
      this.orTransactionDebitWriteOff.AMOUNT[0],
      amount
    );
  }

  /**
   * @details - enter Transaction date
   * @param date
   * @API - API's are not available
   */
  enterDateOfTransaction(date: string) {
    cy.cType(
      this.orTransactionDebitWriteOff.TRANS_DATE[1],
      this.orTransactionDebitWriteOff.TRANS_DATE[0],
      date,
      false,
      true
    );
  }

  /**
   * @details - select dropdown from charges debit popup
   * @param - dropdown
   * @param - ValueToSelect
   * @API - API's are not available
   */
  transactionWriteoffPopupSelectDropdownValue(
    dropdown: string,
    valueToSelect: string
  ) {
    const dropdowns = [
      {
        name: this.orTransactionDebitWriteOff.PERIOD[0],
        selector: this.orTransactionDebitWriteOff.PERIOD[1],
      },
      {
        name: this.orTransactionDebitWriteOff.BATCH[0],
        selector: this.orTransactionDebitWriteOff.BATCH[1],
      },
      {
        name: this.orTransactionDebitWriteOff.WRITEOFF_TRANS_CODE[0],
        selector: this.orTransactionDebitWriteOff.WRITEOFF_TRANS_CODE[1],
      },
    ];

    const selectedDropdown = dropdowns.find((item) => item.name === dropdown);

    if (selectedDropdown) {
      const value = selectorFactory.getDropdownValues(valueToSelect);
      const { selector, name } = selectedDropdown;
      cy.cRemoveMaskWrapper(Application.office);
      cy.cClick(selector, name);
      cy.cClick(value, value);
    }
  }

  /**
   * @details - Enter data in writeoff popup and post transaction
   * @param - writeoff
   * @API - API's are available - Implemented for click Done button
   * @author Praveen
   */
  writeoffPopupPostTransaction(
    writeoffs: WriteOffs,
    yesOrNo: YesOrNo = YesOrNo.no
  ) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    this.transactionWriteoffPopupSelectDropdownValue(
      this.orTransactionDebitWriteOff.WRITEOFF_TRANS_CODE[0],
      writeoffs.WriteoffTransactionCode ?? ''
    );
    this.transactionDebitEnterDebitAmount(writeoffs.WriteoffAmount!);
    this.enterDateOfTransaction(writeoffs.TransactionDate ?? '');
    this.transferToNextParty(yesOrNo);
    this.clickDoneOnTransactionsPopup();
  }

  /**
   * @details - Verify the CPT Border color in transactions
   * @API - API's are not available
   * @author Praveen
   */
  verifyCptBorderColor() {
    cy.cGet(this.orCharges.CHARGE_PANEL[1])
      .should(ShouldMethods.css, InvokeAttributes.border)
      .then(($val) => {
        const col = String($val).split(CommonClassAttributes.solid)[1];
        const hexValue = String(color(col).hex()).toLowerCase();
        expect(hexValue).to.equal(
          AppColors.component_enabled_toggle_button_selected
        );
      });
  }

  /**
   * @details Verify the balance due amount based on the cpt code
   * @param - cpt
   * @param - amount
   * @API - API's are not available
   */
  verifyBalanceDueBasedOnCpt(cpt: string, amount: string) {
    cy.cGet(this.orCharges.TRANSACTION_DETAILS[1]).then(($list) => {
      for (let i = 0; i < $list.length; i++) {
        cy.cGet(selectorFactory.transactionRow(i)).then(($val) => {
          const cptVal = $val.text().toString().includes(cpt);

          if (cptVal == true) {
            for (let j = 1; j < $val.length - 2; j++) {
              cy.cGet(selectorFactory.transactionRowColumn(i, j)).then(
                ($balAmount) => {
                  if (j == 7) {
                    expect(
                      $balAmount.text().replace(/\n|\r/g, '').trim()
                    ).to.contain(amount);
                  }
                }
              );
            }
          }
        });
      }
    });
  }

  /**
   * @details To verify the label names in Debit popup
   * @param - headerLabels
   * @param - dropdownLabels
   * @API - API's are not available
   */
  verifyDebitPopupLabelNames(headerLabels: any, dropdownLabels: any) {
    cy.cGet(this.orTransactionDebitWriteOff.DEBIT_CASE_DETAILS[1])
      .each(($val, index) => {
        expect($val.text()).to.contain(headerLabels[index]);
      })
      .then(() => {
        cy.wrap(this.orTransactionDebitWriteOff.DEBIT_DIALOGUE_CONTENT[1])
          .get(CommonGetLocators.label)
          .each(($ele, index) => {
            expect($ele.text().replace(/^[ ]+$/g, '')).to.contain(
              dropdownLabels[index]
            );
          });
      });
  }

  /**
   * @details - To verify the Debit amount and write off amounts for child transaction
   * @param - debitAmount
   * @param - writeOffAmount
   * @API - API's are not available
   */
  verifyDebitAmountWriteoffAmountContextMenuOptions(
    debitAmount: string,
    writeOffAmount: string
  ) {
    cy.cGet(
      OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1],
      OR_TRANSACTION.TRANSACTION_DETAILS_DATA[0]
    ).each(($transactionList) => {
      // Verify Debit
      cy.wrap($transactionList)
        .first()
        .within(() => {
          cy.cGet(CommonGetLocators.span)
            .eq(1)
            .then(($type) => {
              if ($type.text() === TransactionsValues.debit) {
                cy.wrap($type).should(ShouldMethods.length, 1);
                cy.cGet(CommonGetLocators.span)
                  .eq(3)
                  .should(ShouldMethods.text, '$' + debitAmount + '.00');
              }
              if ($type.text() === TransactionsValues.writeoff) {
                cy.wrap($type).should(ShouldMethods.length, 1);
                cy.cGet(CommonGetLocators.span)
                  .eq(3)
                  .should(ShouldMethods.text, '-$' + writeOffAmount + '.00');
              }
            });
          cy.cClick(
            OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[1],
            OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[0],
            false,
            true
          );
        });
      /*************Clicking on Context Menu and validating the options*********************/
      cy.cGet(CoreCssClasses.DropDown.loc_dropdown_list)
        .filter(FilterMethods.visible)
        .should(ShouldMethods.length, 3);
      cy.cGet(CoreCssClasses.DropDown.loc_dropdown_list)
        .filter(FilterMethods.visible)
        .then(($list) => {
          expect($list[0]).to.contain.text(ContextMenu.view_edit);
          expect($list[1]).to.contain.text(ContextMenu.delete);
          expect($list[2]).to.contain.text(ContextMenu.correction);
        });

      /*************Closing the Context Menu post validation*********************/
      cy.wrap($transactionList[0])
        .first()
        .within(() => {
          cy.cClick(
            OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[1],
            OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[0]
          );
        });
    });
  }

  /**
   * @details To verify the Debit details
   * @param - debitTransactionCode
   * @param - debitAmount
   * @API - API's are not available
   */
  verifyDebitInfo(debitTransactionCode: string, debitAmount: string) {
    cy.cGet(
      OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1],
      OR_TRANSACTION.TRANSACTION_DETAILS_DATA[0]
    ).each(($transactionList) => {
      // Verify Debit
      cy.wrap($transactionList)
        .first()
        .within(() => {
          cy.cGet(CommonGetLocators.span)
            .eq(1)
            .then(($type) => {
              if ($type.text() === TransactionsValues.debit) {
                cy.wrap($type).should(ShouldMethods.length, 1);
                cy.cGet(CommonGetLocators.span)
                  .eq(1)
                  .should(ShouldMethods.text, TransactionsValues.debit);
                cy.cGet(CommonGetLocators.span)
                  .eq(2)
                  .should(ShouldMethods.contain, debitTransactionCode);
                cy.cGet(CommonGetLocators.span)
                  .eq(3)
                  .should(ShouldMethods.text, '$' + debitAmount + '.00');
              }
            });
        });
    });
  }

  /**
   * @details - enter Transaction date in Payments
   * @param - date as parameter in function
   * @API - API's are not available
   */
  enterDateOfTransactionInPayments(date: string) {
    /**
     * Issue: The charges are not loading in payments popup when we click on the Payments icon in Transaction page.
     * Resolution: Based on the assertPaymentsPopupFields function to validate the mandatory fields and wait for other components like charges to load in the payments popup.
     */
    this.assertPaymentsPopupFields();
    cy.get(this.orTransactionPayments.TRANSACTION_DATE[1], {
      timeout: Cypress.config('responseTimeout'),
    })
      .should(ShouldMethods.visible)
      .then(() => {
        cy.cType(
          this.orTransactionPayments.TRANSACTION_DATE[1],
          this.orTransactionPayments.TRANSACTION_DATE[0],
          date,
          false,
          true
        );
      });
  }

  /**
   * @details - click Done in payments popup
   * @API - API's are available - Implemented
   * @author Praveen
   */
  clickDoneInPayment() {
    const interceptCollection =
      this.facesheetTransactionApis.interceptDoneTransactionApi();
    cy.cClickAndWaitApis(
      this.orTransactionPayments.DONE[1],
      interceptCollection
    );
  }

  /**
   * @details - click on update button in the payer details
   * @API - API's are available - Not yet Implemented
   * @author Praveen
   */
  clickUpdateButton() {
    //TODO: Need to implement API
    cy.cClick(
      this.orSisOffice.UPDATE_BUTTON[1],
      this.orSisOffice.UPDATE_BUTTON[0]
    );
  }

  /**
   * @details - To select the values from dropdown in Payments popup
   * @param - fieldName - This is an argument to pass for declare the field name of dropdown in function
   * @param - valueToSelect -This is an argument to pass for value selection in function
   * @API - API's are not available
   */
  selectValueInPayments(
    locator: string,
    fieldName: string,
    valueToSelect: string,
    options?: any
  ) {
    cy.cClick(locator, fieldName);
    cy.document()
      .its(CommonGetLocators.body)
      .find(CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper)
      .first()
      .within(() => {
        cy.cClick(
          selectorFactory.getSpanText(valueToSelect),
          fieldName,
          false,
          false,
          options
        );
      });
  }

  /**
   * @details - Select the values from dropdown Transaction Code, Group Code, Reason Code and Enter the amount in Payment popup.
   * @param - payments to be passed as model for reference
   * @API - API's are not available
   */
  selectTransactionValuesInPayments(payments: Payments) {
    cy.cGet(this.orTransactionPayments.PAYMENT_PANEL[1]).each(($cpt) => {
      if ($cpt.text().includes(payments.CPTHCPCS!)) {
        cy.wrap($cpt)
          .first()
          .within(() => {
            payments.TransactionType &&
            this.selectValueInPayments(
                this.orTransactionPayments.TRANSACTION_TYPE[1],                
                this.orTransactionPayments.TRANSACTION_TYPE[0],
                payments.TransactionType
              );
            payments.Amount &&
              cy.cType(
                this.orTransactionPayments.AMOUNT[1],
                '',
                payments.Amount
              );
            payments.TransactionCode &&
              this.selectValueInPayments(
                this.orTransactionPayments.TRANSACTION_CODE[1],
                this.orTransactionPayments.TRANSACTION_CODE[0],
                payments.TransactionCode!
              );
            payments.GroupCode &&
              this.selectValueInPayments(
                this.orTransactionPayments.GROUP_CODE[1],
                this.orTransactionPayments.GROUP_CODE[0],
                payments.GroupCode
              );
            payments.ReasonCode &&
              this.selectValueInPayments(
                this.orTransactionPayments.REASON_CODE[1],
                this.orTransactionPayments.REASON_CODE[0],
                payments.ReasonCode
              );
            payments.RemarkCode &&
              this.selectValueInPayments(
                this.orTransactionPayments.REMARK_CODE[1],
                this.orTransactionPayments.REMARK_CODE[0],
                payments.RemarkCode
              );
            payments.TransferTo &&
              this.selectValueInPayments(
                this.orTransactionPayments.TRANSFER_TO[1],
                this.orTransactionPayments.TRANSFER_TO[0],
                payments.TransferTo,
                { force: true } // Added force true because in the dashboard sometimes dropdown value is not selected
              );
          });
      }
    });
  }

  /**
   * @details - Enter data in payments popup
   * @param - payments as payment fields values
   * @param - charges - parameter representing charges (default value is 0).
   * @API - API's are not available
   * @author Bindhu
   */
  paymentsPopupPostTransaction(payments: Payments, charges = 0) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    payments.Period &&
      this.selectDropdownValueInDebitPopup(
        this.orTransactionDebitWriteOff.PERIOD[0],
        payments.Period!
      );
    payments.Batch &&
      this.selectDropdownValueInDebitPopup(
        this.orTransactionDebitWriteOff.BATCH[0],
        payments.Batch!
      );
    payments.TransactionDate &&
      this.enterDateOfTransactionInPayments(payments.TransactionDate!);
    payments.DeductibleAmount &&
      cy.cType(
        selectorFactory.deductible(charges),
        '',
        payments.DeductibleAmount ?? ''
      );
    payments.CopayAmount &&
      cy.cType(selectorFactory.copay(charges), '', payments.CopayAmount ?? '');
    payments.CoinsAmount &&
      cy.cType(selectorFactory.coins(charges), '', payments.CoinsAmount ?? '');
    this.selectTransactionValuesInPayments(payments);
  }

  /**
   * @details - To verify the total payment and write offs amount in Payment Popup at bottom
   * @param - payments as model reference passed as argument in function
   * @API - API's are not available
   */
  verifyTotalPaymentAndWriteOff(payment: Payments) {
    cy.cGet(this.orTransactionPayments.TOTALS_BOTTOM_BAR[1])
      .invoke(InvokeMethods.text)
      .then(($textLabels) => {
        let labelValues = $textLabels.split('\n');
        expect(labelValues[2]).to.include(payment.TotalPayments!);
        expect(labelValues[4]).to.include(payment.TotalWriteOffs!);
      });
  }

  /**
   * @details To verify the Charge related amount value in Payments popup
   * @param - payments as model reference passed as argument in function
   * @API - API's are not available
   */
  verifyChargeAmountValueInPayments(payments: Payments) {
    cy.cGet(this.orTransactionPayments.PAYMENT_SECTION[1]).each(($cpt) => {
      if ($cpt.text().includes(payments.CPTHCPCS!)) {
        cy.wrap($cpt)
          .first()
          .within(() => {
            cy.cGet(this.orTransactionPayments.PAYMENT_CPT_HEADER[1]).then(
              (index) => {
                for (let i = 1; i < index.length; i++) {
                  if (i == 7) {
                    cy.cGet(selectorFactory.getColHValues(i))
                      .invoke(InvokeMethods.text)
                      .then(($totalDue) => {
                        expect($totalDue).to.include(payments.TotalDue!);
                      });
                  }
                }
              }
            );
          });
      }
    });
  }

  /**
   *  @details - To delete charges in payments transaction
   *  @param - payments
   *  @API - API's are not available
   */
  deleteChargeInPayments(payments: Payments) {
    cy.cGet(this.orTransactionPayments.PAYMENT_SECTION[1]).each(($cpt) => {
      if ($cpt.text().includes(payments.CPTHCPCS!)) {
        cy.wrap($cpt)
          .first()
          .within(() => {
            cy.cGet(this.orTransactionPayments.TRASH_ICON[1]).click({
              force: true,
            });
          });
      }
    });
  }

  /**
   * @details To verify the CPT Chare in Transaction page
   * @param - cptData as model reference passed as argument in function
   * @API - API's are not available
   */
  verifyCPTCharge(cptData: Cpt) {
    cy.cNotExist(
      selectorFactory.selectChargeFromTransactionPage(
        cptData.CPTCodeAndDescription
      ),
      cptData.CPTCodeAndDescription
    );
  }

  /**
   * @details -verify copy right in transaction
   * @param copyRightValue  as parameter passed in the function
   * @API - API's are not available
   */
  verifyCopyRightTextInTransaction(copyRightValue: string) {
    cy.cGet(OR_TRANSACTION.CPTCDT_CODE[1]).each(($copyRightText) => {
      expect($copyRightText.text().trim()).to.contains(copyRightValue);
    });
  }

  /**
   * @details -select view/edit in payment context menu
   * @param index  as parameter passed in the function
   * @API - API's are available - Implemented
   * @author - Madhu Kiran
   */
  clickOnTransactionContextMenu(index: number, details: string) {
    const interceptCollections = {
      [this.orCharges.PAYMENTS[0]]:
        this.facesheetTransactionApis.interceptContextViewEditPaymentDetails(),
      [this.orCharges.WRITE_OFFS[0]]:
        this.facesheetTransactionApis.interceptViewEditWriteOffAndDebit(),
      [this.orCharges.DEBITS[0]]:
        this.facesheetTransactionApis.interceptViewEditWriteOffAndDebit(),
      // TODO - API are not Yet Identified
      [this.orCharges.ALLOCATION[0]]: [],
    };
    const interceptCollection = interceptCollections[details];
    cy.cClick(selectorFactory.transactionContextMenu(index), '');
    cy.cClickAndWaitApis(
      OR_TRANSACTION.VIEW_EDIT[1],
      interceptCollection,
      false,
      true
    );
  }

  /**
   * @details - Verify on update button in the payer details
   * @param - isDisabled as parameter passed in the function
   * @API - API's are not available
   */
  verifyUpdateButton(isDisabled: boolean = false) {
    if (isDisabled) {
      cy.cGet(this.orSisOffice.UPDATE_BUTTON[1]).should(
        ShouldMethods.class,
        CommonClassAttributes.disabled
      );
    } else {
      cy.cIsEnabled(
        this.orSisOffice.UPDATE_BUTTON[1],
        this.orSisOffice.UPDATE_BUTTON[0],
        false,
        true
      );
    }
  }
  /*
   * @details To verify the Billed Checkmark for charge in transaction page
   * @param - cpt as string reference using inside of function
   * @API - API's are not available
   */
  verifyBilledCheckMark(cpt: string, value: string) {
    this.selectChargeByCPT(cpt);
    cy.cGet(OR_TRANSACTION.CHARGE_COLUMNS[1])
      .eq(8)
      .first()
      .within(() => {
        cy.cGet(this.orCharges.BILLED_CHECK_BOX[1])
          .invoke(InvokeMethods.attribute, InvokeAttributes.class)
          .then(($checkboxValue) => {
            expect($checkboxValue).to.contain(value);
          });
      });
  }

  /**
   * @details - To verify the Info Icon tool tip text
   * @param - cpt as string reference using inside of function
   * @API - API's are not available
   */
  verifyInformationIcon(cpt: string) {
    this.selectChargeByCPT(cpt);
    cy.cGet(OR_TRANSACTION.CHARGE_COLUMNS[1])
      .eq(8)
      .first()
      .within(() => {
        cy.cGet(CommonGetLocators.i).should(
          InvokeMethods.attribute,
          InvokeAttributes.p_tool_tip,
          this.orCharges.INFO_ICON[0]
        );
      });
  }

  /**
   * @details - select charge by cpt code
   * @param cpt
   * @API - API's are not available
   */
  selectChargeByCPT(cpt: string) {
    cy.cGet(OR_TRANSACTION.CHARGE_ROWS[1]).each(($row) => {
      if ($row.text().indexOf(cpt) > 1) {
        cy.wrap($row)
          .first()
          .within(($ele) => {
            return $ele;
          });
      }
    });
  }

  /**
   * @details - To verify the last billed date value for charge
   * @param - cpt as string reference using inside of function
   * @param - dateValue
   * @API - API's are not available
   */
  verifyLastBilledDate(cpt: string, dateValue: string) {
    this.selectChargeByCPT(cpt);
    cy.cGet(OR_TRANSACTION.CHARGE_COLUMNS[1]).eq(9).contains(dateValue);
  }

  /**
   * @details - To click on claim status in Transaction page
   * @API - API's are available - Implemented
   * @Author - Praveen
   */
  clickClaimStatus() {
    const interceptCollection =
      this.facesheetTransactionApis.interceptClaimStatusApi();
    cy.cClickAndWaitApis(this.orCharges.CLAIM_STATUS[1], interceptCollection);
  }

  /**
   * @details - verify the claim status values related to last billed date
   * @param - cpt
   * @param - value
   * @API - API's are not available
   */
  verifyClaimStatus(cpt: string, value: string) {
    cy.cGet(OR_TRANSACTION.CLAIM_STATUS.CHARGE_ROWS[1]).each(($row) => {
      if ($row.text().includes(cpt)) {
        cy.wrap($row)
          .first()
          .within(() => {
            cy.cGet(CommonGetLocators.td).eq(4).contains(value);
          });
      }
    });
  }

  /**
   * @details - verify the last billed info icon with tooltip message
   * @param - cpt
   * @param - value
   * @API - API's are not available
   */
  verifyLastBilledInfoIcon(cpt: string, value: string) {
    cy.cGet(OR_TRANSACTION.CLAIM_STATUS.CHARGE_ROWS[1]).each(($row) => {
      if ($row.text().includes(cpt)) {
        cy.wrap($row)
          .first()
          .within(() => {
            cy.cGet(CommonGetLocators.td)
              .eq(4)
              .first()
              .within(() => {
                cy.cGet(CommonGetLocators.i).should(
                  InvokeMethods.attribute,
                  InvokeAttributes.p_tool_tip,
                  value
                );
              });
          });
      }
    });
  }

  /**
   * @details - verify the sent to way star icon for charges
   * @param - cpt
   * @param - flag
   * @API - API's are not available
   */
  verifySentToWaystar(cpt: string, flag: boolean = true) {
    cy.cGet(OR_TRANSACTION.CHARGE_ROWS[1]).each(($row) => {
      if ($row.text().includes(cpt)) {
        cy.wrap($row)
          .first()
          .within(() => {
            cy.cGet(CommonGetLocators.div)
              .eq(5)
              .first()
              .within(() => {
                cy.cNotExist(
                  this.orCharges.SENT_TO_WAYSTAR_ICON[1],
                  this.orCharges.SENT_TO_WAYSTAR_ICON[0],
                  flag
                );
              });
          });
      }
    });
  }

  /**
   * @details To click on the Billed check mark for charge in transaction page
   * @param - cpt as string reference using inside of function
   * @API - API's are available - Implemented
   * @Author - Praveen
   */
  clickBilledCheckMark(cpt: string) {
    const interceptCollection =
      this.facesheetTransactionApis.interceptBilledCheckboxApi();
    cy.cGet(OR_TRANSACTION.CHARGE_ROWS[1]).each(($row) => {
      if ($row.text().indexOf(cpt) > 1) {
        cy.wrap($row)
          .first()
          .within(() => {
            cy.cClickAndWaitApis(
              CoreCssClasses.Checkbox.loc_p_checkbox_box,
              interceptCollection
            );
          });
      }
    });
  }

  /**
   * @details - To verify the debit popup existing
   * @API - API's are not available
   */
  verifyDebitPopup() {
    cy.cNotExist(
      selectorFactory.getH3Text(TransactionsValues.debit),
      TransactionsValues.debit
    );
  }

  /**
   * @details - To verify the Transaction type value is disabled in Payments Pop-up
   * @param - payments as model reference passed as argument in function
   * @API - API's are not available
   */
  verifyTransactionTypeValueDisabledInPayment(payments: Payments) {
    cy.cGet(this.orTransactionPayments.PAYMENT_PANEL[1]).each(($cpt) => {
      if ($cpt.text().includes(payments.CPTHCPCS!)) {
        cy.wrap($cpt)
          .first()
          .within(() => {
            if (payments.TransactionType == TransactionsValues.writeoff) {
              this.verifyWriteOffToolTipInPayments();
            }
            cy.cClick(
              this.orTransactionPayments.TRANSACTION_TYPE[1],
              this.orTransactionPayments.TRANSACTION_TYPE[0],
              false,
              true
            );
          });
        cy.cGet(
          this.orTransactionPayments.TRANSACTION_TYPE_DROPDOWN_ITEMS[1]
        ).each(($value) => {
          if ($value.text().includes(payments.TransactionType!)) {
            cy.wrap($value)
              .invoke(InvokeMethods.attribute, InvokeAttributes.class)
              .should(ShouldMethods.contain, CommonClassAttributes.pdisabled);
          }
        });
      }
    });
  }

  /**
   * @details - To verify Warning message in Write-Off
   * @API - API's are not available
   */
  verifyWarningMessageInWriteOff() {
    cy.cGet(
      selectorFactory.getSpanText(AppErrorMessages.write_off_warning)
    ).should(ShouldMethods.visible);
  }

  /**
   * @details - To verify done button
   * @param - isEnabled
   * @API - API's are not available
   */
  verifyDoneButton(isEnabled: boolean = false) {
    cy.cIsEnabled(
      this.orSisOffice.DONE_BUTTON[1],
      this.orSisOffice.DONE_BUTTON[0],
      false,
      isEnabled
    );
  }

  /**
   * @details - To verify type count for a charge
   * @param - cpt
   * @param type
   * @type count
   * @API - API's are not available
   */
  verifyTypeCountForCharge(cpt: string, type: string, count: number = 0) {
    cy.cGet(this.orCharges.TRANSACTION_DETAILS[1]).each(($charge) => {
      if ($charge.text().includes(cpt)) {
        cy.wrap($charge)
          .first()
          .within(() => {
            cy.cGet(OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1])
              .find(selectorFactory.getSpanText(type))
              .should(ShouldMethods.length, count);
          });
      }
    });
  }

  /**
   * @details - To verify Write-Off tooltip in Payments
   * @API - API's are not available
   */
  verifyWriteOffToolTipInPayments() {
    cy.cGet(selectorFactory.getDivText(TransactionHeaders.transaction_type))
      .find(CommonGetLocators.i)
      .should(
        InvokeMethods.attribute,
        InvokeAttributes.p_tool_tip,
        AppErrorMessages.write_off_warning
      );
  }

  /**
   * @details - To delete the transaction
   * @param - cpt
   * @API - API's are not available
   */
  deleteTransaction(cpt: string) {
    cy.cGet(this.orCharges.TRANSACTION_DETAILS[1]).then(($list) => {
      for (let i = 0; i < $list.length; i++) {
        cy.cGet(selectorFactory.transactionRow(i)).then(($val) => {
          const cptVal = $val.text().toString().includes(cpt);
          if (cptVal == true) {
            cy.wrap($list)
              .eq(i)
              .first()
              .within(() => {
                cy.cGet(
                  OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1],
                  OR_TRANSACTION.TRANSACTION_DETAILS_DATA[0]
                ).each(($transactionList) => {
                  cy.wrap($transactionList)
                    .first()
                    .within(() => {
                      cy.cClick(
                        OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[1],
                        OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[0],
                        false,
                        true
                      );
                    });
                });
              });
            cy.cGet(CoreCssClasses.DropDown.loc_dropdown_list)
              .filter(FilterMethods.visible)
              .then(($list) => {
                expect($list[1]).to.contain.text(ContextMenu.delete);
                $list[1].click();
              });
            cy.cClick(
              OR_TRANSACTION.DELETE_POPUP.YES_BUTTON[1],
              OR_TRANSACTION.DELETE_POPUP.YES_BUTTON[0],
              false,
              true
            );
            cy.cWait(SubRoutes.case_to_charge_get);
          }
        });
      }
    });
  }

  /**
   * @details - To verify the presence of System Billed Icon
   * @param - presence
   * @API - API's are not available
   */
  verifySystemBilledIcon(presence: boolean = true) {
    cy.cGet(OR_TRANSACTION.CHARGE_ROWS[1]).each(($row) => {
      cy.wrap($row)
        .first()
        .within(() => {
          if (presence) {
            cy.cIsVisible(
              this.orCharges.SYSTEM_BILLED_ICON[1],
              this.orCharges.SYSTEM_BILLED_ICON[0]
            );
          } else {
            cy.cNotExist(
              this.orCharges.SYSTEM_BILLED_ICON[1],
              this.orCharges.SYSTEM_BILLED_ICON[0]
            );
          }
        });
    });
  }

  /**
   * @details - verify transaction code mapped with procedure under face sheet transaction tab
   * @param text to be verified in transaction tab
   * @API - API's are not available
   */
  verifyTextInTransactionTab(text: string) {
    cy.cIsVisible(selectorFactory.getSpanText(text), text);
  }

  /**
   * @details - click on transactions in facesheet
   * @API - API's are available - Not Implemented
   */
  selectTransactions() {
    cy.cClick(
      selectorFactory.getSpanText(ContextMenu.transactions),
      ContextMenu.transactions
    );
  }

  /**
   * @details - selecting te drop down values in transfer pop-up for next responsible party and the transaction code
   * @param dropdown - select the dropdown control
   * @param valueToSelect - select the value from the dropdown
   * @API - API's are not available
   */
  transactionTransferPopupSelectDropdownValue(
    dropdown: string,
    valueToSelect: string
  ) {
    const dropdowns = [
      {
        logicalName: this.orTransactionTransfer.NEXT_RESPONSIBLE_PARTY[0],
        locator: this.orTransactionTransfer.NEXT_RESPONSIBLE_PARTY[1],
      },
      {
        logicalName: this.orTransactionTransfer.TRANSFER_TRANSACTION_CODE[0],
        locator: this.orTransactionTransfer.TRANSFER_TRANSACTION_CODE[1],
      },
    ];

    const selectedDropdown = dropdowns.find(
      (item) => item.logicalName === dropdown
    );

    if (selectedDropdown) {
      const value = selectorFactory.getDropdownValues(valueToSelect);
      const { locator, logicalName } = selectedDropdown;
      cy.cRemoveMaskWrapper(Application.office);
      cy.cClick(locator, logicalName);
      cy.cClick(value, value);
    }
  }

  /**
   * @details - for transfer the charge to the desired party
   * @param code - to select the cpt code to transfer
   * @param period - to select the period
   * @param batch - to select the batch
   * @param nextRespParty - to select the next responsible party
   * @param transferCode -to select transfer code as per nextRespParty
   * @API - API's are available - Not Implemented
   */
  transferCharge(
    code: string,
    period: string,
    batch: string,
    nextRespParty: string,
    transferCode: string
  ) {
    this.selectCPTCodeAndTransactionForCharge(
      code,
      this.orCharges.TRANSFERS[0]
    );
    this.selectDropdownValueInDebitPopup(
      this.orTransactionDebitWriteOff.PERIOD[0],
      period
    );
    this.selectDropdownValueInDebitPopup(
      this.orTransactionDebitWriteOff.BATCH[0],
      batch
    );
    this.transactionTransferPopupSelectDropdownValue(
      this.orTransactionTransfer.NEXT_RESPONSIBLE_PARTY[0],
      nextRespParty
    );
    this.transactionTransferPopupSelectDropdownValue(
      this.orTransactionTransfer.TRANSFER_TRANSACTION_CODE[0],
      transferCode
    );
    this.clickDoneOnTransactionsPopup();
  }

  /**
   * @details - To verify Responsible column
   * @param - guarantor as parameters inside the function
   * @API - API's are not available
   */
  verifyResponsible(guarantor: string) {
    cy.cGet(this.orCharges.TRANSACTION_DETAILS[1]).each(($charge) => {
      expect($charge.text()).includes(guarantor);
    });
  }

  /**
   * @details verify context menu in Transactions
   * @API - API's are not available
   */
  verifyContextMenuOptions() {
    cy.cClick(
      OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[1],
      OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[0],
      false,
      true
    );

    cy.cGet(CoreCssClasses.DropDown.loc_dropdown_list)
      .filter(FilterMethods.visible)
      .should(ShouldMethods.length, 3);
    cy.cGet(CoreCssClasses.DropDown.loc_dropdown_list)
      .filter(FilterMethods.visible)
      .then(($list) => {
        expect($list[0]).to.contain.text(ContextMenu.view_edit);
        expect($list[1]).to.contain.text(ContextMenu.delete);
        expect($list[2]).to.contain.text(ContextMenu.correction);
      });
    cy.cClick(
      OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[1],
      OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[0],
      false,
      true
    );
  }

  /**
   * @details - select option in context menu option in transactions
   * @param option to be selected in context menu
   * @API - API's are not available
   */
  selectContextMenuOption(option: string) {
    cy.cClick(
      OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[1],
      OR_TRANSACTION.TRANSACTION_CONTEXT_MENU[0],
      false,
      true
    );
    cy.cGet(CoreCssClasses.DropDown.loc_dropdown_list)
      .filter(FilterMethods.visible)
      .contains(option)
      .click();
  }

  /**
   * @details - To verify fields in Allocation Correction PopUp. This method asserts data in UI and date we passed to be same.
   * @param transactionDate - TransactionDate need to be passed
   * @param transactionCode - TransactionCode need to be passed
   * @param allocationAmount - AllocationAmount need to be passed
   * @param receivedFrom - ReceivedFrom need to be passed
   * @API - API's are not available
   */
  verifyFieldsInAllocationCorrectionPopUp(
    transactionDate: string,
    transactionCode: string,
    allocationAmount: string,
    receivedFrom: string
  ) {
    cy.cGet(this.orTransactionAllocation.SECOND_ROW[1]).then(($values) => {
      if (transactionDate !== undefined)
        expect($values[0]).to.contain.text(transactionDate);
      if (transactionCode !== undefined)
        expect($values[1]).to.contain.text(transactionCode);
      if (allocationAmount !== undefined)
        expect($values[2]).to.contain.text(allocationAmount);
      if (receivedFrom !== undefined)
        expect($values[3]).to.contain.text(receivedFrom);
    });
  }

  /**
   * @details - verify period in Allocation Correction PopUp
   * @param period to be verified in pop-up
   * @API - API's are not available
   */
  verifyPeriodInAllocationCorrection(period: string) {
    cy.cIncludeText(
      this.orTransactionAllocation.PERIOD[1],
      this.orTransactionAllocation.PERIOD[0],
      period
    );
  }

  /**
   * @details - verify batch in Allocation Correction PopUp
   * @param batch to be verified in pop-up
   * @API - API's are not available
   */
  verifyBatchInAllocationCorrection(batch: string) {
    cy.cIncludeText(
      this.orTransactionAllocation.BATCH[1],
      this.orTransactionAllocation.BATCH[0],
      batch
    );
  }

  /**
   * @details - verify amount in Allocation PopUp
   * @param amount to be entered in field
   * @API - API's are not available
   */
  enterNewAllocationAmount(amount: string) {
    cy.cType(
      this.orTransactionAllocation.NEW_ALLOCATION_AMOUNT[1],
      this.orTransactionAllocation.NEW_ALLOCATION_AMOUNT[0],
      amount
    );
  }

  /**
   * @details - verify balance in Allocation PopUp
   * @param balance to be verified in pop-up
   */
  verifyNewBalance(balance: string) {
    cy.cIncludeText(
      this.orTransactionAllocation.NEW_BALANCE[1],
      this.orTransactionAllocation.NEW_BALANCE[0],
      balance
    );
  }

  /**
   * @details - enter notes in Allocation PopUp
   * @param allocationCorrection model values(Notes) needs to be passed as reference
   * @API - API's are not available
   * @author Bindhu
   */
  enterNotes(allocationCorrection: AllocationCorrection) {
    allocationCorrection.Notes &&
      cy.cType(
        this.orTransactionAllocation.NOTES[1],
        this.orTransactionAllocation.NOTES[0],
        allocationCorrection.Notes!
      );
  }

  /**
   * @details - verify Done button in Allocation Correction PopUp
   * @param isPresent to be passed to check button presence
   * @API - API's are not available
   */
  verifyDoneButtonIsPresent(isPresent: boolean = true) {
    isPresent
      ? cy.cIsVisible(
          this.orTransactionAllocation.DONE[1],
          this.orTransactionAllocation.DONE[0]
        )
      : cy.cNotExist(
          this.orTransactionAllocation.DONE[1],
          this.orTransactionAllocation.DONE[0]
        );
  }

  /**
   * @details - click on Done button
   * @API - API's are available - Not Implemented
   */
  clickDoneButton() {
    cy.cClick(
      selectorFactory.getSpanText(this.orTransactionAllocation.DONE[0]),
      this.orTransactionAllocation.DONE[0]
    );
  }

  /**
   * @details - verify new line is added or not
   * @param count to be passed for line count
   * @param flag to be passed as true or false
   * @API - API's are not available
   */
  verifyNewLineAdded(count: number, flag: boolean = true) {
    cy.cGet(this.orCharges.TRANSACTIONS[1])
      .first()
      .within(() => {
        let length = undefined;
        if (!flag) {
          length = ShouldMethods.length_less_than;
          count = count + 1;
        } else {
          length = ShouldMethods.length_greater_than;
        }
        cy.cGet(this.orCharges.TRANSACTION_LINE[1]).should(length, count);
      });
  }

  /**
   * @details - select dropdown in Allocation Correction PopUp
   * @param dropdown to be selected in correction pop-up
   * @param valueToSelect value to be selected in dropdown
   * @API - API's are not available
   */
  selectDropdownAllocationCorrectionPopUp(
    dropdown: string,
    valueToSelect: string
  ) {
    let dropdownSelector: string = '';
    const value = selectorFactory.getDropdownValues(valueToSelect);
    let dropdownLogicalName: string = '';

    const dropdownOptions = [
      {
        selector: this.orTransactionAllocation.CORRECTION_CODE[1],
        logicalName: this.orTransactionAllocation.CORRECTION_CODE[0],
      },
    ];

    const selectedOption = dropdownOptions.find(
      (option) => option.logicalName === dropdown
    );

    if (selectedOption) {
      dropdownSelector = selectedOption.selector;
      dropdownLogicalName = selectedOption.logicalName;
    }

    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, dropdownLogicalName);
    cy.cClick(value, value);
  }

  /**
   * @details -verify Transaction Date, Type, Amount in allocation and correction line in Charges table
   * @param type to be verified in charges table
   * @param date to be verified in charges table
   * @param amount to be verified in charges table
   * @API - API's are not available
   */
  verifyFieldsInChargesTable(type: string, date: string, amount: string) {
    cy.cGet(this.orCharges.TRANSACTIONS[1]).within(() => {
      cy.cGet(this.orCharges.TRANSACTION_LINE[1])
        .contains(type)
        .parent()
        .within(() => {
          cy.cGet(CommonGetLocators.span).eq(0).contains(date);
          cy.cGet(CommonGetLocators.span).eq(1).contains(type);
          cy.cGet(CommonGetLocators.span).eq(3).contains(amount);
        });
    });
  }

  /**
   * @details - verify the Allocation Correction fields
   * @param allocationCorrection to be passed as model for reference
   * @param flag to be passed for reference
   * @API - API's are not available
   */
  verifyFieldsInAllocationCorrection(
    allocationCorrection: AllocationCorrection,
    flag: boolean = true
  ) {
    allocationCorrection.Period!
      ? this.verifyPeriodInAllocationCorrection(allocationCorrection.Period!)
      : null;
    allocationCorrection.Batch!
      ? this.verifyBatchInAllocationCorrection(allocationCorrection.Batch)
      : null;

    this.verifyFieldsInAllocationCorrectionPopUp(
      allocationCorrection.TransactionDate!,
      allocationCorrection.TransactionCode!,
      allocationCorrection.AllocationAmount!,
      allocationCorrection.ReceivedFrom!
    );
    allocationCorrection.NewBalance!
      ? this.verifyNewBalance(allocationCorrection.NewBalance)
      : null;
    flag ? this.verifyDoneButtonIsPresent() : null;
  }

  /**
   * @details - Allocation Correction
   * @param allocationCorrection to be passed as reference model
   * @API - API's are not available
   */
  allocationCorrection(allocationCorrection: AllocationCorrection) {
    this.enterNewAllocationAmount(allocationCorrection.NewAllocationAmount!);
    this.enterNotes(allocationCorrection);
    this.selectDropdownAllocationCorrectionPopUp(
      OR_TRANSACTION.ALLOCATION_CORRECTION_POP_UP.CORRECTION_CODE[0],
      allocationCorrection.CorrectionCode!
    );
  }

  /**
   * @details - to verify balance due in transactions
   * @param row - Passing for which row number in the transaction
   * @param column - Passing for which column number in the transaction
   * @param amount- to verify the amount value in the transaction
   */
  verifyBalanceDueInTransactions(row: number, column: number, amount: string) {
    cy.cGet(selectorFactory.transactionRowColumn(row, column)).contains(amount);
  }

  /**
   * @details - Verify the payment other option in transaction page
   */
  verifyOptionInTransaction() {
    const fields = [
      this.orCharges.PAYMENTS[1],
      this.orCharges.DEBITS[1],
      this.orCharges.TRANSFERS[1],
      this.orCharges.WRITE_OFFS[1],
    ];
    fields.forEach((field) => {
      cy.shouldBeEnabled(field);
    });
  }

  /**
   * selecting period and batch Labels in Balance Reconciliation
   * @API - API's are not available
   */
  clickPeriodAndBatchLabel() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getLabelText(this.orTransactionDebitWriteOff.PERIOD[0]),
      this.orTransactionDebitWriteOff.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getLabelText(this.orTransactionDebitWriteOff.BATCH[0]),
      this.orTransactionDebitWriteOff.BATCH[0],
      false,
      true
    );
  }

  /**
   * @details - To verify the period is closed and batch is closed in Unassigned Payment Edit
   * @param locator - To pass the locator as parameter (period or batch locator)
   * @param logicalName - To pass the logicalname in unassigned payment (period or batch)
   * @param message - to verify the value present (ex: period is closed)
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyPeriodAndBatchClosedWarningMsg(
    locator: string,
    logicalName: string,
    message: string
  ) {
    cy.cIncludeText(locator, logicalName, message);
  }

  /**
   * details - To select the dropdown in unassigned payment allocation popup
   * @param dropdown to be selected
   * @param valueToSelect value to be selected in drop down
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  unassignedPaymentAllocationSelectDropdown(
    dropdown: string,
    valueToSelect: string
  ) {
    let dropdownSelector: string;
    const value = selectorFactory.getDropdownValues(valueToSelect);
    let dropdownLogicalName: string;
    switch (dropdown) {
      case OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0]:
        dropdownSelector = OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[1];
        dropdownLogicalName = OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0]:
        dropdownSelector = OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[1];
        dropdownLogicalName = OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0];
        break;
      case OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0]:
        dropdownSelector =
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[1];
        dropdownLogicalName =
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0];
        break;
      default:
        break;
    }
    cy.cClick(dropdownSelector!, dropdownLogicalName!);
    cy.cClick(value, value);
  }

  /**
   * @details - Enter amount in allocation popup
   * @param amount - Passing amount number in the allocation popup(ex: 1000)
   * @param rowNo to which row need to pass for allcation of amount(ex: 0,1)
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  enterAllocationAmount(amount: number, rowNo: string) {
    cy.cClick(
      CommonUtils.concatenate(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[2],
        rowNo,
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[1]
      ),
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[0]
    );
    cy.cType(
      CommonUtils.concatenate(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[2],
        rowNo,
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[1]
      ),
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT[0],
      amount
    );
  }

  /**
   * @details click on Done button in Edit Allocation Popup
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  clickOnDoneInEditAllocationPopUp() {
    cy.cClick(
      selectorFactory.getSpanText(
        OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DONE_BUTTON[0]
      ),
      OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.DONE_BUTTON[0]
    );
  }

  /**
   * @details To edit Unassigned Payment Allocation
   * @param allocation to be passed as model for reference
   * @param rowNo to select the which row in Unassigned Payment Allocation(0,1)
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  editUnassignedPaymentAllocation(
    allocation: UnAssignedAllocation,
    rowNo: string
  ) {
    if (allocation.Period !== undefined)
      this.unassignedPaymentAllocationSelectDropdown(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0],
        allocation.Period!
      );

    if (allocation.Batch !== undefined)
      this.unassignedPaymentAllocationSelectDropdown(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0],
        allocation.Batch!
      );

    if (allocation.TransactionCode !== undefined)
      this.unassignedPaymentAllocationSelectDropdown(
        OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0],
        allocation.TransactionCode
      );

    if (allocation.AmountAllocation !== undefined)
      this.enterAllocationAmount(allocation.AmountAllocation, rowNo);
    this.clickOnDoneInEditAllocationPopUp();
  }

  /**
   * @details - To verify Allocation Amount is editable in Edit Unassigned Payment Allocation
   * @param disabled - disabled is passed as param(true or false) to check Disabled or Enabled
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyAllocationAmount(disabled: boolean = true) {
    let filledVal = disabled
      ? CommonClassAttributes.filled
      : CommonClassAttributes.valid;

    cy.cHasAttribute(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT_VERIFY[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.ALLOCATION_AMOUNT_VERIFY[0],
      InvokeAttributes.class,
      filledVal
    );
  }

  /**
   * @details - To verify Period and batch  dropdown is Disabled in Edit Unassigned Payment Allocation
   * @param locator - to be passed as string
   * @param disabled - disabled is passed as param(true or false) to check Disabled or Enabled
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyPeriodAndBatchDropdown(locator: string, disabled: boolean = true) {
    cy.cGet(locator)
      .invoke(InvokeMethods.attribute, InvokeAttributes.class)
      .should(
        disabled ? ShouldMethods.include : ShouldMethods.not_class,
        CommonClassAttributes.pdisabled
      );
  }

  /**
   * @details - To verify Correction dropdown is Disabled in Edit Unassigned Payment Allocation
   * @param disabled - disabled is passed as param(true or false) to check Disabled or Enabled
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyTransactionDropdown(disabled: boolean = true) {
    let shouldValue = disabled
      ? ShouldMethods.include
      : ShouldMethods.not_class;
    cy.cGet(OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE_VERIFY[1])
      .invoke(InvokeMethods.attribute, InvokeAttributes.class)
      .should(shouldValue, CommonClassAttributes.pdisabled);
  }

  /**
   * @details - To verify fields in allocation correction popup are editable or not
   * @param disabled - disabled is passed as param(true or false) to check Disabled or Enabled
   * @API - API's are not Yet identified
   * @author Rakesh
   */
  verifyEditUpAllocation(disabled: boolean = true) {
    this.verifyAllocationAmount(disabled);
    this.verifyPeriodAndBatchDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD_VERIFY[1],
      disabled
    );
    this.verifyPeriodAndBatchDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH_VERIFY[1],
      disabled
    );
    this.verifyTransactionDropdown(disabled);
  }

  /**
   * @details - To assert the mandatory fields in Payments Transaction popup.
   */
  assertPaymentsPopupFields() {
    const paymentsFields = [
      this.orTransactionDebitWriteOff.PERIOD[1],
      this.orTransactionDebitWriteOff.BATCH[1],
      this.orTransactionPayments.TRANSACTION_DATE[1],
      this.orTransactionPayments.RECEIVED_FROM[1],
    ];
    paymentsFields.forEach((payFields) => {
      cy.shouldBeEnabled(payFields);
    });
  }

  /**
   * @details - Verify context menu in Transactions
   */
  verifyContextMenu() {
    /**
     * @Issue: Current should be visible is not helping for the asserting
     * @Resolution: we have added the should be enabled method for the context menu to be enable
     */
    cy.shouldBeEnabled(selectorFactory.transactionContextMenu(0));
  }

  /**
   * @detail - To select period and add new batch
   * @param period - To provide the period name
   * @param batch - To provide the batch name
   * @API - API's are available - Not Implemented (Done button)
   * @author Praveen
   */
  selectPeriodAddNewBatch(period: string, batch: string) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cClick(selectorFactory.getSpanText(addNewItem), addNewItem);
    cy.cType(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH_TEXT_INPUT[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH_TEXT_INPUT[0],
      batch
    );
    this.sisOfficeDesktop.clickDoneButtonPopup();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details click on Done button in write-off Popup
   * @API - API's are available - Implemented Completely
   * As Api response are same in payment and writeoff done button using interceptDonePaymentApi() in clickDoneWriteoffpopup
   * @author Spoorthy
   */
  clickDoneOnTransactionsPopup() {
    const interceptCollection =
      this.facesheetTransactionApis.interceptDoneTransactionApi();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - To verify amount for a charge based on type
   * @param - cpt to select the charge
   * @param- amountType to select the payment type
   * @param -value- to verify amount
   * @API - API's are not available
   * @Author-Spoorthy
   */
  verifyAmountBasedOnType(cpt: string, amountType: string, value: string) {
    cy.cGet(this.orCharges.TRANSACTION_DETAILS[1]).each(($charge) => {
      if ($charge.text().includes(cpt)) {
        cy.wrap($charge)
          .first()
          .within(() => {
            cy.cGet(OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1]).find(
              selectorFactory.getSpanText(amountType)
            );
            cy.cGet(OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1])
              .contains(value)
              .should(ShouldMethods.visible);
          });
      }
    });
  }

  /**
   * @details -select option in payment context menu dropdown
   * @param index  as per number of transaction available
   * @param value as view/edit, delete, correction
   * @API - API's are not available
   * @author Bindhu
   */
  clickContextMenuOptionsItems(index: number, value: string) {
    cy.cClick(selectorFactory.transactionContextMenu(index), '');
    cy.cClick(
      CommonUtils.concatenate(
        OR_TRANSACTION.VIEW_DELETE_CORRECTION[1],
        selectorFactory.getSpanText(value)
      ),
      OR_TRANSACTION.VIEW_DELETE_CORRECTION[0],
      false,
      true
    );
  }

  /**
   * @details -Click on Yes Or No button in delete popup
   * @param option Yes or No
   * @API - API's are available - Implemented Completely
   * @author Bindhu
   */
  clickYesOrNoInDeletePopUp(option: string) {
    const interceptYesButton =
      this.facesheetTransactionApis.interceptDeletionPopup();
    cy.cIntercept(interceptYesButton);
    if (option == YesOrNo.yes) {
      cy.cClick(selectorFactory.selectYesNo(option), option);
      cy.cWaitApis(interceptYesButton);
    } else {
      cy.cClick(selectorFactory.selectYesNo(option), option);
    }
  }

  /**
   * @details - click on X icon in popup
   * @API - API's are not available
   * @author - Bindhu
   */
  clickXBtnInPopup() {
    cy.cClick(this.orSisOffice.CLOSE_ICON[1], this.orSisOffice.CLOSE_ICON[0]);
  }

  /**
   * @details - select dropdown from charges transfers popup
   * @param dropdown - select the dropdown control
   * @param valueToSelect - select the value from the dropdown
   * @API - API's are not available
   * @author Bindhu
   */
  selectDropdownValueInTransfersPopup(dropdown: string, valueToSelect: string) {
    let dropdownSelector: string = '';
    let dropdownLogicalName: string = '';

    if (dropdown === this.orTransactionTransfer.NEXT_RESPONSIBLE_PARTY[0]) {
      dropdownSelector = this.orTransactionTransfer.NEXT_RESPONSIBLE_PARTY[1];
      dropdownLogicalName =
        this.orTransactionTransfer.NEXT_RESPONSIBLE_PARTY[0];
    } else if (
      dropdown === this.orTransactionTransfer.TRANSFER_TRANSACTION_CODE[0]
    ) {
      dropdownSelector =
        this.orTransactionTransfer.TRANSFER_TRANSACTION_CODE[1];
      dropdownLogicalName =
        this.orTransactionTransfer.TRANSFER_TRANSACTION_CODE[0];
    }
    const value = selectorFactory.getDropdownValues(valueToSelect);
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(dropdownSelector, dropdownLogicalName);
    cy.cClick(value, value);
  }

  /**
   * @details - Enter data in transfers popup and post transaction
   * @param - transfers as enter the values in transfer popup
   * @API - API's are not available
   * @author Bindhu
   */
  transferPopupPostTransaction(transfers: Transfers) {
    const nextRespParty: ILocatorValue = {
      locator: this.orTransactionTransfer.NEXT_RESPONSIBLE_PARTY[1],
      value: transfers.NextResponsibleParty,
    };
    const transferTransactionCode: ILocatorValue = {
      locator: this.orTransactionTransfer.TRANSFER_TRANSACTION_CODE[1],
      value: transfers.TransferTransactionCode,
    };

    const locators = [nextRespParty, transferTransactionCode];
    locators.forEach((locatorObj) => {
      locatorObj.value &&
        cy.cSelectDropdown(locatorObj.locator, '', locatorObj.value);
    });
    this.clickDoneButton();
  }

  /**
   * @details - select option in context menu option in transactions
   * @param index as per number of transaction available
   * @param allocationCorrection as allocation amount
   * @API - API's are not available
   * @author Bindhu
   */
  enterCorrectionPopupDetails(
    index: number,
    allocationCorrection: AllocationCorrection
  ) {
    this.clickContextMenuOptionsItems(index, ContextMenu.correction);
    this.performAllocationCorrectionAndAmount(allocationCorrection);
    this.clickDoneInEditCorrectionPayment();
  }

  /**
   * @details - select option in context menu option in transactions
   * @param index as per number of transaction available
   * @param amount as parameters in the function
   * @API - API's are not available
   * @author Bindhu
   */
  viewEditCorrectionAmount(index: number, amount: string) {
    this.clickContextMenuOptionsItems(index, ContextMenu.view_edit);
    this.enterNewAllocationAmount(amount);
    this.clickPeriodAndBatchLabel();
    this.clickDoneButton();
  }

  /**
   * @details - Enter data in debit popup and post transaction
   * @param debits as values in debits popup
   * @param yesOrNo as select yes or no in transfer to next party
   * @API - API's are available - Implemented
   * @author Bindhu
   */
  debitPopupPostTransaction(debits: Debits, yesOrNo: YesOrNo = YesOrNo.no) {
    this.clickPeriodAndBatchLabel();

    const period: ILocatorValue = {
      locator: this.orTransactionDebitWriteOff.PERIOD[1],
      value: debits.Period,
    };
    const batch: ILocatorValue = {
      locator: this.orTransactionDebitWriteOff.BATCH[1],
      value: debits.Batch,
    };
    const transCode: ILocatorValue = {
      locator: this.orTransactionDebitWriteOff.DEBIT_TRANS_CODE[1],
      value: debits.DebitTransactionCode,
    };

    const locators = [period, batch, transCode];
    locators.forEach((locatorObj) => {
      locatorObj.value &&
        cy.cSelectDropdown(locatorObj.locator, '', locatorObj.value);
    });

    this.transactionDebitEnterDebitAmount(debits.DebitAmount!);
    this.enterDateOfTransaction(debits.TransactionDate);
    if(yesOrNo != YesOrNo.none)
    {
    this.transferToNextParty(yesOrNo);
    }
    this.clickDoneOnTransactionsPopup();
  }

  /**
   * @details - Enter data in payments popup from transaction
   * @param payments as values in payments popup
   * @API - API's are available - Implemented for click Done button
   * @author Bindhu
   */
  paymentsPopupTransaction(payments: Payments) {
    this.paymentsPopupPostTransaction(payments);
    this.clickDoneInPayment();
  }

  /**
   * @details - select CPT Code And Transaction For Charge
   * @param cpt as cpt code
   * @param optionSelected as charges in transaction
   * @API - API's are not available
   * @author Bindhu
   */
  selectCPTCodeAndTransactionForCharge(cpt: string, optionSelected: string) {
    this.sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
    faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
    this.selectCPTCode(cpt);
    this.selectTransactionForCharge(optionSelected);
  }

  /**
   * @details - Delete Multiple Transaction
   * @param - types as charges in transactions
   * @param - yesNo as yes or no in delete multiple transaction in pop
   * @API - API's not are available
   * @author Bindhu
   */
  deleteMultipleTransactions(types: string[], yesNo: YesOrNo) {
    types.forEach((transactionType) => {
      this.deleteChargesInTransaction(transactionType, yesNo);
    });
  }

  /**
   * @details - delete complete Charges In transaction
   * @param type as charges in transactions
   * @param yesNo as yes or no in delete pop
   * @API - API's are available - Implemented
   * @author Bindhu
   */
  deleteChargesInTransaction(type: string, yesNo: YesOrNo) {
    // Switching between tasks as rerendering still happening after using API wait is used
    this.sisOfficeDesktop.selectTaskInMyTasks(
      this.orSisOffice.MY_TASKS.CHARGE_ENTRY[0]
    );
    this.sisOfficeDesktop.selectTaskInMyTasks(
      this.orSisOffice.MY_TASKS.TRANSACTIONS[0]
    );
    cy.cGet(selectorFactory.getTransactionType(type))
      .parents(OR_TRANSACTION.TRANSACTION_DETAILS_DATA[1])
      .find(CoreCssClasses.Icon.loc_fa_chevron_circle)
      .each(($el) => {
        cy.wrap($el).click();
        cy.cClick(selectorFactory.getSpanText(ContextMenu.delete), '');
        this.clickYesOrNoInDeletePopUp(yesNo);
      });
  }

  /**
   * @details - click Done in edit correction payments popup
   * @API - API's are not available
   * @author Bindhu
   */
  clickDoneInEditCorrectionPayment() {
    cy.cClick(
      selectorFactory.getSpanText(this.orTransactionAllocation.DONE[0]),
      this.orTransactionAllocation.DONE[0]
    );
  }

  /**
   * @details - select Dropdown Allocation Correction PopUp and enter NewAllocation Amount
   * @param allocationCorrection as allocation amount
   * @API - API's are not available
   * @author Bindhu
   */
  performAllocationCorrectionAndAmount(
    allocationCorrection: AllocationCorrection
  ) {
    this.enterNewAllocationAmount(allocationCorrection.NewAllocationAmount!);
    this.selectDropdownAllocationCorrectionPopUp(
      this.orTransactionAllocation.CORRECTION_CODE[0],
      allocationCorrection.CorrectionCode!
    );
  }

  /**
   * @details - Selecting Case option in Face sheet Cases
   * @param CaseOption - Case Details/Transactions/Coding
   * @API - API's are available and Partially Implemented
   * @Author - Sai Swarup
   */
  faceSheetSelectCaseOption(CaseOption: string) {
    const interceptCollection =
      this.facesheetTransactionApis.interceptFaceheetInventory();
    if (CaseOption == FaceSheetOptions.INVENTORY) {
      cy.cIntercept(interceptCollection);
    }
    cy.cGet(this.orCharges.FACE_SHEET_CASE_DETAILS_BLOCK[1]).then(($val) => {
      const plusIconElement = $val.find(this.orCharges.PLUS_ICON[1]);
      const caseOptionElement = selectorFactory.getSpanText(CaseOption);

      if (plusIconElement.length > 0) {
        cy.cClick(this.orCharges.PLUS_ICON[1], this.orCharges.PLUS_ICON[0]);
      }
      cy.cClick(caseOptionElement, CaseOption);
    });

    if (CaseOption == FaceSheetOptions.INVENTORY) {
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - Verify Bill Sent to patient
   * @param index - index value of the charge
   * @param status - boolean, default true
   * @API - API's are not available
   * @author - Nikitan
   */
  verifyEmailSent(index: number, status = true) {
    const circleElement = selectorFactory.getBillChargedCircle(index);
    if (status) {
      cy.cHasAttribute(
        circleElement,
        this.orCharges.SYSTEM_BILLED_ICON[0],
        InvokeAttributes.class,
        confirmation.circle
      );
    } else {
      cy.cIsVisible(
        circleElement,
        OR_TRANSACTION.WAY_STAR_ICON[0],
        false,
        false
      );
    }
  }

  /**
   * @details -verify delete pop up in transaction facesheet
   * @param transactionType is Payment or write-off or Debit
   * @param message delete pop up warning messages for all transaction
   * @API - API's are not available
   * @author Azhar
   */
  verifyTransactionDeletePopUp(transactionType: string, message: string) {
    cy.cIncludeText(
      CoreCssClasses.Dialog.loc_dialog_title,
      ' ',
      transactionType
    );
    cy.cIsVisible(selectorFactory.getSpanText(message), message);
    cy.cIsVisible(selectorFactory.selectYesNo(YesOrNo.yes), YesOrNo.yes);
    cy.cIsVisible(selectorFactory.selectYesNo(YesOrNo.no), YesOrNo.no);
  }

  /**
   * @details -verify context menu options in transaction
   * @param index number passed as per number of context menu
   * @param text option inside the context menu
   * @param exist true or false
   * @API - API's are not available
   * @author Azhar
   */
  verifyTransactionContextMenuOptions(
    index: number,
    text: string,
    exist: boolean
  ) {
    const spanElement = selectorFactory.getSpanText(text);
    cy.cClick(selectorFactory.transactionContextMenu(index), '');
    if (exist) {
      cy.cIsVisible(spanElement, text);
    } else {
      cy.cNotExist(spanElement, text);
    }
    cy.cClick(selectorFactory.transactionContextMenu(index), '');
  }

  /**
   * @details - verify Edit Debit pop-up details
   * @param text as to verify span context
   * @API - API's are not available
   * @author Azhar
   */
  verifyEditDebitPopup(text: string) {
    cy.cIsVisible(selectorFactory.getDialogEditDebitPopUp(text), text);
  }

  /**
   * @details -Select the main charge context menu and select option
   * @param index  as parameter passed based on number context menu
   * @param option as Edit in context menu of transaction
   * @API - API's are not available
   * @author Azhar
   */
  clickChargeContextMenuOption(index: number, option: string[]) {
    cy.cClick(selectorFactory.chargeContextMenu(index), '');
    cy.cClick(option[1], option[0], false, true);
  }

  /**
   * @details - Verify transfer to next party is enabled or disabled
   * @param state - State of the button based on class value, ex: ng-untouched for disable
   * @API - API's are not available
   * @author Azhar
   */
  verifyTransferToNextPartyState(state: string) {
    cy.cHasAttribute(
      CommonUtils.concatenate(
        OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.TRANSFER_TO_NEXT_PARTY[1],
        ' ',
        CoreCssClasses.Button.loc_p_selectbutton_tag
      ),
      OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.TRANSFER_TO_NEXT_PARTY[0],
      InvokeAttributes.class,
      state
    );
  }

  /**
   * @details - To verify the debit pop up header
   * @param option pass the header name to verify
   * @API - API's are not available
   * @author Azhar
   */
  verifyEditDebitHeader(option: string) {
    cy.cIsVisible(selectorFactory.getH3Text(option), option);
  }
}
