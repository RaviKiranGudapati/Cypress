import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class FacesheetCasesApis {
  /**
   * @details - To select the Transaction option from Facesheet
   * @author - Praveen
   */

  interceptTransactionsCaseOptionsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'GetCaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_estimate_params,
        'PatientEstimateParams',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_perform_procedures,
        'GetPerformProcedures',
        200
      ),
    ];
  }

  /**
   * @details - After selecting case details in facesheet
   * @author - Arushi
   */
  interceptFacesheetCaseDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_detail,
        'CaseDetail',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'CaseSummaryFacesheet',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_record,
        'PatientRecord',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Payer details in facesheet
   *  @author - Spoorthy
   */
  interceptFacesheetPayerDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Financial Clearance details in facesheet
   * @author - Spoorthy
   */
  interceptFacesheetFinancialApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_detail,
        'CaseDetail',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Forms and consent in facesheet
   * @author - Spoorthy
   */
  interceptFacesheetFormsAndConsentApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'PatientData',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Inventory in facesheet
   * @author - Spoorthy
   */
  interceptFacesheetInventoryApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'CaseInformation',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Coding in facesheet
   * @author - Spoorthy
   */
  interceptFacesheetCodingApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_detail,
        'CaseDetail',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Charge entry in facesheet
   * @author - Spoorthy
   */
  interceptFacesheetChargeEntryApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_insurances,
        'PatientInsurances',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_detail,
        'CaseDetail',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'CaseInformation',
        200
      ),
    ];
  }

  /**
   * @details - API Calls on click of Notes button
   * @author - Praveen
   */
  interceptFacesheetNotesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
    ];
  }

  /**
   * @details - API Calls on click  of Done button in Notes popup.
   * @author - Praveen
   */
  interceptFacesheetSaveNotesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_save_patient_notes,
        'PatientNotes',
        200
      ),
    ];
  }

  /**
   * @details - API Calls on click  of preview button in Print popup.
   * @author - Praveen
   */
  interceptPreviewApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.preview_option_reports,
        'Preview',
        200
      ),
    ];
  }

  /**
   * @details - API Calls on click  of preview button in Print popup.
   * @author - Praveen
   */
  interceptPreviewPatientLabelApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.patient_labels_data,
        'PatientLabels',
        200
      ),
    ];
  }
}
