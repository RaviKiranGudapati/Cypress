import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

export class FacesheetTransactionsApis {
  /**
    @details - This method intercepts the Debit/transactional API and returns an array of ApiEndpoints
    that includes the necessary information to select the Debit icon.
    @returns {ApiEndpoint[]} - An array of ApiEndpoints that includes information about the HTTP request method,
    the endpoint URL, the responsible party ID, and the expected HTTP response status code.
    @author Spoorthy
  */
  interceptDebitTransactionalApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'PeriodBatch',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_responsible_party,
        'ResponsibleParty',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the Transfer/transactional API and returns an array of ApiEndpoints
    that includes the necessary information to select the Transfer icon.
    @returns {ApiEndpoint[]} - An array of ApiEndpoints that includes information about the HTTP request method,
    the endpoint URL, the responsible party ID, and the expected HTTP response status code.
    @author Spoorthy
  */
  interceptTransferTransactionalApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_responsible_party,
        'ResponsibleParty',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'PeriodBatch',
        200
      ),
    ];
  }

  /**
    @details - After clicking on done button in payment popup
    @author Spoorthy
  */
  interceptDoneTransactionApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'CaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.unassigned_payment,
        'UnassignedPayment',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.case_to_charge_get,
        'Charge',
        200
      ),
    ];
  }

  /**
   * @details -  Api call for claim status button.
   * @author - Praveen
   */
  interceptClaimStatusApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_insurance_billing_history,
        'InsuranceBillingHistory',
        200
      ),
    ];
  }

  /**
   * @details -  Api call for click on the selected billed checkbox
   * @author - Praveen
   */
  interceptBilledCheckboxApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.charge_unbill,
        'ChargeUnbill',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.updated_case_status,
        'UpdateCaseStatus',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'CaseInformation',
        200
      ),
    ];
  }

  /**
   * @details -  Api for context menu view/edit Payment Details
   * @author - Madhu Kiran
   */
  interceptContextViewEditPaymentDetails(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_unassigned_payment_Information,
        'GetUnassignedPaymentInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_level_responsible_Parties,
        'GetCaseLevelResponsibleParties',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_default_payment_transaction_code_by_responsible_party_id,
        'TransactionCode',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_write_off_default_codes_by_responsible_party_id,
        'GetWriteOffDefaultCodesByResponsiblePartyId',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPatientInsurancesByPatientId',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_transaction_responsible_party_by_id,
        'GetTransactionResponsiblePartyById',
        200
      ),
    ];
  }

  /**
   * @details -  Api call for click on view/edit WriteOff and Debit
   * @author -  Madhu Kiran
   */
  interceptViewEditWriteOffAndDebit(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the payment transactional API and selects the payment icon.
    It returns an array of API endpoints to be used by the intercepting function.
    @returns {Array} - An array of API endpoints containing the HTTP method, endpoint URL, endpoint name, and expected HTTP status code.
    @author Praveen
  */
  interceptPaymentTransactionalApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_unassigned_payment_Information,
        'UnassignedPayment',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_level_responsible_Parties,
        'ResponsibleParty',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_write_off_default_codes_by_responsible_party_id,
        'WriteOffTransactionCode',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_default_payment_transaction_code_by_responsible_party_id,
        'PaymentTransactionCode',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'PatientInsurances',
        200
      ),
    ];
  }

  /**
    @details - This method intercepts the writeoff/transactional API and returns an array of ApiEndpoints
    that includes the necessary information to select the writeoff icon.
    @returns {ApiEndpoint[]} - An array of ApiEndpoints that includes information about the HTTP request method,
    the endpoint URL, the responsible party ID, and the expected HTTP response status code.
    @author Praveen
  */
  interceptWriteoffTransactionalApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_responsible_party,
        'GetResponsibleParty',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_write_off_default_codes_by_responsible_party_id,
        'WriteOffDefaultCodes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
    ];
  }

  /**
   * @details -  Api call for click on delete Pop-up in Transaction
   * @author -  Bindhu
   */
  interceptDeletionPopup() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.delete,
        SubRoutes.delete_transaction_yes,
        'DeleteTransaction',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details -  Api call for click on done button in edit correction Pop-up in Transaction
   * @author -  Bindhu
   */
  interceptEditCorrectionDoneButton() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.delete_transaction_yes,
        'DeleteTransaction',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details -  Api call after selecting inventory in facesheet
   * @author - Arushi
   */
  interceptFaceheetInventory() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'PatientData',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_summary,
        'CaseSummary',
        200
      ),
    ];
    return endpoints;
  }
}
