import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class FacesheetChargeEntryApis {
  /**
   * @details -  This method intercepts the add procedure Api search in procedure(CPT) input field, after clicking on add procedure button in facesheet charge entry
   * @author - Harsh Ranjan
   */
  interceptAddProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule,
        'FeeSchedule',
        200
      ),
    ];
  }

  /**
   * @details - This method intercepts the add procedure button  Api in order to click on add procedure button in facesheet charge entry
   * @author - Harsh Ranjan
   */
  interceptAddProcedureButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.record_header,
        'RecordHeader',
        200
      ),
    ];
  }

  /**
   * @details - This method intercepts the add procedure  Api in order to  search input field by clicking on add procedure button in facesheet charge entry
   * @author - Harsh Ranjan
   */
  interceptSelectProcedureButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
   * @details - This method intercepts the search Supply button Api  in order to click and searching the supplieson search supply input field.
   * @author - Harsh Ranjan
   */
  interceptSearchSupplyButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_inventory,
        'Inventory',
        200
      ),
    ];
  }

  /**
   * @details - API Collection after selecting collpase in the facesheet chargeEntry
   */
  interceptSavePerformedProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_save_procedure,
        'SavePerformedProcedure',
        200
      ),
    ];
  }

  /**
   * @details - API Collection after clicking on auto sort button in facesheet charge entry
   * @author - Spoorthy
   *
   */
  interceptAutoSortApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.process_contract_logic,
        'ContractLogic',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.charge_entry_auto_sort,
        'ChargeAuto',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.auto_sort_performed_case,
        'AutoSortPerformed',
        200
      ),
    ];
  }

  /**
   * @details - API Collection for drag and drop in facesheet charge entry
   * @author - Rakesh Donakonda
   */
  interceptDragAndDropApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'EvaluateDiscount',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.charge_entry_auto_sort,
        'ChargeEntryAutoSort',
        200
      ),
    ];
  }

  /**
   * @details - API collection for update button in facesheet charge entry.
   * @author - Rakesh Donakonda
   */
  interceptUpdateBtnApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_save_procedure,
        'GetSaveProcedure',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'GetCaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPeriodBatch',
        200
      ),
    ];
  }
}
