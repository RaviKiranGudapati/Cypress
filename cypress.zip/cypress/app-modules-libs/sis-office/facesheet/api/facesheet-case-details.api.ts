import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class FacesheetCaseDetailsApis {
  /**
   * @details -  Api collection after clicking update button in faceSheet Case details
   */
  interceptUpdateButtonCaseDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_case_detail,
        'CaseDetailUpdate',
        200
      ),
    ];
  }

  /**
   * @details - Api collection to clear operating room
   */
  interceptClearOperatingRoomApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_case_conflicts_minimal,
        'CaseConflicts',
        200
      ),
    ];
  }
}
