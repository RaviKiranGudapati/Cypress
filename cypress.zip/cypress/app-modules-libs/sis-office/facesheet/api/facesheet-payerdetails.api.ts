import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class FacesheetPayerDetailsApis {
  /**
   * @details - Api collection after clicking update button in faceSheet payer details
   * @author - Praveen
   */
  interceptUpdateButtonPayerDetailsApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_billing_detail,
        'BillingDetail',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_data_get,
        'GetPatient',
        200
      ),
    ];
  }
}
