import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class RevenueCycleManagementApis {
  /**
   * @details - Intercept for clicking on the patient in row grid in RCM tracker
   * @author - Nikitan
   */
  interceptForSelectPatientInRow(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'Notes',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on Allocate button from context menu options
   * @author - Nikitan
   */
  interceptForClickOnAllocate(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'PeriodBatch',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for select responsible party
   * @author - Rakesh Donakonda
   */
  interceptSelectResponsiblePartyApi() {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.rcm_tracker_details,
        'RcmTrackerDetails',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for getting Billing history
   * @author - Nikitan
   */
  interceptForBillingHistory(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.patient_statements_config,
        'Config',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on Bill Selected Insurance Charge button in Billing History
   * @author - Nikitan
   */
  interceptForBillSelectedInsuranceCharge(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.bill_insurance_carrier,
        'BillInsurance',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for getting insurance charges in RCM tracker
   * @author - Nikitan
   */
  interceptForRCMChargeInsurance(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.rcm_charge_for_insurance,
        'RCMCharge',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for Bill patient statement before selecting Yes or No
   * @author - Nikitan
   */
  interceptForBillPatientStatementYesOrNo(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.patient_statement_details,
        'BillPatient',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for Select patient row RCM tracker
   * @author - Rakesh Donakonda
   */
  interceptSelectPatientRowInRcmApi() {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'GetCaseInfo',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_unacknowledged_count,
        'GetUnacknowledgedCount',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_rcm_tracker_insurance_responsible_party,
        'GetInsuranceResponsibleParty',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_procedure,
        'GetCaseProcedure',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.transaction_code,
        'GetTransactionCode',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_fee_schedules,
        'GetFeeSchedule',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_image,
        'GetPatientImage',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on Done button in allocation dialog window
   * @author - Nikitan
   */
  interceptForAllocationDone(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.rcm_insurance_charges,
        'RCMInsuranceCharges',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on Print Selected Insurance Charge from Billing history
   * @author - Nikitan
   */
  interceptForPrintInsuranceCharge(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.print_insurance_charge,
        'PrintInsurance',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on Print Selected Patient Statements from Billing history
   * @author - Nikitan
   */
  interceptForPrintPatientStatement(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_reports,
        'PrintPatientStatement',
        200
      ),
    ];
  }

  /**
   * @details - Api collection on clicking done after selecting rcm status in rcm summary
   * @author - Rakesh Donakonda
   */
  interceptClickDoneButton() {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.update_rcm_charges,
        'UpdateRcmCharges',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_unacknowledged_count,
        'GetUnacknowledgedCount',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.rcm_tracker_details,
        'RcmTrackerDetails',
        200
      ),
    ];
  }

  /**
   * @details - Intercept for clicking on Clear Filters and Refresh button
   * @author - Ravi Kiran
   */
  interceptForClearRefreshFilters(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.rcm_tracker_data,
        'RcmTracker',
        200
      ),
    ];
  }

  /**
   * @details -  Intercept after entering Allocate UP amount to a charge from UP amount payer
   * @author - chandrika
   */
  interceptAllocateUpAmount(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.save_transactions,
        'Transaction',
        200
      ),
    ];
  }

  /**
   * @details - intercept collection for downloaded file
   * @author - Rakesh Donakonda
   */
  interceptVerifyDownloadFileApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.reports_ssrs_reports,
        'ReportsSsrsReports',
        200
      ),
    ];
  }
}
