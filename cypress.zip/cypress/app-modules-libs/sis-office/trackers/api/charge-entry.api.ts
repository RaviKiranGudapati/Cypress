import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class ChargeEntryApis {
  /**
   * @details - Intercept for Selecting Patient
   * @author - Madhu Kiran
   */
  interceptSelectingPatient(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'GetCaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_total_balance_due_by_case_summary_Id,
        'GetTotalBalanceDueByCaseSummaryId',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_transaction_code_list_by_type,
        'GetTransactionCodeListByType',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_revenue_code_list,
        'GetRevenueCodeList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_source_of_revenueList,
        'GetSourceOfRevenueList',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_modifiers,
        'GetModifiers',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'GetPatientNotes',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient,
        'GetPatient',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_perform_procedures,
        'GetPerformProcedures',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_period_batch,
        'GetPeriodBatch',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurances_by_patient_id,
        'GetPatientInsurancesByPatientId',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Ready for bill yes and Done button in Charge Entry page
   * @author - Harsh Ranjan
   */
  interceptReadyForBillYesDoneButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_case_summary,
        'CaseSummary',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.charge_entry_get_tracker_data,
        'ChargeEntryTracker',
        200
      ),
    ];
  }

  /**
   * @details - After selecting Redy for bill no and Done button in Charge Entry page
   * @author - Harsh Ranjan
   */
  interceptReadyForBillNoDoneButtonApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.charge_entry_get_tracker_data,
        'ChargeEntryTracker',
        200
      ),
    ];
  }

  /**
   * @details - After clicking on primary insurance dropdown cross icon in Charge Entry page
   * @author - Harsh Ranjan
   */
  interceptPrimaryInsuranceCrossIconApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
   * @details - After adding new procedure when we are clicking on minus icon we are getting this call
   * @author - Harsh Ranjan
   */
  interceptMinusIconApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_save_procedure,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
   * @details -  This method intercepts the add procedure Api search in procedure(CPT) input field, after clicking on add procedure button in charge entry
   * @author - Harsh Ranjan
   */
  interceptAddProcedureApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_fee_schedule,
        'FeeSchedule',
        200
      ),
    ];
  }

  /**
   * @details - This method intercepts the add procedure  Api in order to  search input field by clicking on add procedure button in charge entry
   * @author - Harsh Ranjan
   */
  interceptSelectProcedureSelfPayApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
    ];
  }

  /**
   * @details - Select supplies from search input field by clicking on add procedure button in charge-entry tracker
   * @author - Harsh Ranjan
   */
  interceptSearchAndSelectSupplyApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_inventory,
        'SelectSupplies',
        200
      ),
    ];
  }

  /**
   * @details - Select Procedure from search input field by clicking on add procedure button in charge-entry tracker
   * @author - Harsh Ranjan
   */
  interceptSearchDiagnosisCodeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_icd_code_classifications,
        'SearchIcdCodes',
        200
      ),
    ];
  }

  /**
   * @details - Select Procedure from search input field by clicking on add Batch in charge-entry tracker
   * @author - Harsh Ranjan
   */
  interceptAddBAtchApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insert_batch,
        'InsertBatch',
        200
      ),
    ];
  }
  /**
   * @details - The api call once after collapsed the update/add procedures in charge entry tracker
   * @author - Praveen
   */
  interceptCollapseChargeApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_save_procedure,
        'SaveProcedure',
        200
      ),
    ];
  }

  /**
   * @details - The api call happens on clicking Yes on the Delete charge Popup
   * @author - Prashant
   */
  interceptClickYesInDeleteChargePopupApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.delete,
        SubRoutes.delete_performed_case_procedure,
        'DeletePerformedCaseProcedure',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_case_information,
        'GetCaseInformation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_insurance_contract_evaluation,
        'InsuranceContractEvaluation',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_insurance_by_id,
        'Insurance',
        200
      ),
    ];
  }

  /**
   * @details - API Collection after clicking on auto sort button in charge entry Page
   * @author - Prashant Raman
   */
  interceptAutoSortApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.process_contract_logic,
        'ContractLogic',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.charge_entry_auto_sort,
        'ChargeAuto',
        200
      ),
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.auto_sort_performed_case,
        'AutoSortPerformed',
        200
      ),
    ];
  }

  /**
   * @details - API Calls on click of Notes button
   * @author - Prashant Raman
   */
  interceptChargeEntryNotesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient_notes,
        'PatientNotes',
        200
      ),
    ];
  }

  /**
   * @details - API Calls on click  of Done button in Notes popup.
   * @author - Prashant Raman
   */
  interceptChargeEntrySaveNotesApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_save_patient_notes,
        'PatientNotes',
        200
      ),
    ];
  }

  /**
   * @details - This Api calls happen when we click on Done button in Additional claim info popup
   * @author - Prashant Raman
   */
  interceptAdditionalClaimInfoDoneBtnApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.post_upsert_additional_claim_info_with_performed_case_id,
        'UpsertAdditionalClaimInfo',
        200
      ),
    ];
  }

  /**
    @details - The Api calls happen When we click on Additional claim information button after selecting a procedure in charge Entry Page.
    @author - Prashant Raman
  */
  interceptClickAdditionalClaimInformationBtnApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_additional_claim_info_by_proc_case_id,
        'AdditionalClaimInfo',
        200
      ),
    ];
  }
}
