import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class RemittancePostingTrackerApis {
  /**
   * @details - Api collection after selecting Manual Remittance Posting Button
   * @author Madhu Kiran
   */
  interceptForManualRemittancePostingButton(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_period_batch_false,
        'GetAllPeriodBatch',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_transaction_static_lists,
        'GetTransactionStaticLists',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after adding Received from
   * @author Madhu Kiran
   */
  interceptForReceivedFrom(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_remittance,
        'Remittance',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for getting patients after clicking Start Dos
   * @author Madhu Kiran
   */
  interceptForStartDos(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.get_bulk_payment,
        'GetChargesForBulk',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for transactions dialog after selecting the ellipsis icon
   * @author Nikitan
   */
  interceptForTransactionWindow(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.unassigned_payment,
        'UnassignedPayment',
        200
      ),
    ];
  }

  /**
   * @details - Api collection after allocating UP amount and click on done
   * @author Nikitan
   */
  interceptForUPAmountAllocated(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_period_batch_false,
        'GetAllPeriodBatch',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for clicking ellipse based on cpt
   * @author Spoorthy
   */
  interceptClickOnEllipsis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_all_case_procedure,
        'CaseProcedure',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.unassigned_payment,
        'Payment',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_facesheetcases_chargeItems,
        'ChargeItems',
        200
      ),
    ];
  }
}
