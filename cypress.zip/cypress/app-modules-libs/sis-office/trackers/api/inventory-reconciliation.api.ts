import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class InventoryReconciliationApi {
  /**
   * @details - Api collection for select patient.
   */
  interceptSelectPatientApis(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.get_patient,
        'GetPatient',
        200
      ),
    ];
  }

  /**
   * @details - Api collection for select depletion and done.
   *  @author - Spoorthy
   */
  interceptSelectDepletionDoneApis() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.inventory_depletion_stock,
        'UpsertStockDepletion',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - Api collection for add supply
   *  @author - Spoorthy
   */
  interceptAddSupplyApi() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.inventory_name_get,
        'SearchSupplyInventoryName',
        200
      ),
    ];
    return endpoints;
  }

  /**
   * @details - Api collection for select depletion and update
   *  @author - Spoorthy
   */
  interceptSelectDepletionUpdateApis() {
    const endpoints: ApiEndpoint[] = [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.inventory_depletion_stock,
        'UpsertStockDepletion',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.inventory_depletion,
        'Depletion',
        200
      ),
    ];
    return endpoints;
  }
}
