import { ApiEndpoint } from '../../../../support/common-core-libs/framework/api-endpoint';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../support/common-core-libs/application/constants/sub-routes.constants';

export class InsuranceBillingApis {
  /**
   * @details - Api collection for bill selected payers button
   * @author - Spoorthy
   */
  interceptBillSelectedPayersApi(): ApiEndpoint[] {
    return [
      new ApiEndpoint(
        WaitMethods.post,
        SubRoutes.bill_insurance_carrier,
        'BillInsurance',
        200
      ),
      new ApiEndpoint(
        WaitMethods.get,
        SubRoutes.insurance_billing_tracker,
        'InsuranceTracker',
        200
      ),
    ];
  }
}
