import {
  Application,
  CommonClassAttributes,
  CommonGetLocators,
  InvokeAttributes,
  InvokeMethods,
  ShouldMethods,
  SortOrder,
  TriggerAttributes,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { Charges } from '../../../test-data-models/sis-office/trackers/combined-coding.model';
import { UnAssignedAllocation } from '../../../test-data-models/sis-office/facesheet/facesheet-ledger.model';
import {
  ChargeTransaction,
  ManualRemittancePosting,
  TransactionDetails,
} from '../../../test-data-models/sis-office/trackers/remittance-posting.model';
import { PatientCase } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_REMITTANCE_POSTING } from './or/remittance-posting.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_FACESHEET_LEDGER_TAB } from '../facesheet/or/facesheet-ledger.or';

import LedgerTabFaceSheet from '../facesheet/facesheet-ledger';
import {
  defaultWriteOffGroupCode,
  defaultWriteOffReasonCode,
} from '../../shared/application-settings/constants/enterprise-configuration.const';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';
import { RemittancePostingTrackerApis } from './api/remittance-posting.api';
import { HelperText } from '../../shared/application-settings/enums/enterprise-configuration.enum';
import {
  dateFormat,
  selectItem,
  paymentMethod,
  transactionGridHeaders,
} from './constants/remittance-posting.const';

/* instance variables */
const sisOfficeDesktopApis = new SisOfficeDesktopApis();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();

const sisOfficeDesktop = new SISOfficeDesktop();
const remittancePostingTrackerApis = new RemittancePostingTrackerApis();

/* const values */
const checkAmountInputMaxAndMinValue = ['9,999,999.00', '0.01'];

/* Used pop method to remove last element since that value is not present in dropdown values*/
defaultWriteOffGroupCode.pop();
defaultWriteOffReasonCode.pop();

/**
 * Class for RemittancePosting
 */
export class RemittancePosting {
  /**
   * @details - Select Remittance posting tracker from Trackers list
   * @API - API's are available and implemented completely
   * @author Nikitan
   */
  clickOnRemittancePostingTracker() {
    const interceptCollection =
      sisOfficeDesktopApis.interceptRemittancePostingTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectTracker(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REMITTANCE_POSTING[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select Manual Remittance Posting Button
   * @API - API's are available and implemented completely
   * @author Nikitan
   */
  selectManualRemittancePostingButton() {
    const interceptCollection =
      remittancePostingTrackerApis.interceptForManualRemittancePostingButton();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_REMITTANCE_POSTING.MANUAL_REMITTANCE_POSTING[1],
      OR_REMITTANCE_POSTING.MANUAL_REMITTANCE_POSTING[0]
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on Calender Date
   * @param calendarOr passed to click on particular Calendar, ex: START_DOS, END_DOS
   * @API - API's are not available
   * @author Nikitan
   */
  clickOnCalender(calendarOr: string) {
    cy.cClick(calendarOr, OR_REMITTANCE_POSTING.START_DOS[0]);
  }

  /**
   * @details - Click start date of service calendar in remittance posting tracker and select current date
   * @API - Apis are not available
   * @author Madhu Kiran
   */
  selectDOSStartDate() {
    cy.cGet(OR_REMITTANCE_POSTING.START_DOS[1])
      .scrollIntoView()
      .invoke(InvokeMethods.show)
      .click();
    cy.cClick(
      OR_REMITTANCE_POSTING.CURRENT_DATE[1],
      OR_REMITTANCE_POSTING.CURRENT_DATE[0],
      false,
      true
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Click end date of service calendar in remittance posting tracker and select current date
   * @API - Apis are not available
   * @author Madhu Kiran
   */
  selectCurrentDateInEndDateCalendar() {
    cy.cGet(OR_REMITTANCE_POSTING.END_DOS[1])
      .scrollIntoView()
      .invoke(InvokeMethods.show)
      .click();
    cy.cClick(
      OR_REMITTANCE_POSTING.CURRENT_DATE[1],
      OR_REMITTANCE_POSTING.CURRENT_DATE[0],
      false,
      true
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - Select value from received from dropdown
   * @param value as Param to select Insurance in received from drop down
   * @API - Apis are available Implemented Completely
   * @author Madhu Kiran
   */
  selectValueFromReceivedFromDropdown(value: string) {
    const interceptCollection =
      remittancePostingTrackerApis.interceptForReceivedFrom();
    cy.cIntercept(interceptCollection);
    cy.cClick(
      OR_REMITTANCE_POSTING.RECEIVED_FROM[1],
      OR_REMITTANCE_POSTING.RECEIVED_FROM[0]
    ).then(() => {
      cy.cType(
        OR_REMITTANCE_POSTING.RECEIVED_FROM_SEARCH[1],
        OR_REMITTANCE_POSTING.RECEIVED_FROM[0],
        value,
        false,
        false,
        { force: true }
      );
    });
    cy.cClick(
      selectorFactory.searchAndSelectItemFromList(value),
      value,
      false,
      false,
      { force: true }
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - selecting period in Manual Remittance Posting
   * @param period passed to select period
   * @API - Apis are not available
   * @author Madhu Kiran
   */
  selectPeriod(period: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.PERIOD[1],
      OR_REMITTANCE_POSTING.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(period),
      OR_REMITTANCE_POSTING.PERIOD[0]
    );
  }

  /**
   * @details - selecting batch in Manual Remittance Posting
   * @param batch passed to select batch
   * @API - Apis are not available
   * @author Madhu Kiran
   */
  selectBatch(batch: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.BATCH[1],
      OR_REMITTANCE_POSTING.BATCH[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(batch),
      OR_REMITTANCE_POSTING.BATCH[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - selecting period and batch in Manual Remittance Posting
   * @param chargesInfo passed to select period and batch values
   * @API - Apis are not available
   * @author Madhu Kiran
   */
  selectPeriodAndBatch(chargesInfo: Charges) {
    this.selectPeriod(chargesInfo.Period);
    this.selectBatch(chargesInfo.Batch);
  }

  /**
   * @details - To enter Check Amount
   * @param amount passed to enter amount in check ammount field
   * @API - Apis are not available
   * @author Madhu Kiran
   */
  enterCheckAmount(amount: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cType(
      OR_REMITTANCE_POSTING.CHECK_AMOUNT[1],
      OR_REMITTANCE_POSTING.CHECK_AMOUNT[0],
      amount
    );
  }

  /**
   * @details - selecting Icon Ellipsis based on cpt
   * @param cpt passed to select Ellipsis according to cpt number
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  clickOnEllipsisBasedOnCpt(cpt: string) {
    cy.cClick(
      selectorFactory.getIconEllipsis(cpt),
      OR_REMITTANCE_POSTING.ICON_ELLIPSIS[0],
      false,
      true,
      { force: true }
    );
  }

  /**
   * @details - Click on down active in unassigned payment
   * @Api - API's are not available
   * @author Madhu Kiran
   */
  clickOnDownActive() {
    cy.cClick(
      OR_REMITTANCE_POSTING.DOWN_ACTIVE[1],
      OR_REMITTANCE_POSTING.DOWN_ACTIVE[0]
    );
  }

  /**
   * @details - Click on done button in Unassigned Payment
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  clickOnDoneButtonInUnassignedPayment() {
    cy.cClick(
      OR_REMITTANCE_POSTING.UNASSIGNED_PAVEMENT_DONE[1],
      OR_REMITTANCE_POSTING.UNASSIGNED_PAVEMENT_DONE[0]
    );
  }

  /**
   * @details - Click on done button in Manual Remittance Posting Details
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  clickOnDoneButton() {
    cy.cClick(
      OR_REMITTANCE_POSTING.REMITTANCE_POSTING_DETAILS_DONE[1],
      OR_REMITTANCE_POSTING.REMITTANCE_POSTING_DETAILS_DONE[0]
    );
  }

  /**
   * @detail - To click the post eob is toggled as - Yes/No
   * @param flag - true/false needs to be passed as per post eob(true if post eob is yes and false if post eob is no)
   * @Api -Api are not avaliable
   * @author Spoorthy
   */
  clickOnPostEobToggleAndDone(flag: boolean = false) {
    const yesOrNo = flag ? YesOrNo.yes : YesOrNo.no;
    cy.cClick(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.POST_EOB[1],
        selectorFactory.getSpanText(yesOrNo)
      ),
      yesOrNo
    );
    sisOfficeDesktop.clickDoneButton();
  }

  /**
   * @details - To click on post in confirm Remittance Post
   * @Api - API's are available not Implemented
   * @author Madhu Kiran
   */
  unassignedPaymentAllocation(allocation: UnAssignedAllocation, rowNo: string) {
    ledgerTabFaceSheet.enterAllocationAmount(
      allocation.AmountAllocation,
      rowNo
    );
    ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
      OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0],
      allocation.TransactionCode
    );
    this.clickOnDoneButtonInUnassignedPayment();
  }

  /**
   * @details - To select Yes Or No in post EOB
   * @param status to select EOB status Yes or No
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  clickOnPostEobYesOrNoAndDone(status: string) {
    cy.cClick(
      selectorFactory.getPostEobYesOrNoAndDone(status),
      OR_REMITTANCE_POSTING.POSTEOB_STATUS[0]
    );
  }

  /**
   * @details - To click on post in conform Remittance Post
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  clickOnPostRemittancePost() {
    cy.cClick(OR_REMITTANCE_POSTING.POST[1], OR_REMITTANCE_POSTING.POST[0]);
  }

  /**
   * @details - To verify Start Date Calender
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyStartDate() {
    cy.cIsVisible(
      OR_REMITTANCE_POSTING.START_DOS[1],
      OR_REMITTANCE_POSTING.START_DOS[0]
    );
  }

  /**
   * @detail - To select Transferto toggle Yes/No  button in Manual remittance posting
   * @param flag - true/false needs to be passed as transfer to(if transfer to is no, pass false else pass true )
   * @Api -Api are not avaliable
   * @Author - Spoorthy
   */
  selectGenerateBill(flag: boolean = false) {
    const yesOrNo = flag ? YesOrNo.yes : YesOrNo.no;
    cy.cClick(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.GENERATE_BILL[1],
        selectorFactory.getSpanText(yesOrNo)
      ),
      yesOrNo
    );
  }

  /**
   * @details - To verify End Date Calender
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyEndDate() {
    cy.cIsVisible(
      OR_REMITTANCE_POSTING.END_DOS[1],
      OR_REMITTANCE_POSTING.END_DOS[0]
    );
  }

  /**
   * @detail - To click the generate bill is toggled as - Yes/No
   * @param flag - true/false needs to be passed as per Generate bill(if Generate bill is no, pass false else pass true )
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyStartDateFormat() {
    cy.cHasAttribute(
      CommonUtils.concatenate(OR_REMITTANCE_POSTING.START_DATE_FORMAT[1]),
      OR_REMITTANCE_POSTING.START_DATE_FORMAT[0],
      CommonClassAttributes.placeholder,
      dateFormat
    );
  }

  /**
   * @detail - To verify Transaction details screen header
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransactionDetailsScreen() {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_HEADER[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_HEADER[0],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_HEADER[0]
    );
  }

  /**
   * @detail - To verify Deductible field in payment/writeoff/debit/transfers popup
   * @param -value is passed to verify the deductible field value
   * @Api - Api's are not available
   * @Author - Spoorthy
   */
  verifyDeductibleField(value: string) {
    cy.cHasValue(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.DEDUCTIBLE[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.DEDUCTIBLE[0],
      value
    );
  }

  /**
   * @detail - To verify coins field in payment/writeoff/debit/transfers popup
   * @param -value is passed to verify the coins value
   * @Api - Api's are not available
   * @Author - Spoorthy
   */
  verifyCoins(value: string) {
    cy.cHasValue(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.COINS[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.COINS[0],
      value
    );
  }

  /**
   * @detail - To verify copay in payment/writeoff/debit/transfers popup
   * @param -value is passed to verify the copay value
   * @Api - Api's are not available
   * @Author - Spoorthy
   */
  verifyCopay(value: string) {
    cy.cHasValue(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.COPAY[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.COPAY[0],
      value
    );
  }

  /**
   * @details - Verify End Date Format in case date of service
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyEndDateFormat() {
    cy.cHasAttribute(
      CommonUtils.concatenate(OR_REMITTANCE_POSTING.END_DATE_FORMAT[1]),
      OR_REMITTANCE_POSTING.END_DATE_FORMAT[0],
      CommonClassAttributes.placeholder,
      dateFormat
    );
  }

  /**
   * @detail - To verify Period in transaction details
   * @param-period to pass the period value
   * @Api - Api's are not available
   * @Author - Spoorthy
   */
  verifyPeriodInTransactionDetails(period: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.PERIOD[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.PERIOD[0],
      period
    );
  }

  /**
   * @details - Verify Case Date Of Service as Mandatory
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyCaseDateOfServiceAsMandatory() {
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.CASE_DATE_OF_SERVICE_MANDATORY[1],
      OR_REMITTANCE_POSTING.CASE_DATE_OF_SERVICE_MANDATORY[0],
      InvokeAttributes.class,
      InvokeAttributes.warning_asterisk
    );
  }

  /**
   * @details - verify batch in Transaction Details
   * @param batch to pass  data as the parameter
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyBatchInTransactionDetails(batch: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.BATCH[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.BATCH[0],
      batch
    );
  }

  /**
   * @details -  To verify Received From Drop Down Values
   * @param value to verify dropdown values of Received from
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyReceivedFromDropDownValues(value: string) {
    cy.cIncludeText(
      selectorFactory.getSpanText(value),
      OR_REMITTANCE_POSTING.RECEIVED_FROM[0],
      value
    );
  }

  /**
   * @details - verify Transfer to in Transaction Details
   * @param transfer-to pass the value
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransferTo(transfer: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSFER_TO[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSFER_TO[0],
      transfer
    );
  }

  /**
   * @details -  To  verify Method Of Payment as Default Value
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyMethodOfPaymentAsDefaultValue() {
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.METHOD_OF_PAYEMENT_VALUE[1],
      OR_REMITTANCE_POSTING.METHOD_OF_PAYEMENT_VALUE[0],
      CommonClassAttributes.placeholder,
      selectItem
    );
  }

  /**
   * @details - verify Method of payment in Transaction Details
   * @param payment -to verify method of payment
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyMethodOfPaymentRemittance(payment: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.METHOD_OF_PAYMENT[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.METHOD_OF_PAYMENT[0],
      payment
    );
  }

  /**
   * @details -  To verify Method Of Payment Drop Down Value
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyMethodOfPaymentDropDownValues() {
    cy.cClick(
      OR_REMITTANCE_POSTING.METHOD_OF_PAYMENT_DROPDOWN[1],
      OR_REMITTANCE_POSTING.METHOD_OF_PAYMENT_DROPDOWN[0]
    );
    paymentMethod.forEach((item) => {
      cy.cIsVisible(
        CommonUtils.concatenate(
          OR_REMITTANCE_POSTING.PAYMENT_METHOD_DROPDOWN_VALUE[1],
          ' ',
          selectorFactory.getSpanText(item)
        ),
        item
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.METHOD_OF_PAYMENT_DROPDOWN[1],
      OR_REMITTANCE_POSTING.METHOD_OF_PAYMENT_DROPDOWN[0]
    );
  }

  /**
   * @detail - To verify transfer in Transaction Details
   * @param value - To provide value
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransfer(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSFER[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSFER[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - To verify both maximum and minimum value of check ammount value
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyMaxAndMinValue() {
    checkAmountInputMaxAndMinValue.forEach((val) => {
      this.enterCheckAmount(val);
      cy.cClick(
        OR_REMITTANCE_POSTING.END_DOS[1],
        OR_REMITTANCE_POSTING.END_DOS[0]
      );
      this.verifyCheckAmountValue(val);
    });
  }

  /**
   * @details - Verifying check amount maximum value and Minimum value
   * @param value passed to verify ammount value
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyCheckAmountValue(value: string) {
    cy.cHasValue(
      OR_REMITTANCE_POSTING.CHECK_AMOUNT[1],
      OR_REMITTANCE_POSTING.CHECK_AMOUNT[0],
      value
    );
  }

  /**
   * @detail - To verify whether the Generate bill option is toggled as - Yes/No
   * @param value - To verify value as Yes or No
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyGenerateBill(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.GENERATE_BILL[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.GENERATE_BILL[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - To enter payment ID
   * @param id example:mbh@123 passed to enter Id
   * @API - API's are not available
   * @author Madhu Kiran
   */
  enterPaymentId(id: string) {
    cy.cType(
      OR_REMITTANCE_POSTING.PAYMENT_ID[1],
      OR_REMITTANCE_POSTING.PAYMENT_ID[0],
      id
    );
  }

  /**
   * @detail - To verify Transaction header
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransactionLabel() {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_TITLE[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_TITLE[0],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_TITLE[0]
    );
  }

  /**
   * @details -Click on allocate in ledger tab
   * @Api - API's are available - Not Yet Identified
   * @author MadhuKiran
   */
  clickOnAllocate() {
    cy.cClick(
      OR_FACESHEET_LEDGER_TAB.ALLOCATE[1],
      OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
    );
  }

  /**
   * @details - To verify payment Id value accepting alpha numeric values
   * @param id passed to verify entered Id value
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifypaymentIdValue(id: string) {
    cy.cHasValue(
      OR_REMITTANCE_POSTING.PAYMENT_ID[1],
      OR_REMITTANCE_POSTING.PAYMENT_ID[0],
      id
    );
  }

  /**
   * @details -verify the Transaction table in transaction details screen
   * @param - transactionHeader to verify the label in transaction
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransactionTableHeaders(transactionHeader: string[]) {
    cy.cGet(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_TITLE[1]
    ).each(($labels, index) => {
      expect($labels.text().replace(/\n/g, '').trim()).to.contain(
        transactionHeader[index]
      );
    });
  }

  /**
   * @details -verify the remittance history table
   * @param -  historyLabels to verify the labels in remittance history
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyRemittanceHistory(historyLabels: string[]) {
    cy.cGet(OR_REMITTANCE_POSTING.REMITTANCE_HISTORY[1]).each(
      ($labels, index) => {
        expect($labels.text().replace(/\n/g, '').trim()).to.contain(
          historyLabels[index]
        );
      }
    );
  }

  /**
   * @details - To click Hide defaults/Show defaults
   * @API - API's are not available
   * @author Madhu Kiran
   */
  clickOnDefaults() {
    cy.cClick(
      OR_REMITTANCE_POSTING.PANEL_ICON[1],
      OR_REMITTANCE_POSTING.PANEL_ICON[0]
    );
  }

  /**
   * @details - To verify both Hide Defaults and Show Defaults state
   * @param state passed both verify both Hide Defaults and Show Defaults
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyDefaults(state: string) {
    cy.cIsVisible(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.PANEL_DEFAULTS_HEADER[1],
        ' ',
        selectorFactory.getSpanText(state)
      ),
      OR_REMITTANCE_POSTING.PANEL_DEFAULTS_HEADER[0]
    );
  }

  /**
   * @details -verify the copy right in transaction details screen
   * @param -  copyRightValue as parameters in function
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyCopyRightTextInTransaction(copyRightValue: string) {
    cy.cGet(OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.CPTCDT_CODE[1]).each(
      ($copyRightText) => {
        expect($copyRightText.text().trim()).to.contains(copyRightValue);
      }
    );
  }

  /**
   * @details - To verify Period Dropdown values
   * @param period passed to verify active period
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyPeriodDropDownValues(period: string) {
    this.selectPeriod(period);
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.PERIOD_DROPDOWN[1],
      OR_REMITTANCE_POSTING.PERIOD_DROPDOWN[0],
      period
    );
  }

  /**
   * @details -verify the done button in transaction details screen
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyDoneButton() {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.DONE_BUTTON[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.DONE_BUTTON[0],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.DONE_BUTTON[0]
    );
  }

  /**
   * @details - To verify Batch Dropdown values
   * @param batch passed to verify active batch values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyBatchDropDownValues(batch: string) {
    this.selectBatch(batch);
    cy.cIncludeText(
      selectorFactory.getBatchValue(batch),
      OR_REMITTANCE_POSTING.BATCH[0],
      batch
    );
  }

  /**
   * @details -verify the payment,write-off amount in transaction details screen
   * @param- amounts to verify the payment/writeoff amount
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransactionAmounts(amounts: string[]) {
    amounts.forEach((amount, index) => {
      cy.cGet(selectorFactory.paymentInTransactionDetails(index)).should(
        ShouldMethods.contain,
        amount
      );
    });
  }

  /**
   * @details - Verify calenders Date Format of case Transaction date
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyDateFormatOfTransactionDate() {
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.TRANSACTION_DATE[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DATE[0],
      CommonClassAttributes.placeholder,
      dateFormat
    );
  }

  /**
   * @details - Verify Mandatory fields in Manual Remittance postong
   * @param fieldName passed to verify particular field is Mandatory
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyMandatoryFields(fieldName: string) {
    cy.cHasAttribute(
      CommonUtils.concatenate(
        selectorFactory.getLabelText(fieldName),
        ' ',
        CommonGetLocators.span
      ),
      OR_REMITTANCE_POSTING.CASE_DATE_OF_SERVICE_MANDATORY[0],
      InvokeAttributes.class,
      InvokeAttributes.warning_asterisk
    );
  }

  /**
   * @details -verify the DOS in transaction details screen
   * @param -  value is passed to verify the dos
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyDOSChargeDetails(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.DOS[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.DOS[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify Transaction Date as today date
   * @param date passed to verify today date in transaction date
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyTransactionDateAsTodayDate(date: string) {
    cy.cHasValue(
      OR_REMITTANCE_POSTING.TRANSACTION_DATE[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DATE[0],
      date
    );
  }

  /**
   * @details -verify the cpt in transaction details screen
   * @param -  value is passed to verify the cpt value
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyCPTChargeDetails(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.CPT_HCPS[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.CPT_HCPS[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify Transfer to toggle as Yes by dafault
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyTransferToDefaultAsYes() {
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.TRANFER_TO_YES[1],
      OR_REMITTANCE_POSTING.TRANFER_TO_YES[0],
      InvokeAttributes.aria_label,
      YesOrNo.yes
    );
  }

  /**
   * @details -verify Balance due in transaction details screen
   * @param -  value is passed to verify the Balance amount
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyBalanceChargeDetails(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.BALANCE_DUE[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.BALANCE_DUE[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify Generate Bill to toggle as Yes by dafault
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyGenerateBillDefaultAsYes() {
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.GENERATE_BILL_YES[1],
      OR_REMITTANCE_POSTING.GENERATE_BILL_YES[0],
      InvokeAttributes.aria_label,
      YesOrNo.yes
    );
  }

  /**
   * @details -verify Charge amount in transaction details screen
   * @param -  value is passed to verify the Charge amount
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyChargeAmountInCharge(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.CHARGE_AMOUNT[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.CHARGE_AMOUNT[0],
      value,
      false,
      true
    );
  }

  /**
   * @details -verify allowed amount in transaction details screen
   * @param - value is passed to verify the allowed amount
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyAllowedChargeDetails(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.ALLOWED_AMOUNT[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.ALLOWED_AMOUNT[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify writeoff1 Transaction code
   * @param writeOff passed to verify writeoff1 Transaction code
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyWriteoff1TransactionCode(writeOff: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.WRITEOFF_1_TRANSACTION_DROPDOWN_VALUE[1],
      OR_REMITTANCE_POSTING.WRITEOFF_1_TRANSACTION_DROPDOWN_VALUE[0],
      writeOff
    );
  }

  /**
   * @details -verify transaction date in transaction details screen
   * @param -  value is passed to verify the transaction date
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransactionDate(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_DATE[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TRANSACTION_DATE[0],
      value,
      false,
      true
    );
  }

  /**
   * @details -verifypayment id in transaction details screen
   * @param -  value is passed to verify the payment id
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyPaymentId(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.PAYMENT_ID[1],
      OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.PAYMENT_ID[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify writeoff2 Transaction code
   * @param writeOff passed to verify writeoff2 Transaction code
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyWriteoff2TransactionCode(writeOff: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.WRITEOFF_2_TRANSACTION_DROPDOWN_VALUE[1],
      OR_REMITTANCE_POSTING.WRITEOFF_2_TRANSACTION_DROPDOWN_VALUE[0],
      writeOff
    );
  }

  /**
   * @details -verify total payment in transaction details screen
   * @param -value is passed to verify the total payment
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTotalPayment(value: string) {
    cy.cGet(OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TOTAL_PAYMENT[1])
      .parents(
        CommonUtils.concatenate(
          CommonGetLocators.div,
          CoreCssClasses.Text.loc_custom_alignment
        )
      )
      .find(
        CommonUtils.concatenate(
          CommonGetLocators.span,
          CoreCssClasses.Text.loc_payment
        )
      )
      .should(ShouldMethods.contain_text, value);
  }

  /**
   * @details -verify total write-off in transaction details screen
   * @param -  value is passed to verify the total writeoff
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTotalWriteoff(value: string) {
    cy.cGet(OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.TOTAL_WRITE_OFF[1])
      .parents(
        CommonUtils.concatenate(
          CommonGetLocators.div,
          CoreCssClasses.Text.loc_custom_alignment
        )
      )
      .find(
        CommonUtils.concatenate(
          CommonGetLocators.span,
          CoreCssClasses.Text.loc_payment
        )
      )
      .should(ShouldMethods.contain_text, value);
  }

  /**
   * @details -verify responsible party in transaction details screen
   * @param -  value is passed to verify the responsible party
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyResponsibleParty(value: string) {
    cy.cGet(OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.RESPONSIBLE_PARTY[1])
      .first()
      .should(ShouldMethods.contain_text, value);
  }

  /**
   * @details -verify responsible party in transaction details screen
   * @param -  value is passed to verify the received from
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyReceivedFrom(value: string) {
    cy.cGet(OR_REMITTANCE_POSTING.TRANSACTION_DETAILS.RECEIVED_FROM[1]).should(
      ShouldMethods.contain_text,
      value
    );
  }

  /**
   * @details - Verify Grouper Code Dropdown values
   * @param grouperCodeOr passed to verify particular Grouper code values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyGroupCodeDropdownValues(grouperCodeOr: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(grouperCodeOr, OR_REMITTANCE_POSTING.GROUP_CODE_1[0]);
    defaultWriteOffGroupCode.forEach((item) => {
      cy.cIsVisible(
        CommonUtils.concatenate(
          CommonGetLocators.div,
          CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper,
          ' ',
          selectorFactory.getSpanText(item)
        ),
        item
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(grouperCodeOr, OR_REMITTANCE_POSTING.GROUP_CODE_1[0]);
  }

  /**
   * @details - Verify Reason Code Dropdown values
   * @param reasonCodeOr passed to verify Reason code values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyReasonCodeDropdownValues(resaonCodeOr: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(resaonCodeOr, OR_REMITTANCE_POSTING.REASON_CODE_1[0]);
    defaultWriteOffReasonCode.forEach((item) => {
      cy.cIsVisible(
        CommonUtils.concatenate(
          CommonGetLocators.div,
          CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper,
          ' ',
          selectorFactory.getSpanText(item)
        ),
        item
      );
    });
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(resaonCodeOr, OR_REMITTANCE_POSTING.REASON_CODE_1[0]);
  }

  /**
   * @details -verify batch in confirm remittance posting
   * @param- text to verify the batch
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyBatchInConfirm(text: string) {
    cy.cIsVisible(selectorFactory.getPeriodBatch(text), text);
  }

  /**
   * @details -verify MRN in confirm remittance posting
   * @param -  text to verify draft text in remittance posting
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTypeInRemittancePosting(text: string) {
    cy.cIsVisible(selectorFactory.getTextInLimitTextContainer(text), text);
  }

  /**
   * @details -verify period in confirm remittance posting
   * @param- text to verify the period
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyPeriodInConfirm(text: string) {
    cy.cIsVisible(selectorFactory.getPeriodBatch(text), text);
  }

  /**
   * @details -verify transaction date in confirm remittance posting
   * @param- text to verify the transaction date
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyTransactionDateInConfirm(text: string) {
    cy.cIsVisible(selectorFactory.getPeriodBatch(text), text);
  }

  /**
   * @details -verify MRN in confirm remittance posting
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyMRNInConfirm() {
    cy.cIsVisible(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.MRN[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.MRN[0]
    );
  }

  /**
   * @details - Verify Payment Transaction Code in dropdown
   * @param paymentCode verify Payment Transaction code in dropdown
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyPaymentTransactionCode(paymentCode: string) {
    cy.cIncludeText(
      selectorFactory.getSpanText(paymentCode),
      OR_REMITTANCE_POSTING.PAYMENT_METHOD_DROPDOWN_VALUE[1],
      paymentCode
    );
  }

  /**
   * @details - Verify Debit Transaction Code Dropdown
   * @param transactionCode verify active Transaction code in dropdown
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyDebitTransactionCode(transactionCode: string) {
    cy.cIsVisible(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.DEBIT_TRANSACTION_CODE_DROPDOWN[1],
        ' ',
        selectorFactory.getSpanText(transactionCode)
      ),
      OR_REMITTANCE_POSTING.DEBIT_TRANSACTION_CODE_DROPDOWN[0]
    );
  }

  /**
   * @details - Verify headers in Transaction Grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyHeadersInTranasactionGrid() {
    transactionGridHeaders.forEach((item) => {
      cy.cIncludeText(
        selectorFactory.getThText(item),
        OR_REMITTANCE_POSTING.TRANSACTION_GRID[0],
        item
      );
    });
  }

  /**
   * @details - Verify MRN is Sortable
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyMrnIsSortable() {
    cy.cClick(
      OR_REMITTANCE_POSTING.MRN_SORT_ICON[1],
      OR_REMITTANCE_POSTING.MRN_SORT_ICON[0]
    );
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.MRN_SORT[1],
      OR_REMITTANCE_POSTING.MRN_SORT[0],
      InvokeAttributes.aria_sort,
      SortOrder.ascending
    );
    cy.cClick(
      OR_REMITTANCE_POSTING.MRN_SORT_ICON[1],
      OR_REMITTANCE_POSTING.MRN_SORT_ICON[0]
    );
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.MRN_SORT[1],
      OR_REMITTANCE_POSTING.MRN_SORT[0],
      InvokeAttributes.aria_sort,
      SortOrder.descending
    );
  }

  /**
   * @details -verify Patient name in confirm remittance posting
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyPatientNameInConfirm() {
    cy.cIsVisible(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.MRN[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.MRN[0]
    );
  }

  /**
   * @details - Verify DOS is Sortable
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyDosIsSortable() {
    cy.cClick(
      OR_REMITTANCE_POSTING.DOS_SORT_ICON[1],
      OR_REMITTANCE_POSTING.DOS_SORT_ICON[0]
    );
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.DOS_SORT[1],
      OR_REMITTANCE_POSTING.DOS_SORT[0],
      InvokeAttributes.aria_sort,
      SortOrder.ascending
    );
    cy.cClick(
      OR_REMITTANCE_POSTING.DOS_SORT_ICON[1],
      OR_REMITTANCE_POSTING.DOS_SORT_ICON[0]
    );
    cy.cHasAttribute(
      OR_REMITTANCE_POSTING.DOS_SORT[1],
      OR_REMITTANCE_POSTING.DOS_SORT[0],
      InvokeAttributes.aria_sort,
      SortOrder.descending
    );
  }

  /**
   * @details -verify ,DOS in confirm remittance posting
   * @param -  value to verify the dos passed in
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyDOSInConfirm(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.DOS[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.MRN[0],
      value
    );
  }

  /**
   * @details - Verify DOS format in Transaction grid
   * @param patientName to verify particular patient dos in transaction grid
   * @param dos to verify particular patient dos in transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyDosFormatInTransactionGrid(patientName: string, dos: string) {
    cy.cIncludeText(
      selectorFactory.getDosInTransactionGrid(patientName),
      OR_REMITTANCE_POSTING.DATE[0],
      dos
    );
  }

  /**
   * @details -verify cpt confirm remittance posting
   * @param -  value to verify particular text
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyCPTInConfirm(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.CPT_HCPCS[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.CPT_HCPCS[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify Cpt code in Transaction grid
   * @param patientName passed to verify particular patient cpt in transaction grid
   * @param cpt passed to verify particular patient cpt in transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyCptInTransactionGrid(patientName: string, cpt: string) {
    cy.cIncludeText(
      selectorFactory.getCptInTransactionGrid(patientName),
      OR_REMITTANCE_POSTING.CPT_CODE[0],
      cpt
    );
  }

  /**
   * @details -verify cpt in confirm remittance posting
   * @param - value is passed to verify the Payment
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyPaymentInConfirm(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.PAYMENT[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.PAYMENT[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify Payment value in Transaction grid
   * @param patientName passed to verify particular payment in transaction grid
   * @param value passed to verify particular payment in transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyPaymentValueInTransactionGrid(patientName: string, value: string) {
    cy.cHasValue(
      selectorFactory.getPaymentValueInTransactionGrid(patientName),
      OR_REMITTANCE_POSTING.PAYMENT_TRANSACTION_GRID[0],
      value
    );
  }

  /**
   * @details -verify writeoff 1 in confirm remittance posting
   * @param - value is passed to verify the writeoff1
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyWriteoff1InConfirm(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.WRITE_OFF_1[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.WRITE_OFF_1[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify WriteOff1 value in Transaction grid
   * @param patientName passed to verify particular patient WriteOff1 in transaction grid
   * @param value passed to verify particular WriteOff1 in transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyWriteOff1ValueInTransactionGrid(patientName: string, value: string) {
    cy.cHasValue(
      selectorFactory.getWriteOff1ValueInTransactionGrid(patientName),
      OR_REMITTANCE_POSTING.WRITEOFF1_TRANSACTION_GRID[0],
      value
    );
  }

  /**
   * @details -verify writeoff 2 in confirm remittance posting
   * @param - value is passed to verify the writeoff 2
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyWriteoff2InConfirm(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.WRITE_OFF_2[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.WRITE_OFF_2[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify WriteOff2 value in Transaction grid
   * @param patientName passed to verify particular patient WriteOff2 in transaction grid
   * @param value passed to verify particular patient WriteOff2 in transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyWriteOff2ValueInTransactionGrid(patientName: string, value: string) {
    cy.cHasValue(
      selectorFactory.getWriteOff2ValueInTransactionGrid(patientName),
      OR_REMITTANCE_POSTING.WRITEOFF2_TRANSACTION_GRID[0],
      value
    );
  }

  /**
   * @details -verify Balance due in confirm remittance posting
   * @param -  value is passed to verify the Balance due
   * @API - API's are not available
   * @Author - Spoorthy
   */
  verifyBalanceDueInConfirm(value: string) {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.BALANCE_DUE[1],
      OR_REMITTANCE_POSTING.CONFIRM_REMITTANCE_POSTING.BALANCE_DUE[0],
      value,
      false,
      true
    );
  }

  /**
   * @details - Verify Debit value in Transaction grid
   * @param patientName passed to verify particular Debit in transaction grid
   * @param value passed to verify particular Debit in transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyDebitValueInTransactionGrid(patientName: string, value: string) {
    cy.cHasValue(
      selectorFactory.getDebitValueInTransactionGrid(patientName),
      OR_REMITTANCE_POSTING.DEBIT_TRANSACTION_GRID[0],
      value
    );
  }

  /**
   * @details - Verify Transfer to Dropdown values in Transaction grid
   * @param patientName passed to verify particular Transfer to value  in transaction grid
   * @param tranferTo passed to verify particular Transfer to value in transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyTransferToDropdownValuesInTransactionGrid(
    patientName: string,
    tranferTo: string[]
  ) {
    cy.cClick(selectorFactory.getTransferTransactionGrid(patientName), '');
    tranferTo.forEach((tranferTo) => {
      cy.cIncludeText(
        selectorFactory.getSpanText(tranferTo),
        OR_REMITTANCE_POSTING.TRANSFER_TO_TRANSACTION_GRID[0],
        tranferTo
      );
      cy.cRemoveMaskWrapper(Application.office);
      cy.cClick(selectorFactory.getTransferTransactionGrid(patientName), '');
      cy.cRemoveMaskWrapper(Application.office);
    });
  }

  /**
   * @details - Verify Patient names order after clckin sort icon in Transaction grid
   * @param patientNames passed in alphabetical order and verifying in Transaction grid
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyPatientNamesOrder(patientNames: PatientCase[]) {
    cy.cClick(
      OR_REMITTANCE_POSTING.PATIENT_NAME_SORT_ICON[1],
      OR_REMITTANCE_POSTING.PATIENT_NAME_SORT_ICON[0]
    );
    cy.cGet(OR_REMITTANCE_POSTING.PATIENT_COLUMN[1])
      .should(ShouldMethods.visible)
      .each(function ($ele, index) {
        let expectedPatientName = $ele.text();
        expect(expectedPatientName.replace(/\n/g, '').trim()).to.contain(
          patientNames[index].PatientDetails.LastName
        );
      });
  }

  /**
   * @details - Verify Gentarate Bill helper text
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyGenerateBillHelperText() {
    cy.cGet(OR_REMITTANCE_POSTING.GENERATE_BILL_ICON[1]).trigger(
      TriggerAttributes.mouseenter
    );
    cy.cIncludeText(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      OR_REMITTANCE_POSTING.GENERATE_BILL_ICON[0],
      HelperText.generate_bill
    );
    cy.cClick(
      OR_REMITTANCE_POSTING.GENERATE_BILL_ICON[1],
      OR_REMITTANCE_POSTING.GENERATE_BILL_ICON[0]
    );
  }

  /**
   * @details -verify the Post button in confirm remittance posting
   * @API - API's are not available
   * @author Spoorthy
   */
  verifyPostButton() {
    cy.cIncludeText(
      OR_REMITTANCE_POSTING.POST[1],
      OR_REMITTANCE_POSTING.POST[0],
      OR_REMITTANCE_POSTING.POST[0]
    );
  }

  /**
   * @details - Verify Mrn by hovering on it
   * @param patientName passed to get Mrn value and verify
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyMrnByHovering(patientName: string) {
    let mrn = '';
    cy.cGet(selectorFactory.getMrnValue(patientName)) // Select the element you want to get the value from
      .invoke(InvokeMethods.text)
      .then((value) => {
        mrn = value.trim();
        cy.cGet(selectorFactory.getMrnValue(patientName)).trigger(
          TriggerAttributes.mouseenter
        );
        cy.cIncludeText(
          CoreCssClasses.ToolTipText.loc_p_tooltip_text,
          OR_REMITTANCE_POSTING.GENERATE_BILL_ICON[0],
          mrn
        );
      });
  }

  /**
   * @details - Verify Cpt Code by hovering on it
   * @param patientName passed to get Cpt Code value and verify
   * @param cptCode passed to get Cpt Code value and verify
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyCptCodeValue(patientName: string, cptCode: string) {
    cy.cIncludeText(
      selectorFactory.getCptCodeValue(patientName),
      OR_REMITTANCE_POSTING.CPT_CODE[0],
      cptCode
    );
  }

  /**
   * @details - To enter writeoff1 Transaction Dropdown
   * @param writeOff passed to select writeoff1 Transaction code
   * @API - API's are not available
   * @author Madhu Kiran
   */
  enterWriteoff1TransactionCode(writeOff: string) {
    cy.cClick(
      OR_REMITTANCE_POSTING.WRITEOFF_1_TRANSACTION_DROPDOWN[1],
      OR_REMITTANCE_POSTING.WRITEOFF_1_TRANSACTION_DROPDOWN[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(writeOff),
      OR_REMITTANCE_POSTING.WRITEOFF_1_TRANSACTION_DROPDOWN[0]
    );
  }

  /**
   * @details - Document the payment amount in remittance posting
   * @param option like cpt/patient last name/Dos passed locate particular case
   * @param amount passed to verify payment value
   * @API - API's are not available
   * @author Madhu Kiran
   */
  enterPaymentInRemittance(option: string, amount: string) {
    cy.cType(
      selectorFactory.getPaymentValueInTransactionGrid(option),
      OR_REMITTANCE_POSTING.PAYMENT_TRANSACTION_GRID[0],
      amount
    );
    cy.cClick(
      OR_REMITTANCE_POSTING.DOS_SORT_ICON[1],
      OR_REMITTANCE_POSTING.DOS_SORT_ICON[0]
    );
  }

  /**
   * @details - To select value Payment Transaction Code dropdown
   * @param paymentCode to click Payment Transaction code in dropdown
   * @API - API's are not available
   * @author Madhu Kiran
   */
  enterPaymentTransactionCode(paymentCode: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.PAYMENT_TRANSACTION_DROPDOWN[1],
      OR_REMITTANCE_POSTING.PAYMENT_TRANSACTION_DROPDOWN[0]
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.DROPDOWN_ITEM[1],
        ' ',
        selectorFactory.getSpanText(paymentCode)
      ),
      OR_REMITTANCE_POSTING.PAYMENT_TRANSACTION_DROPDOWN[1]
    );
  }

  /**
   * @details - To enter writeoff2 Transaction Dropdown
   * @param  writeoff to select writeoff2 Transaction code
   * @API - API's are not available
   * @author Madhu Kiran
   */
  enterWriteoff2TransactionCode(writeOff: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.WRITEOFF_2_TRANSACTION_DROPDOWN[1],
      OR_REMITTANCE_POSTING.WRITEOFF_2_TRANSACTION_DROPDOWN[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(writeOff),
      OR_REMITTANCE_POSTING.WRITEOFF_2_TRANSACTION_DROPDOWN[0]
    );
  }

  /**
   * @details -enter the payment amount in remittance posting
   * @param - cptCode to get that cpt value
   * @param-amounts to pass the value
   * @API - API's are not available
   * @Author - Spoorthy
   */
  enterAmountBasedOnCPT(cptCode: string, amounts: string[]) {
    const fieldSelectors = [
      selectorFactory.getPaymentValueInTransactionGrid(cptCode),
      selectorFactory.getWriteOff1ValueInTransactionGrid(cptCode),
      selectorFactory.getWriteOff2ValueInTransactionGrid(cptCode),
    ];

    fieldSelectors.forEach((selector, index) => {
      cy.get(selector).type(amounts[index]);
    });
  }

  /**
   * @details - To select Start date in Case Date Of Service
   * @param date to select date in calender
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectStartDate(date: string) {
    if (date) {
      this.clickOnCalender(OR_REMITTANCE_POSTING.START_DOS[1]);
      sisOfficeDesktop.selectDateFromCalendar(date);
    }
  }

  /**
   * @details - To select End date in Case Date Of Service
   * @param date to select date in calender
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectEndtDate(date: string) {
    if (date) {
      this.clickOnCalender(OR_REMITTANCE_POSTING.END_DOS[1]);
      sisOfficeDesktop.selectDateFromCalendar(date);
    }
  }

  /**
   * @details - To verify all cpt codes in transaction grid
   * @param patientModel to pass patient names
   * @param  cptModel to pass cpt
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyCasesCptCodes(
    patientModel: PatientCase[],
    cptModel: ChargeTransaction[]
  ) {
    patientModel.forEach((patient, index) => {
      this.verifyCptCodeValue(
        patient.PatientDetails.LastName ?? '',
        cptModel[index].CptCode ?? ''
      );
    });
  }

  /**
   * @details - To select End date in Case Date Of Service
   * @param date to select date in calender
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectEndDate(date: string) {
    this.clickOnCalender(OR_REMITTANCE_POSTING.END_DOS[1]);
    sisOfficeDesktop.selectDateFromCalendar(date);
  }

  /**
   * @details - To enter Debit Transaction Code in Dropdown
   * @param transactionCode to click Transaction code dropdown
   * @API - API's are not available
   * @author Madhu Kiran
   */
  enterDebitTransactionCode(transactionCode: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.DEBIT_TRANSACTION_CODE_DROPDOWN[1],
      OR_REMITTANCE_POSTING.DEBIT_TRANSACTION_CODE_DROPDOWN[0]
    );
    cy.cClick(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.DROPDOWN_ITEM[1],
        ' ',
        selectorFactory.getSpanText(transactionCode)
      ),
      OR_REMITTANCE_POSTING.DEBIT_TRANSACTION_CODE_DROPDOWN[0]
    );
  }

  /**
   * @details - Verify all Mandatory fields in Manual Remittance postong
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyAllMandatoryFields() {
    this.verifyMandatoryFields(OR_REMITTANCE_POSTING.TRANSACTION_DATE[0]);
    this.verifyMandatoryFields(OR_REMITTANCE_POSTING.PERIOD[0]);
    this.verifyMandatoryFields(OR_REMITTANCE_POSTING.BATCH[0]);
  }

  /**
   * @details - Verify all Grouper Code Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyAllGroupCodeDropdownValues() {
    this.verifyGroupCode1Dropdown();
    this.verifyGroupCode2Dropdown();
    this.verifyGroupCode3Dropdown();
  }

  /**
   * @details - Verify Grouper1 Code Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyGroupCode1Dropdown() {
    this.verifyGroupCodeDropdownValues(OR_REMITTANCE_POSTING.GROUP_CODE_1[1]);
  }

  /**
   * @details - Verify Grouper2 Code Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyGroupCode2Dropdown() {
    this.verifyGroupCodeDropdownValues(OR_REMITTANCE_POSTING.GROUP_CODE_2[1]);
  }

  /**
   * @details - Verify all Grouper Code Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyGroupCode3Dropdown() {
    this.verifyGroupCodeDropdownValues(OR_REMITTANCE_POSTING.GROUP_CODE_3[1]);
  }

  /**
   * @details - Verify all Reason Code Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyAllReasonCodeDropdownValues() {
    this.verifyReasonCode1Dropdown();
    this.verifyReasonCode2Dropdown();
    this.verifyReasonCode3Dropdown();
  }

  /**
   * @details - Verify Reason Code1 Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyReasonCode1Dropdown() {
    this.verifyReasonCodeDropdownValues(OR_REMITTANCE_POSTING.REASON_CODE_1[1]);
  }

  /**
   * @details - Verify Reason Code2 Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyReasonCode2Dropdown() {
    this.verifyReasonCodeDropdownValues(OR_REMITTANCE_POSTING.REASON_CODE_2[1]);
  }

  /**
   * @details - Verify Reason Code3 Dropdown values
   * @API - API's are not available
   * @author Madhu Kiran
   */
  verifyReasonCode3Dropdown() {
    this.verifyReasonCodeDropdownValues(OR_REMITTANCE_POSTING.REASON_CODE_3[1]);
  }

  /**
   * @details - Click on Group Code1 Dropdown value
   * @param code passed to click on particular Group code dropdown and click on code passed
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectGroupCode1(code: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.GROUP_CODE_1[1],
      OR_REMITTANCE_POSTING.GROUP_CODE_1[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(code),
      OR_REMITTANCE_POSTING.GROUP_CODE_1[0]
    );
  }

  /**
   * @details - Click on Group Code2 Dropdown value
   * @param code passed to click on particular Group code dropdown and click on code passed
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectGroupCode2(code: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.GROUP_CODE_2[1],
      OR_REMITTANCE_POSTING.GROUP_CODE_2[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(code),
      OR_REMITTANCE_POSTING.GROUP_CODE_2[0]
    );
  }

  /**
   * @details - Click on Group Code3 Dropdown value
   * @param code passed to click on particular Group code dropdown and click on code passed
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectGroupCode3(code: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.GROUP_CODE_3[1],
      OR_REMITTANCE_POSTING.GROUP_CODE_2[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(code),
      OR_REMITTANCE_POSTING.GROUP_CODE_3[0]
    );
  }

  /**
   * @details - Click on Reason Code1 Dropdown value
   * @param code passed to click on particular Reason code dropdown and click on code passed
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectReasonCode1(code: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.REASON_CODE_1[1],
      OR_REMITTANCE_POSTING.REASON_CODE_1[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(code),
      OR_REMITTANCE_POSTING.REASON_CODE_1[0]
    );
  }

  /**
   * @details - Click on Reason Code2 Dropdown value
   * @param code passed to click on particular Reason code dropdown and click on code passed
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectReasonCode2(code: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.REASON_CODE_2[1],
      OR_REMITTANCE_POSTING.REASON_CODE_2[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(code),
      OR_REMITTANCE_POSTING.REASON_CODE_2[0]
    );
  }

  /**
   * @details - Click on Reason Code3 Dropdown value
   * @param code passed to click on particular Reason code dropdown and click on code passed
   * @API - API's are not available
   * @author Madhu Kiran
   */
  selectReasonCode3(code: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_REMITTANCE_POSTING.REASON_CODE_3[1],
      OR_REMITTANCE_POSTING.REASON_CODE_3[0]
    );
    cy.cClick(
      selectorFactory.getSpanText(code),
      OR_REMITTANCE_POSTING.REASON_CODE_3[0]
    );
  }

  /**
   * @details - To Enter mandatory fields in manual remittance posting
   * @param remittanceData-ManualRemittancePosting model passed to select values in manual remittance posting
   * @API - API's are not available
   * @author Spoorthy
   */
  enterDataInManualRemittancePosting(remittanceData: ManualRemittancePosting) {
    this.selectValueFromReceivedFromDropdown(remittanceData.ReceivedFrom);
    this.selectEndtDate(remittanceData.EndDate ?? '');
    this.enterCheckAmount(remittanceData.CheckAmount);
    this.selectStartDate(remittanceData.StartDate ?? '');
    this.enterPaymentId(remittanceData.PaymentId ?? '');
    this.selectPeriodAndBatch(remittanceData);
    this.enterPaymentTransactionCode(remittanceData.PaymentTransactionCode);
    this.selectReasonCode1(remittanceData.ReasonCode1 ?? '');
    this.enterDebitTransactionCode(remittanceData.DebitTransactionCode);
    this.selectGroupCode1(remittanceData.GroupCode1 ?? '');
    this.enterWriteoff1TransactionCode(remittanceData.WriteOffCode1 ?? '');
    this.enterWriteoff2TransactionCode(remittanceData.WriteOffCode2 ?? '');
    this.selectGroupCode2(remittanceData.GroupCode2 ?? '');
    this.selectReasonCode2(remittanceData.ReasonCode2 ?? '');
    this.selectReasonCode3(remittanceData.ReasonCode3 ?? '');
    this.selectGroupCode3(remittanceData.GroupCode3 ?? '');
  }

  /**
   * @details - To verify charge details section in Payments/Write-offs/Debits/Transfers popup
   * @param chargeData- ChargeTransaction model passed to select values in manual remittance posting
   * @API - API's are not available
   * @author Spoorthy
   */
  verifyChargeDetailsInTransactionpopup(chargeData: ChargeTransaction) {
    this.verifyDOSChargeDetails(chargeData.DOS ?? '');
    this.verifyCPTChargeDetails(chargeData.CptCode ?? '');
    this.verifyBalanceChargeDetails(chargeData.BalanceDue ?? '');
    this.verifyChargeAmountInCharge(chargeData.ChargeAmount ?? '');
    this.verifyDeductibleField(chargeData.Deductible ?? '');
    this.verifyCoins(chargeData.Coins ?? '');
    this.verifyCopay(chargeData.CoPay ?? '');
    this.verifyAllowedChargeDetails(chargeData.AllowedAmount ?? '');
    this.verifyResponsibleParty(chargeData.ResponsibleParty ?? '');
  }

  /**
   * @details - To verify transaction details section in Payments/Write-offs/Debits/Transfers popup
   * @param transactionData-TransactionDetails model passed to verify data in Payments/Write-offs/Debits/Transfers popup
   * @API - API's are not available
   * @author Spoorthy
   */
  verifyTransactionsDetailsSection(transactionData: TransactionDetails) {
    this.verifyTransactionDate(transactionData.TransactionDate ?? '');
    this.verifyReceivedFrom(transactionData.ReceivedFrom ?? '');
    this.verifyPaymentId(transactionData.PaymentID ?? '');
    this.verifyTransferTo(transactionData.TransferTo ?? '');
    this.verifyPeriodInTransactionDetails(transactionData.Period ?? '');
    this.verifyBatchInTransactionDetails(transactionData.Batch ?? '');
  }

  /**
   * @details -To verify Total payment,total writeoff and copy right in Payments/Write-offs/Debits/Transfers popup
   * @param charges-ChargeTransaction model passed to verify total payment writeoff and copy right in Payments/Write-offs/Debits/Transfers popup
   * @API - API's are not available
   * @author Spoorthy
   */
  verifyTotalPaymentWriteoffCopyRight(charges: ChargeTransaction) {
    this.verifyTotalPayment(charges.TotalPayment ?? '');
    this.verifyTotalWriteoff(charges.TotalWriteoff ?? '');
    this.verifyCopyRightTextInTransaction(charges.CopyRight ?? '');
  }

  /**
   * @details - To verify the data in confirm remittance post
   * @param charges-ChargeTransaction model passed to verify data in confirm remittance post
   * @param-transactionData-TransactionDetails model passed to verify data in confirm remittance post
   * @API - API's are not available
   * @author Spoorthy
   */
  verifyConfirmRemittancePostFields(
    charges: ChargeTransaction,
    transactionData: TransactionDetails
  ) {
    this.verifyDOSInConfirm(charges.DOS ?? '');
    this.verifyPeriodInConfirm(transactionData.Period ?? '');
    this.verifyBatchInConfirm(transactionData.Batch ?? '');
    this.verifyTransactionDateInConfirm(transactionData.TransactionDate ?? '');
    this.verifyPaymentInConfirm(charges.TotalPayment ?? '');
    this.verifyWriteoff1InConfirm(charges.Writeoff1 ?? '');
    this.verifyWriteoff2InConfirm(charges.Writeoff2 ?? '');
    this.verifyBalanceDueInConfirm(charges.BalanceDue ?? '');
  }

  /**
   * @detail - To select Transfer to toggle Yes/No  button in Manual remittance posting
   * @param flag - true/false needs to be passed as transfer to(if transfer to is no, pass false else pass true )
   * @Api -Api are not available
   * @Author - Spoorthy
   */
  selectTranferTo(flag: boolean = false) {
    const yesOrNo = flag ? YesOrNo.yes : YesOrNo.no;
    cy.cClick(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.TRANSFER_TO[1],
        selectorFactory.getSpanText(yesOrNo)
      ),
      yesOrNo
    );
  }

  /**
   * @details - To click on History in remittance posting
   * @Api - API's are available not Implemented
   * @author Madhu Kiran
   */
  clickOnHistory() {
    cy.cClick(
      OR_REMITTANCE_POSTING.HISTORY[1],
      OR_REMITTANCE_POSTING.HISTORY[0]
    );
  }

  /**
   * @details - To select any date in Case Date Of Service
   * @param calendarOr to select particular calender to select
   * @param date to select date in calender
   * @API - API's are not yet identified
   * @author Madhu Kiran
   */
  selectAnyDateInCaseDateOfService(date: string, calendarOr: string) {
    calendarOr === OR_REMITTANCE_POSTING.START_DOS[1]
      ? (this.clickOnCalender(calendarOr),
        sisOfficeDesktop.selectDateFromCalendar(date))
      : (this.clickOnCalender(calendarOr),
        sisOfficeDesktop.selectDateFromCalendar(date));
  }

  /**
   * @details Click on previous month icon
   * @API - API's are not available
   * @author Nikitan
   */
  clickOnPreviousMonth() {
    cy.cClick(
      OR_REMITTANCE_POSTING.CALENDER_PREVIOUS_ICON[1],
      OR_REMITTANCE_POSTING.CALENDER_PREVIOUS_ICON[0]
    );
  }

  /**
   * @details Select the date in calendar based on input
   * @param date - Provide the date in string
   * @API - API's are not available
   * @author Nikitan
   */
  selectDateInCalendar(date: string) {
    cy.cClick(selectorFactory.getDate(date), date);
  }

  /**
   * @details - Click on UP amount context menu options
   * @param option - Allocate, View/Edit, Delete
   * @API - API's are available and implemented completely
   * @author Nikitan
   */
  clickOnUPContextMenuOptions(option: string) {
    const interceptCollection =
      remittancePostingTrackerApis.interceptForUPAmountAllocated();
    cy.cIntercept(interceptCollection);
    cy.cClick(selectorFactory.getSpanText(option), option);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Click on Unassigned Payment context menu based on the Received From provided
   * @param receivedFrom - Received from value (ex. patient name, carrier name)
   * @API - API's are not available
   * @author Nikitan
   */
  clickOnUPContextMenu(receivedFrom: string) {
    cy.cGet(
      CommonUtils.concatenate(
        OR_REMITTANCE_POSTING.UNASSIGNED_PAYMENT_TABLE[1],
        ' ',
        selectorFactory.getSpanText(receivedFrom)
      )
    )
      .parents(CommonGetLocators.tr)
      .find(CommonGetLocators.i)
      .click();
  }
}
