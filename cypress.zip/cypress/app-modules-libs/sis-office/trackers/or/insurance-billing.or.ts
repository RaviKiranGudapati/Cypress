import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_INSURANCE_BILLING = {
  BILL_SELECTED_PAYERS: ['Bill Selected Payers', '#insBillSelected'],
  PRINT_SELECTED_PAYERS: ['Print Selected Payers', '#btnPrintSelected'],
  DOWNLOAD_CLAIMS: ['Download Claims', '#btnClaimDownload'],
  EXPAND_PLUS_ICON: ['Expand Plus Icon', '.ins-billing-expander > span i'],
  CHECK_BOX: [
    'Check Box',
    CommonUtils.concatenate('td ', CoreCssClasses.Checkbox.loc_p_checkbox_icon),
  ],
  CARRIER_ROW: ['Carrier Row', CoreCssClasses.Row.loc_p_selectable_row],
  PATIENT_ROW: [
    'Patient Row',
    CommonUtils.concatenate(
      '.expanded-data ',
      CoreCssClasses.List.loc_p_data_table,
      '-tbody > .expansion-body'
    ),
  ],
  BILL_SELECTED_PAYERS_SENDING: ['Sending', '#insBillButtonDisable'],
  CLOSE_ICON: ['Close'],
};
