import { CommonGetLocators } from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../support/common-core-libs/application/or/sis-office-desktop.or';

export const OR_REVENUE_CYCLE_MANAGEMENT = {
  BILLING_HISTORY: ['Billing History', '#billingBtn'],
  BILLING_HISTORY_CHARGE_CHECKBOX: [
    'Billing hstory charge checkbox',
    CommonUtils.concatenate('#charges ', CoreCssClasses.Checkbox.loc_checkbox),
  ],
  BILL_SELECTED_INSURANCE_CHARGE: [
    'Bill selected insurance charge',
    '#btnBill',
  ],
  BILL_CONFIRMATION_POPUP_HEADER: [
    'Confirmation',
    CommonUtils.concatenate(
      CoreCssClasses.Dialog.loc_confirm_dialog,
      ' ',
      CoreCssClasses.Dialog.loc_dialog_title
    ),
  ],
  BILL_SELECTED_PATIENT_STATEMENT_OK: ['OK', 'button[label="OK"]'],
  BILL_SELECTED_PATIENT_STATEMENT: [
    'Bill selected patient statement',
    '#btnBillStm',
  ],
  BILL_SELECTED_PATIENT_STATEMENT_YES: ['Yes', '#btnConfirmYes span'],
  BILL_SELECTED_PATIENT_STATEMENT_NO: ['No', '#btnConfirmNo span'],
  BILL_CONFIRMATION_TEXT: [
    'Bill confirmation text',
    CommonUtils.concatenate(
      'span',
      CoreCssClasses.Dialog.loc_confirm_dialog_message
    ),
  ],
  PRINT_SELECTED_INSURANCE_CHARGE: [
    'Print Selected Insurance Charge',
    '#btnPrint',
  ],
  CLOSE_PRINT_PREVIEW: [
    'Close print preview',
    CommonUtils.concatenate(
      CoreCssClasses.Dialog.loc_dialog_header,
      '-close-icon'
    ),
  ],
  PRINT_SELECTED_PATIENT_STATEMENT: [
    'Print selected patient statement',
    '#btnPrintStm',
  ],
  ROWS: [
    'Table Rows',
    CommonUtils.concatenate(
      CommonGetLocators.tr,
      CoreCssClasses.Row.loc_p_selectable_row
    ),
  ],
  DOS_COLUMN: ['DOS', '.date-of-service-col'],
  RCM_PAYMENT_TABLE: ['Payment', '#rcm-payment-table'],
  ALLOCATION_DONE: ['Done', CoreCssClasses.Dialog.loc_dialog_mask_button],
  ALLOCATION: {
    TRANSACTION_CODE: ['Transaction Code', '#transactionCodeDropdown'],
    CHARGE_TO_ALLOCATE_ROW: [
      'Allocate Amount',
      CommonUtils.concatenate(
        '#patient-charges-table ',
        CoreCssClasses.Row.loc_p_selectable_row,
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    COLUMN_SIX_CHARGE_TO_ALLOCATE: ['Allocate', '.col6'],
  },
  RCM_STATUS_INDICATOR: ['RCM Status Indicator', '.rcm_status_indicator i'],

  FILTERS: {
    RESPONSIBLE_PARTY: ['Responsible Party', '#rcmRPMultiSelect #msItems'],
    INSURANCE_PLAN_TYPE: [
      'Insurance Plan Type',
      '#rcmIPTypeMultiSelect #msItems',
    ],
    RCM_STATUS: ['Rcm Status', '#rcmStatusMultiSelect #msItems'],
    CLAIM_STATUS: ['Claim Status', '#rcmClaimStatusMultiSelect #msItems'],
    DENIALS: [
      'Denails',
      CommonUtils.concatenate(
        '#rcmDenialSingleSelect',
        ' ',
        CoreCssClasses.DropDown.loc_p_dropdown_tag
      ),
    ],
    AGING_TYPE: ['Aging Type', '#rcmAgingTypeSingleSelect'],
    AGING_CATEGORY: ['Aging Category', '#rcmAgingCategoryMultiSelect #msItems'],
    INSURANCE_CLASSIFICATION: [
      'Insurance Classificaton',
      '#rcmIcMultiSelect #msItems',
    ],
    PAYER_ROLE: ['Payer Role', '#rcmPayerRoleMultiSelect #msItems'],
    APPOINTMENT_TYPE: ['Appointment Type', '#rcmAptTypeMultiSelect #msItems'],
    PHYSICIAN: ['Physician', '#rcmPhyMultiSelect #msItems'],
  },

  RESPONSIBLE_PARTY_DROPDOWN: [
    'Responsible Party',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_dropdown_responsive,
      selectorFactory.getLabelText('Responsible Party')
    ),
  ],
  INSURANCE_CLASSIFICAITON_DROPDOWN: [
    'Insurance Classificaton',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_dropdown_responsive,
      selectorFactory.getLabelText('Insurance Classification')
    ),
  ],
  RCM_STATUS_DROPDOWN: [
    'RCM Status',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_dropdown_responsive,
      selectorFactory.getLabelText('RCM Status')
    ),
  ],
  DENIALS_DROPDOWN: [
    'Denails',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_dropdown_responsive,
      selectorFactory.getLabelText('Denials')
    ),
  ],
  SHOW_DEFAULTS: ['Show Defaults', CoreCssClasses.Button.loc_fa_chevron_down],
  HIDE_DEFAULTS: ['Hide Defaults', CoreCssClasses.Button.loc_fa_chevron_up],
  RESPONSIBLE_PARTY_LABELS: [
    'Responsible Party Labels',
    '.contact-info .label-header',
  ],
  REFRESH: ['Refresh', '#btnRefresh'],
  CLEAR_FILTERS: ['Clear Filters', '#btnClear'],
  PATIENTLASTNAMEFROM: ['Patient Last Name From', '#patientLastNameFromid'],
  PATIENTLASTNAMETO: ['Patient Last Name To', '#patientLastNameToid'],
  FOLLOW_UP_DATE: [
    'Follow-Up Date',
    CommonUtils.concatenate('#followUpDate', ' ', CommonGetLocators.input),
  ],
  MRN: ['MRN', '#rcmMRN'],
  PAGINATOR: ['Paginator', CoreCssClasses.Panel.loc_p_paginator],
  RESPONSIBLE_PARTY: {
    DROPDOWN: ['Responsible Party Dropdown', '#rcmRPMultiSelect #msItems'],
    SEARCH_FIELD: [
      'Search Field',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_multi_select_panel_p_component,
        ' ',
        CommonGetLocators.input
      ),
    ],
    MULTI_SELECT_WRAPPER: [
      'Multi Select Wrapper',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_multi_select_panel_p_component,
        ' ',
        CoreCssClasses.MultiSelect.loc_p_multiselect_items_wrapper
      ),
    ],
    RESPONSIBLE_PARTY_LABEL: [
      'Responsible Party',
      selectorFactory.getLabelText('Responsible Party'),
    ],
  },

  REFRESH_BUTTON: ['Refresh', '#btnRefresh'],
  PATIENT_NAME_IN_RCM: [
    'PatientName',
    '.trackers-entry-body-max #rcm-tracker-table tbody tr td.patient-col',
  ],
  PATIENT_NAME_WITHIN_ROW_IN_RCM: ['PatientName', 'td.patient-col'],
  DOS_WITHIN_ROW_IN_RCM: ['Dos', 'td.date-of-service-col'],
  BALANCE_WITHIN_ROW_IN_RCM: ['Balance', 'td.balance-col'],
  RESPONSIBLE_PARTY_WITHIN_ROW_IN_RCM: [
    'Responsible Party',
    'td.responsible-party-col',
  ],
  TRANSFER_WITHIN_ROW_IN_RCM: ['Transfer', 'td.post-date-col'],
  MRN_WITHIN_ROW_IN_RCM: ['Mrn', 'td.mrn-col'],
  ARDAYS_WITHIN_ROW_IN_RCM: ['Ar days', 'td.aging-col'],
  FOLLOW_UP_DATE_WITHIN_ROW_IN_RCM: ['Follow Up Date', 'td.follow-up-date-col'],
  STATUS_WITHIN_ROW_IN_RCM: ['Status', 'td.status-col div'],
  LAST_NOTE_DATE_WITHIN_ROW_IN_RCM: [
    'Last Note Date',
    '.trackers-entry-body-max #rcm-tracker-table tbody tr',
  ],
  CHECK_BOX_WITHIN_ROW_IN_RCM: ['Check Box', 'td.check-box-col span'],
  ROW_IN_RCM: [
    'Row In Rcm',
    '.trackers-entry-body-max #rcm-tracker-table tbody tr',
  ],
  TURNOVER_TO_COLLECTION_BUTTON: [
    'Turnover To Collection',
    '#btnTurnoverToCollection',
  ],
  RCM_SUMMARY: {
    CPT_IN_CHARGES: ['CPT/HCPCS', 'div .rcharge__content--cpt-text'],
    SIS_RCM_TAG: ['TAG', 'sis-rcm-charge'],
    RCM_STATUS: ['Rcm Status', '#rcmStatuses'],
    RCM_DROPDOWN_WRAPPER: [
      'Rcm Dropdown Wrapper',
      CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper,
    ],
    DONE_BUTTON: ['Done', OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1]],
  },
  TURNOVER_TO_COLLECTION_POPUP: {
    NEW_RCM_STATUS: ['New Rcm Status', '#rcmStatusDropdown'],
    PERIOD: ['Period Dropdown', '#periodDropdown'],
    BATCH: ['Batch Dropdown', '#batchDropdown'],
    TRANSACTION_CODE: [
      'Transaction Code Dropdown',
      '#rcmBulkWriteOffTransactionCodeDropdown',
    ],
    TRANSACTION_DATE: ['Transaction Date', '#calTransactionDate'],
    NEW_RCM_STATUS_WRAPPER: [
      'New Rcm Status Wrapper',
      CommonUtils.concatenate(
        CommonGetLocators.div,
        ' ',
        CoreCssClasses.DropDown.loc_p_dropdown_items_wrapper
      ),
    ],
    WRITE_OFF_ALL_SELECTED_CHARGES_YES: [
      'Write Off All Selected Charges Yes',
      '#sbWriteOffAllCharges [aria-label="Yes"]',
    ],
    WRITE_OFF_ALL_SELECTED_CHARGES_NO: [
      'Write Off All Selected Charges No',
      '#sbWriteOffAllCharges [aria-label="No"]',
    ],
    GENERATE_FILE_AND_DONE: [
      'Generate File And Done',
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
    ],
  },
  INSURANCE_DROPDOWN: ['Insurance Drop Down'],
  UNASSIGNED_PAYMENT: {
    RECEIVED_FROM_COL: ['Received From', '.received-from-col'],
    CONTEXT_MENU: ['Context Menu', '.context-menu'],
    DOWN_CONTEXT: ['Down context', '.context-menu i'],
    ALLOCATE: ['Allocate'],
    DONE: [
      'Done',
      CommonUtils.concatenate(
        '.btn-done ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],
  },
  RESPONSIBLE_PARTY_SEARCH: [
    'Responsible Party',
    CommonUtils.concatenate(
      CoreCssClasses.DropDown.loc_p_multiselect_filter_container,
      ' ',
      CommonGetLocators.input
    ),
  ],
  RCM_DETAILS: {
    SUBSCRIBER_LABELS: [
      'Subscriber Labels',
      'sis-rcm-subscriber .contact-info .label-header',
    ],
    SUBSCRIBER: {
      SUBSCRIBER_INFO: [
        'Subscriber Info',
        'sis-rcm-subscriber .contact-info label.data-item',
      ],
    },
    RESPONSIBLE_PARTY_LABELS: [
      'Responsible Party Labels',
      'sis-rcm-insurance .contact-info .label-header',
    ],
    INSURANCE: {
      INSURANCE_INFO: [
        'Subscriber Info',
        'sis-rcm-insurance .contact-info label.data-item',
      ],
    },
    SHOW_PAYMENTS: ['Show Payments', CoreCssClasses.Button.loc_fa_chevron_down],
    HIDE_PAYMENTS: ['Hide Payments', CoreCssClasses.Button.loc_fa_chevron_up],
  },
};
