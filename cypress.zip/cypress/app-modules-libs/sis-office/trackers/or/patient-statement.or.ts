import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';

export const OR_PATIENT_STATEMENT = {
  BILL_SELECTED_PATIENTS: ['Bill Selected Patients', '#insBillSelected'],
  PRINT_SELECTED_PATIENTS: ['Print Selected Patients', '#btnPrintSelected'],
  DOWNLOAD_STATEMENTS: ['Download Statements', '#btnPatientStatementsDownload'],
  SUBMIT_FILE: ['Submit File'],
  CHECKBOX: [
    'Check Box',
    CommonUtils.concatenate('td ', CoreCssClasses.Checkbox.loc_p_checkbox_icon),
  ],
  PATIENT_STATEMENT_VALUES: ['Patient Statement Header Values', 'td span'],
  CLOSE_PRINT_PREVIEW: [
    'Close print preview',
    CommonUtils.concatenate(
      CoreCssClasses.Dialog.loc_dialog_header,
      '-close-icon'
    ),
  ],
};
