import {
  InvokeAttributes,
  CommonGetLocators,
  YesOrNo,
} from '../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_CHARGE_ENTRY = {
  CHARGE_ENTRY: {
    CHARGE_ENTRY: ['Charge Entry'],
    PERIOD: ['Period', '[data-test-id^="periodDropdown"]'],
    BATCH: ['Batch', '[data-test-id^="batchDropdown"]'],
    TOTAL_CASES: ['Total Cases', '.trackers-entry .total-cases-badge'],
    AUTO_SORT: ['Auto sort', '#autoSortBtn'],
    DEBIT_INPUT: ['Debit Input', '#txtDebitAmount'],
    NOTES_DONE: [
      'Done',
      CommonUtils.concatenate(
        '.notesContainer-modal ',
        selectorFactory.getSpanText('Done')
      ),
    ],
    UNITS_HEADER: [
      'Units',
      CommonUtils.concatenate(selectorFactory.getPStrongText('Units')),
    ],
    SELF_PAY_YES: [
      'Yes',
      CommonUtils.concatenate(
        '#toggleInsSelfPay div[',
        InvokeAttributes.aria_label,
        '="',
        YesOrNo.yes,
        '"]'
      ),
    ],
    SELF_PAY_NO: [
      'No',
      CommonUtils.concatenate(
        '#toggleInsSelfPay div[',
        InvokeAttributes.aria_label,
        '="',
        YesOrNo.no,
        '"]'
      ),
    ],
    PHYSICIAN_CROSS_ICON: [
      'Physcian Cross Icon',
      CommonUtils.concatenate(
        `[id*='physicianListDropdown'] `,
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    PRIMARY_INSURANCE: [
      'Primary Insurance',
      CommonUtils.concatenate(
        '[id*="primaryInsuranceDropdown"] ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    PRIMARY_INSURANCE_CLEAR: [
      'Primary Insurance Clear',
      CommonUtils.concatenate(
        '[id*="primaryInsuranceDropdown"] > ',
        CoreCssClasses.PrimeNg.loc_single_select,
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    SECONDARY_INSURANCE: [
      'Secondary Insurance',
      CommonUtils.concatenate(
        '[id*="secondaryInsuranceDropdown"] ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    SECONDARY_INSURANCE_CLEAR: [
      'Secondary Insurance Clear',
      CommonUtils.concatenate(
        '[id*="secondaryInsuranceDropdown"] > ',
        CoreCssClasses.PrimeNg.loc_single_select,
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    TERTIARY_INSURANCE: [
      'Tertiary Insurance',
      CommonUtils.concatenate(
        '[id*="tertiaryInsuranceDropdown"] ',
        CoreCssClasses.DropDown.loc_dropdown_label
      ),
    ],
    TERTIARY_INSURANCE_CLEAR: [
      'Tertiary Insurance Clear',
      CommonUtils.concatenate(
        '[id*="tertiaryInsuranceDropdown"] > ',
        CoreCssClasses.PrimeNg.loc_single_select,
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    INSURANCE_OPTIONS: [
      'Select Insurance',
      CommonUtils.concatenate(
        'div.ng-star-inserted > ',
        CoreCssClasses.Label.loc_custom_tooltip,
        ' > ',
        CoreCssClasses.Text.loc_limittext_holder,
        ' > ',
        CoreCssClasses.Text.loc_limittext_container
      ),
    ],
    WRITEOFF_AMOUNT: ['Write-Off Amount', '#amount'],    
    NO_RESULTS: ['No records found', '#dtCEWriteOffs .td-no-hover div'],
    BALANCE_AMOUNT: [
      'Balance',
      CommonUtils.concatenate(
        '.tppadding2rem ',
        CoreCssClasses.Text.loc_label_text
      ),
    ],
    PHYSICIAN: [
      'Physician',
      '[data-test-id^="staffSingleSelectphysicianListDropdown"]',
    ],
    SEARCH_DIAGNOSIS_CODE: ['Diagnosis Codes', '#diagnosisSearchText'],
    DIAGNOSIS_CODE_LIST: [
      'Diagnosis List',
      CoreCssClasses.List.loc_diagnosis_list_item,
    ],
    DIAGNOSIS_TRASH_ICON: [
      'Trash Icon',
      CommonUtils.concatenate(
        CoreCssClasses.Icon.loc_trash_icon(),
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    REFERRING_PHYSICIAN: [
      'Referring Physician',
      '[data-test-id^="staffSingleSelectreferringPhysicianDropdown"]',
    ],
    SELF_PAY: ['Self-Pay', '#toggleInsSelfPay'],
    PROCEDURE_GRID: ['Procedure', '.p-grid-row'],

    PERFORMED_ITEMS: {
      PERFORMED_ITEMS_PANEL: [
        'Performed Items List',
        CommonUtils.concatenate(
          '#cpiPerformedList ',
          CoreCssClasses.Panel.loc_p_panel
        ),
      ],
      PHYSICIAN_DROPDOWN: ['Physician'],
      EXPAND_PLUS_ICON: ['Plus Icon', CoreCssClasses.Icon.loc_expand_icon()],
      EXPAND_MINUS_ICON: [
        'Minus Icon',
        CoreCssClasses.Icon.loc_collapse_icon(),
      ],
      WRITE_OFFS: {
        WRITE_OFF_AMOUNT: ['Write-Off Amount', '#amount'],
        WRITE_OFF_TRANSACTION_CODE: [
          'Write-Off Transaction Code',
          '#woTransactionCodeDropdown_0',
        ],
        WRITE_OFF_GROUP_CODE: [
          'Write-Off Group Code',
          '#woGroupCodeDropdown_0',
        ],
        WRITE_OFF_REASON_CODE: [
          'Write-Off Reason Code',
          '#woReasonCodeDropdown_0',
        ],
      },
    },
    READY_FOR_BILL_YES_BUTTON: [
      'Yes',
      '#inpsReadyForBill span:contains("Yes")',
    ],
    ADD_PROCEDURE: ['Add Procedure', '#btnAddProcedure'],
    PROCEDURE_DESCRIPTION: [
      'Procedure Description',
      CommonUtils.concatenate(
        '.selectedlst div:last-child .',
        CoreCssClasses.Panel.loc_p_panel,
        '-content #procedureAutoComplete input'
      ),
    ],
    PROCEDURE_SELECTION: [
      'Cpt Code Selection',
      CoreCssClasses.List.loc_procedure_item,
    ],
    GENERATE_BILL: [
      'Generate Bill',
      CoreCssClasses.Checkbox.loc_p_checkbox_box,
    ],
    ADD_SUPPLIES: ['Add supplies', '#btnAddSupplies'],
    SEARCH_SUPPLIES: [
      'Supply selection',
      `input[placeholder*=' Search by name or inv #']`,
    ],
    SUPPLIES_SELECTION: ['Supply selection', `li[role='option']`],
    AMOUNT_LABEL: ['Amount', `strong[class*='red-asterisk']`],
    CHARGE_AMOUNT: ['Charge amount', `[id^='txtAmount'] #numericInput`],
    CPT_ROW: ['Cpt', `[id^='chargeRow']`],
    REVENUE_CODE: [
      'Revenue Code',
      CommonUtils.concatenate(
        '[id^="revenueCodeDropdown"] ',
        CoreCssClasses.DropDown.loc_p_dropdown
      ),
    ],
    DEBIT_HEADER: [
      'Debit amount',
      CommonUtils.concatenate(selectorFactory.getPStrongText('Debit Amount')),
    ],
    DEBIT_AMOUNT: ['Debit amount', `[id^='txtDebitAmount'] #numericInput`],
    HCPCS: ['HCPCS', '[id^="hcpcsInput"]'],
    ADD_SUPPLIES_DEBIT_AMOUNT: [
      'Add supplies debit amount',
      CommonUtils.concatenate(
        '.debits_box div[class*="modifier debit_amount"] ',
        selectorFactory.getPStrongText('Debit Amount')
      ),
    ],
    ADD_SUPPLIES_DEBIT_TRANSACTION_CODE: [
      'Add supplies debit transaction code',
      selectorFactory.getPStrongText('Debit Transaction Code'),
    ],
    ADD_SUPPLIES_REVENUE_DISCOUNT: [
      'Add supplies revenue discount',
      CommonUtils.concatenate(
        'div[class*="modifier discounts_padding"] ',
        selectorFactory.getPStrongText('Discounts')
      ),
    ],
    ADD_SUPPLIES_REVENUE_REVENUE_CODE: [
      'Add supplies revenue code',
      'div[class*="revenue_box"] p strong span[class="red-asterisk"]',
    ],
    ADD_SUPPLIES_CHARGE_DETAILS_BALANCE: [
      'Charge Details Balance in Add Supplies',
      CommonUtils.concatenate(
        'div[class*="charge-details-container"] div[class*="amount-row"] div ',
        selectorFactory.getPStrongText('Balance')
      ),
    ],
    ADD_SUPPLIES_CHARGE_DETAILS_AMOUNT: [
      'Add supplies charge details amount',
      CommonUtils.concatenate(
        'div[class*="charge-details-container"] div[class*="amount_unit"] ',
        selectorFactory.getPStrongText('Amount')
      ),
    ],
    ADD_SUPPLIES_CHARGE_DETAILS_TYPE_OF_BILL: [
      'Add supplies charge details type of bill',
      CommonUtils.concatenate(
        'div[class*="charge-details-container"] div ',
        selectorFactory.getPStrongText('Type of Bill')
      ),
    ],
    ADD_SUPPLIES_CHARGE_DETAILS_UNITS: [
      'Add supplies charge details units',
      CommonUtils.concatenate(
        'div[class*="charge-details-container"] div ',
        selectorFactory.getPStrongText('Units')
      ),
    ],
    ADD_SUPPLIES_PRIMARY_INSURANCE: [
      'Add supplies primary insurance',
      'div[class*="col2"] div[class*="modifier primary-insurance"]',
    ],
    ADD_SUPPLIES_SECONDARY_INSURANCE: [
      'Add supplies secondary insurance',
      'div[class*="col2"] div[class*="Secondary"]',
    ],
    ADD_SUPPLIES_TERTIARY_INSURANCE: [
      'Add supplies tertiary insurance',
      'div[class*="col2"] div[class*="modifier tertiary-insurance"]',
    ],
    ADD_SUPPLIES_SELF_PAY: [
      'Add supplies self pay',
      CommonUtils.concatenate(
        'div[class*="col3"] div[class*="modifier self-pay"] ',
        selectorFactory.getPStrongText('Self-Pay')
      ),
    ],
    ADD_SUPPLIES_COMPENSATION: [
      'Add supplies compensation',
      'div[class*="col3"] div[class*="compensation"] ',
    ],
    ADD_SUPPLIES_CLAIM_INFO: [
      'Add supplies additional claim information',
      'div[class*="col3"] div[class*="additional_claim"] ',
    ],
    UNITS_OF_MEASURE: [
      'Add supplies unit of measure ',
      '#unitOfMeasureDropdown_1',
    ],
    CLEAR_UNITS_OF_MEASURE: [
      'Clear units of measure',
      CommonUtils.concatenate(
        '#unitOfMeasureDropdown_1  ',
        CoreCssClasses.PrimeNg.loc_single_select,
        ' ',
        CoreCssClasses.DropDown.loc_dropdown_clear
      ),
    ],
    DISCOUNT_DROPDOWN: ['Discount dropdown', '[id*="sourceOfRevenueDropdown"]'],
    AMOUNT: ['Amount', '#txtAmount0 #numericInput'],
    BATCH_TEXT_INPUT: ['Batch text', '#batchTxt'],
    SEARCH_PROCEDURE: [
      'Search Procedure',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_grid_responsive,
        ` #procedureAutoComplete`
      ),
    ],
    ADD_PROCEDURE_PHYSICIAN: [
      'Physician',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_grid_responsive,
        ` sis-single-select-dropdown[id*='physician']`
      ),
    ],
    ADD_PROCEDURE_PERIOD: [
      'Period',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_grid_responsive,
        ` sis-single-select-dropdown[id*='period']`
      ),
    ],
    ADD_PROCEDURE_BATCH: [
      'Batch',
      CommonUtils.concatenate(
        CoreCssClasses.Panel.loc_p_grid_responsive,
        ` sis-single-select-dropdown[id*='batch']`
      ),
    ],
    CPT_PROCEDURE: ['CPT Procedure', '.expanded #procedureAutoComplete'],
    CPT_COL_HEADER: ['CPT Procedure and Description', CommonUtils.concatenate(CommonGetLocators.tr,' .cpt-col')],
    PI_DOCUMENT: ['PI Document Ctrl #', 'input#piDocControl'],
    SI_DOCUMENT: ['Document Ctrl #', 'input#siDocControl'],
    TI_DOCUMENT: ['TI Document Ctrl #', 'input#tiDocControl'],
    APPLY_ALL_CHARGES_NO: ['Apply all charges set to no', '#applychanges '],
    RESUBMISSION_FREQUENCY_CODE: [
      'Resubmission Frequency Code',
      'input#resubmissionCode',
    ],
    ADDITIONAL_CLAIM_INFO_ENABLE_DISABLE: [
      'Additional cliam information',
      '.additional_claim button',
    ],
    SEARCH_HCPCS: [
      'Search Hcpcs',
      CommonUtils.concatenate(
        CoreCssClasses.Input.loc_p_input_text,
        '.hcpcsInput'
      ),
    ],
    APPLY_ALL_CHARGES_YES: ['Apply all charges set to yes', '#applychanges '],
    UNITS: ['Units', `[id^="txtUnits"] input`],
    WRITE_OFF_ROW: ['Write off Row', '.write-off-row'],
    SEARCH_PROCEDURE_INPUT_FIELD: [
      'Search Procedure Input Field',
      CommonUtils.concatenate(
        '.procedure-search ',
        CoreCssClasses.Button.loc_p_element
      ),
    ],
  },
  APPLY_ALL_CHARGES_I_ICON: [
    'i Icon',
    CommonUtils.concatenate(
      '.footer-zone .control-label ',
      CoreCssClasses.ClassPrefix.loc_fa_fa
    ),
  ],
  GENERATE_BILL_LABEL: ['Generate Bill', '.generate-bill'],
};
