import { YesOrNo } from '../../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../support/common-core-libs/framework/selector-factory';

export const OR_CLINICAL_DOCUMENTATION = {
  DOCUMENTATION_COMPLETE: {
    YES: [
      'Yes',
      CommonUtils.concatenate(
        '#documentationComplete',
        ' ',
        selectorFactory.getSpanText(YesOrNo.yes)
      ),
    ],
    NO: [
      'No',
      CommonUtils.concatenate(
        '#documentationComplete',
        ' ',
        selectorFactory.getSpanText(YesOrNo.no)
      ),
    ],
  },
};
