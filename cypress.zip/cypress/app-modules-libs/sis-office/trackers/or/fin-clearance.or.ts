export const OR_AMOUNT_VERIFICATION = {
  FINANCIAL_CLEARANCE_PAGE: {
    SEND_PATIENT_ESTIMATE: [
      'Send Patient Estimate',
      'button#sendPatientEstimate',
    ],

    PRIMARY_INSURANCE: [
      'Primary Insurance',
      '[id*="primaryInsuranceDropdown"] span[class*="loc_dropdown_label loc_ui_input_text"]',
    ],

    SECONDARY_INSURANCE: [
      'Secondary Insurance',
      '[id*="secondaryInsuranceDropdown"] span[class*="loc_dropdown_label loc_ui_input_text"]',
    ],
    DEPOSIT_AMOUNT: ['Deposit Amount', '#txtDepAmt0'],
    SI_DEPOSIT_AMOUNT: ['Secondary Insurance Deposit', '#txtDepAmt1'],
    VERIFICATION_COMPLETE_TOGGLE: [
      'Verification Complete',
      '#readyForChargeToggle',
    ],
  },
};
