export const responsibleParty = [
  'Select All',
  'Patient Responsibility',
  'Self-Pay with No Insurance',
  'Insurance106826',
];
export const claimStatus = [
  'Sent to Waystar',
  'No Status Available',
  'Accepted by Waystar',
];
export const denials = ['Exclude denials', 'Only show denials', 'Show all'];
export const agingType = [
  'Case Date of Service',
  'Last Payment Date',
  'Transfer Days',
];
export const agingCategory = ['0-30', '31-60', '61-90', '91-120', '121+'];
export const insuranceClassification = [
  'Automobile Medical',
  'BC/BS',
  'Champus',
  'Commercial',
];
export const payerRole = [
  'PI (Primary Insurance)',
  'SI (Secondary Insurance)',
  'TI (Tertiary Insurance)',
  'PG (Primary Guarantor)',
  'SG (Secondary Guarantor)',
];
export const rcmTrackerColumns = [
  'DOS',
  'Balance',
  'Responsible Party',
  'Post/Transfer Date',
  'Patient Name',
  'MRN',
  'A/R Days',
  'Follow-Up Date',
  'Status',
  'Last Note Date',
];
export const responsibilityPartyFields = [
  'Carrier:',
  'Plan:',
  'Claim Office:',
  'Claim Office Address:',
  'Phone:',
  'Payer Code',
  'Subscriber ID:',
];
export const insuranceFields = [
  'Carrier:',
  'Plan:',
  'Claim Office:',
  'Claim Office Address:',
  'Phone:',
  'Payer Code',
];
export const subscriberFields = [
  'Subscriber Name:',
  'Subscriber DOB:',
  'Relationship:',
  'Group Name:',
  'Group Number:',
  'Subscriber ID:',
];
