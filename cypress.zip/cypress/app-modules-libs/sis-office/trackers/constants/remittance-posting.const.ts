export const transactionsTableHeaders = [
    'Transaction Type',
    'Amount',
    'Transaction Code',
    'Group Code',
    'Reason Code',
    'Remark Code',
  ];
  export const remittanceHistorytableHeaders = [
    'Date',
    'Batch Name',
    'Insurance',
    'Check Total',
    '',
  ];
  
  export const dateFormat = 'mm/dd/yyyy';
  export const paymentMethod = ['Cash', 'Check', 'Credit Card', 'EFT', 'Care Credit'];
  export const selectItem = 'Select Item';
  export const transactionGridHeaders = [
    'MRN',
    'DOS',
    'CPT® / HCPCS',
    'Payment',
    'Write-Off 1',
    'Write-Off 2',
    'Debit',
    'Transfer To',
    'Balance Due',
  ];