export const addNewItem = 'Add New Item';
export const headersName = [
  'Patient Name',
  'MRN',
  'Insurance',
  'Physician',
  'Procedure',
  'Specialty',
  'Status',
  'DOS',
];

export const unitsOfMeasure = ['UN', 'ML', 'ME', 'GR', 'F2'];

export const headers = [
  'CPT® Code or HCPCS Code',
  'Physician',
  'Period',
  'Batch',
];

export const writeOff = [
  'Write-Off Amount',
  'Write-Off Transaction Code',
  'Write-Off Group Code',
  'Write-Off Reason Code',
];
export const modifiers = [
  'Billing Procedure Description',
  'Referring Physician',
  'Modifier 1',
  'Modifier 2',
  'Modifier 3',
  'Modifier 4',
];
