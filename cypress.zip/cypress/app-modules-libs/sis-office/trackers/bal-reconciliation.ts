import {
  Application,
  CommonGetLocators,
  InvokeMethods,
} from '../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { Charges } from '../../../test-data-models/sis-office/trackers/combined-coding.model';

import { OR_BALANCE_RECONCILIATION } from './or/bal-reconciliation.or';
import { OR_CHARGE_ENTRY } from './or/charge-entry.or';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

export default class BalanceReconciliation {
  /* instance variables */
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  /**
   * @details - selecting period and batch in Balance
   * removing mask wrapper and selecting patient
   * @param - chargesInfo
   * @API - API's are not available
   */
  selectPeriodAndBatch(chargesInfo: Charges) {
    // Added clicking on the period and batch labels because of the rendering issue
    this.clickPeriodAndBatchLabel();
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getDropdownValues(chargesInfo.Period),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
    cy.cGet(OR_BALANCE_RECONCILIATION.BATCH[1])
      .first()
      .within(() => {
        cy.cGet(selectorFactory.getSpanText(chargesInfo.Batch)).eq(0).click();
      });
  }

  /**
   * @details - Verify the deleted allocation transaction is not present in balance reconciliation page
   * @param - name
   * @param - value
   * @API - API's are not available
   */
  verifyTransactionType(name: string, value: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_PLUS_ICON[1],
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_PLUS_ICON[0]
    );
    cy.cGet(OR_BALANCE_RECONCILIATION.BALANCE_RECONCILIATION_ROW[1]).each(
      () => {
        cy.cGet(CommonGetLocators.td).each(($rowData) => {
          if ($rowData.text().includes(name))
            expect($rowData.text().replace(/\s+/g, ' ').trim()).to.not.contains(
              value
            );
        });
      }
    );
  }

  /**
   * @details -Click on Plus Icon
   * @API - API's are not available
   */
  clickOnPlusIcon() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cGet(OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_PLUS_ICON[1])
      .invoke(InvokeMethods.show)
      .click();
    cy.cRemoveMaskWrapper(Application.office);
  }

  /**
   * @details - verify Transaction code mapped with patient row
   * @API - API's are not available
   */
  verifyTransactionCode(value: string) {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cIsVisible(
      selectorFactory.getAmountInBalanceReconciliation(value),
      value
    );
  }

  /**
   * selecting period and batch Labels in Balance Reconciliation
   * @API - API's are not available
   */
  clickPeriodAndBatchLabel() {
    cy.cRemoveMaskWrapper(Application.office);
    cy.cClick(
      selectorFactory.getLabelText(OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.PERIOD[0],
      false,
      true
    );
    cy.cClick(
      selectorFactory.getLabelText(OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0]),
      OR_CHARGE_ENTRY.CHARGE_ENTRY.BATCH[0],
      false,
      true
    );
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the Balance reconciliation tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptBalanceReconciliationTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }
}
