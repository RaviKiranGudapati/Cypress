import {
  ShouldMethods,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';

import { Carrier } from '../../../test-data-models/sis-office/trackers/fin-clearance.model';
import { PatientDetails } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_AMOUNT_VERIFICATION } from './or/fin-clearance.or';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';
import { FinancialClearanceApis } from './api/financial-clearance.api';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

/**
 * Class for Financial clearance Page
 */
export default class FinancialClearance {
  /* instance variables */
  private finClearanceApis = new FinancialClearanceApis();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  /**
   * @details - Enter the Deposit amount in Primary Insurance
   * @param - depositAmountField
   * @API - API's are not available
   */
  enterPIDepositAmount(depositAmountField: Carrier) {
    cy.cType(
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.DEPOSIT_AMOUNT[1],
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.DEPOSIT_AMOUNT[0],
      depositAmountField.DepositAmount
    );
  }

  /**
   * @details - Enter the Deposit amount in Secondary Insurance
   * @param - siDepositAmountField
   * @API - API's are not available
   */
  enterSIDepositAmount(siDepositAmountField: Carrier) {
    cy.cType(
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.SI_DEPOSIT_AMOUNT[1],
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.SI_DEPOSIT_AMOUNT[0],
      siDepositAmountField.DepositAmount
    );
  }

  /**
   * @details - To verify complete toggle
   * @param - option
   * @API - API's are not available
   */
  verificationCompleteToggle(option: string) {
    let i;
    option.toUpperCase() == 'YES' ? (i = YesOrNo.yes) : (i = YesOrNo.no);
    cy.cClick(
      CommonUtils.concatenate(
        OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE
          .VERIFICATION_COMPLETE_TOGGLE[1],
        ' ',
        selectorFactory.getSpanText(i)
      ),
      i
    );
  }

  /**
   * @details - To remove deposit amount in financial clearance page
   * @API - API's are not available
   */
  // To remove deposit amount in financial clearance page
  removeDepositAmount() {
    let selector =
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.DEPOSIT_AMOUNT[1];
    let logicalName =
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.DEPOSIT_AMOUNT[0];
    cy.cGet(selector, logicalName)
      .should(ShouldMethods.visible)
      .then(() => {
        cy.cClear(selector);
      });
  }

  /**
   * @details - To remove deposit amount in financial clearance page
   * @API - API's are not available
   */
  removeSiDepositAmount() {
    let selector =
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.SI_DEPOSIT_AMOUNT[1];
    let logicalName =
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.SI_DEPOSIT_AMOUNT[0];
    cy.cGet(selector, logicalName)
      .should(ShouldMethods.visible)
      .then(() => {
        cy.cClear(selector);
      });
  }

  /**
   * @details - Waiting for Financial Clearance Page to load by verifying the visibility of Send Patient Estimate Button
   * @API - API's are not available
   */
  waitForFCPageToLoad() {
    cy.cIsVisible(
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.SEND_PATIENT_ESTIMATE[1],
      OR_AMOUNT_VERIFICATION.FINANCIAL_CLEARANCE_PAGE.SEND_PATIENT_ESTIMATE[0]
    );
  }

  /**
   * @details - select Patient Row Through Patient Information based on the selfpay param. if case is selfpay pass true otherwise pass false
   * @param patientInfo - Patient details (First Name,Last Name) needs to be passed
   * @param selfPay - Pass true if case is Self pay else pass false if case is mapped with Insurance
   * @author - Madhu Kiran
   * @API - API's are available - Implemented Completely
   */
  selectPatientRow(patientInfo: PatientDetails, selfPay: boolean = false) {
    const interceptCollection = selfPay
      ? this.finClearanceApis.interceptSelfPaySelectingPatient()
      : this.finClearanceApis.interceptInsuranceSelectingPatient();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectTableRow(
      patientInfo.PatientFirstName!,
      patientInfo.LastName!
    );
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the Finance Clearance tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptFinancialClearanceTrackerApi();
    cy.cIntercept(interceptCollection);
    sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }
}
