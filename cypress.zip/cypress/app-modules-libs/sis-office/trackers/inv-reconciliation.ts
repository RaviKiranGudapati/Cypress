import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import {
  CommonGetLocators,
  defaultTimeOut,
  InvokeAttributes,
  InvokeMethods,
  ShouldMethods,
  SortOrder,
  TriggerAttributes,
  YesOrNo,
} from '../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';

import { AppErrorMessages } from '../../../support/common-core-libs/application/constants/app-errors.constants';

import {
  Implant,
  Medication,
} from '../../../test-data-models/sis-office/trackers/inv-reconciliation.model';
import { PatientDetails } from '../../../test-data-models/sis-office/case/patient-case.model';

import { OR_INVENTORY_RECONCILIATION } from './or/inv-reconciliation.or';
import { OR_NURSING_CONFIGURATION } from '../../shared/application-settings/or/nursing-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { CoreCssClasses } from '../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';
import { Supplies } from '../../../test-data-models/shared/application-settings/application-settings.model';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';
import { InventoryReconciliationApi } from './api/inventory-reconciliation.api';
import { LabelHeaders } from './enums/inv-reconciliation.enum';
import { SupplyHeaders } from '../../shared/application-settings/enums/nursing-configuration.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();

/**
 * Class for InventoryReconciliation
 */
export default class InventoryReconciliation {
  /* instance variables */
  private inventoryReconApis = new InventoryReconciliationApi();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  // CommonLayoutPage
  private sisOfficeDesktop: SISOfficeDesktop;
  // Object Repositories For Inventory Reconciliation
  private orInvReconciliation =
    OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION;
  // Object Repositories for Medication Layout
  private orMedicationsTable =
    OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
      .MEDICATIONS_TABLE;

  /**
   * @details - Self Initialization For PatientInfo, implantInfo,supplyInfo and medicationInfo
   * @details - Page Initialization For commonLayoutPage
   * @param patientInfo
   * @param implantInfo
   * @param supplyInfo
   * @param medicationInfo
   */
  constructor(
    private patientInfo: PatientDetails,
    private implantInfo?: Implant[],
    private medicationInfo?: Medication[]
  ) {
    this.sisOfficeDesktop = new SISOfficeDesktop();
  }

  /**
   * exposing patientInfo to client
   */
  get patientModel(): PatientDetails {
    return this.patientInfo;
  }

  /**
   * exposing implantInfo to client
   */
  get implantModel(): Implant[] | undefined {
    return this.implantInfo;
  }

  /**
   * @details - exposing medicationInfo to client
   */
  get medicationModel(): Medication[] | undefined {
    return this.medicationInfo;
  }

  /**
   * @details - select Patient Row
   * @API - API's are available - Implemented Completely
   * @author Shobhan
   */
  selectPatientRow() {
    const patientName = `${this.patientInfo.LastName}, ${this.patientInfo.PatientFirstName} `;
    const logicalName =
      this.orInvReconciliation.INVENTORY_RECONCILIATION_TABLE.PATIENT_NAME[0];
    const interceptCollection =
      this.inventoryReconApis.interceptSelectPatientApis();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.selectPatientRow(patientName, logicalName);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - select MRN Row
   * @API - API's are not available
   */
  selectMRN() {
    let MRN = `${this.patientInfo.MRN}`;
    let logicalName =
      this.orInvReconciliation.INVENTORY_RECONCILIATION_TABLE.MRN[0];
    this.sisOfficeDesktop.selectPatientRow(MRN, logicalName);
  }

  /**************Implant Related Methods****************************** */

  /**
   * @details - Verify Implants Appear On Screen
   * @param implantName - passing implant name
   * @param rowSequence - passing implant row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyImplantsAppearOnScreen(implantName: string, rowSequence: number = 0) {
    const logicalName =
      this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.IMPLANTS[0];
    cy.cGet(selectorFactory.getDivText(implantName), logicalName)
      .eq(rowSequence)
      .should(ShouldMethods.visible);
  }

  /**
   * @details - type Used Value For Implant
   * @param implantName
   * @param value
   * @API - API's are not available
   */
  enterUsedValueForImplant(implantName: string, value: any) {
    let selector =
      selectorFactory.inputBoxAgainstGivenLabelAndDataTestIdInTableRow(
        implantName,
        this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.USED[1]
      );
    let logicalName = this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.USED[0];
    cy.cType(selector, logicalName, value);
  }

  /**
   * @details - select Implant
   * @param implantName - passing implant name
   * @param rowSequence - passing implant row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectImplant(implantName: string, rowSequence: number = 0) {
    const selector = selectorFactory.getAText(implantName);
    const logicalName =
      this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.IMPLANTS[0];

    cy.cGet(selector, logicalName)
      .eq(rowSequence)
      .should(ShouldMethods.visible)
      .click();
    cy.shouldBeEnabled(
      this.orInvReconciliation.INVENTORY.ADD_IMPLANTS_PROSTHETIC_POPUP.NOTES[1]
    );
    cy.cIsVisible(
      selectorFactory.getH3Text(
        this.orInvReconciliation.INVENTORY.ADD_IMPLANTS_PROSTHETIC_POPUP
          .POPUP_NAME[0]
      ),
      this.orInvReconciliation.INVENTORY.ADD_IMPLANTS_PROSTHETIC_POPUP
        .POPUP_NAME[0]
    );
  }

  /**
   * @details - Verify Value For Given Implant Name
   * @param implantName
   * @param value
   * @API - API's are not available
   */
  verifyUsedValueForImplant(implantName: string, value: any) {
    let selector =
      selectorFactory.inputBoxAgainstGivenLabelAndDataTestIdInTableRow(
        implantName,
        this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.USED[1]
      );
    let logicalName = this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.USED[0];

    cy.cHasValue(selector, logicalName, value);
  }

  /**
   * @details - Click On Done Button On Add Implant And Prosthetic Pop Up
   * @API - API's are not available
   */
  clickAddImplantProstheticDoneBtn() {
    let addImplantsProstheticPopUpSchema =
      this.orInvReconciliation.INVENTORY.ADD_IMPLANTS_PROSTHETIC_POPUP;
    let selector = addImplantsProstheticPopUpSchema.DONE_BUTTON[1];
    let logicalName = addImplantsProstheticPopUpSchema.DONE_BUTTON[0];

    cy.cClick(selector, logicalName);
  }

  /**
   * @details - Add Information Implant Or Prosthetic Pop Up
   * @param quantity
   * @param size
   * @param lot
   * @param serial
   * @param expiration
   * @param reference
   * @param notes
   * @API - API's are not available
   */
  addImplantOrProstheticInfo(impRecord: Implant) {
    let prostheticPopupObject =
      this.orInvReconciliation.INVENTORY.ADD_IMPLANTS_PROSTHETIC_POPUP;
    let selectorQty = prostheticPopupObject.QUANTITY[1];
    let logicalNameQty = prostheticPopupObject.QUANTITY[0];
    let selectorSize = prostheticPopupObject.SIZE[1];
    let logicalNameSize = prostheticPopupObject.SIZE[0];
    let selectorLot = prostheticPopupObject.LOT_NO[1];
    let logicalNameLot = prostheticPopupObject.LOT_NO[0];
    let selectorSerial = prostheticPopupObject.SERIAL_NO[1];
    let logicalNameSerial = prostheticPopupObject.SERIAL_NO[0];
    let selectorExpiration = prostheticPopupObject.EXPIRATION[1];
    let logicalNameExpiration = prostheticPopupObject.EXPIRATION[0];
    let selectorReference = prostheticPopupObject.REFERENCE_NO[1];
    let logicalNameLReference = prostheticPopupObject.REFERENCE_NO[0];
    let selectorNotes = prostheticPopupObject.NOTES[1];
    let logicalNameNotes = prostheticPopupObject.NOTES[0];
    // Set Quantity
    cy.cType(selectorQty, logicalNameQty, impRecord.Used);
    // Set Size
    cy.cType(selectorSize, logicalNameSize, impRecord.Size);
    // Set lot
    cy.cType(selectorLot, logicalNameLot, impRecord.Lot);
    // Set serial
    cy.cType(selectorSerial, logicalNameSerial, impRecord.Serial);
    // Set Expiration
    cy.cType(selectorExpiration, logicalNameExpiration, impRecord.Expiration);
    // Set Reference
    cy.cType(selectorReference, logicalNameLReference, impRecord.Reference);
    // Set Notes
    cy.cType(selectorNotes, logicalNameNotes, impRecord.Notes);
  }

  /**
   * @details - Verify Information Implant And Prosthetic Popup
   * @param quantity
   * @param size
   * @param lot
   * @param serial
   * @param expiration
   * @param reference
   * @param notes
   * @API - API's are not available
   */
  verifyImplantOrProstheticInfo(impRecord: Implant) {
    let prostheticPopupObject =
      this.orInvReconciliation.INVENTORY.ADD_IMPLANTS_PROSTHETIC_POPUP;
    let selectorQty = prostheticPopupObject.QUANTITY[1];
    let logicalNameQty = prostheticPopupObject.QUANTITY[0];
    let selectorSize = prostheticPopupObject.SIZE[1];
    let logicalNameSize = prostheticPopupObject.SIZE[0];
    let selectorLot = prostheticPopupObject.LOT_NO[1];
    let logicalNameLot = prostheticPopupObject.LOT_NO[0];
    let selectorSerial = prostheticPopupObject.SERIAL_NO[1];
    let logicalNameSerial = prostheticPopupObject.SERIAL_NO[0];
    let selectorExpiration = prostheticPopupObject.EXPIRATION[1];
    let logicalNameExpiration = prostheticPopupObject.EXPIRATION[0];
    let selectorReference = prostheticPopupObject.REFERENCE_NO[1];
    let logicalNameLReference = prostheticPopupObject.REFERENCE_NO[0];
    let selectorNotes = prostheticPopupObject.NOTES[1];
    let logicalNameNotes = prostheticPopupObject.NOTES[0];
    // Verify Quantity
    cy.cHasValue(selectorQty, logicalNameQty, impRecord.Used);
    // Verify Size
    cy.cHasValue(selectorSize, logicalNameSize, impRecord.Size);
    // Verify lot
    cy.cHasValue(selectorLot, logicalNameLot, impRecord.Lot);
    // Verify serial
    cy.cHasValue(selectorSerial, logicalNameSerial, impRecord.Serial);
    // Verify Expiration
    cy.cHasValue(
      selectorExpiration,
      logicalNameExpiration,
      impRecord.Expiration
    );
    // Verify Reference
    cy.cHasValue(selectorReference, logicalNameLReference, impRecord.Reference);
    // Verify Notes
    cy.cHasValue(selectorNotes, logicalNameNotes, impRecord.Notes);
  }

  /*************Implant APIs Ends************************8 */
  /***********Medications Related Methods**************** */

  /**
   * @details - enter value in medication Administered text box
   * @param medicationName
   * @param value
   * @param rowSequence
   * @API - API's are not available
   */
  enterAdministeredValueForMedications(
    medicationName: string,
    value: any,
    rowSequence?: number
  ) {
    this.sisOfficeDesktop.typeOnTabularInput(
      medicationName,
      `${this.orMedicationsTable.ADMINISTERED[1]}`,
      this.orMedicationsTable.ADMINISTERED[0],
      value,
      rowSequence
    );
  }

  /**
   * @details - verify Administered value For Medication
   * @param medicationName
   * @param value
   * @param rowSequence
   * @API - API's are not available
   */
  verifyAdministeredValueForMedications(
    medicationName: string,
    value: any,
    rowSequence?: number
  ) {
    this.sisOfficeDesktop.verifyValueOnTabularInput(
      this.orMedicationsTable.ADMINISTERED[1],
      this.orMedicationsTable.ADMINISTERED[0],
      value,
      medicationName,
      rowSequence
    );
  }

  /**
   * @details - enter value in medication Wasted Text Box
   * @param medicationName
   * @param value
   * @param rowSequence
   * @API - API's are not available
   */
  enterWastedValueForMedications(
    medicationName: string,
    value: any,
    rowSequence?: number
  ) {
    this.sisOfficeDesktop.typeOnTabularInput(
      medicationName,
      `${this.orMedicationsTable.WASTED[1]}`,
      this.orMedicationsTable.WASTED[0],
      value,
      rowSequence
    );
  }

  /**
   * @details - verify Wasted Value For Medication
   * @param medicationName
   * @param value
   * @param rowSequence
   * @API - API's are not available
   */
  verifyWastedValueForMedications(
    medicationName: string,
    value: any,
    rowSequence?: number
  ) {
    this.sisOfficeDesktop.verifyValueOnTabularInput(
      this.orMedicationsTable.WASTED[1],
      this.orMedicationsTable.WASTED[0],
      value,
      medicationName,
      rowSequence
    );
  }

  /**
   * @details - enter value in medication Total Value Input Box
   * @param medicationName
   * @param value
   * @param rowSequence
   * @API - API's are not available
   */
  enterUsageTotalValueForMedications(
    medicationName: string,
    value: any,
    rowSequence?: number
  ) {
    this.sisOfficeDesktop.typeOnTabularInput(
      medicationName,
      `${this.orMedicationsTable.USAGE_TOTAL[1]}`,
      this.orMedicationsTable.USAGE_TOTAL[0],
      value,
      rowSequence
    );
  }

  /**
   * @details - verify Usage Total Value For Medication
   * @param medicationName
   * @param value
   * @param rowSequence
   * @API - API's are not available
   */
  verifyUsageTotalValueForMedication(
    medicationName: string,
    value: any,
    rowSequence?: number
  ) {
    this.sisOfficeDesktop.verifyValueOnTabularInput(
      this.orMedicationsTable.USAGE_TOTAL[1],
      this.orMedicationsTable.USAGE_TOTAL[0],
      value,
      medicationName,
      rowSequence
    );
  }

  /**
   * @details - enter all or any of administer, wasted and Usage Total Value For Medication
   * @param medicationInfo
   * @param rowSequence
   * @API - API's are not available
   */
  enterMedicationInfo(medicationInfo: Medication, rowSequence?: number) {
    if (medicationInfo.InventoryMedication?.Administered) {
      this.sisOfficeDesktop.typeOnTabularInput(
        medicationInfo.Medication!,
        `${this.orMedicationsTable.ADMINISTERED[1]}`,
        this.orMedicationsTable.ADMINISTERED[0],
        medicationInfo.InventoryMedication?.Administered,
        rowSequence
      );
    }
    if (medicationInfo.SisChartsMedication?.Wasted) {
      this.sisOfficeDesktop.typeOnTabularInput(
        medicationInfo.Medication!,
        `${this.orMedicationsTable.WASTED[1]}`,
        this.orMedicationsTable.WASTED[0],
        medicationInfo.SisChartsMedication?.Wasted,
        rowSequence
      );
    }
    if (medicationInfo.InventoryMedication?.UsageTotal) {
      this.sisOfficeDesktop.typeOnTabularInput(
        medicationInfo.Medication!,
        `${this.orMedicationsTable.USAGE_TOTAL[1]}`,
        this.orMedicationsTable.USAGE_TOTAL[0],
        medicationInfo.InventoryMedication?.UsageTotal,
        rowSequence
      );
    }
  }

  /**
   * @details - verify all or any of administer, wasted and Usage Total Value For Medication
   * @param medicationInfo
   * @param rowSequence
   * @API - API's are not available
   */
  verifyMedicationInfo(medicationInfo: Medication, rowSequence?: number) {
    if (medicationInfo.InventoryMedication?.Administered) {
      this.sisOfficeDesktop.verifyValueOnTabularInput(
        this.orMedicationsTable.ADMINISTERED[1],
        this.orMedicationsTable.ADMINISTERED[0],
        medicationInfo.InventoryMedication?.Administered,
        medicationInfo.Medication!,
        rowSequence
      );
    }
    if (medicationInfo.SisChartsMedication?.Wasted) {
      this.sisOfficeDesktop.verifyValueOnTabularInput(
        this.orMedicationsTable.WASTED[1],
        this.orMedicationsTable.WASTED[0],
        medicationInfo.SisChartsMedication?.Wasted,
        medicationInfo.Medication!,
        rowSequence
      );
    }
    if (medicationInfo.InventoryMedication?.UsageTotal) {
      this.sisOfficeDesktop.verifyValueOnTabularInput(
        this.orMedicationsTable.USAGE_TOTAL[1],
        this.orMedicationsTable.USAGE_TOTAL[0],
        medicationInfo.InventoryMedication?.UsageTotal,
        medicationInfo.Medication!,
        rowSequence
      );
    }
  }

  /**
   * @details - Select DOS records in descending order in Inventory Reconciliation
   * @API - API's are not available
   */
  selectDOSRecordsInDescendingOrder() {
    cy.cIsVisible(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION
        .INVENTORY_RECONCILIATION_TABLE.DEPLETE_SELECTED_BUTTON[1],
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION
        .INVENTORY_RECONCILIATION_TABLE.DEPLETE_SELECTED_BUTTON[0]
    );
    cy.cGet(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION
        .INVENTORY_RECONCILIATION_TABLE.SORTABLE_COL_ICON[1]
    ).then(($ele) => {
      let sortedOrder = $ele.attr(InvokeAttributes.aria_sort);
      if (sortedOrder === SortOrder.ascending) {
        cy.cClick(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION
            .INVENTORY_RECONCILIATION_TABLE.SORTABLE_COL_ICON[1],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION
            .INVENTORY_RECONCILIATION_TABLE.SORTABLE_COL_ICON[0],
          false,
          true
        );
      }
    });
  }

  /**
   * @details - Add implant or prosthetic in inventory reconciliation tracker
   * @param - implantInfo refers ImplantModel
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectImplantInAddImplantPopUp(implantInfo: Implant) {
    this.clickAddImplantProstheticBtn();
    this.addImplantInImplantProstheticPopUp(implantInfo);
  }

  /**
   * @details - To click on the clear icon in Implants.
   * @param implant - passing implant name
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clickImplantsClearIcon(implant: string) {
    cy.cGet(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .IMPLANTS_TABLE.IMPLANTS_DATA[1]
    ).each(($rowsData) => {
      cy.wrap($rowsData).then(($data) => {
        if ($data.text().includes(implant)) {
          cy.wrap($data).then(() => {
            cy.cClick(
              OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
                .IMPLANTS_TABLE.IMPLANTS_CLEAR_ICON[1],
              OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
                .IMPLANTS_TABLE.IMPLANTS_CLEAR_ICON[1],
              false,
              false,
              { force: true }
            );
          });
        }
      });
    });
  }

  /**
   * @details - Click Add Implant or Prosthetic Button in Inventory Tracker
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clickAddImplantProstheticBtn() {
    cy.cClick(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .IMPLANTS_TABLE.ADD_IMPLANTS_PROSTHETIC_BUTTON[1],
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .IMPLANTS_TABLE.ADD_IMPLANTS_PROSTHETIC_BUTTON[0]
    );
    cy.shouldBeEnabled(
      this.orInvReconciliation.INVENTORY.ADD_IMPLANTS_PROSTHETIC_POPUP.NOTES[1]
    );
    cy.cIsVisible(
      selectorFactory.getH3Text(
        OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
          .ADD_IMPLANTS_PROSTHETIC_POPUP.POPUP_NAME[0]
      ),
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.POPUP_NAME[0]
    );
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the Inventory Reconciliation tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptInventoryReconciliationTrackerApi();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify Depletion Warning message Tooltip Text for Patient Case in Inventory Reconciliation Tracker
   * @param patientName - passing patient first name as argument
   * @param warningType - passing warning type
   * @param isVisible - passing true or false
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyDepletionWarningMessage(
    patientName: string,
    warningType: string,
    isVisible: boolean = true
  ) {
    const warningVerificationType =
      warningType === this.orInvReconciliation.INVENTORY.FREE_TEXT_ITEM[0]
        ? AppErrorMessages.inventory_free_text_warning
        : AppErrorMessages.inventory_reconcile_warning;

    if (isVisible == true) {
      cy.cGet(selectorFactory.getWarningExclamatoryIcon(patientName))
        .should(ShouldMethods.visible)
        .trigger(TriggerAttributes.mouseenter);
      /**
       * Waiting for Tooltip Text Locator to attach to DOM
       */
      cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
        timeout: Cypress.config(defaultTimeOut),
      }).should(ShouldMethods.visible);
      cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
        .invoke(InvokeMethods.show)
        .should(ShouldMethods.text, warningVerificationType);
      cy.cGet(selectorFactory.getWarningExclamatoryIcon(patientName)).trigger(
        TriggerAttributes.mouseleave
      );
      cy.cWaitForElementToDisappear(
        CoreCssClasses.ToolTipText.loc_p_tooltip_text,
        CoreCssClasses.ToolTipText.loc_p_tooltip_text
      );
    } else {
      cy.cNotExist(
        selectorFactory.getWarningExclamatoryIcon(patientName),
        patientName
      );
    }
  }

  /**
   * @details - Verify Implant Details in Inventory Reconciliation Tracker
   * @param implantInfo - as model reference passed as argument inside the function
   * @param rowSequence - passing implant row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyImplantsInInventory(implantInfo: Implant, rowSequence: number = 0) {
    this.verifyImplantsAppearOnScreen(implantInfo.Implant!);
    this.verifyImplantDetails(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .IMPLANTS_TABLE.TOTAL_DEPLETED[0],
      implantInfo.Implant!,
      implantInfo.TotalDepleted!,
      rowSequence
    );
    this.verifyImplantDetails(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .IMPLANTS_TABLE.USED[0],
      implantInfo.Implant!,
      implantInfo.Used!,
      rowSequence
    );
    this.verifyImplantDetails(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .IMPLANTS_TABLE.BILLED[0],
      implantInfo.Implant!,
      implantInfo.Billed!,
      rowSequence
    );
    this.selectImplant(implantInfo.Implant!);
    this.verifyImplantOrProstheticInfo(implantInfo);
    this.clickAddImplantProstheticDoneBtn();
  }

  /**
   * @details - Verify Total Depleted, Used, Billed Value For Given Implant Name
   * @param implantHeader - passing Used, Billed, Total Depleted as a Header
   * @param implantName - Implant Name is passed
   * @param value - Used, Billed, Total Depleted Value for an Implant is passed
   * @param rowSequence - passing implant row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyImplantDetails(
    implantHeader: string,
    implantName: string,
    value: string | number,
    rowSequence: number = 0
  ) {
    const implantProperties = {
      [this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.TOTAL_DEPLETED[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(implantName),
          ' ',
          this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.TOTAL_DEPLETED[1]
        ),
        ShouldMethods.text,
      ],
      [this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.USED[0]]: [
        selectorFactory.inputBoxAgainstGivenLabelAndDataTestIdInTableRow(
          implantName,
          this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.USED[1]
        ),
        ShouldMethods.value,
      ],
      [this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.BILLED[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(implantName),
          ' ',
          this.orInvReconciliation.INVENTORY.IMPLANTS_TABLE.BILLED[1]
        ),
        ShouldMethods.text,
      ],
    };

    cy.cGet(implantProperties[implantHeader][0])
      .eq(rowSequence)
      .should(implantProperties[implantHeader][1], value);
  }

  /**
   * @details - Verify Supply Details in Inventory Reconciliation Tracker
   * @param supplyInfo - passing supply info like supply name, pulled, used, wasted, defective, billed, total depleted
   * @param rowSequence - passing supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifySuppliesInInventory(supplyInfo: Supplies, rowSequence: number = 0) {
    const sisChartsSupply = supplyInfo.SisChartsSupply!;
    const inventorySupply = supplyInfo.InventorySupply!;
    let supplyKeyDetails: string;

    this.verifySuppliesAppearOnScreen(supplyInfo.SupplyName!);
    this.verifySupplyDetails(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .SUPPLIES_TABLE.TOTAL_DEPLETED[0],
      supplyInfo.SupplyName!,
      inventorySupply.TotalDepleted!,
      rowSequence
    );
    Object.entries(sisChartsSupply).forEach((entry) => {
      const [key, value] = entry;

      supplyKeyDetails =
        key === SupplyHeaders.pulled
          ? OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
              .SUPPLIES_TABLE.PULLED[0]
          : key === SupplyHeaders.used
          ? OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
              .SUPPLIES_TABLE.USED[0]
          : key === SupplyHeaders.wasted
          ? OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
              .SUPPLIES_TABLE.WASTED[0]
          : OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
              .SUPPLIES_TABLE.DEFECTIVE[0];
      this.verifySupplyDetails(
        supplyKeyDetails,
        supplyInfo.SupplyName!,
        value,
        rowSequence
      );
    });
    this.verifySupplyDetails(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .SUPPLIES_TABLE.BILLED[0],
      supplyInfo.SupplyName!,
      inventorySupply.Billed!,
      rowSequence
    );
  }

  /**
   * @details - Verify Supply Name Appear On Screen
   * @param supplyName - passing supply name
   * @param rowSequence - passing supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifySuppliesAppearOnScreen(supplyName: string, rowSequence: number = 0) {
    const logicalName =
      this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.SUPPLIES[0];

    cy.cGet(selectorFactory.getSpanText(supplyName), logicalName)
      .eq(rowSequence)
      .should(ShouldMethods.visible);
  }

  /**
   * @details - Verify Total Depleted, Pulled, Used, Wasted, Defective, Billed Value For Given Supply Name
   * @param supplyHeader - passing supply name, pulled, used, wasted , defective, billed as a header
   * @param supplyName - passing supply name
   * @param value - passing pulled, used, wasted , defective, billed as a value
   * @param rowSequence - passing supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifySupplyDetails(
    supplyHeader: string,
    supplyName: string,
    value: string | number,
    rowSequence: number = 0
  ) {
    const supplyProperties = {
      [this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.TOTAL_DEPLETED[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(supplyName),
          ' ',
          this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.TOTAL_DEPLETED[1]
        ),
        ShouldMethods.text,
      ],
      [this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.PULLED[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(supplyName),
          ' ',
          this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.PULLED[1]
        ),
        ShouldMethods.text,
      ],
      [this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.USED[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(supplyName),
          ' ',
          this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.USED[1]
        ),
        ShouldMethods.value,
      ],
      [this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.WASTED[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(supplyName),
          ' ',
          this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.WASTED[1]
        ),
        ShouldMethods.value,
      ],
      [this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.DEFECTIVE[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(supplyName),
          ' ',
          this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.DEFECTIVE[1]
        ),
        ShouldMethods.value,
      ],
      [this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.BILLED[0]]: [
        CommonUtils.concatenate(
          selectorFactory.getTrText(supplyName),
          ' ',
          this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.BILLED[1]
        ),
        ShouldMethods.text,
      ],
    };

    cy.cGet(supplyProperties[supplyHeader][0])
      .eq(rowSequence)
      .should(supplyProperties[supplyHeader][1], value);
  }

  /**
   * @details - Verify Tooltip Text for Inventory Item in Inventory Reconciliation Tracker
   * @param inventoryType - passing supply or implant as a header
   * @param logicalName - passing supply or implant logical name
   * @param inventoryItemName - passing inventory name
   * @param itemNumber - passing inventory item item number coming form ios
   * @param manufacturerNumber - passing inventory item manufacturer number coming form ios
   * @param rowSequence - passing implant or supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyTooltipTextForInventoryItem(
    inventoryType: string,
    logicalName: string,
    inventoryItemName: string,
    itemNumber?: string,
    manufacturerNumber?: string,
    rowSequence: number = 0
  ) {
    const inventoryTypeLoc =
      inventoryType ===
      this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.SUPPLIES[0]
        ? selectorFactory.getInventorySupply(inventoryItemName)
        : selectorFactory.getInventoryImplant(inventoryItemName);
    const inventoryTooltipText =
      logicalName === this.orInvReconciliation.INVENTORY.FREE_TEXT_ITEM[0]
        ? inventoryItemName
        : logicalName ===
          this.orInvReconciliation.INVENTORY.IOS_TEXT_ITEM_WITH_MANUFACTURER[0]
        ? selectorFactory.getInventoryToolTipTextWithManufacturer(
            inventoryItemName,
            itemNumber!,
            manufacturerNumber!
          )
        : selectorFactory.getInventoryToolTipTextWithOutManufacturer(
            inventoryItemName,
            itemNumber!
          );

    cy.cGet(inventoryTypeLoc)
      .eq(rowSequence)
      .trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.text, inventoryTooltipText);
    cy.cGet(inventoryTypeLoc)
      .eq(rowSequence)
      .trigger(TriggerAttributes.mouseleave);
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      CoreCssClasses.ToolTipText.loc_p_tooltip_text
    );
  }

  /**
   * @details - Verify Free Text Tooltip For Given Implant or Supply Name
   * @param freeTextName - passing free text name
   * @param inventoryType - passing supply or implant as a header
   * @param rowSequence - passing implant or supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyFreeTextToolTipText(
    freeTextName: string,
    inventoryType: string,
    rowSequence: number = 0
  ) {
    const freeTextToolTip =
      inventoryType ===
      this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.SUPPLIES[0]
        ? selectorFactory.getSupplyFreeTextToolTipIcon(freeTextName)
        : selectorFactory.getImplantFreeTextToolTipIcon(freeTextName);

    cy.cGet(freeTextToolTip)
      .eq(rowSequence)
      .prev(CoreCssClasses.Icon.loc_exclamation)
      .should(ShouldMethods.visible)
      .trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.text, AppErrorMessages.inventory_free_text_tooltip);
    cy.cGet(freeTextToolTip)
      .eq(rowSequence)
      .prev(CoreCssClasses.Icon.loc_exclamation)
      .trigger(TriggerAttributes.mouseleave);
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      CoreCssClasses.ToolTipText.loc_p_tooltip_text
    );
  }

  /**
   * @details - Add Implant in Add Implant Prosthetic PopUp
   * @param implantInfo - as model reference passed as argument inside the function
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  addImplantInImplantProstheticPopUp(implantInfo: Implant) {
    cy.cClick(
      selectorFactory.getH3Text(
        OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
          .ADD_IMPLANTS_PROSTHETIC_POPUP.POPUP_NAME[0]
      ),
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.POPUP_NAME[0]
    );
    const interceptCollection = this.inventoryReconApis.interceptAddSupplyApi();
    cy.cIntercept(interceptCollection);
    cy.cClear(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.MANUFACTURER[1]
    );
    cy.cType(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.IMPLANT_SEARCH[1],
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.IMPLANT_SEARCH[0],
      implantInfo.Implant!
    );
    cy.cWaitApis(interceptCollection);
    cy.shouldBeEnabled(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.ENTERED_IMPLANT_NAME[1]
    );
    cy.cClick(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.ENTERED_IMPLANT_NAME[1],
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.ENTERED_IMPLANT_NAME[0],
      false,
      true
    );
    cy.cClick(
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.IMPLANT_MFD_NAME[1],
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .ADD_IMPLANTS_PROSTHETIC_POPUP.IMPLANT_MFD_NAME[0]
    );
  }

  /**
   * @details - Select Supply
   * @param supplyName - passing supply name
   * @param rowSequence - passing supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  selectSupply(supplyName: string, rowSequence: number = 0) {
    const selector = selectorFactory.getSpanText(supplyName);
    const logicalName =
      this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.SUPPLIES[0];

    cy.cGet(selector, logicalName)
      .eq(rowSequence)
      .should(ShouldMethods.visible)
      .click();
  }

  /**
   * @details - Click Supply Input Text Box
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clearSupplyFreeText() {
    cy.cClear(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .INVENTORY_FREE_TEXT[1]
    );
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .INVENTORY_FREE_TEXT[1],
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .SUPPLIES_AND_INSTRUMENTS.SUPPLY[0]
    );
  }

  /**
   * @details - Click KeyBoard Icon for Supply Input Box
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clickSupplyKeyBoardIcon() {
    cy.cClick(
      CommonUtils.concatenate(
        CommonGetLocators.i,
        CoreCssClasses.Icon.loc_keyboard_icon
      ),
      this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.KEY_BOARD_ICON[0],
      false,
      true
    );
  }

  /**
   * @details - Verify Original Free Text Description after converting from Free Text to IOS Inventory Implant or Supply
   * @param inventoryType - passing implant or supply as an header
   * @param freeTextName - passing implant or supply free text name
   * @param iosInventoryName - passing implant or supply name
   * @param rowSequence - passing implant or supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyOriginalFreeTextDescription(
    inventoryType: string,
    freeTextName: string,
    iosInventoryName: string,
    rowSequence: number = 0
  ) {
    const freeTextToolTip =
      inventoryType ===
      this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.SUPPLIES[0]
        ? selectorFactory.getSupplyFreeTextToolTipIcon(iosInventoryName)
        : selectorFactory.getImplantFreeTextToolTipIcon(iosInventoryName);

    cy.cGet(freeTextToolTip)
      .eq(rowSequence)
      .prev(CoreCssClasses.Button.loc_fa_info_circle)
      .should(ShouldMethods.visible)
      .trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(
        ShouldMethods.text,
        selectorFactory.getInventoryOriginalFreeTextDescription(freeTextName)
      );
    cy.cGet(freeTextToolTip)
      .eq(rowSequence)
      .prev(CoreCssClasses.Button.loc_fa_info_circle)
      .trigger(TriggerAttributes.mouseleave);
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      CoreCssClasses.ToolTipText.loc_p_tooltip_text
    );
  }

  /**
   * @details - Click Depletion Verified as Yes or No Option and Done button in Inventory Reconciliation Tracker
   * @param yesOrNoOption - passing Yes or no option as argument
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  selectDepletionVerifiedAndDone(yesOrNoOption: string) {
    cy.cClick(selectorFactory.getSpanText(yesOrNoOption), yesOrNoOption);
    const interceptCollection =
      this.inventoryReconApis.interceptSelectDepletionDoneApis();
    cy.cIntercept(interceptCollection);

    sisOfficeDesktop.clickDoneButton();

    if (yesOrNoOption === YesOrNo.yes) {
      cy.cWaitApis(interceptCollection);
    } else {
      cy.cWaitApis(interceptCollection);
    }
  }

  /**
   * @details - Add Supply in Inventory Reconciliation Tracker
   * @param supplyName - passing supply name
   * @param rowSequence - passing supply row
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  addSupply(supplyName: string, rowSequence: number = 0) {
    const interceptCollection = this.inventoryReconApis.interceptAddSupplyApi();
    cy.cIntercept(interceptCollection);
    cy.cGet(
      OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.RESOURCES
        .INVENTORY_IOS_TEXT[1]
    )
      .eq(rowSequence)
      .clear()
      .type(supplyName);
    cy.cWaitApis(interceptCollection);
    cy.cGet(selectorFactory.getSpanText(supplyName)).eq(rowSequence).click();
  }

  /**
   * @details - Select Depletion Verified Yes or No and click on Update Button In Inventory Face-Sheet
   * @param yesOrNoOption - To Pass Yes or No Value
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  selectDepletionVerifiedAndUpdate(yesOrNoOption: string) {
    const updateButton = CommonUtils.concatenate(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.UPDATE_BUTTON[1],
      ' ',
      selectorFactory.getSpanText(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.UPDATE_BUTTON[0]
      )
    );
    const depletionVerified =
      yesOrNoOption === YesOrNo.yes
        ? OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .DEPLETION_VERIFIED_YES[1]
        : OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .DEPLETION_VERIFIED_NO[1];

    cy.cClick(depletionVerified, yesOrNoOption, false, true);
    cy.shouldBeEnabled(updateButton);
    const interceptCollection =
      this.inventoryReconApis.interceptSelectDepletionUpdateApis();
    cy.cIntercept(interceptCollection);
    cy.cClick(updateButton, OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.UPDATE_BUTTON[0]);
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Verify Update or New Label with Tooltip Text for Inventory Item in Inventory Reconciliation Tracker
   * @param inventoryType - passing supply or implant as an header
   * @param inventoryItem - passing inventory name
   * @param label - passing new or update label for inventory item
   * @param rowSequence - passing implant or supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyInventoryItemLabel(
    inventoryType: string,
    inventoryItem: string,
    label: string,
    rowSequence: number = 0
  ) {
    const inventoryTypeDetail =
      inventoryType ===
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .SUPPLIES_TABLE.SUPPLIES[0]
        ? selectorFactory.getSupplyLabelToolTipText(inventoryItem, label)
        : selectorFactory.getImplantLabelToolTipText(inventoryItem, label);
    const inventoryLabelToolTipText =
      label === LabelHeaders.update
        ? AppErrorMessages.inventory_update_label
        : AppErrorMessages.inventory_new_label;

    cy.cGet(inventoryTypeDetail)
      .eq(rowSequence)
      .trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.text, inventoryLabelToolTipText);
    cy.cGet(inventoryTypeDetail)
      .eq(rowSequence)
      .trigger(TriggerAttributes.mouseleave);
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      CoreCssClasses.ToolTipText.loc_p_tooltip_text
    );
  }

  /**
   * @details - Verify Triangle Exclamatory Icon for Patient Case in Inventory Reconciliation Tracker
   * @param patientName - passing patient first name as argument
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyTriangleExclamatoryIcon(patientName: string) {
    cy.cGet(selectorFactory.getTriangleExclamatoryIcon(patientName))
      .should(ShouldMethods.visible)
      .trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(
        ShouldMethods.text,
        AppErrorMessages.inventory_triangle_exclamatory
      );
    cy.cGet(selectorFactory.getTriangleExclamatoryIcon(patientName)).trigger(
      TriggerAttributes.mouseleave
    );
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      CoreCssClasses.ToolTipText.loc_p_tooltip_text
    );
  }

  /**
   * @details - Verify Discrepancy Warning Message for Inventory Item where Used quantity and billed quantity are not same
   * @param inventoryName - passing supply or implant name
   * @param isVisible - to verify discrepancy message is visible or not
   * @param rowSequence - passing implant or supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyDiscrepancyWarningForInventoryItem(
    inventoryName: string,
    isVisible: boolean = true,
    rowSequence: number = 0
  ) {
    isVisible
      ? cy
          .cGet(selectorFactory.getInventoryDiscrepancyMessage(inventoryName))
          .eq(rowSequence)
          .should(ShouldMethods.visible)
          .should(
            ShouldMethods.contain_text,
            AppErrorMessages.inventory_discrepancy_warning
          )
      : cy.cNotExist(
          selectorFactory.getInventoryDiscrepancyMessage(inventoryName),
          inventoryName
        );
  }

  /**
   * @details - Enter Used Quantity for Supply
   * @param supplyName - passing supply name
   * @param value - passing used value for supply
   * @param rowSequence - passing supply row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  enterUsedQuantityForSupply(
    supplyName: string,
    value: number,
    rowSequence: number = 0
  ) {
    const usedLoc = CommonUtils.concatenate(
      selectorFactory.getTrText(supplyName),
      ' ',
      this.orInvReconciliation.INVENTORY.SUPPLIES_TABLE.USED[1]
    );

    cy.cGet(usedLoc).eq(rowSequence).clear().type(value.toString());
  }

  /**
   * @details - verify Total Depleted Value For Medication
   * @param medicationName - passing medication name
   * @param value - passing depleted value
   * @param rowSequence - passing medication row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyTotalDepletedValueForMedication(
    medicationName: string,
    value: string | number,
    rowSequence: number = 0
  ) {
    let medicationDetails: string;

    (medicationDetails = CommonUtils.concatenate(
      selectorFactory.getTrText(medicationName),
      ' ',
      this.orMedicationsTable.TOTAL_DEPLETED[1]
    )),
      cy
        .cGet(medicationDetails)
        .eq(rowSequence!)
        .should(ShouldMethods.text, value);
  }

  /**
   * @details - verify Billed Value For Medication
   * @param medicationName - passing medication name
   * @param value - passing billed value
   * @param rowSequence - passing medication row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyBilledValueForMedication(
    medicationName: string,
    value: string | number,
    rowSequence: number = 0
  ) {
    let medicationDetails: string;

    (medicationDetails = CommonUtils.concatenate(
      selectorFactory.getTrText(medicationName),
      ' ',
      this.orMedicationsTable.BILLED[1]
    )),
      cy
        .cGet(medicationDetails)
        .eq(rowSequence!)
        .should(ShouldMethods.text, value);
  }

  /**
   * @details - Verify Tooltip Text for Medication Inventory Item in Inventory Reconciliation Tracker
   * @param medicationName - passing medication Name
   * @param logicalName - passing medication with manufacturer or without manufacturer logical name
   * @param inventoryItemName - passing inventory linked ios name
   * @param itemNumber - passing inventory item item number coming form ios
   * @param manufacturerNumber - passing inventory item manufacturer number coming form ios
   * @param rowSequence - passing medication row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyTooltipTextForMedicationInventoryItem(
    medicationName: string,
    logicalName: string,
    inventoryItemName: string,
    itemNumber?: string,
    manufacturerNumber?: string,
    rowSequence: number = 0
  ) {
    const inventoryTypeLoc = selectorFactory.getInventorySupply(medicationName);
    const inventoryTooltipText =
      logicalName ===
      this.orInvReconciliation.INVENTORY.IOS_TEXT_ITEM_WITH_MANUFACTURER[0]
        ? selectorFactory.getInventoryToolTipTextWithManufacturer(
            inventoryItemName,
            itemNumber!,
            manufacturerNumber!
          )
        : selectorFactory.getInventoryToolTipTextWithOutManufacturer(
            inventoryItemName,
            itemNumber!
          );

    cy.cGet(inventoryTypeLoc)
      .eq(rowSequence)
      .trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.text, inventoryTooltipText);
    cy.cGet(inventoryTypeLoc)
      .eq(rowSequence)
      .trigger(TriggerAttributes.mouseleave);
    cy.cWaitForElementToDisappear(
      CoreCssClasses.ToolTipText.loc_p_tooltip_text,
      CoreCssClasses.ToolTipText.loc_p_tooltip_text
    );
  }

  /**
   * @details - Click on Clear Icon for an Inventory Item
   * @param inventoryName - passing inventory Name
   * @param rowSequence - passing inventory item row
   * @API - API's are not available
   * @author - Sai Swarup
   */
  clearInventoryDiscrepancyIcon(
    inventoryName: string,
    rowSequence: number = 0
  ) {
    const clearIconLoc = CommonUtils.concatenate(
      selectorFactory.getTrText(inventoryName),
      ' ',
      CommonGetLocators.td,
      ' ',
      CommonGetLocators.i,
      CoreCssClasses.Icon.loc_clear_icon
    );

    cy.cGet(clearIconLoc).eq(rowSequence).trigger(TriggerAttributes.mouseenter);
    /**
     * Waiting for Tooltip Text Locator to attach to DOM
     */
    cy.get(CoreCssClasses.ToolTipText.loc_p_tooltip_text, {
      timeout: Cypress.config(defaultTimeOut),
    }).should(ShouldMethods.visible);
    cy.cGet(CoreCssClasses.ToolTipText.loc_p_tooltip_text)
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.text, AppErrorMessages.clear_discrepancy_warning);
    cy.cGet(clearIconLoc)
      .eq(rowSequence)
      .trigger(TriggerAttributes.click)
      .should(ShouldMethods.not_exist);
    sisOfficeDesktop.clickPatientSearchIcon();
    this.verifyDiscrepancyWarningForInventoryItem(inventoryName, false);
  }

  /**
   * @details - Verify Banner Icon and Banner Message in Face-Sheet Inventory Tab when Patient is not discharged and Send Inventory Feature is Enable
   * @param option - pass header text as an option
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyBannerMessageInFaceSheet(option: string) {
    const bannerMessage =
      option === AppErrorMessages.patient_discharge_and_inventory_not_available
        ? AppErrorMessages.inventory_banner_message_no_inventory_details
        : AppErrorMessages.inventory_banner_message_send_inventory_upon_patient_discharge;

    cy.cIsVisible(
      this.orInvReconciliation.INVENTORY.DEPLETION_VERIFIED_NO[1],
      this.orInvReconciliation.INVENTORY.DEPLETION_VERIFIED_NO[0]
    );
    cy.shouldBeEnabled(this.orInvReconciliation.INVENTORY.BANNER_ICON[1]);
    cy.cIsVisible(
      this.orInvReconciliation.INVENTORY.BANNER_ICON[1],
      this.orInvReconciliation.INVENTORY.BANNER_ICON[0]
    );
    cy.cGet(this.orInvReconciliation.INVENTORY.BANNER_TEXT[1])
      .invoke(InvokeMethods.show)
      .should(ShouldMethods.text, bannerMessage);
  }

  /**
   * @details - Verify Supplies, Implant, Medications are not visible in Inventory Tracker or Face-sheet Inventory
   * @param inventoryType - Passing Supply, Medication, Implant as a header
   * @param inventoryName - Passing inventory name
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyInventoryItemsNotAppearOnScreen(
    inventoryType: string,
    inventoryName: string
  ) {
    const inventoryNameLoc =
      inventoryType ===
      OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
        .SUPPLIES_TABLE.SUPPLIES[0]
        ? selectorFactory.getSpanText(inventoryName)
        : inventoryType ===
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        ? selectorFactory.getDivText(inventoryName)
        : selectorFactory.getSpanText(inventoryName);

    cy.cNotExist(inventoryNameLoc, inventoryName);
  }
}
