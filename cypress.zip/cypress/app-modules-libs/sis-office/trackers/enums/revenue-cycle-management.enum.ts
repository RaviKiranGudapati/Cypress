export enum ShowMoreLess {
  show_defaults = 'Show Defaults',
  hide_defaults = 'Hide Defaults',
}
export enum RefreshClearFilters {
  refresh = 'Refresh',
  clear_Filters = 'Clear Filters',
}
export enum DropDown {
  responsible_party = 'Responsible Party',
  insurance_plan_type = 'Insurance Plan Type',
  rcm_status = 'Rcm Status',
  claim_status = 'Claim Status',
  denials = 'Denials',
  denial_reason = 'Denial Reason',
  aging_type = 'Aging Type',
  aging_category = 'Aging Category',
  payer_role = 'Payer Role',
  insurance_classification = 'Insurance Classification',
  appointment_type = 'Appointment Type',
  physician = 'Physician',
}
export enum ShowHidePayments {
  show_payments = 'Show Payments',
  hide_payments = 'Hide Payments',
}
