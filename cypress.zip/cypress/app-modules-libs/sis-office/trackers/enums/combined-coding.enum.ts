export enum ChargeAdjustment {
  charge = 'Charge',
  adjustment = 'Adjustment',
  modifier = 'Modifier',
  cpt = 'CPT® Code or HCPCS Code',
  ndc = 'NDC #',
  base_units = 'Base Units',
  units_of_measure = 'Unit of Measure',
  write_off_amount = 'Write-off amount',
}

export enum CodingPopUpText {
  select_period = 'Please select a period before posting charges.',
  select_batch = 'Please select or create a new batch before posting charges.',
}

export enum HoverText {
  clinical_trial_number = 'This field can also be used for a demonstration project identifier.',
}
