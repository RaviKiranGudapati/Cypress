import {
  ExpandOrCollapse,
  ShouldMethods,
} from '../../../support/common-core-libs/application/common-core';
import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import SISOfficeDesktop from '../../../support/common-core-libs/application/sis-office-desktop';
import { CommonUtils } from '../../../support/common-core-libs/framework/common-utils';

import {
  SubRoutes,
  WaitMethods,
} from '../../../support/common-core-libs/application/constants/sub-routes.constants';

import { CasesToCodeDetails } from '../../../test-data-models/sis-office/trackers/cases-to-code.model';
import { Cpt } from '../../../test-data-models/sis-office/case/patient-case.model';
import { PatientCase } from '../../../test-data-models/sis-office/case/patient-case.model';
import { Implant } from '../../../test-data-models/sis-office/trackers/inv-reconciliation.model';

import { OR_SIS_OFFICE_DESKTOP } from '../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_CASES_TO_CODE } from './or/cases-to-code.or';
import { OR_CHARGE_ENTRY } from './or/charge-entry.or';

import { ImplantHeaders, SupplyHeaders } from '../../shared/application-settings/enums/nursing-configuration.enum';

import { SisOfficeDesktopApis } from '../../../support/common-core-libs/application/api/sis-office-desktop.api';
import { CasesToCodeApis } from './api/cases-to-code.api';

export default class CasesToCode {
  /* instance variables */
  private casesToCodeApis = new CasesToCodeApis();
  private sisOfficeDesktopApis = new SisOfficeDesktopApis();

  private sisOfficeDesktop = new SISOfficeDesktop();

  /**
   * @details - Self Initialization For NewPatientInfo, cptData
   * @details - Page Initialization For Sis Office Desktop Page
   * @param patientCaseInfo
   */
  constructor(private patientCaseInfo: PatientCase) {
    this.sisOfficeDesktop = new SISOfficeDesktop();
  }

  get patientCaseModel(): PatientCase | undefined {
    return this.patientCaseInfo;
  }

  /**
   * @details - perform Cases To Code
   * @param - casesToCodeDetails
   * @APIs are available - Completely Implemented
   * @Author - Rakesh Donakonda
   */
  performCasesToCode(casesToCodeDetails: CasesToCodeDetails) {
    this.addSelectedToPerformed();
    this.selectDiagnosisCode(casesToCodeDetails);
  }

  /**
   * @details To add the procedure in Case To Code
   * @param cptData as model reference to pass in the function
   * @APIs are available - Completely Implemented
   * @author - Rakesh Donakonda
   */
  addProcedureCaseToCode(cptData: Cpt) {
    const interceptCollection =
      this.casesToCodeApis.interceptSearchProcedureApi();
    this.addSelectedToPerformed();
    cy.cClick(
      OR_CASES_TO_CODE.CODING.ADD_PROCEDURE[1],
      OR_CASES_TO_CODE.CODING.ADD_PROCEDURE[0]
    );
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_CASES_TO_CODE.CODING.PROCEDURE_DESCRIPTION[1],
      OR_CASES_TO_CODE.CODING.PROCEDURE_DESCRIPTION[0],
      cptData.CPTCodeAndDescription
    );
    cy.cWaitApis(interceptCollection);
    cy.cIsVisible(
      selectorFactory.getTextInLimitTextContainer(
        cptData.CPTCodeAndDescription
      ),
      cptData.CPTCodeAndDescription
    );
    cy.cSelectListItem(
      OR_CASES_TO_CODE.CODING.PROCEDURE_SELECTION[1],
      OR_CASES_TO_CODE.CODING.PROCEDURE_SELECTION[0],
      cptData.CPTCodeAndDescription
    );
  }

  /**
   * @details To select the diagnosis code in Case To Code page
   * @param casesToCodeDetails as model reference in function
   * @APIs are available - Completely Implemented
   * @author - Rakesh Donakonda
   */
  selectDiagnosisCode(casesToCodeDetails: CasesToCodeDetails) {
    const interceptSearchDiagnosisApiCollection =
      this.casesToCodeApis.interceptSearchDiagnosisApi();
    cy.cGet(OR_CASES_TO_CODE.CODING.PERFORMED_CASES_PANEL[1]).each(
      ($element) => {
        if (
          $element
            .text()
            .indexOf(
              this.patientCaseInfo.CaseDetails?.CptCodeInfo![0]
                .CPTCodeAndDescription!
            ) > -1
        ) {
          cy.wrap($element)
            .first()
            .within(() => {
              cy.cClick(
                OR_CASES_TO_CODE.CODING.EXPAND_PLUS_ICON[1],
                OR_CASES_TO_CODE.CODING.EXPAND_PLUS_ICON[0]
              );
              cy.cIntercept(interceptSearchDiagnosisApiCollection);
              cy.cType(
                OR_CASES_TO_CODE.CODING.SEARCH_DIAGNOSIS_CODE[1],
                OR_CASES_TO_CODE.CODING.SEARCH_DIAGNOSIS_CODE[0],
                casesToCodeDetails.DiagnosisCode
              );
              cy.cWaitApis(interceptSearchDiagnosisApiCollection);
              cy.cGet(OR_CASES_TO_CODE.CODING.DIAGNOSIS_CODE_LIST[1])
                .parent()
                .click();
              cy.cClick(
                OR_CASES_TO_CODE.CODING.EXPAND_MINUS_ICON[1],
                OR_CASES_TO_CODE.CODING.EXPAND_MINUS_ICON[0]
              );
            });
        }
      }
    );
    cy.cClick(
      OR_CASES_TO_CODE.CODING.READY_FOR_CHARGE_YES_BUTTON[1],
      OR_CASES_TO_CODE.CODING.READY_FOR_CHARGE_YES_BUTTON[0]
    );
    /**
     * if statusCode is passed in cy.intercept then it getting passed
     */
    const interceptClickDoneApiCollection =
      this.casesToCodeApis.interceptClickDoneApi();
    cy.cIntercept(interceptClickDoneApiCollection);
    cy.intercept(WaitMethods.post, SubRoutes.post_set_user_preferences_list, {
      statusCode: 204,
    }).as('Testt');
    this.sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptClickDoneApiCollection);
    /**
     * has used hard coded cy.intercept above, hence used hard coded wait
     */
    cy.wait('@Testt').its('response.statusCode').should(ShouldMethods.eq, 204);
  }

  /**
   * @details To click on the Add Selected To Performed button in Case To Code
   * @APIs are available - Completely Implemented
   * @author - Harsh Ranjan
   */
  addSelectedToPerformed() {
    const interceptSelectCaseButtonApiCollection =
      this.casesToCodeApis.interceptSelectCaseButtonApi();
    this.sisOfficeDesktop.selectTracker(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CASES_TO_CODE[0]
    );
    cy.cIntercept(interceptSelectCaseButtonApiCollection);
    this.sisOfficeDesktop.selectPatientRow(
      this.patientCaseInfo.PatientDetails.LastName!,
      this.patientCaseInfo.PatientDetails.PatientFirstName!
    );
    cy.cWaitApis(interceptSelectCaseButtonApiCollection);
    cy.cGet(OR_CASES_TO_CODE.CODING.SCHEDULED_PROCEDURES_LIST[1])
      .should(ShouldMethods.visible)
      .then(() => {
        cy.cClick(
          OR_CASES_TO_CODE.CODING.SELECT_ALL_SCHEDULE_PROCEDURES[1],
          OR_CASES_TO_CODE.CODING.SELECT_ALL_SCHEDULE_PROCEDURES[0]
        );
      });
    const interceptAddSelectedToPerformButtonApiCollection =
      this.casesToCodeApis.interceptAddSelectedToPerformButtonApi();
    cy.cIntercept(interceptAddSelectedToPerformButtonApiCollection);
    cy.cClick(
      OR_CASES_TO_CODE.CODING.ADD_SELECTED_TO_PERFORMED[1],
      OR_CASES_TO_CODE.CODING.ADD_SELECTED_TO_PERFORMED[0]
    );
    cy.cWaitApis(interceptAddSelectedToPerformButtonApiCollection);
  }

  /**
   * @details - Select SIS Logo for navigating to business desktop page, added apis call of the case to code tracker
   * @API - API's are available - Implemented Completely
   * @author - Vamshi
   */
  selectSisLogo() {
    const interceptCollection =
      this.sisOfficeDesktopApis.interceptCasesToCodeTrackerApi();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.selectSisLogo();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @detail - Expand Collapse Procedure In Performed Items Based On CPT
   * @param option - pass expand or collapse option
   * @param cptCode - pass procedure cpt code
   */
  expandCollapseProcedureInPerformedItemsBasedOnCPT(
    option: string,
    cptCode: string
  ) {
    cy.cGet(OR_CASES_TO_CODE.CODING.PERFORMED_CASES_PANEL[1]).each(
      ($element) => {
        if ($element.text().indexOf(cptCode) > -1) {
          cy.wrap($element).within(() => {
            const plusMinus =
              option.toUpperCase() === ExpandOrCollapse.expand
                ? OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS.EXPAND_PLUS_ICON
                : OR_CHARGE_ENTRY.CHARGE_ENTRY.PERFORMED_ITEMS
                    .EXPAND_MINUS_ICON;

            cy.cClick(plusMinus[1], plusMinus[0]);
          });
        }
      }
    );
  }

  /**
   * @details - Search and Select Diagnosis Code in the search box
   * @param casesToCodeDetails - Diagnosis Code Details
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  enterDiagnosisCode(casesToCodeDetails: CasesToCodeDetails) {
    const interceptCollection =
      this.casesToCodeApis.interceptDiagnosisCodeApi();
    cy.cIntercept(interceptCollection);
    cy.cType(
      OR_CASES_TO_CODE.CODING.SEARCH_DIAGNOSIS_CODE[1],
      OR_CASES_TO_CODE.CODING.SEARCH_DIAGNOSIS_CODE[0],
      casesToCodeDetails.DiagnosisCode
    );
    cy.cWaitApis(interceptCollection);
    cy.cGet(OR_CASES_TO_CODE.CODING.DIAGNOSIS_CODE_LIST[1]).parent().click();
  }

  /**
   * @detail - Verify Units In Performed Items Based On CPT
   * @param units - inventory or procedure item units
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyUnits(units: number) {
    cy.cHasValue(
      OR_CASES_TO_CODE.CODING.UNITS[1],
      OR_CASES_TO_CODE.CODING.UNITS[0],
      units
    );
  }

  /**
   * @details - To type HCPCS value
   * @param value - HCPCS Value for inventory or procedure item
   * @API - API's are not available
   * @author - Sai Swarup
   */
  enterHcpcs(value: string) {
    cy.cType(
      OR_CASES_TO_CODE.CODING.HCPCS[1],
      OR_CASES_TO_CODE.CODING.HCPCS[0],
      value
    );
    this.sisOfficeDesktop.clickPatientSearchIcon();
  }

  /**
   * @details - Verify Implant Details under Documentation Section
   * @param implantInfo - Implant Details like Implant Name, Manufacturer, Quantity, Size, Lot, Serial, Expiration, Reference, Notes
   * @param rowSequence - Implant Row in Documentation Section
   * @API - API's are not available
   * @author - Sai Swarup
   */
  verifyDocumentationImplantDetails(
    implantInfo: Implant,
    rowSequence: number = 0
  ) {
    const implantHeaderDetails = new Map<string, string>([
      [SupplyHeaders.notes, OR_CASES_TO_CODE.CODING.DOCUMENTATION.NOTES[1]],
      [
        ImplantHeaders.reference,
        OR_CASES_TO_CODE.CODING.DOCUMENTATION.REFERENCE[1],
      ],
      [
        ImplantHeaders.expiration,
        OR_CASES_TO_CODE.CODING.DOCUMENTATION.EXPIRATION[1],
      ],
      [
        ImplantHeaders.serial,
        OR_CASES_TO_CODE.CODING.DOCUMENTATION.SERIAL_NO[1],
      ],
      [ImplantHeaders.lot, OR_CASES_TO_CODE.CODING.DOCUMENTATION.LOT_NO[1]],
      [ImplantHeaders.size, OR_CASES_TO_CODE.CODING.DOCUMENTATION.SIZE[1]],
      [
        ImplantHeaders.manufacturer,
        OR_CASES_TO_CODE.CODING.DOCUMENTATION.MANUFACTURER[1],
      ],
      [
        ImplantHeaders.implant,
        OR_CASES_TO_CODE.CODING.DOCUMENTATION.IMPLANT_PROSTHETIC[1],
      ],
    ]);

    Object.entries(implantInfo).forEach((entry) => {
      const [key, value] = entry;

      if (CommonUtils.isDefinedAndNotEmpty(value)) {
        const documentationImplant = implantHeaderDetails.get(key);

        if (documentationImplant) {
          cy.cGet(
            selectorFactory.getDocumentationImplantDetails(
              implantInfo.Implant!,
              documentationImplant
            )
          )
            .eq(rowSequence)
            .should(ShouldMethods.contain_text, value);
        }
      }
    });
  }

  /**
   * @detail - Click Ready For Charge Yes Button and Done Button
   * @API - API's are available and Implemented Completely
   * @author - Sai Swarup
   */
  clickReadyForChargeAndDoneButton() {
    cy.cClick(
      OR_CASES_TO_CODE.CODING.READY_FOR_CHARGE_YES_BUTTON[1],
      OR_CASES_TO_CODE.CODING.READY_FOR_CHARGE_YES_BUTTON[0]
    );
    const interceptCollection =
      this.casesToCodeApis.interceptClickReadyForChargeAndDoneButtonApi();
    cy.cIntercept(interceptCollection);
    this.sisOfficeDesktop.clickDoneButton();
    cy.cWaitApis(interceptCollection);
  }

  /**
   * @details - Modify Units In Performed Items Based On CPT
   * @param units - inventory or procedure item units
   * @API - API's are not available
   * @author - Sai Swarup
   */
  enterUnits(units: number) {
    cy.cType(
      OR_CASES_TO_CODE.CODING.UNITS[1],
      OR_CASES_TO_CODE.CODING.UNITS[0],
      units
    );
  }
}
