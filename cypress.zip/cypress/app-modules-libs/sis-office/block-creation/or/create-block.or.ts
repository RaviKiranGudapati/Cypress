/* Revision history
11/22/2022, Arushi, removed unused locators
*/

import { CoreCssClasses } from '../../../../support/common-core-libs/core-css-classes';
import { CommonUtils } from '../../../../support/common-core-libs/framework/common-utils';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../support/common-core-libs/application/or/sis-office-desktop.or';

export const OR_BLOCK_CREATION = {
  CREATE_A_BLOCK: {
    CREATE_A_BLOCK_TAB: ['create a block', 'a#CreateBlock'],
    BLOCK_NAME_LABEL: [
      'Block Name',
      CommonUtils.concatenate(
        ':nth-child(1) > :nth-child(1) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    BLOCK_NAME: ['Block Name', '#blockName'],
    EXISTING_BLOCK_NAME_DROPDOWN: [
      'Block Name Dropdown',
      '#blockRecurrenceDropdown',
    ],
    PHYSICIAN: ['Physician', '[data-test-id^="staffMultiSelect"]'],
    THE_MONTH: ['The month', '#btn_daysList_multiselect'],
    DATE_LABEL: [
      'Date',
      CommonUtils.concatenate(
        ':nth-child(2) > :nth-child(1) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    DATE: ['Date', '#blockDateCalendar input'],
    ROOM_LABEL: [
      'Room',
      CommonUtils.concatenate(
        ':nth-child(2) > :nth-child(2) > ',
        CoreCssClasses.Label.loc_control_label,
        ' > ',
        CoreCssClasses.Text.loc_warning_text
      ),
    ],
    ROOM: [
      'Room dropdown',
      CommonUtils.concatenate(
        '#blockRooms',
        ' ',
        CoreCssClasses.MultiSelect.loc_p_multiselect_label_container,
        ' ',
        CoreCssClasses.MultiSelect.loc_p_multiselect_label
      ),
    ],
    START_TIME: ['Start Time', '#txtMaskStartTime input'],
    END_TIME: ['End Time', '#txtMaskEndTime input'],
    LESS_END_TIME: [
      'End Time',
      CommonUtils.concatenate(
        CoreCssClasses.Text.loc_warning_text,
        CoreCssClasses.Ng.loc_star_inserted,
        ' >',
        CoreCssClasses.Ng.loc_star_inserted
      ),
    ],
    SPECIALTY: [
      'Specialty',
      CommonUtils.concatenate(
        '#blockSpecialities > ',
        CoreCssClasses.PrimeNg.loc_single_select,
        CoreCssClasses.Ng.loc_untouched,
        ' > ',
        CoreCssClasses.DropDown.loc_p_dropdown
      ),
    ],
    BLOCK_OUT: ['Yes', '#sbtnBlockOut'],
    LOSS_OF_DATA: [
      'Yes',
      CommonUtils.concatenate(
        '[label="Yes"] > ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],
    NO_LOSS_OF_DATA: [
      'Yes',
      CommonUtils.concatenate(
        '[label="No"] > ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],
    DONE_BUTTON: [
      'Done',
      CommonUtils.concatenate(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[1],
        ' > ',
        CoreCssClasses.Button.loc_button_label
      ),
    ],
    NEW_BLOCK_INSTANCE: ['New Block Instance', '*.section-padding'],
    NEW_AND_EXISTING_BLOCK_TOGGLE_BUTTON: {
      NEW_BLOCK: [
        'New Block',
        CommonUtils.concatenate(
          CoreCssClasses.Ng.loc_valid,
          ' > ',
          CoreCssClasses.Button.loc_select_button,
          ' > [aria-pressed="false"] > ',
          CoreCssClasses.Button.loc_button_label
        ),
      ],
      EXISTING_BLOCK: [
        'Existing Block',
        CommonUtils.concatenate(
          '#sbtnNewBlockTab > ',
          CoreCssClasses.Ng.loc_untouched,
          ' > ',
          CoreCssClasses.Button.loc_select_button,
          ' > [aria-pressed="false"] > ',
          CoreCssClasses.Button.loc_button_label
        ),
      ],
    },
  },
};
