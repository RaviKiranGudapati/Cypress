import { selectorFactory } from '../../../support/common-core-libs/framework/selector-factory';
import { OR_NURSING_CONFIGURATION } from '../../shared/application-settings/or/nursing-configuration.or';

export default class BlockSchedule {
  /**
   * @description Verify Duplicate Blocks
   * @param blockName
   * @param index
   */
  verifyDuplicateBlocks(blockName: string, index: number) {
    cy.cIsVisible(
      selectorFactory.blockTitleInBlockSchedule(index, blockName),
      blockName
    );
  }

  /**
   * @description Verify click on schedule grid
   * @param blockName
   */
  verifyBlockAndClick(blockName: string, index: number) {
    cy.cClick(
      selectorFactory.blockTitleInBlockSchedule(2, blockName),
      blockName
    );
  }

  /**
   * @description click on block verify block out Room Closed popup
   */
  verifyRoomClosed() {
    cy.cIsVisible(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_CLOSE[1],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_CLOSE[0]
    );
    cy.cClick(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OK_BUTTON[1],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OK_BUTTON[0]
    );
  }

  /**
   * @description click on cross icon in create block Instance
   */
  clickOnCrossIcon() {
    cy.cClick(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.CROSS_ICON[1],
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.CROSS_ICON[0]
    );
  }
}
