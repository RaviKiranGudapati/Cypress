import '../shared/enterprise-configuration/cbo-views-facility-management-tcid-270825.spec.ts';
import '../shared/enterprise-configuration/cbo-views-cbo-management-tcid-270826.spec.ts';