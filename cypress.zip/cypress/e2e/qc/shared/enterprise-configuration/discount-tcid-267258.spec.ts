import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseDiscountTcId267258 } from './scenarios/tcid-267258.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseDiscountConfig = new EnterpriseDiscountTcId267258();

/*****************Test Script Validation Details **********************
 * * Verify Discounts option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name
 * 3. Verify Discounts feature is displaying under Enterprise Build section.
 * 4. Verify Dictionaries and Configuration tab were visible at Enterprise settings >Facility Management tab
 * 5. Select Discounts, verify Search field, Add button and default text message is displaying.
 * 6. Click on Add button and verify the Add popup window fields like helper text, Cancel and Done button.
 * 7. Click on Add button and add new code, hit cancel button. Verify the cancelled Discounts is not saved.
 * 8. Again Add new Discount by hitting done button and verify the newly added code is saved.
 * 9. Search and select the newly added code and verify the Transaction code,WriteOff group code and writeOff Reason code dropdown values.
 * 10.Navigate to Facility Management and verify Discounts under Configuration tab.
 * 11.Verify Include Enterprise Items and Allow Add to Configuration column hover text message.
 * 12.Verify the default behavior of Include Enterprise Items and Allow Add to Configuration.
 * 13.Select 'Yes' toggle from Include Enterprise Items and verify Allow Add to Configuration is set to 'Yes' automatically.
 */

describe(
  'Verify new feature Discounts under Configuration tab and Enterprise Build',
  {
    tags: ['enterprise-configuration', 'US#237466', 'TC#267258'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseDiscountConfig.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseDiscountConfig.verifyDiscountFeatureUnderEnterpriseBuild();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
