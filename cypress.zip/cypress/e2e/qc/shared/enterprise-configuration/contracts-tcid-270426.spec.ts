import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { EnterpriseContractsTcId270426 } from './scenarios/tcid-270426.sc';

/* instance variables */
const enterpriseContracts = new EnterpriseContractsTcId270426();

/*****************Test Script Validation Details **********************
 * * Verify Discounts option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name.
 * 3. Verify Contracts feature is displaying under Enterprise Build section.
 * 4. Ensure shared Fee schedule and transaction code are available.
 * 5. Add new Contract, document Effective date, Expire date and Contract Type(Grouper) dropdown
 * 6. Document posting options dropdown fields and verify warning text
 * 7. Select Index as 0 and enter reimbursement amount as $10.00
 * 8. Under Review/Edit tab, select the index value to shared procedure under details column dropdown
 * 9. Verify the Dropdown values under Type header in Review/Edit
 * 10.Verify the Contract Type dropdown is disabled and user cannot modify the type dropdown
 * 11.Modify Reimbursement data and change dropdown values
 * 12.Verify the updated Reimbursement amount under Details header in Review/Edit
 * 13.Check the Duplicate error message in add popup by adding existing contract
 * 14.Check duplicate warning by adding existing contract in name field and verify disable states of fields
 * 15.Verify the functionality of create copy in Add popup
 * 16.Check that a copy of previously added contract is populated
 */

describe(
  'Verify new feature Discounts under Configuration tab and Enterprise Build',
  {
    tags: ['enterprise-configuration', 'US#237466', 'TC#267258'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed

    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseContracts.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseContracts.verifyGrouperTypAtEnterprise();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
