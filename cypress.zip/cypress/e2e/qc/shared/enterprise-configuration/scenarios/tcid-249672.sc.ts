import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ShowOrHide,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_dictionary_tcid_249672 } from '../../../../../fixtures/shared/enterprise-configuration/dictionary-tcid-249672.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import { HelperText } from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();

export class EnterPriseDictionaryTcId249672 {
  verifyDictionaryEnableFeature() {
    describe('To verify the availability of Enterprise build and UI of Dictionary', () => {
      it('Verifying Dictionary visibility in Enterprise Build as per Internal tab settings and and ui verification', () => {
        // #region - Navigating to the enterprise location, selecting organization under facility management settings

        cy.cGroupAsStep(
          'Navigating to the enterprise location, selecting organization under facility management settings'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_1
        );

        // #end region

        // #region -Clicking on internal tab and verifying whether enterprise build is visible by default and then verifying after enabling it

        cy.cGroupAsStep(
          'Clicking on the internal tab and verifying the enterprise build visibility'
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifyEnterpriseBuild(false);

        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        enterpriseConfig.verifyEnterpriseBuild();
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
            .DICTIONARY_LABEL[0]
        );

        // #end region

        // #region -Select dictionaries from enterprise builds and add dictionary items for Insurance Plan Type dictionary.

        cy.cGroupAsStep(
          'Select dictionaries from enterprise builds and add dictionary items'
        );
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
            .DICTIONARY_LABEL[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
            .DICTIONARY_LABEL[0]
        );
        enterpriseConfig.selectDictionaryInDictionaries();
        enterpriseConfig.verifyDictionariesHelperText(
          HelperText.dictionaries_insurance_plan_type
        );
        enterpriseConfig.verifyShowInactive();
        enterpriseConfig.addEnterpriseDictionaries(
          td_dictionary_tcid_249672.Dictionaries.DictionaryItems[0]
        );
        enterpriseConfig.addInactiveAndActiveDictItem(
          YesOrNo.no,
          td_dictionary_tcid_249672.Dictionaries.DictionaryItems[0]
        );
        // Removed verification step as verify warning message is already added in add Dictionary method
        enterpriseConfig.renameDictionaryItem(
          td_dictionary_tcid_249672.Dictionaries.DictionaryItems[2]
        );
        enterpriseConfig.addEnterpriseDictionaries(
          td_dictionary_tcid_249672.Dictionaries.DictionaryItems[1]
        );
        enterpriseConfig.addEnterpriseDictionaries(
          td_dictionary_tcid_249672.Dictionaries.DictionaryItems[3]
        );
        // #endregion

        // #region -Navigating to facility management,selecting the desired facility and verifying the options visibility and the default toggle behaviour of the options

        cy.cGroupAsStep(
          'Navigating to facility management and selecting an organization,verifying the options visibility and the default toggle behaviour of the options'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_1
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.DICTIONARIES
            .DICTIONARIES_TAB[0]
        );
        enterpriseConfig.verifyColumnsInDictionariesTab();
        enterpriseConfig.verifyMouseHoverTextInDictionariesTab();
        enterpriseConfig.verifyDefaultBehaviorToggleSwitch(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DICTIONARY
            .ENTERPRISE_DICTIONARIES[0]
        );

        // #endregion
      });
    });
  }
}
