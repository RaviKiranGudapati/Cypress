import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ShowOrHide,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';
import { DoneOrCancel } from '../../../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_contracts_tcid_270425 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-contracts-tcid-270425.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import {
  adjustmentTime,
  defaultWriteOffGroupCode,
  defaultWriteOffReasonCode,
  grouperTypeColumnsInReviewEdit,
  reviewTypeOptionsUnderProcedures,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';
import {
  AddNewOrCreateCopy,
  ContractHeaders,
} from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfiguration = new EnterpriseConfiguration();

/* const values */
const copyContractName1 = CommonUtils.concatenate(
  'Copy of',
  ' ',
  td_enterprise_config_contracts_tcid_270425.Contracts[4].ContractName
);
const copyContractName2 = CommonUtils.concatenate(
  'Copy of',
  ' ',
  td_enterprise_config_contracts_tcid_270425.Contracts[5].ContractName
);
const exemptOptionsInReviewEdit = [YesOrNo.yes, YesOrNo.no];

/**
 * In defaultWriteOffGroupCode, defaultWriteOffReasonCode there are six elements,
 * but in my case I have to validate first five elements, so using pop to skip last element
 */
defaultWriteOffGroupCode.pop();
defaultWriteOffReasonCode.pop();

export class EnterpriseContractsTcId270425 {
  precondition() {
    describe('Enable "Shared Dictionaries/Configurations" And verify Enterprise Build- Contracts', () => {
      it('Ensure shared Transaction codes, Fee schedule items are created and available at Enterprise ', () => {
        // #region - Change login location to Enterprise and enable Enterprise Build - Contracts from Add On Features

        cy.cGroupAsStep(
          'Enable contracts from Add On Features under Enterprise Build'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfiguration.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        // #endregion

        // #region - Set Shared Dictionaries/Configuration to 'Show' state

        cy.cGroupAsStep('Set Shared Dictionaries/Configuration to Show state');
        enterpriseConfiguration.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfiguration.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_1
        );
        enterpriseConfiguration.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfiguration.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        // #endregion

        // #region - Verifying Contracts feature under Enterprise Build

        cy.cGroupAsStep('Verifying Contracts feature under Enterprise Build');
        enterpriseConfiguration.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.verifyEnterpriseBuild(true);
        enterpriseConfiguration.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        // #endregion

        // #region - Adding transaction codes at Enterprise level

        cy.cGroupAsStep('Adding transactions codes at Enterprise Level');
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfiguration.addTransactionCode(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[0]
            .TransactionCodeOne!
        );
        enterpriseConfiguration.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfiguration.addTransactionCode(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[1]
            .TransactionCodeTwo!
        );
        enterpriseConfiguration.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfiguration.searchAndSelectTransactionCode(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[0]
            .TransactionCodeOne!
        );
        enterpriseConfiguration.selectTransactionCodeTypeItem(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[0].Type
        );
        enterpriseConfiguration.searchAndSelectTransactionCode(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[1]
            .TransactionCodeTwo!
        );
        enterpriseConfiguration.selectTransactionCodeTypeItem(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[1].Type
        );
        // #endregion

        // #region - Adding Fee Schedule at Enterprise Level

        cy.cGroupAsStep('Adding Fee Schedule at Enterprise Level ');
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270425.FeeSchedules[0]
        );
        enterpriseConfiguration.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270425.FeeSchedules[1]
        );
        // #endregion
      });
    });
  }

  verifyContractsCodeFeature() {
    describe('Verify Contracts functionality under Enterprise build', () => {
      it('Verify the Contracts options at Enterprise level', () => {
        // #region - Verify character limit for contract name field and notes field in contracts

        cy.cGroupAsStep(
          'Verify character limit for contract name field and notes field in contracts'
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[0],
          DoneOrCancel.done
        );
        enterpriseConfiguration.verifyMaxLengthOfContractName(80);
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[2],
          DoneOrCancel.done
        );
        enterpriseConfiguration.contractEffectiveDate(
          td_enterprise_config_contracts_tcid_270425.Contracts[2]
        );
        enterpriseConfiguration.contractExpirationDate(
          td_enterprise_config_contracts_tcid_270425.Contracts[2]
        );
        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270425.Contracts[2]
        );
        enterpriseConfiguration.addNotesInContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[0]
        );
        enterpriseConfiguration.verifyMaxLengthOfTextInContractNotes(500);
        enterpriseConfiguration.addNotesInContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[2]
        );
        enterpriseConfiguration.verifyWarningTextUnderPostingOptions();
        // #endregion

        // #region - Verify Transaction codes, Default group code and Default reason code under Posting options

        cy.cGroupAsStep(
          'Verify Transaction codes, Default group code and Default reason code under Posting options'
        );
        enterpriseConfiguration.enterContractPercentage(
          td_enterprise_config_contracts_tcid_270425
            .ProcedureDetailsInReviewEdit[0].Details
        );
        enterpriseConfiguration.selectAdjustmentTimeDropdown(adjustmentTime[0]);
        enterpriseConfiguration.verifyDefaultWriteOffTransactionCodeOptions([
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[0]
            .TransactionCodeOne!,
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[1]
            .TransactionCodeTwo!,
        ]);
        enterpriseConfiguration.verifyDefaultWriteOffGroupCodeOptions(
          defaultWriteOffGroupCode
        );
        enterpriseConfiguration.verifyDefaultWriteOffReasonCodeOptions(
          defaultWriteOffReasonCode
        );
        enterpriseConfiguration.selectDefaultWriteOffGroupCode(
          defaultWriteOffGroupCode[1]
        );
        enterpriseConfiguration.selectDefaultWriteOffReasonCode(
          defaultWriteOffReasonCode[1]
        );
        enterpriseConfiguration.selectDefaultWriteOffTransactionCode(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[0]
            .TransactionCodeOne!
        );
        // #endregion

        // #region - Verify the headers and procedure details under Review/Edit.

        cy.cGroupAsStep(
          'Verify the headers and procedure details under Review/Edit.'
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.verifyColumnsNameUnderReviewEdit(
          grouperTypeColumnsInReviewEdit
        );
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270425
            .ProcedureDetailsInReviewEdit[0]
        );
        // #endregion

        // #region - Verify type headers and exempt options under Review/Edit

        cy.cGroupAsStep(
          'Verify type headers and exempt options under Review/Edit'
        );
        enterpriseConfiguration.verifyTypeOptionsInReviewEdit(
          td_enterprise_config_contracts_tcid_270425.FeeSchedules[0]
            .CptProcedure,
          reviewTypeOptionsUnderProcedures
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.verifyExemptOptionsInReviewEdit(
          td_enterprise_config_contracts_tcid_270425.FeeSchedules[0]
            .CptProcedure,
          exemptOptionsInReviewEdit
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        // #endregion

        // #region - Verify the contract type is locked once the contract is saved and user navigates away and come back to same contract

        cy.cGroupAsStep(
          'Verify the contract type is locked once the contract is saved and user navigates away and come back to same contract'
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.searchAndSelectContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[1]
        );
        enterpriseConfiguration.searchAndSelectContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[2]
        );
        enterpriseConfiguration.selectConfigurationFirstTemplate();
        // #endregion

        // #region - Verifying the warning message when contract name modified with existing contact name

        cy.cGroupAsStep(
          'Verifying the warning message when contract name modified with existing contact name'
        );
        enterpriseConfiguration.enterContractPercentage(
          td_enterprise_config_contracts_tcid_270425
            .ProcedureDetailsInReviewEdit[1].Details
        );
        enterpriseConfiguration.selectDefaultWriteOffGroupCode(
          defaultWriteOffGroupCode[2]
        );
        enterpriseConfiguration.selectDefaultWriteOffReasonCode(
          defaultWriteOffReasonCode[2]
        );
        enterpriseConfiguration.selectDefaultWriteOffTransactionCode(
          td_enterprise_config_contracts_tcid_270425.TransactionCodes[1]
            .TransactionCodeTwo!
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );

        /**
         * The below lines code of should be uncommented once bug is fixed : BUG ID: 273485
         */
        // enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
        //   td_enterprise_config_contracts_tcid_270425
        //     .ProcedureDetailsInReviewEdit[1]
        // );

        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[2],
          DoneOrCancel.done
        );
        enterpriseConfiguration.duplicateWarningInContractAddPopup();
        // #endregion

        // #region - Verifying the effective date, expire date and contract type are disabled when contract is edited with existing contract name

        cy.cGroupAsStep(
          'Verifying the effective date, expire date and contract type are disabled when contract is edited with existing contract name'
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[3],
          DoneOrCancel.done
        );
        enterpriseConfiguration.contractEffectiveDate(
          td_enterprise_config_contracts_tcid_270425.Contracts[3]
        );
        enterpriseConfiguration.contractExpirationDate(
          td_enterprise_config_contracts_tcid_270425.Contracts[3]
        );

        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270425.Contracts[3]
        );
        enterpriseConfiguration.verifyWarningBannerByClearingOrDuplicateContractName(
          td_enterprise_config_contracts_tcid_270425.Contracts[2]
        );
        // #endregion

        // #region - Verifying the all fields are disabled under posting options when contract is edited with existing contract name

        cy.cGroupAsStep(
          'Verifying the all fields are disabled under posting options when contract is edited with existing contract name'
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfiguration.verifyStateOfPercentageOfBilledCharge(false);
        enterpriseConfiguration.verifyStateOfDefaultWriteOffReasonCode(false);
        enterpriseConfiguration.verifyStateOfDefaultWriteOffTransactionCode(
          false
        );
        enterpriseConfiguration.verifyStateOfDefaultWriteOffGroupCode(false);
        // #endregion

        // #region - Verify Type dropdown, Details and Exempt fields are disabled under Review/Edit.

        cy.cGroupAsStep(
          'Verify Type dropdown, Details and Exempt fields are disabled under Review/Edit'
        );

        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270425.FeeSchedules[0]
            .CptProcedure
        );
        enterpriseConfiguration.verifyStateOfTypeUnderReviewEdit(false);
        enterpriseConfiguration.verifyStateOfDetailsInputFieldUnderReviewEdit(
          false
        );
        enterpriseConfiguration.verifyStateOfExemptUnderReviewEdit(false);
        // #endregion

        // #region - Verify copy of previously added contract should be populated and the data is shown same as the contract

        cy.cGroupAsStep(
          'Verify copy of previously added contract should be populated and the data is shown same as the contract'
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[4],
          DoneOrCancel.done
        );
        enterpriseConfiguration.contractEffectiveDate(
          td_enterprise_config_contracts_tcid_270425.Contracts[4]
        );
        enterpriseConfiguration.contractExpirationDate(
          td_enterprise_config_contracts_tcid_270425.Contracts[4]
        );
        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270425.Contracts[4]
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.searchAndSelectContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[4]
        );
        enterpriseConfiguration.clickOnAddButton();

        enterpriseConfiguration.clickOnAddNewOrCreateCopy(
          AddNewOrCreateCopy.CreateCopy
        );
        enterpriseConfiguration.verifyDefaultSelectedContractOptionUnderCreateCopy(
          td_enterprise_config_contracts_tcid_270425.Contracts[4].ContractName
        );
        enterpriseConfiguration.verifyTextFieldUnderCreateCopy(
          copyContractName1
        );
        enterpriseConfiguration.editTextFieldUnderCreateCopy(
          td_enterprise_config_contracts_tcid_270425.Contracts[5].ContractName
        );
        enterpriseConfiguration.clickDoneOrCancelInAddContractPopUp(
          DoneOrCancel.done
        );
        enterpriseConfiguration.searchAndSelectContract(
          td_enterprise_config_contracts_tcid_270425.Contracts[5]
        );
        enterpriseConfiguration.verifyContractExist(
          td_enterprise_config_contracts_tcid_270425.Contracts[5]
        );
        enterpriseConfiguration.verifyContractNameField(
          td_enterprise_config_contracts_tcid_270425.Contracts[5]
        );
        enterpriseConfiguration.verifyContractType(
          td_enterprise_config_contracts_tcid_270425.Contracts[4].ContractType!
        );
        enterpriseConfiguration.clickOnAddButton();

        enterpriseConfiguration.clickOnAddNewOrCreateCopy(
          AddNewOrCreateCopy.CreateCopy
        );
        enterpriseConfiguration.verifyDefaultSelectedContractOptionUnderCreateCopy(
          td_enterprise_config_contracts_tcid_270425.Contracts[5].ContractName
        );
        enterpriseConfiguration.verifyTextFieldUnderCreateCopy(
          copyContractName2
        );
        // #endregion
      });
    });
  }
}
