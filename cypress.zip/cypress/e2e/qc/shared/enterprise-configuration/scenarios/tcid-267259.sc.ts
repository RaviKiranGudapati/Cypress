import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ShowOrHide,
  YesOrNo,
  DoneOrCancel,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_discount_tcid_2647259 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-discount-tcid-267259.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import {
  defaultWriteOffGroupCode,
  defaultWriteOffReasonCode,
  typeDropDownOptionValues,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();

/* const values */
const selectItem = 'Select Item';

export class EnterpriseDiscountTcId267259 {
  precondition() {
    describe('Enable "Shared Dictionaries/Configurations" And verify Enterprise Build-Discounts feature', () => {
      it('Verifying Enterprise Build-Discounts Feature and add Transaction codes ', () => {
        // #region -- Change login location to enterprise and Set Shared Dictionaries/Configuration to 'Show' state

        cy.cGroupAsStep(
          'Enable Shared Dictionaries/Configuration to Show state and Verifying Discount Feature under Enterprise Build'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_6
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        // #endregion

        // #region - verify Discount and Transaction Code under Enterprise Build

        cy.cGroupAsStep('Verify Enterprise Build Configurations');
        enterpriseConfig.verifyEnterpriseBuild(true);
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // #endregion

        // #region - Adding 2 new Transaction Codes at Enterprise

        cy.cGroupAsStep(
          'Two transaction codes are being added at the enterprise.'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues[0]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues[1]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        // #endregion
      });
    });
  }

  verifyDiscountFunctionUnderEnterpriseBuild() {
    describe('Verify Discounts Configuration feature functionality(Addition and updating) under Enterprise build', () => {
      it('Verify Addition, Updating of new Discount item & error message check for duplicate items at Discounts option>Enterprise level', () => {
        // #region -- Verify discounts UI of Add popup window

        cy.cGroupAsStep(
          'Verifying the default values available in the dropdowns, max length for discount name and warning text without name'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.clickOnAddButton();
        enterpriseConfig.verifyAddDiscountStateBeforeInputs();
        enterpriseConfig.verifyAddDiscountStateAfterInputs(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[1]
        );
        enterpriseConfig.verifyDiscountExists(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0],
          false
        );
        // #endregion

        // #region -- Adding new discount and validating max length, dropdown default lists

        cy.cGroupAsStep(
          'Adding a new discount and checking the maximum length and default dropdown values'
        );
        enterpriseConfig.addDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[1],
          DoneOrCancel.done
        );
        enterpriseConfig.verifyDiscountNameFieldLength(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[2]
        );
        enterpriseConfig.verifyTransactionCodeInDiscount(selectItem);
        enterpriseConfig.verifyWriteOffGroupCodeInDiscount(selectItem);
        enterpriseConfig.verifyWriteOffReasonCodeInDiscount(selectItem);
        // #endregion

        // #region -- Updating discount name,percentage and selection of dropdown values for Transaction,Write of Group code,Write of Reason code dropdowns

        cy.cGroupAsStep(
          'updating the fields for discount name, percentage and dropdown values'
        );
        enterpriseConfig.enterTextInNameField(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0]
        );
        enterpriseConfig.enterDiscountPercentage(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .DiscountPercentage[1]
        );
        enterpriseConfig.verifyDiscountPercentage(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .DiscountPercentage[1]
        );
        enterpriseConfig.verifyTransactionCodeListsInDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues
        );
        enterpriseConfig.selectTransactionCodeInDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues[0]
        );
        enterpriseConfig.selectGroupCodeInDiscount(defaultWriteOffGroupCode[0]);
        enterpriseConfig.selectReasonCodeInDiscount(
          defaultWriteOffReasonCode[0]
        );
        // #endregion

        // #region - Verify updated fields of Discount fields.

        cy.cGroupAsStep(
          'Navigate to other tab and comeback to verify the updated values for Discount'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0]
        );
        enterpriseConfig.verifyTransactionCodeInDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues[0]
        );
        enterpriseConfig.verifyWriteOffGroupCodeInDiscount(
          defaultWriteOffGroupCode[0]
        );
        enterpriseConfig.verifyWriteOffReasonCodeInDiscount(
          defaultWriteOffReasonCode[0]
        );
        // #endregion

        // #region - Again Updating Transaction code, Writeoff Group code and Writeoff Reason code dropdowns value

        cy.cGroupAsStep(
          'Again update only dropdown fields for selected Discount'
        );
        enterpriseConfig.selectTransactionCodeInDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues[1]
        );
        enterpriseConfig.selectGroupCodeInDiscount(defaultWriteOffGroupCode[1]);
        enterpriseConfig.selectReasonCodeInDiscount(
          defaultWriteOffReasonCode[1]
        );
        // #endregion

        // #region - Navigate to other tab and comeback o validate the updated dropdown values for Discount

        cy.cGroupAsStep(
          'Go to another tab and then return to confirm the new dropdown settings for Discount.'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0]
        );
        enterpriseConfig.verifyTransactionCodeInDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues[1]
        );
        enterpriseConfig.verifyWriteOffGroupCodeInDiscount(
          defaultWriteOffGroupCode[1]
        );
        enterpriseConfig.verifyWriteOffReasonCodeInDiscount(
          defaultWriteOffReasonCode[1]
        );
        // #endregion

        // #region - Adding an existing discount to the duplicate warning message to confirm

        cy.cGroupAsStep(
          'Verifying a duplicate warning notice by adding a discount that already exists'
        );
        enterpriseConfig.addDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0],
          DoneOrCancel.done
        );
        // Removed the verification step as its implemented in addDiscount method

        // #region - Verifying warning banner message by removing name field data

        cy.cGroupAsStep(
          'Deleting the name field data to confirm the warning banner message'
        );
        enterpriseConfig.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0]
        );
        enterpriseConfig.verifyWaringBannerByClearingName();
        enterpriseConfig.verifyStatesOfFieldsInDiscountScreen();
        // #endregion

        // #region -- Verify the disabled fields of discount by removing name field

        cy.cGroupAsStep(
          'Verify the discount disabled fields by eliminating the name field.'
        );
        enterpriseConfig.enterTextInNameField(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0]
        );
        enterpriseConfig.enterDiscountPercentage(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .DiscountPercentage[2]
        );
        enterpriseConfig.verifyTickMark(
          td_enterprise_config_discount_tcid_2647259.Discounts.DiscountNames[0]
        );
        enterpriseConfig.clickXMarkInDiscountSearch();
        // #endregion

        // #region -- Deleting a transaction code which is used by Discounts in Enterprise Build

        cy.cGroupAsStep(
          'Deleting a transaction code which is used by Discounts in Enterprise Build'
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // Removed the above code to click on delete icon for the mapped transaction code and implemented in the below method
        enterpriseConfig.deleteMappedTransactionCode(
          td_enterprise_config_discount_tcid_2647259.Discounts
            .TransactionCodeDropdownValues[1],
          YesOrNo.yes
        );
      });
    });
  }
}
