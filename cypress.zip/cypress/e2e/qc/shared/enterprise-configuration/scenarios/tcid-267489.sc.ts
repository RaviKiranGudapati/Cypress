/**
 * Revision History
 * Harsh: We found a issue in configuration feature enabling at enterprise leve so we have changed the facility GEM_ORG_5 to GEM_ORG_7
 */
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ShowOrHide,
  YesOrNo,
  DoneOrCancel,
  TrueOrFalse,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_discount_tcid_267489 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-discount-tcid-267489.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import {
  defaultWriteOffGroupCode,
  defaultWriteOffReasonCode,
  typeDropDownOptionValues,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import ChartsLogin from '../../../../../app-modules-libs/sis-charts/login/login';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();
const chartsLogin = new ChartsLogin();
const nursingConfiguration = new NursingConfiguration();

/* const values */
const discounts = 'Discounts';
const transactionCodes = 'Transaction Codes';
const facility = 'Facility';
const enterprise = 'Enterprise';

export class EnterpriseDiscountTcId267489 {
  precondition() {
    describe('Under the Internal tab, turn on Shared Dictionaries/Configurations, and then add Transaction codes.', () => {
      it('Enable Shared Dictionaries/Configurations under Internal tab and Add Transaction codes', () => {
        // #region -- Change login location to enterprise and Set Shared Dictionaries/Configuration to 'Show' state

        cy.cGroupAsStep(
          'Set Shared Dictionaries/Configurations option to Enable under Internal tab and verify Enterprise-Build Configurations'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_CONFIGURATION.PROFILES[0]
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifySharedDictionariesConfigurationsState(
          TrueOrFalse.true
        );
        enterpriseConfig.verifyEnterpriseBuild(true);
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // #endregion

        // #region -- Enable sharing for Discount and Transaction code to gem_Org003

        cy.cGroupAsStep(
          'Set Include Enterprise Items to Yes and Allow add to Configuration to Yes for Discounts and Transaction code to gem_Org003'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          discounts
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.yes,
          discounts
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          transactionCodes
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.yes,
          transactionCodes
        );
        // #endregion

        // #region -- Set Allow add to Discount and Transaction code to No for gem_Org004

        cy.cGroupAsStep(
          'Set Include Enterprise Items to Yes and Allow add to Configuration to No for Discounts and Transaction code to gem_Org004'
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_4
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          discounts
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.no,
          discounts
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          transactionCodes
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.no,
          transactionCodes
        );
        // #endregion

        // #region -- Verify sharing is disable for Discount and Transaction code for gem_Org005

        cy.cGroupAsStep(
          'Set Include Enterprise Items to No for Discounts and Transaction code to gem_Org005'
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_7
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.no,
          discounts
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.no,
          transactionCodes
        );
        // #endregion

        // #region -- At the enterprise level, adding transaction codes

        cy.cGroupAsStep('Adding Transaction codes at Enterprise level');
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[1]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[1],
          true
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[2]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[2],
          true
        );
        // #endregion
      });
    });
  }

  verifyDiscountsWhenSharingIsEnabled() {
    describe('when sharing is enabled, check the discount is shared at Facility from Enterprise', () => {
      it('Verify discounts when sharing is enabled for both Discounts and Transaction codes Under Internal tabs', () => {
        // #region - Adding "35% of DiscountA" at Enterprise level

        cy.cGroupAsStep('Adding DiscountA at Enterprise level');
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.addDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[0],
          DoneOrCancel.done
        );
        enterpriseConfig.enterDiscountPercentage(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[0]
        );
        enterpriseConfig.selectTransactionCodeInDiscount(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[1]
        );
        enterpriseConfig.selectGroupCodeInDiscount(defaultWriteOffGroupCode[1]);
        enterpriseConfig.selectReasonCodeInDiscount(
          defaultWriteOffReasonCode[1]
        );
        enterpriseConfig.verifyDiscountExists(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[0],
          true
        );
        // #endregion

        // #region -Adding new Discount and verify the state of add button at GEM_ORG_3

        cy.cGroupAsStep(
          'Adding DiscountB at gem_Org003 and state of Add button for Discount'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.selectDiscountInSearchList(discounts, true);
        nursingConfiguration.verifyStateOfAddButton();
        nursingConfiguration.addDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1],
          DoneOrCancel.done
        );
        nursingConfiguration.enterValuesInDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[1]
        );
        nursingConfiguration.selectDiscountTransactionCode(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[1]
        );
        nursingConfiguration.verifyDiscountExists(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1],
          true
        );
        // #endregion

        // #region - verify source field name for DiscountA at gem_Org003

        cy.cGroupAsStep(
          'Verify shared DiscountA from Enterprise is displaying along with source field'
        );
        nursingConfiguration.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[0]
        );
        nursingConfiguration.verifyDiscountSourceField(enterprise);
        nursingConfiguration.verifyDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[0]
        );
        nursingConfiguration.verifyTransactionCodeField(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[1]
        );
        nursingConfiguration.verifyWriteOffGroupCodeField(
          defaultWriteOffGroupCode[1]
        );
        nursingConfiguration.verifyWriteOffReasonCodeField(
          defaultWriteOffReasonCode[1]
        );
        // #endregion

        // #region -- verify source field name for DiscountB at gem_Org003

        cy.cGroupAsStep(
          'Verify newly added DiscountB is displaying along with source field at gem_Org003'
        );
        nursingConfiguration.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1]
        );
        nursingConfiguration.verifyDiscountSourceField(facility);
        nursingConfiguration.verifyDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[1]
        );
        nursingConfiguration.verifyTransactionCodeField(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[1]
        );
        nursingConfiguration.verifyWriteOffGroupCodeField(
          defaultWriteOffGroupCode[5]
        );
        nursingConfiguration.verifyWriteOffReasonCodeField(
          defaultWriteOffReasonCode[5]
        );
        // #endregion

        // #region - Verify DiscountB should not be displayed at Enterprise level

        cy.cGroupAsStep('Check DiscountB is not present at Enterprise');
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.verifyDiscountExists(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1],
          false
        );
        // #endregion

        // #region -- Add the same discountB which is added at gem_Org003

        cy.cGroupAsStep(
          'Add same DiscountB which is already added at gem_Org003 and update dropdown value'
        );
        enterpriseConfig.addDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1],
          DoneOrCancel.done
        );
        enterpriseConfig.enterDiscountPercentage(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[2]
        );
        enterpriseConfig.selectTransactionCodeInDiscount(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[2]
        );
        enterpriseConfig.selectGroupCodeInDiscount(defaultWriteOffGroupCode[2]);
        enterpriseConfig.selectReasonCodeInDiscount(
          defaultWriteOffReasonCode[2]
        );
        // #endregion

        // #region - Verify updated DiscountB at Gem_Org003 when sharing is turned on

        cy.cGroupAsStep(
          'Verify updated DiscountB from Enterprise to Gem_Org003 when sharing is turned on'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.selectDiscountInSearchList(discounts, true);
        nursingConfiguration.verifyStateOfAddButton();
        nursingConfiguration.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1]
        );
        nursingConfiguration.verifyDiscountSourceField(enterprise);
        nursingConfiguration.verifyDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[2]
        );
        nursingConfiguration.verifyTransactionCodeField(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[2]
        );
        nursingConfiguration.verifyWriteOffGroupCodeField(
          defaultWriteOffGroupCode[2]
        );
        nursingConfiguration.verifyWriteOffReasonCodeField(
          defaultWriteOffReasonCode[2]
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyAddButtonStateWhenConfigurationIsNO() {
    describe('Verify state of add button at facility when Allow Add to Configuration is set to NO', () => {
      it('Verify Add button state and shared Discounts from Enterprise to Facility_Org004', () => {
        // #region - Verify Add button is in disable state and Shared Discounts from Enterprise to Gem_Org004

        cy.cGroupAsStep(
          'When allow add to Configuration for Discount is set to No, Add button should be in disable state'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_4
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.selectDiscountInSearchList(discounts, true);
        nursingConfiguration.verifyStateOfAddButton(false);
        // #endregion

        // #region -- Verify DiscountA displaying at gem_Org004 when sharing is turned ON

        cy.cGroupAsStep(
          'Search and select DiscountA at gem_Org004 and verify source field'
        );
        nursingConfiguration.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[0]
        );
        nursingConfiguration.verifyDiscountSourceField(enterprise);
        nursingConfiguration.verifyDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[0]
        );
        nursingConfiguration.verifyTransactionCodeField(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[1]
        );
        nursingConfiguration.verifyWriteOffGroupCodeField(
          defaultWriteOffGroupCode[1]
        );
        nursingConfiguration.verifyWriteOffReasonCodeField(
          defaultWriteOffReasonCode[1]
        );
        // #endregion

        // #region -- Verify DiscountB displaying at gem_Org004 when sharing is turned ON

        cy.cGroupAsStep(
          'Search and select DiscountB at gem_Org004 and verify source field'
        );
        nursingConfiguration.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1]
        );
        nursingConfiguration.verifyDiscountSourceField(enterprise);
        nursingConfiguration.verifyDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[2]
        );
        nursingConfiguration.verifyTransactionCodeField(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[2]
        );
        nursingConfiguration.verifyWriteOffGroupCodeField(
          defaultWriteOffGroupCode[2]
        );
        nursingConfiguration.verifyWriteOffReasonCodeField(
          defaultWriteOffReasonCode[2]
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyDiscountsWhenSharingDisabled() {
    describe('Verify Discounts sharing when Include Enterprise is set to NO and in Transaction delete popup when it is in use', () => {
      it('Verify Discounts sharing is disabled and Transaction delete popup when it is in use', () => {
        // #region - Verify Add button is in enable state and Shared Discounts from Enterprise to Gem_Org005

        cy.cGroupAsStep(
          'Verify Add button is in enable state and Shared Enterprise Discounts were not exist when sharing is turned OFF'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_7
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.selectDiscountInSearchList(discounts, true);
        nursingConfiguration.verifyDiscountExists(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[0],
          false
        );
        nursingConfiguration.verifyDiscountExists(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[1],
          false
        );
        nursingConfiguration.verifyStateOfAddButton();
        sisOfficeDesktop.selectSisLogo();
        // #endregion

        // #region - Adding new Sharing WriteOff Three(Transaction code) from Enterprise

        cy.cGroupAsStep('Adding new Sharing WriteOff code from Enterprise');
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.addTransactionCode(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[3]
        );
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        enterpriseConfig.verifyTransactionCodeExists(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[3],
          true
        );
        // #endregion

        // #region - Add new DiscountC at Enterprise

        cy.cGroupAsStep('Adding new DiscountC at Enterprise level');
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        enterpriseConfig.addDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[2],
          DoneOrCancel.done
        );
        enterpriseConfig.enterDiscountPercentage(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[3]
        );
        enterpriseConfig.selectTransactionCodeInDiscount(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[3]
        );
        enterpriseConfig.selectGroupCodeInDiscount(defaultWriteOffGroupCode[2]);
        enterpriseConfig.selectReasonCodeInDiscount(
          defaultWriteOffReasonCode[1]
        );
        // #endregion

        // #region - Set Include Enterprise Items to Yes and Allow add to Configuration to Yes for Discounts to gem_Org005
        cy.cGroupAsStep(
          'Set Include Enterprise Items to Yes and Allow add to Configuration to Yes for Discounts to gem_Org005'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_7
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          discounts
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.yes,
          discounts
        );
        // #endregion

        // #region - Verify Shared Discounts from Enterprise to Gem_Org005 and Transaction code dropdown is in 'Select Items' as sharing is Off for Transaction

        cy.cGroupAsStep(
          'Verify shared Discounts at gem_Org005 when sharing is turned ON for Discount and OFF for Transaction code'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_7
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.selectDiscountInSearchList(discounts, true);
        nursingConfiguration.verifyStateOfAddButton();
        nursingConfiguration.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[2]
        );
        nursingConfiguration.verifyDiscountSourceField(enterprise);
        nursingConfiguration.verifyDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[3]
        );
        nursingConfiguration.verifyTransactionCodeField(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[0]
        );
        nursingConfiguration.verifyWriteOffGroupCodeField(
          defaultWriteOffGroupCode[2]
        );
        nursingConfiguration.verifyWriteOffReasonCodeField(
          defaultWriteOffReasonCode[1]
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion

        // #region - Turn on sharing for Transactions for Gem_Org005

        cy.cGroupAsStep(
          'Set Include Enterprise Items to Yes and Allow add to Configuration to Yes for Transaction code to gem_Org005'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_7
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          transactionCodes
        );
        enterpriseConfig.selectYesNoForAllowAddToConfiguration(
          YesOrNo.yes,
          transactionCodes
        );
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.DISCOUNTS
            .DISCOUNTS_LABEL[0]
        );
        // #endregion

        // #region -Verify shared Transactions are reflecting at Gem_Org005

        cy.cGroupAsStep(
          'Verify shared Transactions are reflecting at Gem_Org005 after setting turning on Sharing from enterprise'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_7
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.selectDiscountInSearchList(discounts, true);
        nursingConfiguration.verifyStateOfAddButton();
        nursingConfiguration.searchAndSelectDiscount(
          td_enterprise_config_discount_tcid_267489.Discount.DiscountNames[2]
        );
        nursingConfiguration.verifyDiscountSourceField(enterprise);
        nursingConfiguration.verifyDiscountPercentField(
          td_enterprise_config_discount_tcid_267489.Discount
            .DiscountPercentage[3]
        );
        nursingConfiguration.selectDiscountTransactionCode(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[3]
        );
        nursingConfiguration.verifyTransactionCodeField(
          td_enterprise_config_discount_tcid_267489.Discount
            .TransactionCodeDropdownValues[3]
        );
        nursingConfiguration.verifyWriteOffGroupCodeField(
          defaultWriteOffGroupCode[2]
        );
        nursingConfiguration.verifyWriteOffReasonCodeField(
          defaultWriteOffReasonCode[1]
        );
        // #endregion
      });
    });
  }
}
