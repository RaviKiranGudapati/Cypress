import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import {
  Application,
  YesOrNo,
  DoneOrCancel,
  ShowOrHide,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_contracts_tcid_270398 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-contracts-tcid-270398.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import {} from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import {
  defaultWriteOffGroupCode,
  typeDropDownOptionValues,
  defaultWriteOffReasonCode,
  contractTypes,
  adjustmentTime,
  contractHeadersForFeeSchedule,
  contractHeadersForBilledCharges,
  grouperTypeColumnsInReviewEdit,
  feeScheduleTypeColumnInReviewEdit,
} from '../../../../../app-modules-libs/shared/application-settings/constants/enterprise-configuration.const';
import { ContractHeaders } from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfiguration = new EnterpriseConfiguration();

/* const values */
const contracts = 'Contracts';
const selectItem = 'Select Item';
const index = ['0', '1'];

/**
 * In defaultWriteOffGroupCode, defaultWriteOffReasonCode there are six elements,
 * but in my case I have to validate first five elements, so using pop to skip last element
 */
defaultWriteOffGroupCode.pop();
defaultWriteOffReasonCode.pop();

export class EnterpriseContractsTcId270398 {
  precondition() {
    describe('Enable "Shared Dictionaries/Configurations" and verify Enterprise Build-Contracts', () => {
      it('Verifying Enterprise Build-Contracts Feature ', () => {
        // #region - Change login location to Enterprise and enable Enterprise Build - Contracts from Add On Features

        cy.cGroupAsStep(
          'Enable contracts from Add On Features under Enterprise Build'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfiguration.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        // #endregion

        // #region - Enable Shared Dictionaries/Configuration to Show state and Verifying Contracts Feature under Enterprise Build

        cy.cGroupAsStep(
          'Enable Shared Dictionaries/Configuration to Show state and Verifying Contracts Feature under Enterprise Build'
        );

        enterpriseConfiguration.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfiguration.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfiguration.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfiguration.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        enterpriseConfiguration.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfiguration.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.no,
          contracts
        );
        // #endregion

        // #region - verify Contracts, Fee schedule and Transaction Code under Enterprise Build

        cy.cGroupAsStep('Verify Enterprise Build Configurations');
        enterpriseConfiguration.verifyEnterpriseBuild(true);
        enterpriseConfiguration.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // #endregion

        // #region - Adding Transaction code at Enterprise level

        cy.cGroupAsStep(
          'Adding new Transaction code with type as WriteOff at Enterprise level'
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfiguration.addTransactionCode(
          td_enterprise_config_contracts_tcid_270398.TransactionCodeName[0]
        );
        enterpriseConfiguration.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfiguration.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        enterpriseConfiguration.addTransactionCode(
          td_enterprise_config_contracts_tcid_270398.TransactionCodeName[1]
        );
        enterpriseConfiguration.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfiguration.selectTransactionCodeTypeItem(
          typeDropDownOptionValues[6]
        );
        // #endregion

        // #region - Adding Procedure at Enterprise level

        cy.cGroupAsStep(
          'Adding new Procedure with status as billable at Enterprise level'
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfiguration.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270398.FeeSchedules[0]
        );
        enterpriseConfiguration.addFeeSchedule(
          td_enterprise_config_contracts_tcid_270398.FeeSchedules[1]
        );
        // #endregion
      });
    });
  }

  verifyContractFeatureUnderEnterpriseBuild() {
    describe('Verify Contract Configuration feature functionality under Enterprise build', () => {
      it('Verify adding new contract UI and new contract functionality under enterprise build', () => {
        // #region - Add Contract at enterprise

        cy.cGroupAsStep('Adding new Contract at enterprise');
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270398.Contracts[3],
          DoneOrCancel.done
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfiguration.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.CONTRACTS
            .CONTRACTS_LABEL[0]
        );
        // #endregion

        // #region - Check contracts user interfaces.

        cy.cGroupAsStep('Validating the UI and adding a new contract');
        enterpriseConfiguration.verifyContractScreenOptions();
        enterpriseConfiguration.verifyAddContractPopUpWindow();
        enterpriseConfiguration.verifyCopyContractFields(selectItem, false);
        enterpriseConfiguration.verifyContractScreenOptions();
        // #endregion

        // #region - Verify the Add popup's cancel button does not save the contract

        cy.cGroupAsStep(
          'Make sure the contract is not preserved after cancelling in the Add popup.'
        );

        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270398.Contracts[0],
          DoneOrCancel.cancel
        );
        enterpriseConfiguration.verifyContractScreenOptions();
        enterpriseConfiguration.verifyContractExist(
          td_enterprise_config_contracts_tcid_270398.Contracts[0],
          false
        );
        // #endregion

        // #region -- check that the contract was saved after clicking "done" in the Add popup

        cy.cGroupAsStep(
          'After clicking "Done" in the Add window, be sure the contract was saved.'
        );
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270398.Contracts[0],
          DoneOrCancel.done
        );
        enterpriseConfiguration.verifyContractExist(
          td_enterprise_config_contracts_tcid_270398.Contracts[0],
          true
        );
        enterpriseConfiguration.verifyTickMark(
          td_enterprise_config_contracts_tcid_270398.Contracts[0].ContractName
        );
        // #endregion

        // #region -- verify default behavior of Transaction code, WriteOff Group Code, WriteOff Reason Code Dropdowns

        cy.cGroupAsStep(
          'Verify the Transaction code, WriteOff Group Code and WriteOff Reason Code default behavior.'
        );
        enterpriseConfiguration.verifyContractNameField(
          td_enterprise_config_contracts_tcid_270398.Contracts[0]
        );
        enterpriseConfiguration.contractEffectiveDate(
          td_enterprise_config_contracts_tcid_270398.Contracts[0]
        );
        enterpriseConfiguration.contractExpirationDate(
          td_enterprise_config_contracts_tcid_270398.Contracts[0]
        );
        enterpriseConfiguration.verifyContractTypeValues(contractTypes);
        enterpriseConfiguration.verifyContractEffectiveDate(
          td_enterprise_config_contracts_tcid_270398.Contracts[0]
        );
        enterpriseConfiguration.verifyContractExpirationDate(
          td_enterprise_config_contracts_tcid_270398.Contracts[0]
        );
        cy.cRemoveMaskWrapper(Application.office);
        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270398.Contracts[0]
        );
        enterpriseConfiguration.verifyTabHeadingInContracts(
          contractHeadersForFeeSchedule
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfiguration.verifyFeeGroup();
        enterpriseConfiguration.verifyAdjustmentTimeOptions(adjustmentTime);
        enterpriseConfiguration.verifyDefaultWriteOffTransactionCodeOptions(
          td_enterprise_config_contracts_tcid_270398.TransactionCodeName
        );
        enterpriseConfiguration.verifyDefaultWriteOffGroupCodeOptions(
          defaultWriteOffGroupCode
        );
        enterpriseConfiguration.verifyDefaultWriteOffReasonCodeOptions(
          defaultWriteOffReasonCode
        );
        enterpriseConfiguration.addFeeGroup(
          td_enterprise_config_contracts_tcid_270398.FeeGroups[0]
        );
        enterpriseConfiguration.addFeeGroup(
          td_enterprise_config_contracts_tcid_270398.FeeGroups[1]
        );

        // #endregion

        // #region -- Verify procedure details under Review/Edit tab.

        cy.cGroupAsStep('Verify procedure details under Review/Edit tab.');
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.verifyColumnsNameUnderReviewEdit(
          grouperTypeColumnsInReviewEdit
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[0].CptHcpsc
        );
        enterpriseConfiguration.selectDetailsInReviewEdit(index[0]);
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[0]
        );
        enterpriseConfiguration.clearProcedureSearchInContract();

        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[1].CptHcpsc
        );
        enterpriseConfiguration.selectDetailsInReviewEdit(index[1]);
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[1]
        );
        enterpriseConfiguration.clearProcedureSearchInContract();
        // #endregion
      });
    });
  }

  contractFeeScheduleType() {
    describe('Verify Contract FeeSchedule Type feature functionality under Enterprise build', () => {
      it('Verify the Contract feature options under posting options at Enterprise level', () => {
        // #region - Verify contract details and under Posting options

        cy.cGroupAsStep('Verify contract details and under Posting options');
        cy.cRemoveMaskWrapper(Application.office);
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270398.Contracts[1],
          DoneOrCancel.done
        );
        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270398.Contracts[1]
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfiguration.verifyTabHeadingInContracts(
          contractHeadersForFeeSchedule
        );
        enterpriseConfiguration.enterContractPercentage(
          td_enterprise_config_contracts_tcid_270398.Contracts[1]
            .PercentageOfAllowed!
        );
        enterpriseConfiguration.verifyContractPercentage(
          td_enterprise_config_contracts_tcid_270398.Contracts[1]
            .PercentageOfAllowed!
        );
        enterpriseConfiguration.verifyAdjustmentTimeOptions(adjustmentTime);
        enterpriseConfiguration.verifyDefaultWriteOffTransactionCodeOptions(
          td_enterprise_config_contracts_tcid_270398.TransactionCodeName
        );
        enterpriseConfiguration.verifyDefaultWriteOffGroupCodeOptions(
          defaultWriteOffGroupCode
        );
        enterpriseConfiguration.verifyDefaultWriteOffReasonCodeOptions(
          defaultWriteOffReasonCode
        );
        // #endregion

        // #region - Verify contract details and under Posting options

        cy.cGroupAsStep('Verify contract details and under Posting options');
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.verifyColumnsNameUnderReviewEdit(
          feeScheduleTypeColumnInReviewEdit
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[0].CptHcpsc
        );
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[2]
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[1].CptHcpsc
        );
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[3]
        );
        // #endregion
      });
    });
  }

  percentageOfBilledCharges() {
    describe('Verify Contract Percentage Of Billed Charges feature functionality under Enterprise build', () => {
      it('Verify the percentage of billed charges under posting options at Enterprise level', () => {
        // #region - Verify contract details and under Posting options

        cy.cGroupAsStep('Verify contract details and under Posting options');
        enterpriseConfiguration.addContract(
          td_enterprise_config_contracts_tcid_270398.Contracts[2],
          DoneOrCancel.done
        );
        enterpriseConfiguration.selectContractType(
          td_enterprise_config_contracts_tcid_270398.Contracts[2]
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.PostingOption
        );
        enterpriseConfiguration.verifyTabHeadingInContracts(
          contractHeadersForBilledCharges
        );
        enterpriseConfiguration.enterContractPercentage(
          td_enterprise_config_contracts_tcid_270398.Contracts[2]
            .PercentageOfAllowed!
        );
        enterpriseConfiguration.verifyContractPercentage(
          td_enterprise_config_contracts_tcid_270398.Contracts[2]
            .PercentageOfAllowed!
        );
        enterpriseConfiguration.verifyAdjustmentTimeOptions(adjustmentTime);
        enterpriseConfiguration.verifyDefaultWriteOffTransactionCodeOptions(
          td_enterprise_config_contracts_tcid_270398.TransactionCodeName
        );
        enterpriseConfiguration.verifyDefaultWriteOffGroupCodeOptions(
          defaultWriteOffGroupCode
        );
        enterpriseConfiguration.verifyDefaultWriteOffReasonCodeOptions(
          defaultWriteOffReasonCode
        );
        // #endregion

        // #region - Verify the columns names and procedure details under Review/Edit

        cy.cGroupAsStep(
          ' Verify the columns names and procedure details under Review/Edit'
        );
        enterpriseConfiguration.selectTabHeadingInContracts(
          ContractHeaders.ReviewEdit
        );
        enterpriseConfiguration.verifyColumnsNameUnderReviewEdit(
          grouperTypeColumnsInReviewEdit
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[4].CptHcpsc
        );
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[4]
        );
        enterpriseConfiguration.searchProcedureInContracts(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[5].CptHcpsc
        );
        enterpriseConfiguration.verifyProcedureDetailsUnderReviewEdit(
          td_enterprise_config_contracts_tcid_270398
            .ProcedureDetailsInReviewEdit[5]
        );
        // #endregion
      });
    });
  }

  contractConfigurationTab() {
    describe('Verify Contract Configuration feature functionality under Configuration Tab', () => {
      it('Verify the default behavior of toggle switch of Contracts at Enterprise level', () => {
        // #region - Under Configuration tab, verify the Contract feature option

        cy.cGroupAsStep(
          'Under Configuration tab, verify the Contracts feature option'
        );
        enterpriseConfiguration.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfiguration.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfiguration.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfiguration.verifyColumnsInConfigurationsTab();
        enterpriseConfiguration.verifyMouseHoverTextInConfigurationsTab();
        enterpriseConfiguration.verifyDefaultBehaviorToggleSwitch(contracts);
        // #endregion

        // #region - select Include Enterprise Items Toggles to Yes and verify the toggles saved conditions

        cy.cGroupAsStep(
          'Select Include Enterprise Items Toggles to Yes and verify the toggles saved conditions'
        );
        enterpriseConfiguration.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          contracts
        );
        enterpriseConfiguration.verifyYesNoIsEnabledForIncludeEnterpriseItems(
          YesOrNo.yes,
          contracts
        );
        enterpriseConfiguration.verifyYesNoIsEnabledForAllowAddToConfiguration(
          YesOrNo.yes,
          contracts
        );
        // #endregion
      });
    });
  }
}
