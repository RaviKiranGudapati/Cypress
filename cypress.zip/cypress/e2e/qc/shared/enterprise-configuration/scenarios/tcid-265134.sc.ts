import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import {
  EnableOrDisable,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';

import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { td_enterprise_configuration_tcid_265134 } from '../../../../../fixtures/enterprise-configuration-tcid265134.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_SIS_CHARTS_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-charts-desktop.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';

/* instance variables */
const nursingConfigurationLayout = new NursingConfigurationLayout();
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const enterpriseConfig = new EnterpriseConfiguration();
const scheduleGrid = new ScheduleGrid();

export class EnterpriseMfaSsoTcId265134 {
  enterpriseSettings() {
    describe('Verify the MFA-SSO functionality in Enterprise', () => {
      it('Verify the e-mail is required for newly added users', () => {
        // #region Verify the e-mail is required for newly added users.

        cy.cGroupAsStep(
          'Navigate to Application settings and Selecting Add on feature Configuration'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURE.ADD_ON_FEATURE_HEADER[0]
        );
        // #endregion

        // #region - Clicking on plus icon for the unreleased feature and verify the MFASSO Name its state

        cy.cGroupAsStep(
          'Clicking on plus icon for the unreleased feature and verify the MFASSO Name its state'
        );
        nursingConfigurationLayout.clickUnreleased();
        nursingConfigurationLayout.clickMFASSObutton();
        // #endregion

        // #region - Navigate to Enterprise settings and select security settings

        cy.cGroupAsStep(
          'Navigate to Enterprise settings and select security settings'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.SECURITY.SECURITY_SECTION[0]
        );
        enterpriseConfig.clickMFAAndBypassingMFAbutton(EnableOrDisable.enable, true, true);
        enterpriseConfig.clickMFAAndBypassingMFAbutton(YesOrNo.no, true, false);
        // #endregion

        // #region - Select the user and click Add button in users and verify duplicate, invalid email in enterprise

        cy.cGroupAsStep(
          'Select the user and click Add button in users and verify duplicate, invalid email in enterprise'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_NURSING_CONFIGURATION.FACILITY_USERS.USERS[0]
        );
        enterpriseConfig.clickAddButton();
        enterpriseConfig.verifyEmail();
        // #endregion

        // #region - Verify Invalid, duplicate messages for email

        cy.cGroupAsStep('Verify Invalid, duplicate messages for email');
        enterpriseConfig.enterEmail(
          td_enterprise_configuration_tcid_265134.UserDetails[1]
        );
        enterpriseConfig.verifyInvalidEmail(AppErrorMessages.invalid_email);
        enterpriseConfig.enterEmail(
          td_enterprise_configuration_tcid_265134.UserDetails[2]
        );

        enterpriseConfig.verifyInvalidEmail(AppErrorMessages.duplicate_email);
        // #endregion

        // #region - enter values in user details and click on done

        cy.cGroupAsStep('Enter values in user details and click on done');
        enterpriseConfig.createUser(
          td_enterprise_configuration_tcid_265134.UserDetails[0]
        );
        enterpriseConfig.enterEmail(
          td_enterprise_configuration_tcid_265134.UserDetails[0]
        );
        enterpriseConfig.clickOnUserDoneButton();
        // #endregion

        // #region - Click user details tab and verify email and text,Verify Invalid, duplicate messages for email

        cy.cGroupAsStep(
          'Click user details tab and verify email and text,Verify Invalid, duplicate messages for email'
        );
        enterpriseConfig.clickOnUserDetailsTab();
        enterpriseConfig.verifyEmailAsterisk();

        enterpriseConfig.enterEmailInUserDetailsTab(
          td_enterprise_configuration_tcid_265134.UserDetails[1].EMail
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
        );
        enterpriseConfig.verifyInvalidTextInTooltip(
          AppErrorMessages.invalid_email
        );
        enterpriseConfig.clickOnOk();
        enterpriseConfig.enterEmailInUserDetailsTab(
          td_enterprise_configuration_tcid_265134.UserDetails[2].EMail
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
        );
        enterpriseConfig.verifyInvalidTextInTooltip(
          AppErrorMessages.duplicate_email
        );
        enterpriseConfig.clickOnOk();

        // #endregion

        // #region - Select existing user and verify email and Invalid, duplicate messages for email and verify change password is disabled

        cy.cGroupAsStep(
          'Select existing user and verify email and Invalid, duplicate messages for email and verify change password is disabled'
        );
        enterpriseConfig.searchConfigurationItem(UserList.GEM_USER_3[0]);
        enterpriseConfig.selectUserName(UserList.GEM_USER_3[0]);
        enterpriseConfig.verifyChangePassword();
        enterpriseConfig.clickOnUserDetailsTab();
        enterpriseConfig.verifyEmailAsterisk();
        enterpriseConfig.enterEmailInUserDetailsTab(
          td_enterprise_configuration_tcid_265134.UserDetails[1].EMail
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
        );
        enterpriseConfig.verifyInvalidTextInTooltip(
          AppErrorMessages.invalid_email
        );
        enterpriseConfig.clickOnOk();
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
        );
        enterpriseConfig.enterEmailInUserDetailsTab(
          td_enterprise_configuration_tcid_265134.UserDetails[2].EMail
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
        );
        enterpriseConfig.verifyInvalidTextInTooltip(
          AppErrorMessages.duplicate_email
        );
        enterpriseConfig.clickOnOk();
        enterpriseConfig.enterEmailInUserDetailsTab(
          td_enterprise_configuration_tcid_265134.UserDetails[3].EMail
        );
        // #endregion

        // #region - Click create copy user enterprise and verify email and Invalid, duplicate messages for email

        cy.cGroupAsStep(
          'Click create copy user enterprise and verify email and Invalid, duplicate messages for email'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_NURSING_CONFIGURATION.FACILITY_USERS.USERS[0],
          true
        );
        enterpriseConfig.clickAddButton();
        enterpriseConfig.clickCreateCopyUser();
        enterpriseConfig.verifyEmail();
        enterpriseConfig.enterEmail(
          td_enterprise_configuration_tcid_265134.UserDetails[1]
        );
        enterpriseConfig.verifyInvalidEmail(AppErrorMessages.invalid_email);
        enterpriseConfig.enterEmail(
          td_enterprise_configuration_tcid_265134.UserDetails[2]
        );
        enterpriseConfig.verifyInvalidEmail(AppErrorMessages.duplicate_email);
        enterpriseConfig.createUser(
          td_enterprise_configuration_tcid_265134.UserDetails[0]
        );
        enterpriseConfig.enterEmail(
          td_enterprise_configuration_tcid_265134.UserDetails[4]
        );
        sisOfficeDesktop.clickDoneButton();
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
        );
        // #endregion

        // #region -  Select nursing desktop and select user select user setting and verify change password disabled

        cy.cGroupAsStep(
          'Select nursing desktop and select user select user setting and verify change password disabled'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_CHARTS_DESKTOP.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectFacilityInChangeLoginLocation(
          OrganizationList.GEM_ORG_4
        );

        scheduleGrid.scheduleGridEnable();

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.FACILITY_USERS.USERS[0]
        );
        nursingConfigurationLayout.selectUserInUserList(UserList.GEM_USER_3[0]);
        nursingConfigurationLayout.verifyChangePassword();

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.FACILITY_USERS.USERS[0]
        );
        nursingConfigurationLayout.selectUserInUserList(UserList.GEM_USER_3[0]);
        nursingConfigurationLayout.verifyChangePassword();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.USER_SETTINGS[0]
        );
        nursingConfigurationLayout.verifyChangePasswordInUsers();
        nursingConfigurationLayout.clickOnCrossIcon();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion
      });
    });
  }
}
