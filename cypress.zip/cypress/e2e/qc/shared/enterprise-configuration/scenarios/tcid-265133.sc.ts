import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import {
  EnableOrDisable,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';

import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { td_enterprise_configuration_tcid_265133 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-configuration-tcid265133.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SIS_CHARTS_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-charts-desktop.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';

import EnterpriseConfiguration, { MFAIP } from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const enterpriseConfig = new EnterpriseConfiguration();

/* const values */
const num = ['0', '1', '2', '3'];
const ipFrom = [
  '255.1.1.1',
  '255.1.1.3',
  '255.1.1.5',
  '56.1.1.99',
  '256.1.13',
  '255.1.15',
  '255.1.15.15',
];
const ipTo = [
  '255.1.1.2',
  '255.1.1.4',
  '255.1.1.6',
  '256.1.14',
  '56.1.14.99',
  '255.1.16',
  '255.1.16.16',
];

export class AddOnFeaturesMfaSsoTcId265133 {
  addOnFeaturesAppSettings() {
    describe('Verify the MFA feature flag in application settings', () => {
      it('Verify the MFA behind a feature flag in the addon features in the Application settings.', () => {
        // #region Verify the MFA behind a feature flag in the addon features in the Application settings.

        cy.cGroupAsStep(
          'Navigate to Application settings and Selecting Add on feature Configuration'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectAddOnFeaturesConfiguration();
        // #endregion

        // #region Clicking on plus icon for the unreleased feature and verify the MFASSO Name its state.

        cy.cGroupAsStep(
          'Clicking on plus icon for the unreleased feature and verify the MFASSO Name its state'
        );
        nursingConfigurationLayout.clickUnreleased();
        nursingConfigurationLayout.verifyMFASSOName();
        nursingConfigurationLayout.verifyMFASSObutton(false);
        // #endregion

        // #region Verify the unpresence of MFA flag in the Enterprise.

        cy.cGroupAsStep(
          'Navigating to the Enterprise and verify the unpresence of MFA and SSO in security'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.SECURITY.SECURITY_SECTION[0]
        );
        enterpriseConfig.verifyMFASSOHeader(false);
        // #endregion

        // #region Enabling the MFA feature flag in the addon features in the Application settings.

        cy.cGroupAsStep(
          'Clicking on plus icon for the unreleased feature in application settings and click the enable MFASSO'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_CHARTS_DESKTOP.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectFacilityInChangeLoginLocation(
          OrganizationList.GEM_ORG_3
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURE.ADD_ON_FEATURE_HEADER[0]
        );
        nursingConfigurationLayout.clickUnreleased();
        nursingConfigurationLayout.clickMFASSObutton();
        // #endregion

        // #region Verify the presence of MFA flag in the Enterprise.

        cy.cGroupAsStep(
          'Navigating to the Enterprise and verify the presence of MFA and SSO in security'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_CHARTS_DESKTOP.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.SECURITY.SECURITY_SECTION[0]
        );
        enterpriseConfig.verifyMFASSOHeader(true);
        // #endregion

        // #region verifying the MFA feature flag is enabled in the addon features in the Application settings for another location.

        cy.cGroupAsStep(
          'Change into different location and verify the MFASSO falg is enabled in Add on feature'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_CHARTS_DESKTOP.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectFacilityInChangeLoginLocation(
          OrganizationList.GEM_ORG_3
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURE.ADD_ON_FEATURE_HEADER[0]
        );
        nursingConfigurationLayout.clickUnreleased();
        nursingConfigurationLayout.verifyMFASSObutton();
        // #endregion

        // #region verifying the MFA section in the enterprise.

        cy.cGroupAsStep(
          'Verifying the MFA section in the Enterprise after enabling in add on features'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_CHARTS_DESKTOP.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.SECURITY.SECURITY_SECTION[0]
        );
        enterpriseConfig.verifyMFASSOHeader(true);
        enterpriseConfig.verifyMFAHeader();
        enterpriseConfig.verifyMFAbutton(EnableOrDisable.disable);
        enterpriseConfig.verifyBypassingMFAHeader();
        enterpriseConfig.minimumLength(7);
        enterpriseConfig.verifyIPRangeHeader();
        enterpriseConfig.verifyIPRangeTextBox(false);
        // #endregion

        // #region Verifying the sections Select Multi-Factor Authentication enable button.

        cy.cGroupAsStep(
          'Verifying the sections Select Multi-Factor Authentication enable button.'
        );
        enterpriseConfig.clickMFAAndBypassingMFAbutton(EnableOrDisable.enable, false, true);
        enterpriseConfig.verifyPasswordWarning(
          AppErrorMessages.security_password_strength
        );
        enterpriseConfig.verifyPasswordWarning(
          AppErrorMessages.security_password
        );
        enterpriseConfig.verifyBypassingMFAbutton(YesOrNo.yes);
        enterpriseConfig.verifyIPRangeTextBox();
        // #endregion

        // #region Verifying the tooltip of Bypassing MFA button.

        cy.cGroupAsStep('Verifying the tooltip of Bypassing MFA button.');
        enterpriseConfig.toolTipBypassingMFA();
        // #endregion

        // #region Verifying the IP Ranges and documenting the values of the IP ranges.

        cy.cGroupAsStep(
          'Verifying the IP Ranges and documenting the values of the IP ranges'
        );
        enterpriseConfig.addIcon();
        enterpriseConfig.enterIpFrom(ipFrom[0], num[0]);
        enterpriseConfig.enterIpTo(ipTo[0], num[0]);
        enterpriseConfig.addIcon();
        enterpriseConfig.enterIpFrom(ipFrom[1], num[1]);
        enterpriseConfig.enterIpTo(ipTo[1], num[1]);
        enterpriseConfig.addIcon();
        enterpriseConfig.enterIpFrom(ipFrom[2], num[2]);
        enterpriseConfig.enterIpTo(ipTo[2], num[2]);
        // #endregion

        // #region Verifying the IP Ranges errors by edit the values of the IP ranges and incorrect entires.

        cy.cGroupAsStep(
          'Verifying the IP Ranges errors by edit the values of the IP ranges and incorrect entires'
        );
        enterpriseConfig.clickIpFromTo(num[1], MFAIP.IpFrom);
        enterpriseConfig.enterIpFrom(ipFrom[4], num[1]);
        enterpriseConfig.verifyIpFromToWarning(AppErrorMessages.ip_format);
        enterpriseConfig.enterIpFrom(ipFrom[3], num[1]);
        enterpriseConfig.addIcon();
        enterpriseConfig.clickIpFromTo(num[1], MFAIP.IpTo);
        enterpriseConfig.enterIpTo(ipTo[3], num[1]);
        enterpriseConfig.verifyIpFromToWarning(AppErrorMessages.ip_format);
        enterpriseConfig.enterIpTo(ipTo[4], num[1]);
        enterpriseConfig.addIcon();
        enterpriseConfig.enterIpFrom(ipFrom[5], num[3]);
        enterpriseConfig.verifyIpFromToWarning(AppErrorMessages.ip_format);
        enterpriseConfig.enterIpFrom(ipFrom[6], num[3]);
        enterpriseConfig.enterIpTo(ipTo[5], num[3]);
        enterpriseConfig.verifyIpFromToWarning(AppErrorMessages.ip_format);
        enterpriseConfig.enterIpTo(ipTo[6], num[3]);
        enterpriseConfig.addIcon();
        // #endregion

        // #region Deleting the existing IP range.

        cy.cGroupAsStep('Deleting the existing IP range');
        enterpriseConfig.clickIpFromToDelete(num[2]);
        enterpriseConfig.clickMFAAndBypassingMFAbutton(YesOrNo.no, false, false);

        // #endregion

        // #region Verifying the MFA section in the enterprise after enabling in add on features.

        cy.cGroupAsStep(
          'Verifying the MFA section in the Enterprise after enabling in add on features'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS_TAB.USERS_SECTION[0]
        );
        // #endregion

        // #region enter values in user details and click on done

        cy.cGroupAsStep('Enter values in user details and click on done');
        enterpriseConfig.clickAddButton();
        enterpriseConfig.createUser(
          td_enterprise_configuration_tcid_265133.UserDetails[0]
        );
        enterpriseConfig.enterEmail(
          td_enterprise_configuration_tcid_265133.UserDetails[0]
        );
        sisOfficeDesktop.clickDoneButton();
        enterpriseConfig.clickActiveToggle(YesOrNo.yes);
        enterpriseConfig.clickActiveToggle(YesOrNo.no);
        enterpriseConfig.searchConfigurationItem(
          td_enterprise_configuration_tcid_265133.UserDetails[0].FirstName!
        );
        enterpriseConfig.verifyUser(
          td_enterprise_configuration_tcid_265133.UserDetails[0]
        );
        enterpriseConfig.clickActiveToggle(YesOrNo.no);
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS_TAB.USERS_SECTION[0],
          true
        );
        enterpriseConfig.clickUserToDelete();
        enterpriseConfig.clickOnOk();
        enterpriseConfig.searchConfigurationItem(
          td_enterprise_configuration_tcid_265133.UserDetails[0].FirstName!
        );
        enterpriseConfig.clickActiveToggle(YesOrNo.yes);
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS_TAB.USERS_SECTION[0],
          true
        );
        enterpriseConfig.clickUserToInactive();
        enterpriseConfig.selectUserName(
          td_enterprise_configuration_tcid_265133.UserDetails[0].FirstName!
        );
        // #endregion

        // #region click user details tab and verify email and text,Verify Invalid, duplicate messages for email

        cy.cGroupAsStep(
          'Click user details tab and verify email and text,Verify Invalid, duplicate messages for email'
        );
        enterpriseConfig.clickOnUserDetailsTab();
        enterpriseConfig.enterEmailInUserDetailsTab(
          td_enterprise_configuration_tcid_265133.UserDetails[1].EMail
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.USER_DETAILS.USER_DETAILS_TAB[0]
        );
        enterpriseConfig.verifyInvalidTextInTooltip(
          AppErrorMessages.invalid_email
        );
        enterpriseConfig.clickOnOk();
        // #endregion
      });
    });
  }
}
