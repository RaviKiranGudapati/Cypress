import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ShowOrHide,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';

import { td_fee_schedule_tcid_262407 } from '../../../../../fixtures/shared/application-settings/fee-schedule/fee-schedule-tcid-262407.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import SISCompleteLogin from '../../../../../app-modules-libs/sis-office/login/login';

/* instance variables */

const sisOfficeDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();

export class EnterpriseFeeScheduleTcId262507 {
  verifyFeeScheduleEnableFeature() {
    describe('To verify the availability of Enterprise build and UI of Fee Schedule after adding procedure', () => {
      it('Verifying Fee Schedule visibility in Enterprise Build as per Internal tab settings', () => {
        // #region - Navigating to the enterprise location, selecting organization under facility management settings

        cy.cGroupAsStep(
          'Navigating to the enterprise location, selecting organization under facility management settings'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );

        // #end region

        // #region -Clicking on internal tab and verifying whether enterprise build is visible by default and then verifying after enabling it

        cy.cGroupAsStep(
          'Clicking on the internal tab and verifying the enterprise build visibility'
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifyEnterpriseBuild(false);

        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        enterpriseConfig.verifyEnterpriseBuild();
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        // #end region

        // #region -Adding Cpt code in fee schedule,verifying the helper text of add procedure pop-up and verifying the fields visible as well as the default values present in the fields

        cy.cGroupAsStep(
          'Adding the cpt code and verifying fields visible as well as the default values'
        );
        enterpriseConfig.clickOnAddInFeeSchedule();

        enterpriseConfig.verifySearchHelperText();

        enterpriseConfig.clickOnCancel();

        enterpriseConfig.addProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.CptProcedure
        );
        enterpriseConfig.selectAddedProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.CptProcedure
        );

        enterpriseConfig.verifyOptionsInProcedure();

        enterpriseConfig.verifyStatusDropDownValues(
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues
        );
        enterpriseConfig.verifyDefaultValuesForRevCodeAndTypeOfBill(
          td_fee_schedule_tcid_262407.FeeSchedule.DefaultRevenueCode,
          td_fee_schedule_tcid_262407.FeeSchedule.DefaultTypeOfBill
        );
        enterpriseConfig.verifyDisclaimerText();
        // #end region

        // #region -Navigating to facility management,selecting the desired facility and verifying the options visibility and the default toggle behaviour of the options
        cy.cGroupAsStep(
          'Navigating to facility management and selecting an organization,verifying the options visibility and the default toggle behaviour of the options'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        enterpriseConfig.verifyColumnsInConfigurationsTab();

        enterpriseConfig.verifyMouseHoverTextInConfigurationsTab();

        enterpriseConfig.verifyTogglesInConfiguration(
          td_fee_schedule_tcid_262407.FeeSchedule.ConfigurationItems[0]
        );

        enterpriseConfig.verifyDefaultBehaviorToggleSwitch(
          td_fee_schedule_tcid_262407.FeeSchedule.ConfigurationItems[0]
        );

        // #endregion
      });
    });
  }

  verifyGCodeFunctionality() {
    describe('To verify add ,update and delete functionality for GCode', () => {
      it('Verifying add update and delete functionality for GCode', () => {
        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        // #region Adding Gcode code in fee schedule, default values present in the fields,updating code from procedure field as well as the data present in the history
        cy.cGroupAsStep(
          'Adding Gcode and updating it from procedure field as well as verifying history'
        );
        enterpriseConfig.addProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[0]
        );

        enterpriseConfig.selectAddedProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[0]
        );

        enterpriseConfig.clickOnAutoCompleteClear();

        enterpriseConfig.verifyProcedureWarning();

        enterpriseConfig.updateCodeFromProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[1]
        );

        enterpriseConfig.enterModifiedProcedureDescription(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .greaterThan200
        );

        enterpriseConfig.enterModifiedProcedureDescription(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .lessThan200
        );

        enterpriseConfig.verifyDefaultStateOfIncludeInStateReport(
          td_fee_schedule_tcid_262407.FeeSchedule
            .DefaultStateIncludeInReportForGCode
        );

        enterpriseConfig.selectStatusValue(
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[2]
        );

        enterpriseConfig.enterAmount(
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[0]
        );

        enterpriseConfig.clickHistory();

        enterpriseConfig.verifyHistory(
          td_fee_schedule_tcid_262407.FeeSchedule.FeeScheduleColumnValues
        );
        // #endregion

        // #region Verifying if the documented data is saved by navigating to other page,verify addition of duplicate code and updating the data in the fields

        cy.cGroupAsStep(
          'Navigating to another page(facility management) and updating the data in the fields for Gcode'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.selectAddedProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[1]
        );

        enterpriseConfig.verifyDocumentedDataForProcedurecode(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .lessThan200,
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[2],
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[0],
          td_fee_schedule_tcid_262407.FeeSchedule.TypeOfBill[0]
        );

        enterpriseConfig.verifyAddDuplicateCode(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[1]
        );

        enterpriseConfig.clickOnAutoCompleteClear();

        enterpriseConfig.updateCodeFromProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[2]
        );

        enterpriseConfig.enterModifiedProcedureDescription(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .lessThan200
        );
        enterpriseConfig.enterModifiedProcedureDescription(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .description
        );

        enterpriseConfig.enterAmount(
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[1]
        );

        enterpriseConfig.updateTypeOfBill(
          td_fee_schedule_tcid_262407.FeeSchedule.TypeOfBill[1]
        );

        enterpriseConfig.selectStatusValue(
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[1]
        );

        enterpriseConfig.updateRevenueCode(
          td_fee_schedule_tcid_262407.FeeSchedule.RevenueCode[0]
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.selectAddedProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[2]
        );

        enterpriseConfig.verifyDocumentedDataForProcedurecode(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .description,
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[1],
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[1],
          td_fee_schedule_tcid_262407.FeeSchedule.TypeOfBill[1]
        );

        // #endregion

        // #region -To verify the delete(inactivate) procedure by clicking on trash icon and selecting no initially and then selecting yes
        cy.cGroupAsStep(
          'Verifying the delete procedure functionality for Gcode'
        );
        enterpriseConfig.inactivateProcedureItem(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[2],
          YesOrNo.no
        );
        enterpriseConfig.inactivateProcedureItem(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[2],
          YesOrNo.yes
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.verifyProcedureItemExists(
          td_fee_schedule_tcid_262407.FeeSchedule.GCodeProcedure[2],
          false
        );
        // #endregion
      });
    });
  }

  verifyHcpcsCodeFunctionality() {
    describe('To verify add update and delete functionality for HCPCSCode', () => {
      it('Verifying add update and delete functionality for HCPCSCode', () => {
        // #region Adding HCPCScode code in fee schedule, default values present in the fields,updating code from procedure field as well as the data present in the history
        cy.cGroupAsStep(
          'Adding HCPCScode and updating it from procedure field as well as verifying history'
        );
        enterpriseConfig.addProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[0]
        );

        enterpriseConfig.verifyDefaultStateOfIncludeInStateReport(
          td_fee_schedule_tcid_262407.FeeSchedule
            .DefaultStateIncludeInReportForHcpcs
        );
        enterpriseConfig.clickOnAutoCompleteClear();

        enterpriseConfig.verifyProcedureWarning();

        enterpriseConfig.updateCodeFromProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[1]
        );

        enterpriseConfig.enterModifiedProcedureDescription(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .lessThan200
        );

        enterpriseConfig.selectStatusValue(
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[2]
        );

        enterpriseConfig.enterAmount(
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[0]
        );

        enterpriseConfig.clickHistory();

        enterpriseConfig.verifyHistory(
          td_fee_schedule_tcid_262407.FeeSchedule.FeeScheduleColumnValues
        );
        // #endregion

        // #region Verifying if the documented data is saved by navigating to other page,verify addition of duplicate code and updating the data in the fields

        cy.cGroupAsStep(
          'Navigating to another page(facility management) and updating the data in the fields for Hcpcs code'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );
        enterpriseConfig.selectAddedProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[1]
        );

        enterpriseConfig.verifyDocumentedDataForProcedurecode(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .lessThan200,
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[2],
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[0],
          td_fee_schedule_tcid_262407.FeeSchedule.TypeOfBill[0]
        );

        enterpriseConfig.verifyAddDuplicateCode(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[1]
        );

        enterpriseConfig.clickOnAutoCompleteClear();

        enterpriseConfig.updateCodeFromProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[2]
        );

        enterpriseConfig.enterModifiedProcedureDescription(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .lessThan200
        );
        enterpriseConfig.enterModifiedProcedureDescription(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .description
        );

        enterpriseConfig.enterAmount(
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[1]
        );

        enterpriseConfig.updateTypeOfBill(
          td_fee_schedule_tcid_262407.FeeSchedule.TypeOfBill[1]
        );

        enterpriseConfig.selectStatusValue(
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[1]
        );

        enterpriseConfig.updateRevenueCode(
          td_fee_schedule_tcid_262407.FeeSchedule.RevenueCode[0]
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.selectAddedProcedure(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[2]
        );

        enterpriseConfig.verifyDocumentedDataForProcedurecode(
          td_fee_schedule_tcid_262407.FeeSchedule.ModifiedProcedureDescription
            .description,
          td_fee_schedule_tcid_262407.FeeSchedule.StatusDropDownValues[1],
          td_fee_schedule_tcid_262407.FeeSchedule.Amount[1],
          td_fee_schedule_tcid_262407.FeeSchedule.TypeOfBill[1]
        );
        // #endregion

        // #region -To verify the delete(inacivate) procedure by clicking on trash icon and selecting no initially and then selecting yes

        cy.cGroupAsStep(
          'Verifying the delete procedure functionality for Hcpcs code'
        );
        enterpriseConfig.inactivateProcedureItem(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[2],
          YesOrNo.no
        );
        enterpriseConfig.inactivateProcedureItem(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[2],
          YesOrNo.yes
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );

        enterpriseConfig.clickOnSubMenuItem(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.FEE_SCHEDULE
            .FEE_SCHEDULE_LABEL[0]
        );

        enterpriseConfig.verifyProcedureItemExists(
          td_fee_schedule_tcid_262407.FeeSchedule.HcpcsCodeProcedure[2],
          false
        );
        sisOfficeDesktop.logout();
        cy.reload();

        // #endregion
      });
    });
  }

  verifyNonAdminUserPermissions() {
    describe('To verify whether non admin user has no permission to view Internal feature tab', () => {
      it('Verifying that Internal Feature tab is not available for non admin users', () => {
        /**********Login To Application***********/
        const login = new SISCompleteLogin();
        login.login(
          UserList.GEM_USER_1[0],
          UserList.GEM_USER_1[1],
          OrganizationList.GEM_ORG_3
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );

        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );

        // #region -Non admin user navigates to facility managment ,selects organization and verifying if Internal tab is visible to the non admin user

        cy.cGroupAsStep(
          'Navigating to facility management and selecting the organization and verifying internal tab visibility for non-admin user'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );

        enterpriseConfig.verifyTabs(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0],
          false
        );
        // #endregion
      });
    });
  }
}
