import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  DoneOrCancel,
  EnableOrDisable,
  ShowOrHide,
} from '../../../../../support/common-core-libs/application/common-core';
import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_cbo_management_facility_tcid_270825 } from '../../../../../fixtures/shared/enterprise-configuration/cbo-views-facility-management-tcid-270825.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();

/* const values */
const featureFlag = '155';
const enterprise = 'Enterprise';
const admin = 'sisAdmin';

export class CBOManagementTcId270825 {
  verifyCBOManagementMapping() {
    describe('Verify CBO feature flag in CBO Management and CBO Details', () => {
      it('Verifying CBO feature flag under Facility Management Internal tab and CBO Details and Mapping CBO Entity to Users', () => {
        // #region Navigating to Enterprise build and verifying CBO feature flag

        cy.cGroupAsStep(
          'Navigating to Enterprise build and verifying CBO feature flag'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifyFeatureFlag(featureFlag, ShowOrHide.hide);
        enterpriseConfig.verifyMenuInEnterpriseConfig(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0],
          false
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ADD_ON_FEATURES.ADD_ON_FEATURES_LABEL[0]
        );
        enterpriseConfig.selectFacilityAddOnFeatures(enterprise);
        enterpriseConfig.searchAddOnFeature(
          td_cbo_management_facility_tcid_270825.AddOnFeatures
        );
        enterpriseConfig.verifyFeatureFlag(
          featureFlag,
          EnableOrDisable.disable
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.searchAndSelectItem(
          admin,
          td_cbo_management_facility_tcid_270825.UserManagement[0].User
        );
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[0].TabName
        );
        enterpriseConfig.verifyCBOUserToggle(false, YesOrNo.yes);
        enterpriseConfig.verifyCBODetailsTab(
          td_cbo_management_facility_tcid_270825.UserManagement[1],
          false
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifyFeatureFlag(featureFlag, ShowOrHide.hide);

        // #endregion

        // #region Verifying CBO Management and CBO details when feature flag is show

        cy.cGroupAsStep(
          'Verifying CBO Management and CBO Details when feature flag is show'
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .CBO_CENTRALIZED_VIEWS[0],
          ShowOrHide.show
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifyFeatureFlag(featureFlag, ShowOrHide.show);
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.verifyFeatureFlag(featureFlag, ShowOrHide.show);
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ADD_ON_FEATURES.ADD_ON_FEATURES_LABEL[0]
        );
        enterpriseConfig.selectFacilityAddOnFeatures(enterprise);
        enterpriseConfig.searchAddOnFeature(
          td_cbo_management_facility_tcid_270825.AddOnFeatures
        );
        enterpriseConfig.verifyFeatureFlag(featureFlag, EnableOrDisable.enable);
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.searchAndSelectItem(
          admin,
          td_cbo_management_facility_tcid_270825.UserManagement[0].User
        );
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[0].TabName
        );
        enterpriseConfig.verifyCBOUserToggle(true, YesOrNo.yes);
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[1].TabName
        );
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[0].TabName
        );
        enterpriseConfig.verifyCBOUserToggle(true, YesOrNo.no);
        enterpriseConfig.verifyCBODetailsTab(
          td_cbo_management_facility_tcid_270825.UserManagement[1],
          false
        );
        enterpriseConfig.verifyCBOUserToggle(true, YesOrNo.yes);
        enterpriseConfig.verifyMenuInEnterpriseConfig(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0],
          true
        );

        // #endregion

        // #region Adding and verifying CBO Entities in CBO Management

        cy.cGroupAsStep('Adding and verifying CBO Entities in CBO Management');
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.CBO_MANAGEMENT.CBO_MANAGEMENT_LABEL[0]
        );
        enterpriseConfig.addCBOEntity(
          td_cbo_management_facility_tcid_270825.CBOManagement[0],
          DoneOrCancel.done
        );
        enterpriseConfig.mapUnMapFacilityToCBO(
          td_cbo_management_facility_tcid_270825.CBOManagement[0]
        );
        enterpriseConfig.addCBOEntity(
          td_cbo_management_facility_tcid_270825.CBOManagement[1],
          DoneOrCancel.done
        );
        enterpriseConfig.mapUnMapFacilityToCBO(
          td_cbo_management_facility_tcid_270825.CBOManagement[1]
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_management_facility_tcid_270825.CBOManagement[0]
        );
        enterpriseConfig.verifyCBOEntityNameAcronym(
          td_cbo_management_facility_tcid_270825.CBOManagement[0]
        );
        enterpriseConfig.searchCBOEntity(
          td_cbo_management_facility_tcid_270825.CBOManagement[1]
        );
        enterpriseConfig.verifyCBOEntityNameAcronym(
          td_cbo_management_facility_tcid_270825.CBOManagement[1]
        );

        // #endregion

        // #region Mapping CBO Entity and profile to the user from Users

        cy.cGroupAsStep(
          'Mapping CBO Entity and profile to the user from Users'
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.searchAndSelectItem(
          admin,
          td_cbo_management_facility_tcid_270825.UserManagement[0].User
        );
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[0].TabName
        );
        enterpriseConfig.verifyCBOUserToggle(true, YesOrNo.yes);
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[1].TabName
        );
        enterpriseConfig.mapCBOEntities(
          td_cbo_management_facility_tcid_270825.CBODetails
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.USERS.USERS[0]
        );
        enterpriseConfig.searchAndSelectItem(
          admin,
          td_cbo_management_facility_tcid_270825.UserManagement[0].User
        );
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[0].TabName
        );
        enterpriseConfig.verifyCBOUserToggle(true, YesOrNo.yes);
        enterpriseConfig.clickOnTab(
          td_cbo_management_facility_tcid_270825.UserManagement[1].TabName
        );
        enterpriseConfig.verifyCBOListInCBODetails(
          td_cbo_management_facility_tcid_270825.CBODetails
        );

        // #endregion

        // #region Verifying CBO Entities in login location window

        cy.cGroupAsStep('Verifying CBO Entities in login location window');
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.SECURITY.SECURITY_SECTION[0]
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.verifyCBODetailsInLoginWindow(
          td_cbo_management_facility_tcid_270825.CBODetails.CBOEntity[0]
        );
        enterpriseConfig.verifyCBODetailsInLoginWindow(
          td_cbo_management_facility_tcid_270825.CBODetails.CBOEntity[1]
        );

        // #endregion
      });
    });
  }
}
