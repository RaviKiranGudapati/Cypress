import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  Application,
  ShowOrHide,
} from '../../../../../support/common-core-libs/application/common-core';
import {
  YesOrNo,
  DoneOrCancel,
} from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_enterprise_config_transaction_code_tcid_264929 } from '../../../../../fixtures/shared/enterprise-configuration/enterprise-config-transaction-code-tcid-264929.td';

import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';

/* instance variables */

const sisOfcDesktop = new SISOfficeDesktop();
const enterpriseConfig = new EnterpriseConfiguration();
const transactionCodeName =
  td_enterprise_config_transaction_code_tcid_264929.TransactionCode
    .TransactionCodeName;

/* const values */
const TransactionCode = 'Transaction Codes';
const selectItem = 'Select Item';

export class EnterpriseTransactionCodeTcId264929 {
  precondition() {
    describe('Enable "Shared Dictionaries/Configurations" And verify Enterprise Build-Transaction Codes', () => {
      it('Verifying Enterprise Build-Transaction Codes Feature ', () => {
        // #region -- Change login location to enterprise

        cy.cGroupAsStep(
          'Verifying Transaction Code Feature under Enterprise Build'
        );
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        // #endregion

        // #region -- Set Shared Dictionaries/Configuration to 'Show' state
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.SIS_OFFICE
            .SHARED_DICTIONARIES_OR_CONFIGURATIONS_TEXT[0],
          ShowOrHide.show
        );
        // #endregion

        // #region -- Verifying Transaction Codes feature under Enterprise Build
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        enterpriseConfig.verifyEnterpriseBuild(true);
        enterpriseConfig.verifyItemInEnterpriseBuild(
          OR_ENTERPRISE_CONFIGURATION.ENTERPRISE_BUILD.TRANSACTION_CODE
            .TRANSACTION_CODE_LABEL[0]
        );
        // #endregion
      });
    });
  }

  verifyTransactionCodeFeature() {
    describe('Verify Transaction code functionality under Enterprise build', () => {
      it('Verify the Transaction code options at Enterprise level', () => {
        cy.cGroupAsStep(
          'Adding new transaction code and validating the functionality'
        );
        // #region -- Verify transaction code UI
        // Removed code to click on transaction code as its already selected
        enterpriseConfig.verifyTransactionCodeOptions();
        // #endregion

        // #region -- Verify transaction code add feature

        enterpriseConfig.verifyAddPopUpWindow();
        enterpriseConfig.verifyTransactionCodeOptions();
        enterpriseConfig.addTransactionCode(transactionCodeName);
        enterpriseConfig.clickOnCancelButtonInTransactionCodeAddWindow();
        enterpriseConfig.verifyTransactionCodeOptions();
        enterpriseConfig.addTransactionCode(transactionCodeName);
        enterpriseConfig.clickAddTransactionDone(DoneOrCancel.done);
        enterpriseConfig.verifyTransactionCodeExists(transactionCodeName, true);
        enterpriseConfig.observeTickMarkForSelectedTransactionCode(
          transactionCodeName
        );
        enterpriseConfig.verifyTextInTransactionCode(transactionCodeName);
        enterpriseConfig.verifyTransactionType(transactionCodeName, selectItem);
        enterpriseConfig.verifyTransactionCodeTypeItems();
        // #endregion

        cy.cGroupAsStep(
          'Verifying transaction code option under configuration tab'
        );
        // #region - Navigating to internal tab
        cy.cRemoveMaskWrapper(Application.office);
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        enterpriseConfig.clickOnTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .CONFIGURATIONS_TAB[0]
        );
        // #endregion

        // #region - Verifying default behavior for transaction code
        enterpriseConfig.verifyColumnsInConfigurationsTab();
        enterpriseConfig.verifyMouseHoverTextInConfigurationsTab();
        enterpriseConfig.verifyDefaultBehaviorToggleSwitch(TransactionCode);
        enterpriseConfig.selectYesNoForIncludeEnterpriseItems(
          YesOrNo.yes,
          TransactionCode
        );
        enterpriseConfig.verifyYesNoIsEnabledForIncludeEnterpriseItems(
          YesOrNo.yes,
          TransactionCode
        );
        enterpriseConfig.verifyYesNoIsEnabledForAllowAddToConfiguration(
          YesOrNo.yes,
          TransactionCode
        );
        // #endregion
      });
    });
  }
}
