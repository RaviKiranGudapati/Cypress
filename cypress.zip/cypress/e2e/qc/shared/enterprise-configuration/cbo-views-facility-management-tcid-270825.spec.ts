import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { CBOManagementTcId270825 } from './scenarios/tcid-270825.sc';

/* instance variables */
const cboManagement = new CBOManagementTcId270825();

/*****************Test Script Validation Details **********************
 * * Verify CBO Management option under 'Management Settings' and feature flag under Facility Management Internal tab
 * *Script Execution Approach -
 * 1.Login to the application and navigate to Enterprise settings
 * 2.Verify new feature flag CBO Centralized View is Hide by default
 * 3.Verify new section CBO Management is available when feature flag is in Show state
 * 4.Verify CBO entities can be added and mapped with multiple facilities in CBO Management
 * 5.Navigate to Users, verify that CBO User toggle is available and default state is No
 * 6.Verify CBO details section with entities and profile data
 * 7.Verify that added entities can be mapped with a CBO user
 * 8.Verify that CBO entity is displayed in the login location window
 */

describe(
  'Verify CBO Management option under Management Settings and feature flag under Facility Management Internal tab',
  {
    tags: [
      'enterprise-configuration',
      'cbo-management',
      'US#270061',
      'TC#270825',
    ],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        cboManagement.verifyCBOManagementMapping();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
