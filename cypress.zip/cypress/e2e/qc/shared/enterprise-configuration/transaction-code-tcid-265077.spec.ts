import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseTransactionCodeTcId265077 } from './scenarios/tcid-265077.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseTransactionCode = new EnterpriseTransactionCodeTcId265077();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Navigating to User Icon --> Change Login Location --> Enterprise Settings --> Navigate to Transaction codes
 * 2. Validating that system default codes are not available in the enterprise transaction code
 * 3. Adding a new transaction code and verify the default type dropdown options and transaction code length
 * 4. Verifying updates made on the transaction code name and type values
 * 5. Verifying duplicate warning messages when adding transaction code with the same name as available in the list
 * 6. Verifying deletion of the newly added transaction code
 */

describe(
  'Verify Addition Updating Deletion of new Transaction codes and error message check for duplicate and default codes at Transaction code option at Enterprise settings',
  {
    tags: ['enterprise-configuration', 'US#237464', 'TC#265077'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseTransactionCode.verifyTransactionCodeAtEnterprise();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
