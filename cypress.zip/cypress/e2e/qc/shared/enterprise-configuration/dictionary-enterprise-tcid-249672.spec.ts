import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterPriseDictionaryTcId249672 } from './scenarios/tcid-249672.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseDictionary = new EnterPriseDictionaryTcId249672();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Login to the application
 * 2.Select user menu dropdown
 * 3.Change login location
 * 4.Select enterprise
 * 5.Select facility management from management settings
 * 6.Search gem_Org001 and select internal tab
 * 7.Verify the shared configuration and dictionary toggle button should be disabled
 * 8.Enable the toggle button and verify enterprise build on the left side under configuration.
 * 9.Select Dictionaries and select Insurance Plan Type dictionary.
 * 10.Add Dictionary items with active and inactive state
 * 11.Navigate to facility management dictionaries
 * 12.verify the ui and i icon tool tip message
 * 13.Verify the Insurance plan type toggle button behavior
 * 14. Logout from application.
 */

describe(
  'Verify the availability of Enterprise build and UI of Dictionary, along with the toggle button behavior under facility management dictionary tab',
  { tags: ['enterprise-dictionary', 'US#265139', 'TC#249672'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseDictionary.verifyDictionaryEnableFeature();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
