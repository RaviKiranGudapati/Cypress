import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseContractsTcId270425 } from './scenarios/tcid-270425.sc';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseContracts = new EnterpriseContractsTcId270425();

/*****************Test Script Validation Details **********************
 * * Verify Contracts option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name.
 * 3. Verify Contracts feature is displaying under Enterprise Build section.
 * 4. Ensure shared Fee schedule and transaction code are available.
 * 5. Navigate to Contracts under Enterprise build, add a new contract, verify the charter limit for contract name and notes fields.
 * 6. Click on Posting options and verify warning message and dropdown options in posting options.
 * 7. Click on Review/Edit options and verify the headers, and type options, Exempt options for any procedure.
 * 8. Navigate to transaction under enterprise build and come back to contract add new contract select any option from contract type.
 * 9. Navigate to some other contract and get back the contract created and verify the contract type is disabled.
 * 10.Click on add button, give the name of any existing contract, and verify the warning message in add contract pop up.
 * 11.Open any Existing contract and edit its name with some other existing contract and verify the eff date, exp date and contract type is disabled.
 * 12.Click on the Posting options and verify the fields are disabled. Click on Review/Edit tab check the type , exempt fields are disabled.
 */

describe(
  'Verify Contracts feature at Enterprise build and under Configurations at Enterprise settings Facility Management tab',
  {
    tags: ['enterprise-configuration', 'US#237465', 'TC#270425'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed

    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseContracts.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {}
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseContracts.verifyContractsCodeFeature();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => {}
    );
  }
);
