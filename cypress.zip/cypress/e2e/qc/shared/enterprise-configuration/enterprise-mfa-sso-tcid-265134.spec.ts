import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { EnterpriseMfaSsoTcId265134 } from './scenarios/tcid-265134.sc';

/* instance variables */
const mfaSso = new EnterpriseMfaSsoTcId265134();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into application and select change login location and select enterprise settings.
 * 2. check users , create copy , existing  users
 * 3. Document mandatory  details
 * 4. Verify email as mandatory  for MFA users
 * 5. Verify the warning lines for invalid, duplicate email address
 * 6. Logout from application
 */

describe(
  'Verify the MFA feature flag in application and enterprise and Verifying the Email is mandatory field for new users and Checking Invalid and Duplicate error message for email',
  { tags: ['enterprise-configuration', 'TC#265134', 'US#255971'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        mfaSso.enterpriseSettings();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
