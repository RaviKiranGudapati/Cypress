import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseTransactionCodeTcId265079 } from './scenarios/tcid-265079.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseTransactionCode = new EnterpriseTransactionCodeTcId265079();

/*****************Test Script Validation Details **********************
 * * Verify sharing functionality of Transaction codes (Enterprise and Facility level)
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name
 * 3. Ensure from Enterprise settings>Facility Management>FASC>Configurations tab>Transaction codes>Yes toggle should be selected for both Include Enterprise Items and Allow add to Configuration
 * 4. Ensure from Enterprise settings>Facility Management>FASC1>Configurations tab>Transaction codes>Yes toggle should be selected for Include Enterprise Items and No option should be selected for Allow add to Configuration
 * 5. Ensure from Enterprise settings>Facility Management>FASC2>Configurations tab>Transaction codes>No toggle should be selected for Include Enterprise Items and here Allow Add to Configuration toggles (Yes/No) should be greyed out/disabled state
 * 6. Go to Enterprise build>Transaction codes, Click Add button and add a new Transaction code item (Transaction codeA) with Type
 * 7. Change login location>select FASC>Go to Application settings>Transaction Codes>Check that "Add" button is in enabled state and added Transaction code from enterprise level.
 * 8. Add new Transaction code from FASC facility and observe soruce field section.
 * 9. Go to Enterprise settings>Enterprise Build>Transaction codes, check the newly added code from FASC facility is not displaying.
 * 10.Change login location>select FASC1>Go to Application settings>Transaction Codes>Check the Transaction Codes added from enterprise are correctly reflecting and "Add" button should be disabled state.
 * 11.Change login location>select FASC2>Go to Application settings>Transaction Codes>>Check the Transaction Codes added from enterprise are not reflecting.
 * 12.Go to Enterprise settings>Enterprise Build>Transaction codes, delete the added code from Enterprise and verify in FASC,FASC1 and FASC2 the code got deleted.
 * 13.Add new Transaction Code at Enterprise and mapp that to any case, now again from enterprise delete the mapped transaction code from facility(It should get delete from Enterprise but not from facilities)
 */

describe(
  'Verify sharing functionality of Transaction codes at Enterprise and Facility level',
  {
    tags: ['enterprise-configuration', 'US#237464', 'TC#265079'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseTransactionCode.preCondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseTransactionCode.verifyTransactionCode();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
