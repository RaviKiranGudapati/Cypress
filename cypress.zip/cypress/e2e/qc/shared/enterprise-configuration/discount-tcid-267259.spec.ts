import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseDiscountTcId267259 } from './scenarios/tcid-267259.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseDiscountConfig = new EnterpriseDiscountTcId267259();

/*****************Test Script Validation Details **********************
 * * Verify Transaction code option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name
 * 3. Ensure some Transaction code are created at Enterprise level
 * 4. Select Discount under Enterprise Build, verify the state of Done and Cancel button in Add popup window
 * 5. Enter more than 80 characters in name field and verify the length
 * 6. Document percentage, Transaction, WriteOff group code and WriteOff Reason code dropdown values
 * 7. Verify the saved discounts data
 * 8. Add the existing discount and verify the duplicate warning message in add popup window
 * 9. Remove the name field at Discounts, verify the state of Add button and all 3 dropdown values
 */

describe(
  'Verify Addition, Updating of new Discount item & error message check for duplicate items at Discounts option Enterprise level',
  {
    tags: ['enterprise-configuration', 'US#237466', 'TC#267259'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseDiscountConfig.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseDiscountConfig.verifyDiscountFunctionUnderEnterpriseBuild();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
