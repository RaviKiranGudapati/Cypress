import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { EnterpriseContractsTcId270427 } from './scenarios/tcid-270427.sc';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const enterpriseContracts = new EnterpriseContractsTcId270427();

/*****************Test Script Validation Details **********************
 ** * Verify Contracts option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and enable 'Shared Dictionaries/Configuration' to Show under internal tab based on facility name.
 * 3. Verify Contracts feature is displaying under Enterprise Build section.
 * 4. Ensure shared Fee schedule and transaction code are available.
 * 5. Add contract at enterprise level and verify all fields, fields in posting options nd review edit
 * 6. Verify the state of contract type is disabled after navigating to some where and getting back to the respective contract
 * 7. Verify the warning message when contract name is cleared and try to save it
 * 8. Verify the fields under Posting option are disabled when the contact name is cleared are duplicated
 * 9. Verify the fields under Review/Edit are disabled when the contact name is cleared are duplicated
 */

describe(
  'Verify Transaction code feature at Enterprise build and under Configurations at Enterprise settings Facility Management tab',
  {
    tags: ['enterprise-configuration', 'US#237465', 'TC#270427'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed

    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      enterpriseContracts.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {}
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        enterpriseContracts.verifyContractsCodeFeature();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => {}
    );
  }
);
