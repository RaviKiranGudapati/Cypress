import { UserList } from '../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { DocumentsAcknowledgedTcId270998 } from './scenarios/tcid-270998.sc';

/* instance variables */
const documentsAcknowledged = new DocumentsAcknowledgedTcId270998();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * Before running the spec make sure WorkList270998_Yes and WorkList270998_No are not present in pre-admission instructions in application settings
 * This script uses seed data for patient creation.
 * 1. Login to application
 * 2. Add the worklist template for pre admission instructions.
 * 3. Document the template details in nursing desktop in pre-admit task.
 * 4. Verify widget details in patient check-in.
 * */

describe(
  'Verify documents in patient checkin when documented in sis charts for the case.',
  {
    tags: ['pre-admission-instructions', 'TC#270998', 'US#56426'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        documentsAcknowledged.worklistTemplateValidations();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
