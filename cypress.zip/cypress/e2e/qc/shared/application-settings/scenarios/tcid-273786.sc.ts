import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';

import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_surgery_board_phase } from '../../../../../fixtures/shared/application-settings/surgery-board-phase-tcid-273786.td';

import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { NursingDept } from '../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { BoardSettingsHeaders } from '../../../../../app-modules-libs/patient-tracking/enums/surgery-board.enum';
import { trackers } from '../../../../../app-modules-libs/patient-tracking/enums/tracking-board.enum';

import ChartsCoverFaceSheet from '../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import { TrackerBoard } from '../../../../../app-modules-libs/patient-tracking/tracking-board';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import PreOperativeDepartment from '../../../../../app-modules-libs/sis-charts/departments/pre-operative/pre-operative';
import OperativeDepartment from '../../../../../app-modules-libs/sis-charts/departments/operative/operative';
import RecoveryDepartment from '../../../../../app-modules-libs/sis-charts/departments/recovery/recovery';
import Phase1Department from '../../../../../app-modules-libs/sis-charts/departments/phase-1/phase-1';
import Phase2Department from '../../../../../app-modules-libs/sis-charts/departments/phase-2/phase-2';
import Phase3Department from '../../../../../app-modules-libs/sis-charts/departments/phase-3/phase-3';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ChartsLogin from '../../../../../app-modules-libs/sis-charts/login/login';
import { SurgeryBoard } from '../../../../../app-modules-libs/patient-tracking/surgery-board';

/* instance variables */
const createCase = new CreateCase(td_surgery_board_phase.PatientCase[2]);
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const preOperativeDepartment = new PreOperativeDepartment();
const operativeDepartment = new OperativeDepartment();
const recoveryDepartment = new RecoveryDepartment(
  td_surgery_board_phase.RecoveryInfo
);
const phase1Department = new Phase1Department();
const phase2Department = new Phase2Department();
const phase3Department = new Phase3Department();
const chartsLogin = new ChartsLogin();
const trackerBoard = new TrackerBoard();
const surgeryBoard = new SurgeryBoard();

/* const values */
const dob = '10/10/1990';

export class SurgeryBoardTrackerTcId273786 {
  preCondition() {
    describe('Verify surgery board tracker with different patients documented in different locations and rooms', () => {
      it('Documenting the patients in different departments and locations.', () => {
        // #region - Arriving the patient-2 from schedule grid and adding anesthesia type.

        cy.cGroupAsStep('Clicking on arrive for patient-2 from schedule grid');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_phase.PatientCase[1].PatientDetails.PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVE_BUTTON[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_phase.PatientCase[1].PatientDetails.PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );

        createCase.selectAnesthesiaType(
          td_surgery_board_phase.PatientCase[1].CaseDetails.AnesthesiaType ?? ''
        );
        sisOfficeDesktop.clickDoneButton();

        // #endregion

        // #region - Check-in the patient-3 from schedule grid.

        cy.cGroupAsStep(
          'Clicking on check-in for patient-3 from schedule grid'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_phase.PatientCase[2].PatientDetails.PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.enterDOB(dob);
        createCase.clickCheckInDone();

        // #endregion

        // #region - Entering Pre-op admission time for patient-4.

        cy.cGroupAsStep(
          'Enter pre-op admission time for patient-4 in nursing desktop'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.pickPatient(
          td_surgery_board_phase.PatientCase[3].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.pre_operative);
        preOperativeDepartment.enterAdmissionTimeRoom(
          td_surgery_board_phase.DepartmentInfo[0]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Entering Pre-op admission time and ready for transfer as yes for patient-5.

        cy.cGroupAsStep(
          'Enter pre-op admission time and click ready for transfer as Yes for patient-5 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_phase.PatientCase[4].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.pre_operative);
        preOperativeDepartment.enterAdmissionTimeRoom(
          td_surgery_board_phase.DepartmentInfo[1]
        );
        preOperativeDepartment.clickYesNoInReadyForTransfer(YesOrNo.yes);
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Entering Operative admission time for patient-6.

        cy.cGroupAsStep(
          'Enter operative admission time for patient-6 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_phase.PatientCase[5].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        operativeDepartment.enterAdmissionTimeRoom(
          td_surgery_board_phase.DepartmentInfo[2]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Entering Phase-1 admission time for patient-7.

        cy.cGroupAsStep(
          'Enter phase-1 admission time for patient-7 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_phase.PatientCase[6].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.phase1);
        phase1Department.enterAdmissionTimeRoom(
          td_surgery_board_phase.DepartmentInfo[3]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        // #endregion

        // #region - Entering Phase-2 admission time for patient-8.

        cy.cGroupAsStep(
          'Enter phase-2 admission time for patient-8 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_phase.PatientCase[7].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.phase2);
        phase2Department.enterAdmissionTimeRoom(
          td_surgery_board_phase.DepartmentInfo[4]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Entering Phase-3 admission time for patient-9.

        cy.cGroupAsStep(
          'Enter phase-3 admission time for patient-9 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_phase.PatientCase[8].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.phase3);
        phase3Department.enterAdmissionTimeRoom(
          td_surgery_board_phase.DepartmentInfo[5]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Discharging Patient-10 from Phase-3 department.

        cy.cGroupAsStep(
          'Discharge patient-10 from phase-3 department in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_phase.PatientCase[9].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.phase3);
        phase3Department.enterAdmissionTimeRoom(
          td_surgery_board_phase.DepartmentInfo[5]
        );
        phase3Department.clickOnTransfer();

        recoveryDepartment.caseDischarge();

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        sisOfficeDesktop.logout();

        // #endregion
      });
    });
  }
  verifyPatientsData() {
    describe('Verify surgery board tracker with different patients documented in different locations and rooms', () => {
      it('Verifying the patients in surgery board tracker', () => {
        // #region -Verify able to land on surgery board tracker from patient tracking and verify the patient details

        cy.cGroupAsStep(
          'Navigate to patient tracking url and verify user able to land on surgery board tracker.'
        );

        cy.visit(Cypress.env('patientTracking'));

        chartsLogin.login(
          UserList.SIS_ADMIN[0],
          UserList.SIS_ADMIN[1],
          OrganizationList.GEM_ORG_PHASE_001
        );
        trackerBoard.selectPatientTrackingBoard(trackers.surgery_board_tracker);

        surgeryBoard.clickGearIcon();

        surgeryBoard.clickToggleInBoardSettings(
          BoardSettingsHeaders.discharged_cases
        );
        surgeryBoard.clickToggleInBoardSettings(
          BoardSettingsHeaders.unarrived_cases
        );
        surgeryBoard.clickDoneInBoardSettings();
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[0]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[1]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[2]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[3]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[4]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[5]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[6]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_phase.SurgeryBoardTrackerInfo[7]
        );

        // #endregion
      });
    });
  }
}
