import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';
import { selectorFactory } from '../../../../../support/common-core-libs/framework/selector-factory';

import { td_block_schedule_tcid_9730 } from '../../../../../fixtures/shared/application-settings/block-schedule-tcid-9730.td';
import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';

/* instance variables */
const nursingConfiguration = new NursingConfiguration();
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();

enum tcid9730 {
  exist = 'Exist',
  not_exist = 'NotExist',
  deselect_radio_Btn = 'fa-circle-o',
  multi_sel_dropdown_text = 'Multiple Selected',
}

export class BlockScheduleTcId9730 {
  VerifyBlockScheduleWeeklyRadioButtonFunctionality() {
    describe('Verify Block scheduling functionality in nursing configuration', () => {
      it('Create new Blocks From Block Scheduling Configurations and verify warning messages', () => {
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        cy.cGroupAsStep('Selecting Block Scheduling Configuration');
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0],
          true
        );
        nursingConfiguration.addBlockScheduling(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[2]
        );
        nursingConfiguration.addBlockScheduling(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );

        cy.cGroupAsStep(
          'Update Recur every value and navigate to other block then navigate back and verify value is saved'
        );
        // Recur every value
        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0],
          '6'
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[2]
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );
        nursingConfiguration.verifyBlockSchedulingTextInputFieldValue(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.RecurEvery[3]
        );

        cy.cGroupAsStep(
          'Enter all mandatory details for the block,Navigate to other Block and Navigate back verify warning message absence'
        );
        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Physician
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Room
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Specialty
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[0]
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.End_Time[0]
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Date
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.End_Date
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn
        );

        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[2]
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );

        nursingConfiguration.VerifyBlockScheduleErrors(
          tcid9730.not_exist,
          AppErrorMessages.block_warning
        );

        cy.cGroupAsStep('Deselect weeks on dropdown and verify error message');
        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn
        );

        nursingConfiguration.VerifyBlockScheduleErrors(
          tcid9730.exist,
          AppErrorMessages.block_warning
        );

        cy.cGroupAsStep('Check start time and end time is editable');
        nursingConfiguration.enterAndVerifyInput(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[1],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[1]
        );
        nursingConfiguration.enterAndVerifyInput(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[1],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[1]
        );

        cy.cGroupAsStep(
          'Enter Start and End time same and Verify that Message ""Start Time" and "End Time" are the same'
        );
        // Step 9 Enter Start and End Date same
        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[1]
        );
        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[1]
        );
        // To focus away
        nursingConfiguration.clickBlockScheduleSubheader();
        nursingConfiguration.VerifyBlockScheduleErrors(
          tcid9730.exist,
          AppErrorMessages.start_time_end_time_same_warning
        );

        cy.cGroupAsStep(
          'Enter Start time after End time same and Verify that Message "End Time must be after Start Time"'
        );
        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.End_Time[0]
        );
        // Code to focus away
        nursingConfiguration.clickBlockScheduleSubheader();
        nursingConfiguration.VerifyBlockScheduleErrors(
          tcid9730.exist,
          AppErrorMessages.end_time_should_greater
        );

        cy.cGroupAsStep(
          'Check Weekly radio button under recurrence pattern Verify Recur every "Text field" week(s) on multi-select drop-down for all week days Verify that 1-99 digit only accepted in recur every box'
        );
        cy.cIsVisible(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0]
        );
        // Opening the weeks on dropdown
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[1]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[1]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[2]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[3]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[4]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[5]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[6]
        );

        nursingConfiguration.enterAndVerifyInput(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.RecurEvery[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.RecurEvery[1]
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn
        );
      });
    });
  }

  VerifyMonthlyRadioButtonFunctionality() {
    describe('Verify Monthly radio button functionality', () => {
      it('Select monthly radio button and verify recurrence pattern and dropdown functionality ', () => {
        // Selecting multiple day in weeks on dropdown is already done

        cy.cGroupAsStep(
          'Check Weekly radio button under recurrence pattern Verify data selected is saved'
        );
        cy.cIncludeText(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON_VALUE[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON_VALUE[0],
          tcid9730.multi_sel_dropdown_text
        );
        cy.cGroupAsStep(
          'Check Monthly radio button under recurrence pattern Verify data displayed on right side of radio button'
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );
        nursingConfiguration.selectWeeklyAndMonthlyRadioButton(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTHLY[0]
        );
        // Verify weekly radio button is unselected
        cy.cHasClass(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY_TOGGLE[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY_TOGGLE[0],
          tcid9730.deselect_radio_Btn
        );

        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[0]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[1]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[2]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[3]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[4]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[5]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1[6]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.MonthsOn[0]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.MonthsOn[1]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.MonthsOn[2]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.MonthsOn[3]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.MonthsOn[4]
        );
        nursingConfiguration.blockScheduleVerifyDropdownValuesDisplayed(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.MonthsOn[5]
        );

        cy.cHasValue(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[0],
          1
        );

        nursingConfiguration.VerifyBlockScheduleErrors(
          tcid9730.exist,
          AppErrorMessages.block_warning
        );

        cy.cGroupAsStep(
          'Update of every month value and navigate to other block then navigate back and verify value is saved'
        );
        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.RecurEvery[2]
        );
        // Navigate to other block and navigate back
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[2]
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );
        cy.cHasValue(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.RecurEvery[2]
        );

        cy.cGroupAsStep(
          'Select Value from first dropdown and verify Banner is displayed'
        );
        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.MonthsOn
        );
        nursingConfiguration.VerifyBlockScheduleErrors(
          tcid9730.exist,
          AppErrorMessages.block_warning
        );

        cy.cGroupAsStep(
          'Verify that user is able to document any value between 1 and 99 in of Every field'
        );
        nursingConfiguration.enterAndVerifyInput(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.OF_EVERY[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.RecurEvery[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.RecurEvery[1]
        );

        cy.cGroupAsStep(
          'Select Value from Second dropdown and verify Banner is not displayed'
        );
        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn2
        );
        nursingConfiguration.VerifyBlockScheduleErrors(
          tcid9730.not_exist,
          AppErrorMessages.block_warning
        );

        cy.cGroupAsStep(
          'Toggle  Weekly radio button and verify that last entered data should be auto-populate'
        );
        nursingConfiguration.selectWeeklyAndMonthlyRadioButton(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY[0]
        );

        nursingConfiguration.selectWeeklyAndMonthlyRadioButton(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTHLY[0]
        );
        cy.cIncludeText(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS_VALUE[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_DAYS_LISTS_VALUE[0],
          tcid9730.multi_sel_dropdown_text
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0],
          true
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0],
          true
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );

        cy.cGroupAsStep(
          'Enter Start date and End date as past date under Range of Reoccurrence and verify past date should not be selected'
        );
        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
          CommonUtils.getPreviousDay().replace(/[/]/g, '')
        );
        nursingConfiguration.clickBlockScheduleSubheader();
        cy.cHasValue(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
          ''
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
          CommonUtils.getPreviousDay().replace(/[/]/g, '')
        );
        nursingConfiguration.clickBlockScheduleSubheader();
        // Check end date should be empty
        cy.cHasValue(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[1],
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
          ''
        );

        cy.cGroupAsStep(
          'Navigate to other Configuration and Navigate back and verify block is saved & saving only happened for Configuration Settings. Block schedule will not display on the schedule'
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0],
          true
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0],
          true
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );
        sisOfficeDesktop.selectSisLogo();

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        cy.cNotExist(
          selectorFactory.patientCaseTileInScheduleGrid(
            td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
          ),
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[0]
        );
      });
    });
  }

  createWeeklyBlocksFromBlockSchedulingConfigurations() {
    describe('Create a weekly Block from block schedule and verify on the schedule', () => {
      it('Create new Blocks From Block Scheduling Configurations and verify block is visible on todays and future date on schedule', () => {
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        cy.cGroupAsStep(
          'Selecting Block Scheduling Configuration and create a block with Recur 1 week on (All Days) and verify of schedule'
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0],
          true
        );
        nursingConfiguration.addBlockScheduling(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[1]
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Physician
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Room
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Specialty
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Time[0]
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.End_Time[0]
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Start_Date
        );

        nursingConfiguration.blockSchedulingTextInputField(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.End_Date
        );

        nursingConfiguration.enterBlockDetailsInBlockSchedulingDropdowns(
          OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.WeeksOn1
        );

        cy.cGroupAsStep(
          'Navigate to sis office and verify block in block schedule for current date'
        );
        nursingConfiguration.clickBlockScheduleSubheader();
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[2]
        );
        nursingConfiguration.selectExistingBlock(
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[1]
        );
        sisOfficeDesktop.selectSisLogo();

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );

        cy.cIsVisible(
          selectorFactory.patientCaseTileInScheduleGrid(
            td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[1]
          ),
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[1]
        );

        cy.cGroupAsStep(
          'Verify the block in block schedule in one month future date'
        );
        sisOfficeDesktop.selectDateFromScheduleGrid(
          CommonUtils.getAfterDate_mmddyyyy(30)
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        cy.cIsVisible(
          selectorFactory.patientCaseTileInScheduleGrid(
            td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[1]
          ),
          td_block_schedule_tcid_9730.BlockInfos.CreateBlock.Block_Name[1]
        );
      });
    });
  }
}
