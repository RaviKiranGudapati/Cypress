import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import { OnOff } from '../../../../../support/common-core-libs/application/common-core';

import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import ChartsLogin from '../../../../../app-modules-libs/sis-charts/login/login';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import { TrackerBoard } from '../../../../../app-modules-libs/patient-tracking/tracking-board';
import { trackers } from '../../../../../app-modules-libs/patient-tracking/enums/tracking-board.enum';

/* instance variables */
const nursingConfiguration = new NursingConfiguration();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const sisOfficeDesktop = new SISOfficeDesktop();
const chartsLogin = new ChartsLogin();
const trackerBoard = new TrackerBoard();
const enterpriseConfig = new EnterpriseConfiguration();
const sisOfcDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();

export class PatientTrackingTcId273784 {
  verifySurgeryBoardFeatureFlag() {
    describe('Verify surgery board feature flag in enterprise add on feature and surgery board tracker in application settings', () => {
      it('Verify surgery board feature is on in facility enterprise setting and able to land on surgery tracker board.', () => {
        // #region - Navigate to surgery board tracker when feature flag is on

        cy.cGroupAsStep(
          'Verify feature toggle is on and verify surgery board in patient tracking.'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_3
        );
        enterpriseConfig.selectFeatureTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .INTERNAL_TAB[0]
        );
        enterpriseConfig.togglesInInternalTab(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL
            .SURGERY_BOARD_TRACKER.HEADER[0],
          OnOff.on
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        scheduleGrid.scheduleGridEnable();
        sisOfcDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.PATIENT_TRACKING.SUB_HEADER[0]
        );
        nursingConfiguration.verifyTrackerInPatientTracking(
          OR_NURSING_CONFIGURATION.PATIENT_TRACKING.SURGERY_BOARD_TRACKER[0]
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.logout();
        // #endregion

        // #region -Verify able to land on surgey board tracker from patient tracking

        cy.cGroupAsStep(
          'Navigate to patient tracking url and verify user able to land on surgery board tracker.'
        );

        cy.visit(Cypress.env('patientTracking'));

        chartsLogin.login(
          UserList.SIS_ADMIN[0],
          UserList.SIS_ADMIN[1],
          OrganizationList.GEM_ORG_3
        );
        trackerBoard.selectPatientTrackingBoard(trackers.surgery_board_tracker);
        // #endregion
      });
    });
  }
}
