import { Application } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_preference_card_tcid_260015 } from '../../../../../fixtures/shared/application-settings/preference-card-tcid-260015.td';
import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';

/* instance variables */
const nursingConfiguration = new NursingConfiguration();
const nursingConfLayout = new NursingConfigurationLayout();
const createCase = new CreateCase(td_preference_card_tcid_260015.PatientCase);
const sisOfficeDesktop = new SISOfficeDesktop();

export class PreferenceCardTcId260015 {
  verifyPreferenceCardCreation() {
    describe('Preference card creation and verification', () => {
      it(' Click on add button in preference card, add name and click done and add preference card data', () => {
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CONFIGURATION[0]
        );
        nursingConfiguration.verifyHelperText;
        nursingConfiguration.clickOnAdd();
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.COMMON.ADD.ADD_NAME[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AddPreferenceCard
        );

        cy.cGroupAsStep('Select and verify case specialty dropdown');
        nursingConfiguration.clickOnCaseSpecialtyDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CASE_SPECIALTY[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[0]
        );
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CASE_SPECIALTY[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[2]
        );
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CASE_SPECIALTY[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[3]
        );
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CASE_SPECIALTY[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[1]
        );
        nursingConfiguration.preferenceCardcaseSpecialtyItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[0]
        );

        cy.cGroupAsStep('Verify Anesthesia Type select dropdown');
        nursingConfiguration.clickOnAnesthesiaDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .ANESTHESIA_TYPE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[0]
        );
        nursingConfiguration.preferenceCardAnesthesiaDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[0]
        );

        cy.cGroupAsStep('Verify Physician select dropdown');
        nursingConfiguration.clickOnPhysicianDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Physician[0]
        );
        nursingConfiguration.preferenceCardPhysicianDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.Physician[0]
        );

        cy.cGroupAsStep('Verify Duration Time and DurationText');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Duration[0]
        );
        nursingConfiguration.clickOnDurationMinutesTextAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.DurationText
        );
        nursingConfiguration.clickOnDurationBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.Duration[1]
        );

        cy.cGroupAsStep('verify Clean Up Time');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CLEAN_UP_TIME[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CleanUpTime[0]
        );
        nursingConfiguration.clickOnCleanUpTimeBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.CleanUpTime[1]
        );
        nursingConfiguration.clickOnCleanUpTimeTextAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.MinutesText
        );

        cy.cGroupAsStep('verify Physician Preferences');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[0],
          td_preference_card_tcid_260015.PreferenceCardInfo
            .PhysicianPreferences[0]
        );
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[0],
          td_preference_card_tcid_260015.PreferenceCardInfo
            .PhysicianPreferences[0]
        );

        cy.cGroupAsStep('verify Appointment type');
        nursingConfiguration.clickOnAppointmentTypeDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[0]
        );
        nursingConfiguration.preferenceCardAppointmentTypeDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[0]
        );

        cy.cGroupAsStep('verify Cpt trade mark');
        nursingConfiguration.clickOnCPTTrademarkTextAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.CPTTrademark
        );
        nursingConfiguration.clickOnCPTTrademarkTextAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.CPTTrademark
        );

        cy.cGroupAsStep('Procedure select dropdown');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Procedures[0]
        );
        nursingConfiguration.verifyProcedure(
          td_preference_card_tcid_260015.PreferenceCardInfo.Procedures[0]
        );
      });
    });
  }

  verifyExistingPreferenceCard() {
    describe('Navigating to other page and then verifying existing preference card by updating details', () => {
      it(' Navigate to other page Selecting RCM in Configuration and Navigate back to Preference Cards Configuration page ', () => {
        nursingConfLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0]
        );

        cy.cGroupAsStep(
          'Navigate to Preference Cards configuration Select Pre-existing Preference card having Physician Preference data Check Physician Preference field data.'
        );
        nursingConfLayout.typeConfiguration(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CONFIGURATION[0]
        );
        nursingConfiguration.clickOnExistingPreferenceCard();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[0],
          td_preference_card_tcid_260015.PreferenceCardInfo
            .PhysicianPreferences[0]
        );

        cy.cGroupAsStep('Verify the data in existing preference card');
        nursingConfiguration.clickOnCaseSpecialtyDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CASE_SPECIALTY[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[0]
        );
        nursingConfiguration.preferenceCardcaseSpecialtyItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[0]
        );
        nursingConfiguration.clickOnAnesthesiaDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .ANESTHESIA_TYPE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[0]
        );
        nursingConfiguration.preferenceCardAnesthesiaDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[0]
        );
        nursingConfiguration.clickOnAppointmentTypeDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .APPOINTMENT_TYPE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[0]
        );
        nursingConfiguration.preferenceCardAppointmentTypeDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[0]
        );
        nursingConfiguration.clickOnPhysicianDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Physician[0]
        );
        nursingConfiguration.preferenceCardPhysicianDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.Physician[0]
        );
        nursingConfiguration.clickOnDurationBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.Duration[1]
        );
        nursingConfiguration.clickOnCleanUpTimeBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.CleanUpTime[1]
        );
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[0],
          td_preference_card_tcid_260015.PreferenceCardInfo
            .PhysicianPreferences[0]
        );
        nursingConfiguration.verifyProcedure(
          td_preference_card_tcid_260015.PreferenceCardInfo.Procedures[0]
        );
      });

      it('Edit the data in existing preference card data and Verify', () => {
        nursingConfiguration.clickOnCaseSpecialtyDropdown();
        cy.cRemoveMaskWrapper(Application.office);
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CASE_SPECIALTY[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[1]
        );
        nursingConfiguration.preferenceCardcaseSpecialtyItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[1]
        );

        cy.cGroupAsStep('Edit the Procedure Data and verify');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PROCEDURE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Procedures[1]
        );
        nursingConfiguration.verifyProcedure(
          td_preference_card_tcid_260015.PreferenceCardInfo.Procedures[1]
        );

        cy.cGroupAsStep('Edit the Anesthesia Type Data and verify');
        nursingConfiguration.clickOnAnesthesiaDropdown();
        cy.cRemoveMaskWrapper(Application.office);
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .ANESTHESIA_TYPE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[1]
        );
        nursingConfiguration.preferenceCardAnesthesiaDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[1]
        );

        cy.cGroupAsStep('Edit the Duration Data and verify');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.DURATION[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Duration[2]
        );
        nursingConfiguration.clickOnDurationBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.Duration[2]
        );

        cy.cGroupAsStep('Edit the Clean Up Time Data and verify');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CLEAN_UP_TIME[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CleanUpTime[2]
        );
        nursingConfiguration.clickOnCleanUpTimeBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.CleanUpTime[2]
        );

        cy.cGroupAsStep('Edit the Appointment type Data and verify');
        nursingConfiguration.clickOnAppointmentTypeDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .APPOINTMENT_TYPE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[1]
        );
        nursingConfiguration.preferenceCardAppointmentTypeDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[1]
        );

        cy.cGroupAsStep('Edit the Physician Data and verify');
        nursingConfiguration.clickOnPhysicianDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Physician[1]
        );
        nursingConfiguration.preferenceCardPhysicianDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.Physician[1]
        );

        cy.cGroupAsStep('Edit the Physician Preferences Data and verify');
        nursingConfiguration.preferenceCardText(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[0],
          td_preference_card_tcid_260015.PreferenceCardInfo
            .PhysicianPreferences[1]
        );
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[0],
          td_preference_card_tcid_260015.PreferenceCardInfo
            .PhysicianPreferences[1]
        );

        cy.cGroupAsStep('Verify the data after updating the preference card');
        nursingConfiguration.clickOnCaseSpecialtyDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CASE_SPECIALTY[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[1]
        );
        nursingConfiguration.preferenceCardcaseSpecialtyItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.CaseSpecialty[1]
        );
        nursingConfiguration.clickOnAnesthesiaDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .ANESTHESIA_TYPE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[1]
        );
        nursingConfiguration.preferenceCardAnesthesiaDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AnesthesiaType[1]
        );
        nursingConfiguration.clickOnAppointmentTypeDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .APPOINTMENT_TYPE[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[1]
        );
        nursingConfiguration.preferenceCardAppointmentTypeDropdownItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AppointmentType[1]
        );
        nursingConfiguration.clickOnPhysicianDropdown();
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION.PHYSICIAN[0],
          td_preference_card_tcid_260015.PreferenceCardInfo.Physician[1]
        );
        cy.cRemoveMaskWrapper(Application.charts);
        nursingConfiguration.clickOnDurationBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.Duration[2]
        );
        nursingConfiguration.clickOnCleanUpTimeBoxAndVerify(
          td_preference_card_tcid_260015.PreferenceCardInfo.CleanUpTime[2]
        );
        nursingConfiguration.verifyPreferenceCardFieldData(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .PHYSICIAN_PREFERENCES[0],
          td_preference_card_tcid_260015.PreferenceCardInfo
            .PhysicianPreferences[1]
        );
        nursingConfiguration.verifyProcedure(
          td_preference_card_tcid_260015.PreferenceCardInfo.Procedures[1]
        );

        cy.cGroupAsStep(
          'Verify You cannot have duplicate preference card names Check the warning text and click on cancel button'
        );
        nursingConfiguration.verifyDuplicateMessagePreferenceCardName(
          td_preference_card_tcid_260015.PreferenceCardInfo.AddPreferenceCard,
          AppErrorMessages.duplicate_preference_card
        );
      });

      it(' Click Add button and Click Create Copy tab Verify that in Free-text field should be auto-populated with "Copy of [preference card]', () => {
        nursingConfiguration.VerifyPreferenceCardCopy(
          td_preference_card_tcid_260015.PreferenceCardInfo
            .CopyPreferenceCardName
        );

        cy.cGroupAsStep(
          'Select "Preference Card1" in the list Mouse hover on the "Preference Card1" in the list'
        );
        nursingConfiguration.selectAndVerifyPreferenceCardListItem(
          td_preference_card_tcid_260015.PreferenceCardInfo.AddPreferenceCard
        );
        nursingConfiguration.verifyTrashIcon();

        cy.cGroupAsStep(
          'Remove the name Preference Card1 from Preference Card name field check the banner'
        );
        nursingConfiguration.VerifyPreferenceCardBanner(
          AppErrorMessages.preference_card_warning
        );
      });
    });
  }

  verifyCardInCaseCreation() {
    describe('Create a create and add the created preference card in it', () => {
      it(' Navigate to Business Desktop Schedule grid Click Create a Case Create Patient1 case on current date Add PreferenceCard 1 Check the Procedures', () => {
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        createCase.enterPatientDetails(
          td_preference_card_tcid_260015.PatientCase.PatientDetails
        );
        createCase.enterCaseDetails(
          td_preference_card_tcid_260015.PatientCase.CaseDetails
        );
        createCase.clickPreviousInBillingDetails();

        nursingConfiguration.clickAddAndVerifyProcedure(
          td_preference_card_tcid_260015.PreferenceCardInfo.Procedures[1]
        );
      });
    });
  }
}
