import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';
import {
  CommonGetLocators,
  Header,
} from '../../../../../support/common-core-libs/application/common-core';

import { td_rev_cyc_manager_tcid_97581 } from '../../../../../fixtures/shared/application-settings/revenue-cycle-manager-tcid-97581.td';

import { AppColors } from '../../../../../support/common-core-libs/application/constants/app-colors.constants';
import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';
import { SubRoutes } from '../../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfiguration = new NursingConfiguration();
const nursingConfigurationLayout = new NursingConfigurationLayout();

export class RevCycleManagerTcId97581 {
  verifyUI() {
    describe('Verify all the UI Validations for Revenue Cycle Manager Template Configuration', () => {
      it('Verify Background Color of Dictionary Item, Header, Sub Header, Page Load Text and Labels in RCM Template configuration', () => {
        cy.cGroupAsStep(
          'Verify Background Color of RCM before and after selecting'
        );

        cy.cWait(SubRoutes.case_request_get_pending_count);
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.typeConfiguration(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0]
        );

        cy.cGroupAsStep('Verify Background Color before selecting');
        sisOfficeDesktop.verifyBackgroundColor(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
            .REVENUE_CYCLE_MANAGER[1],
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
            .REVENUE_CYCLE_MANAGER[0],
          AppColors.component_before_selection
        );

        cy.cGroupAsStep(
          'Verify non existence of tick mark icon before selecting'
        );
        nursingConfigurationLayout.verifyTickIconInConfiguration(
          CommonGetLocators.ngHide
        );

        cy.cGroupAsStep('Selecting RCM in Configuration');
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0],
          true
        );

        cy.cGroupAsStep(
          'Verify Background color of dictionary item after selecting'
        );
        sisOfficeDesktop.verifyBackgroundColor(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
            .REVENUE_CYCLE_MANAGER[1],
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH
            .REVENUE_CYCLE_MANAGER[0],
          AppColors.component_on_selection
        );

        cy.cGroupAsStep('Verify existence of tick mark icon after selecting');
        nursingConfigurationLayout.verifyTickIconInConfiguration(
          CommonGetLocators.checkCircle
        );

        cy.cGroupAsStep('Verify Header');
        nursingConfiguration.verifyHeader(
          OR_NURSING_CONFIGURATION.COMMON.HEADER[1],
          OR_NURSING_CONFIGURATION.COMMON.HEADER[0],
          Header.business
        );

        cy.cGroupAsStep('Verify Sub Header');
        nursingConfiguration.verifyFieldLabels(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[1],
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0],
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0]
        );

        cy.cGroupAsStep('Verify Page Load Text');
        nursingConfiguration.verifyHelperText();

        cy.cGroupAsStep('Verify label, Selecting first List Item in RCM Page');
        nursingConfiguration.selectConfigurationFirstTemplate();

        cy.cGroupAsStep('Verify Classification Label');
        nursingConfiguration.verifyFieldLabels(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER
            .CLASSIFICATION_LABEL[1],
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER
            .CLASSIFICATION_LABEL[0],
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.CLASSIFICATION_LABEL[0]
        );

        cy.cGroupAsStep('Verify Days From Post Transfer Label');
        nursingConfiguration.verifyFieldLabels(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER
            .DAYS_FROM_POST_TRANSFER_LABEL[1],
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER
            .DAYS_FROM_POST_TRANSFER_LABEL[0],
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER
            .DAYS_FROM_POST_TRANSFER_LABEL[0]
        );
      });
    });
  }

  verifyAddEditDuplicateSorting() {
    describe('Verify Functionalities like add, edit, duplicate and sorting templates in rcm configuration', () => {
      it('Adding, editing, validate duplicate and sorting templates in rcm configuration', () => {
        cy.cGroupAsStep('Verify Add Functionality');
        nursingConfiguration.addRevenueCycleManager(
          td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo[0]
        );
        nursingConfiguration.verifyRevenueCycleManager();

        cy.cGroupAsStep('Verify Edit Functionality');
        nursingConfiguration.editRevenueCycleManager(
          nursingConfiguration.RevenueCycleManagerModel
        );

        cy.cGroupAsStep('Verify Duplicate message in add popup window');
        nursingConfiguration.verifyDuplicateMessage(
          nursingConfiguration.RevenueCycleManagerModel.Name!,
          AppErrorMessages.duplicate_rev_cyc_manager
        );

        cy.cGroupAsStep(
          'Verify Sorting of Revenue Cycle Manager List, Reload the page and select RCM template again'
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER.SUB_HEADER[0]
        );

        cy.cGroupAsStep('Verify Sorting');
        sisOfficeDesktop.verifyListIfSorted(
          OR_NURSING_CONFIGURATION.COMMON.ALL_LIST_OPTIONS[1]
        );
      });
    });
  }

  verifyDoneCancelButtonAndDaysFromPostTransfer() {
    describe('Verify Done, Cancel button and Days From Post Transfer Field functionality In RCM configuration', () => {
      it('Verify Cancel button and Days From Post Transfer Field functionality in RCM configuration', () => {
        cy.cGroupAsStep(
          'Verifying Cancel Button Functionality in Add Popup of RCM configuration'
        );
        nursingConfiguration.verifyDoneButtonDisableInAddPopup();

        cy.cGroupAsStep(
          'Clicking on Cancel Button and verifying non-existence of add popup post cancel'
        );
        nursingConfiguration.verifyCancelInAddPopup();

        cy.cGroupAsStep(
          'Verify Days From Post Transfer Field Functionality, Selected First RCM List Item'
        );
        nursingConfiguration.selectConfigurationFirstTemplate();

        cy.cGroupAsStep(
          'Verify Only Numbers are accepted in Days From Post/Transfer Field'
        );
        let selectorDaysFromPostTransferLabel =
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER
            .DAYS_FROM_POST_TRANSFER[1];
        let logicalNameDaysFromPostTransferLabel =
          OR_NURSING_CONFIGURATION.REVENUE_CYCLE_MANAGER
            .DAYS_FROM_POST_TRANSFER[0];
        nursingConfiguration.enterAndVerifyInput(
          selectorDaysFromPostTransferLabel,
          logicalNameDaysFromPostTransferLabel,
          td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo[1]
            .DaysFromPostOrTransfer,
          CommonUtils.getNumbersFromString(
            td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo[1]
              .DaysFromPostOrTransfer,
            3
          )
        );
        nursingConfiguration.enterAndVerifyInput(
          selectorDaysFromPostTransferLabel,
          logicalNameDaysFromPostTransferLabel,
          td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo[2]
            .DaysFromPostOrTransfer,
          CommonUtils.getNumbersFromString(
            td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo[2]
              .DaysFromPostOrTransfer,
            3
          )
        );
        nursingConfiguration.enterAndVerifyInput(
          selectorDaysFromPostTransferLabel,
          logicalNameDaysFromPostTransferLabel,
          td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo[3]
            .DaysFromPostOrTransfer,
          CommonUtils.getNumbersFromString(
            td_rev_cyc_manager_tcid_97581.RevenueCycleManagerInfo[3]
              .DaysFromPostOrTransfer,
            3
          )
        );
      });
    });
  }
}
