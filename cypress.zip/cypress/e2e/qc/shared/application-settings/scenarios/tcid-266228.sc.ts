import { EnableOrDisable } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import {
  SubRoutes,
  WaitMethods,
} from '../../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';

import ChartsFacesheet from '../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import PatientDetailsTab from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import { NursingDept, MyTasks } from '../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { td_Outbound_CCDA_tcid_266228 } from '../../../../../fixtures/shared/application-settings/outboundCCDA-dictionary-items-tcid-266228.td';

/* instance variables */
const nursingConfiguration = new NursingConfiguration();
const nursingConfLayout = new NursingConfigurationLayout();
const enterpriseConfig = new EnterpriseConfiguration();
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase();
const patientDetailsTab = new PatientDetailsTab();
const sisChartsDesktop = new SISChartsDesktop();
const chartsFacesheet = new ChartsFacesheet();

/* const values */
const featureId = 145;

export class OutboundCCDATcId266228 {
  verifyGatewayConfigTobaccoUseInReportingCodes(option: string, flag: boolean) {
    nursingConfLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.SIS_GATEWAY_CONFIG.SIS_GATEWAY[0]
    );
    nursingConfiguration.verifyGatewayConfigState(option);

    nursingConfLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.REPORTING_CODES[0]
    );

    nursingConfiguration.verifyTobaccoInReportingCodes(
      OR_NURSING_CONFIGURATION.REPORTING_CODES.TOBACCO_USE[0],
      flag
    );
  }

  navigateToUnreleased() {
    sisOfficeDesktop.selectOptionInUserMenuDropdown(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
    );

    nursingConfLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.SUB_HEADER[0]
    );
    nursingConfiguration.expandUnreleased();
  }

  navigateToInternalTab(orgName: string) {
    sisOfficeDesktop.selectOptionInUserMenuDropdown(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
    );
    enterpriseConfig.selectEnterpriseInPopup(
      OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
      OrganizationList.ENTERPRISE
    );
    enterpriseConfig.enterpriseSelectConfiguration(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
        .FACILITY_MANAGEMENT_HEADER[0]
    );
    enterpriseConfig.selectFacilityInFacilityManagement(orgName);
    enterpriseConfig.clickOnTab(
      OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERNAL_TAB[0]
    );
  }

  enableFeature() {
    describe('To Enable outbound CCDA from Add On Features and in Enterprise Settings', () => {
      it('Verify Gateway config and Tobacco Use in Reporting Codes before and after Outbound CCDA is enabled', () => {
        // #region - Navigate to Add On Features -> Unreleased feature and verify Outbound CCDA Flag default state

        cy.cGroupAsStep('Verify new Outbound CCDA flag in Add on Features');
        this.navigateToUnreleased();
        nursingConfiguration.verifyOutboundCCDAFlag();

        // #endregion

        // #region - Verify Gateway config disabled, No Tobacco Use in Reporting codes and No CCDA flag in Enterprise settings  when CCDA is disabled in Add on features

        cy.cGroupAsStep(
          'Verify SIS Gateway Configuration is disabled and no Tobacco Use in Reporting codes and no CCD flag in Enterprise settings'
        );
        this.verifyGatewayConfigTobaccoUseInReportingCodes(
          EnableOrDisable.disable,
          false
        );
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.verifyRoomInScheduleGrid();
        this.navigateToInternalTab(OrganizationList.GEM_ORG_3);
        enterpriseConfig.verifyOutboundCCDAFeature();
        // #endregion

        // #region - Enable Outbound CCDA in Add on features
        cy.cGroupAsStep('Enable Outbound CCDA in Add On Features');
        enterpriseConfig.switchToFacilityFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        cy.cWait(SubRoutes.scdl_grid_gemini_get, WaitMethods.post);
        scheduleGrid.verifyRoomInScheduleGrid();

        // Call Web service method to enable Outbound CCDA Add On Feature
        // OutBound CCDA feature_type_id = 145 --- from [Charts-Master].[security].[feature_type]
        cy.enableUnreleasedFeature(featureId);
        this.navigateToUnreleased();
        nursingConfiguration.verifyOutboundCCDAFlag();
        // #endregion

        // #region - Verify Gateway config is still disabled and no Tobacco Use in Reporting codes after enabling CCDA from Add On Features

        cy.cGroupAsStep(
          'Verify SIS Gateway Configuration is disabled and no Tobacco Use in Reporting codes'
        );
        this.verifyGatewayConfigTobaccoUseInReportingCodes(
          EnableOrDisable.disable,
          false
        );
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion

        // #region - Verify and enable Outbound CCDA flag in Enterprise

        cy.cGroupAsStep(
          'Enable Outbound CCDA flag in Enterprise settings Facility Management Internal Tab'
        );
        this.navigateToInternalTab(OrganizationList.GEM_ORG_3);
        enterpriseConfig.verifyOutboundCCDAFeature(true);
        enterpriseConfig.verifyOutboundCCDAState();
        enterpriseConfig.togglesFeaturesInInterfacesInternalTab(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.OUTBOUND_CCDA.FLAG[0],
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERFACES
            .ENABLE[0]
        );
        enterpriseConfig.switchToFacilityFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        cy.cWait(SubRoutes.scdl_grid_gemini_get, WaitMethods.post);
        scheduleGrid.verifyRoomInScheduleGrid();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        // #endregion

        // #region - Verify Gateway config and Tobacco Use Reporting codes

        cy.cGroupAsStep(
          'Verify SIS Gateway Configuration is enabled and Tobacco Use is displayed in Reporting codes'
        );
        this.verifyGatewayConfigTobaccoUseInReportingCodes(
          EnableOrDisable.enable,
          true
        );
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion
      });
    });
  }

  verifyConfigDictionaryItems() {
    describe('To verify CCDA col and Codes for dictionary items when Outbound CCDA is enabled', () => {
      it('Verify new CCDA column and CCDA Codes for Race, Ethnicity, Language and Tobacco Use ', () => {
        // #region - Verify Outbound CCDA Flag is enabled in Enterprise Settings

        cy.cGroupAsStep(
          'Verify Outbound CCDA flag is enabled in Enterprise Settings'
        );
        this.navigateToInternalTab(OrganizationList.GEM_ORG_3);
        enterpriseConfig.verifyOutboundCCDAState();
        enterpriseConfig.switchToFacilityFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        cy.cWait(SubRoutes.scdl_grid_gemini_get, WaitMethods.post);
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion

        // #region - Verify CCDA column, Enter CCDA code and verify in Reporting codes for Race, Ethnicity, Language and Tobacco Use

        cy.cGroupAsStep('Verify CCDA Col and CCDA Codes for Race');
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.REPORTING_CODES[0]
        );
        nursingConfiguration.verifyCCDAColAndCodesReportingCodes(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.RACE[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[1].Item,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[1].CCDACode,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[1].OnHoverText
        );
        // #endregion

        // #region - Verify CCDA column, Enter CCDA code and verify in Reporting codes for Language

        cy.cGroupAsStep('Verify CCDA Col and CCDA Codes for Language');
        nursingConfiguration.verifyCCDAColAndCodesReportingCodes(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.LANGUAGE[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[2].Item,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[2].CCDACode,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[2].OnHoverText
        );
        // #endregion

        // #region - Verify CCDA column, Enter CCDA code and verify in Reporting codes for Ethnicity

        cy.cGroupAsStep('Verify CCDA Col and CCDA Codes for Ethnicity');
        nursingConfiguration.verifyCCDAColAndCodesReportingCodes(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.ETHNICITY[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[0].Item,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[0].CCDACode,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[0].OnHoverText
        );
        // #endregion

        // #region - Verify CCDA column, Enter CCDA code and verify in Reporting codes for Tobacco Use

        cy.cGroupAsStep('Verify CCDA Col and CCDA Codes for Tobacco Use');
        nursingConfiguration.verifyCCDAColAndCodesReportingCodes(
          OR_NURSING_CONFIGURATION.REPORTING_CODES.TOBACCO_USE[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[3].Item,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[3].CCDACode,
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[3].OnHoverText
        );
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion
      });
    });
  }

  addDicItemsAndVerifyInPatientDetailsTab() {
    describe('To add new Dictionary items and Verify them in Patient Details Tab in Face sheet', () => {
      it('Add and verify Dictionary items in Face sheet patient details tab', () => {
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_Outbound_CCDA_tcid_266228.PatientInfo.PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );

        // #region - Document Race, Ethnicity and Language Dictionary items mapped with CCDA Code in Patient details

        cy.cGroupAsStep(
          'Select CCDA concept Names for Race, Primary Language and Ethnicity in Patient details'
        );
        createCase.clickPreviousInCaseDetails();
        createCase.waitUntilDicItemsLoad();
        createCase.verifyAndSelectDropdownValInPatientDetails(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .RACE[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[1].Item!
        );

        createCase.verifyAndSelectDropdownValInPatientDetails(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .PRIMARY_LANGUAGE[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[2].Item
        );

        createCase.verifyAndSelectDropdownValInPatientDetails(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .ETHNICITY[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[0].Item
        );
        createCase.clickNextInPatientDetails();
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region - Verify Documented dictionary items mapped with CCDA Code in Face sheet > Patient details tab

        cy.cGroupAsStep(
          'Verify Selected Dictionary items in Face sheet Patient details tab'
        );
        scheduleGrid.globalSearch(
          td_Outbound_CCDA_tcid_266228.PatientInfo.Nickname,
          td_Outbound_CCDA_tcid_266228.PatientInfo.PatientFirstName
        );
        patientDetailsTab.clickOnPatientDetailsTab();
        patientDetailsTab.waitForPdToLoad();

        patientDetailsTab.verifyDisplayedValPatientDetailsTab(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .RACE[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[1].Item
        );
        patientDetailsTab.verifyDisplayedValPatientDetailsTab(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .PRIMARY_LANGUAGE[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[2].Item
        );
        patientDetailsTab.verifyDisplayedValPatientDetailsTab(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .ETHNICITY[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[0].Item
        );
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion
      });
    });
  }

  verifyTobaccoUseInPreAdQxInSISCharts() {
    describe('Add Worklist and verify Tobacco value in Pre-Admission Qx in SIS Charts', () => {
      it('Verify Tobacco Use Dictionary item Pre_Admission Qx', () => {
        // #region - Navigate to in Pre-Admit Qx in nursing desktop

        cy.cGroupAsStep('Navigate to Face sheet, My tasks, Pre-Admission Qx');
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.closeNotificationIcon();
        sisChartsDesktop.selectPatientFromPatientList(
          td_Outbound_CCDA_tcid_266228.PatientInfo
        );
        chartsFacesheet.selectDepartment(NursingDept.pre_operative);
        chartsFacesheet.waitToLoadContents(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.OPERATIVE_CONSENT.CONSENTS
            .CONSENTS_HEADER[0]
        );
        chartsFacesheet.selectMyTasks(MyTasks.pre_admit);
        chartsFacesheet.waitToLoadContents(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.QUESTIONNAIRE[0]
        );
        // #endregion

        // #region - Add Worklist and Document Tobacco Use item mapped with CCDA Code in Pre-Admit Qx

        cy.cGroupAsStep(
          'Add Work list template and Select dropdown item in tobacco and verify'
        );
        chartsFacesheet.addWorkList(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ALL_WORKLISTS[0],
          td_Outbound_CCDA_tcid_266228.PreAdQxInfo.WorklistName
        );
        chartsFacesheet.selectValInPreAdQxDropdown(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0],
          td_Outbound_CCDA_tcid_266228.PreAdQxInfo.Tobacco
        );

        chartsFacesheet.verifyDisplayedValInPreAdQxDropdown(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0],
          td_Outbound_CCDA_tcid_266228.PreAdQxInfo.Tobacco
        );
        chartsFacesheet.selectValInPreAdQxDropdown(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[3].Item
        );
        chartsFacesheet.verifyDisplayedValInPreAdQxDropdown(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.PRE_ADMIT_QX.TOBACCO[0],
          td_Outbound_CCDA_tcid_266228.ReportingCodeInfo[3].Item
        );
        // Removed the steps because of the unneccessary navigation
        // #endregion
      });
    });
  }

  disableFeature() {
    describe('To disable outbound CCDA from Add On Features and in Enterprise Settings', () => {
      it('Verify Gateway config and Tobacco Use in Reporting Codes when Outbound CCDA is disabled', () => {
        // #region - Disable Outbound CCDA from Enterprise Settings

        cy.cGroupAsStep(
          'Disable Outbound CCDA flag in Enterprise settings Facility Management Internal Tab'
        );
        this.navigateToInternalTab(OrganizationList.GEM_ORG_3);
        enterpriseConfig.verifyOutboundCCDAFeature(true);
        enterpriseConfig.verifyOutboundCCDAState();
        enterpriseConfig.togglesFeaturesInInterfacesInternalTab(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURES.OUTBOUND_CCDA.FLAG[0],
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT.INTERNAL.INTERFACES
            .DISABLE[0]
        );
        enterpriseConfig.switchToFacilityFromEnterprise(
          OrganizationList.GEM_ORG_3
        );
        scheduleGrid.verifyRoomInScheduleGrid();
        // #endregion

        // #region - Verify Gateway config is disabled and no Tobacco Use in Reporting codes and disable CCDA from Add on Features

        cy.cGroupAsStep(
          'Verify SIS Gateway Configuration is disabled and no Tobacco Use in Reporting codes'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        this.verifyGatewayConfigTobaccoUseInReportingCodes(
          EnableOrDisable.disable,
          false
        );
        cy.disableUnreleasedFeature(featureId);
        // #endregion
      });
    });
  }
}
