import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_surgery_board_recovery } from '../../../../../fixtures/shared/application-settings/surgery-board-recovery-tcid-273785.td';

import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { NursingDept } from '../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

import ChartsCoverFaceSheet from '../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import PreOperativeDepartment from '../../../../../app-modules-libs/sis-charts/departments/pre-operative/pre-operative';
import OperativeDepartment from '../../../../../app-modules-libs/sis-charts/departments/operative/operative';
import RecoveryDepartment from '../../../../../app-modules-libs/sis-charts/departments/recovery/recovery';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ChartsLogin from '../../../../../app-modules-libs/sis-charts/login/login';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import {
  TrackerBoard,
} from '../../../../../app-modules-libs/patient-tracking/tracking-board';
import {
  SurgeryBoard,
} from '../../../../../app-modules-libs/patient-tracking/surgery-board';
import { BoardSettingsHeaders } from '../../../../../app-modules-libs/patient-tracking/enums/surgery-board.enum';
import { trackers } from '../../../../../app-modules-libs/patient-tracking/enums/tracking-board.enum';

/* instance variables */
const createCase = new CreateCase(td_surgery_board_recovery.PatientCase[2]);
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const preOperativeDepartment = new PreOperativeDepartment();
const operativeDepartment = new OperativeDepartment();
const recoveryDepartment = new RecoveryDepartment(
  td_surgery_board_recovery.RecoveryInfo
);
const chartsLogin = new ChartsLogin();
const trackerBoard = new TrackerBoard();
const surgeryBoard = new SurgeryBoard();

export class SurgeryBoardTrackerTcId273785 {
  preCondition() {
    describe('Different patients documented in different locations and rooms in SIS-Complete', () => {
      it('Documenting the patients in different departments.', () => {
        // #region - Arriving the patient-2 from schedule grid and adding anesthesia type.

        cy.cGroupAsStep('Clicking on arrive for patient-2 from schedule grid');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_recovery.PatientCase[1].PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.ARRIVE_BUTTON[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_recovery.PatientCase[1].PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );

        createCase.selectAnesthesiaType(
          td_surgery_board_recovery.PatientCase[1].CaseDetails.AnesthesiaType
        );
        sisOfficeDesktop.clickDoneButton();

        // #endregion

        // #region - Check-in the patient-3 from schedule grid.

        cy.cGroupAsStep(
          'Clicking on check-in and entering anesthesia type for patient-3 from schedule grid'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_recovery.PatientCase[2].PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.enterDOB('10/10/1999');

        createCase.clickCheckInDone();
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_recovery.PatientCase[2].PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );

        createCase.selectAnesthesiaType(
          td_surgery_board_recovery.PatientCase[2].CaseDetails.AnesthesiaType
        );
        sisOfficeDesktop.clickDoneButton();

        // #endregion

        // #region - Entering Anesthesia type for patient-4.

        cy.cGroupAsStep(
          'Entering anesthesia type for the patient-4 in business desktop.'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_surgery_board_recovery.PatientCase[3].PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );

        createCase.selectAnesthesiaType(
          td_surgery_board_recovery.PatientCase[3].CaseDetails.AnesthesiaType
        );
        sisOfficeDesktop.clickDoneButton();

        // #endregion

        // #region - Entering Pre-op admission time for patient-4.

        cy.cGroupAsStep(
          'Enter pre-op admission time for patient-4 in nursing desktop'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.pickPatient(
          td_surgery_board_recovery.PatientCase[3].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.pre_operative);
        preOperativeDepartment.enterAdmissionTimeRoom(
          td_surgery_board_recovery.DepartmentInfo[0]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Entering Pre-op admission time and ready for transfer as yes for patient-5.

        cy.cGroupAsStep(
          'Enter pre-op admission time and click ready for transfer as Yes for patient-5 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_recovery.PatientCase[4].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.pre_operative);
        preOperativeDepartment.enterAdmissionTimeRoom(
          td_surgery_board_recovery.DepartmentInfo[1]
        );
        preOperativeDepartment.clickYesNoInReadyForTransfer(YesOrNo.yes);
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Entering Operative admission time for patient-6.

        cy.cGroupAsStep(
          'Enter operative admission time for patient-6 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_recovery.PatientCase[5].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        operativeDepartment.enterAdmissionTimeRoom(
          td_surgery_board_recovery.DepartmentInfo[2]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Entering recovery admission time for patient-7.

        cy.cGroupAsStep(
          'Enter recovery admission time for patient-7 in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_recovery.PatientCase[6].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.recovery);
        recoveryDepartment.enterAdmissionTimeRoom(
          td_surgery_board_recovery.DepartmentInfo[3]
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();

        // #endregion

        // #region - Discharging the patient from the recovery for patient-8

        cy.cGroupAsStep(
          'Discharge patient-8 from recovery department in nursing desktop'
        );

        sisChartsDesktop.pickPatient(
          td_surgery_board_recovery.PatientCase[7].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.recovery);
        recoveryDepartment.dischargePatientInOutsideFacility();

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        sisOfficeDesktop.logout();

        // #endregion
      });
    });
  }

  verifyPatientsData() {
    describe('Verify surgery board tracker with different patients documented in different locations and rooms', () => {
      it('Verify surgery board tracker with different patients', () => {
        // #region -Verify able to land on surgery board tracker from patient tracking and verify the patient details

        cy.cGroupAsStep(
          'Navigate to patient tracking url and verify surgery board tracker with different patients'
        );

        cy.visit(Cypress.env('patientTracking'));

        chartsLogin.login(
          UserList.SIS_ADMIN[0],
          UserList.SIS_ADMIN[1],
          OrganizationList.GEM_ORG_5
        );
        trackerBoard.selectPatientTrackingBoard(trackers.surgery_board_tracker);

        surgeryBoard.clickGearIcon();
        surgeryBoard.clickToggleInBoardSettings(
          BoardSettingsHeaders.discharged_cases
        );
        surgeryBoard.clickToggleInBoardSettings(
          BoardSettingsHeaders.unarrived_cases
        );
        surgeryBoard.clickDoneInBoardSettings();
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[0]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[1]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[2]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[3]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[4]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[5]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[6]
        );
        surgeryBoard.verifyColumnValuesByPatient(
          td_surgery_board_recovery.SurgeryBoardTrackerInfo[7]
        );

        // #endregion
      });
    });
  }
}
