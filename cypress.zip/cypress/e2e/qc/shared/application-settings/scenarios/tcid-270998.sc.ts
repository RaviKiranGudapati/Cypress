import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import {
  LeftOrRight,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';
import {
  CommonUtils,
  StringType,
} from '../../../../../support/common-core-libs/framework/common-utils';

import { td_pre_admission_instructions_tcid_270998 } from '../../../../../fixtures/shared/application-settings/preadmission-instructions-tcid-270998.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';

import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import ChartsCoverFaceSheet from '../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CaseConsents from '../../../../../app-modules-libs/sis-office/case-check-in/case-consents';
import { PreAdmitInstructions } from '../../../../../app-modules-libs/sis-charts/departments/pre-admit/instructions';
import {
  NursingDept,
  MyTasks,
} from '../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const chartsCoverFacesheet = new ChartsCoverFaceSheet();
const nursingConfiguration = new NursingConfiguration();
const preAdmitInstructions = new PreAdmitInstructions();
const scheduleGrid = new ScheduleGrid();
const caseConsents = new CaseConsents();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();

/* const values */
const item1 = 'Notice of Patient Rights and Responsibilities';
const item2 = 'No Surprise Billing';
const item3 = 'Partnership Posting';
const question1 = 'Instructed to not bring valuables?';
const randomStr = CommonUtils.generateUniqueString(
  100,
  StringType.ALPHANUMERIC
);

export class DocumentsAcknowledgedTcId270998 {
  worklistTemplateValidations() {
    describe('Validations for documents and disclosure in Pre-admission Instructions and validating template in SIS-Charts', () => {
      it('Verify documents and disclosure in Pre-admission Instructions in application settings', () => {
        // #region Creating worklist template in application settings

        cy.cGroupAsStep(
          'Navigate to application settings verify documents and disclosure worklist'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.PRE_ADMISSION_INSTRUCTIONS.SUB_HEADER[0]
        );
        // #endregion

        // #region Adding Worklists in application settings
        cy.cGroupAsStep(
          'Adding Documents and Disclosures template to the Worklist'
        );
        nursingConfiguration.addPreAdmissionWorklist(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[0].WorklistName
        );

        nursingConfiguration.clickPlusIconInPreAdmissionInstructions(
          LeftOrRight.right
        );
        nursingConfiguration.selectWorkListItemInPreAdmissionInstructions(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[0].WorklistType[0]
        );
        nursingConfiguration.clickYesNoInDocumentsAcknowledged(YesOrNo.no);

        nursingConfiguration.verifySearchAndButtonInDocumentsAcknowledged(true);
        nursingConfiguration.clickPlusIconInPreAdmissionInstructions(
          LeftOrRight.left
        );

        nursingConfiguration.addPreAdmissionWorklist(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[1].WorklistName
        );

        nursingConfiguration.clickPlusIconInPreAdmissionInstructions(
          LeftOrRight.right
        );
        nursingConfiguration.selectWorkListItemInPreAdmissionInstructions(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[1].WorklistType[0]
        );
        nursingConfiguration.clickYesNoInDocumentsAcknowledged();
        nursingConfiguration.addItemsToDocumentsAcknowledged(item1);

        nursingConfiguration.addItemsToDocumentsAcknowledged(item1);
        nursingConfiguration.addItemsToDocumentsAcknowledged(item2);

        nursingConfiguration.addItemsToDocumentsAcknowledged(randomStr);

        nursingConfiguration.clickPlusIconInPreAdmissionInstructions(
          LeftOrRight.right
        );
        nursingConfiguration.selectWorkListItemInPreAdmissionInstructions(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[1].WorklistType[1]
        );

        nursingConfiguration.clickPlusIconInPreAdmissionInstructions(
          LeftOrRight.left
        );
        nursingConfiguration.selectWorkListItemInPreAdmissionInstructions(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[1].WorklistType[2]
        );
        nursingConfiguration.addConfigurableQuestions(question1);

        nursingConfiguration.searchAndSelectPreAdmissionInstructionsWorklist(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[0].WorklistName
        );
        nursingConfiguration.searchAndSelectPreAdmissionInstructionsWorklist(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[1].WorklistName
        );

        sisOfficeDesktop.selectSisLogo();
        // #endregion

        // #region Adding documents and disclosures Worklist having No to the case in nursing desktop
        cy.cGroupAsStep(
          'Adding worklist which has documents and disclosures as No to the case in nursing desktop'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.pickPatient(
          td_pre_admission_instructions_tcid_270998.PatientCase[0]
            .PatientDetails
        );

        chartsCoverFacesheet.selectDepartment(NursingDept.pre_operative);

        chartsCoverFacesheet.selectMyTasks(MyTasks.pre_admit);

        preAdmitInstructions.clickInstructions();
        preAdmitInstructions.selectWorklistInPopUp(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[0].WorklistName
        );

        nursingConfiguration.verifySearchAndButtonInDocumentsAcknowledged(true);

        // #endregion

        // #region Checking the widget in patient check-in when template has No in Documents and Disclosures
        cy.cGroupAsStep(
          'Verify sticky panel in check-in when template has No in Documents and Disclosures'
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.SURGICAL_CASES[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_pre_admission_instructions_tcid_270998.PatientCase[0]
            .PatientDetails.PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        caseConsents.checkInNext();
        caseConsents.verifyDocumentsAcknowledgementPanel(false);

        // #endregion

        // #region Adding documents and disclosures Worklist having Yes to the case in nursing desktop
        cy.cGroupAsStep(
          'Adding worklist which has documents and disclosures as Yes to the case in nursing desktop'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.pickPatient(
          td_pre_admission_instructions_tcid_270998.PatientCase[0]
            .PatientDetails
        );

        chartsCoverFacesheet.selectDepartment(NursingDept.pre_operative);

        chartsCoverFacesheet.selectMyTasks(MyTasks.pre_admit);

        preAdmitInstructions.clickInstructions();
        preAdmitInstructions.clickWorkListIcon();
        preAdmitInstructions.selectWorklistInPopUp(
          td_pre_admission_instructions_tcid_270998
            .PreAdmissionInstructionsInfo[1].WorklistName
        );

        preAdmitInstructions.editAddedItemInDocumentsAcknowledged(item2, item3);
        preAdmitInstructions.clickInstructions();

        preAdmitInstructions.deleteAddedItem(item3);

        preAdmitInstructions.clickInstructions();

        // #endregion

        // #region Checking the widget in patient check-in when template has No in Documents and Disclosures
        cy.cGroupAsStep(
          'Verify sticky panel and updated widget in check-in when template has yes in Documents and Disclosures'
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.SURGICAL_CASES[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_pre_admission_instructions_tcid_270998.PatientCase[0]
            .PatientDetails.PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        caseConsents.checkInNext();
        caseConsents.verifyDocumentsAcknowledgementPanel();
        caseConsents.verifyDocuments(item1);

        // #endregion
      });
    });
  }
}
