import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { PreferenceCardTcId260015 } from './scenarios/tcid-260015.sc';

/* instance variables */
const preferenceCardScenario = new PreferenceCardTcId260015();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Navigating to User Icon --> Application Settings--> Preference card
 * 2. Add new preference card and verify the fields
 * 3. Navigate to RCM and come back to saved preference card to verify if data is saved
 * 4. Update the existing fields and verify the data
 * 5. Verify if the duplicate preference card can be added and validate the error message
 * 6. Verifying physician preferences field when trying to add preference card from existing cards
 * 7. Verify preference card by trying to add preference card during case creation
 */

describe(
  'Verify the checkpoint permission for user to access the Preference card',
  {
    tags: ['application-settings', 'preference-card', 'US#260238', 'TC#260015'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        preferenceCardScenario.verifyPreferenceCardCreation();
        preferenceCardScenario.verifyExistingPreferenceCard();
        preferenceCardScenario.verifyCardInCaseCreation();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
