import { TrackerBoard } from '../../../../app-modules-libs/patient-tracking/tracking-board';

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

/* As in azure enviornment we are not able to login/logout with API. Hence, commented the code */
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { PatientTrackingTcId273784 } from './scenarios/tcid-273784.sc';

/* instance variables */
const trackerBoard = new TrackerBoard();
const patientTrackingScenario = new PatientTrackingTcId273784();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to sis-complete application and navigate to enterprise.
 * 2. Verify the surgery board feature flag in internal tab.
 * 3. Navigate to Organization and check the surgery board in patient tracking configuration
 */

describe(
  'Verify user able to navigate surgery board tracker when flag is on in enterprise facility management',
  {
    tags: ['patient-tracking', 'US#196473', 'TC#273784'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      trackerBoard.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        patientTrackingScenario.verifySurgeryBoardFeatureFlag();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
