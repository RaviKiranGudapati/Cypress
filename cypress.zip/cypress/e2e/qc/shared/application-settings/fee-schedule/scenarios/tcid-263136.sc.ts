import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  Application,
  ExpandOrCollapse,
} from '../../../../../../support/common-core-libs/application/common-core';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';

import { td_feeschedule_freetext_tcid_263136 } from '../../../../../../fixtures/shared/application-settings/fee-schedule/fee-schedule-freetext-tcid-263136.td';

import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import CasesToCode from '../../../../../../app-modules-libs/sis-office/trackers/cases-to-code';
import RecoveryDepartment from '../../../../../../app-modules-libs/sis-charts/departments/recovery/recovery';
import FaceSheetChargeEntry from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';

/* instance variables */
const sisChartsDesktop = new SISChartsDesktop();
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(
  td_feeschedule_freetext_tcid_263136.PatientCase
);
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const facesheetChargeEntry = new FaceSheetChargeEntry();
const casesToCode = new CasesToCode(createCase.patientCaseModel!);
const chargeEntry = new ChargeEntry(
  td_feeschedule_freetext_tcid_263136.PatientCase
);
const recoveryDepartment = new RecoveryDepartment(
  td_feeschedule_freetext_tcid_263136.RecoveryInfo
);
const facesheetCases = new FaceSheetCases();

export class FacesheetTcId264050 {
  verifySampleFeeSchedule() {
    describe('Verify Fee schedule configuration and add', () => {
      it('Verifying fee schedule configuration in the application settings', () => {
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        // #region - Navigating to application settings, search for fee schedule enter the CPT text without code

        cy.cGroupAsStep(
          'Searching for Fee Schedule and adding CPT code with free Text'
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.FEE_SCHEDULE[0]
        );
        nursingConfiguration.clickAddInFeeSchedule();
        nursingConfiguration.clickOnKeyboard();
        nursingConfiguration.enterFeeScheduleFreeText(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        sisOfficeDesktop.clickDoneButton();
        nursingConfiguration.feeScheduleStatusDropdown(
          td_feeschedule_freetext_tcid_263136.FeeSchedule.Status
        );
        cy.cRemoveMaskWrapper(Application.office);
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.FEE_SCHEDULE[0]
        );
        nursingConfiguration.clickAddInFeeSchedule();
        nursingConfiguration.clickOnKeyboard();
        nursingConfiguration.enterFeeScheduleFreeText(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[1].CPTCodeAndDescription
        );
        sisOfficeDesktop.clickDoneButton();
        nursingConfiguration.feeScheduleStatusDropdown(
          td_feeschedule_freetext_tcid_263136.FeeSchedule.Status
        );
        cy.cRemoveMaskWrapper(Application.office);
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.FEE_SCHEDULE[0]
        );
        nursingConfiguration.clickAddInFeeSchedule();
        nursingConfiguration.clickOnKeyboard();
        nursingConfiguration.enterFeeScheduleFreeText(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[2].CPTCodeAndDescription
        );
        sisOfficeDesktop.clickDoneButton();
        nursingConfiguration.feeScheduleStatusDropdown(
          td_feeschedule_freetext_tcid_263136.FeeSchedule.Status
        );
        cy.cRemoveMaskWrapper(Application.office);
        // #endregion

        // #region - Adding Contract and verifying added free Text CPT Code

        cy.cGroupAsStep(
          'Adding Contract and verifying added free Text CPT Code'
        );
        nursingConfiguration.addContract(
          td_feeschedule_freetext_tcid_263136.Contract
        );
        facesheetChargeEntry.selectReviewEdit();
        nursingConfiguration.procedureSearchBox(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[0]
        );
        nursingConfiguration.verifyCptTextInReviewOrEdit(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyCaseDetails() {
    describe('Create a patient and verify CPT text in case details', () => {
      it('Create a patient and verify CPT text in case details', () => {
        // #region - Create a patient case

        cy.cGroupAsStep(
          'Click create patient tab, enter mandatory data navigate to case details '
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        createCase.enterPatientDetails(
          createCase.patientCaseModel!.PatientDetails
        );
        createCase.selectRoom(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .OperatingRoom
        );
        createCase.enterDateOfService(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .DateOfService
        );
        createCase.enterStartTime(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails.StartTime
        );
        createCase.enterEndTime(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails.EndTime
        );
        createCase.selectAppointmentType(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .AppointmentType
        );

        createCase.clickPlusIconProcedureDetails();
        createCase.enterCPTRowData(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[0]
        );
        createCase.next();
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region - Navigating to nursing desktop and discharging patient with case status performed

        cy.cGroupAsStep(
          'Navigating to Nursing Desktop and Discharging the Patient'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.recovery);
        recoveryDepartment.dischargePatientInOutsideFacility();
        // #endregion

        // #region - Performing Cases to Code and Performing Charge Entry

        cy.cGroupAsStep('Navigating to Business Desktop');
        sisOfficeDesktop.selectSisLogo();
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion

        // #region- checking for cpt code in cases to code tracker

        casesToCode.addProcedureCaseToCode(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[1]
        );
        casesToCode.selectDiagnosisCode(
          td_feeschedule_freetext_tcid_263136.CasesToCodeDetails
        );
        // #endregion

        // #region - select patient from charge entry tracker and checking for free text cpt code

        cy.cGroupAsStep(
          'Select patient from charge entry tracker and checking for free text cpt code'
        );
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(
          td_feeschedule_freetext_tcid_263136.ChargeDetails
        );
        chargeEntry.verifyCptCodeName(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry.verifyCptCodeName(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry.addProcedure(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[2]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        chargeEntry.clickReadyForBillAndDoneButton();
        // #endregion

        // #region - checking for cpt code in facesheet- charge entry

        cy.cGroupAsStep('checking for cpt code in facesheet- charge entry');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_feeschedule_freetext_tcid_263136.PatientCase.PatientDetails
        );
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        chargeEntry.verifyCptCodeName(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry.verifyCptCodeName(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry.verifyCptCodeName(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry.addProcedure(
          td_feeschedule_freetext_tcid_263136.PatientCase.CaseDetails
            .CptCodeInfo[1]
        );
        // #endregion
      });
    });
  }
}
