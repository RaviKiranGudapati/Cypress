import { td_consents_physicians_tcid_262596 } from '../../../../fixtures/sis-office/case/check-in/forms-consents/consents-physicians-tcid-262596.td';
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import SISMobileLogin from '../../../../app-modules-libs/sis-mobile/login/login';
import MyCases from '../../../../app-modules-libs/sis-mobile/my-cases/my-cases';

/* instance variables */
const sisMobileLogin = new SISMobileLogin();
const myCases = new MyCases();

export class MobileConsentsTcId262596 {
  signConsents() {
    describe('Verifying the Performing Physicians can sign Consents from Physician Mobile', () => {
      it('Verify the Performing Physicians added to consent can access consents and sign them from Physician Mobile', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep(
          'Check-in the Patient Case and Navigate to Forms and Consents'
        );
        cy.visit(Cypress.env('phyMobileURL'));
        sisMobileLogin.login(
          UserList.GEM_USER_11[0],
          UserList.GEM_USER_11[1],
          OrganizationList.GEM_ORG_6
        );
        myCases.selectPatient(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails
            .PatientFirstName
        );
        myCases.selectCaseConsents(
          td_consents_physicians_tcid_262596.Consents[3].ConsentName
        );
        myCases.signConsentStatement(
          td_consents_physicians_tcid_262596.Consents[3].ConsentName
        );
        sisMobileLogin.logout();

        sisMobileLogin.login(
          UserList.GEM_USER_10[0],
          UserList.GEM_USER_10[1],
          OrganizationList.GEM_ORG_6
        );
        myCases.selectPatient(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails
            .PatientFirstName
        );
        myCases.verifyCaseConsents(
          td_consents_physicians_tcid_262596.Consents[3].ConsentName,
          false
        );
        // #endregion
      });
    });
  }
}
