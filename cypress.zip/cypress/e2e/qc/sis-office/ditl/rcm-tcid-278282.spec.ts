import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { RevenueCycleManagementTcId278282 } from './scenarios/tcid-278282.sc';

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * 1. Login to the application with Gem_user1
 * 2. Select Org1
 * 3. Navigate to RCM tracker and ​select the responsible party as Insurance provider to the patient and click on refresh
 * 4. Verify the created patient in  RCM tracker.
 * 5. Select charge in RCM tracker and enter RCM status field and click on Done. Verify the RCM status saved successfully
 * 6. Check the check mark on the charge and verify the Turnover button should be enabled
 * 7. Click on the turn over button and document all the fields in the popup
 * 9. Click on Generate file and Done button and verify the CSV file should be downloaded
 */

/* instance variables */
const revenueCycleManagement = new RevenueCycleManagementTcId278282();

describe(
  'To verify the charges in RCM tracker and Verify the functionality of the Turn Over to collection button',
  {
    tags: ['ditl', 'revenue-cycle-management', 'US#278268', 'TC#278282'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      revenueCycleManagement.precondition();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        revenueCycleManagement.verifyChargeInRCMTracker();
      }
    );
    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
