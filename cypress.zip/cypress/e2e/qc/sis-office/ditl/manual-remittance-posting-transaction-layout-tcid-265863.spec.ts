import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { RemittancePostingTcId265863 } from './scenarios/tcid-265863.sc';

/* instance variables */
const remittancePosting = new RemittancePostingTcId265863();

/* Test Script Validation Details *****
 *1.Login SIS Complete Business desktop with User3,Navigate to Remittance Posting .
 *2.Click om manual remittance posting.
 *3.Verify case date of service,Date range field (2 values),Date Range fields should have the standard format (MM\DD\YYYY),calendar range selection button and  mandatory field.
 *4.Verify able to select Max date range of 366 and verify User should be able to see the all the active Insurance Carriers  and Guarantors
 *5.Verify User should  be able to see the title Method of Payment and should be a drop down field
 The Method of Payment  is defaulted to blank.
 *6.Verify user should be able to the amount as Max value $9,999,999.99 in the Check Amount free text field.
 *7.Verify user should be able to enter the alpha numeric data into the Payment ID.
 *8.Verify user should be able to see the Hide Show Defaults and is clickable text.
 *9.verify The User should be able to see the Period, Period should be a dropdown and listed with all the Open Periods in the dropdown and its is mandatory field.
 *10.verify The User should be able to see the Batch, Batch should be a dropdown and listed with all the Open Periods in the dropdown and its is mandatory field.
 *11.Verify Transaction date field that User should be able to see the Date  fields should have the standard format (MM\DD\YYYY), able to see the calendar range selection button, Date field should be mandatory field and defaulted to Today's date.
 *12.Verify Payment Transaction code is a dropdown, the Transfer To is a Yes/No toggle defaulted to Yes and the Generate Bill is a Yes/No toggle defaulted to Yes.
 *13.Verify that user should be able to see the helper text when the user on hover on (i)and the message should be "Set the GB checkbox for the new responsible party.
 *14.The Write Off 1 Transaction Codes is a dropdown listing active codes, Group Code is a dropdown displaying the codes and Reason Code is a dropdown displaying the codes.
 *15.The Write Off 2 Transaction Codes is a dropdown listing active codes, Group Code is a dropdown displaying the codes and Reason Code is a dropdown displaying the codes.
 *16.The Debit Transaction Codes is a dropdown listing active codes, Group Code is a dropdown displaying the codes and Reason Code is a dropdown displaying the codes.
 *17.Verify that user able enter see the Patient Name column. The user should be able to see the list of all the Patients within the date range selected, The User should be able to see the Patient name as "patient name in Last Name, First name format" and The order of the listing should be Based on DOS ( Current DOS patient at the last ).
 *16.Verify user should be able to do a Click Sorting and the Patient Name should match in Alphabetical order.
 *17.Verify user should be able to see the Patient MRN Number. And MRN Column header,The MRN number should have display the the complete MRN number when on hovered and user should be able to  do a  Click Sorting based on the MRN number.
 *18.Verify user should be able to see the DOS  as Column header and The data for the  DOS should be in standard format.(MM/DD/YY).
 *19.Verify user should be able to see the column name as CPT/HCPCS, user should be able to see the Procedure Code or supply HCPCS for this line .(Patient 1 , Patient 2 two cases and Patient 3 cases).
 *20.Verify User should be able to see the Payment column as Header. This is a Monetary amount field in US dollars. and The Value should be blank ( not 0.00).
 *21.Verify User should be able to see the (Write Off 1,Write Off 2) column as Header, The User should be able to see the Write Off 2 column as Header, This is a Monetary amount field in US dollars and The Value should be blank ( not 0.00).
 *22.Verify User should be able to see the Debit column as Header, The User should be able to see the Write Off 2 column as Header, This is a Monetary amount field in US dollars and The Value should be blank ( not 0.00).
 *23.Verify user should be able to see the Transfer to Column as Header, The Transfer to should be a dropdown, able to see the list of the all the actual drop down can show billing order (PI / SI / TI / PG / SG) and the name and but the field should only display the Billing Order.
 *24.Verify user should be able to see the Balance Due column as Header
 */

describe(
  'Data verification in Remittance Posting tracker',
  {
    tags: ['ditl', 'trackers', 'remittance-posting', 'US#277574', 'TC#265863'],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {
        remittancePosting.verifyUiFieldsInManualRemittanceposting();
      }
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        remittancePosting.verifyFieldsInTransactionGrid();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
