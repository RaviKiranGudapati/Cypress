import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { td_case_status_denied_tcid_276995 } from '../../../../../fixtures/sis-exchange/ditl/case-status-denied-tcid-276995.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { OR_CASE_REQUEST } from '../../../../../app-modules-libs/sis-office/case-request/or/case-request.or';

import CaseRequest from '../../../../../app-modules-libs/sis-office/case-request/case-request';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

/* instance variables */
const caseRequest = new CaseRequest();
const sisOfficeDesktop = new SISOfficeDesktop();

/* const values */
const fileName =
  td_case_status_denied_tcid_276995.AppointmentRequest.Attachments.FilePath.replace(
    '.png',
    ''
  );
const denyReason = 'DenyReason276995';

export class CaseRequestDenyTcId276995 {
  verifyDenyRequest() {
    it('verification of labels and perform the denial of case request in SIS Office', () => {
      // #region verifying the case details under request information and deny the case.

      cy.cGroupAsStep(
        'Verify the case details and deny the case in case request'
      );

      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
      sisOfficeDesktop.selectPatientInCaseRequest(
        td_case_status_denied_tcid_276995.AppointmentRequest.PatientDetails
          .FirstName
      );
      verifyCaseRequestDetails();
      caseRequest.performDeny(denyReason);

      // #endregion
    });
  }
}

/**
 * To verify the case request details in Request Information Tab
 */
function verifyCaseRequestDetails() {
  caseRequest.verifyRequestInformationLabels();
  caseRequest.verifyRequestInformation(
    td_case_status_denied_tcid_276995.RequestInformation
  );
  caseRequest.verifyPreviousButtonState();
  caseRequest.verifyDoneButtonState();
  caseRequest.selectRequestDetailsTab(
    OR_CASE_REQUEST.CASE_ATTACHMENT.CASE_ATTACHMENT_TAB[0]
  );
  caseRequest.verifyFileNameInAttachments(fileName);
  caseRequest.selectRequestDetailsTab(
    OR_CASE_REQUEST.REQUEST_DETAILS.REQUEST_INFORMATION[0]
  );
}
