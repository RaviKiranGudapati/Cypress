import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_transaction_tcid_276342 } from '../../../../../fixtures/sis-office/ditl/transaction-payments-write-off-debits-transfer-tcid-276342.td';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import Transactions, {
  ContextMenu,
  TransactionsTypes,
  TransactionsValues,
} from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const index = [0, 1];

/* An Array to store transaction types */
let transactionTypes: string[] = [];

export class VerifyTransactionsTcId276342 {
  verifyTransactionFunctionality() {
    it('Navigate to Facesheet transaction and Verify the Payments Popup in Transaction', () => {
      // #region Navigate to Facesheet and verify payment transaction

      cy.cGroupAsStep('Navigate to Facesheet and verify payment transaction');
      sisOfficeDesktop.navigateToFacesheetOptions(
        td_transaction_tcid_276342.PatientCase.PatientDetails,
        FaceSheetOptions.TRANSACTIONS
      );
      verifyPaymentTransaction();
      // #endregion
    });

    it('Verify the WriteOffs Popup in Transaction', () => {
      verifyWriteOffTransaction();
    });

    it('Verify the Debits Popup in Transaction', () => {
      verifyDebitTransaction();
    });

    it('Verify the Transfers Popup in Transaction', () => {
      verifyTransferTransaction();
    });
  }
}

function verifyPaymentTransaction() {
  /* The following code sets up an array to store transaction types, allowing users to delete specific types like "correction" and "payments" */

  transactionTypes = [
    TransactionsValues.correction,
    TransactionsValues.payment,
  ];

  // #region Select Cpt and enter data in payments popup

  cy.cGroupAsStep('Select Cpt and enter data in payments');
  transactions.selectCPTCodeAndTransactionForCharge(
    td_transaction_tcid_276342.PatientCase.CaseDetails.CptCodeInfo[0]
      .CPTCodeAndDescription,
    TransactionsTypes.payments
  );
  transactions.paymentsPopupTransaction(
    td_transaction_tcid_276342.CaseTransaction.Payments
  );
  // #endregion

  // #region User should be able to verify and click view/edit pop-up

  cy.cGroupAsStep('User should be able to verify and click view/edit pop-up');
  cy.reload();
  transactions.clickContextMenuOptionsItems(index[0], ContextMenu.view_edit);
  transactions.clickXBtnInPopup();
  // #endregion

  // #region User should be able to verify correction pop-up and enter new payments amount

  cy.cGroupAsStep(
    'User should be able to verify correction pop-up and enter new payments amount'
  );
  transactions.enterCorrectionPopupDetails(
    index[0],
    td_transaction_tcid_276342.AllocationCorrection
  );
  // #endregion

  // #region User should view/edit the payment correction amount

  cy.cGroupAsStep('User should view/edit the payments correction amount');
  transactions.viewEditCorrectionAmount(
    index[1],
    td_transaction_tcid_276342.CaseTransaction.Payments.PaymentCorrectionAmount
  );
  // #endregion

  // #region User should be able to click Yes and No Button for delete Payment

  cy.cGroupAsStep(
    'User should be able to click Yes and No Button for delete Payments'
  );
  transactions.deleteMultipleTransactions(transactionTypes, YesOrNo.yes);

  // #endregion
}

function verifyWriteOffTransaction() {
  /* User should be able to delete off Transaction types such as transfer and writeoff in Transactions */

  transactionTypes = [TransactionsValues.transfer, TransactionsValues.writeoff];

  // #region Select Cpt and enter data in writeOffs

  cy.cGroupAsStep('Select Cpt and enter data in writeOffs');
  transactions.selectCPTCodeAndTransactionForCharge(
    td_transaction_tcid_276342.PatientCase.CaseDetails.CptCodeInfo[0]
      .CPTCodeAndDescription,
    TransactionsTypes.writeoffs
  );
  transactions.writeoffPopupPostTransaction(
    td_transaction_tcid_276342.CaseTransaction.WriteOffs,
    YesOrNo.yes
  );
  // #endregion

  // #region User should be able to verify correction pop-up and enter new writeOffs amount

  cy.cGroupAsStep(
    'User should be able to verify correction pop-up and enter new writeOffs amount'
  );
  transactions.enterCorrectionPopupDetails(
    index[0],
    td_transaction_tcid_276342.AllocationCorrection
  );
  // #endregion

  // #region User should be able to verify and click view/edit pop-up

  cy.cGroupAsStep('User should be able to verify and click view/edit pop-up');
  transactions.viewEditCorrectionAmount(
    index[0],
    td_transaction_tcid_276342.CaseTransaction.WriteOffs
      .WriteOffCorrectionAmount
  );
  // #endregion

  // #region User should be able to click Yes and No Button for delete WriteOffs

  cy.cGroupAsStep(
    'User should be able to click Yes and No Button for delete WriteOffs'
  );
  transactions.deleteMultipleTransactions(transactionTypes, YesOrNo.yes);
  // #endregion
}

function verifyDebitTransaction() {
  /* User should be able to delete off Transaction types such as debit and transfer in Transactions */

  transactionTypes = [TransactionsValues.debit, TransactionsValues.transfer];

  // #region Select Cpt and enter data in Debits

  cy.cGroupAsStep('Select Cpt and enter data in Debits');
  transactions.selectCPTCodeAndTransactionForCharge(
    td_transaction_tcid_276342.PatientCase.CaseDetails.CptCodeInfo[0]
      .CPTCodeAndDescription,
    TransactionsTypes.debits
  );
  transactions.debitPopupPostTransaction(
    td_transaction_tcid_276342.CaseTransaction.Debits[0],
    YesOrNo.yes
  );
  // #endregion

  // #region User should be able to click correction pop-up and enter new debits amount

  cy.cGroupAsStep(
    'User should be able to click correction pop-up and enter new Debits amount'
  );
  transactions.enterCorrectionPopupDetails(
    index[0],
    td_transaction_tcid_276342.AllocationCorrection
  );
  // #endregion

  // #region User should view/edit the debits correction amount

  cy.cGroupAsStep('User should view/edit the debits correction amount');
  transactions.viewEditCorrectionAmount(
    index[0],
    td_transaction_tcid_276342.CaseTransaction.Debits[0].DebitCorrectionAmount
  );
  // #endregion

  // #region User should be able to click Yes and No Button for delete debits

  cy.cGroupAsStep(
    'User should be able to click Yes and No Button for delete debits'
  );
  transactions.deleteMultipleTransactions(transactionTypes, YesOrNo.yes);
  // #endregion
}

function verifyTransferTransaction() {
  // #region Select Cpt and enter data in Transfers

  cy.cGroupAsStep('Select Cpt and enter data in Transfers');
  transactions.selectCPTCodeAndTransactionForCharge(
    td_transaction_tcid_276342.PatientCase.CaseDetails.CptCodeInfo[0]
      .CPTCodeAndDescription,
    TransactionsTypes.transfers
  );
  transactions.transferPopupPostTransaction(
    td_transaction_tcid_276342.CaseTransaction.Transfers
  );
  // #endregion

  // #region - User should delete transfer content menu option

  cy.cGroupAsStep('User should delete transfer content menu option');
  transactions.deleteChargesInTransaction(
    TransactionsValues.transfer,
    YesOrNo.yes
  );
  // #endregion
}
