import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ExpandOrCollapse,
  YesOrNo,
  HierarchyOptions,
} from '../../../../../support/common-core-libs/application/common-core';

import { td_charge_entry_calculations_tcid_276353 } from '../../../../../fixtures/sis-office/ditl/charge-entry-calculations-tcid-276353.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';

/* instance variables */
const createCase1 = new CreateCase(
  td_charge_entry_calculations_tcid_276353.PatientCase
);
const sisChartsDesktop = new SISChartsDesktop();
const chargeEntry = new ChargeEntry(createCase1.patientCaseModel!);
const sisOfficeDesktop = new SISOfficeDesktop();
const faceSheetCases = new FaceSheetCases();
const faceSheetChargeEntry = new FaceSheetChargeEntry();

export class ChargeEntryTrackerTcId276353 {
  chargeEntryBalanceCalculations() {
    it('Verification of Sort functionality in charge entry page', () => {
      // #region Navigate to Charge Entry Tracker and Click Headers for Sorting

      cy.cGroupAsStep(
        'Navigate to Charge Entry Tracker and Click Headers for Sorting'
      );
      sisChartsDesktop.selectTracker(
        OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
      );
      chargeEntry.getTotalCasesCount();
      chargeEntry.clickOnHeadersToSort();
      chargeEntry.getTotalCasesCount();
      // #endregion
    });

    it('Verification of Auto Sort functionality for a case procedures', () => {
      performAutoSortAndVerifyOrderOfProcedures();
    });

    it('Verification of Balance amounts after addition and deletion of Charge Entry Details', () => {
      removeChargeDetailsAndVerifyBalances();
      addChargeDetailsAndVerifyBalances();
    });

    it('Documentation and verification of Additional Claim Info in Charge Entry Details', () => {
      documentAndVerifyAdditionalClaimInfo();
    });

    it('Addition of Debit amount and discounts and Verify Balance, Total Balance Due and Add Notes', () => {
      addDebitAndVerifyBalances();
      addDiscountsAndVerifyBalances();
      addNotes();
    });

    it('Verification of Balance amounts after adding Writeoffs in Charge entry details', () => {
      addWriteoffsAndVerifyBalances();
    });

    it('Verification of Balance amounts after adding Units in Charge entry details', () => {
      addUnitsAndVerifyBalances();

      // #region perform ready for bill and click on done
      cy.cGroupAsStep('Perform ready for bill and click on done');
      chargeEntry.clickReadyForBillAndDoneButton(true);
      chargeEntry.verifyPatientFallOff(
        td_charge_entry_calculations_tcid_276353.PatientCase.PatientDetails
          .PatientFullName
      );
      // #endregion
    });
  }
}

function performAutoSortAndVerifyOrderOfProcedures() {
  // #region Navigating to Charge Entry Tracker, select the case and Verify the order of cpts before and after autosort

  cy.cGroupAsStep(
    'Navigating to Charge Entry Tracker, select the case and Verify the order of cpts before and after autosort'
  );
  chargeEntry.selectCase(td_charge_entry_calculations_tcid_276353.ChargesInfo);
  chargeEntry.verifyTheOrderOfProcedure(
    td_charge_entry_calculations_tcid_276353.Cpt[0].CPTCodeAndDescription
  );
  chargeEntry.clickOnAutoSort();
  chargeEntry.verifyTheOrderOfProcedure(
    td_charge_entry_calculations_tcid_276353.Cpt[1].CPTCodeAndDescription
  );
  sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
  // #endregion

  // #region Navigating to Facsesheet Charge Entry and Verify the order of cpts after performing autosort from Charge entry tracker

  cy.cGroupAsStep(
    'Navigating to Facsesheet Charge Entry and Verify the order of cpts'
  );
  faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
  faceSheetChargeEntry.autoSort(
    td_charge_entry_calculations_tcid_276353.Cpt[1].CPTCodeAndDescription
  );
  sisOfficeDesktop.selectSisLogo();  
  // #endregion
}

function removeChargeDetailsAndVerifyBalances() {
  // #region Verification of Balances after removing the charge Details

  cy.cGroupAsStep('Verification of Balances after removing the charge Details');
  sisOfficeDesktop.selectTracker(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
      .SCHEDULE_GRID[0]
  );
  sisOfficeDesktop.selectTracker(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
  );
  chargeEntry.selectCase(td_charge_entry_calculations_tcid_276353.ChargesInfo);
  sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 0);
  chargeEntry.removePhysician(0);
  chargeEntry.removeInsurance(HierarchyOptions.primary);
  chargeEntry.clickOnXIconInSearchProcedure();
  chargeEntry.verifyAmountTotalAmountBalanceAndTotalBalanceDue(
    td_charge_entry_calculations_tcid_276353.Charges[0]
  );
  // #endregion
}

function addChargeDetailsAndVerifyBalances() {
  // #region Verification of Balances after adding charge details

  cy.cGroupAsStep('Verification of Balances after adding charge details');
  chargeEntry.enterProcedure(
    td_charge_entry_calculations_tcid_276353.PatientCase.CaseDetails
      .CptCodeInfo[0]
  );
  chargeEntry.addInsurance(
    HierarchyOptions.primary,
    td_charge_entry_calculations_tcid_276353.PatientCase.InsuranceInfo[0]
      .InsuranceCarrierName
  );
  chargeEntry.selectPhysicianDropdown(
    td_charge_entry_calculations_tcid_276353.PatientCase.CaseDetails
      .ReferringPhysician,
    0
  );
  chargeEntry.verifyPrimaryInsurance(
    td_charge_entry_calculations_tcid_276353.PatientCase.InsuranceInfo[0]
      .InsuranceCarrierName
  );
  chargeEntry.clickSelfPay(YesOrNo.yes);
  chargeEntry.verifyAmountTotalAmountBalanceAndTotalBalanceDue(
    td_charge_entry_calculations_tcid_276353.Charges[3]
  );
  // #endregion
}

function documentAndVerifyAdditionalClaimInfo() {
  // #region Document and Verify the Additional Claim Information details

  cy.cGroupAsStep(
    'Document and Verify the Additional Claim Information details'
  );
  chargeEntry.verifyAndClickAdditionalClaimInformationBtnAndVerifyUbAdditionalClaimHeadersAndLabels(
    td_charge_entry_calculations_tcid_276353.UBAdditionalClaim[0]
      .UBInstitutional!,
    td_charge_entry_calculations_tcid_276353.UBAdditionalClaim[1]
      .UBInstitutional!
  );
  chargeEntry.enterDataInUbFields(
    td_charge_entry_calculations_tcid_276353.UBAdditionalClaim[0]
  );
  chargeEntry.selectAdditionalClaimInfoDoneAndVerifyPopup();
  chargeEntry.verifyAndClickAdditionalClaimInformationBtnAndVerifyUbAdditionalClaimHeadersAndLabels(
    td_charge_entry_calculations_tcid_276353.UBAdditionalClaim[0]
      .UBInstitutional!,
    td_charge_entry_calculations_tcid_276353.UBAdditionalClaim[1]
      .UBInstitutional!
  );
  chargeEntry.verifyUbAdditionalClaimData(
    td_charge_entry_calculations_tcid_276353.UBAdditionalClaim[0]
  );
  chargeEntry.selectAdditionalClaimInfoDoneAndVerifyPopup();
  // #endregion
}

function addDebitAndVerifyBalances() {
  // #region Verification of the Balances after adding Debits

  cy.cGroupAsStep('Verification of the Balances after adding Debits');
  chargeEntry.enterDebitAmount(
    td_charge_entry_calculations_tcid_276353.Debits.DebitAmount
  );
  chargeEntry.verifyBalanceAndTotalBalanceDue(
    td_charge_entry_calculations_tcid_276353.Charges[1].Balance,
    td_charge_entry_calculations_tcid_276353.Charges[1].TotalBalanceDue
  );
  // #endregion
}

function addDiscountsAndVerifyBalances() {
  // #region Verification of the Balances after adding Discounts

  cy.cGroupAsStep('Verification of the Balances after adding Discounts ');
  chargeEntry.addDiscountAndVerifyBalanceAndTotalBalanceDue(
    td_charge_entry_calculations_tcid_276353.Charges1
  );
  // #endregion
}

function addNotes() {
  // #region Addition of the Notes

  cy.cGroupAsStep('Addition of the Notes ');
  chargeEntry.clickNotesButton();
  chargeEntry.addNotes(
    td_charge_entry_calculations_tcid_276353.PatientCase.CaseDetails.CaseNotes
  );
  // #endregion
}

function addWriteoffsAndVerifyBalances() {
  // #region Verification of balances after adding a writeoffs

  cy.cGroupAsStep('Verification of balances after adding a writeoffs');
  chargeEntry.enterWriteOffAndVerifyBalanceAndTotalBalanceDue(
    td_charge_entry_calculations_tcid_276353.Adjustment,
    td_charge_entry_calculations_tcid_276353.Charges2[0]
  );
  // #endregion
}

function addUnitsAndVerifyBalances() {
  // #region Verifications of Balances after adding units

  cy.cGroupAsStep('Verifications of Balances after adding units');
  chargeEntry.enterUnits(
    td_charge_entry_calculations_tcid_276353.Charges[0].Units,
    0
  );
  chargeEntry.verifyAmountTotalAmountBalanceAndTotalBalanceDue(
    td_charge_entry_calculations_tcid_276353.Charges[2]
  );
  sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 0);
  // #endregion
}
