import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_case_creation_verification_tcid_276386 } from '../../../../../fixtures/sis-office/ditl/case-creation-verification-tcid-276386.td';

import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const createCase = new CreateCase(
  td_case_creation_verification_tcid_276386.PatientCase
);
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();

export class CaseCreationVerificationTcId276386 {
  caseCreationVerification() {
    it('Verification of Case Creation via Scheduling grid', () => {
      caseCreationVerification();
    });

    it('Verification of Case Update Functionality via Edit option', () => {
      editCaseVerification();
    });

    it('Verification of Case Arrival & check-in process', () => {
      arrivalAndCheckInVerification();
    });
  }
}

function caseCreationVerification() {
  // #region Clicking the create a case tab slider in the schedule grid and creating a new patient

  cy.cGroupAsStep(
    'Clicking the create a case tab slider in the schedule grid and creating a new patient'
  );
  createCase.clickCreateACaseTab();
  createCase.createNewPatient(createCase.patientCaseModel!.PatientDetails);
  // #endregion

  // #region Creating the New Patients click Gender and verifying the MRN External labels

  cy.cGroupAsStep(
    'Creating the New Patients click Gender and verifying the MRN External labels'
  );
  createCase.verifyMRNExternalMRN();
  createCase.selectGender(
    td_case_creation_verification_tcid_276386.PatientCase.PatientDetails.Gender
  );
  // #endregion

  // #region Adding multiple insurances in patient details tab

  cy.cGroupAsStep('Adding multiple insurances in patient details tab');
  createCase.addMultipleInsurances(
    td_case_creation_verification_tcid_276386.PatientCase.PatientDetails
      .InsuranceCoverage
  );
  createCase.clickNextInPatientDetails();
  // #endregion

  // #region Entering the values in case details and Billing details Tab

  cy.cGroupAsStep('Entering the values in case details Tab');
  createCase.enterCaseDetails(createCase.patientCaseModel!.CaseDetails!);
  // #endregion

  // #region Selecting insurances in billing details tab
  cy.cGroupAsStep('Selecting insurances in billing details tab');
  createCase.enterBillingDetails(createCase.patientCaseModel!.BillingDetails!);
  createCase.clickDoneFooterButton();
  // #endregion
}

function editCaseVerification() {
  // #region Select Patient and click on edit icon change the start, end time, observe the duration

  cy.cGroupAsStep(
    'Select Patient and click on edit icon change the start and end time and observe the duration in case details tab'
  );
  scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
    td_case_creation_verification_tcid_276386.PatientCase.PatientDetails
      .PatientFirstName,
    OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
  );
  createCase.enterStartTime(
    td_case_creation_verification_tcid_276386.PatientCase.CaseDetails.StartTime
  );
  createCase.enterEndTime(
    td_case_creation_verification_tcid_276386.PatientCase.CaseDetails.EndTime
  );
  createCase.verifyTimeAndDuration(
    td_case_creation_verification_tcid_276386.PatientCase.CaseDetails
  );
  createCase.selectPreferenceCard(
    td_case_creation_verification_tcid_276386.PatientCase.CaseDetails
      .PreferenceCard
  );
  // #endregion

  // #region Click on Billing details tab and on Primary Guarantor drop down, Click on Add New Guarantor and Click on Done button

  cy.cGroupAsStep(
    'Click on Billing details tab and on Primary Guarantor drop down, Click on Add New Guarantor and Click on Done button'
  );
  createCase.clickOnBillingDetailsTab();
  createCase.clickAndAddPrimaryGuarantor(
    td_case_creation_verification_tcid_276386.PatientCase.GuarantorDetails
  );
  // #endregion

  // #region Select Patient and click on edit icon Check the details of Room and Preference Card in case details tab

  cy.cGroupAsStep(
    'Select Patient and click on edit icon Check the details of Room, Start Time,End Time and Preference Card in case details tab'
  );
  scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
    td_case_creation_verification_tcid_276386.PatientCase.PatientDetails
      .PatientFirstName,
    OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
  );
  createCase.verifyRoom(
    td_case_creation_verification_tcid_276386.PatientCase.CaseDetails
      .OperatingRoom
  );
  createCase.verifyTimeAndDuration(
    td_case_creation_verification_tcid_276386.PatientCase.CaseDetails
  );
  createCase.verifyPreferenceCard();
  createCase.clickDoneFooterButton();
  // #endregion
}

function arrivalAndCheckInVerification() {
  // #region Click on Patient and  Click on Arrive

  cy.cGroupAsStep('Click on Patient and  Click on Arrive');
  scheduleGrid.clickArriveButton(
    td_case_creation_verification_tcid_276386.PatientCase.PatientDetails
      .PatientFirstName
  );
  sisOfficeDesktop.selectSisLogo();
  // #endregion

  // #region Click on Patient and Click on Check-in Go to Billing and payments tab and Select Period, Batch Add some data in Amount collected, Payment id fields Click Done button

  cy.cGroupAsStep(
    'Click on Patient and Click on Check-in Go to Billing and payments tab and Select Period, Batch Add some data in Amount collected, Payment id fields Click Done button'
  );
  scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
    td_case_creation_verification_tcid_276386.PatientCase.PatientDetails
      .PatientFirstName,
    OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
  );
  createCase.selectBillingAndPayment();
  createCase.paymentDetails(
    td_case_creation_verification_tcid_276386.AmountDueDetails
  );
  createCase.selectMethodOfPayment(
    td_case_creation_verification_tcid_276386.AmountDueDetails.MethodOfPayment
  );
  createCase.selectTransactionCode(
    td_case_creation_verification_tcid_276386.AmountDueDetails.TransactionCode
  );
  createCase.clickCheckInDone();
  // #endregion;
}
