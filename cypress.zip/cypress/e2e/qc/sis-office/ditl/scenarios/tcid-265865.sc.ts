import {
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_transaction_post_tcid_265865 } from '../../../../../fixtures/sis-office/ditl/transaction-post-tcid-265865.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import { RemittancePosting } from '../../../../../app-modules-libs/sis-office/trackers/remittance-posting';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import {
  transactionsTableHeaders,
  remittanceHistorytableHeaders,
} from '../../../../../app-modules-libs/sis-office/trackers/constants/remittance-posting.const';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const faceSheetCases = new FaceSheetCases();
const remittancePosting = new RemittancePosting();

export class RemittancePostingTcId265865 {
  transactionDetailsPopup() {
    it('Verification of data in Payments/Write-offs/Debits/Transfers popup', () => {
      verifyTransactionDetailsPopup();
    });

    it('Verification of data in Confirm Remittance Post popup and posting to transactions', () => {
      verifyConfirmAndManualRemittance();
    });

    it('Verification of posted amounts(from remittance) in transactions page', () => {
      verifyAmountInTransaction();
    });
  }
}

function selectManualRemittanceAndEnterFields() {
  remittancePosting.selectManualRemittancePostingButton();
  remittancePosting.enterDataInManualRemittancePosting(
    td_transaction_post_tcid_265865.ManualRemittancePost
  );
  remittancePosting.selectTranferTo();
  remittancePosting.selectGenerateBill();
}

function verifyTransactionDetailsPopup() {
  // #region Navigate to remittance posting tracker

  cy.cGroupAsStep(
    'Navigating to Remittance posting tracker and document mandatory fields in manual remittance posting'
  );
  sisOfficeDesktop.selectScheduleType(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE.SCHEDULE_GRID[0]
  );
  sisOfficeDesktop.selectTracker(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REMITTANCE_POSTING[0]
  );
  selectManualRemittanceAndEnterFields();
  remittancePosting.enterAmountBasedOnCPT(
    td_transaction_post_tcid_265865.CptCodeInfo[0].CPTCodeAndDescription,
    td_transaction_post_tcid_265865.ChargeTransaction.Amount
  );

  // #endregion

  // #region verify charge details in transaction details popup

  cy.cGroupAsStep(
    'Verify Charge details section in Payments/Write-offs/Debits/Transfers popup'
  );
  remittancePosting.clickOnEllipsisBasedOnCpt(
    td_transaction_post_tcid_265865.PatientCase[0].PatientDetails.LastName
  );
  remittancePosting.verifyTransactionLabel();
  remittancePosting.verifyChargeDetailsInTransactionpopup(
    td_transaction_post_tcid_265865.ChargeTransaction
  );
  // #endregion

  // #region verify transaction section in transaction details popup

  cy.cGroupAsStep(
    'Verify Transaction details section in Payments/Write-offs/Debits/Transfers popup'
  );
  remittancePosting.verifyTransactionsDetailsSection(
    td_transaction_post_tcid_265865.TransactionDetails
  );
  remittancePosting.verifyGenerateBill(YesOrNo.no);
  remittancePosting.verifyTransfer(YesOrNo.no);

  // #endregion

  // #region verify transaction section in transaction details popup

  cy.cGroupAsStep(
    'Verify Transactions section in Payments/Write-offs/Debits/Transfers popup'
  );
  remittancePosting.verifyTransactionLabel();
  remittancePosting.verifyTransactionTableHeaders(transactionsTableHeaders);

  remittancePosting.verifyTransactionAmounts(
    td_transaction_post_tcid_265865.TransactionDetails.Amount
  );
  // #endregion

  // #region verify total payment copy right at the bottom of the transaction details pop up

  cy.cGroupAsStep(
    'Verify Total Payment,total write-off copy right in Payments/Write-offs/Debits/Transfers popup'
  );

  remittancePosting.verifyTotalPaymentWriteoffCopyRight(
    td_transaction_post_tcid_265865.ChargeTransaction
  );
  remittancePosting.verifyDoneButton();
  sisOfficeDesktop.clickCloseIcon();
}

function verifyConfirmAndManualRemittance() {
  // #region verify data in confirm remittance post

  cy.cGroupAsStep('Verify data in Confirm Remittance post');

  remittancePosting.clickOnPostEobToggleAndDone(true);
  remittancePosting.verifyConfirmRemittancePostFields(
    td_transaction_post_tcid_265865.ChargeTransaction,
    td_transaction_post_tcid_265865.TransactionDetails
  );
  remittancePosting.verifyMRNInConfirm();
  remittancePosting.verifyPatientNameInConfirm();

  remittancePosting.verifyPostButton();
  sisOfficeDesktop.clickCloseIcon();

  remittancePosting.clickOnPostEobToggleAndDone(false);

  remittancePosting.verifyTypeInRemittancePosting(
    td_transaction_post_tcid_265865.ManualRemittancePost.Draft
  );
  remittancePosting.selectManualRemittancePostingButton();
  // #endregion

  // #region Enter payment write-off amount for different patients

  cy.cGroupAsStep(
    'Document payment, write off amount for different patients in manual remittance posting'
  );
  remittancePosting.enterDataInManualRemittancePosting(
    td_transaction_post_tcid_265865.ManualRemittancePost
  );
  remittancePosting.selectTranferTo(true);
  remittancePosting.selectGenerateBill(true);

  remittancePosting.enterAmountBasedOnCPT(
    td_transaction_post_tcid_265865.CptCodeInfo[0].CPTCodeAndDescription,
    td_transaction_post_tcid_265865.ChargeTransaction.Amount
  );
  remittancePosting.clickOnPostEobToggleAndDone(true);
  remittancePosting.clickOnPostRemittancePost();
  // #endregion

  // #region Click on post eob yes toggle

  cy.cGroupAsStep(
    'Document data in manual remittance posting and select yes post eob toggle and click on post'
  );

  selectManualRemittanceAndEnterFields();
  remittancePosting.enterPaymentInRemittance(
    td_transaction_post_tcid_265865.CptCodeInfo[2].CPTCodeAndDescription,
    td_transaction_post_tcid_265865.ManualRemittancePost.Amount
  );
  remittancePosting.clickOnPostEobToggleAndDone(true);
  remittancePosting.clickOnPostRemittancePost();
  // #endregion
}

function verifyAmountInTransaction() {
  // #region Navigate to faceheet transaction

  cy.cGroupAsStep(
    'Navigate to facesheet transaction and verify payment amount for charge'
  );
  sisOfficeDesktop.sisOfficeGlobalSearchPatient(
    td_transaction_post_tcid_265865.PatientCase[1].PatientDetails
  );
  sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
  faceSheetCases.faceSheetSelectCaseOptionBaseCptDescription(
    FaceSheetOptions.TRANSACTIONS,
    td_transaction_post_tcid_265865.TransactionDetails.CPT
  );
  transactions.verifyAmountBasedOnType(
    td_transaction_post_tcid_265865.CptCodeInfo[2].CPTCodeAndDescription,
    td_transaction_post_tcid_265865.ChargeTransaction.TransactionType,
    td_transaction_post_tcid_265865.ChargeTransaction.Payment
  );
  // #endregion

  // #region Verify remittance history popup

  cy.cGroupAsStep('Verify remittance history popup');
  sisOfficeDesktop.selectSisLogo();
  sisOfficeDesktop.selectScheduleType(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE.SCHEDULE_GRID[0]
  );
  sisOfficeDesktop.selectTracker(
    OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REMITTANCE_POSTING[0]
  );
  remittancePosting.clickOnHistory();
  remittancePosting.verifyRemittanceHistory(remittanceHistorytableHeaders);
  // #endregion
}
