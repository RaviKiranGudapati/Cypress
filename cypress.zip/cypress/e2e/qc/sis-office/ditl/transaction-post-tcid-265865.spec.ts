import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { RemittancePostingTcId265865 } from './scenarios/tcid-265865.sc';

/*Test Script Validation Details *****
1.Login to the application and  select remittance posting tracker and click on Manual remittance posting button
2.Document all mandatory fields and verify the Dos ,charge amount ,Allowed amount and Balance due.
3.Verify period, batch ,transaction date and received from and verify the mandatory fields which are documented
4.Verify the total payment , total write off at the bottom of the window and cpt copy right text.
5.Verify Documented Payments , Write off1, Write off 2 , Debit, Amount should displayed.
6.Click on post eob button and verify the fields in confirm remittance post screen.
7.Click on Patient 1 and Document data Payment as 2000, Write Off 1 as 500 and Write Off 2 as 300.
8.Click on Patient 2 Case 1 and Document data Payment as 2500, Write Off 1 as 750.Click on Patient 2 Case 2 DO NOT  Document anything,
9.Click on Patient 3 and Document data Payment as 1500.Click on Post EOB Button ,Click on Post Button.
10.Confirm Remittance Post  modal window should be closed.
11.Logout from the application
 ************************************************************************/

/* instance variables */
const remittancePosting = new RemittancePostingTcId265865();

describe(
  'Remittance posting Operations',
  { tags: ['ditl', 'tracker', 'remittance-posting', 'US#277575', 'TC#265865'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        remittancePosting.transactionDetailsPopup();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
