import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { ChargeEntryTrackerTcId276353 } from './scenarios/tcid-276353.sc';

// SHIFT + ALT + O - Organizing the import
/*Test Script Validation Details *****
 * The spec file have dependency on seed data. One patient is created through seed data with three different insurance .
 * Case is performed with cases to code
 * Script Execution Details -
 * 1. Login into SIS  Office application and Navigate to the charge Entry Page
 * 2. Verify the headers in the charge entry page and perform the actions on ascending/descending order on the header
 * 3. Select the case and click on the autosort button and verify the sorted procedures
 * 4. Verify the Balances while adding and removing charge entry details
 * 5. Document and Verify the data for Additional claim information
 * 6. Verify the balance and total balance due  while adding debits
 * 7. Verify the balance and total balance due while selecting discounts
 * 8. Verify the Balance, Amount, Total Amount , Total Balance Due Adding  units
 * 9. Verify the case should fall off the tracker after performing ready to bill.
 ************************************************************************/

/* instance variables */
const chargeEntryTracker = new ChargeEntryTrackerTcId276353();

describe(
  'Verification of Amount, Balance and Total Balance Calculations for All Charges in Charge Entry',
  { tags: ['ditl', 'charge-entry', 'US#277588', 'TC#276353'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_7[0],
        Password: UserList.GEM_USER_7[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_7, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        chargeEntryTracker.chargeEntryBalanceCalculations();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
