import { Application } from '../../../../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../../../../support/common-core-libs/framework/common-utils';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';

import { td_block_schedule_tcid_259992 } from '../../../../../../fixtures/sis-office/block-schedule/create/block-schedule-tcid-259992.td';

import { BlockScheduling } from '../../../../../../test-data-models/shared/application-settings/application-settings.model';

import { OR_BLOCK_CREATION } from '../../../../../../app-modules-libs/sis-office/block-creation/or/create-block.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import BlockSchedule from '../../../../../../app-modules-libs/sis-office/block-creation/block-schedule';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import createBlock from '../../../../../../app-modules-libs/sis-office/block-creation/create-block';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';

/*  instance variables */
const room = new Array();
room.push(td_block_schedule_tcid_259992.BlockScheduling[4].Room[2]);
const rooms = new Array();
rooms.push(
  td_block_schedule_tcid_259992.BlockScheduling[4].Room[0],
  td_block_schedule_tcid_259992.BlockScheduling[4].Room[1]
);
const createBlocks = new createBlock();
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfiguration = new NursingConfiguration();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase(td_block_schedule_tcid_259992.PatientCase);
const blockSchedules = new BlockSchedule();

/*  const values */
const fifthMonday = CommonUtils.getNextFifthMondayInMonth();

export class BlockScheduleTcId259992 {
  editBlockScheduling(
    blockInfo: BlockScheduling,
    blockOutFlag: boolean = false
  ) {
    nursingConfiguration.addBlockScheduling(blockInfo.BlockName);

    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0],
      blockInfo.Physician
    );
    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0],
      blockInfo.Room
    );
    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0],
      blockInfo.Specialty
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
      blockInfo.StartTime
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
      blockInfo.EndTime
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
      blockInfo.StartDate
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
      blockInfo.EndDate
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.RECUR_EVERY[0],
      blockInfo.RecurEvery
    );
    nursingConfiguration.selectWeeklyAndMonthlyRadioButton(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEKLY[0]
    );
    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.WEEK_ON[0],
      blockInfo.WeeksOn
    );

    if (blockOutFlag) {
      nursingConfiguration.selectBlockOutToggleButton(
        OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_OUT[0]
      );
    }
    nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_NOTES[0],
      true
    );
    nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0],
      true
    );
  }

  monthlyBlockScheduling(
    blockInfo: BlockScheduling,
    blockOutFlag: boolean = false
  ) {
    nursingConfiguration.addBlockScheduling(blockInfo.BlockName);

    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.PHYSICIAN_DROPDOWN[0],
      blockInfo.Physician
    );
    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.ROOM_DROPDOWN[0],
      blockInfo.Room
    );
    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.SPECIALTY[0],
      blockInfo.Specialty
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_TIME[0],
      blockInfo.StartTime
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_TIME[0],
      blockInfo.EndTime
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.START_DATE[0],
      blockInfo.StartDate
    );
    nursingConfiguration.enterBlockDetails(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.END_DATE[0],
      blockInfo.EndDate
    );
    nursingConfiguration.selectWeeklyAndMonthlyRadioButton(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.MONTHLY[0]
    );
    nursingConfiguration.selectDropdownInBlockScheduling(
      OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.THE_MONTH[0],
      blockInfo.TheMonth
    );
    nursingConfiguration.selectMonthlyWeekDays(blockInfo.MonthOn);
    if (blockOutFlag) {
      nursingConfiguration.selectBlockOutToggleButton(
        OR_NURSING_CONFIGURATION.BLOCK_SCHEDULING.BLOCK_OUT[0]
      );
    }
    nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_NOTES[0],
      true
    );
    nursingConfigurationLayout.selectConfiguration(
      OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0],
      true
    );
  }

  //adding blocks from application settings
  verifyBlockSchedulingApplicationSettings() {
    describe('Creating two recurring blocks(Test Block 1, Test Block 3, Test Block 4, Test Block 5) from application settings ', () => {
      it('Entering block scheduling details for creation of Test Block 1, Test Block 3, Test Block 4, Test Block 5', () => {
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        // #region

        cy.cGroupAsStep(
          'Creating Test Block 1, Test Block 3, Test Block 4, Test Block 5'
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.BLOCK_SCHEDULING[0],
          true
        );
        this.editBlockScheduling(
          td_block_schedule_tcid_259992.BlockScheduling[0]
        );
        this.editBlockScheduling(
          td_block_schedule_tcid_259992.BlockScheduling[1],
          true
        );
        this.monthlyBlockScheduling(
          td_block_schedule_tcid_259992.BlockScheduling[2]
        );
        this.monthlyBlockScheduling(
          td_block_schedule_tcid_259992.BlockScheduling[3],
          true
        );

        // #endregion
      });
    });
  }

  verifyBlockSchedulingGrid() {
    describe('Create a Block from Block Schedule Grid', () => {
      it('Create Test Block 2 in Block schedule grid', () => {
        sisOfficeDesktop.selectSisLogo();
        // #region

        cy.cGroupAsStep('Creating Test Block 2');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        createBlocks.openBlockScheduleTab();
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.BLOCK_NAME[0],
          td_block_schedule_tcid_259992.BlockScheduling[4].BlockName
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.DATE[0],
          td_block_schedule_tcid_259992.BlockScheduling[4].Date
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.START_TIME[0],
          td_block_schedule_tcid_259992.BlockScheduling[4].StartTime
        );
        createBlocks.blockScheduleText(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.END_TIME[0],
          td_block_schedule_tcid_259992.BlockScheduling[4].EndTime
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.PHYSICIAN[0],
          td_block_schedule_tcid_259992.BlockScheduling[4].Physician![0]
        );
        createBlocks.selectDropdownValue(
          OR_BLOCK_CREATION.CREATE_A_BLOCK.SPECIALTY[0],
          td_block_schedule_tcid_259992.BlockScheduling[4].Specialty![0]
        );
        createBlocks.selectMultiSelectRoom(rooms);
        createBlocks.selectMultiSelectRoom(rooms);
        cy.cRemoveMaskWrapper(Application.office);
        createBlocks.selectMultiSelectRoom(room);
        cy.cRemoveMaskWrapper(Application.office);
        createBlocks.clickOnDoneButton();
        createBlocks.openBlockScheduleTab();

        // #endregion
      });
    });
  }

  verifyTestBlock1() {
    describe('Click on block and verify the details for Test Block 1', () => {
      it('Verifying Test block 1 from Block Schedule Grid', () => {
        // #region

        cy.cGroupAsStep('Verifying Test Block 1');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectDateFromScheduleGrid(
          CommonUtils.getMondayDateFromToday()
        );
        scheduleGrid.clickBlockNameInBlockSchedule(
          td_block_schedule_tcid_259992.BlockScheduling[0].BlockName
        );
        blockSchedules.clickOnCrossIcon();

        // #endregion
      });
    });
  }

  verifyChangeDate() {
    describe('Verify the change date to monday as per configuration', () => {
      it('Verifying change date for Test Block 1', () => {
        // #region

        cy.cGroupAsStep(
          'Verifying Test Block 1 by changing date to next monday'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectDateFromScheduleGrid(
          CommonUtils.getThirdMonday()
        );
        scheduleGrid.clickBlockNameInBlockSchedule(
          td_block_schedule_tcid_259992.BlockScheduling[0].BlockName
        );
        blockSchedules.clickOnCrossIcon();

        // #endregion
      });
    });
  }

  verifyBlock() {
    describe('Verify existing block and blockOut toggle button and Recurrence for fifth week for block 4,5', () => {
      it('Verifying block 3, block 4, block 5', () => {
        // #region

        cy.cGroupAsStep('Verifying existing block and blockOut toggle button');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        createBlocks.openBlockScheduleTab();
        createBlocks.selectExistingBlockToggleButton(false);
        createBlocks.selectBlockNameDropdown(
          td_block_schedule_tcid_259992.BlockScheduling[1].BlockName
        );
        createBlocks.verifyBlockOutYesOrNo();
        blockSchedules.clickOnCrossIcon();
        createBlocks.selectYesOrNoButton();

        // #endregion

        // #region

        cy.cGroupAsStep('Verifying Test Block 5 and Room close popup window');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectDateFromScheduleGrid(fifthMonday);
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[3].BlockName,
          2
        );
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[3].BlockName,
          4
        );
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[3].BlockName,
          5
        );
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[3].BlockName,
          6
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cRemoveMaskWrapper(Application.office);
        blockSchedules.verifyBlockAndClick(
          td_block_schedule_tcid_259992.BlockScheduling[3].BlockName,
          2
        );
        blockSchedules.verifyRoomClosed();

        // #endregion

        // #region

        cy.cGroupAsStep(
          'Verifying Test Block 4 and creating patient in schedule grid'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectDateFromScheduleGrid(fifthMonday);
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[2].BlockName,
          2
        );
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[2].BlockName,
          4
        );
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[2].BlockName,
          5
        );
        blockSchedules.verifyDuplicateBlocks(
          td_block_schedule_tcid_259992.BlockScheduling[2].BlockName,
          6
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cRemoveMaskWrapper(Application.office);
        blockSchedules.verifyBlockAndClick(
          td_block_schedule_tcid_259992.BlockScheduling[2].BlockName,
          2
        );
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        createCase.enterPatientDetails(
          createCase.patientCaseModel!.PatientDetails!
        );
        createCase.selectAppointmentType(
          createCase.patientCaseModel!.CaseDetails?.AppointmentType!
        );
        createCase.enterCPTRowData(
          td_block_schedule_tcid_259992.PatientCase.CaseDetails!.CptCodeInfo[0]
        );
        createCase.clickNextInCaseDetails();
        sisOfficeDesktop.clickDoneButton();

        // #endregion
      });
    });
  }
}
