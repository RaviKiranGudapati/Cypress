import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CaseCancelTcId260016 } from './scenarios/tcid-260016.sc';

/* instance variables */
const caseCancelScenario = new CaseCancelTcId260016();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login and Set Show Cancelled Cases as NO In User Settings
 * 2. Create a case for one Patient
 * 3. Cancel the case In schedule Grid
 * 4. Verify the cancelled case is not displayed in Schedule Grid
 * 5. Set Show Cancelled Cases as Yes In User Settings
 * 6. Verify the background color of Cancelled Case
 * 7. Verify the Reinstate buttons and other buttons state in case details popup
 * 8. Verify Reinstate button functionality to re-activate the cancelled case
 * 9. Verify the background color of Reinstated Case
 * 10. Logout from application
 */

describe(
  'Verifying Visibility Of Cancelled Case Based On User Menu Settings - YES/No',
  { tags: ['case-cancel', 'TC#260016'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        caseCancelScenario.verifyShowCancelCaseNo();
        caseCancelScenario.verifyShowCancelCaseYes();
        caseCancelScenario.verifyButtonsInCancelledCase();
        caseCancelScenario.verifyReinstateFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
