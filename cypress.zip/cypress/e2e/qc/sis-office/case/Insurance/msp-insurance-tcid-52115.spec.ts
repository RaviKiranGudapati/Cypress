import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { MspInsuranceTcId52115 } from './scenarios/tcid-52115.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

//SHIFT + ALT + O - Organizing the import
/*Test Script Validation Details *****
 * Script Execution Details
 * Login to the application
 * Insurances and patients should be created using seed data.
 * Navigate to business desktop and create a new patient.
 * Verify MSP insurance type code dropdown functionality during patient creation
 * Navigate back to schedule grid and select created patient
 * Verify MSP insurance type code dropdown functionality during patient updation.
 * Above steps will be repeated for 3 patients by adding different types of insurances.
 * Select patient from schedule grid, checkin the patient.
 * Verify MSP insurance type code dropdown functionality and the saved MSP code.
 * Above steps will be repeated for 2 patients by adding different types of insurances
 * Search the patient from masthead and navigate to facesheet
 * Verify MSP insurance type code dropdown functionality and the saved MSP code.
 * Above steps will be repeated for 2 patients by adding different types of insurances
  
 ************************************************************************/

/* instance variables */
const mspInsurance = new MspInsuranceTcId52115();

describe(
  'Verify the MSP code drop-down functionality during case-creation,check-in and facesheet',
  { tags: ['Case Creation', 'TC#52115', 'US#267063'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    //After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        mspInsurance.verifyMspInsuranceCaseCreation();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
