import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_msp_insurance_tcid52115 } from '../../../../../../fixtures/sis-office/case/insurance/msp-insurance-tcid-52115.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';

/*instance variables*/
const createCase = new CreateCase();
const createCase1 = new CreateCase(td_msp_insurance_tcid52115.PatientCase[0]);
const createCase2 = new CreateCase(td_msp_insurance_tcid52115.PatientCase[1]);
const createCase3 = new CreateCase(td_msp_insurance_tcid52115.PatientCase[2]);
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();

export class MspInsuranceTcId52115 {
  verifyMspInsuranceCaseCreation() {
    describe('Verifying MSP Type code functionality during case creation and update', () => {
      it('Verifying MSP Type code dropdown as per the insurance selection', () => {
        // #region Creating patient1 from schedule grid and verifying the MSP code drop down

        cy.cGroupAsStep(
          'Creating patient1 from schedule grid and verifying the MSP code drop down'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase1.clickCreateACaseTab();
        createCase1.createNewPatient(
          createCase1.patientCaseModel!.PatientDetails
        );
        createCase1.selectGender(
          td_msp_insurance_tcid52115.PatientCase[0].PatientDetails.Gender
        );
        createCase1.clickInsuranceAddButton();

        createCase1.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase1.clickInsuranceCarrierDropdown();
        createCase1.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase1.selectInsuranceCarrierDropdownValue();

        createCase1.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase1.clickInsuranceDoneButton();
        createCase1.clickInsuranceAddButton();
        createCase1.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase1.clickInsuranceCarrierDropdown();
        createCase1.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase1.selectInsuranceCarrierDropdownValue();

        createCase1.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase1.clickInsuranceDoneButton();
        createCase1.clickNextInPatientDetails();
        createCase1.enterCaseDetails(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
        );
        // Added additional assertions before clicking primary insurance drop down
        createCase1.clickPrimaryInsurance();
        createCase1.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase1.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase1.verifyMSpFieldPresence(false);
        createCase1.removeInsurance(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .PRIMARY_INSURANCE[0]
        );
        createCase1.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase1.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[0].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase1.verifyMSpFieldPresence(true);
        createCase1.clickMspCodeField();
        createCase1.verifyMspCodeFieldValues(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues
        );

        createCase1.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[4]
        );

        createCase1.clickDoneFooterButton();

        // #endregion

        // #region Verifying MSP code functionality during the case update

        cy.cGroupAsStep(
          'Verifying MSP code functionality during the case update'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[0].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase1.clickNextInCaseDetails();

        createCase1.verifySavedMspCodeValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[4]
        );
        createCase.clickCaseCross();
        createCase.clickLossData();
        sisOfficeDesktop.selectSisLogo();

        // #endregion

        // #region Creating patient2 from schedule grid and verifying the MSP code drop down

        cy.cGroupAsStep(
          'Creating patient2 from schedule grid and verifying the MSP code drop down'
        );
        sisOfficeDesktop.selectSisLogo();
        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase2.patientCaseModel!.PatientDetails
        );
        createCase2.selectGender(
          td_msp_insurance_tcid52115.PatientCase[1].PatientDetails.Gender
        );
        createCase2.clickInsuranceAddButton();
        createCase2.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase2.clickInsuranceCarrierDropdown();
        createCase2.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase2.selectInsuranceCarrierDropdownValue();

        createCase2.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase2.clickInsuranceDoneButton();
        createCase2.clickInsuranceAddButton();
        createCase2.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase2.clickInsuranceCarrierDropdown();
        createCase2.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase2.selectInsuranceCarrierDropdownValue();

        createCase2.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase2.clickInsuranceDoneButton();
        createCase2.clickInsuranceAddButton();
        createCase2.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[2]
        );
        createCase2.clickInsuranceCarrierDropdown();
        createCase2.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[2]
        );
        createCase2.selectInsuranceCarrierDropdownValue();

        createCase2.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[2]
        );
        createCase2.clickInsuranceDoneButton();
        createCase2.clickNextInPatientDetails();
        createCase2.enterCaseDetails(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
        );
        // Added additional assertions before clicking primary insurance drop down
        createCase2.clickPrimaryInsurance();
        createCase2.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase2.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase2.verifyMSpFieldPresence(false);
        createCase2.enterTertiaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[1].CaseDetails
            .InsuranceCoverage[2].InsuranceCarrier
        );
        createCase2.verifyMSpFieldPresence(true);
        createCase2.clickMspCodeField();
        createCase2.verifyMspCodeFieldValues(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues
        );

        createCase2.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[3]
        );
        createCase2.clickDoneFooterButton();

        // #endregion

        // #region Verifying MSP code functionality during the case update

        cy.cGroupAsStep(
          'Verifying MSP code functionality during the case update'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[1].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase2.clickNextInCaseDetails();
        createCase2.verifySavedMspCodeValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[3]
        );
        createCase.clickCaseCross();
        createCase.clickLossData();
        sisOfficeDesktop.selectSisLogo();
        // #endregion

        // #region Creating patient3 from schedule grid and verifying the MSP code drop down

        cy.cGroupAsStep(
          'Creating patient3 from schedule grid and verifying the MSP code drop down'
        );
        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase3.patientCaseModel!.PatientDetails
        );
        createCase3.selectGender(
          td_msp_insurance_tcid52115.PatientCase[2].PatientDetails.Gender
        );
        createCase3.clickInsuranceAddButton();
        createCase3.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase3.clickInsuranceCarrierDropdown();
        createCase3.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase3.selectInsuranceCarrierDropdownValue();

        createCase3.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase3.clickInsuranceDoneButton();
        createCase3.clickInsuranceAddButton();
        createCase3.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase3.clickInsuranceCarrierDropdown();
        createCase3.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase3.selectInsuranceCarrierDropdownValue();

        createCase3.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase3.clickInsuranceDoneButton();
        createCase3.clickNextInPatientDetails();
        createCase3.enterCaseDetails(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
        );
        // Added additional assertions before clicking primary insurance drop down
        createCase3.clickPrimaryInsurance();
        createCase3.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase3.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[2].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase3.verifyMSpFieldPresence(true);
        createCase3.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[10]
        );
        createCase3.clickDoneFooterButton();

        // #endregion

        // #region Verifying MSP code functionality during the case update

        cy.cGroupAsStep(
          'Verifying MSP code functionality during the case update'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[2].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase3.clickNextInCaseDetails();
        createCase3.verifySavedMspCodeValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[10]
        );
        createCase.clickCaseCross();
        createCase.clickLossData();
        // #endregion
      });
    });
  }
}
