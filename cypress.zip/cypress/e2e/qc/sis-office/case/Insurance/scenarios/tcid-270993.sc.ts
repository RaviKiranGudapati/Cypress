import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { SubRoutes } from '../../../../../../support/common-core-libs/application/constants/sub-routes.constants';

import { td_msp_insurance_tcid52115 } from '../../../../../../fixtures/sis-office/case/insurance/msp-insurance-tcid-52115.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import PatientDetailsFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import CaseConsents from '../../../../../../app-modules-libs/sis-office/case-check-in/case-consents';

/*instance variables*/
const createCase = new CreateCase();
const createCase1 = new CreateCase(td_msp_insurance_tcid52115.PatientCase[0]);
const scheduleGrid = new ScheduleGrid();
const transaction = new Transactions();
const patientDetailsFacesheet = new PatientDetailsFaceSheet();
const sisOfficeDesktop = new SISOfficeDesktop();
const facesheetCases = new FaceSheetCases();
const consent = new CaseConsents();

export class MspInsuranceTcId270993 {
  verifyMspInsuranceCheckIn() {
    describe('Verifying MSP Type code functionality during patient check-in', () => {
      it('Verifying MSP Type code dropdown as per the insurances available', () => {
        // #region Performing the patient4 check-in and verifying the MSP drop down as insurances being added

        cy.cGroupAsStep(
          'Performing the patient4 check-in and verifying the MSP drop down as insurances being added'
        );
        sisOfficeDesktop.selectSisLogo();
        cy.reload();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[3].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.clickInsuranceAddButton();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.selectInsuranceCarrierDropdownValue();

        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceDoneButton();
        createCase.clickInsuranceAddButton();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.selectInsuranceCarrierDropdownValue();

        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.clickInsuranceDoneButton();
        createCase.selectBillingAndPayment();
        createCase.assertBillingAndPaymentDetailsInCheckIn();
        // Added additional assertions before clicking primary insurance drop down
        createCase.clickPrimaryInsurance();
        createCase.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase.verifyMSpFieldPresence(false);
        createCase.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase.verifyMSpFieldPresence(true);
        createCase.clickMspCodeField();
        createCase.verifyMspCodeFieldValues(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues
        );
        createCase1.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );
        consent.clickPreviousInBillingAndPaymentCheckIn();
        createCase.clickCheckInDone();

        // #endregion

        // #region Verifying the saved MSP drop down value during check-in

        cy.cGroupAsStep(
          'Verifying the saved MSP drop down value during check-in'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cWait(SubRoutes.case_request_get_pending_count);
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[3].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();
        createCase.assertBillingAndPaymentDetailsInCheckIn();
        createCase.verifySavedMspCodeValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        // #endregion

        // #region Performing the patient5 check-in and verifying the MSP drop down as insurances being added

        cy.cGroupAsStep(
          'Performing the patient5 check-in and verifying the MSP drop down as insurances being added'
        );
        cy.reload();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cWait(SubRoutes.case_request_get_pending_count);
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[4].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.clickInsuranceAddButton();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[4].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[4].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.selectInsuranceCarrierDropdownValue();

        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[4].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceDoneButton();
        createCase.clickInsuranceAddButton();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[4].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[4].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.selectInsuranceCarrierDropdownValue();

        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[4].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.clickInsuranceDoneButton();
        createCase.selectBillingAndPayment();
        createCase.assertBillingAndPaymentDetailsInCheckIn();
        // Added additional assertions before clicking primary insurance drop down
        createCase.clickPrimaryInsurance();
        createCase.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[4].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[3].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase.verifyMSpFieldPresence(true);
        createCase.clickMspCodeField();
        createCase.verifyMspCodeFieldValues(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues
        );
        createCase1.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );
        createCase.clickCheckInDone();

        // #endregion

        // #region Verifying the saved MSP drop down value during check-in

        cy.cGroupAsStep(
          'Verifying the saved MSP drop down value during check-in'
        );
        cy.reload();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cWait(SubRoutes.case_request_get_pending_count);
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[4].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();
        createCase.assertBillingAndPaymentDetailsInCheckIn();
        createCase.verifySavedMspCodeValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyMspInsuranceFacesheet() {
    describe('Verifying MSP Type code functionality in facesheet', () => {
      it('Verifying the MSP code drop down functionality in facesheet by adding different types of insurances', () => {
        cy.reload();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        // #region Searching the patient6 from masthead,navigating to facesheet and verifying MSP drop down

        cy.cGroupAsStep(
          'Searching the patient6 from masthead,navigating to facesheet and verifying MSP drop down'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_msp_insurance_tcid52115.PatientCase[5].PatientDetails
        );
        patientDetailsFacesheet.clickOnPatientDetailsTab();
        patientDetailsFacesheet.clickAddInsurance();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[5].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[5].CaseDetails
            .InsuranceCoverage[0]
        );
        patientDetailsFacesheet.selectInsuranceCarrierDropdownValue();

        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[5].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceDoneButton();
        patientDetailsFacesheet.clickAddInsurance();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[5].CaseDetails
            .InsuranceCoverage[1]
        );
        patientDetailsFacesheet.selectInsuranceCarrierDropdownValue();
        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[5].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.clickInsuranceDoneButton();
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );
        facesheetCases.clickNotesButton();
        facesheetCases.addNotesDone();

        createCase.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[5].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase1.verifyMSpFieldPresence(false);
        createCase.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[5].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase.verifyMSpFieldPresence(true);
        createCase.clickMspCodeField();
        createCase.verifyMspCodeFieldValues(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues
        );
        createCase.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );
        transaction.clickUpdateButton();
        // #endregion

        // #region Verifying the saved MSP code value in payer details

        cy.cGroupAsStep('Verifying the saved MSP code value in payer details');
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        facesheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );
        facesheetCases.clickNotesButton();
        facesheetCases.addNotesDone();

        createCase1.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );

        // #endregion

        // #region Searching the patient7 from masthead,navigating to facesheet and verifying MSP drop down

        cy.cGroupAsStep(
          'Searching the patient7 from masthead,navigating to facesheet and verifying MSP drop down'
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        sisOfficeDesktop.selectSisLogo();
        cy.reload();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_msp_insurance_tcid52115.PatientCase[6].PatientDetails
        );
        patientDetailsFacesheet.clickOnPatientDetailsTab();
        cy.reload();
        patientDetailsFacesheet.clickAddInsurance();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[0]
        );
        patientDetailsFacesheet.selectInsuranceCarrierDropdownValue();

        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.clickInsuranceDoneButton();
        patientDetailsFacesheet.clickAddInsurance();
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[1]
        );

        createCase.clickInsuranceCarrierDropdown();
        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[1]
        );
        patientDetailsFacesheet.selectInsuranceCarrierDropdownValue();

        createCase.enterSubscriberID(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[1]
        );
        createCase.clickInsuranceDoneButton();
        cy.reload();
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );
        facesheetCases.clickNotesButton();
        facesheetCases.addNotesDone();

        createCase.enterPrimaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[0].InsuranceCarrier
        );
        createCase.enterSecondaryInsurance(
          td_msp_insurance_tcid52115.PatientCase[6].CaseDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        createCase.verifyMSpFieldPresence(true);
        createCase.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );
        transaction.clickUpdateButton();
        // #endregion

        // #region Verifying the saved MSP code value in payer details

        cy.cGroupAsStep('Verifying the saved MSP code value in payer details');
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        facesheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );
        cy.reload();
        facesheetCases.clickNotesButton();
        facesheetCases.addNotesDone();

        createCase.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );
        cy.reload();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.reload();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_msp_insurance_tcid52115.PatientCase[4].PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();
        createCase.assertBillingAndPaymentDetailsInCheckIn();
        createCase.selectMspCodeFieldValue(
          td_msp_insurance_tcid52115.InsuranceCoverage.MspCodeDropDownValues[2]
        );
        // #endregion
      });
    });
  }
}
