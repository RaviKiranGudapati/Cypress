/************************Revision History*************************** *
 * 02/11/22, Praveen,Rakesh Designed the new spec based on the Test Case - TCID - 260018.
 */
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import Configuration from '../../../../../app-modules-libs/sis-exchange/configuration/configuration';

import { SisOfficeCDTCodeTcId260018 } from './scenarios/tcid-260018.sc';
import { SisExchangeCDTCodeTcId260018 } from '../../../sis-exchange/case/scenarios/tcid-260018.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const sisOfficeCDTCode = new SisOfficeCDTCodeTcId260018();
const configuration = new Configuration();
const sisExchangeCDTCode = new SisExchangeCDTCodeTcId260018();

/* Test Script Validation Details *****
 * Pre-Condition-
 * CDT code feature verify either enable or disable mode in Enterprise Configuration page
 * Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Select the facility management and check the CDT feature as disable mode under features tab based on facility name
 * 3. Verify the CDT Code with no results in Fee Schedule and Case Details tab.
 * 4. Login into SIS Exchange application and verify the CDT code with no results in Procedure Details tab.
 * 5. Login into application and navigate to SIS Enterprise Configuration page.
 * 6. Select the facility management and check the CDT feature as enable mode under features tab based on facility name
 * 7. Verify the CDT Code with results in Fee Schedule, Case Details,Case To Code, Charge Entry and My Tasks - Charge Entry,
 * 8. Login into SIS Exchange application and verify the CDT code with results in Procedure Details tab.
 */

describe(
  'Verifying CDT feature state in Facility Management and CDT search results in Fee Schedule, Case Details in Create Case, Case To Code, Charge Entry, Facesheet -Charge Entry and Procedure Details in Appointment Request popup',
  {
    tags: ['case-create', 'US#260240', 'TC#260018'],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      configuration.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        /*** Verify CDT Codes in Application when feature as disable mode****/
        sisOfficeCDTCode.verifyCDTCodeDisableFeature();
        sisOfficeCDTCode.verifyCDTCodeNoSearchResults();
        sisExchangeCDTCode.verifyCDTCodeNoSearchResultsInProcedureDetails();

        /***Verify CDT Codes in Application when feature as enable mode ****/
        sisOfficeCDTCode.VerifyCDTCodeEnableFeature();
        sisOfficeCDTCode.verifyCDTCodeSearchResults();
        sisExchangeCDTCode.verifyCDTCodeSearchResultsInProcedureDetails();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
