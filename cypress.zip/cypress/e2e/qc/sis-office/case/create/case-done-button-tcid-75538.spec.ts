import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { VerifyingDoneButtonTcId75538 } from './scenarios/tcid-75538.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const verifyingDoneButton = new VerifyingDoneButtonTcId75538();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify functionality of Done Button during case creation and Patient Check-In
 * Script Execution Approach -
 * 1. Click on Create Case Tab and create New Patient
 * 2. Enter all the mandatory fields in patient details, case details and billing details
 * 3. Verify the Done button is enabled and click on done button to create case
 * 4. ChickIn the created case, add Primary Guarantor
 * 5. Verify the Done to be enabled, click on done button
 * 6. Click on Create Case Tab and create New Patient
 * 7. Verify the Done button is disable without entering mandatory fields
 * 8. ChickIn the created case and Verify the Done button is disabled without mandatory data
 * 9. Verify Case Details Tab is open upon editing the patient
 * 11. Logout
 ************************************************************************/

describe(
  'Verify functionality of Done Button during case creation and Patient Check-In',
  { tags: ['US#260218', 'TC#75538', 'case-create'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        verifyingDoneButton.verifyDoneButtonEnabledEnteringAllMandatoryFields();
        verifyingDoneButton.verifyDoneButtonDisabledNotEnteringMandatoryFields();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
