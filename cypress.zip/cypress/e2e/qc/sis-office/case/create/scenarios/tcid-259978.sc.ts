import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';

import { td_case_creation_259978 } from '../../../../../../fixtures/sis-office/case/create/case-creation-tcid-259978.td';

import { OR_PATIENT_CASE_CREATION } from '../../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const createCase = new CreateCase(td_case_creation_259978.PatientCase[0]);
const create2ndCase = new CreateCase(td_case_creation_259978.PatientCase[1]);
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();

/* const values */
const stateValue = '62';
const subValue = '8';
const State_dropdown_Values = [
  'AA',
  'AE',
  'AK',
  'AL',
  'AP',
  'AR',
  'AS',
  'AZ',
  'CA',
  'CO',
  'CT',
  'DC',
  'DE',
  'FL',
  'FM',
  'GA',
  'GU',
  'HI',
  'IA',
  'ID',
  'IL',
  'IN',
  'KS',
  'KY',
  'LA',
  'MA',
  'MD',
  'ME',
  'MH',
  'MI',
  'MN',
  'MO',
  'MP',
  'MS',
  'MT',
  'NC',
  'ND',
  'NE',
  'NH',
  'NJ',
  'NM',
  'NV',
  'NY',
  'OH',
  'OK',
  'OR',
  'PA',
  'PR',
  'PW',
  'RI',
  'SC',
  'SD',
  'TN',
  'TX',
  'UT',
  'VA',
  'VI',
  'VT',
  'WA',
  'WI',
  'WV',
  'WY',
];
const Relationship_dropdown_vals = [
  'Self',
  'Spouse',
  'Child',
  'Employee',
  'Life Partner',
  'Other Relationship',
  'Unknown',
  'Organ Donor',
];

export class casecreationTcid259978 {
  orPatientDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS;
  orBillingDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS;
  orCaseDetails = OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS;
  orNewPatient = OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CREATE_NEW_PATIENT;

  createPatient() {
    describe('Verify the fields are enabled or disabled and required for the new patient', () => {
      it('Verify and clicking fields for the new patient window', () => {
        // #region Clicking the create a case tab slider in the schedule grid

        cy.cGroupAsStep(
          'Clicking the create a case tab slider in the schedule grid'
        );

        createCase.clickCreateACaseTab();

        cy.cGroupAsStep(
          'Clicking the new patient button and verifing the labels'
        );
        // Clicking the add new patient button in the tab
        createCase.clickNewPatientButton();
        createCase.verifyNewPatientLabel();
        // Verify the Done button is enabled after entering the mandatory fields in patient popup window
        createCase.enterPatientFirstName(
          td_case_creation_259978.PatientCase[0].PatientDetails
        );
        createCase.enterPatientLastName(
          td_case_creation_259978.PatientCase[0].PatientDetails
        );
        createCase.verifyNewPatientDoneButtonEnabled();

        cy.cGroupAsStep('Clicking the Patient cross and Case Cross buttons');
        // Clicking the cross icon in the new patient popup window
        sisOfficeDesktop.clickCloseIcon();
        createCase.clickCaseCross();
      });
      // #endregion

      it('Creating the patient case and patient details section ', () => {
        // #region Creating the New Patients click Gender and verifing the MRN External labels

        cy.cGroupAsStep(
          'Creating the New Patients click Gender and verifing the MRN External labels'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // Verifying mrn and external mrn fields are disabled in the patient details
        createCase.verifyMRNExternalMRN();
        // #endregion

        // #region Select Gender
        createCase.selectGender(
          td_case_creation_259978.PatientCase[0].PatientDetails.Gender
        );

        cy.cGroupAsStep(
          'Click on the Add button of insurance button and verifing tiles and labels of the model'
        );

        // Click on Add button in insurance model of the case creation
        createCase.clickInsuranceAddButton();

        // Verify Titles and close icons in insurance model
        createCase.verifyTitlesIconsInsuranceModel();

        cy.cGroupAsStep(
          'Enter the Values in the fields and verifing the warning messages of the Insurance model'
        );

        // Remove data and verify warning text in insurance coverage pop-up
        createCase.enterInsuranceFirstName(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterInsuranceLastName(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterInsuranceMiddleInitial(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );

        // Removing first,mi,last name
        createCase.clearInsuranceFirstLastName();

        // Verify warning text for first and last name
        createCase.verifyWarningMsgInsuranceFirstLastName();

        // Entering first,mi,last name
        createCase.enterInsuranceFirstName(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterInsuranceLastName(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );

        // Verify gender with 2 options and select gender in insurance coverage pop-up
        createCase.verifyInsuranceGender();
        createCase.selectInsuranceGender(
          td_case_creation_259978.InsuranceCoverage[0]
        );

        // Verify DOB field in insurance coverage pop-up
        createCase.verifyInsuranceDOB();
        createCase.verifyPlaceholderInsuranceDOB(
          td_case_creation_259978.InsuranceCoverage[1]
        );
        createCase.enterInsuranceDOB(
          td_case_creation_259978.InsuranceCoverage[0]
        );
        createCase.enterInsuranceMiddleInitial(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.verifyInsuranceDOBFilled();
        createCase.enterInsuranceDOB(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );

        // Check for subscriber id and enter 81 char verify subscriber ID field in insurance coverage pop-up
        createCase.verifySubscriberID(
          td_case_creation_259978.InsuranceCoverage[0]
        );
        createCase.enterSubscriberID(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );

        // Verify group name, group number & employer fields in insurance coverage pop-up
        createCase.enterGroupName(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterGroupNumber(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterEmployer(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        // #endregion

        // #region verifying effective from and effective to fields in  add insurance coverage pop-up
        createCase.verifyDateFormatEffectiveFrom(
          td_case_creation_259978.InsuranceCoverage[1]
        );
        createCase.verifyDateFormatEffectiveTo(
          td_case_creation_259978.InsuranceCoverage[1]
        );

        // Entering effective from and effective to fields in insurance coverage pop-up
        createCase.enterEffectiveFrom(
          td_case_creation_259978.InsuranceCoverage[1]
        );
        createCase.enterEffectiveTo(
          td_case_creation_259978.InsuranceCoverage[1]
        );

        // Entering invalid dates in Effective From and To fields and verifying warning text
        createCase.enterEffectiveFrom(
          td_case_creation_259978.InsuranceCoverage[0]
        );
        createCase.clickEffectiveTo();
        createCase.verifyEffectiveFromFilled();
        createCase.enterEffectiveTo(
          td_case_creation_259978.InsuranceCoverage[0]
        );
        createCase.clickEffectiveFrom();
        createCase.verifyEffectiveToFilled();
        createCase.enterEffectiveFrom(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterEffectiveTo(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        // #endregion
      });

      it('verifing and entering the Adrreses the values in Insurance Models', () => {
        // #region Verifying Relationship to Subscriber label on add insurance coverage window having red asterisk

        createCase.verifyRelationshipToSubscriberLabel();
        createCase.verifyRelationshipToSubscriberDefaultValue();
        createCase.clickRelationshipToSubscriberDropdown();
        createCase.verifyDropdownValues(subValue, Relationship_dropdown_vals);

        // #endregion
        // #region verify address fields in insurance coverage pop-up
        createCase.clickStateDropdown();
        createCase.verifyDropdownValues(stateValue, State_dropdown_Values);
        // Entering address fields in insurance coverage pop-up
        createCase.enterAddressFields(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.enterPhoneNumber(
          td_case_creation_259978.InsuranceCoverage[0]
        );
        createCase.clickEmail();
        createCase.verifyPhoneNumberFilled();
        createCase.enterPhoneNumber(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );

        // Select insurance carrier and verify done button is disabled in add insurance coverage pop-up
        createCase.clickInsuranceCarrierDropdown();

        createCase.enterInsuranceCarrierDropdownSearchBar(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );

        createCase.selectInsuranceCarrierDropdownValue();

        // Verify that done Button should be in disabled state.
        createCase.verifyInsuranceDone(false);
        // Select relationship to subscriber and verify done button is disabled in add insurance coverage pop-up
        createCase.clickSelectRelationshipToSubscriberDropdown(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        createCase.verifyInsuranceDone();
        createCase.clickInsuranceDoneButton();

        // #endregion clicking on the next button in the patient details page
      });

      it('verifing the case details & Billing Details fields and entering the values', () => {
        // #region
        createCase.clickNextInPatientDetails();
        // Verifying the case details fields labels
        createCase.verifyCaseDetailsLabels();

        cy.cGroupAsStep(
          'Enter the Values in the fields and verifing the warning messages of the Case details section'
        );

        // Verifying the Error message for the start time and end time
        createCase.verifyWarningMsgStartEndTime();
        // Verifying the Error message for the Date of service

        createCase.enterDateOfService(
          td_case_creation_259978.PatientCase[0].CaseDetails.DateOfService
        );
        createCase.verifyWarningMsgDOS();

        cy.cGroupAsStep(
          'verifying and Enter the Values in the fields Proceddure Details section'
        );

        // Verifying the Procedure Details Section fields at the bottom of the Case Details Screen
        createCase.verifyProcedureDetailsCaseDetailsLabel();
        createCase.verifyPlaceholderCPTPreOp();
        createCase.verifyCopyRight();
        // Entering the Procedure Details Section fields at the bottom of the Case Details Screen
        createCase.enterCPTRowData(
          td_case_creation_259978.PatientCase[0].CaseDetails.CptCodeInfo[0]
        );
        // Clicking on the plus icon in Procedure Details Section at the bottom of the Case Details Screen
        createCase.clickPlusIconProcedureDetails();
        // Verifying the Procedure Details Section fields at the bottom after click plus icon
        createCase.verifyProcedureDetailsCaseDetailsLabel();
        // #endregion

        // #region Validating Add Guarantor pop up fields on UI level
        cy.cGroupAsStep('click billing details button');
        // Click billing details button
        createCase.clickBillingDetails();

        cy.cGroupAsStep(
          'Verifing the labels and Entering the values for Primary Guarantor popup'
        );
        // Click primary guarantor dropdown and select add new guarantor value from the dropdown list
        createCase.clickPrimaryGuarantorDropdown();
        createCase.selectPrimaryGuarantorDropdownValue();
        // Verify all the fields of Add Guarantor PopUp
        createCase.verifyGuarantorPopupLabels();
        // Click Add Guarantor PopUp Close button
        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        // #region click primary guarantor dropdown and select add_new_guarantor value from the dropdown list
        createCase.clickPrimaryGuarantorDropdown();
        createCase.selectPrimaryGuarantorDropdownValue();
        createCase.selectAddGuarantor(
          td_case_creation_259978.PatientCase[0].GuarantorDetails
        );

        // #endregion

        cy.cGroupAsStep(
          'Verifying the labels and Entering the values for Secondary Guarantor'
        );

        // #region For the Second Guarantor toggle the button to Yes
        createCase.selectYesOrNoButton(YesOrNo.yes);
        // Click Secondary Guarantor DropDown and select self value from the dropdown list
        createCase.selectSecondaryGuarantorDropdownValue(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DROPDOWN_VALUES.SELF
        );
        createCase.verifySecondaryGuarantorFields();
        // #endregion
        createCase.clickCaseCross();
        createCase.clickLossData();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        create2ndCase.clickCreateACaseTab();
        create2ndCase.createNewPatient(
          create2ndCase.patientCaseModel!.PatientDetails
        );
        create2ndCase.createCase();
      });
    });
  }

  editCase() {
    describe('Verify the radio button and insurance fields are enabled or disabled for the edit functionality', () => {
      it('Verify the insurance coverage popup window labels for the edit functionality', () => {
        // #region check for the insurance carrier label
        cy.reload();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          create2ndCase.patientCaseModel!.PatientDetails.PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        create2ndCase.verifyPatientDetails();
        create2ndCase.verifyCheckMarkPatientDetails();
        create2ndCase.clickPatientDetails();
        create2ndCase.clickInsuranceAddButton();
        create2ndCase.verifyTitlesIconsInsuranceModel();
        // Click on cancel and verify it should close the add insurance coverage pop-up
        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        // #region Verify the lengthy names in the insurance coverage pop labels for the edit functionality
        create2ndCase.clickInsuranceAddButton();
        create2ndCase.clickAndSelectInsuranceCarrierDropdown(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        create2ndCase.clickSelectRelationshipToSubscriberDropdown(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        create2ndCase.enterSubscriberID(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );
        create2ndCase.verifyInsuranceDone();
        create2ndCase.clickInsuranceDoneButton();

        create2ndCase.verifyInsuranceDataTable();
        create2ndCase.verifyInsuranceNameInTable(
          td_case_creation_259978.PatientCase[0].CaseDetails
            .InsuranceCoverage[0]
        );

        // Verify the bubble above the patient page title will check off as complete
        create2ndCase.verifyCheckMarkPatientDetails();
        create2ndCase.clickCaseCross();
        create2ndCase.clickLossData();
        // #endregion
      });
    });
  }
}
