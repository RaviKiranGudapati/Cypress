import { Application } from '../../../../../../support/common-core-libs/application/common-core';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { td_case_cdtcode_tcid_260018 } from '../../../../../../fixtures/sis-office/case/create/case-cdtcode-tcid-260018.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import CasesToCode from '../../../../../../app-modules-libs/sis-office/trackers/cases-to-code';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import FacesheetChargeEntry from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const nursingConfig = new NursingConfiguration();
const createCase = new CreateCase(td_case_cdtcode_tcid_260018.PatientCase);
const casesToCode = new CasesToCode(createCase.patientCaseModel!);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const facesheetChargeEntry = new FacesheetChargeEntry();
const faceSheetCases = new FaceSheetCases();
const nursingConfigurationLayout = new NursingConfigurationLayout();

export class SisOfficeCDTCodeTcId260018 {
  verifyCDTCodeDisableFeature() {
    describe('To verify the CDT Code state in Enterprise Configuration', () => {
      it('Verify the CDT feature as disable mode by default under features tab in Enterprise Configuration page', () => {
        // #region To check the CDT Code as disable mode in feature tab and logout from enterprise application

        cy.cGroupAsStep(
          'Verify CDT feature as disable mode by default under feature tab in Enterprise Configuration page'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        /** Select the Application Setting option from user menu dropdown */
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        /** To select the add on feature option from application settings */
        nursingConfigurationLayout.selectAddOnFeaturesConfiguration();

        /** To verify the cdt code feature state */
        nursingConfigurationLayout.verifyCDTCode(true);

        /**To click on the sis logo  */
        sisOfficeDesktop.selectSisLogo();

        /**To logout from the application */
        sisOfficeDesktop.logout();
        // #endregion
      });
    });
  }

  verifyCDTCodeNoSearchResults() {
    describe('To verify CDT search results not appeared as CDT Feature disable mode in SIS Office', () => {
      it('Verify CDT codes not displayed in Fee Schedule - Configuration and Case Details page under Create Case', () => {
        // #region verifying the no search results displayed in fee schedule as CDT feature is disable in enterprise

        cy.cGroupAsStep(
          'As CDT feature is disable mode,Verify the CDT codes not displayed when user enter the CDT code in Fee Schedule - Configuration page'
        );
        /** Login into SIS Office application*/
        const login = new SISCompleteLogin();
        login.login(
          UserList.GEM_USER_3[0],
          UserList.GEM_USER_3[1],
          OrganizationList.GEM_ORG_3
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        /** Select the Application Setting option from user menu dropdown */
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        /** To verify no data when search with CDT Code while adding the CDT Code in Fee Schedule page */
        nursingConfig.verifyCDTSearchResults(
          td_case_cdtcode_tcid_260018.FeeScheduleInfo
        );

        /** To click on SIS Logo for navigating to business desktop page */
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        cy.cGroupAsStep(
          'As CDT feature is disable mode,Verify the CDT code not displayed when user enter the CDT code in Case Details page under create case'
        );

        /** Click on Create Case Tab */
        createCase.clickCreateACaseTab();

        /** Click on Create New Patient slide out in schedule grid page and Enter the Patient Details*/
        createCase.createNewPatient(
          td_case_cdtcode_tcid_260018.PatientDetailsInfo[0]
        );

        /** Verify the no search results when enter the CDT code in procedure field in Case Details page*/
        createCase.verifyCDTCode(td_case_cdtcode_tcid_260018.CptCodeInfo[0]);
        sisOfficeDesktop.selectSisLogo();

        /** Logout from SIS Office application */
        /**
         * @Issue: Due to logout and login to PPE, API is not working and we have tried with the cy reload after logout and still not worked
         * @Resolution: we are moving to old logout
         */
        sisOfficeDesktop.logout();
        // #endregion
      });
    });
  }

  VerifyCDTCodeEnableFeature() {
    describe('To verify the CDT feature state in Facility Management - Enterprise Configuration', () => {
      it('Verify the CDT feature as enable mode under features tab in Facility Management - Enterprise Configuration', () => {
        // #region verifying the cdt code enable mode under feature tab in Enterprise configuration page

        cy.cGroupAsStep(
          'Verifying CDT feature as enable mode in other organization under feature tab in Facility Management - Enterprise Configuration'
        );
        /*Launch the SIS Office application **/
        const userLogin: UserLogin = {
          UserName: UserList.SIS_ADMIN[0],
          Password: UserList.SIS_ADMIN[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_7, userLogin);

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        /** Select the Application Setting option from user menu dropdown */
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        /** To select the add on feature option from application settings */
        nursingConfigurationLayout.selectAddOnFeaturesConfiguration();

        /** To verify the cdt code feature state */
        nursingConfigurationLayout.verifyCDTCode(false);

        /**To click on the sis logo  */
        sisOfficeDesktop.selectSisLogo();

        /**To logout from the application */
        cy.cLogOut();
        // #endregion
      });
    });
  }

  verifyCDTCodeSearchResults() {
    describe('To verify CDT Code Search Results as CDT feature enable mode in SIS Office ', () => {
      it('Verify the CDT Code search results in Fee Schedule, Case Details, Case To Code, Charge Entry and My Task- Charge Entry pages', () => {
        // #region verifying the cdt code search results in fee schedule, case details, case to code, charge entry and my tasks-charge entry.

        cy.cGroupAsStep(
          'As CDT feature is enable mode, Verify and Add the CDT codes in Fee Schedule - Configuration'
        );
        /** Login into application with valid credentials */

        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_7[0],
          Password: UserList.GEM_USER_7[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_7, userLogin);

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        /** Select the Application Settings from user menu dropdown */
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        /** To verify data when search with CDT Code while adding the CDT Code in Fee Schedule page */
        nursingConfig.verifyCDTSearchResults(
          td_case_cdtcode_tcid_260018.FeeScheduleInfo
        );

        /** Click on Add button and add the CDT codes in Fee Schedule page */
        nursingConfig.addCDTCode(td_case_cdtcode_tcid_260018.FeeScheduleInfo);

        /** Click on SIS Logo icon to navigate to business desktop page */
        sisOfficeDesktop.selectSisLogo();

        cy.cGroupAsStep(
          'As CDT feature is enable mode, Verify the CDT codes in Case Details under Create Case'
        );

        /** Click on Schedule Grid tab */
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        /**Click on Create Case Tab */
        createCase.clickCreateACaseTab();

        /** Click on Create Case slide out and enter patient details in Case Details popup */
        createCase.createNewPatient(
          td_case_cdtcode_tcid_260018.PatientDetailsInfo[1]
        );

        /** Verify the CDT Search results in Case Details page */
        createCase.verifyCDTCode(td_case_cdtcode_tcid_260018.CptCodeInfo[1]);

        cy.cGroupAsStep(
          'As CDT feature is enable mode, Verify and Add the CDT codes in Case To Code page'
        );

        /**Click on Add Procedure button and Verify the CDT Code */
        casesToCode.addProcedureCaseToCode(
          td_case_cdtcode_tcid_260018.CptCodeInfo[2]
        );

        /** Select the Diagnosis Code and Make it as Ready for charge  */
        casesToCode.selectDiagnosisCode(
          td_case_cdtcode_tcid_260018.CasesToCodeDetails
        );

        cy.cGroupAsStep(
          'As CDT feature is enable mode, Verify and Add the CDT codes in charge entry page'
        );

        /** Click on schedule grid in tracker after removing the mask wrapper */
        cy.cRemoveMaskWrapper(Application.office);

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectSisLogo();

        /** Select the charge entry option from tracker */
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );

        /** Select the case period and batch from charge entry tracer */
        chargeEntry.selectCase(td_case_cdtcode_tcid_260018.ChargeDetails);

        /** Click on Add Procedure and Verify the CDT code and Make it as Ready for bill */
        chargeEntry.addProcedure(td_case_cdtcode_tcid_260018.CptCodeInfo[3]);
        chargeEntry.clickOnChargeCollapse(2);
        chargeEntry.clickReadyForBillAndDoneButton(true);

        cy.cGroupAsStep(
          'As CDT feature is enable mode, Verify and Add the CDT codes in FaceSheet - Charge Entry'
        );

        /*************Navigating to Schedule Grid *********************/
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        /*************Search and select the patient from global search *********************/
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );

        /*************Selecting Charge Entry *********************/
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);

        /** Verify the CDT Code in procedure search results and Adding the CDT Code  */
        facesheetChargeEntry.addProcedure(
          td_case_cdtcode_tcid_260018.CptCodeInfo[4]
        );
        facesheetChargeEntry.clickUpdateButton();
        // #endregion
      });
    });
  }
}
