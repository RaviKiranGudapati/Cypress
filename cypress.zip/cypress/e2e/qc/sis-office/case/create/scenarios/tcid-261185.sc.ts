import { ExpandOrCollapse } from '../../../../../../support/common-core-libs/application/common-core';
import { transactionalAPIs } from '../../../../../../support/common-core-libs/application/transactional-apis';

import { td_patient_lockmessage_tcid_261185 } from '../../../../../../fixtures/sis-office/case/create/case-lockmessage-tcid-261185.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import PatientDetailsTab from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';

/* instance variables */
const patientDetailsTab = new PatientDetailsTab();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase(
  td_patient_lockmessage_tcid_261185.patientCase
);
const faceSheetCases = new FaceSheetCases(createCase.patientCaseModel!);
const sisOfficeDesktop = new SISOfficeDesktop();

/* const values */
const patient =
  td_patient_lockmessage_tcid_261185.patientCase.PatientDetails.LastName +
  `, ` +
  td_patient_lockmessage_tcid_261185.patientCase.PatientDetails
    .PatientFirstName;
const dosStartDate = '2022-11-30';
const dosEndDate = '2022-12-02';

export class PatientLockMessageTcId261185 {
  verifyPatientLockMessage() {
    describe(' verify lock message by using different users in Edit, checkin, facesheet ', () => {
      it('verify patient search and lockmessage for different users ', () => {
        // Verify that the Add button. (New Patient button) should not be visible as the User2 do not have Demographics checkpoint Create permission

        cy.cGroupAsStep(
          'verify the create case  and Add new patient button should  not be available'
        );

        // #region - search patient and verify create case button is not available
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        createCase.verifyCreateCaseNotVisible();
        // #endregion

        cy.cGroupAsStep(
          'Verify that user should not able to update patient details'
        );

        //  Verify that the User should NOT be able to update the Patient  details
        // #region -select the patient and verify that user should not able to update patient details

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        patientDetailsTab.clickOnPatientDetailsTab();
        patientDetailsTab.editFirstNameInPatientDetailsTabViewOnly(
          td_patient_lockmessage_tcid_261185.patientCase.PatientDetails.LastName
        );
        patientDetailsTab.clickOnCasesTab();
        patientDetailsTab.clickOnPatientDetailsTab();

        patientDetailsTab.verifyPatientNameInPatientDetailsTab(
          td_patient_lockmessage_tcid_261185.patientCase.PatientDetails
            .PatientFirstName
        );
        sisOfficeDesktop.logout();
        // #endregion

        // Login to user 1 and click on edit icon in case details popup

        cy.cGroupAsStep(
          'Login to user and click on edit icon in case details popup'
        );

        /** Login into SIS Office application*/
        // const userLogin1: UserLogin = {
        //   userName: UserList.GEM_USER_3[0],
        //   password: UserList.GEM_USER_3[1],
        // };
        // cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin1);

        const login = new SISCompleteLogin();
        login.login(
          UserList.GEM_USER_3[0],
          UserList.GEM_USER_3[1],
          OrganizationList.GEM_ORG_3
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        transactionalAPIs
          .API_Login(
            UserList.GEM_USER_3[0],
            UserList.GEM_USER_3[1],
            OrganizationList.GEM_ORG_3
          )
          .then(() => {
            transactionalAPIs
              .API_GetPatientCaseDOS(
                td_patient_lockmessage_tcid_261185.patientCase.PatientDetails
                  .PatientFirstName,
                td_patient_lockmessage_tcid_261185.patientCase.PatientDetails
                  .LastName,
                dosStartDate,
                dosEndDate
              )
              .then(($response) => {
                sisOfficeDesktop.selectDateFromScheduleGrid(
                  $response.toString()
                );
              });
          });
        cy.reload();

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase.clickPreviousInCaseDetails();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        // Login to user3 and select the patient in Schedule grid
        /** Login into SIS Office application*/
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_4[0],
          Password: UserList.GEM_USER_4[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        cy.cGroupAsStep(
          'Select the patient and click on edit icon and verify the lockmessage in patient details and billing detials '
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );

        // #region - verify the patient lockmessage in Edit icon
        createCase.clickPreviousInCaseDetails();
        createCase.verifyPatientLockMessage(UserList.GEM_USER_3[0]);
        createCase.clickOnBillingDetails();
        createCase.verifyPatientLockMessage(UserList.GEM_USER_3[0]);
        // #endregion

        cy.cGroupAsStep(
          'Select the patient and click on checkin and verify the lockmessage in patient details and Billing & payment screen '
        );

        //  Select the patient in Schedule grid and click on check-in icon
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );

        // #region- verify the patient lockmessage in Check-in icon

        // Verify the patient lockmessage in patient details
        createCase.verifyPatientLockMessage(UserList.GEM_USER_3[0]);

        // Verify the patient lockmessage in Billing & payment screen
        createCase.selectBillingAndPayment();

        createCase.verifyPatientLockMessage(UserList.GEM_USER_3[0]);
        // #endregion

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        cy.cGroupAsStep(
          'Select the patient and click on Facesheet and verify the lockmessage in patient details tab, payer details and Financial clearance'
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        // #region- verify the patient lockmessage in Facesheet icon

        // Verify the patient lockmessage in Patient details tab
        patientDetailsTab.clickOnPatientDetailsTab();
        patientDetailsTab.waitForPdToLoad();
        createCase.verifyPatientLockMessage(UserList.GEM_USER_3[0]);

        // Verify the patient lockmessage in Payer details option
        patientDetailsTab.clickOnCasesTab();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );
        patientDetailsTab.verifyLockMessageInFacesheetOptions(
          UserList.GEM_USER_3[0]
        );

        // Verify the patient lockmessage in Financial Clearance option
        patientDetailsTab.selectLockedFinancialClearance();
        patientDetailsTab.verifyLockMessageInFacesheetOptions(
          UserList.GEM_USER_3[0]
        );
        // #endregion
      });
    });
  }
}
