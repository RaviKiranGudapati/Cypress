import { td_verifying_done_button_tcid_75538 } from '../../../../../../fixtures/sis-office/case/create/case-done-button-tcid-75538.td';

import { AppColors } from '../../../../../../support/common-core-libs/application/constants/app-colors.constants';

import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import { PrimaryGuarantorCheckIn } from '../../../../../../app-modules-libs/sis-office/case-creation/enums/create-case.enum';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';

/* instance variables */
const createCase = new CreateCase(
  td_verifying_done_button_tcid_75538.PatientCase
);
const scheduleGrid = new ScheduleGrid();
const patient =
  td_verifying_done_button_tcid_75538.PatientCase.PatientDetails.LastName +
  `, ` +
  td_verifying_done_button_tcid_75538.PatientCase.PatientDetails
    .PatientFirstName;

export class VerifyingDoneButtonTcId75538 {
  verifyDoneButtonState(color: string, isEnable: boolean = true) {
    createCase.verifyDoneButtonStateInFooter(isEnable);
    createCase.verifyTheColorOfDoneButtonInFooter(color);
  }

  verifyDoneButtonStateInCheckIn(color: string, isEnable: boolean = true) {
    createCase.verifyDoneButtonStateInFooterInCheckIn(isEnable);
    createCase.verifyColorOfDoneButtonInFooterInCheckIn(color);
  }

  verifyDoneButtonEnabledEnteringAllMandatoryFields() {
    describe('Verify the done button upon entering all mandatory fields', () => {
      it('Done Button is enabled during case creation and patient check in', () => {
        cy.cGroupAsStep(
          `Verify the done button to be enabled during case creation`
        );
        // #region - Create New Patient, Enter the Mandatory fields Patient Details

        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          td_verifying_done_button_tcid_75538.PatientCase.PatientDetails
        );
        // Removed cWait as using apis
        createCase.selectGender(
          td_verifying_done_button_tcid_75538.PatientCase.PatientDetails.Gender
        );
        // #endregion

        // #region - Click on Case Details Tab, Enter the Mandatory fields in Case Details
        createCase.clickOnCaseDetailsTab();
        createCase.enterCaseDetails(
          td_verifying_done_button_tcid_75538.PatientCase.CaseDetails
        );
        // #endregion

        // #region - Click on Billing Details Tab, verify the state of done button and click on it
        createCase.clickOnBillingDetailsTab();
        this.verifyDoneButtonState(
          AppColors.component_enabled_toggle_button_selected
        );
        createCase.clickDoneFooterButton();
        // #endregion

        cy.cGroupAsStep(`Verify the done button to be enabled in check in`);
        // #region - CheckIn the created patient, add primary guarantor in Billing & Payments
        
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();
        createCase.selectPrimaryGuarantor(
          td_verifying_done_button_tcid_75538.AddGuarantor,
          PrimaryGuarantorCheckIn.PrimaryGuarantor
        );
        // #endregion

        // #region - Verify the done button is enabled and click on it
        this.verifyDoneButtonStateInCheckIn(
          AppColors.component_enabled_toggle_button_selected
        );
        createCase.clickCheckInDone();
        // #endregion
      });
    });
  }

  verifyDoneButtonDisabledNotEnteringMandatoryFields() {
    describe('Verify the done button upon not entering mandatory fields', () => {
      it('Done Button is disabled during case creation and patient check in', () => {
        cy.cGroupAsStep(
          `Verify the done button to be disable during case creation`
        );
        // #region - Create New Patient, verify the state and color of done button, close the tab without creating case

        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          td_verifying_done_button_tcid_75538.PatientCase.Patient1Details
        );
        this.verifyDoneButtonState(AppColors.component_disabled_button, false);
        createCase.clickOnCaseDetailsTab();
        this.verifyDoneButtonState(AppColors.component_disabled_button, false);
        createCase.clickOnBillingDetailsTab();
        this.verifyDoneButtonState(AppColors.component_disabled_button, false);
        createCase.crossIconInMyTasksYesOrNo();
        // #endregion

        cy.cGroupAsStep(`Verify the done button to be disable in check in`);
        // #region - CheckIn the created case, remove the DOB in patient details, verify the state of done button
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.clickOnPatientDetailsTabInCheckIn();
        createCase.enterDobInPatientDetailsInCheckIn('  ');
        createCase.clickOnDobTextInPatientDetailsInCheckIn();
        this.verifyDoneButtonStateInCheckIn(
          AppColors.component_disabled_button,
          false
        );
        // #endregion

        // #region - Click on Forms & Consents, verify the Done button state is disabled
        createCase.clickOnFormsAndConsentsTabInCheckIn();
        this.verifyDoneButtonStateInCheckIn(
          AppColors.component_disabled_button,
          false
        );
        // #endregion

        // #region - Click on Attachments, verify the Done button state is disabled
        createCase.clickOnAttachmentsTabInCheckIn();
        this.verifyDoneButtonStateInCheckIn(
          AppColors.component_disabled_button,
          false
        );
        // #endregion

        // #region - Click on Billing & Payments, verify the Done button state is disabled
        createCase.selectBillingAndPayment();
        this.verifyDoneButtonStateInCheckIn(
          AppColors.component_disabled_button,
          false
        );
        // #endregion

        // #region - re-enter the DOb in patient details tab and click on done button
        createCase.clickOnPatientDetailsTabInCheckIn();
        createCase.enterDobInPatientDetailsInCheckIn(
          td_verifying_done_button_tcid_75538.PatientCase.PatientDetails.DOB
        );
        createCase.clickOnDobTextInPatientDetailsInCheckIn();
        createCase.clickCheckInDone();
        // #endregion

        cy.cGroupAsStep(
          `Verify the case details tab open upon editing the patient`
        );
        // #region - edit the patient from schedule grid and verify case details tab is open by default

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.EDIT_ICON[0]
        );
        createCase.verifyCaseDetailsTabIsHighlighted(
          AppColors.component_tick_mark_selected
        );
        // #endregion
      });
    });
  }
}
