import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import sisExchangeLogin from '../../../../../app-modules-libs/sis-exchange/login/login';

import { PpeCaseEquipmentTcId260005 } from '../../../sis-exchange/appointment-request/scenarios/tcid-260005.sc';
import { CaseEquipmentTcId260005 } from './scenarios/tcid-260005.sc';

/* instance variables */
const ppeCaseEquipment = new PpeCaseEquipmentTcId260005();
const caseEquipment = new CaseEquipmentTcId260005();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to SIS Exchange and create an appointment request and Logout
 * 2. Login to SIS Office, select appointment from case requests and update case
 * 3. Select case from schedule grid and click edit
 * 4. Add Preference with procedures, verify and click on Done
 * 5. Edit Case and add preference card with equipments, verify Equipment overbooked warning
 * 6. Verify deletion of equipment and adding duplicate equipment
 * 7. Verify deletion of Preference Card
 * 8. Logout from application
 */

describe(
  'Verify addition, updation, deletion of equipments for a case & adding preference cards with equipments for a case',
  { tags: ['case-create', 'TC#260005'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      Cypress.on('uncaught:exception', (error, runnable) => {
        return false;
      });
      /****Open the URL as defined in baseUrl in Cypress Configuration File Or CLI flag - --config baseUrl ********/
      cy.visit(Cypress.env('ppeURL'));
      /**********Login To PPE Application***********/
      const ppeLogin = new sisExchangeLogin();
      ppeLogin.login(
        UserList.GEM_USER_1[0],
        UserList.GEM_USER_1[1],
        OrganizationList.GEM_ORG_1
      );
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        ppeCaseEquipment.createCaseFromSisExchange();
        caseEquipment.updatePpeCaseFromCaseRequests();
        caseEquipment.verifyAddPreferenceCardInCreateCase();
        caseEquipment.verifyDeletePreferenceCardAndEquipment();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
