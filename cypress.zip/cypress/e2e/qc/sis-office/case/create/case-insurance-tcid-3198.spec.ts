import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { CaseInsuranceTcId3198 } from './scenarios/tcid-3198.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/*instance variables*/
const caseInsurance = new CaseInsuranceTcId3198();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to office application with user1.
 * 2. Select the case by using case name.
 * 3. Click on Add button in Insurance Coverage section.
 * 4. verify the label names, dropdown values, place holder values in Insurance popup
 * 5. Clearing the values correctly when entered the incorrect data and loss the focus in Date fields in Insurance popup.
 * 6. Login into application with user2.
 * 7. Verify the case details as disable in Insurance popup.
 * 8. Login into application with user1
 * 9. Enter all the details and verify the done button enable/disable modes
 * 10. Click on Done button and Insurance added to case and popup closed correctly.
 * 11. logout from the SIS office application.
 */

describe(
  'Verify the labels,placeholders,dropdown values in Add Insurance Coverage popup in Create Case',
  { tags: ['case-create', 'tcid#3198', 'US#260242'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_2[0],
        Password: UserList.GEM_USER_2[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        caseInsurance.verifyDataInInsuranceCoveragePopup();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
