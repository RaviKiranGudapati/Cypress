import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { ScheduleGridTcId264773 } from './scenarios/tcid-264773.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const caseCreationScenario = new ScheduleGridTcId264773();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
1. Login into application and navigate to Schedule grid.
2. Create a case and verify the new Sex, Gender Identity, Pronouns, Preferred Name fields under create case-patient details sections along with tool tips message .
3. Navigate to face sheet-patient details and verify the new Sex, Gender Identity, Pronouns, Preferred Name fields with tool tip message.
4. Face sheet-Edit, modified above mentioned fields and check the modified data under face sheet-patient details.
5. Logout from application
 */

describe(
  'Verifying Sex, Gender Identity, Pronouns, Preferred Name fields in Patient details of create case and face sheet',
  { tags: ['case-create', 'TC#264773', 'US#189158'] },
  () => {
    // Before suite
    before('Launching Web Application', function () {
      // Login To Application

      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {}
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        caseCreationScenario.patientDetailsGenderIdentityUI();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => {}
    );
  }
);
