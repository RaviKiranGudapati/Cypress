import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { PatientLockMessageTcId261185 } from './scenarios/tcid-261185.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/*instance variables*/
const patientLockMessage = new PatientLockMessageTcId261185();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 *  1. Login  to application with user 1 and select the patient
 *  2. verify the Facesheet is displayed and logout from application
 *  3. Login with user 2 and search for patient  and try to click on create case
 *  4. Verify that the Add button. (New Patient button) should not be visible as the User2 do not have Demographics checkpoint Create permission
 *  5. Verify that the User should NOT be able to update the Patient  details
 *  6. Login to application with user 3 and select the same case which is being edited by User1
 *  7. verify Patient lock message  should be displayed and in patient details
 *  8. Logout from application
 */

describe(
  'Verify patient search and patient lock message for different users',
  { tags: ['case-lockmessage', 'case-create', 'US#260248', 'TC#261185'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USERVONLY[0],
        Password: UserList.GEM_USERVONLY[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        // Verify patient search and patient lock message for different users
        patientLockMessage.verifyPatientLockMessage();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
