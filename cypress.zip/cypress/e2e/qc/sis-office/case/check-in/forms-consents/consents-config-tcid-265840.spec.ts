import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import SISPhysicianDesktop from '../../../../../../app-modules-libs/sis-charts/physician/physician-desktop';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

import { SISOfficeConsentsTcId265840 } from './scenarios/tcid-265840.sc';
import { NursingConsentsTcId265840 } from '../../../../sis-charts/case/consents/scenarios/tcid-265840.sc';
import { AnesthesiaConsentsTcId265840 } from '../../../../sis-anesthesia/scenarios/tcid-265840.sc';
import { PhysicianConsentsTcId265840 } from '../../../../sis-physician/my-tasks/consents/scenarios/tcid-265840.sc';

/* instance variables */
const sisPhysicianDesktop = new SISPhysicianDesktop();
const sisOfficeCaseConsents = new SISOfficeConsentsTcId265840();
const anesthesiaCaseConsents = new AnesthesiaConsentsTcId265840();
const nursingConsents = new NursingConsentsTcId265840();
const physicianConsents = new PhysicianConsentsTcId265840();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation, consent template creation with consents
 * 1. Login to application
 * 2. Verify the primary procedure and procedure display in configuration for consents.
 * 3. Verify procedures based on configuration in nursing, anesthesia, physician and in facesheet check-in
 * */

describe(
  'Verify primary procedure and procedure display in consents configuration and procedures data in consents popup when consents configuration setting in default mode',
  {
    tags: ['case-consents', 'TC#265840', 'US#253014'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_21[0],
        Password: UserList.GEM_USER_21[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_21, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisPhysicianDesktop.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        sisOfficeCaseConsents.verifyConsentsPrimaryProcedures();
        nursingConsents.verifyConsentsModifiedProcedureDesc();
        sisOfficeCaseConsents.verifyModifiedProcedureInFormsAndConsents();
        anesthesiaCaseConsents.verifyConsentsModifiedProcedure();
        physicianConsents.verifyPhysicianConsentsModifiedProcedures();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
