import { CommonUtils } from '../../../../../../../support/common-core-libs/framework/common-utils';
import { YesOrNo } from '../../../../../../../support/common-core-libs/application/common-core';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { td_consents_procedure_sc265842 } from '../../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-procedure-tcid-265842.td';

import { FaceSheetOptions } from '../../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CaseConsents from '../../../../../../../app-modules-libs/sis-office/case-check-in/case-consents';
import FaceSheetCases from '../../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import SISOfficeDesktop from '../../../../../../../support/common-core-libs/application/sis-office-desktop';

/*instance variables*/
const sisOfficeDesktop = new SISOfficeDesktop();
const caseConsents = new CaseConsents();
const faceSheetCases = new FaceSheetCases();

export class SISOfficeConsentsTcId265842 {
  verifyCPTDescInFormsAndConsents() {
    describe('To verify cpt and description under procedure section within the consents popup in business desktop', () => {
      it('Verify cpt and description under procedure text area in the consents popup', () => {
        // #region verify cpt and description under procedure section in the consents popup

        cy.cGroupAsStep(
          'Verify the cpt and description inside of procedure section in forms and consents in business desktop'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_consents_procedure_sc265842.PatientCase[0].PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.FORMS_AND_CONSENTS
        );

        caseConsents.clickConsentNameInList(
          td_consents_procedure_sc265842.ConsentsModel[0].ConsentName
        );

        sisOfficeDesktop.verifyProceduresInConsents(
          CommonUtils.concatenate(
            td_consents_procedure_sc265842.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_procedure_sc265842.ConsentsModel[0].Procedures![1]
          )
        );

        caseConsents.closeConsentWindow();
        caseConsents.closeConsentWindowConfirm(YesOrNo.yes);

        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyModifiedDescriptionInFormsAndConsents() {
    describe('To verify modified procedure description under procedure section within the consents popup in business desktop', () => {
      it('Verify modified procedure description under procedure text area ', () => {
        // #region verify modified procedure under procedure section in the consents popup
        cy.cGroupAsStep(
          'Verify the modified procedure inside of procedure section in forms and consents in business desktop'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_consents_procedure_sc265842.PatientCase[1].PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.FORMS_AND_CONSENTS
        );

        caseConsents.clickConsentNameInList(
          td_consents_procedure_sc265842.ConsentsModel[1].ConsentName
        );

        sisOfficeDesktop.verifyProceduresInConsents(
          td_consents_procedure_sc265842.ConsentsModel[1].Procedures![0]
        );

        caseConsents.closeConsentWindow();
        caseConsents.closeConsentWindowConfirm(YesOrNo.yes);

        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
