import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import SISPhysicianDesktop from '../../../../../../app-modules-libs/sis-charts/physician/physician-desktop';
import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

import { AnesthesiaConsentsTcId265841 } from '../../../../sis-anesthesia/scenarios/tcid-265841.sc';
import { PhysicianConsentsTcId265841 } from '../../../../sis-physician/my-tasks/consents/scenarios/tcid-265841.sc';
import { SISOfficeConsentsTcId265841 } from './scenarios/tcid-265841.sc';
import { NursingConsentsTcId265841 } from '../../../../sis-charts/case/consents/scenarios/tcid-265841.sc';

/* instance variables */
const sisOfficeCaseConsents = new SISOfficeConsentsTcId265841();
const anesthesiaCaseConsents = new AnesthesiaConsentsTcId265841();
const nursingConsents = new NursingConsentsTcId265841();
const physicianConsents = new PhysicianConsentsTcId265841();
const sisPhysicianDesktop = new SISPhysicianDesktop();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation, consent template creation with consents
 * 1. Login to application
 * 2. Change the procedure display and primary procedure to enable in consents application settings.
 * 3. Verify procedures based on configuration in nursing, anesthesia, physician and in facesheet checkin
 * */

describe(
  'Verify the cpt and modified procedure descriptions in consents popup based on the consents configuration',
  {
    tags: ['case-consents', 'TC#265841', 'US#253014'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_22[0],
        Password: UserList.GEM_USER_22[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_22, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisPhysicianDesktop.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        nursingConsents.verifyModifiedPrimaryProcedure();
        anesthesiaCaseConsents.verifyModifiedProcDescOfPrimaryProc();
        nursingConsents.verifyCPTPrimaryProcDesc();
        nursingConsents.verifyConsentsModifiedPrimaryProcedure();
        nursingConsents.verifyLateralityOfPrimaryProc();
        sisOfficeCaseConsents.verifyModifiedProcInFormsAndConsents();
        physicianConsents.verifyModifiedPrimaryProcedure();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
