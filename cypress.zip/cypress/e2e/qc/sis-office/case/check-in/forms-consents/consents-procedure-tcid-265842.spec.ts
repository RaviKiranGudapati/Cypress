import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import SISPhysicianDesktop from '../../../../../../app-modules-libs/sis-charts/physician/physician-desktop';

import { NursingConsentsTcId265842 } from '../../../../sis-charts/case/consents/scenarios/tcid-265842.sc';
import { SISOfficeConsentsTcId265842 } from './scenarios/tcid-265842.sc';
import { AnesthesiaConsentsTcId265842 } from '../../../../sis-anesthesia/tcid-265842.sc';
import { PhysicianConsentsTcId265842 } from '../../../../sis-physician/my-tasks/consents/scenarios/tcid-265842.sc';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';

/* instance variables */
const sisOfficeCaseConsents = new SISOfficeConsentsTcId265842();
const anesthesiaCaseConsents = new AnesthesiaConsentsTcId265842();
const nursingConsents = new NursingConsentsTcId265842();
const physicianConsents = new PhysicianConsentsTcId265842();
const sisPhysicianDesktop = new SISPhysicianDesktop();
const loginPage = new SISCompleteLogin();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation, consent template creation with consents
 * 1. Login to application
 * 2. Change the procedure display and primary procedure to disable in consents application settings.
 * 3. Verify procedures based on configuration in nursing, anesthesia, physician and in facesheet checkin
 * */

describe(
  'Verify cpt description and modified procedure description within the consents popup based on consents configuration settings',
  {
    tags: ['case-consents', 'TC#265842', 'US#253014'],
  },
  () => {
    before(`Launching Web Application`, function () {
      // const userLogin: UserLogin = {
      //   UserName: UserList.GEM_USER_9[0],
      //   Password: UserList.GEM_USER_9[1],
      // };
      // cy.cSetSession(OrganizationList.GEM_ORG_9, userLogin);

      Cypress.on('uncaught:exception', (error, runnable) => {
        return false;
      });
      /****Open the URL as defined in baseUrl in Cypress Configuration File Or CLI flag - --config baseUrl ********/
      cy.visit('/');
      /**********Login To Application***********/
      loginPage.login(
        UserList.GEM_USER_9[0],
        UserList.GEM_USER_9[1],
        OrganizationList.GEM_ORG_9
      );
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisPhysicianDesktop.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        nursingConsents.verifyCPTDescOnlyInConsents();
        sisOfficeCaseConsents.verifyCPTDescInFormsAndConsents();
        anesthesiaCaseConsents.verifyCPTDescInConsents();
        physicianConsents.verifyCPTDescInConsents();
        nursingConsents.verifyModifiedProcedureDescInConsents();
        sisOfficeCaseConsents.verifyModifiedDescriptionInFormsAndConsents();
        anesthesiaCaseConsents.verifyModifiedProcedureDescInConsents();
        physicianConsents.verifyModifiedProcedureDescInConsents();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
