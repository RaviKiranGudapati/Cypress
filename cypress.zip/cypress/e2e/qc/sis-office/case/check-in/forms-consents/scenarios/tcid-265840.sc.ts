import { CommonUtils } from '../../../../../../../support/common-core-libs/framework/common-utils';
import {
  Application,
  YesOrNo,
} from '../../../../../../../support/common-core-libs/application/common-core';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';

import { td_consents_config_sc265840 } from '../../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-config-tcid-265840.td';

import { FaceSheetOptions } from '../../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CaseConsents from '../../../../../../../app-modules-libs/sis-office/case-check-in/case-consents';
import FaceSheetCases from '../../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import CreateCase from '../../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import NursingConfigurationLayout from '../../../../../../../support/common-core-libs/application/application-settings';
import NursingConfiguration from '../../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import { CasesDetailsFaceSheet } from '../../../../../../../app-modules-libs/sis-office/facesheet/facesheet-case-details';
import SISOfficeDesktop from '../../../../../../../support/common-core-libs/application/sis-office-desktop';

/*instance variables*/
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfig = new NursingConfiguration();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const caseConsents = new CaseConsents();
const createCase = new CreateCase();
const faceSheetCases = new FaceSheetCases();
const casesDetailsFaceSheet = new CasesDetailsFaceSheet();

export class SISOfficeConsentsTcId265840 {
  verifyConsentsPrimaryProcedures() {
    describe('To verify primary procedure and procedure display in consents configuration and to clear modified procedure', () => {
      it('Verify primary procedure label and procedure display dropdown values and clearing modified procedure for cases ', () => {
        // #region To verify the primary procedure and procedure display dropdown option in consents configuration

        cy.cGroupAsStep(
          'To verify primary procedure and procedure display dropdown option in consents configuration'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.CONSENTS[0]
        );
        cy.cRemoveMaskWrapper(Application.office);

        /**To verify Procedure Display Label and Dropdown Values */
        nursingConfig.verifyProcedureDisplayAndDropdownValues(
          td_consents_config_sc265840.ConsentsModel[0]
        );
        cy.cRemoveMaskWrapper(Application.charts);

        nursingConfig.clickProcedureDisplayDropdown();

        /**To Check the Single Select Dropdown */
        nursingConfig.verifySingleSelectDropDown();

        /**To verify the Primary Procedure Only Label */
        nursingConfig.verifyPrimaryProcedureOnly();

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        cy.cGroupAsStep(
          'Clearing the modified procedure description for procedures'
        );

        /** To Clear the Modified Description For Case3 */
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_consents_config_sc265840.PatientCase[2].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);

        createCase.clearModifiedProcedureDescription(
          td_consents_config_sc265840.PatientCase[2].CaseDetails.CptCodeInfo[0]
        );
        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        /** To Clear the Modified Description For Case4 */
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_consents_config_sc265840.PatientCase[3].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);
        createCase.clearModifiedProcedureDescription(
          td_consents_config_sc265840.PatientCase[3].CaseDetails.CptCodeInfo[1]
        );
        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        // #endregion
      });
    });
  }

  verifyModifiedProcedureInFormsAndConsents() {
    describe('To verify the modified procedure data in consents popup in business desktop', () => {
      it('Verify the all procedures data based on the case selection in consents popup in business desktop', () => {
        // #region To verify all procedures in facesheet consents

        cy.cGroupAsStep(
          'Verify all procedure data under procedure section in facesheet consents'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_consents_config_sc265840.PatientCase[3].PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.FORMS_AND_CONSENTS
        );

        caseConsents.clickConsentNameInList(
          td_consents_config_sc265840.ConsentsModel[1].ConsentName
        );

        sisOfficeDesktop.verifyProceduresInConsents(
          CommonUtils.concatenate(
            td_consents_config_sc265840.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_config_sc265840.ConsentsModel[0].Procedures![3]
          )
        );
        caseConsents.closeConsentWindow();
        caseConsents.closeConsentWindowConfirm(YesOrNo.yes);
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
