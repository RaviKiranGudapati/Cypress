import { YesOrNo } from '../../../../../../../support/common-core-libs/application/common-core';
import {
  CommonUtils,
  DateFormats,
} from '../../../../../../../support/common-core-libs/framework/common-utils';
import { transactionalAPIs } from '../../../../../../../support/common-core-libs/application/transactional-apis';

import {
  Consents,
  PatientCase,
} from '../../../../../../../test-data-models/sis-office/case/patient-case.model';

import { td_consents_sc260007 } from '../../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-tcid-260007.td';
import { OrganizationList } from '../../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../../fixtures/shared/user-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import { OR_SCHEDULE_GRID } from '../../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import SISOfficeDesktop from '../../../../../../../support/common-core-libs/application/sis-office-desktop';
import CaseConsents from '../../../../../../../app-modules-libs/sis-office/case-check-in/case-consents';
import CreateCase from '../../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import { CaseConsentsHeader } from '../../../../../../../app-modules-libs/sis-office/case-check-in/enums/case-consents.enum';

/* instance variables */
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();
const caseConsents = new CaseConsents();
const createCase = new CreateCase(td_consents_sc260007.PatientCase);

/* const values */
const number500 = 500;

export class ConsentsTcId260007 {
  editConsentDetailsTemplate(consentDetailsTemplate: Consents) {
    let editConsentText = '',
      num = 0;
    consentDetailsTemplate.EditConsentDescription?.forEach(
      (consentDescription) => {
        editConsentText =
          ' ' + consentDetailsTemplate.ConsentName + consentDescription;
        caseConsents.enterEditConsentText(editConsentText, num);
        caseConsents.closeConsentWindow();
        caseConsents.verifyWarningMessage();
        caseConsents.closeConsentWindowConfirm(YesOrNo.no);
        caseConsents.signCaseConsent(num);
        num++;
      }
    );
    sisOfficeDesktop.clickDoneButton();
  }

  patientCheckIn(patientDetails: PatientCase) {
    describe(' Patient check in from schedule grid for performing edit consents in Forms & Consents tab ', () => {
      it(' Update Address1 and Zip code to patient details for edit consents ', () => {
        // #region - Select patient from schedule grid , fill patient details after check in

        cy.cGroupAsStep(
          'Patient check in from schedule grid to perform edit consents in forms & consents'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        transactionalAPIs
          .API_Login(
            UserList.GEM_USER_4[0],
            UserList.GEM_USER_4[1],
            OrganizationList.GEM_ORG_4
          )
          .then(() => {
            transactionalAPIs
              .API_GetPatientCaseDOS(
                td_consents_sc260007.PatientCase.PatientDetails
                  .PatientFirstName,
                td_consents_sc260007.PatientCase.PatientDetails.LastName,
                CommonUtils.getBeforeDate_yyyymmdd(
                  number500,
                  DateFormats.hyphen
                ),
                CommonUtils.getTodayDate_yyyymmdd(DateFormats.hyphen)
              )
              .then(($response) => {
                sisOfficeDesktop.selectDateFromScheduleGrid(
                  $response.toString()
                );
              });
          });

        cy.reload();

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        scheduleGrid.verifyRoomInScheduleGrid();
        scheduleGrid.selectRoomInScheduleGrid(
          td_consents_sc260007.PatientCase.CaseDetails.OperatingRoom
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_consents_sc260007.PatientCase.PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );

        createCase.enterInputText(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .ADDRESS1[1],
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .ADDRESS1[1],
          patientDetails.PatientDetails.Address1!
        );

        createCase.enterInputText(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .ZIP_CODE[1],
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.PATIENT_DETAILS
            .ZIP_CODE[1],
          patientDetails.PatientDetails.ZipCode!
        );

        caseConsents.checkInNext();
        // #endregion
      });
    });
  }

  updateConsents() {
    describe(' Navigate to Forms & Consents tab from schedule grid ', () => {
      it(' Select consents template from case consents to perform edit ', () => {
        // #region - Search and edit consents

        td_consents_sc260007.ConsentsModel.forEach((consentDetails) => {
          cy.cGroupAsStep(
            'Verify Consent ' +
              consentDetails.ConsentName +
              ' exist in the list, edit consent, add addendum signed by physician/other user'
          );

          caseConsents.verifyPrintDeleteIcon(consentDetails.ConsentName);

          caseConsents.selectConsentInPatientCase(consentDetails.ConsentName);
          caseConsents.verifyEditConsent();
          caseConsents.closeConsentWindow();

          caseConsents.verifyWarningMessage();

          caseConsents.closeConsentWindowConfirm(YesOrNo.yes);

          caseConsents.clickConsentNameInList(consentDetails.ConsentName);

          this.editConsentDetailsTemplate(consentDetails);

          caseConsents.addAddendum(
            consentDetails.AddendumConsentDescription[0],
            consentDetails.ConsentName,
            CaseConsentsHeader.addendum_sign
          );

          caseConsents.addAddendum(
            consentDetails.AddendumConsentDescription[1],
            consentDetails.ConsentName,
            CaseConsentsHeader.addendum_other_user
          );
        });

        caseConsents.saveConsents();
        // #endregion
      });
    });
  }
}

export default { ConsentsTcId260007 };
