import { td_consents_physicians_tcid_262596 } from '../../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-physicians-tcid-262596.td';

import { OR_SCHEDULE_GRID } from '../../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import ScheduleGrid from '../../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import SISOfficeDesktop from '../../../../../../../support/common-core-libs/application/sis-office-desktop';
import CaseConsents from '../../../../../../../app-modules-libs/sis-office/case-check-in/case-consents';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const caseConsents = new CaseConsents();

/* const values */
const patient =
  td_consents_physicians_tcid_262596.PatientCase.PatientDetails.LastName +
  `, ` +
  td_consents_physicians_tcid_262596.PatientCase.PatientDetails
    .PatientFirstName;

export class ConsentsTcId262596 {
  updateConsentsPerformingPhysician() {
    describe('Verifying the Performing Physicians saving for Check-in Patient Case in Forms & Consents', () => {
      it('Verify the adding of Performing Physicians by editing consent in CaseConsents', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep(
          'Check-in the Patient Case and Navigate to Forms and Consents'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        caseConsents.checkInNext();
        // #endregion

        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep('Open Consent and add multiple performing physicians');
        caseConsents.selectConsentInPatientCase(
          td_consents_physicians_tcid_262596.Consents[0].ConsentName
        );
        caseConsents.clearPerformingPhysicians();
        caseConsents.selectPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[0]
        );
        sisOfficeDesktop.clickDoneButton();
        caseConsents.clickConsentNameInList(
          td_consents_physicians_tcid_262596.Consents[0].ConsentName
        );
        caseConsents.verifyPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[0]
        );
        sisOfficeDesktop.clickDoneButton();
        caseConsents.saveConsents();
        // #endregion
      });
    });
  }
}
