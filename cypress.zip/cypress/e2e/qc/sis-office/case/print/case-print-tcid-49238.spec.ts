import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { SisChartsScdlGridPrintTcId49238 } from '../../../sis-charts/case/print/scenarios/tcid-49238.sc';
import { SisOfficeScdlGridPrintTcId49238 } from './scenarios/tcid-49238.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const sisOfficeScdlGridPrint = new SisOfficeScdlGridPrintTcId49238();
const sisChartsScdlGridPrint = new SisChartsScdlGridPrintTcId49238();

/* Test Script Validation Details *****
 * Pre-Condition-
 * By default Layout should be Landscape for the logged in users.
 *
 * Script Execution Approach -
 * 1. Verify Print Icon and Print Options in Schedule Grid Preview of SIS Office and SIS Charts
 * 2. Verify Schedule Grid Preview Fields in SIS Office and SIS Charts.
 * 3. Verify the Refresh is enabled when Layout is changed and verify refresh is disabled when clicked on it in SIS Office nad SIS Charts.
 * 4. Verify Layout is Portrait by default and GroupBY as Physician when user logins again with same user
 * 5. Verify Print options in SIS Office and SIS Charts after login with different user
 * 6. Verify Print Options in SIS Office and SIS Charts after changing login Location
 * 7. Verify User2 should not able to access the Print icon whose scheduling view permission not available
 *
 */
describe(
  'Verifying Print Popup presence in Schedule Grid',
  {
    tags: ['case-print', 'US#19050', 'US#138987', 'TC#49238'],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_4[0],
        Password: UserList.GEM_USER_4[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        // 'Verifying Portrait is by default, Physician in GroupBY when user re-login to application in SIS Office and SIS Office'
        sisOfficeScdlGridPrint.verifyScheduleGridPrintPreviewOptions();

        // 'Verifying Portrait is by default, Physician in GroupBY when user re-login to application in SIS Office and SIS Charts'
        sisChartsScdlGridPrint.verifyScheduleGridPrintPreviewOptions();

        // 'Verify Schedule Grid Print Preview options in SIS Office after Changing the Login Location to Gem_Org005'
        sisOfficeScdlGridPrint.verifyPrintPageForAnotherOrg();

        // 'Verify Schedule Grid Print Preview options in SIS Charts after Changing the Login Location to Gem_Org005'
        sisChartsScdlGridPrint.verifyPrintPageForAnotherOrg();

        // 'Verify with user GEM_USERVSNOVCF(without scheduling view permission) should not able to access print Icon'
        sisOfficeScdlGridPrint.verifyNonAccessUser();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
