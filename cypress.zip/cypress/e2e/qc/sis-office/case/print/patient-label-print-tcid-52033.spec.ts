import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { PatientLabelPrintTcId52033 } from './scenarios/tcid-52033.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const patientLabelPrint = new PatientLabelPrintTcId52033();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * VSTS ID – 52033 Gemini-Patient Labels-Preview Page Layout, Load in Cases/Patients for the DOS, Create the Patient Label Printout-WF-User Story-19051,46498,19052,158849
 * 19051 - Patient Labels: Preview Page Layout
 * 19052 - Patient Labels: Create the Patient Label Printout
 * 46498 - Patient Labels: Load in Cases/Patients for the DOS
 * 158849 - Patient Labels: Ability to Configure Label Printing Count and Starting Position

 * Script Execution Approach -
 * 1. Login and verify if any cases available for the day, if not create a patient case
 * 2. Selecting Print Icon in schedule grid
 * 3. Select Patient Labels option and click on Preview
 * 4. Verify the default options and values available in Patient Labels popup
 * 5. Enter Maximum input for #LabelsPerPatient, #BeginRow, #Begin Column and verify the results
 * 6. Enter More than maximum values in #LabelsPerPatient, #BeginRow, #Begin Column and verify the results
 * 7. Click close Icon in print popup
 * 8. Logout from application
 *
 */
describe(
  'Verifying Patient Labels Print Layout',
  {
    tags: [
      'patient-label-print',
      'US#19051',
      'US#46498',
      'US#19052',
      'US#158849',
      'TC#52033',
    ],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_4[0],
        Password: UserList.GEM_USER_4[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        // 'Verify Labels and Default Values in Patient Labels Print Options'
        patientLabelPrint.verifyPatientLabelsAndDefaultValues();

        // 'Enter Max values and more than Max values in Print Options and Verify the Results'
        patientLabelPrint.verifyMaxAndMoreThanMaxPrintOptions();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
