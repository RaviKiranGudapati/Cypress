import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { NotesTcId105234 } from './scenarios/tcid-105234.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

// SHIFT + ALT + O - Organizing the import
/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verifying all the functionality of Revenue Cycle Manager from Application Settings
 * Script Execution Approach -
 * 1. Search for the Patient in Global Search.
 * 2. Navigate to Case Details from Facesheet page.
 * 3. Create and Verify Notes in Case Details.
 * 4. Similarly navigate to all the modules and validate the added Notes:
 *  Case Details, Payer Details, Financial Clearance, Attachments, Forms & Consents
 *  Clinical, Inventory, Coding, Charge Entry, Transactions
 * 5. Logout
 ************************************************************************/

/* instance variables */
const notes = new NotesTcId105234();

describe(
  'Verifying Notes in all the modules of My Tasks for CDM Organization',
  {
    tags: ['facesheet', 'US#264011', 'TC#105234'],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_CDM2, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        notes.createAndVerifyNotesInCaseDetails();
        notes.verifyNotesInMyTasks();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
