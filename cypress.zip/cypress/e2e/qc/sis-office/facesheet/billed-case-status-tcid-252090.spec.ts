import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { FaceSheetTcId252090 } from './scenarios/tcid-252090.sc';

/* instance variables */
const faceSheet = new FaceSheetTcId252090();

/***Test Script Validation Details *****
 * Pre-Condition:
 * 1. Patient1 case is created with 2 procedures and primary Insurance is mapped.
 * 2. Patient2 case is created with 3 procedures and primary Insurance and Primary Guarantor is mapped.
 * 3. Patient3, Patient5 cases are created with 2 procedures and Primary Insurance is mapped.
 * 4. Patient4 case is created with 2 procedures and Primary Guarantor is mapped.
 * 5. Discharge all Patients and perform Cases to code and Charge Entry.
 *
 * Script Execution Approach -
 * 1. Login into application and navigate to FaceSheet Transactions Page and make Charges as system billed  .
 * 2. Verify the Billed Statement count in Patient Statement Tracker.
 * 3. When Charges are system billed, verify the claim Status, Billing History and Last Billed Date.
 * 4. Verify Zero Charges for the case are visible in Insurance Billing Tracker.
 * 5. Logout from application
 */

describe(
  'Verifying the case status, billing history and claim status in facesheet,transaction and ledger pages',
  { tags: ['facesheet', 'TC#252090', 'US#261297', 'US#109642'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        faceSheet.faceSheetCaseStatus();
        faceSheet.faceSheetBilledStatus();
        faceSheet.claimAndBillHistoryStatus();
        faceSheet.verifyZeroChargesAndCaseStatus();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
