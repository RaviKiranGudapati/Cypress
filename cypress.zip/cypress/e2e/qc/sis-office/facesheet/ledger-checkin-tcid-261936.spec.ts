import { UserList } from '../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { LedgerTcId261936 } from './scenarios/tcid-261936.sc';

/* instance variables */
const ledgerFacesheet = new LedgerTcId261936();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into application and navigate to Schedule grid.
 * 2. Search and select from mast head, verify the ledger.
 * 3. Navigate to schedule grid and added amounts, verify the ledger tab.
 * 4. Click on the Content Menu for the Unassigned Payment and view Allocate, Edit, Delete and Correction options.
 * 5. Verify that Edit Unassigned Payment window should be opened, user should be able to view and edit the data.
 * 6. Verify that Unassigned Payment Allocation modal window should display a message as " No Charges are found".(We have not done charge entry for Patient).
 * 7. Verify the ledger data should not display any Unassigned Payment as we have removed the data in the Check-in(Registration) page.
 * 8. Logout from application
 */

describe(
  'Verify Ledger Unassigned payment and Amount collect from check-in',
  { tags: ['facesheet', 'TC#261936', 'US#263222'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_4[0],
        Password: UserList.GEM_USER_4[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        ledgerFacesheet.payerDetailsFacesheet();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
