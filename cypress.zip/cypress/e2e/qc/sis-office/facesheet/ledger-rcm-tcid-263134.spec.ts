import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import LedgerRcmTcId263134 from './scenarios/tcid-263134.sc';

/* instance variables */

const ledgerRcm = new LedgerRcmTcId263134();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation, Guarantor, insurance , charges
 * 1. Login to application with SIS Admin
 * 2. Navigate to application settings,add-on and enable setting Patient Statement Include Insurances CSV Changes
 * 3. Navigate to patient statements in application settings and enable Include Charges and Unassigned Payments due from Insurance
 * 4. Search patient1() in mast head and navigate to facesheet,select ledger,click on billing history
 * 5. Select charges one by one and verify print and bill selected patient functionality
 * 6. Navigate to RCM tracker,select the same patient and verify print,bill selected patient functionality by selecting charges one by one
 * 7. Search patient2() in mast head and navigate to facesheet,select ledger,click on billing history
 * 8. Select the charge , click on print selected navigate to patient statement tracker and veriy if patient is present.
 * 9.Again navigate to billing history,select charge and bill,navigate back to patient statement tracker to check if the patient is still visible
 * */

describe(
  'Verify generate bill check box functionality in Ledger and RCM tracker',
  {
    tags: ['facesheet', 'TC#264051', 'US#263134'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        ledgerRcm.enablingConditions();
        ledgerRcm.verifyLedgerTabFunctionality();
        ledgerRcm.verifyRcmTracker();
        ledgerRcm.verifyPatientStatementTracker();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
