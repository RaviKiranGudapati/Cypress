import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import { TrueOrFalse } from '../../../../../support/common-core-libs/application/common-core';
import { CoreCssClasses } from '../../../../../support/common-core-libs/core-css-classes';

import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { td_facesheet_ledger_tcid_263134 } from '../../../../../fixtures/sis-office/facesheet/ledger-rcm-tcid-263134.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const nursingConfiguration = new NursingConfiguration();
const facesheetTransactions = new Transactions();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase();
const faceSheetCases = new FaceSheetCases();

/* const values */
const right = 'right';

export default class LedgerRcmTcId263134 {
  enablingConditions() {
    describe('Enabling settings in add-on feature and patient statements', () => {
      it('Enabling settings by logging in via Sis admin', () => {
        // #region Enabling settings by logging in via Sis Admin

        cy.cGroupAsStep('Enabling settings by logging in via Sis Admin');
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_EXCHANGE_CONFIGURATION.CONFIG_ADD_ON_FEATURES.ADD_ON_FEATURES[0]
        );

        nursingConfiguration.clickOnIncludeInsurance();

        nursingConfigurationLayout.selectConfiguration(
          OR_EXCHANGE_CONFIGURATION.PATIENT_STATEMENTS[0]
        );

        nursingConfiguration.selectIncludeInsuranceCharges(right);

        cy.cLogOut();
      });
    });

    // #endregion
  }

  verifyLedgerTabFunctionality() {
    describe('Enabling settings by logging in via Sis admin and then verify print and bill functionality in ledger tab using normal user', () => {
      it('verify print and bill functionality in ledger tab', () => {
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_3[0],
          Password: UserList.GEM_USER_3[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);

        // #region Search patient and transfer the charges to primary and secondary guarantors

        cy.cGroupAsStep(
          'Search patient and transfer the charges to primary and secondary guarantors'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_facesheet_ledger_tcid_263134.PatientCase[0].PatientDetails
        );

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        facesheetTransactions.transferCharge(
          td_facesheet_ledger_tcid_263134.Transfers.CptCode[0],
          td_facesheet_ledger_tcid_263134.Transfers.Period,
          td_facesheet_ledger_tcid_263134.Transfers.Batch,
          td_facesheet_ledger_tcid_263134.Transfers.NextResponsibleParty[0],
          td_facesheet_ledger_tcid_263134.Transfers.TransferTransactionCode[0]
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        facesheetTransactions.transferCharge(
          td_facesheet_ledger_tcid_263134.Transfers.CptCode[1],
          td_facesheet_ledger_tcid_263134.Transfers.Period,
          td_facesheet_ledger_tcid_263134.Transfers.Batch,
          td_facesheet_ledger_tcid_263134.Transfers.NextResponsibleParty[0],
          td_facesheet_ledger_tcid_263134.Transfers.TransferTransactionCode[0]
        );

        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        facesheetTransactions.transferCharge(
          td_facesheet_ledger_tcid_263134.Transfers.CptCode[2],
          td_facesheet_ledger_tcid_263134.Transfers.Period,
          td_facesheet_ledger_tcid_263134.Transfers.Batch,
          td_facesheet_ledger_tcid_263134.Transfers.NextResponsibleParty[1],
          td_facesheet_ledger_tcid_263134.Transfers.TransferTransactionCode[1]
        );

        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();

        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        facesheetTransactions.transferCharge(
          td_facesheet_ledger_tcid_263134.Transfers.CptCode[3],
          td_facesheet_ledger_tcid_263134.Transfers.Period,
          td_facesheet_ledger_tcid_263134.Transfers.Batch,
          td_facesheet_ledger_tcid_263134.Transfers.NextResponsibleParty[1],
          td_facesheet_ledger_tcid_263134.Transfers.TransferTransactionCode[1]
        );

        // #endregion

        // #region Check-in both the patients by navigating to schedule grid

        cy.cGroupAsStep(
          'Check-in both the patients by navigating to schedule grid'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_ledger_tcid_263134.PatientCase[0].PatientDetails
            .LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.clickCheckInDone();

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_ledger_tcid_263134.PatientCase[1].PatientDetails
            .LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );

        createCase.clickCheckInDone();

        // #endregion

        // #region Verifying print selected patient statements functionality from ledger tab

        cy.cGroupAsStep(
          'Verifying print selected patient statements functionality from ledger tab'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_facesheet_ledger_tcid_263134.PatientCase[0].PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[0]
        );

        ledgerTabFaceSheet.clickPrintSelectedPatientStatement();
        ledgerTabFaceSheet.verifyPrintPopup();
        ledgerTabFaceSheet.closePrintPopup();
        ledgerTabFaceSheet.closeBillingHistory();
        // #endregion

        // #region Verifying bill selected patient statements functionality from ledger tab

        cy.cGroupAsStep(
          'Verifying bill selected patient statements functionality from ledger tab'
        );
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[1]
        );
        ledgerTabFaceSheet.clickBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement(false);
        ledgerTabFaceSheet.verifyStatementSentDialog();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[1]
        );
        ledgerTabFaceSheet.clickBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyStatementSentDialog();
        ledgerTabFaceSheet.verifyEmailSent(1);
        ledgerTabFaceSheet.verifyBilledCheckbox(1, TrueOrFalse.true);
        // #endregion
      });
    });
  }

  verifyRcmTracker() {
    describe('Verifying generate bill and print statement functionality in RCM tracker ', () => {
      it('Verify print and bill functionality in RCM tracker', () => {
        // #region Verifying print selected patient statements functionality from RCM tracker billing history

        cy.cGroupAsStep(
          'Verifying print selected patient statements functionality from RCM tracker billing history'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );

        cy.cWaitForElementToBeAttached(
          OR_FACESHEET_LEDGER_TAB.WAIT_RESPONSIBLE_PARTY[1],
          OR_FACESHEET_LEDGER_TAB.WAIT_RESPONSIBLE_PARTY[0]
        );

        cy.cGet(CoreCssClasses.Row.loc_p_selectable_row)
          .last()
          .scrollIntoView();

        sisOfficeDesktop.selectPatientRow(
          td_facesheet_ledger_tcid_263134.PatientCase[0].PatientDetails
            .LastName,
          td_facesheet_ledger_tcid_263134.PatientCase[0].PatientDetails.LastName
        );
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[2]
        );
        ledgerTabFaceSheet.clickPrintSelectedPatientStatement();
        ledgerTabFaceSheet.verifyPrintPopup();
        ledgerTabFaceSheet.closePrintPopup();
        ledgerTabFaceSheet.closeBillingHistory();
        // #endregion

        // #region Verifying bill selected patient statements functionality from RCM tracker billing history

        cy.cGroupAsStep(
          'Verifying bill selected patient statements functionality from RCM tracker billing history'
        );
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[3]
        );
        ledgerTabFaceSheet.clickBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement(false);
        ledgerTabFaceSheet.verifyStatementSentDialog();

        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[3]
        );
        ledgerTabFaceSheet.clickBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyStatementSentDialog();
        // #endregion
      });
    });
  }

  verifyPatientStatementTracker() {
    describe('Verifying generate bill and print statement functionality in Patient Statement tracker ', () => {
      it('Verify if patient is present in statement tracker,before and after billing', () => {
        // #region Verifying print selected patient statements functionality from ledger tab for patient2

        cy.cGroupAsStep(
          'Verifying print selected patient statements functionality from ledger tab for patient2'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_facesheet_ledger_tcid_263134.PatientCase[1].PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[0]
        );
        ledgerTabFaceSheet.clickPrintSelectedPatientStatement();
        ledgerTabFaceSheet.verifyPrintPopup();
        ledgerTabFaceSheet.closePrintPopup();
        ledgerTabFaceSheet.closeBillingHistory();

        // #endregion

        // #region Verifying bill selected patient statements functionality from ledger tab

        cy.cGroupAsStep(
          'Verifying bill selected patient statements functionality from ledger tab'
        );
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[0]
        );
        ledgerTabFaceSheet.clickBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement(false);
        ledgerTabFaceSheet.verifyStatementSentDialog();
        // #endregion

        // #region Verifying if patient is present in patient statement tracker before and after billing

        cy.cGroupAsStep(
          'Verifying if patient is present in patient statement tracker before and after billing'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );
        sisOfficeDesktop.verifyTableRow(
          td_facesheet_ledger_tcid_263134.PatientCase[1].PatientDetails
            .LastName,
          td_facesheet_ledger_tcid_263134.PatientCase[1].PatientDetails.LastName
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_facesheet_ledger_tcid_263134.PatientCase[1].PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(
          td_facesheet_ledger_tcid_263134.Transfers.SelectCharge[0]
        );
        ledgerTabFaceSheet.clickBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyStatementSentDialog();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );
        sisOfficeDesktop.verifyTableRow(
          td_facesheet_ledger_tcid_263134.PatientCase[1].PatientDetails
            .LastName,
          td_facesheet_ledger_tcid_263134.PatientCase[1].PatientDetails
            .LastName,
          false
        );
        // #endregion
      });
    });
  }
}
