import { transactionalAPIs } from '../../../../../support/common-core-libs/application/transactional-apis';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  Application,
  ExpandOrCollapse,
} from '../../../../../support/common-core-libs/application/common-core';

import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { td_facesheet_ledger_tcid_261977 } from '../../../../../fixtures/sis-office/facesheet/facesheet-ledger-tcid-261977.td';

import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import PatientDetailsFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';

/*instance variables*/
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_facesheet_ledger_tcid_261977.PatientCase);
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const patientDetailsFacesheet = new PatientDetailsFaceSheet();
const faceSheetCases = new FaceSheetCases(createCase.patientCaseModel!);
const transactions = new Transactions();

/* const values */
const userLogin: UserLogin = {
  UserName: UserList.GEM_USERMNO_FM[0],
  Password: UserList.GEM_USERMNO_FM[1],
};
const charges = 'Charges';
const zero = '0';
const printOptions = ['Chart Consents', 'Diagnostic Summary', 'Patient Ledger'];
const casesPrintOptions = ['Patient Estimate'];

export class FaceSheetLedgerTcId261977 {
  verifyPeriodAndBatchAreLocked() {
    describe('Verify the Warning Message in Unassigned Payment Allocation, Edit Unassigned Payment, Edit Unassigned Payment Allocation', () => {
      it('Verify the Period, Batch and Allocation Amount are locked in Billing and Payments on correction of Allocated Amount', () => {
        cy.cGroupAsStep(
          'Verify the open Period, Batch and Allocation Amount in Billing and Payments on correction of Allocated Amount'
        );

        // #region -- adding Allocated amount in Billing and Payments
        scheduleGrid.selectPatientCase(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails
            .PatientFirstName
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectPatientDetails();
        createCase.addZipCode(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails.ZipCode
        );
        createCase.addAddress1(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails.Address1
        );
        createCase.selectBillingAndPayment();
        createCase.paymentDetails(
          td_facesheet_ledger_tcid_261977.BillingAndPayment
        );
        createCase.selectTransactionCode(
          td_facesheet_ledger_tcid_261977.BillingAndPayment.TransactionCode
        );
        createCase.selectMethodOfPayment(
          td_facesheet_ledger_tcid_261977.BillingAndPayment.MethodOfPayment
        );
        createCase.clickCheckInDone();
        // #endregion

        // #region -- navigate to ledger and correct the allocated amount
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyChargeHeader(charges);
        ledgerTabFaceSheet.clickOnContextMenu(
          td_facesheet_ledger_tcid_261977.BillingAndPayment.TransactionCode,
          OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.CORRECTION[0]
        );
        ledgerTabFaceSheet.unassignedPaymentCorrection(
          td_facesheet_ledger_tcid_261977.UnassignedPaymentCorrection
        );
        // #endregion

        // #region -- verify period, batch and allocated amount id disabled
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();
        createCase.verifyPeriodAndBatchDropdownState(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.CHECK_IN.PAYMENT
            .PERIOD_VERIFY[1]
        );
        createCase.verifyAmountCollected();
        createCase.clickCheckInDone();
        // #endregion

        cy.cGroupAsStep(
          'Verify the Period and Batch closed Warring Message in Unassigned Payment Edit when Period1 and Batch1 is Closed'
        );

        //#region -- verify period is closed, batch is closed warning message in unassignedPaymentEdit
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_ledger_tcid_261977.AddUnassignedPay[0]
        );
        ledgerTabFaceSheet.verifyChargeHeader(charges);
        ledgerTabFaceSheet.clickOnContextMenu(
          td_facesheet_ledger_tcid_261977.BillingAndPayment.TransactionCode,
          OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS.VIEW_EDIT[0]
        );
        transactionalAPIs.API_CloseBatch(
          td_facesheet_ledger_tcid_261977.AddUnassignedPay[0].Period!,
          td_facesheet_ledger_tcid_261977.AddUnassignedPay[0].Batch!
        );
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_ledger_tcid_261977.AddUnassignedPay[1]
        );
        transactions.verifyPeriodAndBatchClosedWarningMsg(
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .PERIOD_IS_CLOSED_WARNING_MESSAGE[1],
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .PERIOD_IS_CLOSED_WARNING_MESSAGE[0],
          AppErrorMessages.period_closed
        );
        transactions.verifyPeriodAndBatchClosedWarningMsg(
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .BATCH_IS_CLOSED_WARNING_MESSAGE[1],
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .BATCH_IS_CLOSED_WARNING_MESSAGE[0],
          AppErrorMessages.batch_closed
        );
        sisOfficeDesktop.clickCloseIcon();
        // #endregion
      });

      it('Verify the Period and Batch closed Warning Message in Allocation when Period2 and and Batch2 is Closed', () => {
        cy.cGroupAsStep(
          'verify Period is closed, Batch is closed warning message in Allocation PopUp'
        );

        ledgerTabFaceSheet.verifyChargeHeader(charges);
        cy.cRemoveMaskWrapper(Application.office);
        ledgerTabFaceSheet.clickOnContextMenu(
          td_facesheet_ledger_tcid_261977.AddUnassignedPay[0].TransactionCode,
          OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
        );
        ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0],
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[0].Period!
        );
        ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0],
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[0].Batch!
        );
        ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0],
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[0]
            .TransactionCode!
        );
        transactionalAPIs.API_CloseBatch(
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[0]
            .Period!,
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[0].Batch!
        );
        ledgerTabFaceSheet.enterAllocationAmount(
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[0]
            .AmountAllocation,
          zero
        );
        ledgerTabFaceSheet.clickOnDone();
        transactions.verifyPeriodAndBatchClosedWarningMsg(
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .PERIOD_IS_CLOSED_WARNING_MESSAGE[1],
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .PERIOD_IS_CLOSED_WARNING_MESSAGE[0],
          AppErrorMessages.period_closed
        );
        transactions.verifyPeriodAndBatchClosedWarningMsg(
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .BATCH_IS_CLOSED_WARNING_MESSAGE[1],
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT
            .BATCH_IS_CLOSED_WARNING_MESSAGE[0],
          AppErrorMessages.batch_closed
        );
        ledgerTabFaceSheet.clickOkButton();
        // #endregion
      });

      it('Verify the Period is closed, Batch is closed Warning message in Transaction and  Allocation Edit when Period3 and Batch3 is Closed', () => {  

        cy.cGroupAsStep(
          'Verify the Period is closed, Batch is closed Warning message in Transaction Allocation Edit when Period3 and Batch3 is Closed'
        );

        // #region -- Allocate unassigned payment
        ledgerTabFaceSheet.verifyChargeHeader(charges);
        ledgerTabFaceSheet.clickOnContextMenu(
          td_facesheet_ledger_tcid_261977.AddUnassignedPay[1].TransactionCode,
          OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
        );
        ledgerTabFaceSheet.unassignedPaymentAllocation(
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[1],
          zero
        );
        // #endregion

        // #region  -- navigate to Transactions and verify close period and batch warning message in allocation edit
        patientDetailsFacesheet.clickOnCasesTab();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        transactions.clickOnTransactionContextMenu(
          0,
          OR_TRANSACTION.CHARGES.ALLOCATION[0]
        );
        transactions.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.PERIOD[0],
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[2].Period
        );
        transactions.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.BATCH[0],
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[2].Batch
        );
        transactionalAPIs.API_CloseBatch(
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[2].Period,
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[2].Batch
        );
        transactions.enterAllocationAmount(
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[2]
            .AmountAllocation,
          '0'
        );
        transactions.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0],
          td_facesheet_ledger_tcid_261977.UnassignedPaymentAllocation[2]
            .TransactionCode
        );
        transactions.clickOnDoneInEditAllocationPopUp();
        transactions.verifyPeriodAndBatchClosedWarningMsg(
          OR_TRANSACTION.UNASSIGNED_PAYMENT.PERIOD_IS_CLOSED_WARNING_MESSAGE[1],
          OR_TRANSACTION.UNASSIGNED_PAYMENT.PERIOD_IS_CLOSED_WARNING_MESSAGE[0],
          AppErrorMessages.period_closed
        );
        transactions.verifyPeriodAndBatchClosedWarningMsg(
          OR_TRANSACTION.UNASSIGNED_PAYMENT.BATCH_IS_CLOSED_WARNING_MESSAGE[1],
          OR_TRANSACTION.UNASSIGNED_PAYMENT.BATCH_IS_CLOSED_WARNING_MESSAGE[0],
          AppErrorMessages.batch_closed
        );
        ledgerTabFaceSheet.clickOkButton();
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.selectPersonIconInMyTasks();
        // #endregion

        cy.cGroupAsStep(
          'Verify print icon and options on clicking it which is on the top right corner'
        );

        // #region Verify print icon and options on clicking it which is on the top right corner
        patientDetailsFacesheet.clickOnCasesTab();
        ledgerTabFaceSheet.verifyPrintIcon();
        ledgerTabFaceSheet.selectPrintIcon();
        ledgerTabFaceSheet.verifyPrintOption(printOptions);
        ledgerTabFaceSheet.verifyPrintPopUpModel();
        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        cy.cGroupAsStep(
          'Verify the preview on the patient estimate on clicking cases print icon'
        );

        // #region Verify the preview on the patient estimate on clicking cases print icon
        ledgerTabFaceSheet.selectPrintIconInCasesTab();
        faceSheetCases.selectOptionsInPrintPopupClickPreview(
          casesPrintOptions[0]
        );
        faceSheetCases.verifyPrintPreviewOpen();
        faceSheetCases.closePrintPreviewModel();
        cy.cLogOut();
        // #endregion
      });

      it('Verify with user that does not have the financial Modify permissions.', () => {
        // #region logging into new user
        cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
        // #endregion

        cy.cGroupAsStep(
          'Verify that user should not be able to edit the Allocation Correction amount '
        );

        // #region Verifying edit access for the user
        scheduleGrid.selectPatientCase(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails
            .PatientFirstName
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_ledger_tcid_261977.PatientCase.PatientDetails
            .PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        transactions.clickOnTransactionContextMenu(
          0,
          OR_TRANSACTION.CHARGES.ALLOCATION[0]
        );
        transactions.verifyEditUpAllocation(true);
        // #endregion
      });
    });
  }
}
