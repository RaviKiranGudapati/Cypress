import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { td_charge_autosort_tcid_264161 } from '../../../../../fixtures/sis-office/facesheet/charge-autosort-tcid-264161.td';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import {
  Application,
  ExpandOrCollapse,
} from '../../../../../support/common-core-libs/application/common-core';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetChargeEntryPage from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';

/* instance variables */
const createCase = new CreateCase(
  td_charge_autosort_tcid_264161.PatientCase[0]
);
const sisOfficeDesktop = new SISOfficeDesktop();
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const faceSheetChargeEntry = new FaceSheetChargeEntryPage();
const faceSheetCases = new FaceSheetCases();

export class MyTaskChargeEntryTcid264161 {
  autoSortFacesheet() {
    describe('Verify auto sort functionality for patient1 in My task charge entry', () => {
      it('Select patient 1 and add supplies or procedures and verify the auto sort functionality ', () => {
        // #region - Verify period and batch for all charges

        cy.cGroupAsStep(
          'Select patient 1 and  select period and batch for charges'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_charge_autosort_tcid_264161.PatientCase[0].PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.assertPerformedItem();
        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          0,
          td_charge_autosort_tcid_264161.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        faceSheetChargeEntry.assertPerformedItem();

        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          1,
          td_charge_autosort_tcid_264161.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        faceSheetChargeEntry.assertPerformedItem();

        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          2,
          td_charge_autosort_tcid_264161.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 3);
        faceSheetChargeEntry.assertPerformedItem();

        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          3,
          td_charge_autosort_tcid_264161.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 3);
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        // #endregion

        // #region - verify the auto sort functionality for charges after adding supplies,write-off, debit and charge amount

        cy.cGroupAsStep(
          'Add supplies, write-off, debit amount and charge amount and verify auto sort functionality'
        );
        faceSheetChargeEntry.verifyReadyForBill();

        faceSheetChargeEntry.addSupplies(
          td_charge_autosort_tcid_264161.CptCodeInfo[0]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_charge_autosort_tcid_264161.CptCodeInfo[0]
        );
        faceSheetChargeEntry.performExpandCollapseForSaving(
          ExpandOrCollapse.collapse,
          4
        );

        faceSheetChargeEntry.verifyOnAutoSortButton();
        faceSheetChargeEntry.clickOnAutoSort();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        faceSheetChargeEntry.verifyReadyForBill();

        faceSheetChargeEntry.autoSort(
          td_charge_autosort_tcid_264161.CptCode[0].CptCode
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        // Entering Amount and then verifying Balance and Amount
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_autosort_tcid_264161.AmountDetails[0].Amount
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.verifyBalanceAndAmount(
          td_charge_autosort_tcid_264161.AmountDetails[0].Amount
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        faceSheetChargeEntry.assertPerformedItem();

        // Entering Amount and then verifying Balance and Amount
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_autosort_tcid_264161.AmountDetails[1].Amount
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        faceSheetChargeEntry.assertPerformedItem();
        faceSheetChargeEntry.verifyBalanceAndAmount(
          td_charge_autosort_tcid_264161.AmountDetails[1].Amount
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.assertPerformedItem();
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_autosort_tcid_264161.AmountProcedures[0].Amount
        );
        faceSheetChargeEntry.enterDebitAmount(
          td_charge_autosort_tcid_264161.AmountProcedures[1].Amount
        );
        faceSheetChargeEntry.clickOnPlus();

        faceSheetChargeEntry.enterWriteoff(
          td_charge_autosort_tcid_264161.AmountProcedures[0].WriteOff
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        faceSheetChargeEntry.clickOnAutoSort();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        faceSheetChargeEntry.verifyReadyForBill();
        faceSheetChargeEntry.autoSort(
          td_charge_autosort_tcid_264161.CptCode[1].CptCode
        );
        // #endregion

        // #region - verify the auto-sort button should be disabled on the Face sheet in charge entry

        cy.cGroupAsStep(
          'Select Ready for Bill to yes in charge entry, verify the auto-sort button should be disabled on the Face sheet in charge entry.'
        );

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(td_charge_autosort_tcid_264161.ChargeDetails);

        chargeEntry.clickOnReadyForBill();
        sisOfficeDesktop.clickDoneButton();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_charge_autosort_tcid_264161.PatientCase[0].PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();
        faceSheetChargeEntry.verifyOnAutoSortButton(false);

        // #endregion
      });
    });
  }

  autoSortChargeEntry() {
    describe('Verify auto sort functionality for patient 2 in  My task charge entry', () => {
      it('Select patient 2 and add supplies or procedures and verify the auto sort functionality ', () => {
        // #region - Verify period and batch for all charges

        cy.cGroupAsStep(
          'Select patient 2 and  select period and batch for charges'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_charge_autosort_tcid_264161.PatientCase[1].PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.assertPerformedItem();
        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          0,
          td_charge_autosort_tcid_264161.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        faceSheetChargeEntry.assertPerformedItem();

        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          1,
          td_charge_autosort_tcid_264161.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        faceSheetChargeEntry.assertPerformedItem();

        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          2,
          td_charge_autosort_tcid_264161.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);

        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        // #endregion

        // #region - verify the auto sort functionality for charges after adding supplies,write-off, debit and charge amount

        cy.cGroupAsStep(
          'Add supplies, write-off, debit amount and charge amount and verify auto sort functionality'
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.enterChargeAmount(
          td_charge_autosort_tcid_264161.AmountProcedures[1].Amount
        );
        faceSheetChargeEntry.enterDebitAmount(
          td_charge_autosort_tcid_264161.AmountProcedures[1].WriteOff
        );
        faceSheetChargeEntry.clickOnPlus();
        faceSheetChargeEntry.enterWriteoff(
          td_charge_autosort_tcid_264161.AmountProcedures[1].WriteOff
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        faceSheetChargeEntry.clickOnAutoSort();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        faceSheetChargeEntry.clickOnAutoSort();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        faceSheetChargeEntry.autoSort(
          td_charge_autosort_tcid_264161.CptCode[2].CptCode
        );
        faceSheetChargeEntry.addSupplies(
          td_charge_autosort_tcid_264161.CptCodeInfo[0]
        );        
        faceSheetChargeEntry.enterHcpcs(
          td_charge_autosort_tcid_264161.CptCodeInfo[0]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_charge_autosort_tcid_264161.CptCodeInfo[0]
        );
        faceSheetChargeEntry.performExpandCollapseForSaving(
          ExpandOrCollapse.collapse,
          3
        );

        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();
        faceSheetChargeEntry.clickOnAutoSort();
        faceSheetChargeEntry.autoSort(
          td_charge_autosort_tcid_264161.CptCode[3].CptCode
        );
        faceSheetChargeEntry.dragAndDropCharges(
          td_charge_autosort_tcid_264161.CptCodeInfo[1].CPTCodeAndDescription,
          td_charge_autosort_tcid_264161.CptCodeInfo[2].CPTCodeAndDescription
        );
        faceSheetChargeEntry.clickOnAutoSort();
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.assertToLoadFaceSheetChargeEntry();

        faceSheetChargeEntry.autoSort(
          td_charge_autosort_tcid_264161.CptCode[3].CptCode
        );
        // #endregion
      });
    });
  }
}
