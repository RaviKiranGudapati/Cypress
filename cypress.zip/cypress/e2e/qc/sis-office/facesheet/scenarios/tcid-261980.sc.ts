import { ExpandOrCollapse } from '../../../../../support/common-core-libs/application/common-core';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { td_facesheet_payment_tcid_261980 } from '../../../../../fixtures/sis-office/facesheet/facesheet-payment-tcid-261980.td';

import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import PatientDetailsFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const patientDetailsFaceSheet = new PatientDetailsFaceSheet();
const createCase = new CreateCase(td_facesheet_payment_tcid_261980.PatientCase);
const faceSheetCases = new FaceSheetCases(createCase.patientCaseModel!);
const transactions = new Transactions();

/* const values */
const Print_options = [
  'Appeal Letters',
  'Case Consents',
  'Op Notes',
  'Implant Log',
  'Patient Demographics Form',
  'Patient Estimate',
  'Patient Labels',
  'Pick List',
  'Block Notes',
];

export class FacsheetPaymentTcId261980 {
  verifyUnallocatedPayment() {
    describe('Verify  allocated and unassigned payment in aging and  copy right information in transaction screen', () => {
      it('Verify that the Unallocated payment should be displayed under for current and different days in Aging bucket', () => {
        // #region - select the patient and verify unassigned  payment

        cy.cGroupAsStep(
          'Select the patient and add unassigned payment in Ledger tab'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_payment_tcid_261980.UnassignedPayment[0]
        );
        // #endregion

        // #region - verify unallocated payment and current payment in show aging

        cy.cGroupAsStep(
          'Click on context menu and Allocate amount and verify unallocted payment and current payment in show aging'
        );

        ledgerTabFaceSheet.selectContextMenu();
        ledgerTabFaceSheet.clickOnAllocate();

        ledgerTabFaceSheet.amountAllocation(
          td_facesheet_payment_tcid_261980.UnassignedAllocated[0]
            .AmountAllocation,
          td_facesheet_payment_tcid_261980.UnassignedAllocated[0].CPT
        );
        ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
            .COLUMN_FOUR_TRANSACTION_CODE[0],
          td_facesheet_payment_tcid_261980.UnassignedAllocated[0]
            .TransactionCode
        );
        ledgerTabFaceSheet.clickOnAllocateUnassignedPaymentDone();
        patientDetailsFaceSheet.clickOnCasesTab();
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnShowAging();
        ledgerTabFaceSheet.verifyAmountsInAging(
          td_facesheet_payment_tcid_261980.ShowAgingData[0].AgingLabels!,
          td_facesheet_payment_tcid_261980.ShowAgingData[0].AccountData!
        );
        // #endregion

        // #region - verify CPT and Code in payment popup in transaction
        cy.cGroupAsStep(
          'Select payment in Transaction and verify CPT and Code in payment screen'
        );

        patientDetailsFaceSheet.clickOnCasesTab();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOptionBaseCptDescription(
          FaceSheetOptions.TRANSACTIONS,
          td_facesheet_payment_tcid_261980.UnassignedPayment[0].Case
        );
        transactions.selectCPTCode(
          td_facesheet_payment_tcid_261980.CptCodeInfo.CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );

        transactions.paymentsPopupPostTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[0]
        );
        transactions.clickDoneInPayment();
        transactions.clickOnTransactionContextMenu(
          1,
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[0]
            .CopyRight
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[1]
            .CopyRight
        );
        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        // #region - verify CPT and Code in write-off popup in transaction

        cy.cGroupAsStep(
          'Select write-off in Transaction and verify CPT and Code in payment screen'
        );

        transactions.selectCPTCode(
          td_facesheet_payment_tcid_261980.CptCodeInfo.CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );

        transactions.writeoffPopupPostTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.WriteOffInfo
        );
        transactions.clickOnTransactionContextMenu(
          3,
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[0]
            .CopyRight
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[1]
            .CopyRight
        );
        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        // #region - verify CPT and Code in debit popup in transaction

        cy.cGroupAsStep(
          'Select debit in Transaction and verify CPT and Code in payment screen'
        );

        transactions.selectCPTCode(
          td_facesheet_payment_tcid_261980.CptCodeInfo.CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );
        transactions.debitPopupPostTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.DebitInfo
        );
        transactions.clickOnTransactionContextMenu(
          4,
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[0]
            .CopyRight
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[1]
            .CopyRight
        );
        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        // #region - verify CPT and Code in transfers popup in transaction

        cy.cGroupAsStep(
          'select transfers in Transaction and verify CPT and Code in transaction screen'
        );

        transactions.selectCPTCode(
          td_facesheet_payment_tcid_261980.CptCodeInfo.CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.TRANSFERS[0]
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[0]
            .CopyRight
        );
        transactions.verifyCopyRightTextInTransaction(
          td_facesheet_payment_tcid_261980.CaseTransaction.PaymentInfo[1]
            .CopyRight
        );

        sisOfficeDesktop.clickCloseIcon();
        // #endregion
      });
    });
  }

  verifyTotalAmountInAging() {
    describe('Verify unassigned amount  in aging bucket and total amount as document for unassigned payment for each case', () => {
      it('Verify the Total Balance  for all cases as document for Unallocated payment for each case', () => {
        // #region - verify allocated amount and total amount for 5 different cases

        cy.cGroupAsStep(
          'Added unassigned payment for case 2 and verify unallocated amount and total amount'
        );

        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_payment_tcid_261980.UnassignedPayment[1]
        );

        ledgerTabFaceSheet.clickOnShowAging();
        ledgerTabFaceSheet.verifyAmountsInAging(
          td_facesheet_payment_tcid_261980.ShowAgingData[0].AgingLabels!,
          td_facesheet_payment_tcid_261980.ShowAgingData[1].AccountData!
        );

        cy.cGroupAsStep(
          'Added unassigned payment for case 3 and verify unallocated amount and total amount'
        );

        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_payment_tcid_261980.UnassignedPayment[2]
        );

        ledgerTabFaceSheet.clickOnHideAging();
        ledgerTabFaceSheet.clickOnShowAging();
        ledgerTabFaceSheet.verifyAmountsInAging(
          td_facesheet_payment_tcid_261980.ShowAgingData[0].AgingLabels!,
          td_facesheet_payment_tcid_261980.ShowAgingData[2].AccountData!
        );

        cy.cGroupAsStep(
          'Added unassigned payment for case 4 and verify unallocated amount and total amount'
        );

        ledgerTabFaceSheet.clickOnAddButton();

        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_payment_tcid_261980.UnassignedPayment[3]
        );
        ledgerTabFaceSheet.clickOnHideAging();
        ledgerTabFaceSheet.clickOnShowAging();
        ledgerTabFaceSheet.verifyAmountsInAging(
          td_facesheet_payment_tcid_261980.ShowAgingData[0].AgingLabels!,
          td_facesheet_payment_tcid_261980.ShowAgingData[3].AccountData!
        );

        cy.cGroupAsStep(
          'Added unassigned payment for case 5 and verify unallocated amount and total amount'
        );

        ledgerTabFaceSheet.clickOnAddButton();

        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_payment_tcid_261980.UnassignedPayment[4]
        );
        ledgerTabFaceSheet.clickOnHideAging();
        ledgerTabFaceSheet.clickOnShowAging();
        ledgerTabFaceSheet.verifyAmountsInAging(
          td_facesheet_payment_tcid_261980.ShowAgingData[0].AgingLabels!,
          td_facesheet_payment_tcid_261980.ShowAgingData[4].AccountData!
        );
        // #endregion
      });
    });
  }

  verifyContextMenuNotVisible() {
    describe('Verify the options in print icon in cases tab and Verify view Allocate or Edit options are not displayed for the Unallocated Payments context menu.', () => {
      it('Verify print icon option and view Allocate or Edit options are not displayed for unallocated  paymentin cotext menu ', () => {
        // #region -Verify options not avalible in context menu

        cy.cGroupAsStep(
          'View Allocate or Edit options are not displayed for unallocated  payment in context menu'
        );

        patientDetailsFaceSheet.clickOnCasesTab();
        ledgerTabFaceSheet.selectPrintIconInCasesTab();

        ledgerTabFaceSheet.verifyPrintOption(Print_options);

        sisOfficeDesktop.clickCloseIcon();

        ledgerTabFaceSheet.clickOnPrintIconInMasthead();
        ledgerTabFaceSheet.verifyChartConsentInPrint(
          td_facesheet_payment_tcid_261980.PrintIcon.Option
        );
        sisOfficeDesktop.clickCloseIcon();
        cy.cLogOut();

        /**********Login To Application***********/
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USERMNO_FM[0],
          Password: UserList.GEM_USERMNO_FM[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_7, userLogin);

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );

        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.selectContextMenu(false);
        // #endregion
      });
    });
  }
}
