import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { td_charge_entry_tcid_266007 } from '../../../../../fixtures/sis-office/facesheet/facesheet-charge-entry-tcid-266007.td';

import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import FaceSheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';

import {
  ExpandOrCollapse,
  HierarchyOptions,
  ProcedureType,
} from '../../../../../support/common-core-libs/application/common-core';
import NursingConfiguration from '../../../../../app-modules-libs/shared/application-settings/nursing-configuration';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const chargeEntry = new ChargeEntry(td_charge_entry_tcid_266007.PatientCase);
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const faceSheetCases = new FaceSheetCases();

export class FaceSheetChargeEntryTcId266007 {
  verifyCharges() {
    describe('Verify Charges are posted with contracts in my tasks charge entry', () => {
      it('Verify Charges are posted with contracts in my tasks charge entry', () => {
        // #region - Selecting procedure type from application settings contracts

        cy.cGroupAsStep(
          'Selecting procedure type from application settings contracts'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfigurationOption(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.CONTRACTS[0],
          true
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_266007.Contract[0]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_266007.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_266007.PatientCase.CaseDetails.CptCodeInfo[1]
            .CPTCodeAndDescription
        );
        // Removed the unncessary step because the procedure type is already selected
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_266007.Contract[1]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_266007.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.no_write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_266007.PatientCase.CaseDetails.CptCodeInfo[1]
            .CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.no_write_off
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_266007.Contract[2]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_266007.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_266007.PatientCase.CaseDetails.CptCodeInfo[1]
            .CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.grouper
        );

        // #endregion

        // #region - Selecting patient from Masthead and verify writeoff and balance of procedure

        cy.cGroupAsStep(
          'Selecting patient from Masthead and verify writeoff and balance of procedure in charge entry'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_charge_entry_tcid_266007.PatientCase.PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.validateWriteOff(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.WriteOff!
        );
        faceSheetChargeEntry.verifyBalance(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.Balance!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        // #endregion

        // #region - Add procedure and verifying writeoff and balance in charge entry

        cy.cGroupAsStep(
          'Add procedure and verifying writeoff and balance in charge entry'
        );
        faceSheetChargeEntry.addProcedure(
          td_charge_entry_tcid_266007.CptDetails[1]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.validateWriteOff(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.WriteOff!
        );
        faceSheetChargeEntry.verifyBalance(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.Balance!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        //To correct the latency added verifyReadyForBill
        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.removeInsurance(HierarchyOptions.primary);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.addInsurance(
          HierarchyOptions.primary,
          td_charge_entry_tcid_266007.PatientCase.PatientDetails
            .InsuranceCoverage[1].InsuranceCarrier
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.verifyAmount(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.Amount!,
          0
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.removeInsurance(HierarchyOptions.primary);
        chargeEntry.addInsurance(
          HierarchyOptions.primary,
          td_charge_entry_tcid_266007.PatientCase.PatientDetails
            .InsuranceCoverage[2].InsuranceCarrier
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.verifyAmount(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.Amount!,
          0
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Adding and verifying modifier by dragging and dropping the procedure in charge entry

        cy.cGroupAsStep(
          'Adding and verifying modifier by dragging and dropping the procedure in charge entry'
        );

        faceSheetChargeEntry.dragAndDropCharges(
          td_charge_entry_tcid_266007.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription,
          td_charge_entry_tcid_266007.CptDetails[1].CPTCodeAndDescription
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        faceSheetChargeEntry.verifyPerformItems();
        faceSheetChargeEntry.enterModifierDropdownSearchBar(
          td_charge_entry_tcid_266007.ChargeDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        faceSheetChargeEntry.verifyModifier(
          td_charge_entry_tcid_266007.ChargeDetails.Modifier
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        // #endregion

        // #region - Verifying the Amount in charge entry by adding procedure

        cy.cGroupAsStep(
          'Adding procedure and verifying the Amount in charge entry'
        );
        faceSheetChargeEntry.addProcedure(
          td_charge_entry_tcid_266007.CptDetails[2]
        );
        faceSheetChargeEntry.verifyAmount(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.Amount!,
          3
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 3);
        faceSheetChargeEntry.addProcedure(
          td_charge_entry_tcid_266007.CptDetails[0]
        );
        faceSheetChargeEntry.verifyAmount(
          td_charge_entry_tcid_266007.FacesheetChargeDetails.Amount!,
          4
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 4);

        // #endregion

        // #region - Expanding procedure and updating unit value and verifying Amount updated

        cy.cGroupAsStep(
          'Expanding procedure and updating unit value and verifying Amount updated'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        faceSheetChargeEntry.updateUnit(
          td_charge_entry_tcid_266007.ChargeDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        faceSheetChargeEntry.verifyAmount(
          td_charge_entry_tcid_266007.ChargeDetails.Amount,
          2
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);

        // #endregion
      });
    });
  }
}
