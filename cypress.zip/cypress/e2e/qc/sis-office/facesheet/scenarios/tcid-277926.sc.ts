import { td_ledger_checkin_tcid_277926 } from '../../../../../fixtures/sis-office/facesheet/unallocated-amount-checkin-ledger-tcid-277926.td';

import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase(td_ledger_checkin_tcid_277926.PatientCase);
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const numzero = '0';

export class LedgerCheckInTcId277926 {
  unAllocatedAmount() {
    describe('Verify the Ledger Unassigned payment and that Amounts added from check-in of Billing & Payments', () => {
      it('Verify the ledger unallocated amount for the unassigned payment added from check-in', () => {
        // #region - Navigate to patient check-in screen and update amount collected

        cy.cGroupAsStep(
          'Navigate to patient check-in screen and update amount collected'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ledger_checkin_tcid_277926.PatientCase.PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.addAddress1(
          td_ledger_checkin_tcid_277926.PatientCase.PatientDetails.Address1
        );
        createCase.addZipCode(
          td_ledger_checkin_tcid_277926.PatientCase.PatientDetails.ZipCode
        );
        createCase.selectBillingAndPayment();
        createCase.paymentDetails(td_ledger_checkin_tcid_277926.AmountDue[0]);
        createCase.clickCheckInDone();

        // #endregion

        // #region - Navigate to Ledger screen and allocate the amount to a charge

        cy.cGroupAsStep(
          'Navigate to Ledger screen and allocate the amount to a charge'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyAmountUP(
          td_ledger_checkin_tcid_277926.UnassignedPay[0]
        );
        ledgerTabFaceSheet.verifyReceivedFromUP(
          td_ledger_checkin_tcid_277926.UnassignedPay[0]
        );
        ledgerTabFaceSheet.selectContextMenu();
        ledgerTabFaceSheet.clickOnAllocate();
        ledgerTabFaceSheet.unassignedPaymentAllocation(
          td_ledger_checkin_tcid_277926.UnAssignedAllocation,
          numzero
        );

        // #endregion

        // #region - Navigate to check in screen and update transaction code

        cy.cGroupAsStep(
          'Navigate to check in screen and update transaction code'
        );

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ledger_checkin_tcid_277926.PatientCase.PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();
        createCase.selectTransactionCode(
          td_ledger_checkin_tcid_277926.AmountDue[0].TransactionCode
        );
        createCase.clickCheckInDone();

        // #endregion

        // #region - Navigate to Facesheet Ledger and verify unallocated amount

        cy.cGroupAsStep(
          'Navigate to Facesheet Ledger and verify unallocated amount'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyUnAllocatedAmount(
          td_ledger_checkin_tcid_277926.AmountDue[0].TransactionCode,
          td_ledger_checkin_tcid_277926.AmountDue[1].AmountDue.toString()
        );

        //#endregion
      });
    });
  }
}
