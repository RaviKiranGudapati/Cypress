import { YesOrNo } from '../../../../../support/common-core-libs/application/common-core';

import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { td_ledger_checkin_tcid_261936 } from '../../../../../fixtures/sis-office/facesheet/ledger-checkin-tcid-261936.td';

import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';
import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import SISCompleteLogin from '../../../../../app-modules-libs/sis-office/login/login';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase(td_ledger_checkin_tcid_261936.PatientCase);
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const loginPage = new SISCompleteLogin();

/* const values */
const charges = 'Charges';

export class LedgerTcId261936 {
  payerDetailsFacesheet() {
    describe('Verify the Ledger Unassigned payment and that Amounts added from check-in of Billing & Payments', () => {
      it('Creating the case adding amounts and verify the added data in ledger Unassigned Payments.', () => {
        // #region creating the case and adding amounts in check-in of Billing & Payments

        cy.cGroupAsStep('create a patient from the schedule grid');

        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        createCase.createCase();

        cy.cGroupAsStep(
          'Search and select the patient from global search list'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );

        cy.cGroupAsStep('Select the Payer Details option from facesheet');
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyNoCharge();
        sisOfficeDesktop.selectSisLogo();

        cy.cGroupAsStep(
          'Select patient and click check-in and navigate to Billing & Payment'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ledger_checkin_tcid_261936.PatientCase.PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        // cy.cWait(SubRoutes.release_lock, WaitMethods.post);
        createCase.addAddress1(
          td_ledger_checkin_tcid_261936.PatientCase.PatientDetails.Address1
        );
        createCase.addZipCode(
          td_ledger_checkin_tcid_261936.PatientCase.PatientDetails.ZipCode
        );
        createCase.selectBillingAndPayment();

        cy.cGroupAsStep('Enter the amounts inBilling & Payment');
        createCase.paymentDetails(
          td_ledger_checkin_tcid_261936.AmountDueDetails[0]
        );
        createCase.selectMethodOfPayment(
          td_ledger_checkin_tcid_261936.AmountDueDetails[0].MethodOfPayment
        );
        createCase.selectTransactionCode(
          td_ledger_checkin_tcid_261936.AmountDueDetails[0].TransactionCode
        );

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();
        // #endregion

        // #region Navigating to ledger and verify the amounts added are displaying in the ledger unassigned payment

        cy.cGroupAsStep(
          'Navigating to the ledger and Verify the table headears of unassigned payment'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyLabelsUnassignedPayments();
        ledgerTabFaceSheet.verifyDOSUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[0]
        );
        ledgerTabFaceSheet.verifyTransactionDateUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[0]
        );
        ledgerTabFaceSheet.verifyPhysicianUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[0]
        );
        ledgerTabFaceSheet.verifyTransactionCodeUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[0]
        );
        ledgerTabFaceSheet.verifyAmountUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[0]
        );
        ledgerTabFaceSheet.verifyReceivedFromUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[0]
        );
        ledgerTabFaceSheet.verifyAmountUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[0]
        );
        ledgerTabFaceSheet.verifyChargeHeader(charges);

        cy.cGroupAsStep(
          'Click on the context mention and verify the option text of the menu'
        );
        ledgerTabFaceSheet.selectContextMenu();
        ledgerTabFaceSheet.verifyOptionLabelsUnassignedPayments();

        cy.cGroupAsStep(
          'Verify and click on edit button and updated the amount'
        );
        ledgerTabFaceSheet.clickViewEdit();
        ledgerTabFaceSheet.enterAmountCollected(
          td_ledger_checkin_tcid_261936.UnassignPayment[1]
        );
        ledgerTabFaceSheet.paymentSelectDropdownValue(
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.PERIOD[0],
          td_ledger_checkin_tcid_261936.UnassignPayment[1].Period
        );
        ledgerTabFaceSheet.paymentSelectDropdownValue(
          OR_FACESHEET_LEDGER_TAB.UNASSIGNED_PAYMENT.BATCH[0],
          td_ledger_checkin_tcid_261936.UnassignPayment[1].Batch
        );
        ledgerTabFaceSheet.clickOnAddUnassignedPaymentDone();

        cy.cGroupAsStep(
          'Select patient and click check-in navigate to Billing & Payment verify edited amount in checkin'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ledger_checkin_tcid_261936.PatientCase.PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        // cy.cWait(SubRoutes.release_lock, WaitMethods.post);
        createCase.selectBillingAndPayment();
        ledgerTabFaceSheet.verifyAmountCollected(
          td_ledger_checkin_tcid_261936.UnassignPayment[1]
        );
        createCase.clickCaseCross();
        createCase.clickLossData();
        // #endregion
      });

      it('Verify that Amount Collected field should be blank as we have deleted the Unassigned Payment in the ledger screen.', () => {
        // #region Verify that Amount Collected field should be blank as we have deleted the Unassigned Payment in the ledger screen.

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.selectContextMenu();
        ledgerTabFaceSheet.clickDelete();
        ledgerTabFaceSheet.clickConfirm(YesOrNo.yes);
        ledgerTabFaceSheet.verifyNoUnassignedPayment();
        sisOfficeDesktop.selectSisLogo();

        cy.cGroupAsStep(
          'Select patient and click check-in and navigate to Billing & Payment and adding the amount'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ledger_checkin_tcid_261936.PatientCase.PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();

        cy.cGroupAsStep('Enter the amounts in Billing & Payment');
        createCase.paymentDetails(
          td_ledger_checkin_tcid_261936.AmountDueDetails[1]
        );
        createCase.selectMethodOfPayment(
          td_ledger_checkin_tcid_261936.AmountDueDetails[1].MethodOfPayment
        );
        createCase.selectTransactionCode(
          td_ledger_checkin_tcid_261936.AmountDueDetails[1].TransactionCode
        );

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyAmountUP(
          td_ledger_checkin_tcid_261936.UnassignPayment[2]
        );

        cy.cGroupAsStep(
          'Click on the context mention and verify the option text of the menu'
        );
        ledgerTabFaceSheet.selectContextMenu();
        ledgerTabFaceSheet.clickOnAllocate();
        ledgerTabFaceSheet.verifyNoCharge();
        sisOfficeDesktop.clickCloseIcon();
        // #endregion
      });

      it('Verify that amount should not display any Unassigned Payment in the ledger tab as we have removed the data in the Check-in page.', () => {
        // #region Verify that amount should not display any Unassigned Payment in the ledger tab as we have removed the data in the Check-in page.

        cy.cGroupAsStep(
          'Select patient and click check-in and navigate to Billing & Payment and adding the amount'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ledger_checkin_tcid_261936.PatientCase.PatientDetails.LastName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();

        cy.cGroupAsStep('Enter the amounts in Billing & Payment');
        createCase.clearAmountDueCollected();

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyNoUnassignedPayment();
        // #endregion
      });

      it('Verify that the Ledger tab should be disabled as the user does not have View access for Financial.', () => {
        // #region Verify that the Ledger tab should be disabled as the user does not have View access for Financial.

        cy.cGroupAsStep(
          'Login to user and verify the ledger tab for the patient'
        );
        cy.cLogOut();
        /**
         * @Issue: Due to logout and re login, API is not working and we have tried with the cy reload after logout and still not worked
         * @Resolution: we are moving to old login application
         */
        cy.reload();
        cy.visit('/');
        /** Login into SIS Office application*/
        loginPage.login(
          UserList.GEM_USERVNO_FM[0],
          UserList.GEM_USERVNO_FM[1],
          OrganizationList.GEM_ORG_4
        );

        // /**********Login To Application***********/
        // const userLogin: UserLogin = {
        //   UserName: UserList.GEM_USERVNO_FM[0],
        //   Password: UserList.GEM_USERVNO_FM[1],
        // };
        // cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.verifyLedgerTab();
        // #endregion
      });
    });
  }
}
