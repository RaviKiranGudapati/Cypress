import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { Application } from '../../../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../../../support/common-core-libs/framework/common-utils';

import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { td_case_creation_6737 } from '../../../../../fixtures/sis-office/facesheet/case-details-tcid-6737.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { HelperText } from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import { CasesDetailsFaceSheet } from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-case-details';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';

/* instance variables */
const createCase = new CreateCase();
const sisOfficeDesktop = new SISOfficeDesktop();
const casesDetailsFaceSheet = new CasesDetailsFaceSheet();
const faceSheetCases = new FaceSheetCases();
const scheduleGrid = new ScheduleGrid();

/* const values */
const dateOfService_Actual = CommonUtils.getTodayDate();
const dateOfService_Today = 'Today ';
const index = 2;

export class CaseDetailsTcId6737 {
  //Object Repositories For Case details
  private orCaseDetails =
    OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.CASE_DETAILS;

  verifyWarningMsg(warning: string) {
    // delete clearRoom() method after 265171 is resolved
    createCase.clearRoom();
    casesDetailsFaceSheet.verifyTimeWarningMsg(warning, true);
    // delete selectRoom() method after 265171 is resolved
    createCase.selectRoom(
      td_case_creation_6737.PatientCase.CaseDetails.OperatingRoom
    );
  }

  navigateToFormsTabNavigateBackToCaseDetails() {
    sisOfficeDesktop.selectTaskInMyTasks(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.FORMS_CONSENTS[0]
    );
    sisOfficeDesktop.selectTaskInMyTasks(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CASE_DETAILS[0]
    );
  }

  addProcedureByClickPlusIconProcedureDetails() {
    createCase.clickPlusIconProcedureDetails();
    createCase.enterCPTRowData(
      td_case_creation_6737.PatientCase.CaseDetails.CptCodeInfo
    );
  }

  verifyCaseDetailsDataOfPatient_One() {
    describe('Verify the data and update data based on the actions performed in the Case Details', () => {
      it('Verify the data and update data based on the actions performed in the Case Details', () => {
        // #region - select the patient modify operating room,Date of service and update in Case Details

        cy.cGroupAsStep(
          'select the patient modify operating room,Date of service and update in Case Details'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_case_creation_6737.PatientCase.PatientDetails[0]
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);
        casesDetailsFaceSheet.verifyCptCodeAndDescription(HelperText.cpt_label);
        createCase.verifyCopyRight();
        createCase.selectRoom(
          td_case_creation_6737.PatientCase.CaseDetails.OperatingRoom
        );
        cy.cRemoveMaskWrapper(Application.office);
        createCase.enterDateOfService(
          td_case_creation_6737.PatientCase.CaseDetails.DateOfService
        );
        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        this.navigateToFormsTabNavigateBackToCaseDetails();
        // #endregion

        // #region - Verify updated operating room and Date of service  in Case Details

        cy.cGroupAsStep(
          'Verify updated operating room and Date of service  in Case Details'
        );
        casesDetailsFaceSheet.verifyOperatingRoom(
          td_case_creation_6737.PatientCase.CaseDetails.OperatingRoom
        );
        casesDetailsFaceSheet.verifyDateOfService(dateOfService_Actual);
        // #endregion

        // #region -Modify Start time and End time in Case Details '

        cy.cGroupAsStep('Modify Start time and End time in Case Details');
        createCase.enterStartTime(
          td_case_creation_6737.PatientCase.CaseDetails.StartTime[0]
        );
        createCase.enterEndTime(
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[0]
        );
        // #endregion

        // #region - Modify Cleanup time,Notes,Appointment Type,Anesthesia Type and Update in Case Details

        cy.cGroupAsStep(
          'Modify Cleanup time,Notes,Appointment Type,Anesthesia Type and Update in Case Details'
        );
        createCase.enterCleanupTime(
          td_case_creation_6737.PatientCase.CaseDetails.CleanUpTime
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.addNotes(
          td_case_creation_6737.PatientCase.CaseDetails.CaseNotes
        );
        createCase.selectAppointmentType(
          td_case_creation_6737.PatientCase.CaseDetails.AppointmentType
        );
        cy.cGroupAsStep('Verify Anesthesia Type select dropdown');
        casesDetailsFaceSheet.clickOnAnesthesiaDropDown(
          td_case_creation_6737.PatientCase.CaseDetails.AnesthesiaType
        );
        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        this.navigateToFormsTabNavigateBackToCaseDetails();
        // #endregion

        // #region - Verify  Updated Cleanup time,Notes,Appointment Type,Anesthesia Type and Update in Case Details

        cy.cGroupAsStep(
          'Verify  Updated Cleanup time,Notes,Appointment Type,Anesthesia Type and Update in Case Details'
        );
        casesDetailsFaceSheet.verifyStartTimeAndEndTime(
          this.orCaseDetails.START_TIME[0],
          td_case_creation_6737.PatientCase.CaseDetails.StartTime[0]
        );
        casesDetailsFaceSheet.verifyStartTimeAndEndTime(
          this.orCaseDetails.END_TIME[0],
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[0]
        );
        faceSheetCases.clickNotesButton();
        faceSheetCases.verifyAddedNotes(
          td_case_creation_6737.PatientCase.CaseDetails.CaseNotes
        );
        casesDetailsFaceSheet.verifyAppointmentType(
          td_case_creation_6737.PatientCase.CaseDetails.AppointmentType
        );
        casesDetailsFaceSheet.verifyAnesthesiaType(
          td_case_creation_6737.PatientCase.CaseDetails.AnesthesiaType
        );
        // #endregion

        // #region - Add PreferenceCard,Equipments,Add procedure and Update in Case Details

        cy.cGroupAsStep(
          'Add PreferenceCard,Equipments,Add procedure and Update in Case Details'
        );
        createCase.selectPreferenceCard(
          td_case_creation_6737.PatientCase.CaseDetails.PreferenceCard
        );
        createCase.addEquipment(
          td_case_creation_6737.PatientCase.CaseDetails.Equipment[0]
        );
        createCase.addEquipment(
          td_case_creation_6737.PatientCase.CaseDetails.Equipment[1]
        );
        this.addProcedureByClickPlusIconProcedureDetails();
        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        this.navigateToFormsTabNavigateBackToCaseDetails();
        // #endregion

        // #region - Verify Added PreferenceCard,Equipments,Add procedure and Update in Case Details

        cy.cGroupAsStep(
          'Verify Updated PreferenceCard,Equipments and Update in Case Details'
        );
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_creation_6737.PatientCase.CaseDetails.Equipment[0]
        );
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_creation_6737.PatientCase.CaseDetails.Equipment[1]
        );
        createCase.verifyAddedCptCodeInCptTable(
          index,
          td_case_creation_6737.PatientCase.CaseDetails.CptCodeInfo
            .CPTCodeAndDescription
        );
        // #endregion

        // #region - Verify Modified details in Schedule grid As updated in Case Details

        cy.cGroupAsStep(
          'Verify Modified details in Schedule grid As updated in Case Details'
        );
        sisOfficeDesktop.selectSisLogo();
        scheduleGrid.selectRoomInScheduleGrid(
          td_case_creation_6737.PatientCase.CaseDetails.OperatingRoom
        );
        casesDetailsFaceSheet.verifyPatientInOperatingRoomInScheduleGrid(
          td_case_creation_6737.PatientCase.PatientDetails[0].LastName,
          td_case_creation_6737.PatientCase.CaseDetails.StartTime[0],
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[0],
          dateOfService_Today
        );
        // #endregion
      });
    });
  }

  verifyCaseDetailsDataOfPatient_Two() {
    describe('Verify Warning messages by deleting Mandatory fields and update back in Case Details tab', () => {
      it('Verify Warning messages by deleting Mandatory fields and update back in Case Details tab', () => {
        // #region - Verify Warning message by removing operating Room and Date of service

        cy.cGroupAsStep(
          'Verify Warning message by removing operating Room and Date of service'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_case_creation_6737.PatientCase.PatientDetails[1]
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);
        casesDetailsFaceSheet.verifyWarningMsgOperatingRoom(
          AppErrorMessages.required_operating_room
        );
        createCase.selectRoom(
          td_case_creation_6737.PatientCase.CaseDetails.OperatingRoom
        );
        createCase.verifyWarningMsgDOS();
        createCase.enterDateOfService(
          td_case_creation_6737.PatientCase.CaseDetails.DateOfService
        );
        // #endregion

        // #region - Add Equipment,one more case and update in Case Details tab

        cy.cGroupAsStep(
          'Add Equipment,one more case and update in Case Details tab'
        );
        createCase.addEquipment(
          td_case_creation_6737.PatientCase.CaseDetails.Equipment[0]
        );
        this.addProcedureByClickPlusIconProcedureDetails();
        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        this.navigateToFormsTabNavigateBackToCaseDetails();
        // #endregion

        // #region - Verify Updated Equipment,one more case and update in Case Details tab

        cy.cGroupAsStep(
          'Verify Updated Equipment,one more case and update in Case Details tab'
        );
        createCase.verifyEquipmentOrPreferenceCard(
          td_case_creation_6737.PatientCase.CaseDetails.Equipment[0]
        );
        createCase.verifyAddedCptCodeInCptTable(
          index,
          td_case_creation_6737.PatientCase.CaseDetails.CptCodeInfo
            .CPTCodeAndDescription
        );
        // #endregion

        // #region - Enter Start Time Greater Than EndTime and Verify warning message in Case Details tab

        cy.cGroupAsStep(
          'Enter Start Time Greater Than EndTime and Verify warning message in Case Details tab'
        );
        createCase.enterEndTime(
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[1]
        );
        casesDetailsFaceSheet.clearTime(this.orCaseDetails.DURATION[1]);
        createCase.enterEndTime(
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[1]
        );
        createCase.enterStartTime(
          td_case_creation_6737.PatientCase.CaseDetails.StartTime[0]
        );
        this.verifyWarningMsg(AppErrorMessages.start_time_is_greater);
        createCase.enterStartTime(
          td_case_creation_6737.PatientCase.CaseDetails.StartTime[1]
        );
        casesDetailsFaceSheet.verifyTimeWarningMsg(
          AppErrorMessages.start_time_is_greater,
          false
        );
        // #endregion

        // #region - Enter End Time Lesser Than Start Time and Verify warning message in Case Details tab

        cy.cGroupAsStep(
          'Enter End Time Lesser Than Start Time and Verify warning message in Case Details tab'
        );
        createCase.enterEndTime(
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[1]
        );
        this.verifyWarningMsg(AppErrorMessages.start_time_is_greater);
        createCase.enterEndTime(
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[0]
        );
        casesDetailsFaceSheet.verifyTimeWarningMsg(
          AppErrorMessages.start_time_is_greater,
          false
        );
        // #endregion

        // #region - Clear Start Time,Verify warning message,Update back and Verify warning message should disappear

        cy.cGroupAsStep(
          'Clear Start Time,Verify warning message,Update back and Verify warning message should disappear'
        );
        casesDetailsFaceSheet.clearTime(this.orCaseDetails.START_TIME[1]);
        this.verifyWarningMsg(AppErrorMessages.required_start_end_times);
        createCase.enterStartTime(
          td_case_creation_6737.PatientCase.CaseDetails.StartTime[0]
        );
        casesDetailsFaceSheet.verifyTimeWarningMsg(
          AppErrorMessages.required_start_end_times,
          false
        );
        // #endregion

        // #region -Clear End Time,Verify warning message,Update back and Verify warning message should disappear

        cy.cGroupAsStep(
          'Clear End Time,Verify warning message,Update back and Verify warning message should disappear'
        );
        casesDetailsFaceSheet.clearTime(this.orCaseDetails.END_TIME[1]);
        this.verifyWarningMsg(AppErrorMessages.required_start_end_times);
        createCase.enterEndTime(
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[0]
        );
        casesDetailsFaceSheet.verifyTimeWarningMsg(
          AppErrorMessages.required_start_end_times,
          false
        );
      // Api calls will not generate while we click on highlighted cases details tab so we clicked on the label after entering data in the fields
        casesDetailsFaceSheet.clickCaseDetailLabels(
          this.orCaseDetails.END_TIME[0]
        );
        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        this.navigateToFormsTabNavigateBackToCaseDetails();
        // #endregion

        // #region - Verify updated data in Case Details tab

        cy.cGroupAsStep('Verify updated data in Case Details tab');
        casesDetailsFaceSheet.verifyOperatingRoom(
          td_case_creation_6737.PatientCase.CaseDetails.OperatingRoom
        );
        createCase.enterDateOfService(
          td_case_creation_6737.PatientCase.CaseDetails.DateOfService
        );
        casesDetailsFaceSheet.verifyStartTimeAndEndTime(
          this.orCaseDetails.START_TIME[0],
          td_case_creation_6737.PatientCase.CaseDetails.StartTime[0]
        );
        casesDetailsFaceSheet.verifyStartTimeAndEndTime(
          this.orCaseDetails.END_TIME[0],
          td_case_creation_6737.PatientCase.CaseDetails.EndTime[0]
        );
        cy.cLogOut();
        // #endregion
      });
    });
  }

  verifyUser2modifyPermission() {
    describe('Verify that Case Details should not be editable as User2 do not have modify access in scheduling', () => {
      it('Verify that Case Details should not be editable as User2 do not have modify access in scheduling', () => {
        /** Due to 266903 Bug 23rd Step of this US is not scripted completely.
         *  Expected: Step is to verify that Case Details should not be editable as User2 do not have modify ceckpoint  permissin access in scheduling
         *  Actual: But user is able to modify the edit details in Case Details Face sheet
         */

        // #region - Log in with user2
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_4[0],
          Password: UserList.GEM_USER_4[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
        // #endregion

        // #region - Verify user not able to modify tha details in Case Details tab

        cy.cGroupAsStep(
          'Verify user not able to modify tha details in Case Details tab'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_case_creation_6737.PatientCase.PatientDetails[1]
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);
        createCase.selectRoom(
          td_case_creation_6737.PatientCase.CaseDetails.OperatingRoom
        );
        // #endregion
      });
    });
  }
}
