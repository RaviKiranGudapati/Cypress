import { ExpandOrCollapse } from '../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_facesheet_allocation_tcid_263220 } from '../../../../../fixtures/sis-office/facesheet/facesheet-allocation-tcid-263220.td';

import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';
import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import Transactions, {
  ContextMenu,
} from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import PatientDetailsFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';

/* instance variables */
const scheduleGrid = new ScheduleGrid();
const sisOfficeDesktop = new SISOfficeDesktop();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const patientDetailsFaceSheet = new PatientDetailsFaceSheet();
const faceSheetCases = new FaceSheetCases(td_facesheet_allocation_tcid_263220);
const transactions = new Transactions();

/* const values */
const amounts =
  td_facesheet_allocation_tcid_263220.AllocatedAndUnallocatedAmounts1;
const zero = '0';

export class VerifyFieldsInLedgerAndTransactions263220 {
  /**
   * @details - verify AllocatedAmount, UnallocatedAmount, Due amount with different Allocation Amounts
   * @param allocationAmount
   * @param allocatedAmountToBeVerified
   * @param unallocatedAmountToBeVerified
   * @param dueToBeVerified
   */
  verifyAllocateAndUnallocatedAmount(
    allocationAmount: number,
    allocatedAmountToBeVerified: string,
    unallocatedAmountToBeVerified: string,
    dueToBeVerified: string
  ) {
    ledgerTabFaceSheet.enterAllocationAmount(allocationAmount, zero);
    ledgerTabFaceSheet.clickOnSubHeaderInAllocationPopUp();
    ledgerTabFaceSheet.verifyAllocatedAmountInAllocationPopUp(
      allocatedAmountToBeVerified
    );
    ledgerTabFaceSheet.verifyUnallocated(unallocatedAmountToBeVerified);
    ledgerTabFaceSheet.verifyDueInAllocationPopUp(dueToBeVerified);
  }

  verifyFieldsInLedger() {
    describe('Verify Unassigned Payment Allocation fields in Ledger Tab', () => {
      it('Verify Adding Unassigned Payment, and fields in Allocation pop should be pulled from the  added unassigned payment, add Allocation amount', () => {
        cy.cGroupAsStep('Select patient and add unassigned payment');
        // #region - select patient from master search
        scheduleGrid.selectPatientCase(
          td_facesheet_allocation_tcid_263220.PatientDetails.PatientFirstName
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_facesheet_allocation_tcid_263220.PatientDetails.PatientFirstName,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.FACE_SHEET_ICON[0]
        );
        // #endregion

        // #region - add Unassigned Payment
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnAddButton();
        ledgerTabFaceSheet.unassignedPaymentDetails(
          td_facesheet_allocation_tcid_263220.UnassignedPay
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify options in context menu and fields in unassigned payment allocation'
        );
        // #region - verify options in context menu and fields in unassigned payment allocation
        ledgerTabFaceSheet.verifyContextMenuOptions(
          td_facesheet_allocation_tcid_263220.ContextMenuOptions.Options,
          td_facesheet_allocation_tcid_263220.TransactionCode[0]
        );
        ledgerTabFaceSheet.clickOnAllocate();
        ledgerTabFaceSheet.verifyUnassignedPaymentAllocationFieldsPopUp(
          td_facesheet_allocation_tcid_263220.UnAssignedAllocationModel
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify Allocated amount, Unallocated and Due amounts with different Allocation amounts and Allocate Amount'
        );
        // #region - Verify Allocated amount, Unallocated and Due amounts with different Allocation amounts
        this.verifyAllocateAndUnallocatedAmount(
          amounts.AllocationAmount[0],
          amounts.AllocatedAmountToBeVerified[0],
          amounts.UnallocatedAmountToBeVerified[0],
          amounts.DueToBeVerified[0]
        );
        this.verifyAllocateAndUnallocatedAmount(
          amounts.AllocationAmount[1],
          amounts.AllocatedAmountToBeVerified[1],
          amounts.UnallocatedAmountToBeVerified[1],
          amounts.DueToBeVerified[1]
        );
        this.verifyAllocateAndUnallocatedAmount(
          amounts.AllocationAmount[2],
          amounts.AllocatedAmountToBeVerified[2],
          amounts.UnallocatedAmountToBeVerified[2],
          amounts.DueToBeVerified[2]
        );
        // #endregion

        // #region - Allocate Amount
        ledgerTabFaceSheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.ALLOCATION.TRANSACTION_CODE[0],
          td_facesheet_allocation_tcid_263220.TransactionCode[1]
        );
        ledgerTabFaceSheet.clickOnDone();
        // #endregion
      });
    });
  }

  verifyFieldsInTransactions() {
    describe('Verify Allocation Correction fields in Transactions', () => {
      it('Verify that fields in Correction in cases tab should be as documented in the ledger', () => {
        cy.cGroupAsStep('Verify context menu options in transactions');
        // #region - Verify context menu options in transactions
        patientDetailsFaceSheet.clickOnCasesTab();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        transactions.verifyContextMenuOptions();
        // #endregion

        cy.cGroupAsStep(
          'Select correction from context menu and verify fields in Allocation Correction PopUp'
        );
        // #region -Select correction from context menu and verify fields in Allocation Correction PopUp
        transactions.selectContextMenuOption(ContextMenu.correction);
        transactions.verifyFieldsInAllocationCorrection(
          td_facesheet_allocation_tcid_263220.AllocationCorrection1
        );
        // #endregion

        cy.cGroupAsStep(`Verify newBalance, and the field data is not saved`);
        // #region - Enter new Allocation Amount and verify newBalance, then verify Done button is present
        transactions.allocationCorrection(
          td_facesheet_allocation_tcid_263220.AllocationCorrection2
        );
        transactions.verifyNewBalance(
          td_facesheet_allocation_tcid_263220.NewBalance[0]
        );
        transactions.verifyDoneButtonIsPresent();
        // #endregion

        // #region - Close the pop up, verify the field data is not saved
        sisOfficeDesktop.clickCloseIcon();
        transactions.verifyNewLineAdded(1, false);
        // #endregion

        cy.cGroupAsStep(
          'Correcting the Allocation amount with new Allocation amount'
        );
        // #region - Correcting the Allocation amount with new Allocation amount
        transactions.selectContextMenuOption(ContextMenu.correction);
        transactions.allocationCorrection(
          td_facesheet_allocation_tcid_263220.AllocationCorrection2
        );
        transactions.verifyNewBalance(
          td_facesheet_allocation_tcid_263220.NewBalance[0]
        );
        transactions.clickDoneButton();
        // #endregion

        cy.cGroupAsStep(
          'Verify new line is added in charges table with type correction'
        );
        // #region - Verify new line is added in charges table with type correction
        transactions.verifyBalanceDueInTransactions(
          0,
          7,
          td_facesheet_allocation_tcid_263220.NewBalance[0]
        );
        transactions.verifyNewLineAdded(1, true);
        transactions.verifyFieldsInChargesTable(
          td_facesheet_allocation_tcid_263220.FieldsInNewLineAfterCOrrection[0],
          td_facesheet_allocation_tcid_263220.FieldsInNewLineAfterCOrrection[1],
          td_facesheet_allocation_tcid_263220.FieldsInNewLineAfterCOrrection[2]
        );
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        // #endregion

        cy.cGroupAsStep('Verify balance amount in show Aging in Ledger Tab');
        // #region - Verify balance amount in show Aging in Ledger Tab
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnShowAging();
        ledgerTabFaceSheet.verifyAmountsInAging(
          td_facesheet_allocation_tcid_263220.ShowAgingLabels,
          td_facesheet_allocation_tcid_263220.ShowAgingAccountValues
        );
        // #endregion
      });
    });
  }
}
