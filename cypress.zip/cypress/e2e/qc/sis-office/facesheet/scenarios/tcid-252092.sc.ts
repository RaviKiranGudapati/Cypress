import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { ExpandOrCollapse } from '../../../../../support/common-core-libs/application/common-core';

import { td_ready_for_bill_status_tcid_252092 } from '../../../../../fixtures/sis-office/facesheet/ready-for-bill-status-tcid-252092.td';

import { OR_FACESHEET_LEDGER_TAB } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';
import { OR_SCHEDULE_GRID } from '../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import ScheduleGrid from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import InsuranceBilling from '../../../../../app-modules-libs/sis-office/trackers/insurance-billing';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import FaceSheetChargeEntry from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import PatientStatement from '../../../../../app-modules-libs/sis-office/trackers/patient-statement';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import { InsuranceBillingOptions } from '../../../../../app-modules-libs/sis-office/trackers/enums/insurance-billing.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions(
  td_ready_for_bill_status_tcid_252092.PatientCase[0]
);
const faceSheetCases = new FaceSheetCases();
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const patientStatement = new PatientStatement();
const chargeEntry3 = new ChargeEntry(
  td_ready_for_bill_status_tcid_252092.PatientCase[2]
);
const chargeEntry4 = new ChargeEntry(
  td_ready_for_bill_status_tcid_252092.PatientCase[3]
);
const insuranceBilling = new InsuranceBilling();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase();

export class ReadyForBillStatusTcId252092 {
  verifyCaseStatusWithTwoProcAndPI() {
    describe('Verify Case Status in Transaction and Facesheet for the patient with 2 procedures and 1 Insurances', () => {
      it('Validate the case status by adding and removing payments in Transaction and Facesheet', () => {
        // #region - Navigate to Transaction Page from facesheet

        cy.cGroupAsStep('Navigate to Transaction Page from facesheet');
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ready_for_bill_status_tcid_252092.PatientCase[0].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        // #endregion

        cy.cGroupAsStep('Add Payment for both the charges');
        // #region - Add Payment for both the charges
        transactions.selectCPTCode(
          td_ready_for_bill_status_tcid_252092.PatientCase[0].CaseDetails
            ?.CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.selectDropdownValueInDebitPopup(
          OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.PERIOD[0],
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[0]
            .Period!
        );
        transactions.selectDropdownValueInDebitPopup(
          OR_TRANSACTION.CHARGES_DEBITS_AND_WRITE_OFF.BATCH[0],
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[0]
            .Batch!
        );
        transactions.selectTransactionValuesInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[1]
        );
        transactions.clickDoneInPayment();
        // #endregion

        cy.cGroupAsStep(
          'Verify System Billed Icon once payment is done for all the charges'
        );
        // #region - Verify System Billed Icon once payment is done for all the charges
        /**
         * @Issue: Taking few seconds to display billed icon
         * @Resolution: Added assertion and re click on the Transaction
         */
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        transactions.verifyContextMenu();
        transactions.verifySystemBilledIcon();
        // #endregion

        cy.cGroupAsStep(
          'Delete Transaction for 1st Charge and check case status'
        );
        // #region - Delete Transaction for 1st Charge and check case status
        transactions.deleteTransaction(
          td_ready_for_bill_status_tcid_252092.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );

        faceSheetCases.selectCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify System Billed Icon got removed if one of the charges transactions got deleted'
        );
        // #region - Verify System Billed Icon got removed if one of the charges transactions got deleted
        /**
         * @Issue: Taking few seconds to display billed icon
         * @Resolution: Added assertion and re click on the Transaction
         */
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.TRANSACTIONS[0]
        );
        transactions.verifyContextMenu();
        transactions.verifySystemBilledIcon(false);
        // #endregion

        cy.cGroupAsStep(
          'Navigate to Facesheet page and verify the case status'
        );
        // #region - Navigate to Facesheet page and verify the case status
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.verifyCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep(
          'Navigate back to Transaction page and delete other transaction too and checking the status'
        );
        // #region - Navigate back to Transaction page and delete other transaction too and checking the status
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.deleteTransaction(
          td_ready_for_bill_status_tcid_252092.PatientCase[0].CaseDetails
            .CptCodeInfo[1].CPTCodeAndDescription
        );

        faceSheetCases.selectCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep(
          'Navigate to Facesheet page and verify the case status'
        );
        // #region - Navigate to Facesheet page and verify the case status
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.verifyCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Schedule Grid Tracker');
        // #region - Navigate to Schedule Grid Tracker
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyCaseStatusWithGuarantor() {
    describe('Verify Case Status for the patient with 2 procedures and 1 Guarantor and Billed Statement count in Patient Statement', () => {
      it('Validate the case status and Billed Statement in Patient Statement Tracker', () => {
        // #region - Navigate to Transaction Page from facesheet

        cy.cGroupAsStep('Navigate to Transaction Page from facesheet');
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ready_for_bill_status_tcid_252092.PatientCase[1].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        // #endregion

        cy.cGroupAsStep('Add Payment for both the charges');
        // #region - Add Payment for both the charges
        transactions.selectCPTCode(
          td_ready_for_bill_status_tcid_252092.PatientCase[0].CaseDetails
            ?.CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[1]
        );
        transactions.clickDoneInPayment();
        // #endregion

        cy.cGroupAsStep(
          'Navigate to charge entry, add new procedure and check case status'
        );
        // #region - Navigate to charge entry, add new procedure and check case status
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.addProcedure(
          td_ready_for_bill_status_tcid_252092.CptCodeInfo
        );
        faceSheetChargeEntry.clickUpdateButton();
        faceSheetCases.selectCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Patient Statements Tracker');
        // #region - Navigate to Patient Statements Tracker
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify Billed Statement Count in Patient Statements Tracker'
        );
        // #region - Verify Billed Statement Count in Patient Statements Tracker
        patientStatement.verifyBilledStatementCount(
          td_ready_for_bill_status_tcid_252092.patientStatement.PatientName,
          td_ready_for_bill_status_tcid_252092.patientStatement.BilledStatements
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Schedule Grid Tracker');
        // #region - Navigate to Schedule Grid Tracker
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyCaseStatusAfterInsuranceBilling() {
    describe('Verify Case Status After performing Insurance Billing', () => {
      it('Validate the case status after performing Bill Selecting Payers in Insurance Billing tracker', () => {
        // #region - Complete Check-In for Patient 3 and navigate to Schedule Grid

        cy.cGroupAsStep(
          'Complete Check-In for Patient 3 and navigate to Schedule Grid'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_ready_for_bill_status_tcid_252092.PatientCase[2].PatientDetails
            .PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.clickCheckInDone();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        cy.cGroupAsStep(
          'Navigate to Charge Entry, uncheck Generate Bill and make it Ready for Bill'
        );
        // #region - Navigate to Charge Entry, uncheck Generate Bill and make it Ready for Bill
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry3.selectCase(
          td_ready_for_bill_status_tcid_252092.ChargeDetails
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_ready_for_bill_status_tcid_252092.PatientCase[2].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry3.uncheckGenerateBill();
        chargeEntry3.clickOnChargeCollapse(0);
        chargeEntry3.clickReadyForBillAndDoneButton(true);
        // #endregion

        cy.cGroupAsStep('Navigate to Facesheet and check status');
        // #region - Navigate to Facesheet and check status
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ready_for_bill_status_tcid_252092.PatientCase[2].PatientDetails
        );
        faceSheetCases.verifyCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Transaction and check status');
        // #region - Navigate to Transaction and check status
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        faceSheetCases.selectCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep(
          'Navigate to My Tasks Charge Entry, add new procedure and check status'
        );
        // #region - Navigate to My Tasks Charge Entry, add new procedure and check status
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
        );
        faceSheetChargeEntry.addProcedure(
          td_ready_for_bill_status_tcid_252092.CptCodeInfo
        );
        faceSheetChargeEntry.clickUpdateButton();
        faceSheetCases.selectCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Insurance Billing Tracker');
        // #region - Navigate to Insurance Billing Tracker
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INSURANCE_BILLING[0]
        );
        // #endregion

        cy.cGroupAsStep('Select Bill Selected Payers Button');
        // #region - Select Bill Selected Payers Button
        insuranceBilling.expandPlusIconBasedOnCarrier(
          td_ready_for_bill_status_tcid_252092.InsuranceBilling[0]
            .InsuranceCarrier
        );
        insuranceBilling.clickCheckboxInExpandedIcon(
          td_ready_for_bill_status_tcid_252092.InsuranceBilling[0].PatientName
        );
        insuranceBilling.selectButtonsInInsuranceBilling(
          InsuranceBillingOptions.bill_selected_payers
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Facesheet and check case status');
        // #region - Navigate to Facesheet and check case status
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ready_for_bill_status_tcid_252092.PatientCase[2].PatientDetails
        );
        faceSheetCases.verifyCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[1].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Transaction and check case status');
        // #region - Navigate to Transaction and check case status
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        faceSheetCases.selectCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[1].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Schedule Grid Tracker');
        // #region - Navigate to Schedule Grid Tracker
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyCaseStatusWhenPartiallyBilled() {
    describe('Verify Case Status for the patient When 1 procedure with generate bill and out without by doing partial transaction', () => {
      it('Validate the case status for Partially Billed Patient', () => {
        // #region - Navigate to Charge Entry, Uncheck GB for 1st Charge and complete the process

        cy.cGroupAsStep(
          'Navigate to Charge Entry, Uncheck GB for 1st Charge and complete the process'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );

        chargeEntry4.selectCase(
          td_ready_for_bill_status_tcid_252092.ChargeDetails
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_ready_for_bill_status_tcid_252092.PatientCase[3].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry4.uncheckGenerateBill();
        chargeEntry4.clickOnChargeCollapse(0);
        chargeEntry4.clickReadyForBillAndDoneButton(true);
        // #endregion

        cy.cGroupAsStep(
          'Navigate to Transaction Page, complete payment for Charge 2 and verify case status'
        );
        // #region - Navigate to Transaction Page, complete payment for Charge 2 and verify case status
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ready_for_bill_status_tcid_252092.PatientCase[3].PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        transactions.selectCPTCode(
          td_ready_for_bill_status_tcid_252092.PatientCase[3].CaseDetails
            ?.CptCodeInfo[1].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.deleteChargeInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[1]
        );

        transactions.clickDoneInPayment();

        faceSheetCases.selectCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Facesheet and check case status');
        // #region - Navigate to Facesheet and check case status
        sisOfficeDesktop.clickOnPersonIconInBusinessDesktop();
        faceSheetCases.verifyCaseStatus(
          td_ready_for_bill_status_tcid_252092.CaseHeaderDetails[0].CaseStatus
        );
        // #endregion

        cy.cGroupAsStep('Navigate to Schedule Grid Tracker');
        // #region - Navigate to Schedule Grid Tracker
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyPatientInRCMTracker() {
    describe('Verify Billing History and Claim Status in RCM Tracker for Partially Billed Patient', () => {
      it('Verify Billing History and Claim Status in RCM Tracker for Partially Billed Patient', () => {
        // #region - Navigate to Transaction from Facesheet

        cy.cGroupAsStep('Navigate to Transaction from Facesheet');
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_ready_for_bill_status_tcid_252092.PatientCase[4].PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        // #endregion

        cy.cGroupAsStep(
          'Complete Payment for Both the charges to get it billed and delete first charge payment'
        );
        // #region - Complete Payment for Both the charges to get it billed and delete first charge payment
        transactions.selectCPTCode(
          td_ready_for_bill_status_tcid_252092.PatientCase[4].CaseDetails
            ?.CptCodeInfo[1].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.PAYMENTS[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[0]
        );
        transactions.selectTransactionValuesInPayments(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[1]
        );
        transactions.clickDoneInPayment();
        transactions.verifyOptionInTransaction();
        transactions.verifyContextMenu();
        transactions.deleteTransaction(
          td_ready_for_bill_status_tcid_252092.PatientCase[4].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        // #endregion

        cy.cGroupAsStep('Navigate to RCM Tracker and select Patient');
        // #region - Navigate to RCM Tracker and select Patient
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        sisOfficeDesktop.sortInDescendingOrderByDOS();
        sisOfficeDesktop.selectPatientRow(
          td_ready_for_bill_status_tcid_252092.PatientCase[4].PatientDetails
            .LastName!,
          td_ready_for_bill_status_tcid_252092.PatientCase[4].PatientDetails
            .PatientFirstName!
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify the data and system billed info icon in Billing History'
        );
        // #region - Verify the data and system billed info icon in Billing History
        ledgerTabFaceSheet.clickButtonsInLedger(
          OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[0]
        );

        ledgerTabFaceSheet.verifyBillingHistoryHeader(
          OR_FACESHEET_LEDGER_TAB.BILLING_HISTORY[0]
        );

        ledgerTabFaceSheet.clickPlusIconBasedOnCPT(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[1]
            .CPTHCPCS
        );

        ledgerTabFaceSheet.verifyBillHistoryTransactions(
          td_ready_for_bill_status_tcid_252092.BillingHistTransInfo
        );

        ledgerTabFaceSheet.verifySystemBilledInfoIcon(
          td_ready_for_bill_status_tcid_252092.ClaimStatus.InfoIcon
        );

        sisOfficeDesktop.clickCloseIcon();
        // #endregion

        cy.cGroupAsStep('Verify last billed info icon in Claim History');
        // #region - Verify last billed info icon in Claim History
        transactions.clickClaimStatus();

        transactions.verifyLastBilledInfoIcon(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[0]
            .CPTHCPCS,
          td_ready_for_bill_status_tcid_252092.ClaimStatus.InfoIcon
        );

        transactions.verifyLastBilledInfoIcon(
          td_ready_for_bill_status_tcid_252092.caseTransaction.PaymentsInfo[1]
            .CPTHCPCS,
          td_ready_for_bill_status_tcid_252092.ClaimStatus.InfoIcon
        );
        sisOfficeDesktop.clickCloseIcon();

        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
