import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import CasesToCode from '../../../../../app-modules-libs/sis-office/trackers/cases-to-code';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import InventoryReconciliation from '../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';
import { td_case_header_tcid_261978 } from '../../../../../fixtures/sis-office/facesheet/case-header-tcid-261978.td';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

/*instance variables*/
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_case_header_tcid_261978.PatientCase[0]);
const casesToCode = new CasesToCode(createCase.patientCaseModel!);
const faceSheetCases = new FaceSheetCases(createCase.patientCaseModel!);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const inventoryReconciliation = new InventoryReconciliation(
  td_case_header_tcid_261978.PatientCase[0].PatientDetails,
  td_case_header_tcid_261978.ImplantInfo
);

export class CaseHeaderTcId261978 {
  verifyCaseHeader() {
    describe('To verify the patient DOS, Procedure Description, Case status in case header of schedule grid trackers', () => {
      it('Verify the patient DOS, Procedures Description, Case status in case header of schedule grid cases to code, Charge Entry Trackers', () => {
        // #region verify patient case details in case header of schedule grid trackers

        cy.cGroupAsStep('Verify the case header in Schedule Grid trackers');
        /*Search patient in Cases to code tracker and Verify patient DOS,procedures details,case status*/

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CASES_TO_CODE[0]
        );
        sisOfficeDesktop.selectPatientRow(
          td_case_header_tcid_261978.PatientCase[0].PatientDetails.LastName,
          td_case_header_tcid_261978.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        faceSheetCases.verifyCaseHeader(
          td_case_header_tcid_261978.CaseHeaderDetails[0].CaseStatus
        );
        sisOfficeDesktop.selectSisLogo();
        casesToCode.performCasesToCode(
          td_case_header_tcid_261978.CasesToCodeDetails
        );
        /*Search patient in charge entry tracker and Verify patient DOS,procedures details,case status*/
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectPeriodAndBatch(
          td_case_header_tcid_261978.ChargeDetails
        );
        sisOfficeDesktop.selectPatientRow(
          td_case_header_tcid_261978.PatientCase[0].PatientDetails.LastName,
          td_case_header_tcid_261978.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        faceSheetCases.verifyCaseHeader(
          td_case_header_tcid_261978.CaseHeaderDetails[1].CaseStatus
        );
        chargeEntry.clickReadyForBillAndDoneButton(true);

        /*Search patient in  financial clearance tracker and Verify patient DOS,procedures details,case status*/
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.FINANCIAL_CLEARANCE[0]
        );
        sisOfficeDesktop.selectPatientRow(
          td_case_header_tcid_261978.PatientCase[0].PatientDetails.LastName,
          td_case_header_tcid_261978.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        faceSheetCases.verifyCaseHeader(
          td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
        );
        sisOfficeDesktop.clickDoneButton();
        /*Search patient in inventory Reconciliation tracker and Verify patient DOS,procedures details,case status*/
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        cy.shouldBeEnabled(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION
            .INVENTORY_RECONCILIATION_TABLE.DEPLETE_SELECTED_BUTTON[1]
        );
        //Removed selectDOSRecordsInDescendingOrder() due to Inconsistent failure changed the organization as In inventory tracker scrollIntoView is not working because lo lazy loading
        sisOfficeDesktop.selectPatientRow(
          td_case_header_tcid_261978.PatientCase[0].PatientDetails.LastName,
          td_case_header_tcid_261978.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        inventoryReconciliation.selectImplantInAddImplantPopUp(
          td_case_header_tcid_261978.ImplantInfo[0]
        );
        inventoryReconciliation.addImplantOrProstheticInfo(
          td_case_header_tcid_261978.ImplantInfo[0]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        inventoryReconciliation.clickImplantsClearIcon(
          td_case_header_tcid_261978.ImplantInfo[0].Implant[0]
        );
        sisOfficeDesktop.clickDoneButton();
        sisOfficeDesktop.selectPatientRow(
          td_case_header_tcid_261978.PatientCase[0].PatientDetails.LastName,
          td_case_header_tcid_261978.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        faceSheetCases.verifyCaseHeader(
          td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_case_header_tcid_261978.PatientCase[0].PatientDetails
        );
        // #endregion

        /*Search patient in MastHead and click on patient name. Click on Transactions and Verify patient DOS, procedures details, case status in case header.*/

        cy.cGroupAsStep(
          'Search patient in MastHead and click on patient name. Click on Transactions and Verify patient DOS, procedures details, case status in case header'
        );
        /* To take MRN value from facesheet */
        faceSheetCases.selectMRNPath().then(($ele) => {
          let mrn;
          mrn = $ele.text();
          // #region verify patient details in case header under My Task trackers
          faceSheetCases.faceSheetSelectCaseOption(
            FaceSheetOptions.TRANSACTIONS
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);

          cy.cGroupAsStep(
            'Verify patient DOS,Case status,MRN and procedure details in case header of My Task case details,payer details,financial clearance trackers'
          );
          /*verify case header in case details tracker under My task*/
          sisOfficeDesktop.selectTaskInMyTasks(
            OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CASE_DETAILS[0]
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);

          /*verify case header in payer details tracker under My task*/
          sisOfficeDesktop.selectTaskInMyTasks(
            OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.PAYER_DETAILS[0]
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);

          /*verify case header in financial clearance tracker under My task*/
          sisOfficeDesktop.selectTaskInMyTasks(
            OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.FINANCIAL_CLEARANCE[0]
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);

          cy.cGroupAsStep(
            'Verify patient DOS,Case status,MRN and procedure details in case header of My Task attachment,forms&consents,charge entry,coding trackers'
          );
          /*verify case header in attachments tracker under My task*/
          sisOfficeDesktop.selectTaskInMyTasks(
            OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.ATTACHMENTS[0]
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);

          /*verify case header in forms and consents tracker under My task*/
          sisOfficeDesktop.selectTaskInMyTasks(
            OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.FORMS_CONSENTS[0]
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);

          /*verify case header in charge entry tracker under My task*/
          sisOfficeDesktop.selectTaskInMyTasks(
            OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CHARGE_ENTRY[0]
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);

          /*verify case header in coding tracker under My task*/
          sisOfficeDesktop.selectTaskInMyTasks(
            OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_TASKS.CODING[0]
          );
          faceSheetCases.verifyCaseHeader(
            td_case_header_tcid_261978.CaseHeaderDetails[2].CaseStatus
          );
          faceSheetCases.verifyMRN(mrn);
          // #endregion
        });
      });
    });
  }
}
