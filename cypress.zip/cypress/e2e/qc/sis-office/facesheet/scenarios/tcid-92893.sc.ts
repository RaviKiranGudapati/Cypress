import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import LedgerTabFaceSheet from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';

import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import { td_patient_label_tcid_92893 } from '../../../../../fixtures/sis-office/facesheet/patient-label-tcid-92893.td';

import ScheduleGridPrint from '../../../../../app-modules-libs/sis-office/case-creation/schedule-grid-print';

import { OR_FACESHEET_CASE_PAGE } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-cases.or';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const createCase = new CreateCase(td_patient_label_tcid_92893.PatientCase);
const faceSheetCases = new FaceSheetCases(createCase.patientCaseModel!);
const scheduleGridPrint = new ScheduleGridPrint(
  td_patient_label_tcid_92893.PrintPreviewInfo[1]
);

export class PatientLabelTcId92893 {
  verifyPatientLabelsInFacesheet() {
    describe('Verify the Print preview for Patient label and patient demographics form in Facesheet', () => {
      it('Verify Patient label,patient demographics form  and  its default Values displayed in print pop up ', () => {
        // #region - Selecting Patient Labels in Print Popup and click on Preview Button

        cy.cGroupAsStep(
          'Selecting Patient Labels in Print Popup and click on Preview Button'
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFaceSheet.selectPrintIconInCasesTab();

        faceSheetCases.verifyPrintWindow();
        faceSheetCases.selectOptionsInPrintPopupClickPreview(
          OR_FACESHEET_CASE_PAGE.PATIENT_LABELS[0]
        );
        faceSheetCases.clickOnPreviewInPrint();
        // #endregion

        // #region - Verify default values in Print Options

        cy.cGroupAsStep(
          'Verify Labels in Patient Labels and Default Field Values in Patient Label Print Popup screen'
        );

        faceSheetCases.verifyPreviewOptionsInFacesheet();
        faceSheetCases.verifyPreviewValuesFacesheet(
          td_patient_label_tcid_92893.PrintPreviewInfo[0]
        );
        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_tcid_92893.PrintPreviewInfo[0]
            .NoOfPatientLabelBlocks!
        );
        // #endregion

        // #region - Verify Max Allowed Values in Patient Labels Print Popup

        cy.cGroupAsStep(
          'Verify Max Allowed Values  and verify dummy patient details in Print preview of Patient label'
        );

        faceSheetCases.clearValuesInPreview();

        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_tcid_92893.PrintPreviewInfo[1]
            .NoOfPatientLabelBlocks!
        );
        faceSheetCases.verifyPreviewValuesFacesheet(
          td_patient_label_tcid_92893.PrintPreviewInfo[1]
        );
        faceSheetCases.verifyDummyPatientDetails(
          td_patient_label_tcid_92893.PatientDummyInfo
        );

        faceSheetCases.enterValuesInPreview(
          td_patient_label_tcid_92893.PrintPreviewInfo[2]
        );
        faceSheetCases.clickOnPreviewInPrint();
        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_tcid_92893.PrintPreviewInfo[2]
            .NoOfPatientLabelBlocks!
        );
        faceSheetCases.verifyPreviewValuesFacesheet(
          td_patient_label_tcid_92893.PrintPreviewInfo[2]
        );

        faceSheetCases.clearValuesInPreview();
        faceSheetCases.enterValuesInPreview(
          td_patient_label_tcid_92893.PrintPreviewInfo[3]
        );
        faceSheetCases.clickOnPreviewInPrint();

        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_tcid_92893.PrintPreviewInfo[3]
            .NoOfPatientLabelBlocks!
        );
        faceSheetCases.verifyPreviewValuesFacesheet(
          td_patient_label_tcid_92893.PrintPreviewInfo[3]
        );

        faceSheetCases.enterValuesInPreview(
          td_patient_label_tcid_92893.PrintPreviewInfo[4]
        );
        faceSheetCases.clickOnPreviewInPrint();

        faceSheetCases.verifyPreviewValuesFacesheet(
          td_patient_label_tcid_92893.PrintPreviewInfo[2]
        );
        scheduleGridPrint.verifyNoOfPatientBlocksInPatientLabelsPrintPopup(
          td_patient_label_tcid_92893.PrintPreviewInfo[2]
            .NoOfPatientLabelBlocks!
        );
        // #endregion

        // #region - Verify patient demographics form for cases

        cy.cGroupAsStep('Verify patient demographics form in print popup');

        scheduleGridPrint.ClosePrintPreview();
        ledgerTabFaceSheet.selectPrintIconInCasesTab();
        faceSheetCases.verifyPrintWindow();
        faceSheetCases.selectOptionInPrintPopup(
          OR_FACESHEET_CASE_PAGE.PATIENT_LABELS[0]
        );
        faceSheetCases.selectOptionsInPrintPopupClickPreview(
          OR_FACESHEET_CASE_PAGE.PATIENT_DEMOGRAPHICS_FORM[0]
        );
        faceSheetCases.verifyPatientDemographicsForm();
        scheduleGridPrint.ClosePrintPreview();
        // #endregion
      });
    });
  }
}
