import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';
import { InsuranceVerificationTcId6646 } from './scenarios/tcid-6646.sc';

// SHIFT + ALT + O - Organizing the import
/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verifying Insurance for user with all access, view and modify access and view access in patient demographics
 * Precondition -
 * Create 3 Insurance.
 * Create 1 Patient and add 2 Created Insurances to it.
 * Login via user with all patient demographics access.
 *
 * Script Execution Approach -
 * 1. Edit all the fields for First Insurance in Patient Edit
 * 2. Validate all the updated insurance fields in Facesheet Patient Details
 * 3. Validate sorting of insurances in Facesheet Patient Details
 * 4. Verify Details are not getting saved when user clicks on close icon instead of done button
 * 5. Verify the error message when First Name and Last Name is removed in Edit Insurance Popup
 * 6. Verify user is able to edit first name, last name and gender in Edit Insurance Popup
 * 7. Add 3rd Insurance in Patient Check-In and verify insurance count got increased in Facesheet patient details
 * 8. Verify Sorting after adding third insurance
 * 9. Verify Trash Icon On Hover on insurance
 * 10. Delete First insurance and verify the length post deletion in Facesheet, Check-In and Edit
 * 11. Verify Trash Icon On Hover on insurance for the user with view and modify patient demographics access
 * 12. Verify Trash Icon On Hover on insurance for the user with view patient demographics access
 * 13. Logout
 ************************************************************************/

const insuranceVerification = new InsuranceVerificationTcId6646();

describe(
  'Verifying Insurance for user with all access, view and modify access and view access in patient demographics',
  {
    tags: ['facesheet', 'US#265031', 'TC#6646'],
  },
  () => {
    before(`Launching Web Application`, function () {
      Cypress.on('uncaught:exception', (error, runnable) => {
        return false;
      });
      /****Open the URL as defined in baseUrl in Cypress Configuration File Or CLI flag - --config baseUrl ********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        insuranceVerification.verifyInsuranceWithAllAccess();
        insuranceVerification.verifyInsuranceWithViewModifyAccess();
        insuranceVerification.verifyInsuranceWithOnlyViewAccess();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
