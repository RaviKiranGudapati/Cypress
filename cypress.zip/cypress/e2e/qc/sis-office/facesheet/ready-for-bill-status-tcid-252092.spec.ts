import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { ReadyForBillStatusTcId252092 } from './scenarios/tcid-252092.sc';

// SHIFT + ALT + O - Organizing the import
/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verifying Insurance for user with all access, view and modify access and view access in patient demographics
 * Precondition -
 * Create 5 Patients and 1 Insurance.
 * Patient Case1 : Name: PLName252092_1, PFName252092_1; Insurance: ACarrier252092.
 * Patient Case2 : Name: PLName252092_2, PFName252092_2; Guarantor: Self.
 * Patient Case3 : Name: PLName252092_3, PFName252092_3; Insurance: ACarrier252092.
 * Patient Case4 : Name: PLName252092_4, PFName252092_4; Insurance: ACarrier252092.
 * Patient Case5 : Name: PLName252092_5, PFName252092_5; Insurance: ACarrier252092.
 *
 * Script Execution Approach -
 * 1. Login to the application with given user 1.
 * 2. For Patient 1, complete payment for charge 1 and verify case status in transaction page and facesheet page.
 * 3. For Patient 1, complete payment for charge 2 and verify case status in transaction page and facesheet page.
 * 4. For Patient 2, complete payment for both the charges and verify case status in transaction page.
 * 5. Verify patient status and billed statements in patient statement tracker.
 * 6. For patient 3, in charge entry, uncheck generate bill and make ready for bill and verify the status in transaction and facesheet pages.
 * 7. For patient 3, add one more charge in my tasks charge entry without generate bill checked and verify case status.
 * 8. In insurance billing tracker, complete Bill for Selected Payment and check the status in transaction and facesheet pages.
 * 9. For Patient 4, complete charge entry by unchecking GB for 1st charge and checking for 2nd charge.
 * 10. Complete payment for charge 2 and verify case status in transaction and facesheet pages.
 * 11. For Patient 5, complete payment for both the charges and delete payment for 2nd charge.
 * 12. Navigate to RCM Tracker, verify system billed icon and data in Billing History.
 * 13. Close Billing History and click Claim Status button and verify system billed icon.
 * 14. Logout
 ************************************************************************/

/* instance variables */
const readyForBillStatus = new ReadyForBillStatusTcId252092();

describe(
  'Verify the Case Status after performing different transactions for different Charges',
  {
    tags: ['facesheet', 'US#266719', 'TC#252092'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        readyForBillStatus.verifyCaseStatusWithTwoProcAndPI();
        readyForBillStatus.verifyCaseStatusWithGuarantor();
        readyForBillStatus.verifyCaseStatusAfterInsuranceBilling();
        readyForBillStatus.verifyCaseStatusWhenPartiallyBilled();
        readyForBillStatus.verifyPatientInRCMTracker();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
