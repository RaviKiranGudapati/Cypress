import { UserList } from '../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';
import { LedgerAutoAllocationInTcId278107 } from './scenarios/tcid-278107.sc';

/* instance variables */
const ledgerFacesheet = new LedgerAutoAllocationInTcId278107();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into application and navigate to Patient Facesheet > Add UP amount
 * 2. Click on allocate amount and allocate to last row charge
 * 3. Verify that allocation is zero to the first charge
 * 4. Navigate to RCM Tracker and allocate amount to last row charge
 * 5. Verify that allocation amount is zero to the first charge
 * 6. Navigate to Remittance Posting Tracker > Manual remittance
 * 7. Update remittance details and select charge
 * 8. Allocate UP amount to last row charge
 * 9. Verify that allocation amount is zero to the first charge
 * 10. Logout from application
 */

describe(
  'Verify unassigned payment amount is not automatically allocated to the same charge with different DOS',
  {
    tags: ['facesheet', 'rcm', 'remittance-posting', 'TC#278107', 'US#277460'],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        ledgerFacesheet.autoAllocationUPAmount();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
