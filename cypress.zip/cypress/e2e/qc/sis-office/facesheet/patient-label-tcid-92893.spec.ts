import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { PatientLabelTcId92893 } from './scenarios/tcid-92893.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/*instance variables*/
const patientLabel = new PatientLabelTcId92893();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login to the application and select patient in masthead
 * 2. Selecting Print Icon in cases
 * 3. Select Patient Labels option and click on Preview
 * 4. Verify the default options and values available in Patient Labels popup
 * 5. Enter Maximum input for #LabelsPerPatient, #BeginRow, #Begin Column and verify the Preview section
 * 6. Enter More than maximum values in #LabelsPerPatient, #BeginRow, #Begin Column and verify the Preview section
 * 7. Change #BeginRow and #Begin Column respectively and verify the Preview section
 * 8. Click close Icon in print popup
 * 9. Click on Print icon and select patient demographic form and click on preview button for different cases
 * 10. And verify that it should open up  a preview  with just the patient's form for that patient's case.
 * 11. Logout from application
 */

describe(
  'Verify Patient labels, demographics a component in Facesheet',
  { tags: ['facesheet', 'TC#92893', 'US#266915'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_3, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        patientLabel.verifyPatientLabelsInFacesheet();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
