import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { CaseHeaderTcId261978 } from './scenarios/tcid-261978.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/*instance variables*/
const caseHeader = new CaseHeaderTcId261978();

/**********************Test Script Validation Details *************************
 * 1. Login to application  and click on newly created patient from cases to code tracker
 * 2. Verify patient DOS, procedures details, case status in case header and Select ready for charge as Yes after mandatory fields are entered.
 * 3. Navigate to Charge entry tracker. Click on patient name and Verify patient DOS, procedures details, case status in case header. Select ready to bill as yes after mandatory           fields are entered
 * 4. Navigate to financial clearance tracker. Click on patient name and Verify patient DOS, procedures details, case status in case header.
 * 5. Navigate to Inventory reconciliation. Click on patient name and Verify patient DOS, procedures details, case status in case header.
 * 6. Search patient in MastHead and click on patient name. Click on Transactions and Verify patient DOS, procedures details, case status in case header.
 * 7. Click on charge entry under My Tasks and Verify patient DOS, procedures details, case status in case header.
 * 8.  Click on coding under My Tasks and Verify patient DOS, procedures details, case status in case header.
 * 9. Click on case details under My Tasks and Verify patient DOS, procedures details, case status in case header.
 * 10. Click on forms and consents My Tasks and Verify patient DOS, procedures details, case status in case header.
 * 11. Click on attachments under My Tasks and Verify patient DOS, procedures details, case status in case header.
 * 12. Click on Insurance Verification under My Tasks and Verify patient DOS, procedures details, case status in case header.
 * 13. Click on Payer Details under My Tasks and Verify patient DOS, procedures details, case status in case header.
 * 14. Logout from application
 */

describe(
  'To verify the patient DOS, Procedure Description, Case status, MRN number in schedule grid Trackers and My Task trackers',
  { tags: ['facesheet', 'TC#261978', 'US#262534'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      // /****Open the URL as defined in baseUrl in Cypress Configuration File Or CLI flag - --config baseUrl ********/
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        caseHeader.verifyCaseHeader();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
