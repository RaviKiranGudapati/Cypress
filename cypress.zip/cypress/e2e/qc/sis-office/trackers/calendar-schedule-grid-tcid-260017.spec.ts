import SISOfficeDesktop from '../../../../support/common-core-libs/application/sis-office-desktop';

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import SISCompleteLogin from '../../../../app-modules-libs/sis-office/login/login';

import { ScheduleGridCalenderTcid260017 } from './scenarios/tcid-260017.sc';

/* instance variables */
const scheduleGridCalendar = new ScheduleGridCalenderTcid260017();
const login = new SISCompleteLogin();
const sisOfficeDesktop = new SISOfficeDesktop();

/* Test Script Validation Details *****
 * Script Execution Details -
 * Verifying Calendar In SIS charts Business Desktop
 * Taken from TC - SIS charts - Workflows Test Protocol ID: 965932 Heading42/ ID:   1039574
 * Workflow:
 * 1005201-Business Desktop: Hook Up Date Picker For Schedule
 * Script Execution Approach -
 * 1. Verify the calendar is available in Business Desktop
 * 2. Verify Date, month and Year in calendar
 * 3. Verify Today Button, previous and Next arrows
 * 4. Verify Other Month Dates are greyed out in calendar
 * 5. Select Dates and verify results
 */

describe(
  'Verifying Calendar and Date picker available in Schedule Grid In SIS Business Desktop',
  { tags: ['trackers', 'calendar', 'SC#1573'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      Cypress.on('uncaught:exception', (error, runnable) => {
        return false;
      });
      /****Open the URL as defined in baseUrl in Cypress Configuration File Or CLI flag - --config baseUrl ********/
      cy.visit('/');
      /**********Login To Application***********/
      login.login(
        UserList.GEM_USER_8[0],
        UserList.GEM_USER_8[1],
        OrganizationList.GEM_ORG_8
      );
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisOfficeDesktop.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {
        scheduleGridCalendar.verifyCalenderUI();
      }
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        scheduleGridCalendar.verifyCalenderFunctionality();
        scheduleGridCalendar.verifyUnselectedWorkingDays();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
