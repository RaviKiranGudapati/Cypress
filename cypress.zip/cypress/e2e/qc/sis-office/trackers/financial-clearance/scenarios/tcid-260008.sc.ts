import {
  Application,
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_amount_verification_tcid_260008 } from '../../../../../../fixtures/sis-office/trackers/financial-clearance/amount-verification-tcid-260008.td';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import FinancialClearance from '../../../../../../app-modules-libs/sis-office/trackers/fin-clearance';

import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const financialClearance = new FinancialClearance();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase(
  td_amount_verification_tcid_260008.PatientCase
);

/* const values */
const patient =
  td_amount_verification_tcid_260008.PatientCase.PatientDetails.LastName +
  `, ` +
  td_amount_verification_tcid_260008.PatientCase.PatientDetails
    .PatientFirstName;

export class FinancialClearanceTrackerTcId260008 {
  selectPatientInTracker() {
    sisOfficeDesktop.selectTracker(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.FINANCIAL_CLEARANCE[0]
    );

    financialClearance.selectPatientRow(
      td_amount_verification_tcid_260008.PatientCase.PatientDetails,
      false
    );

    financialClearance.waitForFCPageToLoad();
  }

  selectBillingAndPaymentInCheckIn() {
    sisOfficeDesktop.selectSisLogo();
    sisOfficeDesktop.selectScheduleType(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
        .BLOCK_SCHEDULE[0]
    );
    sisOfficeDesktop.selectScheduleType(
      OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE.SCHEDULE_GRID[0]
    );
    cy.cRemoveMaskWrapper(Application.office);
    scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
      patient,
      OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
    );

    createCase.selectBillingAndPayment();
  }

  verifyInsuranceAmountInCheckIn() {
    describe('Verifying Primary Insurance amount in Billing and Payment Under Check-in After updating the PI amount in Financial Clearance Tracker', () => {
      it('Verifying that PI Amount deposit value is displayed in Amount Due Field under Billing and Payment', () => {
        cy.cGroupAsStep(
          'selecting the patient from Financial Clearance tracker'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        this.selectPatientInTracker();

        // #region - Enter Primary Insurance Deposit Amount
        cy.cGroupAsStep(
          'Expanding Primary Insurance and entering the Deposit Amount'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);

        financialClearance.enterPIDepositAmount(
          td_amount_verification_tcid_260008.CarrierDetails1.Primary
        );
        // #endregion

        // #region - Enter Secondary Insurance Deposit Amount
        cy.cGroupAsStep(
          'Expanding Secondary Insurance and entering the Deposit Amount'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        financialClearance.enterSIDepositAmount(
          td_amount_verification_tcid_260008.CarrierDetails1.Secondary
        );
        // #endregion

        cy.cGroupAsStep('Click Done button in financial clearance tracker');
        sisOfficeDesktop.clickDoneButton();

        cy.cGroupAsStep(
          'Navigating to Schedule Grid, Click Check-In for the same patient and navigate to Billing and Payment'
        );
        this.selectBillingAndPaymentInCheckIn();

        cy.cGroupAsStep(
          'Verify Primary Insurance Amount entered in FC Tracker is updated in Deposit Amount field'
        );
        createCase.verifyAmountDue(
          td_amount_verification_tcid_260008.CarrierDetails1.Primary
            .DepositAmount
        );

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();
      });
    });
  }

  verifyAmountDueIsEditable() {
    describe('Verify whether Amount Due is editable in Billing & Payment task if no Deposit Amount is added in financial clearance tracker.', () => {
      it('Verifying that Amount Due Field is editable when there is no value present', () => {
        cy.cGroupAsStep(
          'selecting the patient from Financial Clearance tracker'
        );
        this.selectPatientInTracker();

        cy.cGroupAsStep(
          'Expanding Primary Insurance and removing the Deposit Amount'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        financialClearance.removeDepositAmount();

        cy.cGroupAsStep(
          'Expanding Secondary Insurance and entering the Deposit Amount'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        financialClearance.removeSiDepositAmount();

        cy.cGroupAsStep('Click Done button in financial clearance tracker');
        sisOfficeDesktop.clickDoneButton();

        cy.cGroupAsStep(
          'Navigating to Schedule Grid, Click Check-In for the same patient and navigate to Billing and Payment'
        );
        this.selectBillingAndPaymentInCheckIn();

        cy.cGroupAsStep(
          'Verify Blank value is there in Deposit Amount field since we removed Primary Insurance Amount in FC Tracker'
        );
        createCase.verifyAmountDue('');

        cy.cGroupAsStep(
          'Verify Deposit Amount field is editable since no value is available in FC Tracker for Primary Insurance Amount field'
        );
        createCase.verifyAmountDueIsEditable();

        cy.cGroupAsStep('Enter amount in Deposit Amount field');
        createCase.enterAmountDue(
          td_amount_verification_tcid_260008.AmountDueDetails.AmountDue
        );

        cy.cGroupAsStep('Update all the required details in Payment Details');
        createCase.paymentDetails(
          td_amount_verification_tcid_260008.AmountDueDetails
        );

        cy.cGroupAsStep('Click Print Receipt and cancel it');
        createCase.printReceipt();

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();
      });
    });
  }
  verifyAmountDueIsOverridden() {
    describe('Verify the initial check-in amount has been overridden In Billing & Payment Task by updating PI Deposit Amount In FC Tracker', () => {
      it('Verifying that Amount Due Field value can be overwritten by Financial Clearance amount value', () => {
        cy.cGroupAsStep(
          'selecting the patient from Financial Clearance tracker'
        );
        this.selectPatientInTracker();

        cy.cGroupAsStep(
          'Expanding Primary Insurance and entering the Deposit Amount'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        financialClearance.enterPIDepositAmount(
          td_amount_verification_tcid_260008.CarrierDetails2.Primary
        );

        cy.cGroupAsStep(
          'Expanding Secondary Insurance and entering the Deposit Amount'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        financialClearance.enterSIDepositAmount(
          td_amount_verification_tcid_260008.CarrierDetails2.Secondary
        );

        cy.cGroupAsStep('Click Done button in financial clearance tracker');
        sisOfficeDesktop.clickDoneButton();

        cy.cGroupAsStep(
          'Navigating to Schedule Grid, Click Check-In for the same patient and navigate to Billing and Payment'
        );
        this.selectBillingAndPaymentInCheckIn();

        cy.cGroupAsStep(
          'Verify Primary Insurance Amount entered in FC Tracker is updated in Deposit Amount field'
        );
        createCase.verifyAmountDue(
          td_amount_verification_tcid_260008.CarrierDetails2.Primary
            .DepositAmount
        );

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();
      });
    });
  }

  verifyAmountDueWhenVerificationToggleYes() {
    describe('Verify whether Amount Due is read-only In Billing & Payment Task after updating Verification Complete as Yes in financial clearance tracker', () => {
      it('Verifying that Amount due Field is not editable In Billing & Payment Task after updating Verification Complete as Yes', () => {
        cy.cGroupAsStep(
          'selecting the patient from Financial Clearance tracker'
        );
        this.selectPatientInTracker();

        financialClearance.waitForFCPageToLoad();

        cy.cGroupAsStep('Update Verification as Yes in FC Tracker');
        financialClearance.verificationCompleteToggle(YesOrNo.yes);

        cy.cGroupAsStep('Click Done button in financial clearance tracker');
        sisOfficeDesktop.clickDoneButton();

        cy.cGroupAsStep(
          'Navigating to Schedule Grid, Click Check-In for the same patient and navigate to Billing and Payment'
        );
        this.selectBillingAndPaymentInCheckIn();

        cy.cGroupAsStep(
          'Verify Deposit Amount in Billing and Payment is non-editable'
        );
        createCase.verifyAmountDueIsEditable(false);

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();
      });
    });
  }

  verifyAdditionalClaimInfoInCheckIn() {
    describe('Verifying Additional Claim Info Fields In Billing & Payments Task for Check-In Patient Case', () => {
      it('Verifying Additional Claim Info details for Automobile Medical Insurance', () => {
        cy.cGroupAsStep(
          'Navigating to Schedule Grid, Click Check-In for the same patient and navigate to Billing and Payment'
        );
        this.selectBillingAndPaymentInCheckIn();

        cy.cGroupAsStep('Remove Secondary Insurance in Billing & Payment');
        createCase.removeInsurance(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .SECONDARY_INSURANCE[0]
        );

        cy.cGroupAsStep('Verify Additional Claim Info is Expanded');
        createCase.verifyAdditionalClaimInfoIsExpanded();

        cy.cGroupAsStep(
          'Navigate to Patient Details and back to Billing & Payment to make sure additional claim info is still expanded'
        );
        createCase.selectPatientDetails();
        createCase.selectBillingAndPayment();
        createCase.verifyAdditionalClaimInfoIsExpanded();

        cy.cGroupAsStep(
          'Click Accident Date Calendar and verify future dates are disabled'
        );
        createCase.clickOnAccidentDateCalendar();
        createCase.verifyNextDayIsDisabled();

        cy.cGroupAsStep('Update all the additional claim information');
        createCase.selectAdditionalClaimInformation(
          td_amount_verification_tcid_260008.AdditionalClaimInfo
        );

        cy.cGroupAsStep('Click Done button in check-in');
        createCase.clickCheckInDone();

        cy.cGroupAsStep(
          'Select patient and click check-in and navigate to Billing & Payment'
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.selectBillingAndPayment();

        cy.cGroupAsStep(
          'Verify Additional Claim Info is not expanded and check mark is present'
        );
        createCase.verifyAdditionalClaimInfoIsExpanded(false);
        createCase.verifyAdditionalClaimCheckMark();

        cy.cGroupAsStep('Remove Primary Insurance in Billing & Payment');
        createCase.removeInsurance(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.BILLING_DETAILS
            .PRIMARY_INSURANCE[0]
        );

        cy.cGroupAsStep(
          'Verify Additional Claim Check Mark Not Present post removal of primary insurance'
        );
        createCase.verifyAdditionalClaimCheckMark(false);
      });
    });
  }
}
