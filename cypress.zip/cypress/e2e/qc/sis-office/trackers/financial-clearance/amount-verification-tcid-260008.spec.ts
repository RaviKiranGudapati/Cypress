import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { FinancialClearanceTrackerTcId260008 } from './scenarios/tcid-260008.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const finClearanceTracker = new FinancialClearanceTrackerTcId260008();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation
 * 1. Verify whether Amount Due is editable in Billing & Payment task if no Deposit Amount is added in financial clearance tracker.
 * 2. Verify only Primary Insurance value entered in financial clearance tracker is included in Billing & Payment task and secondary Insurance is not included.
 * 3. Verify the initial check-in amount has been overridden by primary insurance Deposit Amount
 * 4. Verify whether Amount Due is read-only when verification is completed in financial clearance tracker.
 * 5. Verify that an "Additional Claim Information" link by default expanded on selecting an insurance carrier with the classification of Automobile Medical/ Worker's Comp.
 * 6. Verify Additional Claim Information has been removed when Primary Insurance removed.
 * 7. Logout from application
 */

describe(
  'Verify Amount Due field and Additional Claim Information Fields in check-in for Patient Case in Schedule Grid',
  {
    tags: [
      'trackers',
      'financial-clearance',
      'amount-due',
      'US#260247',
      'TC#260008',
      'SC#2084',
      'SC#1739',
    ],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        // Verifying PI amount from Financial Tracker to be displayed in Billing and Payment
        finClearanceTracker.verifyInsuranceAmountInCheckIn();
        // Verify whether Amount Due is editable in Billing & Payment task if no Deposit Amount is added in financial clearance tracker.
        finClearanceTracker.verifyAmountDueIsEditable();
        // Verify the initial check-in amount has been overridden by primary insurance Deposit Amount
        finClearanceTracker.verifyAmountDueIsOverridden();
        // Verify whether Amount Due is read-only when verification is completed in financial clearance tracker
        finClearanceTracker.verifyAmountDueWhenVerificationToggleYes();
        // Verifying Additional Claim Info In Check In
        finClearanceTracker.verifyAdditionalClaimInfoInCheckIn();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
