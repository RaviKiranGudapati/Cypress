import { td_charge_entry_tcid_29389 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/charge-entry-tcid-29389.td';

import {
  Application,
  ExpandOrCollapse,
  HierarchyOptions,
} from '../../../../../../support/common-core-libs/application/common-core';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_CHARGE_ENTRY } from '../../../../../../app-modules-libs/sis-office/trackers/or/charge-entry.or';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const createCase = new CreateCase(td_charge_entry_tcid_29389.PatientCase[0]);
const createCase1 = new CreateCase(td_charge_entry_tcid_29389.PatientCase[1]);
const createCase2 = new CreateCase(td_charge_entry_tcid_29389.PatientCase[2]);
const sisChartsDesktop = new SISChartsDesktop();
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const chargeEntry1 = new ChargeEntry(createCase1.patientCaseModel!);
const nursingConfiguration = new NursingConfiguration();
const chargeEntry2 = new ChargeEntry(createCase2.patientCaseModel!);
const sisOfficeDesktop = new SISOfficeDesktop();

export class ChargeEntryTrackerTcId29389 {
  verifyWriteOffAndTotalCharge() {
    describe('Verify contractual data WriteOff added to the contracts is correctly displayed on the Charge Entry Screen based on the insurance', () => {
      it('Verify WriteOff & No WriteOff Present And Total Charge By Removing and adding Primary Insurance', () => {
        // #region Navigating application setting and opening the contracts from front end

        cy.cGroupAsStep(
          'Navigating application setting and opening the contracts from front end'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_29389.ContractInfo[0]
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_29389.ContractInfo[1]
        );
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_29389.ContractInfo[2]
        );
        // #endregion

        // #region Validating Write-off for Patient case row in Charge Entry

        cy.cGroupAsStep(
          'Validating Write-off for Patient case row in Charge Entry'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );

        chargeEntry.selectCase(td_charge_entry_tcid_29389.ChargeDetails);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.validateWriteOff(
          td_charge_entry_tcid_29389.AmountsProcedures[0].WriteOff
        );
        // #endregion

        // #region Step-2 : Removing primary Insurance and verifying balance

        cy.cGroupAsStep('Removing primary Insurance and verifying balance');
        chargeEntry.removeInsurance(HierarchyOptions.primary);
        cy.cRemoveMaskWrapper(Application.office);
        chargeEntry.verifyNoChargeResults();
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_29389.AmountsProcedures[0].TotalCharge
        );
        // #endregion

        // #region Step-3 : Adding primary Insurance and verifying balance

        cy.cGroupAsStep('Adding primary Insurance and verifying balance');
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.addInsurance(
          HierarchyOptions.primary,
          td_charge_entry_tcid_29389.PatientCase[0].BillingDetails
            .PrimaryInsurance
        );
        cy.cRemoveMaskWrapper(Application.office);
        chargeEntry.validateWriteOff(
          td_charge_entry_tcid_29389.AmountsProcedures[0].WriteOff
        );
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_29389.AmountsProcedures[0].Balance
        );
        // #endregion

        // #region Step-4 :  ExpandOrCollapse.expanding the procedure code-2 and verifying write off and balance amount based on primary insurance

        cy.cGroupAsStep(
          'expanding the procedure code-2 and verifying write off and balance amount based on primary insurance'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.validateWriteOff(
          td_charge_entry_tcid_29389.AmountsProcedures[1].WriteOff
        );
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_29389.AmountsProcedures[1].Balance
        );
        // #endregion
      });
    });
  }

  verifyBalanceWriteOffAndTotalCharge() {
    describe('Verify Write Off Not Present And Total Charge By Removing Primary Insurance For 2nd Time', () => {
      it('Verify Write Off Not Present And Total Charge By Removing Primary Insurance For 2nd Time', () => {
        // #region step-5 Removing Primary Insurance For 2nd Time

        cy.cGroupAsStep('Removing Primary Insurance For 2nd Time');
        chargeEntry.removeInsurance(HierarchyOptions.primary);
        cy.cRemoveMaskWrapper(Application.office);
        chargeEntry.verifyNoChargeResults();
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_29389.AmountsProcedures[1].TotalCharge
        );
        cy.cRemoveMaskWrapper(Application.office);
        // #endregion

        // #region Validating write-off and making case ready for Billing

        cy.cGroupAsStep(
          'Validating write-off and making case ready for Billing'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.addInsurance(
          HierarchyOptions.primary,
          td_charge_entry_tcid_29389.PatientCase[0].BillingDetails
            .PrimaryInsurance
        );
        chargeEntry.validateWriteOff(
          td_charge_entry_tcid_29389.AmountsProcedures[1].WriteOff
        );
        cy.cRemoveMaskWrapper(Application.office);
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_29389.AmountsProcedures[1].Balance
        );
        //Collapsing procedure-2
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        cy.cClick(
          OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[1],
          OR_CHARGE_ENTRY.CHARGE_ENTRY.READY_FOR_BILL_YES_BUTTON[0]
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion
      });
    });
  }

  verifyWriteOffNotDisplayed() {
    describe('Verify Write Off Should Not Be Displayed For Second Patient', () => {
      it('Verify Write Off Not Present After ExpandOrCollapse Procedure1 and Procedure 2 for Second Patient', () => {
        // #region step-7 : Select patient_2 and verify writeoff should not displayed

        cy.cGroupAsStep(
          'Select patient_2 and verify writeoff should not displayed'
        );
        chargeEntry1.selectCase(td_charge_entry_tcid_29389.ChargeDetails);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region Step-8 : Expand procedure-2 and verify writeoff should not displayed

        cy.cGroupAsStep(
          'Expand procedure-2 and verify writeoff should not displayed'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        // #endregion
      });
    });
  }

  verifyWriteOffAndBalance() {
    describe('Verify WriteOff And Balance For 3rd Patient for two procedures', () => {
      it('Verify Write Off and Balance After ExpandOrCollapse Procedure1 and Procedure 2 for third Patient', () => {
        // #region Step-9 : Select patient_3 and verify writeoff and balance amount

        cy.cGroupAsStep(
          'Select patient_3 and verify writeoff and balance amount'
        );
        sisOfficeDesktop.clickDoneButton();
        chargeEntry2.selectCase(td_charge_entry_tcid_29389.ChargeDetails);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry.validateWriteOff(
          td_charge_entry_tcid_29389.AmountsProcedures[0].WriteOff
        );
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_29389.AmountsProcedures[0].Balance
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region Step-10 : Expand procedure-2 and verify writeoff and balance amount

        cy.cGroupAsStep(
          'Expand procedure-2 and verify writeoff and balance amount'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        chargeEntry.validateWriteOff(
          td_charge_entry_tcid_29389.AmountsProcedures[1].WriteOff
        );
        chargeEntry.verifyBalance(
          td_charge_entry_tcid_29389.AmountsProcedures[1].Balance
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);
        sisOfficeDesktop.clickDoneButton();
        // #endregion
      });
    });
  }
}
