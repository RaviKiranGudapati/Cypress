import { ExpandOrCollapse } from '../../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_charge_entry_tcid_265365 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/additional-claim-info-tcid-265365.td';

import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';

/* instance variables */
const createCase = new CreateCase(td_charge_entry_tcid_265365.PatientCase[0]);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();

export default class ChargeEntryTcId265365 {
  verifyFieldsInAdditionalClaimInfo() {
    describe('Verify the date and label fields in UB/HCFA tabs under Additional Claim Information', () => {
      it('Verifying the date and label fields in UB HCFA tabs', () => {
        // #region Navigating to charge entry tracker and selecting patient

        cy.cGroupAsStep(
          'Navigating to charge entry tracker and selecting patient'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        combinedCoding.verifyPatientRow(
          td_charge_entry_tcid_265365.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        chargeEntry.selectCase(td_charge_entry_tcid_265365.Charges);

        // #endregion

        // #region Entering data for HCFA fields in additional claim info window

        cy.cGroupAsStep(
          'Entering data for HCFA fields in additional claim info window'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.enterDataInHcfaFields(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_INSTITUTIONAL[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.enterDataInHcfaFields(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[1]
        );
        combinedCoding.addHcfaAdditionalClaimSupplementalInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[0]
        );
        combinedCoding.addHcfaAdditionalClaimNotesInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[0]
        );
        combinedCoding.clickCodeFieldsTrashIconHCFA(0, 2);
        combinedCoding.addHcfaAdditionalClaimNotesInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_INSTITUTIONAL[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );

        // #endregion

        // #region Verifying data for HCFA fields in additional claim info window

        cy.cGroupAsStep(
          'Verifying data for HCFA fields in additional claim info window'
        );
        combinedCoding.verifyHcfaDateFields();
        combinedCoding.verifyClaimSupplementalInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[1]
        );
        combinedCoding.verifyClaimNoteInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[1]
        );
        combinedCoding.addHcfaAdditionalClaimNotesInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[0]
        );
        combinedCoding.clickCodeFieldsTrashIconHCFA(0, 2);
        combinedCoding.addHcfaAdditionalClaimNotesInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_INSTITUTIONAL[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );

        // #endregion

        // #region Verifying data for HCFA fields in additional claim info window

        cy.cGroupAsStep(
          'Verifying data for HCFA fields in additional claim info window'
        );
        combinedCoding.verifyHcfaDateFields();
        combinedCoding.verifyClaimSupplementalInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[1]
        );
        combinedCoding.verifyClaimNoteInfo(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[1]
        );

        // #endregion

        // #region Entering data for UB fields in additional claim info window

        cy.cGroupAsStep(
          'Entering data for UB fields in additional claim info window'
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_INSTITUTIONAL[0]
        );
        combinedCoding.enterDataInUbFields(
          td_charge_entry_tcid_265365.UBAdditionalClaim[0]
        );
        // #endregion

        // #region Verifying data for UB fields in additional claim info window

        cy.cGroupAsStep(
          'Verifying data for UB fields in additional claim info window'
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_charge_entry_tcid_265365.UBAdditionalClaim[0]
        );
        // #endregion

        // #region Verify clinical trial number info after clicking on done

        cy.cGroupAsStep(
          'Verify clinical trial number info after clicking on done'
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.selectAdditionalClaimInfoDone();
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.verifyClinicalTrial(
          td_charge_entry_tcid_265365.HCFAAdditionalClaim[1].ClinicalTrail
        );
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion
      });
    });
  }
}
