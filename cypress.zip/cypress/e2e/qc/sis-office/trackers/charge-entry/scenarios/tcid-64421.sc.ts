import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ExpandOrCollapse,
  HierarchyOptions,
  ProcedureType,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_contract_grouper_ce_tcid_64421 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/contract-grouper-ce-tcid-64421.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const createCase1 = new CreateCase(
  td_contract_grouper_ce_tcid_64421.PatientCase[0]
);
const createCase2 = new CreateCase(
  td_contract_grouper_ce_tcid_64421.PatientCase[1]
);
const createCase3 = new CreateCase(
  td_contract_grouper_ce_tcid_64421.PatientCase[2]
);
const createCase4 = new CreateCase(
  td_contract_grouper_ce_tcid_64421.PatientCase[3]
);
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const nursingConfiguration = new NursingConfiguration();
const chargeEntry1 = new ChargeEntry(createCase1.patientCaseModel!);
const chargeEntry2 = new ChargeEntry(createCase2.patientCaseModel!);
const chargeEntry3 = new ChargeEntry(createCase3.patientCaseModel!);
const chargeEntry4 = new ChargeEntry(createCase4.patientCaseModel!);

/* const values */
const num = '400';

export class ContractGrouperTcId64421 {
  contractGrouper() {
    describe('Verify the When Supply charges are posted in charge Entry and Calculations for each pricing type ', () => {
      it('Verify the When Supply charges are posted in charge Entry and Calculations for each pricing type', () => {
        // #region Navigating application setting and opening the 1st contract from front end

        cy.cGroupAsStep(
          'Navigating application setting and opening the contracts from front end'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.searchContractOptions(
          td_contract_grouper_ce_tcid_64421.ContractInfo[0]
        );
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[0].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.no_write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[1].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[2].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.selectExemptTypeInContract(YesOrNo.yes);
        nursingConfiguration.enterDetails(num);
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[3].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.selectExemptTypeInContract(YesOrNo.yes);
        // #endregion

        // #region opening the 2nd contracts from front end

        nursingConfiguration.searchContractOptions(
          td_contract_grouper_ce_tcid_64421.ContractInfo[1]
        );
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[5].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.no_write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[1].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[2].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.selectExemptTypeInContract(YesOrNo.yes);
        nursingConfiguration.enterDetails(num);
        nursingConfiguration.searchProcedureInContract(
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[3].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.selectExemptTypeInContract(YesOrNo.yes);
        // #endregion

        // #region Validating amount and Balance for 1st Patient in Charge Entry

        cy.cGroupAsStep(
          'Verifing amount and Balance for 1st Patient in Charge Entry'
        );
        sisOfficeDesktop.selectSisLogo();
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry1.selectCase(
          td_contract_grouper_ce_tcid_64421.ChargeDetails
        );
        chargeEntry1.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[4].CPTCodeAndDescription
        );
        chargeEntry1.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[0].Amount
        );
        chargeEntry1.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[0].Balance
        );
        chargeEntry1.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[4].CPTCodeAndDescription
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region Validating amount and Balance for 2nd Patient in Charge Entry

        cy.cGroupAsStep(
          'Verifing amount and Balance for 2nd Patient in Charge Entry'
        );
        chargeEntry2.selectCase(
          td_contract_grouper_ce_tcid_64421.ChargeDetails
        );
        chargeEntry2.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[4].CPTCodeAndDescription
        );
        chargeEntry2.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[0].Amount
        );
        chargeEntry2.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[0].Balance
        );
        chargeEntry2.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[4].CPTCodeAndDescription
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region Validating amount and Balance for 3rd Patient in Charge Entry

        cy.cGroupAsStep(
          'Verifing amount and Balance for 3rd Patient in Charge Entry'
        );
        chargeEntry3.selectCase(
          td_contract_grouper_ce_tcid_64421.ChargeDetails
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry3.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[1].Amount
        );
        chargeEntry3.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[1].Balance
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry3.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[2].Amount
        );
        chargeEntry3.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[2].Balance
        );
        chargeEntry3.validateWriteOff(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[2].WriteOff!
        );
        chargeEntry3.removeInsurance(HierarchyOptions.primary);
        chargeEntry3.clickBalanceLabel();
        chargeEntry3.verifyNoChargeResults();
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry3.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[3].Amount
        );
        chargeEntry3.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[3].Balance
        );
        chargeEntry3.validateWriteOff(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[3].WriteOff!
        );
        chargeEntry3.removeInsurance(HierarchyOptions.primary);
        chargeEntry3.clickBalanceLabel();
        chargeEntry3.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[4].Balance
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[3].CPTCodeAndDescription
        );
        chargeEntry3.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[4].Amount
        );
        chargeEntry3.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[4].Balance
        );
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[3].CPTCodeAndDescription
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        cy.cGroupAsStep(
          'Verifing amount and Balance for 4th Patient in Charge Entry'
        );
        chargeEntry4.selectCase(
          td_contract_grouper_ce_tcid_64421.ChargeDetails
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[5].CPTCodeAndDescription
        );
        chargeEntry4.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[1].Amount
        );
        chargeEntry4.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[1].Balance
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[5].CPTCodeAndDescription
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry4.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[2].Amount
        );
        chargeEntry4.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[2].Balance
        );
        chargeEntry4.validateWriteOff(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[2].WriteOff!
        );
        chargeEntry4.removeInsurance(HierarchyOptions.primary);
        chargeEntry4.clickBalanceLabel();
        chargeEntry4.verifyNoChargeResults();
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry4.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[3].Amount
        );
        chargeEntry4.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[3].Balance
        );
        chargeEntry4.validateWriteOff(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[3].WriteOff!
        );
        chargeEntry4.removeInsurance(HierarchyOptions.primary);
        chargeEntry4.clickBalanceLabel();
        chargeEntry4.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[4].Balance
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[3].CPTCodeAndDescription
        );
        chargeEntry4.verifyChargeAmount(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[4].Amount
        );
        chargeEntry4.verifyBalance(
          td_contract_grouper_ce_tcid_64421.AmountsProcedures[4].Balance
        );
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_contract_grouper_ce_tcid_64421.CptCodeInfo[3].CPTCodeAndDescription
        );
        sisOfficeDesktop.clickDoneButton();
        // #endregion
      });
    });
  }
}
