import { ExpandOrCollapse } from '../../../../../../support/common-core-libs/application/common-core';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_autosort_tcid_265313 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/autosort-tcid-265313.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import FaceSheetChargeEntry from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';

/* instance variables */
const sisChartsDesktop = new SISChartsDesktop();
const createCase = new CreateCase(td_autosort_tcid_265313.PatientCase[0]);
const createCase2 = new CreateCase(td_autosort_tcid_265313.PatientCase[1]);
const sisOfficeDesktop = new SISOfficeDesktop();
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const chargeEntry2 = new ChargeEntry(createCase2.patientCaseModel!);
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const nursingConfiguration = new NursingConfiguration();
const faceSheetCases = new FaceSheetCases();

export class ChargeEntryAutoSortTcId265313 {
  verifyAutoSortFunctionality() {
    describe('Verify auto-sort functionality in charge entry tracker', () => {
      it('Verify the sort order of the charges after applying auto sort', () => {
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #region Navigating application setting and opening the contracts from front end

        cy.cGroupAsStep(
          'Navigating application setting and opening the contracts from front end'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.searchContractOptions(
          td_autosort_tcid_265313.ContractInfo[0]
        );
        nursingConfiguration.searchContractOptions(
          td_autosort_tcid_265313.ContractInfo[1]
        );
        // #endregion

        // #region Navigating to charge entry tracker and verifying autosort button

        cy.cGroupAsStep(
          'Navigating to charge entry tracker and verifying autosort button'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(td_autosort_tcid_265313.ChargeDetails);
        faceSheetChargeEntry.verifyOnAutoSortButton();

        faceSheetChargeEntry.clickOnAutoSort();
        // #endregion

        // #region Verifying the charge amount after clicking on the auto sort button

        cy.cGroupAsStep(
          'Verifying the charge amount after clicking on the auto sort button'
        );
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[0].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[3].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[4].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[5].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        // #endregion

        // #region Verifying the charge amount after navigating to business desktop and navigating back to charge entry

        cy.cGroupAsStep(
          'Verifying the charge amount after navigating to business desktop and navigating back to charge entry'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(td_autosort_tcid_265313.ChargeDetails);
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[0].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[3].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[4].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[5].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[1].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.clickReadyForBillAndDoneButton();

        // #endregion

        // #region Verifying the state of auto sort button in facesheet charge entry

        cy.cGroupAsStep(
          'Verifying the state of auto sort button in facesheet charge entry'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_autosort_tcid_265313.PatientCase[0].PatientDetails
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);

        faceSheetChargeEntry.verifyOnAutoSortButton(false);

        // #endregion

        // #region Navigating to charge entry and updating the charge amount for the sorted procedures for second patient

        cy.cGroupAsStep(
          'Navigating to charge entry and updating the charge amount for the sorted procedures for second patient'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry2.selectCase(td_autosort_tcid_265313.ChargeDetails);
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[4].CPTCodeAndDescription
        );

        chargeEntry.enterChargeAmount(
          td_autosort_tcid_265313.AmountDetails[3].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[5].CPTCodeAndDescription
        );

        chargeEntry.enterChargeAmount(
          td_autosort_tcid_265313.AmountDetails[6].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region Verifying auto sort functionality for updated charges

        cy.cGroupAsStep(
          'Verifying auto sort functionality for updated charges'
        );
        faceSheetChargeEntry.clickOnAutoSort();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[4].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[3].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[5].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[6].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[4].CPTCodeAndDescription
        );
        chargeEntry.enterDebitAmount(
          td_autosort_tcid_265313.AmountsProcedures.Amount
        );
        // #endregion

        // #region Verifying the auto sort functionality after adding new procedure and performing drag n drop

        cy.cGroupAsStep(
          'Verifying the auto sort functionality after adding new procedure and performing drag n drop'
        );
        chargeEntry.addProcedure(td_autosort_tcid_265313.CptCodeInfo[0]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        faceSheetChargeEntry.dragAndDropCharges(
          td_autosort_tcid_265313.CptCodeInfo[0].CPTCodeAndDescription,
          td_autosort_tcid_265313.CptCodeInfo[4].CPTCodeAndDescription
        );
        faceSheetChargeEntry.clickOnAutoSort();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[4].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[3].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[0].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_autosort_tcid_265313.CptCodeInfo[5].CPTCodeAndDescription
        );
        chargeEntry.verifyChargeAmount(
          td_autosort_tcid_265313.AmountDetails[6].Amount
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion
      });
    });
  }
}
