import {
  ExpandOrCollapse,
  HierarchyOptions,
  ProcedureType,
} from '../../../../../../support/common-core-libs/application/common-core';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_charge_entry_tcid_77097 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/multiple-contracts-grouper-tcid-77097.td';

import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';

/* instance variables */
const createCase1 = new CreateCase(td_charge_entry_tcid_77097.PatientCase[0]);
const createCase2 = new CreateCase(td_charge_entry_tcid_77097.PatientCase[1]);
const createCase3 = new CreateCase(td_charge_entry_tcid_77097.PatientCase[2]);
const createCase4 = new CreateCase(td_charge_entry_tcid_77097.PatientCase[3]);
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfiguration = new NursingConfiguration();
const chargeEntry1 = new ChargeEntry(createCase1.patientCaseModel!);
const chargeEntry2 = new ChargeEntry(createCase2.patientCaseModel!);
const chargeEntry3 = new ChargeEntry(createCase3.patientCaseModel!);
const chargeEntry4 = new ChargeEntry(createCase4.patientCaseModel!);

/* const values */
const index = ['1', '2'];
const reimbursementAmount = ['2000', '500', '500'];

export class ContractGrouperTcId77097 {
  verifyGrouperReimbursementAmount() {
    describe('Verify Balance,Amount and Write Off after adding Insurance mapped with contract Reimbursement Amount in Charge Entry', () => {
      it('Verify the amount calculations was performing correctly based on the contracts in Charge Entry', () => {
        // #region Navigating application setting and Search Contract and add GrouperId in Review/Edit

        cy.cGroupAsStep(
          'Navigating to application setting and Search Contract and add GrouperId in Review/Edit'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.selectContractType(
          td_charge_entry_tcid_77097.ContractInfo[1],
          ProcedureType.grouper
        );
        nursingConfiguration.selectTabHeadingInContracts(
          OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.POSTING_OPTIONS[0]
        );
        nursingConfiguration.addFeeGroup(index[0], reimbursementAmount[0]);
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_77097.ContractInfo[1]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_77097.CptCodeInfo.CPTCodeAndDescription
        );
        nursingConfiguration.selectContractGrouperId(index[0]);
        nursingConfiguration.selectContractType(
          td_charge_entry_tcid_77097.ContractInfo[2],
          ProcedureType.grouper
        );
        nursingConfiguration.selectTabHeadingInContracts(
          OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.POSTING_OPTIONS[0]
        );
        nursingConfiguration.addFeeGroup(index[1], reimbursementAmount[1]);
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_77097.ContractInfo[2]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_77097.CptCodeInfo.CPTCodeAndDescription
        );
        nursingConfiguration.selectContractGrouperId(index[1]);
        nursingConfiguration.selectContractType(
          td_charge_entry_tcid_77097.ContractInfo[3],
          ProcedureType.grouper
        );
        nursingConfiguration.selectTabHeadingInContracts(
          OR_NURSING_CONFIGURATION.CONTRACTS.POSTING_OPTIONS.POSTING_OPTIONS[0]
        );
        nursingConfiguration.addFeeGroup(index[0], reimbursementAmount[1]);
        nursingConfiguration.searchContractOptions(
          td_charge_entry_tcid_77097.ContractInfo[3]
        );
        nursingConfiguration.searchProcedureInContract(
          td_charge_entry_tcid_77097.CptCodeInfo.CPTCodeAndDescription
        );
        nursingConfiguration.selectContractGrouperId(index[0]);
        // #endregion
      });

      it('Verify the amount calculations was performing correctly for patient1 based on the contracts with Effective Date as Current Date 30 days and Expiration Date as Current Date 30 days in Charge Entry', () => {
        // #region Navigating to Business Desktop Tracker Charge Entry and search Patient1 and Verify Balance amd Debit

        cy.cGroupAsStep(
          'Navigating to Business Desktop Tracker Charge Entry and search Patient1 and Verify Balance amd Debit'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry1.selectCase(td_charge_entry_tcid_77097.ChargeDetails);
        chargeEntry1.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_charge_entry_tcid_77097.CptCodeInfo.CPTCodeAndDescription
        );
        chargeEntry1.verifyBalance(
          td_charge_entry_tcid_77097.AmountsProcedures[0].Balance
        );
        chargeEntry1.verifyDebitAmount(
          td_charge_entry_tcid_77097.Debits[0].DebitAmount
        );
        // #endregion

        // #region Remove Insurance and Verify Balance amd Debit

        cy.cGroupAsStep('Remove Insurance and Verify Balance amd Debit');
        chargeEntry1.removeInsurance(HierarchyOptions.primary);
        chargeEntry1.verifyBalance(
          td_charge_entry_tcid_77097.AmountsProcedures[1].Balance
        );
        chargeEntry1.verifyDebitAmount(
          td_charge_entry_tcid_77097.Debits[1].DebitAmount
        );
        // #endregion

        // #region Add Insurance and Verify Balance amd Debit

        cy.cGroupAsStep('Add Insurance and Verify Balance amd Debit');

        chargeEntry1.addInsurance(
          HierarchyOptions.primary,
          td_charge_entry_tcid_77097.Charges.PrimaryInsurance
        );
        chargeEntry1.verifyBalance(
          td_charge_entry_tcid_77097.AmountsProcedures[0].Balance
        );
        chargeEntry1.verifyDebitAmount(
          td_charge_entry_tcid_77097.Debits[0].DebitAmount
        );
        // #endregion
      });

      it('Verify the amount calculations was performing correctly for patient2 based on the contract with Effective Date as Current Date 10 days and Expiration Date as Current Date 2 days in Charge Entry', () => {
        // #region Select patient2 and Verify Write Off

        cy.cGroupAsStep('Select patient2 and Verify Write Off');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry2.selectCase(td_charge_entry_tcid_77097.ChargeDetails);
        chargeEntry2.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_charge_entry_tcid_77097.CptCodeInfo.CPTCodeAndDescription
        );
        chargeEntry2.verifyNoChargeResults();
        // #endregion
      });

      it('Verify the amount calculations was performing correctly for patient3 based on the contracts with Effective Date Expiration Date are not documented in Charge Entry', () => {
        // #region Select patient3 and Verify Write Off,Amount and Balance

        cy.cGroupAsStep(
          'Select patient3 and Verify Write Off,Amount and Balance'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry3.selectCase(td_charge_entry_tcid_77097.ChargeDetails);
        chargeEntry3.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_charge_entry_tcid_77097.CptCodeInfo.CPTCodeAndDescription
        );
        chargeEntry3.clickWriteOffAmountLabel();
        chargeEntry3.validateWriteOff(
          td_charge_entry_tcid_77097.AmountsProcedures[2].WriteOff!
        );
        chargeEntry3.verifyBalance(
          td_charge_entry_tcid_77097.AmountsProcedures[2].Balance
        );
        chargeEntry3.verifyChargeAmount(
          td_charge_entry_tcid_77097.AmountsProcedures[2].Amount
        );
        // #endregion
      });

      it('Verify the amount calculations was performing correctly for patient4 with Self Pay as "Yes" in Charge Entry', () => {
        // #region Select patient4 and Verify Write Off,Amount and Balance

        cy.cGroupAsStep(
          'Select patient4 with self pay and Verify Write Off,Amount and Balance'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry4.selectCase(td_charge_entry_tcid_77097.ChargeDetails);
        chargeEntry4.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_charge_entry_tcid_77097.CptCodeInfo.CPTCodeAndDescription
        );
        chargeEntry4.verifyBalance(
          td_charge_entry_tcid_77097.AmountsProcedures[1].Balance
        );
        chargeEntry4.verifyChargeAmount(
          td_charge_entry_tcid_77097.AmountsProcedures[1].Amount
        );
        // #endregion
      });
    });
  }
}
