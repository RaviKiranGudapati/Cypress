import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';
import {
  CommonUtils,
  DateFormats,
} from '../../../../../../support/common-core-libs/framework/common-utils';
import { transactionalAPIs } from '../../../../../../support/common-core-libs/application/transactional-apis';

import { td_procedure_verification_tcid_264333 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/procedure-verification-tcid-264333.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import { PrimaryGuarantorCheckIn } from '../../../../../../app-modules-libs/sis-office/case-creation/enums/create-case.enum';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import FaceSheetChargeEntryPage from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const chargeEntry1 = new ChargeEntry(
  td_procedure_verification_tcid_264333.PatientCase[0]
);
const chargeEntry2 = new ChargeEntry(
  td_procedure_verification_tcid_264333.PatientCase[1]
);
const faceSheetChargeEntry = new FaceSheetChargeEntryPage();
const scheduleGrid = new ScheduleGrid();
const createCase = new CreateCase();
const faceSheetCases = new FaceSheetCases();

/* const values */
const patient1 =
  td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails.LastName +
  `, ` +
  td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
    .PatientFirstName;

const patient3 =
  td_procedure_verification_tcid_264333.PatientCase[2].PatientDetails.LastName +
  `, ` +
  td_procedure_verification_tcid_264333.PatientCase[2].PatientDetails
    .PatientFirstName;
const number100 = 100;

export class ProcedureVerificationTcId264333 {
  verifyPrimaryProcedureFields() {
    describe('Verify the Primary Fields are getting auto-populated for new Procedure', () => {
      it('Verify only the Primary Procedure Fields are getting updated to new Procedure when user clicks on Add Procedure button', () => {
        // #region Navigate to Charge Entry and select Patient1

        cy.cGroupAsStep('Navigate to Charge Entry and select Patient1');
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry1.selectCase(
          td_procedure_verification_tcid_264333.ChargeDetails[0]
        );
        // #endregion

        // #region Expand Primary Procedure, update diagnosis code and referring physician to have unique diagnosis code for all procedures
        cy.cGroupAsStep(
          'Expand Primary Procedure, update diagnosis code and referring physician to have unique diagnosis code for all procedures'
        );
        chargeEntry1.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        chargeEntry1.deleteDiagnosisCode(
          td_procedure_verification_tcid_264333.CasesToCodeDetails[1]
            .DiagnosisCode
        );
        chargeEntry1.addAdditionalDiagnosisCode(
          td_procedure_verification_tcid_264333.CasesToCodeDetails[0]
            .DiagnosisCode
        );
        chargeEntry1.updateReferringPhysician(
          td_procedure_verification_tcid_264333.CasesToCodeDetails[0]
            .ReferringPhysician ?? ''
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region Navigate to Facesheet Charge Entry Page
        cy.cGroupAsStep('Navigate to Facesheet Charge Entry Page');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        // #endregion

        // #region Click Add Procedure and verify the field values got auto-populated using primary procedure values
        cy.cGroupAsStep(
          'Click Add Procedure and verify the field values got auto-populated using primary procedure values'
        );
        chargeEntry1.clickAddProcedure();
        chargeEntry1.verifyFieldValues(
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[0],
          td_procedure_verification_tcid_264333.CasesToCodeDetails[0],
          td_procedure_verification_tcid_264333.ChargeDetails[0]
        );
        // #endregion

        // #region Navigate to Charge Entry Tracker and select patient
        cy.cGroupAsStep('Navigate to Charge Entry Tracker and select patient');
        chargeEntry1.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectPatientRow(
          td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
            .LastName!,
          td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
            .PatientFirstName!
        );
        // #endregion

        // #region Click Add Procedure and edit the field values and click done button
        cy.cGroupAsStep(
          'Click Add Procedure and edit the field values and click done button'
        );
        chargeEntry1.clickAddProcedure();
        chargeEntry1.enterProcedure(
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[2]
        );
        chargeEntry1.editFieldValues(
          td_procedure_verification_tcid_264333.CasesToCodeDetails[2],
          td_procedure_verification_tcid_264333.CasesToCodeDetails[0],
          td_procedure_verification_tcid_264333.ChargeDetails[1],
          YesOrNo.no
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region Navigate back to Facesheet Charge Entry
        cy.cGroupAsStep('Navigate back to Facesheet Charge Entry');
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        // #endregion

        // #region Expand Newly Added Procedure and verify the field values
        cy.cGroupAsStep(
          'Expand Newly Added Procedure and verify the field values'
        );
        chargeEntry1.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[2].CPTCodeAndDescription
        );
        chargeEntry1.verifyFieldValues(
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[2],
          td_procedure_verification_tcid_264333.CasesToCodeDetails[2],
          td_procedure_verification_tcid_264333.ChargeDetails[1]
        );
        // #endregion

        // #region Navigate to Charge Entry Tracker and select patient
        cy.cGroupAsStep('Navigate to Charge Entry Tracker and select patient');
        chargeEntry1.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectPatientRow(
          td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
            .LastName!,
          td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
            .PatientFirstName!
        );
        // #endregion

        // #region Delete First and Third procedure available
        cy.cGroupAsStep('Delete First and Third procedure available');
        faceSheetChargeEntry.deleteCharge(
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[0]
        );
        faceSheetChargeEntry.deleteCharge(
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[2]
        );
        // #endregion

        // #region Expand Second Procedure and Modify the field values
        cy.cGroupAsStep('Expand Second Procedure and Modify the field values');
        chargeEntry1.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[1].CPTCodeAndDescription
        );
        chargeEntry1.editFieldValues(
          td_procedure_verification_tcid_264333.CasesToCodeDetails[2],
          td_procedure_verification_tcid_264333.CasesToCodeDetails[1],
          td_procedure_verification_tcid_264333.ChargeDetails[1],
          YesOrNo.no
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region Click Add Procedure button and verify Field Values
        cy.cGroupAsStep('Click Add Procedure button and verify Field Values');
        chargeEntry1.clickAddProcedure();
        chargeEntry1.verifyFieldValues(
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[2],
          td_procedure_verification_tcid_264333.CasesToCodeDetails[2],
          td_procedure_verification_tcid_264333.ChargeDetails[1]
        );
        // #endregion

        // #region Enter New CPT Code for the added procedure, Make Ready for Bill as Yes and click done button
        cy.cGroupAsStep(
          'Enter New CPT Code for the added procedure, Make Ready for Bill as Yes and click done button'
        );
        //Enter New CPT Code for the added procedure
        chargeEntry1.enterProcedure(
          td_procedure_verification_tcid_264333.PatientCase[0].CaseDetails
            .CptCodeInfo[2]
        );

        //Make Ready for Bill Yes and click Done Button
        chargeEntry1.clickOnReadyForBill();
        sisOfficeDesktop.clickDoneButton();
        // #endregion

        // #region Navigate to Facesheet Transaction and verify Responsible column
        cy.cGroupAsStep(
          'Navigate to Facesheet Transaction and verify Responsible column'
        );
        // Navigate to Facesheet Transaction
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_procedure_verification_tcid_264333.PatientCase[0].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);

        // Verify Responsible Column
        transactions.verifyResponsible(patient1);

        // Navigate back to Schedule Grid
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyFieldValues() {
    describe('Verify field values in charge entry for newly added procedure', () => {
      it('Verify field values got populated from primary procedure to newly added procedure', () => {
        // #region Navigate to Charge Entry Tracker and select patient

        cy.cGroupAsStep('Navigate to Charge Entry Tracker and select patient');
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectPatientRow(
          td_procedure_verification_tcid_264333.PatientCase[1].PatientDetails
            .LastName!,
          td_procedure_verification_tcid_264333.PatientCase[1].PatientDetails
            .PatientFirstName!
        );
        // #endregion

        // #region Update Referring Physician field for the patient
        cy.cGroupAsStep('Update Referring Physician field for the patient');
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry2.updateReferringPhysician(
          td_procedure_verification_tcid_264333.CasesToCodeDetails[1]
            .ReferringPhysician ?? ''
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region Click Add Procedure and verify field values got populated from primary procedure
        cy.cGroupAsStep(
          'Click Add Procedure and verify field values got populated from primary procedure'
        );
        chargeEntry2.clickAddProcedure();
        chargeEntry2.verifyFieldValues(
          td_procedure_verification_tcid_264333.PatientCase[1].CaseDetails
            .CptCodeInfo[0],
          td_procedure_verification_tcid_264333.CasesToCodeDetails[1],
          td_procedure_verification_tcid_264333.ChargeDetails[0]
        );
        chargeEntry2.selectSisLogo();

        //Navigate to Schedule Grid
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  verifyResponsibleWithGuarantor() {
    describe('Verify Guarantor Name is getting updated in Responsible column in Facesheet Transaction Page', () => {
      it('Verify Guarantor name is updated instead of patient name in Facesheet Transaction Responsible column', () => {
        // #region Navigate to Facesheet Transaction and verify Patient Name is updated in Responsible column

        cy.cGroupAsStep(
          'Navigate to Facesheet Transaction and verify Patient Name is updated in Responsible column'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_procedure_verification_tcid_264333.PatientCase[2].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyResponsible(patient3);
        // #endregion

        // #region Navigate to Schedule Grid Tracker
        cy.cGroupAsStep('Navigate to Schedule Grid Tracker');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region Navigate to given date where patient is available and navigate to check-in
        cy.cGroupAsStep(
          'Navigate to given date where patient is available and navigate to check-in'
        );
        transactionalAPIs
          .API_Login(
            UserList.GEM_USER_3[0],
            UserList.GEM_USER_3[1],
            OrganizationList.GEM_ORG_3
          )
          .then(() => {
            transactionalAPIs
              .API_GetPatientCaseDOS(
                td_procedure_verification_tcid_264333.PatientCase[2]
                  .PatientDetails.PatientFirstName,
                td_procedure_verification_tcid_264333.PatientCase[2]
                  .PatientDetails.LastName,
                CommonUtils.getBeforeDate_yyyymmdd(
                  number100,
                  DateFormats.hyphen
                ),
                CommonUtils.getTodayDate_yyyymmdd(DateFormats.hyphen)
              )
              .then(($response) => {
                sisOfficeDesktop.clickTodayButton();
                sisOfficeDesktop.selectDateFromScheduleGrid(
                  $response.toString()
                );
              });
          });

        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          patient3,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        // #endregion

        // #region Navigate to Billing & Payment, select Primary Guarantor and click Done Button
        cy.cGroupAsStep(
          'Navigate to Billing & Payment, select Primary Guarantor and click Done Button'
        );
        // Navigate to Billing & Payment
        createCase.selectBillingAndPayment();

        // Select Guarantor and click Done Button
        createCase.selectPrimaryGuarantor(
          td_procedure_verification_tcid_264333.PatientCase[2].BillingDetails
            .PrimaryGuarantor ?? '',
          PrimaryGuarantorCheckIn.PrimaryGuarantor
        );
        createCase.clickCheckInDone();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region Navigate to Facesheet Transaction and verify Guarantor is updated in Responsible column
        cy.cGroupAsStep(
          'Navigate to Facesheet Transaction and verify Guarantor is updated in Responsible column'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_procedure_verification_tcid_264333.PatientCase[2].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyResponsible(
          td_procedure_verification_tcid_264333.PatientCase[2].BillingDetails
            .PrimaryGuarantor ?? ''
        );

        // Click Sis Logo
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
