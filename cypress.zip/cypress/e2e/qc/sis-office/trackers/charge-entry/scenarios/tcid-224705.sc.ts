import {
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_all_charges_toggle_functionality_tcid_224705 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/all-charges-toggle-functionality-tcid-224705.td';

import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import FaceSheetChargeEntry from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const transactions = new Transactions();
const createCase = new CreateCase(
  td_all_charges_toggle_functionality_tcid_224705.PatientCase[0]
);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const combinedCoding = new CombinedCoding();
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const faceSheetCases = new FaceSheetCases();

export class ChargeEntryTcId224705 {
  verifyToggleFunctionality() {
    describe('Verify All charges toggle functionality Charge entry', () => {
      it('Verify All charges toggle functionality Charge entry', () => {
        // #region - Select patient navigate to Billing details and add workers compensation and add fields

        cy.cGroupAsStep(
          'Select patient navigate to Billing details and add workers compensation and add fields'
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_all_charges_toggle_functionality_tcid_224705.PatientCase[0]
            .PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(
          FaceSheetOptions.PAYER_DETAILS
        );
        createCase.selectWorkerCompensation(YesOrNo.yes);
        createCase.selectAdditionalClaimInformation(
          td_all_charges_toggle_functionality_tcid_224705.AdditionalClaimInfo
        );
        transactions.clickUpdateButton();

        // #endregion

        // #region  - Select patient from charge entry tracker and select procedure1 and document additional claim information

        cy.cGroupAsStep(
          'Select patient from charge entry tracker and select procedure1 and document additional claim information'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(
          td_all_charges_toggle_functionality_tcid_224705.CombinedCoding
        );
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[3]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyApplyAllChargesLabel();
        chargeEntry.verifyApplyAllChargesSetNo();
        chargeEntry.enterResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.enterPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.enterSiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.enterTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.enterDataInUbFields(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[0]
        );

        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.enterDataInHcfaFields(
          td_all_charges_toggle_functionality_tcid_224705.HCFAAdditionalClaim[0]
        );
        chargeEntry.verifyApplyAllChargesSetNo();
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Verify Procedure1 documented data and click on done button

        cy.cGroupAsStep(
          'Verify Procedure1 documented data and click on done button'
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[0]
        );

        combinedCoding.verifyHcfaDateFields();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[3]
        );

        // #endregion

        // #region  - Select procedure2 and verify additional claim information documented data and set apply all charges yes

        cy.cGroupAsStep(
          'Select procedure2 and verify additional claim information documented data and set apply all charges yes'
        );
        chargeEntry.clickOnGenerateBillLabel();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyPatientCondition(
          td_all_charges_toggle_functionality_tcid_224705.AdditionalClaimInfo
            .PatientConditionDueTo
        );
        chargeEntry.verifyAccidentDate(
          td_all_charges_toggle_functionality_tcid_224705.AdditionalClaimInfo
            .AccidentDate
        );
        chargeEntry.verifyAccidentState(
          td_all_charges_toggle_functionality_tcid_224705.AdditionalClaimInfo
            .AccidentState
        );
        sisOfficeDesktop.clickCloseIcon();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[3]
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );

        // #endregion

        // #region  - Verify Procedure2 documented data and click on cross icon of additional claim information window

        cy.cGroupAsStep(
          'Verify Procedure2 documented data and click on cross icon of additional claim information window'
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[0]
        );

        combinedCoding.verifyHcfaDateFields();

        sisOfficeDesktop.clickCloseIcon();

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[3]
        );
        // #endregion

        // #region  - Click on add procedure and verify additional claim information button enable or disable

        cy.cGroupAsStep(
          'Click on add procedure and verify additional claim information button enable or disable'
        );
        faceSheetChargeEntry.addProcedure(
          td_all_charges_toggle_functionality_tcid_224705.CptCodeInfo[0]
        );
        chargeEntry.verifyAdditionalClaimInfoButton(false);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        faceSheetChargeEntry.verifyReadyForBill();
        chargeEntry.clickOnGenerateBillLabel();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        chargeEntry.verifyAdditionalClaimInfoButton();
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        chargeEntry.verifyPiDocument('');
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();

        chargeEntry.clickApplyAllChargesYes();
        sisOfficeDesktop.clickCloseIcon();

        // #endregion

        // #region  - Click on additional claim information and verify fields click on done button

        cy.cGroupAsStep(
          'Click on additional claim information and verify fields click on done button'
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        chargeEntry.verifyPiDocument('');
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[3]
        );

        // #endregion

        // #region  - Expand procedure1 and verify all fields should match with procedure2 data

        cy.cGroupAsStep(
          'Expand procedure1 and verify all fields should match with procedure2 data'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[0]
        );

        combinedCoding.verifyHcfaDateFields();

        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );

        // #endregion

        // #region  - Expand procedure3 and remove the data and set apply all yes, click on done button

        cy.cGroupAsStep(
          'Expand procedure3 and remove the data and set apply all yes, click on done button'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clearResubmissionCode();
        chargeEntry.clearSiDocument();
        chargeEntry.clearPiDocument();
        chargeEntry.clearTiDocument();
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifyPiDocument('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );
        combinedCoding.clickOnDoneButton();

        // #endregion

        // #region - Navigate to schedule grid>>face sheet>>charge entry and expand procedure3 and verify deleted fields

        cy.cGroupAsStep(
          'Navigate to schedule grid>>face sheet>>charge entry and expand procedure3 and verify deleted fields '
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_all_charges_toggle_functionality_tcid_224705.PatientCase[0]
            .PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifyPiDocument('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );

        // #endregion

        // #region  - Expand procedure1 and set apply all charges yes and click on done button

        cy.cGroupAsStep(
          'Expand procedure1 and set apply all charges yes and click on done button'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[3]
        );

        // #endregion

        // #region  - Expand procedure3 and procedure2 and verify fields of additional claim information should match with procedure1

        cy.cGroupAsStep(
          'Expand procedure3 and procedure2 and verify fields of additional claim information should match with procedure1'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[0]
        );

        combinedCoding.verifyHcfaDateFields();

        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );

        chargeEntry.clickOnGenerateBillLabel();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 2);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[0]
        );

        combinedCoding.verifyHcfaDateFields();

        combinedCoding.selectAdditionalClaimInfoDone();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);
        // #endregion

        // #region - Click on add supplie and verify additional claim information should be disable and verify the fields of additional claim information

        cy.cGroupAsStep(
          'Click on add supplie and verify additional claim information should be disable and verify the fields of additional claim information'
        );
        chargeEntry.addSupply(
          td_all_charges_toggle_functionality_tcid_224705.CptCodeInfo[2]
        );
        chargeEntry.verifyAdditionalClaimInfoButton(false);
        chargeEntry.enterHcpcsValue(
          td_all_charges_toggle_functionality_tcid_224705.Charges.HCPCS
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 3);
        chargeEntry.clickOnGenerateBillLabel();
        faceSheetChargeEntry.verifyReadyForBill();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 3);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifyPiDocument('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        sisOfficeDesktop.clickCloseIcon();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 3);

        // #endregion

        // #region - Expand procedure1 and set apply all charges yes and click on done button and verify fields of added supplie should match with procedure1

        cy.cGroupAsStep(
          'Expand procedure1 and set apply all charges yes and click on done button and verify fields of added supplie should match with procedure1'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );

        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 3);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[0]
        );

        combinedCoding.verifyHcfaDateFields();

        combinedCoding.selectAdditionalClaimInfoDone();

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[5]
        );

        // #endregion;

        // #region - Navigate to other tracker and navigate back to charge entry and click on add procedure button and select cpt

        cy.cGroupAsStep(
          'Navigate to other tracker and navigate back to charge entry and click on add procedure button and select cpt'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CASES_TO_CODE[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry.selectCase(
          td_all_charges_toggle_functionality_tcid_224705.CombinedCoding
        );
        faceSheetChargeEntry.addProcedure(
          td_all_charges_toggle_functionality_tcid_224705.CptCodeInfo[1]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 4);

        // #endregion

        // #region - Expand procedure5 and verify the fields of additional claim information should be empty and click on done button

        cy.cGroupAsStep(
          'Expand procedure5 and verify the fields of additional claim information should be empty and click on done button'
        );
        faceSheetChargeEntry.verifyReadyForBill();
        chargeEntry.clickOnGenerateBillLabel();
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 4);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifyPiDocument('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();
        combinedCoding.selectAdditionalClaimInfoDone();
        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.collapse,
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[1]
        );

        // #endregion
      });
    });
  }
}
