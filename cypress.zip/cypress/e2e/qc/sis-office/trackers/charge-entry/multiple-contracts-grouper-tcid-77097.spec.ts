import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { ContractGrouperTcId77097 } from './scenarios/tcid-77097.sc';

/* instance variables */
const contract = new ContractGrouperTcId77097();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Login SIS Complete Business desktop with User1,Navigate to Nursing Desktop.
 * 2.Search Contract1 and navigate to Review/Edit Select Grouper ID 1.
 * 3.Search Contract2 and navigate to Review/Edit Select Grouper ID 2.
 * 4.Search Contract3 and navigate to Review/Edit Select Grouper ID 3.
 * 5.Navigate to back to Charge Entry select period and batch select patient1.
 * 6.Verify Balance and Debit.
 * 7.Remove insurance1 and Verify Balance and Debit, and again add insurance1 Verify Balance and Debit.
 * 6.navigate Patient2 Charge Entry  and  Verify that the Write-Off amount should not be calculated as Date of Surgery is outside the Effective Date and the Expiration Date of Contract2.
 * 7.Navigate to back to Charge Entry select period and batch select patient3.
 * 8.Verify Write Off and Debit.
 * 9.Navigate to back to Charge Entry select period and batch select patient4.
 * 10.Verify Amount and Balance.
 */

describe(
  'Verify Amount calculation after mapping Insurance with Contract Grouper for multiple patients in Charge Entry ',
  { tags: ['charge-entry', 'TC#77097', 'US#270817'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        contract.verifyGrouperReimbursementAmount();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
