import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { ChargeEntryAutoSortTcId265313 } from './scenarios/tcid-265313.sc';

/* instance variables */
const chargeEntryAutoSort = new ChargeEntryAutoSortTcId265313();

/* Test Script Validation Details *****
 * Script Execution Details -
 * 1. Seed data needs to be executed.
 * 2.Login to the application
 * 3.Navigate to charge entry tracker.
 * 4.Select period and batch and select the created patient.
 * 5.click on auto sort button
 * 6.Verify the arrangement of the procedures.
 * 7.Update the charges manually
 * 8.Verify the updated amount post update
 * 9.Logout from application
 */

describe(
  'Verifying Calendar and Date picker available in Schedule Grid In SIS Business Desktop',
  { tags: ['auto-sort', 'TC#265313', 'US#269622'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_6[0],
        Password: UserList.GEM_USER_6[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_6, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        chargeEntryAutoSort.verifyAutoSortFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
