import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';
import { AdditionalClaimDetailsTcId265364 } from './scenarios/tcid-265364.sc';

/*instance variables*/
const additionalClaimDetails = new AdditionalClaimDetailsTcId265364();

/**********************Test Script Validation Details *************************
 * 1. Login to the application and select patient in charge entry tracker
 * 2. Select the charge and click on the Additional Claim Information button
 * 3. Verify the filed labels  of each section in UB/Institutional tab
 * 4. Do not document the data in all the fields under each section
 * 5. Verify  row should disappear as we have not documented anything for that field
 * 6. Document the data in all the fields under each section and verify documented data
 * 7. Navigate to HCFA tab
 * 8. Click on the + sign ,do Not document data and loose focus & Check for the data
 * 9. Document the data in all the fields under each section and verify documented data.
 * 10. Logout from the application.
 */

describe(
  'Verify and add additional claim info data in charge entry',
  { tags: ['charge-entry', 'US#269055', 'TC#265364'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_4[0],
        Password: UserList.GEM_USER_4[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_4, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        additionalClaimDetails.additionalClaimDetailsInfo();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
