import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { RcmTcId275798 } from './scenarios/tcid-275798.sc';

/* instance variables */
const rcm = new RcmTcId275798();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation
 * 1. Login to application
 * 2. Navigate to Patient Facesheet > Ledger Tab
 * 3. Add unassigned payment as received from Primary Guarantor
 * 4. Allocate the UP amount to the charge with responsible party as Primary Insurance
 * 5. Verify that received from is displayed as Primary Guarantor in the View/Edit and Allocate windows.
 * 6. Navigate to RCM tracker > Select charge to which UP amount allocated.
 * 7. Verify the received from is displayed as Primary guarantor.
 * 8. Allocate UP amount from the RCM tracker
 * 9. Verify the received from in the RCM tracker
 * */

describe(
  'Verify Unassigned Payment Received From field in RCM tracker',
  {
    tags: ['rcm', 'TC#275798', 'US#274696'],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_5[0],
        Password: UserList.GEM_USER_5[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_5, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        rcm.verifyUnassignedPaymentRCM();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
