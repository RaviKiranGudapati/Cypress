import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_revenue_cycle_manager_tcid_274841 } from '../../../../../../fixtures/sis-office/trackers/revenue-cycle-management/rcm-grid-layout-filters-tcid-274841.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { OR_REVENUE_CYCLE_MANAGEMENT } from '../../../../../../app-modules-libs/sis-office/trackers/or/revenue-cycle-management.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import RevenueCycleManagement from '../../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';
import { rcmTrackerColumns } from '../../../../../../app-modules-libs/sis-office/trackers/constants/revenue-cycle-management.const';
import {
  RefreshClearFilters,
  ShowMoreLess,
  DropDown,
} from '../../../../../../app-modules-libs/sis-office/trackers/enums/revenue-cycle-management.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const revenueCycleManagement = new RevenueCycleManagement();

export class RcmTcId274841 {
  verifyFiltersShowHideDefaultsInRCMTracker() {
    describe('Verify Filters and Show Hide Defaults elemnts in Revenue Cycle Management Tracker', () => {
      it('Verify Filters and Show Hide Defaults displayed in RCM Tracker ', () => {
        // #region - Verify Filters and Show Hide Defaults in RCM Tracker

        cy.cGroupAsStep(
          'Verify Show Defaults Expansion and Hide Defaults Collapse text and symbols in Revenue Cycle Management Tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.clear_Filters
        );
        revenueCycleManagement.clickShowLessMore(ShowMoreLess.show_defaults);
        revenueCycleManagement.clickShowLessMore(ShowMoreLess.hide_defaults);

        // #endregion

        // #region Default Filters in RCM Tracker

        cy.cGroupAsStep(
          'Verify Default Filters in Revenue Cycle Management Tracker'
        );

        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.responsible_party
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.insurance_plan_type
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.rcm_status);

        // #endregion

        // #region Filters in RCM Tracker

        cy.cGroupAsStep('Verify Filters in Show Defaults Expansion Section');

        revenueCycleManagement.clickShowLessMore(ShowMoreLess.show_defaults);
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.claim_status);
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.denials);
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.aging_type);
        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.aging_category
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.payer_role);
        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.insurance_classification
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.appointment_type
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.physician);

        // #endregion
      });
    });
  }

  verifyPaginationTextSearchInRCMTracker() {
    describe('Verify Pagination section and Text Seach fields in Revenue Cycle Management Tracker', () => {
      it('Verify Pagination section and Text Seach fields displayed in RCM Tracker ', () => {
        // #region - Verify column Names in RCM Tracker

        cy.cGroupAsStep(
          'Verify Patient Last Name, Follow-Up Date and MRN Fields in  Revenue Cycle Management Tracker'
        );

        revenueCycleManagement.clickShowLessMore(ShowMoreLess.hide_defaults);
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMEFROM[0],
          td_revenue_cycle_manager_tcid_274841.RevenueCycleManagement
            .PatientLastNameFrom
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMETO[0],
          td_revenue_cycle_manager_tcid_274841.RevenueCycleManagement
            .PatientLastNameTo
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.FOLLOW_UP_DATE[0],
          td_revenue_cycle_manager_tcid_274841.RevenueCycleManagement
            .FollowUpDate
        );
        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.refresh
        );

        // #endregion

        // #region verifying Column Names in RCM Tracker

        cy.cGroupAsStep(
          'Verify Column Names in Revenue Cycle Management Tracker'
        );

        revenueCycleManagement.verifyColumnsNameInRCMTracker(rcmTrackerColumns);

        // #endregion

        // #region Verify Refresh and Clear Filters Buttons in RCM Tracker

        cy.cGroupAsStep(
          'Verify Refresh and Clear Filters Buttons in Revenue Cycle Management Tracker'
        );

        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.clear_Filters
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMEFROM[0],
          td_revenue_cycle_manager_tcid_274841.RevenueCycleManagement
            .PatientLastNameFrom
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMETO[0],
          td_revenue_cycle_manager_tcid_274841.RevenueCycleManagement
            .PatientLastNameTo
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.FOLLOW_UP_DATE[0],
          td_revenue_cycle_manager_tcid_274841.RevenueCycleManagement
            .FollowUpDate
        );
        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.refresh
        );
        cy.cLogOut();
        // #endregion
      });
    });
  }

  verifyPaginationInRCMTracker() {
    describe('Verify Pagination section in Revenue Cycle Management Tracker', () => {
      it('Verify Pagination section in RCM Tracker ', () => {
        const login = new SISCompleteLogin();
        /**********Login To Application***********/
        login.login(
          UserList.GEM_USER_1[0],
          UserList.GEM_USER_1[1],
          OrganizationList.GEM_ORG_1
        );
        // #region verifying Pagination in RCM Tracker

        cy.cGroupAsStep(
          'Verify Pagination Section in Revenue Cycle Management Tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.verifyPaginationExists(true);

        // #endregion
      });
    });
  }
}
