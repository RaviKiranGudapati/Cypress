import { td_revenue_cycle_manager_tcid_274842 } from '../../../../../../fixtures/sis-office/trackers/revenue-cycle-management/rcm-filters-resp-details-tcid-274842.td';

import { OR_REVENUE_CYCLE_MANAGEMENT } from '../../../../../../app-modules-libs/sis-office/trackers/or/revenue-cycle-management.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import RevenueCycleManagement from '../../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  responsibleParty,
  denials,
  agingType,
  claimStatus,
  agingCategory,
  payerRole,
  insuranceClassification,
  rcmTrackerColumns,
  insuranceFields,
  subscriberFields
} from '../../../../../../app-modules-libs/sis-office/trackers/constants/revenue-cycle-management.const';
import {
  RefreshClearFilters,
  ShowMoreLess,
  DropDown,
} from '../../../../../../app-modules-libs/sis-office/trackers/enums/revenue-cycle-management.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const revenueCycleManagement = new RevenueCycleManagement();

export class RcmTcId274842 {
  verifyColumnsFiltersInRCMTracker() {
    describe('Verify Columns and Filters functionality in Revenue Cycle Management Tracker', () => {
      it('Verify column Names and Filters displayed in RCM Tracker ', () => {
        // #region - Verify column Names in RCM Tracker

        cy.cGroupAsStep(
          'Verify Default Filters in Revenue Cycle Management Tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.clear_Filters
        );

        // #endregion

        // #region Show Defaults Expansion and Hide Defaults Collapse text and symbols in RCM Tracker

        cy.cGroupAsStep(
          'Verify Show Defaults Expansion and Hide Defaults Collapse text and symbols in Revenue Cycle Management Tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.clear_Filters
        );
        revenueCycleManagement.clickShowLessMore(ShowMoreLess.show_defaults);
        revenueCycleManagement.clickShowLessMore(ShowMoreLess.hide_defaults);
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.responsible_party,
          responsibleParty
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.insurance_plan_type,
          td_revenue_cycle_manager_tcid_274842.Filters.InsurancePlanType
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.rcm_status,
          td_revenue_cycle_manager_tcid_274842.Filters.RCMStatus
        );

        // #endregion

        // #region Single Select Dropdwon Filter Options

        cy.cGroupAsStep('Verify Single Select Dropdwon Filter Options');

        revenueCycleManagement.clickShowLessMore(ShowMoreLess.show_defaults);
        revenueCycleManagement.verifySingleSelectDropdownValue(
          DropDown.denials,
          denials
        );
        revenueCycleManagement.verifySingleSelectDropdownValue(
          DropDown.aging_type,
          agingType
        );

        // #endregion

        // #region Select MultiSelect Dropdown Values in RCM Tracker

        cy.cGroupAsStep(
          'Verify and Select MultiSelect Dropdown Values in Revenue Cycle Management Tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.clickShowLessMore(ShowMoreLess.show_defaults);
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.claim_status,
          claimStatus
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.aging_category,
          agingCategory
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.payer_role,
          payerRole
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.insurance_classification,
          insuranceClassification
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.appointment_type,
          td_revenue_cycle_manager_tcid_274842.Filters.AppointmentType
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.physician,
          td_revenue_cycle_manager_tcid_274842.Filters.Physician
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.claim_status);
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.denials);
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.aging_type);
        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.aging_category
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.payer_role);
        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.insurance_classification
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(
          DropDown.appointment_type
        );
        revenueCycleManagement.verifyFiltersInRcmTracker(DropDown.physician);
        revenueCycleManagement.verifyColumnsNameInRCMTracker(rcmTrackerColumns);

        // #endregion
      });
    });
  }

  verifyResponsiblePartyFieldValues() {
    describe('Verify the field values of Responsible Party for Patient in Revenue Cycle Management Tracker', () => {
      it('Verifying that Responsibility field values as per Responsible Party  other than Self Pay or Patient Responsibility', () => {
        // #region Select MultiSelect Dropdown Values in RCM Tracker

        cy.cGroupAsStep('Navigate to RCM Tracker and select Patient');

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.clear_Filters
        );
        revenueCycleManagement.selectMultiSelectDropdownValue(
          DropDown.responsible_party,
          td_revenue_cycle_manager_tcid_274842.Filters.RespPartyValue
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMEFROM[0],
          td_revenue_cycle_manager_tcid_274842.RevenueCycleManagement
            .PatientLastNameFrom
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.PATIENTLASTNAMETO[0],
          td_revenue_cycle_manager_tcid_274842.RevenueCycleManagement
            .PatientLastNameTo
        );
        revenueCycleManagement.enterPatientNameFollowUpDate(
          OR_REVENUE_CYCLE_MANAGEMENT.FOLLOW_UP_DATE[0],
          td_revenue_cycle_manager_tcid_274842.RevenueCycleManagement
            .FollowUpDate
        );
        revenueCycleManagement.clickRefreshClearFilters(
          RefreshClearFilters.refresh
        );

        // #endregion

        // #region Select Patient Case in RCM Tracker

        cy.cGroupAsStep('Select Patient Case in RCM Tracker');

        revenueCycleManagement.selectTableRow(
          td_revenue_cycle_manager_tcid_274842.PatientDetails.LastName!
        );
        // #endregion

        // #region Check fields in the Responsible Party box on the Detail page

        cy.cGroupAsStep(
          'Verify fields in the Responsible Party box on the Detail page'
        );

        revenueCycleManagement.verifyLabelsInInsuranceTab(insuranceFields);
        revenueCycleManagement.verifyInsuranceFieldValues(
          td_revenue_cycle_manager_tcid_274842.RcmDetails.InsuranceLabels!,
          td_revenue_cycle_manager_tcid_274842.RcmDetails.InsuranceData!
        );
        revenueCycleManagement.selectResponsiblePartyTab(
          td_revenue_cycle_manager_tcid_274842.RcmDetails.Subscriber
        );
        revenueCycleManagement.verifyLabelsInSubscriberTab(subscriberFields);
        revenueCycleManagement.verifySubscriberFieldsData(
          td_revenue_cycle_manager_tcid_274842.RcmDetails.SubscriberLabel!,
          td_revenue_cycle_manager_tcid_274842.RcmDetails.SubscriberData!
        );

        // #endregion
      });
    });
  }
}
