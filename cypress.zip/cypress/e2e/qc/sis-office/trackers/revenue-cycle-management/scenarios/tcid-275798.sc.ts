import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_rcm_unassigned_payment_tcid_275798 } from '../../../../../../fixtures/sis-office/trackers/revenue-cycle-management/td_rcm_unassigned_payment_tcid_275798.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_FACESHEET_LEDGER_TAB } from '../../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-ledger.or';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ledgerTabFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import RevenueCycleManagement from '../../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import { ShowHidePayments } from '../../../../../../app-modules-libs/sis-office/trackers/enums/revenue-cycle-management.enum';
/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const revenueCycleManagement = new RevenueCycleManagement();
const ledgerTabFacesheet = new ledgerTabFaceSheet();
const createCase = new CreateCase(
  td_rcm_unassigned_payment_tcid_275798.PatientCase
);

/* const values */
const patient =
  td_rcm_unassigned_payment_tcid_275798.PatientCase.PatientDetails.LastName +
  `, ` +
  td_rcm_unassigned_payment_tcid_275798.PatientCase.PatientDetails
    .PatientFirstName;

export class RcmTcId275798 {
  verifyUnassignedPaymentRCM() {
    describe('Verify received from in Revenue Cycle Management Tracker', () => {
      it('Verify received from for UP amount allocation in Revenue Cycle Management Tracker', () => {
        // #region - Navigate to facesheet ledger screen and add unassigned payment as received from patient

        cy.cGroupAsStep(
          'Navigate to facesheet ledger screen and add unassigned payment as received from patient'
        );

        sisOfficeDesktop.pickPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        ledgerTabFacesheet.clickOnLedgerTab();
        ledgerTabFacesheet.clickOnAddButton();
        ledgerTabFacesheet.unassignedPaymentDetails(
          td_rcm_unassigned_payment_tcid_275798.UnassignedPayment
        );

        // #endregion

        // #region - Allocate amount to the charge from ledger screen

        cy.cGroupAsStep('Allocate amount to the charge from ledger screen');

        ledgerTabFacesheet.clickOnContextMenu(
          td_rcm_unassigned_payment_tcid_275798.UnassignedPayment
            .TransactionCode!,
          OR_FACESHEET_LEDGER_TAB.ALLOCATE[0]
        );
        ledgerTabFacesheet.amountAllocation(
          td_rcm_unassigned_payment_tcid_275798.UnAssignedAllocation[0]
            .AmountAllocation,
          td_rcm_unassigned_payment_tcid_275798.UnAssignedAllocation[0]
            .CPTHCPCSCode
        );
        ledgerTabFacesheet.unassignedPaymentAllocationSelectDropdown(
          OR_FACESHEET_LEDGER_TAB.CONTEXT_MENU_ITEMS
            .COLUMN_FOUR_TRANSACTION_CODE[0],
          td_rcm_unassigned_payment_tcid_275798.UnAssignedAllocation[0]
            .TransactionCode
        );
        ledgerTabFacesheet.clickOnDone();

        // #endregion

        // #region - Navigate to RCM Tracker and verify the UP received from

        cy.cGroupAsStep(
          'Navigate to RCM Tracker and verify the UP received from'
        );

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyReceivedFromUPAmount(
          td_rcm_unassigned_payment_tcid_275798.UnAssignedAllocation[0]
            .AmountAllocation,
          patient
        );

        // #endregion

        // #region - Allocate UP amount from RCM Tracker and verify the received from

        cy.cGroupAsStep(
          'Allocate UP amount from RCM Tracker and verify the received from'
        );

        revenueCycleManagement.clickHideShowPayments(
          ShowHidePayments.show_payments
        );
        revenueCycleManagement.allocateUPAmount(
          td_rcm_unassigned_payment_tcid_275798.UnAssignedAllocation[1]
        );
        revenueCycleManagement.verifyReceivedFromUPAmount(
          td_rcm_unassigned_payment_tcid_275798.UnAssignedAllocation[1]
            .AmountAllocation,
          patient
        );

        // #endregion
      });
    });
  }
}
