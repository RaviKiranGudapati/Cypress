import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId264191 } from './scenarios/tcid-264191.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId264191();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Login into application with valid credentials based on api
 * 2.Set the additional claim information in Billing Details page for case.
 * 3.Navigate to combined/charge entry page and select the charges.
 * 4.Verify and click on the Additional Claim Information button.
 * 5.Enter the data in all the UB fields and verify the data in fields.
 * 6.Clear and enter the data again and verify the data in fields.
 * 7.Click on Done button in Additional Claim Information popup.
 * 8.Again select the additional claim information and navigate to HCFA tab.
 * 9.Verify the labels in the HCFA tab.
 * 10.Enter the data in all the fields and verify the data is filled in all fields.
 * 11.Enter claim related details and verify in HCFA tab.
 * 12.Remove the codes in HCFA tab
 * 13.Edit the data in conditional code under HCFA tab.
 * 14.Verify the data is saved.
 * 15.click on Done button in Additional Claim Information popup.
 * 16.Click on Done button in Combined Coding Charge Entry page.
 * 17.Select the case again combined coding tracker and click on Next page button.
 * 18.Logout from application.
 */

describe(
  'Verify the additional claim information data is saved in UB and HCFA tab',
  { tags: ['combined-coding', 'US#267764', 'TC#264191'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyAdditionalClaimInfo();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
