import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId207479 } from './scenarios/tcid-207479.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId207479();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Seed data needs to be executed.
 * 2.Login to the application
 * 3.Enable combined coding from application settings.
 * 4.Navigate to combined coding tracker.
 * 5.Select the patient after selecting period and batch.
 * 6.Move to perform,select adjustment tab and verify the implant  values as zero.
 * 7.Select procedure and verify balance as per contract
 * 8.Select new patient from tracker and verify the balance by updating and removing the units
 * 9.Select new patient from tracker and verify the NDC number by adding medication with and without NDC number.
 */

describe(
  'Verify the balance amount and write off amount for implants and procedures mapped as per contracts',
  { tags: ['combined-coding', 'US#268160', 'TC#207479'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyBalanceCalculation();
        combinedCoding.verifyWriteOff();
        combinedCoding.verifyNDCNumber();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
