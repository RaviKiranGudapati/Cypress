import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId213211 } from './scenarios/tcid-213211';

/* instance variables */
const combinedCodingFacesheet = new CombinedCodingTcId213211();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Login into application and navigate to Schedule grid.
 * 2. Navigate to the the combined coding and verify the calculations for each pricing type
 * 3. Verify the Balance, debit, writeoff and amount for all the supplies
 * 4. Navigate to face sheet and select the charge entry,
 * 5. Add the supplies, verify the calculations of contracts for each pricing type
 * 6. Logout from application
 */

describe(
  'Verify When Supply charges are posted in Facesheet and combined coding for Calculations of each pricing type as follows',
  { tags: ['facesheet', 'combined-coding', 'TC#213211', 'US#268509'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCodingFacesheet.combinedCodingSupply();
        combinedCodingFacesheet.chargeEntrySupplyFacesheet();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
