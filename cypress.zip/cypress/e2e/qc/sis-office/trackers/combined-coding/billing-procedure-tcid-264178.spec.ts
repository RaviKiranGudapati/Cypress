import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId264178 } from './scenarios/tcid-264178.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId264178();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1. Verify that the self Pay is selected as Yes by default for Patient case where insurance is not added.
 * 2. Update Self Pay to No and save
 * 3. Open the patient row from combined coding and verify Self Pay fliped back to Yes
 * 4. Veriy the Billing Procedure Description field in Add Procedure
 * 5. Veriy the Billing Procedure Description field in Add Supplies
 * 6. Open the patient row from combined coding and click on Add procedure and verify Existing charges are not deleted
 * 7. Click on Sis Logo and navigate to SIS Desktop
 * 8. Open the patient row from combined coding and click on Add Supplies and verify Existing charges are not deleted
 * 9. Add Suppies, Select Ready for Bill Yes and Click On Done
 * 10. Search the Patient and Navigate to Charge Entry
 * 11. Verify the Amount as 1,000 and Update Units to 5.00
 * 12. Verify the Amount is Updated to 5,000
 */

describe(
  'Verify  Add New Performed Items Functionality and Billing Procedure Description field under Combined Coding tracker',
  { tags: ['combined-coding', 'US#267626', 'TC#264178'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifySelfPayAndBillingProcedure();
        combinedCoding.verifyAddProcedureFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
