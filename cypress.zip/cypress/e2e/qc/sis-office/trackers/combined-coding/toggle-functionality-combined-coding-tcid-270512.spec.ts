import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId224705 } from './scenarios/tcid-270512.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId224705();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Login to application, click on combined coding tracker select period and batch and click patient1.
 * 2.Expand procedure5, click on additional claim information button, verify Apply all charges set no and Document the data at the below fields
     Accident State, Accident date, Patient condition Due to
     Resubmission Frequency Code
     PI Document Ctrl #
     SI Document Ctrl #
     TI Document Ctrl #
     Document all data under UB/Institutional tab (Ex: Condition Codes, Occurrence Span Codes & Date Information, Occurrence Codes & Date Information...etc)
     Document all data under HCFA/Professional tab (Ex: First Occurrence, Date of Onset...etc)
 *3.Set apply to all charges no and click on done button. again click on additional claim information button
 *4.Observe that all fields data at both UB/Institutional and HCFA/Professional tabs are displayed correctly, close window of additional claim information.
 *5.Expand procedure6, click on additional claim information and verify fields should be empty, close the window without clicking on done button.
     Expand procedure5, click on additional claim information and Select Yes option for Apply to All charges toggle, Click Done button.
     Expand procedure6, click on additional claim information and verify all the fields, close the window.
 *6.Click add procedure and search and select procedure and document mandatory fields and click on additional claim information and verify fields should be empty and document all the data and Select Yes option for Apply to All charges toggle, and click on close window instead of done button.
 *7.Expand procedure6 and click on additional claim information button, Document the data.  Select Yes option for Apply to All charges toggle, Click Done button and collapse procedure 6. Expand procedure5 and verify all fields in claim information button and verify all the fields should be match with procedure6.
 *8.select procedure 7 and Remove the data at Clinical trial number, Resubmission frequency code, PI, SI, TI document fields click yes and click on done button. and set apply all to yes and click on done and set ready for bill no and click on done button.
 *9.Click on sis logo and select combined coding tracker and select patient 2 and expand procedure7. click on additional claim information and verify all fields should be empty
 *10.Click on procedure8 and click on additional claim information and set apply all to yes and click on done button  and collapse procedure8, expand procedure7 and click on additional claim information and verify documented fields click on done and collapse procedure7
 *11.Expand procedure6 and click on additional claim information and verify the documented fields and collapse procedure6, click on add supplies button search procedure and hcpcs and select it and verify additional claim information should be disable mode.
 *12.Document mandatory data and collapse procedure and expand and verify additional claim information button should be enable mode. click on additional claim information and verify the data should be empty and collapse supplie.
 *13.Expand procedure5 select additional claim information and set apply all yes and  click on done button. expand supplie and verify fields that should match with procedure1, set ready for bill yes and click on done button.
 *14.(sis logo, cases to code, charge entry, period and batch, select case)Navigate to case to code and come back to charge entry, click on Add procedure8, additional claim information and verify fields should be according to procedure5
 *15.sis logo-schedule grid-face sheet-charge entry click on add procedure9 and select it and collapse procedure9, expand procedure5 and click on additional claim information and ready for bill yes and click on done button.
 *16.Expand procedure9 and click on additional claim information and verify fields and should be according to procedure5, click on update button and change to other tab and come back to combined coding.
 *17.Expand procedure9  and click on additional claim information and verify fields should be according to procedure 5.
 *18.Log out from the application.
 */

describe(
  'Verify All charges toggle functionality  combined coding',
  { tags: ['charge-entry', 'US#269308', 'TC#270512'] },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyToggleFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
