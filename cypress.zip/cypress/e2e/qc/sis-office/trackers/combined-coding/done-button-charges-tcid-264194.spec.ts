import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId264194 } from './scenarios/tcid-264194.sc';

/* instance variables */

const combinedCoding = new CombinedCodingTcId264194();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Verify that the selected Charge should be highlighted in Blue color also user should be able to  add the data to Charge 1 under Charge tab.
 * 2.Verify Done Button should be in enabled state as we have documented all the mandatory  data
 * 3.Verify that the Ready for Bill toggle should be in enabled state as we have documented all the mandatory data.
 * 4.Check for the DOS, Procedure and Case status on the gray task bar component on the top of the page.
 * 5.Verify that the Ready for Bill toggle button behavior.
 * 6.Click on  Add Procedure button document all the mandatory data and check for the Done Button.
 * 7.Click on  Add Supplies button and Check for the Done Button.
 * 8.Verify that the Done Button should be in enabled state as we have documented all the mandatory  data.
 * 9.Set Ready for Bill to No and click on Next Case Button. Verify that Patient 1 should not fall off the tracker.
 *10.click on Adjustments toggle and Verify  one row for write-off and debit should be displayed, Write-Off and Debit amount should be defaulted to blank.
 *11. Verify that it should display the  $ sign along with the Amount entered
 *12.Verify that the user should be able to see another row should appear below it to enter another Debit
 *13.Click on the Transaction Code dropdown and Verify that Transaction Code field should be displayed and it should be defaulted to select Item.
 *14.Verify that it should pull all the Transaction codes as configured Type = Debit.
 *15.Verify that the row should NOT save without debit amount, It should save only after we document the Debit amount.
 *16.Document Debit Amount,Click on the Transaction Code and CLick Out side and Verify that the second row should be saved successfully
 *17.Navigate to Adjustment tab and check for Write-off(Discount 10%) record
 *18.Set Ready for Bill to Yes and Click on Next case  Button Verify that the patient 1 should fall off the combined coding/charge entry tracker.
 *19.Click on Transaction Check for the Transactions posted (Write Off , Debit ) Verify that user should be able to see all the Transaction that are assigned to the charge for Patient 1.
 *20Click on the Balance Reconciliation Tracker verify charges..
 */

describe(
  'Verify the done button charge, along with the toggle button behavior under Combined Coding tracker',
  { tags: ['combined-coding', 'US#267482', 'TC#264194'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyDoneButtonFunctionality();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
