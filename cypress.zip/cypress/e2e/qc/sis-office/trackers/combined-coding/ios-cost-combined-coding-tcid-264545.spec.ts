import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId264545 } from './scenarios/tcid-264545.sc';

/* instance variables */
const combinedCoding = new CombinedCodingTcId264545();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * 1.Login to the application and click on Patient1 case In combined coding/charge entry.
 *2.Add supplies to Patient and verify CPT Code and HCPCS label.
 *3.Click on CPT Code field and search for procedure and verify X icon.
 *4.Click on X icon and search text should be clear. Enter text in search filed and select the item.
 *5.Add another supply and check NDC# label.
 *6.Check for Unit of Measure label and verify dropdown values.
 *7.Check Base Unit filed and verify filed allows numeric input.
 *8.Document mandatory data set ready to bill no and click on next case and verify data documented in combined coding/charge entry by selecting patient.
 *9.Search patient in Masthead and verify case status should be Ready for charge.
 *10.Click on SIS Desktop navigate to combined coding/charge entry and select patient and change the values of added supply and verify data by clicking on done button.
 *11.Click on SIS Desktop navigate to combined coding/charge entry and select patient and remove CPT procedure filed and verify amount, physician & referring physician, modifiers and dx code.
 *12.Search patient in Masthead and verify case status should be Ready for charge.
 *13.Click on SIS Desktop navigate to combined coding/charge entry and select patient edit CPT Code and set set ready for bill Yes, click on Done button and verify patient(patient should be out of combined coding/charge entry tracker.
 *14.Select Patient Case in Schedule grid and click on face sheet>>charge entry and verify Unit of measure filed in added supply.
 *15.Logout from the application.
 */

describe(
  'Verify the IOS cost for all classifications in Combined Coding',
  { tags: ['enterprise-dictionary', 'US#267766', 'TC#264545'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyIosCost();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
