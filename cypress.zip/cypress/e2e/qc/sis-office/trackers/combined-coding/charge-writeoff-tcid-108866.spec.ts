import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { CombinedCodingTcId108866 } from './scenarios/tcid-108866.sc';

/*instance variables*/
const combinedCoding = new CombinedCodingTcId108866();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -

* 1. Login to the application and select patient in masthead
* 2. Select period and batch in charge tracker and select patient
* 3. Select the checkbox for the 3 procedures and click add selected to performed button for procedure 1
* 4. Verify the contractual write-off amount, balance amount for that particular charge
* 5. Add procedure and check contractual write-off amount, balance amount for that particular charge
* 6. Drag and drop charges and verify contractual write-off amount
* 7. Select the data at Modifier1 dropdown
* 8. Check the data which we selected at Modifier1 dropdown is displaying at Modifiers column in 'Scheduled Procedures/Billable Supplies' > Performed items section
* 9. Repeat above steps for patient 2 and patient3 with different contracts mapped
* 10. And verify contractual write-off amount, balance amount for that particular charge 
* 11. Logout from application
 */

describe(
  'Verify write-off amount ,balance amount for different charges in combined coding/charging',
  { tags: ['combined-coding', 'US#267887', 'TC#108866'] },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        combinedCoding.verifyCombinedCoding();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
