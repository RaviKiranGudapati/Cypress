import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';

import { td_combined_coding_264194 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/done-button-charges-tcid-264194.td';

import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import LedgerTabFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import BalanceReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/bal-reconciliation';

/* instance variables */
const sisOfcDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_combined_coding_264194.PatientCase);
const transactions = new Transactions(td_combined_coding_264194.PatientCase);
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const balanceReconciliation = new BalanceReconciliation();
const combinedCodings = new CombinedCoding();
const faceSheetCases = new FaceSheetCases();

export class CombinedCodingTcId264194 {
  verifyDoneButtonFunctionality() {
    describe('To verify the Done button behavior under coding/charge entry tracker', () => {
      it('Verifying Done button behavior ', () => {
        // #region - Navigating to the coding/charge entry tracker

        cy.cGroupAsStep(
          'Navigating to the coding/charge entry tracker, selecting Patient and verifying done button behavior post entering all the charge details.'
        );
        sisOfcDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        /*Select the combined/coding charge entry option from tracker */
        sisOfcDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        combinedCodings.selectCase(
          td_combined_coding_264194.Charge[0],
          td_combined_coding_264194.PatientCase
        );
        combinedCodings.verifyTextOnGreenBar(
          OR_COMBINED_CODING.HEADER.PROCEDURE[0],
          td_combined_coding_264194.Charge[0].CPT
        );
        combinedCodings.selectAllProcedureCheckbox();
        combinedCodings.addSelectedToPerformed();
        combinedCodings.verifyAndSelectProcedure(
          td_combined_coding_264194.Charge[0].CPT
        );
        // #endregion

        // #region -verify the done button and Ready for bill should be disable if all mandatory fields are not filled

        cy.cGroupAsStep('verify the done button and Ready for bill ');

        combinedCodings.verifyFooterButtonEnableDisable(
          OR_COMBINED_CODING.READY_FOR_BILL_NO[0],
          true
        );
        combinedCodings.verifyFooterButtonEnableDisable(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
          true
        );

        // #endregion

        // #region - verify all mandatory fields with red asterisk

        cy.cGroupAsStep('verify all mandatory fields with red asterisk ');
        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_264194.ProcedureAmount
        );
        combinedCodings.verifyMandatoryFields(
          OR_COMBINED_CODING.CHARGE.PHYSICIAN[0]
        );
        combinedCodings.verifyMandatoryFields(
          OR_COMBINED_CODING.CHARGE.DIAGNOSIS_CODE[0]
        );
        combinedCodings.verifyMandatoryFields(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );
        combinedCodings.verifyMandatoryFields(
          OR_COMBINED_CODING.CHARGE.SEARCH_PROCEDURE[0]
        );
        // #endregion

        // #region -Fill all the mandatory fields with valid data in charge tab and verify the done button behavior

        cy.cGroupAsStep(
          'Fill all the mandatory fields and verify done button '
        );
        combinedCodings.selectDiagnosisCode(
          td_combined_coding_264194.Charge[0]
        );

        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.PHYSICIAN[0],
          td_combined_coding_264194.Charge[0].Physician
        );
        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
          td_combined_coding_264194.Charge[0].Discounts
        );

        combinedCodings.verifyDiscountInChargeTab(
          td_combined_coding_264194.Charge[0].Discounts
        );

        combinedCodings.selectModifiers(
          td_combined_coding_264194.Charge[0].Modifier,
          1
        );

        combinedCodings.selectModifiers(
          td_combined_coding_264194.Charge[1].Modifier,
          2
        );
        /* verify Guarantor name in guarantor dropdown*/
        combinedCodings.verifyDropdownValue(
          td_combined_coding_264194.Charge[0].GuarantorFullName
        );
        combinedCodings.verifyFooterButtonEnableDisable(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
          false
        );
        combinedCodings.clickReadyForBillAndDoneButton();

        // #endregion

        // #region -Add supplies and verify done button before and after filling mandatory fields.
        cy.cGroupAsStep(
          'Add supplies and verify done button before and after filling mandatory fields'
        );
        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        sisOfcDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCodings.selectCase(
          td_combined_coding_264194.Charge[0],
          td_combined_coding_264194.PatientCase
        );
        combinedCodings.verifyTextOnGreenBar(
          OR_COMBINED_CODING.HEADER.PROCEDURE[0],
          td_combined_coding_264194.Charge[0].CPT
        );

        combinedCodings.clickAddSuppliesButton();
        combinedCodings.verifyFooterButtonEnableDisable(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
          true
        );

        combinedCodings.searchAndSelectProcedureSupplies(
          td_combined_coding_264194.Charge[1].CPT,
          td_combined_coding_264194.Charge[2].CPT
        );
        combinedCodings.searchAndSelectProcedureSupplies(
          OR_COMBINED_CODING.CHARGE.HCPCS[0],
          td_combined_coding_264194.Charge[0].HCPCS
        );

        combinedCodings.selectModifiers(
          td_combined_coding_264194.Charge[0].Modifier,
          1
        );
        combinedCodings.selectModifiers(
          td_combined_coding_264194.Charge[1].Modifier,
          2
        );
        combinedCodings.selectModifiers(
          td_combined_coding_264194.Charge[2].Modifier,
          3
        );
        combinedCodings.selectModifiers(
          td_combined_coding_264194.Charge[3].Modifier,
          4
        );
        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_264194.Charge[0].Amount
        );
        /* verifying Patient name*/
        combinedCodings.verifyDropdownValue(
          td_combined_coding_264194.PatientCase.PatientDetails.PatientFullName
        );
        /* Editing Modifiers to wait*/
        combinedCodings.selectModifiers(
          td_combined_coding_264194.Charge[3].Modifier,
          4
        );
        /* verifying Guarantor name*/
        combinedCodings.verifyDropdownValue(
          td_combined_coding_264194.PatientCase.PatientDetails.PatientFullName
        );
        combinedCodings.clickReadyForBillAndDoneButton();

        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        sisOfcDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BALANCE_OR_RECONCILIATION[0]
        );
        sisOfcDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        combinedCodings.selectCase(
          td_combined_coding_264194.Charge[0],
          td_combined_coding_264194.PatientCase
        );
        combinedCodings.verifyTextOnGreenBar(
          OR_COMBINED_CODING.HEADER.PROCEDURE[0],
          td_combined_coding_264194.Charge[0].CPT
        );
        combinedCodings.verifyAndSelectProcedure(
          td_combined_coding_264194.Charge[0].CPT
        );

        /**
         * @issue - Discount dropdown value was not being saved in combined coding charge tab Due to the execution speed of cypress,
         *          on the immediate navigation from charge tab to adjustment tab.
         * @fix   - Adding a verification to verify the discount selected dropdown value as part of stabilization.
         */
        combinedCodings.verifyDiscountInChargeTab(
          td_combined_coding_264194.Charge[0].Discounts
        );

        // #endregion

        // #region -Select Adjustment tab and enter all write-Off and Debit Details .

        cy.cGroupAsStep(
          'Select Adjustment tab and enter all write-Off and Debit Details '
        );

        combinedCodings.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        // Write-Off 1
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_combined_coding_264194.Adjustment.WriteoffAmount[0],
          1
        );
        combinedCodings.selectTransactionCode(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0],
          1,
          td_combined_coding_264194.Adjustment.WriteoffTransactionCode[0]
        );
        combinedCodings.selectWriteOffGroupCode(
          1,
          td_combined_coding_264194.Adjustment.WriteoffGroupCode[1]
        );
        combinedCodings.selectReasonCode(
          1,
          td_combined_coding_264194.Adjustment.WriteoffReasonCode[1]
        );
        // Debit Row1
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0],
          td_combined_coding_264194.Adjustment.DebitAmount[0],
          0
        );
        combinedCodings.selectTransactionCode(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_TRANSACTION_CODE[0],
          0,
          td_combined_coding_264194.Adjustment.DebitTransactionCode[0]
        );
        // Write-Off 2
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_combined_coding_264194.Adjustment.WriteoffAmount[1],
          2
        );
        combinedCodings.selectTransactionCode(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0],
          2,
          td_combined_coding_264194.Adjustment.WriteoffTransactionCode[1]
        );
        combinedCodings.selectWriteOffGroupCode(
          2,
          td_combined_coding_264194.Adjustment.WriteoffGroupCode[2]
        );
        combinedCodings.selectReasonCode(
          2,
          td_combined_coding_264194.Adjustment.WriteoffReasonCode[2]
        );
        // Debit Row 2
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0],
          td_combined_coding_264194.Adjustment.DebitAmount[1],
          1
        );
        combinedCodings.selectTransactionCode(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_TRANSACTION_CODE[0],
          1,
          td_combined_coding_264194.Adjustment.DebitTransactionCode[1]
        );
        // Write-Off 3
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_combined_coding_264194.Adjustment.WriteoffAmount[2],
          3
        );
        combinedCodings.selectTransactionCode(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_TRANSACTION_CODE[0],
          3,
          td_combined_coding_264194.Adjustment.WriteoffTransactionCode[2]
        );
        combinedCodings.selectWriteOffGroupCode(
          3,
          td_combined_coding_264194.Adjustment.WriteoffGroupCode[3]
        );
        combinedCodings.selectReasonCode(
          3,
          td_combined_coding_264194.Adjustment.WriteoffReasonCode[3]
        );
        // Debit Row 3
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0],
          td_combined_coding_264194.Adjustment.DebitAmount[2],
          2
        );
        combinedCodings.selectTransactionCode(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_TRANSACTION_CODE[0],
          2,
          td_combined_coding_264194.Adjustment.DebitTransactionCode[2]
        );
        // Write-Off 4
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_combined_coding_264194.Adjustment.WriteoffAmount[3],
          4
        );

        // Debit Row 4
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0],
          td_combined_coding_264194.Adjustment.DebitAmount[3],
          3
        );
        combinedCodings.selectTransactionCode(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_TRANSACTION_CODE[0],
          3,
          td_combined_coding_264194.Adjustment.DebitTransactionCode[3]
        );
        // Debit Row 5
        combinedCodings.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.DEBIT_AMOUNT[0],
          td_combined_coding_264194.Adjustment.DebitAmount[4],
          4
        );
        /* Edit write-off amount */
        combinedCodings.editWriteOffAmount(
          td_combined_coding_264194.Adjustment.WriteoffAmount[3],
          4,
          td_combined_coding_264194.Adjustment.WriteoffAmount[5]
        );

        // #endregion

        // #region -Select Ready for bill Yes and verify patient should fall off from the tracker

        cy.cGroupAsStep(
          'Select Ready for bill Yes and verify patient should fall off from the tracker'
        );
        combinedCodings.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCodings.selectReadyForBill(YesOrNo.yes);
        combinedCodings.clickReadyForBillAndDoneButton(true);
        combinedCodings.verifyPatientFallOffInCombinedCoding(
          td_combined_coding_264194.PatientCase.PatientDetails.PatientFullName
        );

        // #endregion

        // #region -Navigate to face sheet and verify transaction code

        cy.cGroupAsStep('Navigate to face sheet and verify transaction code ');
        sisOfcDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfcDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyTextInTransactionTab(
          td_combined_coding_264194.Adjustment.DebitTransactionCode[0]
        );
        transactions.verifyTextInTransactionTab(
          td_combined_coding_264194.Adjustment.DebitTransactionCode[1]
        );
        transactions.verifyTextInTransactionTab(
          td_combined_coding_264194.Adjustment.DebitTransactionCode[2]
        );
        transactions.verifyTextInTransactionTab(
          td_combined_coding_264194.Adjustment.WriteoffTransactionCode[1]
        );

        // #endregion

        // #region -Navigating to ledger Tab and verifying charges and transaction code

        cy.cGroupAsStep(
          'Navigating to ledger Tab and verifying charges and transaction code'
        );
        sisOfcDesktop.clickOnPersonIconInBusinessDesktop();
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.expandOrCollapseCptRow(
          td_combined_coding_264194.Charge[3].CPT
        );
        ledgerTabFaceSheet.verifyTextInChargesTable(
          td_combined_coding_264194.Adjustment.DebitTransactionCode[1]
        );
        ledgerTabFaceSheet.verifyTextInChargesTable(
          td_combined_coding_264194.Adjustment.WriteoffTransactionCode[1]
        );

        sisOfcDesktop.selectSisLogo();
        // #endregion

        // #region -Navigating to ledger Tab and verifying charges and transaction code

        cy.cGroupAsStep(
          'Navigating to Balance/Reconciliation tracker and verifying charges amount'
        );
        sisOfcDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        /* Click on Balance/Reconciliation tracker */
        sisOfcDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.BALANCE_OR_RECONCILIATION[0]
        );

        /* Select the period and batch in tracker */
        balanceReconciliation.selectPeriodAndBatch(
          td_combined_coding_264194.Charge[0]
        );

        /* verifying the Allocate amount is not displaying for the case  */
        balanceReconciliation.clickOnPlusIcon();
        balanceReconciliation.verifyTransactionCode(
          td_combined_coding_264194.Adjustment.DebitAmount[3]
        );
        balanceReconciliation.verifyTransactionCode(
          td_combined_coding_264194.Adjustment.DebitAmount[3]
        );

        // #endregion
      });
    });
  }
}
