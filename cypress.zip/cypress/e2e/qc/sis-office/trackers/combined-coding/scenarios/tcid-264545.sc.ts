import {
  Application,
  ExpandOrCollapse,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_combined_coding_tcid_264545 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/ios-cost-combined-coding-tcid-264545.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_combined_coding_tcid_264545.PatientCase);
const combinedCoding = new CombinedCoding();
const faceSheetCases = new FaceSheetCases();

export class CombinedCodingTcId264545 {
  verifyIosCost() {
    describe('To Verify the IOS cost for all classifications in Combined Coding', () => {
      it('To Verify the IOS cost for all classifications in Combined Coding', () => {
        // #region - Select the case and click on add button and verify CPT and HCPCS label

        cy.cGroupAsStep(
          'Select the case and click on add button and verify CPT and HCPCS label'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        combinedCoding.selectCase(
          td_combined_coding_tcid_264545.Charge[0],
          createCase.patientCaseModel!
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.addSupplies();
        combinedCoding.clickOnPerformedItems(5);
        combinedCoding.verifyCPT();
        combinedCoding.searchAndSelectProcedureSupplies(
          td_combined_coding_tcid_264545.Charge[1].CPT,
          td_combined_coding_tcid_264545.Charge[2].CPT
        );
        combinedCoding.searchAndSelectProcedureSupplies(
          OR_COMBINED_CODING.CHARGE.HCPCS[0],
          td_combined_coding_tcid_264545.Charge[0].HCPCS
        );
        combinedCoding.crossIconProcedure();
        combinedCoding.clickOnPerformedItems(2);
        combinedCoding.searchAndSelectProcedureSupplies(
          td_combined_coding_tcid_264545.Charge[1].CPT,
          td_combined_coding_tcid_264545.Charge[2].CPT
        );
        combinedCoding.searchAndSelectProcedureSupplies(
          OR_COMBINED_CODING.CHARGE.HCPCS[0],
          td_combined_coding_tcid_264545.Charge[0].HCPCS
        );

        // #endregion

        // #region - Click on added supplies and verify ndc, units of measure, base units and click on next case button

        cy.cGroupAsStep(
          'Click on added supplies and verify ndc, units of measure, base units and click on next case button'
        );
        combinedCoding.verifyNdc(
          td_combined_coding_tcid_264545.CombinedCoding.NdcValue[0]
        );
        combinedCoding.verifyUnitsOfMeasure();
        combinedCoding.clickOnUnitsOfMeasureCrossIcon();
        combinedCoding.verifyDropDownValuesInUnitsOfMeasure(
          td_combined_coding_tcid_264545.CombinedCoding.UnitsOfMeasureValue
        );
        cy.cRemoveMaskWrapper(Application.office);
        combinedCoding.clickOnPerformedItems(1);
        combinedCoding.verifyBaseUnits(
          td_combined_coding_tcid_264545.CombinedCoding.BaseUnitValue
        );
        combinedCoding.selectDiagnosisCode(
          td_combined_coding_tcid_264545.Charge[0]
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264545.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264545.Charge[2].CPT
        );
        combinedCoding.nextCaseButton();

        // #endregion

        // #region - Search patient in masthead and verify status Ready to charge

        cy.cGroupAsStep(
          'Search patient in masthead and verify status Ready to charge'
        );
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_combined_coding_tcid_264545.PatientCase.PatientDetails
        );
        combinedCoding.verifyReadyToCharge();
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_264545.Charge[0],
          createCase.patientCaseModel!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264545.Charge[2].CPT
        );
        combinedCoding.enterHcpcsValue(
          td_combined_coding_tcid_264545.Charge[0].HCPCS
        );
        combinedCoding.verifyNdc(
          td_combined_coding_tcid_264545.CombinedCoding.NdcValue[1]
        );
        combinedCoding.clickOnPerformedItems(1);
        combinedCoding.verifyBaseUnits(
          td_combined_coding_tcid_264545.CombinedCoding.BaseUnitValue
        );
        combinedCoding.clickOnPerformedItems(1);
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264545.Charge[1].HCPCS
        );
        combinedCoding.crossIconProcedure();
        combinedCoding.searchAndSelectProcedureSupplies(
          td_combined_coding_tcid_264545.Charge[1].CPT,
          td_combined_coding_tcid_264545.Charge[2].CPT
        );
        combinedCoding.searchAndSelectProcedureSupplies(
          OR_COMBINED_CODING.CHARGE.HCPCS[0],
          td_combined_coding_tcid_264545.Charge[0].HCPCS
        );

        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264545.PatientCase.CaseDetails.CptCodeInfo[0]
            .CPTCodeAndDescription
        );
        // Removed this as done button was disabled

        // #endregion

        // #region - Select added supplies and remove cpt and verify fields and status Ready to charge

        cy.cGroupAsStep(
          'Select added supplies and remove cpt and verify fields and status Ready to charge'
        );
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_264545.Charge[0],
          createCase.patientCaseModel!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264545.Charge[2].HCPCS
        );
        combinedCoding.crossIconProcedure();
        combinedCoding.verifyAmount(
          td_combined_coding_tcid_264545.Charge[0].Amount
        );
        combinedCoding.verifyPhysician(
          td_combined_coding_tcid_264545.Charge[0].Physician
        );
        combinedCoding.verifyReferringPhysician(
          td_combined_coding_tcid_264545.Charge[0].ReferringPhysician
        );
        combinedCoding.verifyNdc(
          td_combined_coding_tcid_264545.CombinedCoding.NdcValue[2]
        );
        combinedCoding.verifyModifier(1);
        combinedCoding.verifyMandatoryFields(
          OR_COMBINED_CODING.CHARGE.DIAGNOSIS_CODE[0]
        );
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_combined_coding_tcid_264545.PatientCase.PatientDetails
        );
        combinedCoding.verifyReadyToCharge();

        // #endregion

        // #region - Select case and set ready for bill yes and click on done and verify patient out of combined coding

        cy.cGroupAsStep(
          'Select case and set ready for bill yes and click on done and verify patient out of combined coding'
        );
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_264545.Charge[0],
          createCase.patientCaseModel!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_264545.Charge[2].HCPCS
        );
        combinedCoding.crossIconProcedure();
        combinedCoding.searchAndSelectProcedureSupplies(
          td_combined_coding_tcid_264545.Charge[0].CPT,
          td_combined_coding_tcid_264545.Charge[0].CPT
        );
        combinedCoding.clickOnReadyForBill();
        combinedCoding.clickReadyForBillAndDoneButton(true);
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.verifyPatientFallOffInCombinedCoding(
          td_combined_coding_tcid_264545.PatientCase.PatientDetails
            .PatientFullName
        );

        // #endregion

        // #region - From schedule grid select case, click on face sheet charge and verify units of measure

        cy.cGroupAsStep(
          'From schedule grid select case, click on face sheet charge and verify units of measure'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_combined_coding_tcid_264545.PatientCase.PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        combinedCoding.verifyUnitsOfMeasureValue(
          td_combined_coding_tcid_264545.CombinedCoding.UnitsOfMeasureValue[0]
        );

        // #endregion
      });
    });
  }
}
