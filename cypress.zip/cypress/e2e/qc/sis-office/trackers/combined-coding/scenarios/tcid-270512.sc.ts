import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import { ExpandOrCollapse } from '../../../../../../support/common-core-libs/application/common-core';

import { td_all_charges_toggle_functionality_tcid_224705 } from '../../../../../../fixtures/sis-office/trackers/charge-entry/all-charges-toggle-functionality-tcid-224705.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(
  td_all_charges_toggle_functionality_tcid_224705.PatientCase[1]
);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const combinedCoding = new CombinedCoding();
const faceSheetCases = new FaceSheetCases();

export class CombinedCodingTcId224705 {
  verifyToggleFunctionality() {
    describe('To verify All charges toggle functionality in combined coding tracker', () => {
      it('Verifying All charges toggle functionality in combined coding tracker', () => {
        // #region - Click on combined coding tracker and select patient2, click on additional claim information and verify fields

        cy.cGroupAsStep(
          'Click on combined coding tracker and select patient2,  click on additional claim information and verify fields'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_all_charges_toggle_functionality_tcid_224705.Charge,
          createCase.patientCaseModel!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[1]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyApplyAllChargesLabel();
        chargeEntry.verifyApplyAllChargesSetNo();
        chargeEntry.enterResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.enterPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.enterSiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.enterTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.enterDataInUbFields(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[1]
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.HCFA_PROFESSIONAL[0]
        );
        combinedCoding.enterDataInHcfaFields(
          td_all_charges_toggle_functionality_tcid_224705.HCFAAdditionalClaim[1]
        );

        chargeEntry.verifyApplyAllChargesSetNo();
        combinedCoding.selectAdditionalClaimInfoDone();
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[1]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[1]
        );
        combinedCoding.verifyHcfaDateFields();
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Select Procedure2 and verify all fields should be empty

        cy.cGroupAsStep(
          'Select Procedure2 and verify all fields should be empty'
        );
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifyPiDocument('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();
        chargeEntry.clickOnAddClaimInfoCrossIcon();

        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[1]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();

        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[1]
        );
        combinedCoding.verifyHcfaDateFields();

        chargeEntry.clickOnAddClaimInfoCrossIcon();

        // #endregion

        // #region - Add new procedure and verify all fields

        cy.cGroupAsStep('Add new procedure and verify all fields');
        combinedCoding.clickAddProcedureButton();
        combinedCoding.searchAndSelectCptInProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        combinedCoding.selectAdditionalClaimInfoTabs(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO.UB_INSTITUTIONAL[0]
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[1]
        );

        combinedCoding.verifyHcfaDateFields();
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Expand procedure1 and verify all documented fields

        cy.cGroupAsStep('Expand procedure1 and verify all documented fields');
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[1]
        );
        combinedCoding.verifyHcfaDateFields();
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Expand procedure3 and clear fields mentioned and set apply all charges to yes and navigate to combined coding tracker

        cy.cGroupAsStep(
          'Expand procedure3 and clear fields mentioned and set apply all charges to yes and navigate to combined coding tracker'
        );
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clearResubmissionCode();
        chargeEntry.clearSiDocument();
        chargeEntry.clearPiDocument();
        chargeEntry.clearTiDocument();
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_all_charges_toggle_functionality_tcid_224705.Charge,
          createCase.patientCaseModel!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[0]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Add supply and verify additional claim information enable or disable and verify all fields

        cy.cGroupAsStep(
          'Add supplies and verify additional claim information enable or disable and verify all fields'
        );
        combinedCoding.addSupplies();
        chargeEntry.verifyAdditionalClaimInfoButton();
        combinedCoding.searchAndSelectProcedureSupplies(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[3],
          td_all_charges_toggle_functionality_tcid_224705.Charges.HCPCS
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        chargeEntry.verifyPiDocument('');
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Expand procedure1 and set apply all charges yes and click on done button and verify all fields

        cy.cGroupAsStep(
          'Expand procedure1 and set apply all charges yes and click on done button and verify all fields'
        );
        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[1]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();

        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[1]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifyPiDocument('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[1]
        );

        combinedCoding.verifyHcfaDateFields();
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Navigate to combined coding tracker and select case and select cpt and verify fields

        cy.cGroupAsStep(
          'Navigate to combined coding tracker and select case and select cpt and verify fields'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_all_charges_toggle_functionality_tcid_224705.Charge,
          createCase.patientCaseModel!
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.searchAndSelectCptInProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        combinedCoding.verifyNoAdditionalClaimNoteInfo();
        combinedCoding.verifyAdditionalText();
        chargeEntry.verifyResubmissionCode('');
        chargeEntry.verifySiDocument('');
        chargeEntry.verifyTiDocument('');
        chargeEntry.verifyPiDocument('');
        combinedCoding.selectAdditionalClaimInfoDone();

        combinedCoding.verifyAndSelectProcedure(
          td_all_charges_toggle_functionality_tcid_224705.Charges.CPT[2]
        );
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.enterResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.enterSiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.enterTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        chargeEntry.enterPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();

        // #endregion

        // #region - Navigate to schedule grid>>facesheet>>charge entry and click on procedure1 and set apply all charges yes and click on done button

        cy.cGroupAsStep(
          'Navigate to schedule grid>>facesheet>>charge entry and click on procedure1 and set apply all charges yes and click on done button'
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_all_charges_toggle_functionality_tcid_224705.PatientCase[1]
            .PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.clickApplyAllChargesYes();
        combinedCoding.selectAdditionalClaimInfoDone();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        // #endregion

        // #region  - Click procedure2 and verify all fields should match with procedure1

        cy.cGroupAsStep(
          'Click procedure2 and verify all fields should match with procedure1'
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand, 1);
        combinedCoding.clickAdditionalClaimInformation(
          OR_COMBINED_CODING.ADDITIONAL_CLAIM_INFO
            .ADDITIONAL_CLAIM_INFORMATION[0]
        );
        chargeEntry.verifyResubmissionCode(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.ResubmissionFrequencyCode
        );
        chargeEntry.verifyPiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.PiDocument
        );
        chargeEntry.verifySiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.SiDocument
        );
        chargeEntry.verifyTiDocument(
          td_all_charges_toggle_functionality_tcid_224705
            .AdditionalCliamInformation.TiDocument
        );
        combinedCoding.verifyUbAdditionalClaimData(
          td_all_charges_toggle_functionality_tcid_224705.UBAdditionalClaim[1]
        );
        combinedCoding.verifyHcfaDateFields();

        combinedCoding.selectAdditionalClaimInfoDone();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        // #endregion
      });
    });
  }
}
