import { ProcedureType } from '../../../../../../support/common-core-libs/application/common-core';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_combined_coding_tcid_148932 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/combined-coding-balance-tcid-148932.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';

import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();

export class CombinedCodingTcId148932 {
  verifyBalanceIssue() {
    describe('Verify balance issue in combined coding tracker', () => {
      it('Verify balance issue in combined coding tracker', () => {
        // #region - Adding Procedure type and exempt in contracts

        cy.cGroupAsStep('Adding Procedure type and exempt in contracts');
        // Removed sub routes wait as no latency issue
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfigurationOption(
          OR_NURSING_CONFIGURATION.CONFIGURATION_SEARCH.CONTRACTS[0],
          true
        );
        nursingConfiguration.searchContractOptions(
          td_combined_coding_tcid_148932.Contract[0]
        );
        // Removed clickOnContractsTitle() as latency issue is fixed
        nursingConfiguration.searchProcedureInContract(
          td_combined_coding_tcid_148932.PatientCase[2].CaseDetails
            .CptCodeInfo![0].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.no_write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_combined_coding_tcid_148932.PatientCase[2].CaseDetails
            .CptCodeInfo![1].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.write_off
        );
        nursingConfiguration.searchProcedureInContract(
          td_combined_coding_tcid_148932.PatientCase[2].CaseDetails
            .CptCodeInfo![2].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.selectExemptAndConfigureAmount(
          td_combined_coding_tcid_148932.Contract[0].Details
        );
        nursingConfiguration.searchProcedureInContract(
          td_combined_coding_tcid_148932.PatientCase[2].CaseDetails
            .CptCodeInfo![2].CPTCodeAndDescription
        );
        nursingConfiguration.selectProcedureTypeInContract(
          ProcedureType.appended_fee
        );
        nursingConfiguration.selectExemptAndConfigureAmount(
          td_combined_coding_tcid_148932.Contract[0].Details1
        );

        // #endregion

        // #region - Verify balance and amount in Patient1 case

        cy.cGroupAsStep('Verify balance and amount in Patient1 case');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        // Added in seed data hence removed selectAllProcedureCheckbox(), addSelectedToPerformed()
        combinedCoding.selectCase(
          td_combined_coding_tcid_148932.Charges[0],
          td_combined_coding_tcid_148932.PatientCase[0]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_148932.PatientCase[0].CaseDetails
            .CptCodeInfo![0].CPTCodeAndDescription
        );
        combinedCoding.verifyAmountInAddedProcedure(
          td_combined_coding_tcid_148932.Charges[0].Amount
        );
        combinedCoding.verifyBalanceInAddedProcedure(
          td_combined_coding_tcid_148932.Charges[0].Balance
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.verifyFooterButtonEnableDisable(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
          true
        );
        combinedCoding.searchAndSelectCptInProcedure(
          td_combined_coding_tcid_148932.PatientCase[1].CaseDetails
            .CptCodeInfo![0].CPTCodeAndDescription
        );
        combinedCoding.clickReadyForBillAndDoneButton();

        // #endregion

        // #region - Verify balance and amount in Patient1 case

        cy.cGroupAsStep('Verify balance and amount in Patient2 case');
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_148932.Charges[1],
          td_combined_coding_tcid_148932.PatientCase[1]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_148932.PatientCase[1].CaseDetails
            .CptCodeInfo![0].CPTCodeAndDescription
        );
        combinedCoding.verifyAmountInAddedProcedure(
          td_combined_coding_tcid_148932.Charges[1].Amount
        );
        combinedCoding.verifyBalanceInAddedProcedure(
          td_combined_coding_tcid_148932.Charges[1].Balance
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.verifyFooterButtonEnableDisable(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
          true
        );
        combinedCoding.searchAndSelectCptInProcedure(
          td_combined_coding_tcid_148932.PatientCase[2].CaseDetails
            .CptCodeInfo![0].CPTCodeAndDescription
        );
        combinedCoding.nextCaseButton();

        // #endregion

        // #region - Verify balance and amount in Patient3 case

        cy.cGroupAsStep('Verify balance and amount in Patient3 case');
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_148932.Charges[2],
          td_combined_coding_tcid_148932.PatientCase[2]
        );
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_148932.PatientCase[2].CaseDetails
            .CptCodeInfo![3].CPTCodeAndDescription
        );
        combinedCoding.verifyAmountInAddedProcedure(
          td_combined_coding_tcid_148932.Charges[2].Amount
        );
        combinedCoding.verifyBalanceInAddedProcedure(
          td_combined_coding_tcid_148932.Charges[2].Balance
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.verifyFooterButtonEnableDisable(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0],
          true
        );
        combinedCoding.searchAndSelectCptInProcedure(
          td_combined_coding_tcid_148932.PatientCase[0].CaseDetails
            .CptCodeInfo![0].CPTCodeAndDescription
        );
        combinedCoding.clickReadyForBillAndDoneButton();

        // #endregion
      });
    });
  }
}
