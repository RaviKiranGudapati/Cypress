import {
  EnableOrDisable,
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_billing_description_tcid_264178 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/billing-procedure-tcid-264178.td';

import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();
const faceSheetCases = new FaceSheetCases();

export class CombinedCodingTcId264178 {
  verifySelfPayAndBillingProcedure() {
    describe('To verify the Self Pay button behavior under coding/charge entry tracker', () => {
      it('Verifying Self Pay button behavior ', () => {
        // #region - Navigating to the coding/charge entry tracker and select Patient1

        cy.cGroupAsStep(
          'Navigating to the coding/charge entry tracker, selecting Patient1 row, perform it, select CPT code and Verify Self Pay'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_billing_description_tcid_264178.Charge,
          td_billing_description_tcid_264178.PatientCase
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_billing_description_tcid_264178.CPTInfo[0].CPTCodeAndDescription
        );
        combinedCoding.clickSelfPay(YesOrNo.yes);
        combinedCoding.verifySelfPay(YesOrNo.yes);
        // #endregion

        // #region -Toggle SelfPay as No and verify that the value flipback to Yes after navigating back

        cy.cGroupAsStep(
          'Toggle SelfPay as No and verify that the value flipback to Yes after navigating back'
        );
        combinedCoding.selectDiagnosisCode(
          td_billing_description_tcid_264178.Charge
        );
        combinedCoding.clickSelfPay(YesOrNo.no);
        combinedCoding.verifySelfPay(YesOrNo.no);
        combinedCoding.clickOnDoneButton();
        sisOfficeDesktop.selectPatientRow(
          td_billing_description_tcid_264178.PatientCase.PatientDetails
            .LastName!,
          td_billing_description_tcid_264178.PatientCase.PatientDetails
            .PatientFirstName!
        );
        combinedCoding.verifyAndSelectProcedure(
          td_billing_description_tcid_264178.CPTInfo[0].CPTCodeAndDescription
        );
        combinedCoding.verifySelfPay(YesOrNo.yes);
        combinedCoding.verifyInsuranceDropDownState(
          OR_COMBINED_CODING.CHARGE.PRIMARY_INSURANCE[0],
          EnableOrDisable.enable
        );
        // #endregion

        // #region - Verify Billing Procedure Description Field label, maxlength and on-hover hint icon
        cy.cGroupAsStep(
          'Verify Billing Procedure Description Field label, maxlength and on-hover hint icon'
        );
        combinedCoding.verifyBillingProcedureDescriptionField();
        // #endregion
      });
    });
  }

  verifyAddProcedureFunctionality() {
    describe('To verify the Add Procedure/Supply under coding/charge entry tracker does not clear existing charges', () => {
      it('Add Procedure/Supply under coding/charge entry tracker', () => {
        // #region - Add New Procedure and Add Supply and verify Billing Procedure Description

        cy.cGroupAsStep(
          'Add New Procedure and Add Supply and verify Billing Procedure Description'
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.searchAndSelectCptInProcedure(
          td_billing_description_tcid_264178.CPTInfo[1].CPTCodeAndDescription
        );
        combinedCoding.clickGenerateBillCheckBoxInDetailsTable();
        combinedCoding.verifyAndSelectProcedure(
          td_billing_description_tcid_264178.CPTInfo[0].CPTCodeAndDescription
        );
        combinedCoding.enterBillingProcedureDescription(
          td_billing_description_tcid_264178.Charge.BillingProcedureDescription
        );
        combinedCoding.clickGenerateBillCheckBoxInDetailsTable();
        combinedCoding.clickOnDoneButton();
        // #endregion

        // #region - Verify the Add Procedure/Supply under coding/charge entry tracker does not clear existing charges

        cy.cGroupAsStep(
          'Verify the Add Procedure/Supply under coding/charge entry tracker does not clear existing charges'
        );
        sisOfficeDesktop.selectPatientRow(
          td_billing_description_tcid_264178.PatientCase.PatientDetails
            .LastName!,
          td_billing_description_tcid_264178.PatientCase.PatientDetails
            .PatientFirstName!
        );
        combinedCoding.clickAddProcedureButton();
        combinedCoding.verifyCPTProcedure(
          td_billing_description_tcid_264178.CPTInfo[0].CPTCodeAndDescription
        );
        combinedCoding.verifyAndSelectProcedure(
          td_billing_description_tcid_264178.CPTInfo[0].CPTCodeAndDescription
        );
        combinedCoding.verifyBillingProcedureDescription(
          td_billing_description_tcid_264178.Charge.BillingProcedureDescription
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        sisOfficeDesktop.selectPatientRow(
          td_billing_description_tcid_264178.PatientCase.PatientDetails
            .LastName!,
          td_billing_description_tcid_264178.PatientCase.PatientDetails
            .PatientFirstName!
        );
        combinedCoding.clickAddSuppliesButton();
        combinedCoding.verifyBillingProcedureDescriptionField();
        combinedCoding.searchAndSelectProcedureSupplies(
          td_billing_description_tcid_264178.CPTInfo[2].CPTCodeAndDescription,
          td_billing_description_tcid_264178.CPTInfo[2].CPTCodeAndDescription
        );
        combinedCoding.verifyCPTProcedure(
          td_billing_description_tcid_264178.CPTInfo[0].CPTCodeAndDescription
        );
        combinedCoding.selectReadyForBill(YesOrNo.yes);
        combinedCoding.clickOnDoneButton();
        // #endregion

        // #region - Search and Select Patient and update Units in Charge Entry

        cy.cGroupAsStep(
          'Search and Select Patient and update Units in Charge Entry'
        );
        combinedCoding.verifyPatientFallOffInCombinedCoding(
          td_billing_description_tcid_264178.PatientCase.PatientDetails
            .PatientFullName
        );
        sisOfficeDesktop.pickPatient(
          td_billing_description_tcid_264178.PatientCase.PatientDetails
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CHARGE_ENTRY);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        combinedCoding.verifyAmount(
          td_billing_description_tcid_264178.ChargeDetails[0].Amount!
        );
        combinedCoding.updateUnits(
          td_billing_description_tcid_264178.Charge.Units!
        );
        combinedCoding.verifyAmount(
          td_billing_description_tcid_264178.ChargeDetails[1].Amount!
        );
        // #endregion
      });
    });
  }
}
