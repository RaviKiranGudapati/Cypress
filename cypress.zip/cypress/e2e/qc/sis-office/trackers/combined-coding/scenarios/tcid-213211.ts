import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  Application,
  ExpandOrCollapse,
} from '../../../../../../support/common-core-libs/application/common-core';

import { td_combined_coding_tcid_213211 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/combined_coding_tcid_213211.td';

import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetChargeEntry from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-chargeentry';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';

/* instance variables */
const createCase = new CreateCase(
  td_combined_coding_tcid_213211.PatientCase[0]
);
const createCase1 = new CreateCase(
  td_combined_coding_tcid_213211.PatientCase[1]
);
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const nursingConfiguration = new NursingConfiguration();
const faceSheetChargeEntry = new FaceSheetChargeEntry();
const combinedCodings = new CombinedCoding();

/* const values */
const rCode = '0001';

export class CombinedCodingTcId213211 {
  combinedCodingSupply() {
    describe('Verify the When Supply charges are posted in combined coding and Calculations for each pricing type ', () => {
      it('Verify the When Supply charges are posted in combined coding and Calculations for each pricing type', () => {
        // #region Navigating application setting and opening the contracts from front end
        cy.cGroupAsStep(
          'Navigating application setting and opening the contracts from front end'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfiguration.searchContractOptions(
          td_combined_coding_tcid_213211.ContractInfo[0]
        );
        nursingConfiguration.searchContractOptions(
          td_combined_coding_tcid_213211.ContractInfo[1]
        );
        // #endregion

        // #region Validating Write-off Balance and Debit for Patient case row in combined coding

        cy.cGroupAsStep(
          'Navigating to Charge Entry and select the patient in the tracker'
        );
        sisOfficeDesktop.selectSisLogo();
        sisChartsDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );

        cy.cGroupAsStep(
          'Validating contract calculation for supply of revenue code type in combined coding'
        );

        combinedCodings.selectCase(
          td_combined_coding_tcid_213211.ChargeDetails,
          createCase.patientCaseModel!
        );
        combinedCodings.addSupply(
          td_combined_coding_tcid_213211.CptCodeInfo[0]
        );
        combinedCodings.enterHcpcsValue(
          td_combined_coding_tcid_213211.CptCodeInfo[0].HCPCS
        );
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );
        combinedCodings.selectRevenueCode(rCode);

        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_tcid_213211.AmountsProcedures[0].Amount
        );
        /* verifying Guarantor name*/
        combinedCodings.verifyDropdownValue(rCode);
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_combined_coding_tcid_213211.AmountsProcedures[0].Balance
        );
        combinedCodings.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCodings.verifyAmountInAdjustmentTab(
          td_combined_coding_tcid_213211.AmountsProcedures[0].Debit
        );
        combinedCodings.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );

        // #endregion

        // #region Validating contract calculation for supply of code type in combined coding

        cy.cGroupAsStep(
          'Validating contract calculation for supply of code type in combined coding'
        );
        combinedCodings.addSupply(
          td_combined_coding_tcid_213211.CptCodeInfo[1]
        );
        combinedCodings.enterHcpcsValue(
          td_combined_coding_tcid_213211.CptCodeInfo[1].HCPCS
        );
        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_tcid_213211.AmountsProcedures[1].Amount
        );
        /* verifying Guarantor name*/
        combinedCodings.verifyDropdownValue(
          td_combined_coding_tcid_213211.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_combined_coding_tcid_213211.AmountsProcedures[1].Balance
        );
        combinedCodings.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCodings.verifyAmountInAdjustmentTab(
          td_combined_coding_tcid_213211.AmountsProcedures[1].Debit
        );
        combinedCodings.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );

        cy.cGroupAsStep(
          'Validating contract calculation for supply of category type in combined coding'
        );
        combinedCodings.addSupply(
          td_combined_coding_tcid_213211.CptCodeInfo[2]
        );
        combinedCodings.enterHcpcsValue(
          td_combined_coding_tcid_213211.CptCodeInfo[2].HCPCS
        );
        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_tcid_213211.AmountsProcedures[2].Amount
        );
        /* verifying Guarantor name*/
        combinedCodings.verifyDropdownValue(
          td_combined_coding_tcid_213211.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_combined_coding_tcid_213211.AmountsProcedures[2].Balance
        );
        combinedCodings.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCodings.verifyAmountInAdjustmentTab(
          td_combined_coding_tcid_213211.AmountsProcedures[2].Debit
        );
        combinedCodings.verifyAmountInAdjustmentTab(
          td_combined_coding_tcid_213211.AmountsProcedures[2].WriteOff
        );
        combinedCodings.selectChargeAdjustmentButton(ChargeAdjustment.charge);

        cy.cGroupAsStep(
          'Validating contract calculation for supply of supply item type in combined coding'
        );
        combinedCodings.addSupply(
          td_combined_coding_tcid_213211.CptCodeInfo[3]
        );
        combinedCodings.enterHcpcsValue(
          td_combined_coding_tcid_213211.CptCodeInfo[3].HCPCS
        );
        combinedCodings.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0],
          td_combined_coding_tcid_213211.AmountsProcedures[3].Amount
        );
        /* verifying Guarantor name*/
        combinedCodings.verifyDropdownValue(
          td_combined_coding_tcid_213211.PatientCase[0].PatientDetails
            .PatientFirstName
        );
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );
        combinedCodings.verifyBalanceInAddedProcedure(
          td_combined_coding_tcid_213211.AmountsProcedures[3].Balance
        );
        combinedCodings.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCodings.verifyAmountInAdjustmentTab(
          td_combined_coding_tcid_213211.AmountsProcedures[3].Debit
        );
        combinedCodings.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCodings.clickOnMandatoryFieldLabel(
          OR_COMBINED_CODING.CHARGE.AMOUNT[0]
        );
        // #endregion
      });
    });
  }
  chargeEntrySupplyFacesheet() {
    describe('Verify the When Supply charges are posted in FaeSheet of charge Entry and Calculations for each pricing type', () => {
      it('Verify the When Supply charges are posted in FaeSheet of charge Entry and Calculations for each pricing type', () => {
        // #region Validating Write-off, Balance and Debit for Patient case row in Charge Entry of facesheet

        cy.cGroupAsStep(
          'Navigating to global search open facesheet of the patient and click on the charge entry tracker'
        );

        combinedCodings.selectSisLogo();

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase1.patientCaseModel!.PatientDetails
        );
        sisOfficeDesktop.selectTaskInMyTasks(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        faceSheetChargeEntry.selectPeriodAndBatchForCharge(
          0,
          td_combined_coding_tcid_213211.ChargeDetails
        );
        cy.cRemoveMaskWrapper(Application.office);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);

        faceSheetChargeEntry.addSupplies(
          td_combined_coding_tcid_213211.CptCodeInfo[0]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_combined_coding_tcid_213211.CptCodeInfo[0]
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.selectRevenueCode(rCode);
        faceSheetChargeEntry.enterChargeAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[0].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.verifyBalance(
          td_combined_coding_tcid_213211.AmountsProcedures[0].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[0].Debit
        );
        faceSheetChargeEntry.clickBalanceLabel();
        faceSheetChargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 1);

        cy.cGroupAsStep(
          'Validating contract calculation for supply of code type in Charge Entry of Facesheet'
        );
        faceSheetChargeEntry.addSupplies(
          td_combined_coding_tcid_213211.CptCodeInfo[1]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_combined_coding_tcid_213211.CptCodeInfo[1]
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.enterChargeAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[1].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.verifyBalance(
          td_combined_coding_tcid_213211.AmountsProcedures[1].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[1].Debit
        );
        faceSheetChargeEntry.clickBalanceLabel();
        faceSheetChargeEntry.verifyNoChargeResults();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 2);

        cy.cGroupAsStep(
          'Validating contract calculation for supply of category type in Charge Entry of Facesheet'
        );
        faceSheetChargeEntry.addSupplies(
          td_combined_coding_tcid_213211.CptCodeInfo[2]
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.enterHcpcs(
          td_combined_coding_tcid_213211.CptCodeInfo[2]
        );
        faceSheetChargeEntry.enterChargeAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[2].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.verifyBalance(
          td_combined_coding_tcid_213211.AmountsProcedures[2].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[2].Debit
        );
        faceSheetChargeEntry.validateWriteOff(
          td_combined_coding_tcid_213211.AmountsProcedures[2].WriteOff
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 3);

        cy.cGroupAsStep(
          'Validating contract calculation for supply of supply item type in Charge Entry of Facesheet'
        );
        faceSheetChargeEntry.addSupplies(
          td_combined_coding_tcid_213211.CptCodeInfo[3]
        );
        faceSheetChargeEntry.enterHcpcs(
          td_combined_coding_tcid_213211.CptCodeInfo[3]
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.enterChargeAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[3].Amount
        );
        faceSheetChargeEntry.clickAmountLabel();
        faceSheetChargeEntry.verifyBalance(
          td_combined_coding_tcid_213211.AmountsProcedures[3].Balance
        );
        faceSheetChargeEntry.verifyDebitAmount(
          td_combined_coding_tcid_213211.AmountsProcedures[3].Debit
        );
        faceSheetChargeEntry.clickBalanceLabel();
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse, 4);
        // #endregion
      });
    });
  }
}
