import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_charge_writeoff_tcid_108866 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/charge-writeoff-tcid-108866.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';

/* instance variables */
const createCase = new CreateCase(
  td_charge_writeoff_tcid_108866.PatientCase[0]
);
const sisOfficeDesktop = new SISOfficeDesktop();
const combinedCoding = new CombinedCoding();

export class CombinedCodingTcId108866 {
  verifyCombinedCoding() {
    describe('Verify write-off amount ,balance amount for different charges in combined coding/charging', () => {
      it('Add procedure/supply and verify write-off amount ,balance amount for 3 different patients', () => {
        // #region - Select the combined/coding charge entry option from tracker

        cy.cGroupAsStep(
          'Navigating to the coding/charge entry tracker, selecting Patient 1 and verifying charge amount,balance '
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );        

        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        combinedCoding.selectCase(
          td_charge_writeoff_tcid_108866.Charge,
          createCase.patientCaseModel!
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_charge_writeoff_tcid_108866.CPTInfo[2].CPTCodeAndDescription
        );
        combinedCoding.enterChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[0].Amount
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCoding.selectWriteOffGroupCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );
        combinedCoding.selectReasonCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[0]
        );
        combinedCoding.verifyReasonCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.verifyGroupCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );

        // #endregion

        // #region - verify amount for charges

        cy.cGroupAsStep(
          'Select charge, and verify balance and charge amount and click on done button'
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);

        combinedCoding.verifyBalanceAmount(
          td_charge_writeoff_tcid_108866.ChargeDetails[0].Balance
        );
        combinedCoding.verifyChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[0].Amount
        );
        combinedCoding.clickAddProcedureButton();

        combinedCoding.searchAndSelectCptInProcedure(
          td_charge_writeoff_tcid_108866.CPTInfo[1].CPTCodeAndDescription
        );
        combinedCoding.enterChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[1].Amount
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[1],
          0
        );
        combinedCoding.selectWriteOffGroupCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );
        combinedCoding.selectReasonCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[1]
        );
        combinedCoding.verifyReasonCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.verifyGroupCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyBalanceAmount(
          td_charge_writeoff_tcid_108866.ChargeDetails[1].Balance
        );
        combinedCoding.verifyChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[1].Amount
        );
        combinedCoding.dragAndDropCharges(
          td_charge_writeoff_tcid_108866.CPTInfo[1].CPTCodeAndDescription,
          td_charge_writeoff_tcid_108866.CPTInfo[0].CPTCodeAndDescription
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[1].Amount
        );
        // #endregion

        // #region - Select the combined/coding charge entry option from tracker

        cy.cGroupAsStep(
          'Navigating to the coding/charge entry tracker, selecting Patient 2 and verifying charge amount,balance '
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        combinedCoding.selectCase(
          td_charge_writeoff_tcid_108866.Charge,
          createCase.patientCaseModel!
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_charge_writeoff_tcid_108866.CPTInfo[2].CPTCodeAndDescription
        );
        combinedCoding.enterChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[2].Amount
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCoding.selectWriteOffGroupCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );
        combinedCoding.selectReasonCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[0]
        );
        combinedCoding.verifyReasonCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.verifyGroupCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.dragAndDropCharges(
          td_charge_writeoff_tcid_108866.CPTInfo[3].CPTCodeAndDescription,
          td_charge_writeoff_tcid_108866.CPTInfo[2].CPTCodeAndDescription
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charge_writeoff_tcid_108866.CPTInfo[2].CPTCodeAndDescription
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[2].Amount
        );
        combinedCoding.deleteChargeInCoding(
          td_charge_writeoff_tcid_108866.CPTInfo[3]
        );
        // #endregion

        // #region - Select the combined/coding charge entry option from tracker

        cy.cGroupAsStep(
          'Navigating to the coding/charge entry tracker, selecting Patient 3 and verifying charge amount,balance '
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        // Removed verify patient row as it was added to avoid latency we are clicking Patient in selectCase method
        combinedCoding.selectCase(
          td_charge_writeoff_tcid_108866.Charge,
          createCase.patientCaseModel!
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_charge_writeoff_tcid_108866.CPTInfo[2].CPTCodeAndDescription
        );
        combinedCoding.enterChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[2].Amount
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.enterAdjustmentsDetails(
          OR_COMBINED_CODING.ADJUSTMENT.WRITE_OFF_AMOUNT[0],
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[0],
          0
        );
        combinedCoding.selectWriteOffGroupCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );
        combinedCoding.selectReasonCode(
          0,
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffAmount[0]
        );
        combinedCoding.verifyReasonCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffReasonCode[0]
        );
        combinedCoding.verifyGroupCode(
          td_charge_writeoff_tcid_108866.Adjustment.WriteoffGroupCode[0]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.clickAddProcedureButton();

        combinedCoding.searchAndSelectCptInProcedure(
          td_charge_writeoff_tcid_108866.CPTInfo[4].CPTCodeAndDescription
        );
        combinedCoding.enterChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[3].Amount
        );
        combinedCoding.verifyChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[4].Amount
        );

        combinedCoding.dragAndDropCharges(
          td_charge_writeoff_tcid_108866.CPTInfo[4].CPTCodeAndDescription,
          td_charge_writeoff_tcid_108866.CPTInfo[2].CPTCodeAndDescription
        );
        combinedCoding.verifyAndSelectProcedure(
          td_charge_writeoff_tcid_108866.CPTInfo[4].CPTCodeAndDescription
        );
        combinedCoding.verifyChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[4].Amount
        );
        combinedCoding.clickAddSuppliesButton();

        combinedCoding.searchAndSelectProcedureSupplies(
          td_charge_writeoff_tcid_108866.CPTInfo[5].CPTCodeAndDescription,
          td_charge_writeoff_tcid_108866.CPTInfo[5].CPTCodeAndDescription
        );
        combinedCoding.searchAndSelectProcedureSupplies(
          OR_COMBINED_CODING.CHARGE.HCPCS[0],
          td_charge_writeoff_tcid_108866.CPTInfo[5].HCPCS!
        );
        combinedCoding.searchAndSelectProcedureSupplies(
          OR_COMBINED_CODING.CHARGE.HCPCS[0],
          td_charge_writeoff_tcid_108866.CPTInfo[5].HCPCS!
        );
        combinedCoding.enterChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[5].Amount
        );
        combinedCoding.updateUnits(td_charge_writeoff_tcid_108866.Charge.Units);
        combinedCoding.verifyBalanceAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[6].Balance
        );
        combinedCoding.verifyChargeAmount(
          td_charge_writeoff_tcid_108866.AmountsProcedures[6].Amount
        );
        // #endregion
      });
    });
  }
}
