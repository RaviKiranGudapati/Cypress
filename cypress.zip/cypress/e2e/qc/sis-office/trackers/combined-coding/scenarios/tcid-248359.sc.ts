import { ExpandOrCollapse } from '../../../../../../support/common-core-libs/application/common-core';

import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { td_combined_coding_tcid_248359 } from '../../../../../../fixtures/sis-office/trackers/combined-coding/view-delete-modify-contracts-tcid-248359.td';

import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_COMBINED_CODING } from '../../../../../../app-modules-libs/sis-office/trackers/or/combined-coding.or';

import { ChargeAdjustment } from '../../../../../../app-modules-libs/sis-office/trackers/enums/combined-coding.enum';

import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase1 = new CreateCase(
  td_combined_coding_tcid_248359.PatientCase[0]
);
const createCase2 = new CreateCase(
  td_combined_coding_tcid_248359.PatientCase[1]
);
const chargeEntry1 = new ChargeEntry(createCase1.patientCaseModel!);
const chargeEntry2 = new ChargeEntry(createCase2.patientCaseModel!);
const combinedCoding = new CombinedCoding();
const loginPage = new SISCompleteLogin();

export class CombinedCodingTcId248359 {
  verifyContractChargeAdminUser() {
    describe('Verify the charge balance and write off amount for admin user under charge entry', () => {
      it('Verifying charge balance and write off amount for admin user profile', () => {
        // #region Navigating to charge entry tracker select patient 1 and verify amount values

        cy.cGroupAsStep(
          'Navigating to charge entry tracker select patient 1 and verify amount values'
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry1.selectCase(td_combined_coding_tcid_248359.Charges[0]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry1.selectDiscount(
          td_combined_coding_tcid_248359.Charges[0].Discounts
        );
        chargeEntry1.verifyBalance(
          td_combined_coding_tcid_248359.Charges[0].Balance
        );
        chargeEntry1.validateWriteOff(
          td_combined_coding_tcid_248359.Adjustment.WriteoffAmount[0]
        );
        chargeEntry1.verifyAmount(
          td_combined_coding_tcid_248359.Charges[0].Amount
        );

        // #endregion

        // #region Navigating to charge entry tracker select patient 2 and verify amount values

        cy.cGroupAsStep(
          'Navigating to charge entry tracker select patient 2 and verify amount values'
        );
        chargeEntry1.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry2.selectCase(td_combined_coding_tcid_248359.Charges[1]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry2.selectDiscount(
          td_combined_coding_tcid_248359.Charges[1].Discounts
        );
        chargeEntry2.verifyBalance(
          td_combined_coding_tcid_248359.Charges[1].Balance
        );
        chargeEntry2.validateWriteOff(
          td_combined_coding_tcid_248359.Adjustment.WriteoffAmount[1]
        );
        chargeEntry2.verifyAmount(
          td_combined_coding_tcid_248359.Charges[1].Amount
        );
        chargeEntry2.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        // #endregion

        // #region Logging into to another FASC for verifying charge values in combined coding

        cy.cGroupAsStep(
          'Logging into to another FASC for verifying patient 3 charge values in combined coding'
        );
        cy.cLogOut();
        const login = new SISCompleteLogin();
        login.login(
          UserList.GEM_USER_14[0],
          UserList.GEM_USER_14[1],
          OrganizationList.GEM_ORG_14
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_248359.Charges[2],
          td_combined_coding_tcid_248359.PatientCase[2]
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_248359.Charges[2].CPT[0]
        );
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
          td_combined_coding_tcid_248359.Charges[2].Discounts!
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyBalanceAmount(
          td_combined_coding_tcid_248359.Charges[2].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_tcid_248359.Charges[2].Amount!
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_combined_coding_tcid_248359.Adjustment.WriteoffAmount[2]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        // #endregion
      });
    });
  }

  verifyContractChargeSisAdmin() {
    describe('Verify the charge balance and write off amount for sis admin user under charge entry', () => {
      it('Verifying charge balance and write off amount for sis admin user profile', () => {
        // #region Navigating to charge entry tracker select patient 1 and verify amount values

        cy.cGroupAsStep(
          'Navigating to charge entry tracker select patient 1 and verify amount values'
        );
        const userLogin2: UserLogin = {
          UserName: UserList.SIS_ADMIN[0],
          Password: UserList.SIS_ADMIN[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin2);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry1.selectPeriodAddNewBatch(
          td_combined_coding_tcid_248359.Charges[0].Period,
          td_combined_coding_tcid_248359.Charges[0].Batch
        );
        chargeEntry1.selectCase(td_combined_coding_tcid_248359.Charges[0]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry1.selectDiscount(
          td_combined_coding_tcid_248359.Charges[0].Discounts
        );
        chargeEntry1.verifyBalance(
          td_combined_coding_tcid_248359.Charges[0].Balance
        );
        chargeEntry1.validateWriteOff(
          td_combined_coding_tcid_248359.Adjustment.WriteoffAmount[0]
        );
        chargeEntry1.verifyAmount(
          td_combined_coding_tcid_248359.Charges[0].Amount
        );

        // #endregion

        // #region Navigating to charge entry tracker select patient 2 and verify amount values

        cy.cGroupAsStep(
          'Navigating to charge entry tracker select patient 2 and verify amount values'
        );
        chargeEntry1.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        chargeEntry2.selectCase(td_combined_coding_tcid_248359.Charges[1]);
        sisOfficeDesktop.performAction(ExpandOrCollapse.expand);
        chargeEntry2.selectDiscount(
          td_combined_coding_tcid_248359.Charges[1].Discounts
        );
        chargeEntry2.verifyBalance(
          td_combined_coding_tcid_248359.Charges[1].Balance
        );
        chargeEntry2.validateWriteOff(
          td_combined_coding_tcid_248359.Adjustment.WriteoffAmount[1]
        );
        chargeEntry2.verifyAmount(
          td_combined_coding_tcid_248359.Charges[1].Amount
        );
        chargeEntry2.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        cy.cLogOut();
        // #endregion

        // #region Logging into to another FASC for verifying charge values in combined coding

        cy.cGroupAsStep(
          'Logging into to another FASC for verifying charge values in combined coding'
        );
        /**
         * @Issue: Due to logout and re login, API is not working and we have tried with the cy reload after logout and still not worked
         * @Resolution: we are moving to old login application
         */
        cy.reload();
        cy.visit('/');
        /**********Login To Application***********/
        loginPage.login(
          UserList.SIS_ADMIN[0],
          UserList.SIS_ADMIN[1],
          OrganizationList.GEM_ORG_14
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        combinedCoding.scrollToLastRowInTracker();
        combinedCoding.selectPeriodAddNewBatch(
          td_combined_coding_tcid_248359.Charges[2].Period,
          td_combined_coding_tcid_248359.Charges[2].Batch
        );
        combinedCoding.selectCase(
          td_combined_coding_tcid_248359.Charges[2],
          td_combined_coding_tcid_248359.PatientCase[2]
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        combinedCoding.verifyAndSelectProcedure(
          td_combined_coding_tcid_248359.Charges[2].CPT[0]
        );
        combinedCoding.enterAllChargeDetails(
          OR_COMBINED_CODING.CHARGE.DISCOUNT[0],
          td_combined_coding_tcid_248359.Charges[2].Discounts!
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);
        combinedCoding.verifyBalanceAmount(
          td_combined_coding_tcid_248359.Charges[2].Balance!
        );
        combinedCoding.verifyAmount(
          td_combined_coding_tcid_248359.Charges[2].Amount!
        );
        combinedCoding.selectChargeAdjustmentButton(
          ChargeAdjustment.adjustment
        );
        combinedCoding.verifyWriteOffAmount(
          td_combined_coding_tcid_248359.Adjustment.WriteoffAmount[2]
        );
        combinedCoding.selectChargeAdjustmentButton(ChargeAdjustment.charge);

        // #endregion
      });
    });
  }
}
