import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  ExpandOrCollapse,
  YesOrNo,
} from '../../../../../../support/common-core-libs/application/common-core';
import {
  CommonUtils,
  DateFormats,
} from '../../../../../../support/common-core-libs/framework/common-utils';
import { transactionalAPIs } from '../../../../../../support/common-core-libs/application/transactional-apis';

import { td_inv_rec_tcid_270005 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/inv-rec-tcid-270005.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import ClinicalDocumentation from '../../../../../../app-modules-libs/sis-office/trackers/clinical-documentation';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import ChargeEntry from '../../../../../../app-modules-libs/sis-office/trackers/charge-entry';
import CasesToCode from '../../../../../../app-modules-libs/sis-office/trackers/cases-to-code';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';
import { FreeText } from '../../../../../../app-modules-libs/shared/application-settings/enums/nursing-configuration.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const scheduleGrid = new ScheduleGrid();
const clinicalDocumentation = new ClinicalDocumentation();
const transactions = new Transactions();
const combinedCoding = new CombinedCoding();
const createCase = new CreateCase(td_inv_rec_tcid_270005.PatientCase);
const inventoryReconciliation = new InventoryReconciliation(
  createCase.patientCaseModel?.PatientDetails!
);
const casesToCode = new CasesToCode(createCase.patientCaseModel!);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);

/* const values */
const number1000 = 1000; // To do we will be revisited this month to remove the done date filter

export class InvRecFreeTextToIosItemTcId270005 {
  addFreeTextItemPreferenceCard() {
    describe('Add Free Text Implant and Free Text Supply for the Preference Card', () => {
      it('Add Free Text Implant and Free Text Supply for the Preference Card', () => {
        /*****************Test Begins***************/
        // #region - Navigate to Application Settings

        cy.cGroupAsStep('Navigate to Application Settings');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        // #endregion

        // #region - Navigate to Preference Card Configuration, Search and Select Preference Card

        cy.cGroupAsStep(
          'Search and Select Preference Card in Preference Card Configuration in Application Settings'
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.PREFERENCE_CARDS_CONFIGURATION
            .CONFIGURATION[0]
        );
        nursingConfiguration.searchAndSelectPreferenceCard(
          td_inv_rec_tcid_270005.PreferenceCards
        );
        // #endregion

        // #region - Add Free Text Implant in Preference Card

        cy.cGroupAsStep('Add Free Text Implant in Preference Card');

        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0],
          FreeText.free_text_item
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Add Free Text Supply in Preference Card

        cy.cGroupAsStep('Add Free Text Supply in Preference Card');

        nursingConfiguration.addSuppliesInPreferenceCard(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0],
          FreeText.free_text_item
        );
        nursingConfiguration.addSuppliesInPreferenceCard(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1],
          FreeText.free_text_item
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  performPatientCase() {
    describe('Performing the Patient Case in Clinical Documentation Tracker', () => {
      it('Performing the Patient Case in Clinical Documentation Tracker', () => {
        // #region - Click on Arrive Button in Case Details PopUp for the Patient Case in Schedule Grid and Click on Sis Logo

        cy.cGroupAsStep(
          'Click On Arrive Button for the Patient Case in Case Details Popup in Schedule Grid'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region Navigate to given date where patient is available and navigate to check-in

        cy.cGroupAsStep(
          'Navigate to given date where patient is available and navigate to check-in'
        );

        transactionalAPIs
          .API_Login(
            UserList.GEM_USER_1[0],
            UserList.GEM_USER_1[1],
            OrganizationList.GEM_ORG_CDM1
          )
          .then(() => {
            transactionalAPIs
              .API_GetPatientCaseDOS(
                td_inv_rec_tcid_270005.PatientCase.PatientDetails
                  .PatientFirstName,
                td_inv_rec_tcid_270005.PatientCase.PatientDetails.LastName,
                CommonUtils.getBeforeDate_yyyymmdd(
                  number1000,
                  DateFormats.hyphen
                ),
                CommonUtils.getTodayDate_yyyymmdd(DateFormats.hyphen)
              )
              .then(($response) => {
                sisOfficeDesktop.selectDateFromScheduleGrid(
                  $response.toString()
                );
              });
          });

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnArriveButtonInCaseDetailsPopup(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.LastName
        );
        // #endregion

        // #region - Navigate to Clinical Documentation Tracker and select patient case

        cy.cGroupAsStep(
          'Verify and Select Patient Case in Clinical Documentation Tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CLINICAL_DOCUMENTATION[0]
        );
        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.PatientFullName
        );
        sisOfficeDesktop.selectPatientRow(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.LastName,
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.PatientFirstName
        );
        // #endregion

        // #region - Perform the Patient Case by clicking on Yes and Done in Clinical Documentation Tracker

        cy.cGroupAsStep(
          'Select Yes and Done Button in Clinical Documentation Tracker'
        );

        clinicalDocumentation.selectDocumentationCompleteAndDoneButton(
          YesOrNo.yes
        );
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInInventory() {
    describe('Verify Implants and Supplies imported from preference card is displaying in Inventory Reconciliation Tracker', () => {
      it('Verify Implants and Supplies imported from preference card is displaying in Inventory Reconciliation Tracker', () => {
        // #region - Navigate to Inventory Reconciliation Tracker and verify Free Text Warning Icon with Tooltip Text

        cy.cGroupAsStep(
          'Verify Free Text Depletion Warning Text for Patient Case in Inventory Reconciliation Tracker'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.PatientFullName
        );
        inventoryReconciliation.verifyDepletionWarningMessage(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.LastName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0]
        );
        // #endregion

        // #region - Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Select Patient Case in Inventory Reconciliation Tracker'
        );

        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text on mouse hover for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Tooltip Text on mouse hover for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - 'Verify Free Text Tooltip Text for Implant Item on mouse hover in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        // #endregion

        // #region - 'Verify Free Text Tooltip Text for Supply Item on mouse hover in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        // #endregion
      });
    });
  }

  updateFreeTextItemToIosInventoryItem() {
    describe('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Reconciliation Tracker', () => {
      it('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Reconciliation Tracker', () => {
        // #region - Update First Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update First Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Update Second Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Second Free Text Implant Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Update First Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update First Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Update Second Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Update Second Free Text Supply Item to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Verify Implant Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name on mouse hover in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name on mouse hover in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item on mouse hover in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Supply Item on mouse hover in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Saving the Patient Case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Saving the Patient Case in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.no);
        // #endregion
      });
    });
  }

  verifyUpdatedIosInventoryItem() {
    describe('Verify Free Text is converted to IOS Inventory Item after saving the Patient Case in Inventory Reconciliation Tracker', () => {
      it('Verify Free Text is converted to IOS Inventory Item after saving the Patient Case in Inventory Reconciliation Tracker', () => {
        // #region - Verify and Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Verify and Select Patient Case in Inventory Reconciliation Tracker'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.PatientFullName
        );
        inventoryReconciliation.verifyDepletionWarningMessage(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.LastName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          false
        );
        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details after saving the case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details after saving the case in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details after saving the case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details after saving the case in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name on mouser hover in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        // #region - Verify Tooltip Text for Supply Name on mouser hover in inventory reconciliation tracker

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1].Implant,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270005.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        cy.cGroupAsStep(
          'Saving the Patient Case in inventory reconciliation tracker'
        );
        // #region - Saving the Patient Case in inventory reconciliation tracker
        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.no);
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInCoding() {
    describe('Verify Implants and Supplies coming from Inventory Tracker or Face-sheet Inventory are displaying in Coding Tracker', () => {
      it('Verify Implants and Supplies coming from Inventory Tracker or Face-sheet Inventory are displaying in Coding Tracker', () => {
        // #region - Navigate to Cases to Code Tracker and Select Patient Case Row and Add Scheduled Item to Performed Items and Add Diagnosis Code for the Procedure

        cy.cGroupAsStep(
          'Navigate to Cases to Code Tracker and Select Patient Case Row and Add Scheduled Item to Performed Items and Add Diagnosis Code for the Procedure'
        );
        casesToCode.addSelectedToPerformed();
        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270005.CasesToCodeDetails[0].SearchProcedureName!
        );
        casesToCode.enterDiagnosisCode(
          td_inv_rec_tcid_270005.CasesToCodeDetails[0]
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Implant Details in Cases to Code Tracker

        cy.cGroupAsStep('Verify Implant Details in Cases to Code Tracker');

        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270005.CasesToCodeDetails[1].SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270005.CasesToCodeDetails[1].Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270005.CasesToCodeDetails[1].HCPCS!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Supply Details in Cases to Code Tracker

        cy.cGroupAsStep('Verify Supply Details in Cases to Code Tracker');

        casesToCode.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270005.CasesToCodeDetails[3].SearchProcedureName!
        );
        casesToCode.verifyUnits(
          td_inv_rec_tcid_270005.CasesToCodeDetails[3].Units!
        );
        casesToCode.enterHcpcs(
          td_inv_rec_tcid_270005.CasesToCodeDetails[3].HCPCS!
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Implant Details in Documentation section in Coding Screen

        cy.cGroupAsStep(
          'Verify Implant Details in Documentation section in Coding Screen'
        );

        casesToCode.verifyDocumentationImplantDetails(
          td_inv_rec_tcid_270005.CasesToCodeDetails[1].Documentation!
        );
        casesToCode.verifyDocumentationImplantDetails(
          td_inv_rec_tcid_270005.CasesToCodeDetails[2].Documentation!
        );
        // #endregion

        // #region - Make Case as Ready for Charge in Cases to Code Tracker

        cy.cGroupAsStep(
          'Make Case as Ready for Charge in Cases to Code Tracker'
        );

        casesToCode.clickReadyForChargeAndDoneButton();
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInChargeEntry() {
    describe('Verify Implants and Supplies coming from Coding Tracker are displaying in Charge Entry Tracker', () => {
      it('Verify Implants and Supplies coming from Coding Tracker are displaying in Charge Entry Tracker', () => {
        // #region - Navigate to Charge Entry Tracker and Verify Patient Case in Charge Entry Tracker

        cy.cGroupAsStep(
          'Navigate to Charge Entry Tracker and Verify Patient Case in Charge Entry Tracker'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        combinedCoding.verifyPatientRow(
          td_inv_rec_tcid_270005.PatientCase.PatientDetails.PatientFullName
        );
        // #endregion

        // #region - Select Period, Batch and Patient Case Row in Charge Entry Tracker

        cy.cGroupAsStep(
          'Select Period, Batch and Patient Case Row in Charge Entry Tracker'
        );

        chargeEntry.selectCase(td_inv_rec_tcid_270005.Charges[0]);
        // #endregion

        // #region - Verify Procedure Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify Procedure Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270005.Charges[0].CPT
        );
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Implant Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify Implant Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270005.Charges[1].CPT
        );
        chargeEntry.verifyUnits(td_inv_rec_tcid_270005.Charges[1].Units!);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Verify Supply Details in Charge Entry Tracker

        cy.cGroupAsStep('Verify Supply Details in Charge Entry Tracker');

        chargeEntry.expandCollapseProcedureInPerformedItemsBasedOnCPT(
          ExpandOrCollapse.expand,
          td_inv_rec_tcid_270005.Charges[2].CPT
        );
        chargeEntry.verifyUnits(td_inv_rec_tcid_270005.Charges[2].Units!);
        sisOfficeDesktop.performAction(ExpandOrCollapse.collapse);
        // #endregion

        // #region - Make Patient Case as Ready for Bill in Charge Entry Tracker

        cy.cGroupAsStep(
          'Make Patient Case as Ready for Bill in Charge Entry Tracker'
        );

        chargeEntry.clickReadyForBillAndDoneButton();
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInFaceSheetInventory() {
    describe('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
      it('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
        // #region - Search and Select Patient from global search

        cy.cGroupAsStep('Search and Select Patient from global search');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');

        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Implant Details in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Implant Details in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Supply Details in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[0].Implant,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Implant[1].Implant,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270005.PreferenceCardInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270005.FaceSheetInventoryInfo.Supplies[1].SupplyName
        );
        // #endregion
      });
    });
  }
}
