import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';

import { td_inv_rec_tcid_270007 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/inv-rec-tcid-270007.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import { FreeText } from '../../../../../../app-modules-libs/shared/application-settings/enums/nursing-configuration.enum';
import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import CombinedCoding from '../../../../../../app-modules-libs/sis-office/trackers/combined-coding';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';

/* instance variables */
const createCase = new CreateCase(td_inv_rec_tcid_270007.PatientCase);
const inventoryReconciliation = new InventoryReconciliation(
  createCase.patientCaseModel?.PatientDetails!
);
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfiguration = new NursingConfiguration();
const transactions = new Transactions();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const sisChartsDesktop = new SISChartsDesktop();
const combinedCoding = new CombinedCoding();

export class InvRecFreeTextToIosItemTcId270007 {
  addFreeTextItemInOperative() {
    describe('Add Free Text Implant and Free Text Supply in Work-list Under Operative Department', () => {
      it('Add Free Text Implant and Free Text Supply in Work-list Under Operative Department', () => {
        /*****************Test Begins***************/
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Select Yes Button for Implant Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Implant Questionnaire in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.clickImplantsQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Free Text Implant in Preference Card

        cy.cGroupAsStep('Add Free Text Implant in Preference Card');

        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0],
          FreeText.free_text_item
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Select Yes Button for Implant Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Implant Questionnaire in Worklist in Operative Department'
        );
        chartsCoverFaceSheet.clickSuppliesQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Free Text Supply in Preference Card

        cy.cGroupAsStep('Add Free Text Supply in Preference Card');

        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0],
          FreeText.free_text_item
        );
        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1],
          FreeText.free_text_item
        );
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        // #endregion

        // #region - Sign Operative Department

        cy.cGroupAsStep('Sign Operative Department');

        chartsCoverFaceSheet.signDepartment();
        // #endregion

        // #region - Click on Patient Face sheet Icon

        cy.cGroupAsStep('Click on Patient Face sheet Icon');

        chartsCoverFaceSheet.clickFaceSheetIcon();
        // #endregion

        // #region - Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0],
          YesOrNo.yes
        );
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInInventoryFaceSheet() {
    describe('Verify Implants and Supplies imported from SIS Charts is displaying in Inventory Face-Sheet of Patient Case', () => {
      it('Verify Implants and Supplies imported from SIS Charts is displaying in Inventory Face-Sheet of Patient Case', () => {
        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion

        // #region - Navigate Patient Face-Sheet In Business Desktop

        cy.cGroupAsStep('Navigate Patient Face-Sheet In Business Desktop');
        
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');

        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Implant Details in Inventory Face-Sheet

        cy.cGroupAsStep('Verify Implant Details in Inventory Face-Sheet');

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details in Inventory Face-Sheet

        cy.cGroupAsStep('Verify Supply Details in Inventory Face-Sheet');

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Implant Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Implant Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Supply Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Supply Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        inventoryReconciliation.verifyFreeTextToolTipText(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        // #endregion
      });
    });
  }

  updateFreeTextItemToIosInventoryItem() {
    describe('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Face-Sheet of Patient Case', () => {
      it('Update Free Text Supply and Implant to IOS Inventory Item in Inventory Face-Sheet of Patient Case', () => {
        // #region - Update First Free Text Implant Item to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Update First Free Text Implant Item to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Update Second Free Text Implant Item to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Update Second Free Text Implant Item to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.selectImplant(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Update First Free Text Supply Item to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Update First Free Text Supply Item to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        // #endregion

        // #region - Update Second Free Text Supply Item to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Update Second Free Text Supply Item to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.selectSupply(
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Verify Implant Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Implant Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Supply Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Saving the Patient Case in Inventory Face-Sheet

        cy.cGroupAsStep('Saving the Patient Case in Inventory Face-Sheet');

        inventoryReconciliation.selectDepletionVerifiedAndUpdate(YesOrNo.no);
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyUpdatedIosInventoryItem() {
    describe('Verify Free Text is converted to IOS Inventory Item after saving the Patient Case in Inventory Reconciliation Tracker', () => {
      it('Verify Free Text is converted to IOS Inventory Item after saving the Patient Case in Inventory Reconciliation Tracker', () => {
        // #region - Verify and Select Patient Case in Inventory Reconciliation Tracker

        cy.cGroupAsStep(
          'Verify and Select Patient Case in Inventory Reconciliation Tracker'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INVENTORY_RECONCILIATION[0]
        );
        inventoryReconciliation.selectDOSRecordsInDescendingOrder();
        // combinedCoding.verifyPatientRow(
        //   td_inv_rec_tcid_270007.PatientCase.PatientDetails.PatientFullName
        // );
        inventoryReconciliation.verifyDepletionWarningMessage(
          td_inv_rec_tcid_270007.PatientCase.PatientDetails.LastName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          false
        );
        inventoryReconciliation.selectPatientRow();
        // #endregion

        // #region - Verify Implant Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details after updating Free Text to IOS Inventory Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270007.InventoryTrackerInfo.Supplies[1].SupplyName
        );
        // #endregion

        // #region - Saving the Patient Case in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Saving the Patient Case in inventory reconciliation tracker'
        );

        inventoryReconciliation.selectDepletionVerifiedAndDone(YesOrNo.no);
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInCombineCodingChargeEntry() {
    describe('Verify Implants and Supplies coming from Inventory Reconciliation Tracker are displaying in Combine Coding Charge Entry Tracker', () => {
      it('Verify Implants and Supplies coming from Inventory Reconciliation Tracker are displaying in Combine Coding Charge Entry Tracker', () => {
        // #region - Verify Patient Row in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify Patient Row in Combine Coding Charge Entry Tracker'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.COMBINED_CODING[0]
        );
        // #endregion

        // #region - Select Period And Batch and Patient Case in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Select Period And Batch and Patient Case in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.selectPeriodAndBatch(td_inv_rec_tcid_270007.Charges[0]);
        sisOfficeDesktop.selectPatientRow(
          td_inv_rec_tcid_270007.PatientCase.PatientDetails.LastName,
          td_inv_rec_tcid_270007.PatientCase.PatientDetails.PatientFirstName
        );
        // #endregion

        // #region - Select All the Procedures from Scheduled Procedure and move to Performed Items in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Select All the Procedures from Scheduled Procedure and move to Performed Items in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.verifyScheduledProcedureItems(
          td_inv_rec_tcid_270007.Charges[0].CPT
        );
        combinedCoding.selectAllProcedureCheckbox();
        combinedCoding.addSelectedToPerformed();
        // #endregion

        // #region - Add Diagnosis Code for the Procedure in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Add Diagnosis Code for the Procedure in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.verifyAndSelectProcedure(
          td_inv_rec_tcid_270007.Charges[0].CPT
        );
        combinedCoding.selectDiagnosisCode(td_inv_rec_tcid_270007.Charges[0]);
        // #endregion

        // #region - Verify Implant Details with Units in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify Implant Details with Units in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.verifyAndSelectProcedure(
          td_inv_rec_tcid_270007.Charges[1].CPT
        );
        combinedCoding.enterHcpcsValue(
          td_inv_rec_tcid_270007.Charges[1].HCPCS!
        );
        combinedCoding.verifyUnits(td_inv_rec_tcid_270007.Charges[1].Units!);
        // #endregion

        // #region - Verify Supply Details with Units in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify Supply Details with Units in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.verifyAndSelectProcedure(
          td_inv_rec_tcid_270007.Charges[2].CPT
        );
        combinedCoding.enterHcpcsValue(
          td_inv_rec_tcid_270007.Charges[2].HCPCS!
        );
        combinedCoding.verifyUnits(td_inv_rec_tcid_270007.Charges[2].Units!);
        sisOfficeDesktop.clickPatientSearchIcon();
        // #endregion

        // #region - Verify First Implant Details in Implant Log under Documentation Section in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify First Implant Details in Implant Log under Documentation Section in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation.Implant
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation
            .Manufacturer
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation.Size
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation.Lot
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation.Serial
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation.Expiration
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation.Reference
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[0].Documentation.Notes
        );
        // #endregion

        // #region - Verify Second Implant Details in Implant Log under Documentation Section in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Verify Second Implant Details in Implant Log under Documentation Section in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation.Implant
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation
            .Manufacturer
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation.Size
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation.Lot
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation.Serial
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation.Expiration
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation.Reference
        );
        combinedCoding.verifyImplantText(
          td_inv_rec_tcid_270007.CasesToCodeDetails[1].Documentation.Notes
        );
        // #endregion

        // #region - Select Yes For Make Case Ready for Bill and Done in Combine Coding Charge Entry Tracker

        cy.cGroupAsStep(
          'Select Yes For Make Case Ready for Bill and Done in Combine Coding Charge Entry Tracker'
        );

        combinedCoding.selectReadyForBill(YesOrNo.yes);
        combinedCoding.clickOnDoneButton();
        // #endregion
      });
    });
  }

  verifyImplantSuppliesInFaceSheetInventory() {
    describe('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
      it('Verify Updated IOS Inventory Item with Tooltip Text is getting displayed in FaceSheet Inventory', () => {
        // #region - Search and Select Patient from global search

        cy.cGroupAsStep('Search and Select Patient from global search');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');

        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Implant Details in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Implant Details in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[1]
        );
        // #endregion

        // #region - Verify Supply Details In Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Supply Details In Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[1]
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[0].ItemNumber,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[0]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[1].ItemNumber,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[1]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Patient FaceSheet Inventory Tab

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Patient FaceSheet Inventory Tab'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[0]
            .InventorySupply.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ItemNumber,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[1]
            .InventorySupply.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[0].Implant
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[1].SupplyName
        );
        // #endregion
      });
    });
  }

  verifyIosImplantSupplyInOperative() {
    describe('Verify IOS Inventory Item Description on mouse hover of Info icon for the free text item', () => {
      it('Verify IOS Inventory Item Description on mouse hover of info Icon for the free text item', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        // #endregion

        // #region - Un Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Un Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_UNSIGN[0],
          YesOrNo.yes
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - UnSign Operative Department for Patient Case

        cy.cGroupAsStep('UnSign Operative Department for Patient Case');

        chartsCoverFaceSheet.unSignDepartment(YesOrNo.yes);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');
        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[0].Implant,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[0].Implant
        );
        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Implant[1].Implant,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Implant[1].Implant
        );
        // #endregion

        // #region - Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[0].SupplyName,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[0].SupplyName
        );
        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_inv_rec_tcid_270007.SisChartsInventoryInfo.Supplies[1].SupplyName,
          td_inv_rec_tcid_270007.FaceSheetInventoryInfo.Supplies[1].SupplyName
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        // #endregion

        // #region - Sign Operative Department

        cy.cGroupAsStep('Sign Operative Department');

        chartsCoverFaceSheet.signDepartment();
        // #endregion

        // #region - Click on Patient Face sheet Icon

        cy.cGroupAsStep('Click on Patient Face sheet Icon');

        chartsCoverFaceSheet.clickFaceSheetIcon();
        // #endregion

        // #region - Sign Patient Case in Nursing Desktop

        cy.cGroupAsStep('Sign Patient Case in Nursing Desktop');

        chartsCoverFaceSheet.caseDetailsSignUnSign(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.CASE_DETAILS_SIGN[0],
          YesOrNo.yes
        );
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
