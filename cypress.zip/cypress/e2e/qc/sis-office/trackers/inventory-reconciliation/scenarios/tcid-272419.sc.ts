import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import { YesOrNo } from '../../../../../../support/common-core-libs/application/common-core';

import { td_transfer_inv_items_on_discharge_tcid_272419 } from '../../../../../../fixtures/sis-office/trackers/inventory-reconciliation/transfer-inv-items-on-discharge-tcid-272419.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';
import { OR_LOGIN } from '../../../../../../app-modules-libs/sis-office/login/or/login.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_INVENTORY_RECONCILIATION } from '../../../../../../app-modules-libs/sis-office/trackers/or/inv-reconciliation.or';

import EnterpriseConfiguration from '../../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import { IosTextItem, FreeText } from '../../../../../../app-modules-libs/shared/application-settings/enums/nursing-configuration.enum';
import SISAnesthesiaDesktop from '../../../../../../app-modules-libs/sis-anesthesia/anesthesia';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import Transactions, {
  ContextMenu,
} from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import ChartsLogin from '../../../../../../app-modules-libs/sis-charts/login/login';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';
import InventoryReconciliation from '../../../../../../app-modules-libs/sis-office/trackers/inv-reconciliation';
import RecoveryDepartment from '../../../../../../app-modules-libs/sis-charts/departments/recovery/recovery';

import { DischargeCaseStatus } from '../../../../../../app-modules-libs/sis-charts/departments/recovery/enums/recovery.enum';
import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

/* instance variables */
const inventoryReconciliation = new InventoryReconciliation(
  td_transfer_inv_items_on_discharge_tcid_272419.PatientCase.PatientDetails
);
const recoveryDepartment = new RecoveryDepartment(
  td_transfer_inv_items_on_discharge_tcid_272419.Recovery
);
const sisOfficeDesktop = new SISOfficeDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();
const sisAnesthesiaDesktop = new SISAnesthesiaDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const sisChartsDesktop = new SISChartsDesktop();
const enterpriseConfig = new EnterpriseConfiguration();
const scheduleGrid = new ScheduleGrid();
const chartsLogin = new ChartsLogin();
const transactions = new Transactions();

export class TransferInvItemsOnDischargeTcId272419 {
  navigateToFeaturesTab() {
    describe('Enable Send Inventory to tracker upon discharge Feature', () => {
      it('Navigate to Feature Tab in Facility Management and Enable Send Inventory to tracker upon discharge Feature', () => {
        /*****************Test Begins***************/
        // #region - Navigate to Enterprise Settings

        cy.cGroupAsStep('Navigate to Enterprise Settings');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        // #endregion

        // #region - Navigate to Facility Management and Select Required Facility

        cy.cGroupAsStep(
          'Navigate to Facility Management and Select Required Facility'
        );

        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.FACILITY_MANAGEMENT
            .FACILITY_MANAGEMENT_HEADER[0]
        );
        enterpriseConfig.selectFacilityInFacilityManagement(
          OrganizationList.GEM_ORG_8
        );
        // #endregion

        // #region - Click on Features Tab in Facility Management

        cy.cGroupAsStep('Click on Features Tab in Facility Management');

        enterpriseConfig.clickOnFeaturesTab();
        // #endregion

        // #region - Enable Send Inventory to Tracker upon Patient Discharge Feature and Verify Tooltip Text

        cy.cGroupAsStep(
          'Enable Send Inventory to Tracker upon Discharge Features Tab in Facility Management'
        );

        enterpriseConfig.selectSendInventoryDischargeFeature();
        // #endregion

        // #region - Navigate to Business Desktop of the required Facility

        cy.cGroupAsStep(
          'Navigate to Business Desktop of the required Facility'
        );

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        chartsLogin.selectChangeLoginLocationFromEnterprise(
          OrganizationList.GEM_ORG_8
        );
        scheduleGrid.scheduleGridEnable();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  editPatientFormularyMedication() {
    describe('Update Formulary Medication with Required Details in Application Settings', () => {
      it('Add Inventory Medication, Administration Amount, Unit Usage of Measure for Formulary Medication in Application Settings', () => {
        // #region - Navigate to Formulary Tab in Application Settings

        cy.cGroupAsStep('Navigate to Application Settings');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        // #endregion

        // #region - Search and Select Formulary Medication and Add Inventory Medication, Administration Amount, Unit Usage of Measure for Formulary Medication

        cy.cGroupAsStep(
          'Search and Select Formulary Medication in Formulary Tab in Application Settings'
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.FORMULARY.SUB_HEADER[0],
          true
        );
        nursingConfiguration.editFormularyMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0],
          ContextMenu.edit
        );
        nursingConfiguration.editFormularyMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1],
          ContextMenu.edit
        );
        // #endregion
      });
    });
  }

  addMedicationInAnesthesia() {
    describe('Add Medication in Anesthesia Desktop', () => {
      it('Add and Administer Medication for Patient Case in Anesthesia', () => {
        // #region - Navigate to Anesthesia Desktop

        cy.cGroupAsStep('Navigate to Anesthesia Desktop');

        sisAnesthesiaDesktop.selectAnesthesiaInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_ANESTHESIA_DESKTOP_BUTTON[0]
        );
        // #endregion

        // #region - Select Patient In Anesthesia Desktop

        cy.cGroupAsStep('Select Patient In Anesthesia Desktop');

        sisAnesthesiaDesktop.selectPatientInSearchBox(
          td_transfer_inv_items_on_discharge_tcid_272419.PatientCase
            .PatientDetails
        );
        // #endregion

        // #region - Add and Administer Medication in Anesthesia

        cy.cGroupAsStep('Add and Administer Medication in Anesthesia');

        sisAnesthesiaDesktop.addAnesthesiaMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion
      });
    });
  }

  addImplantsSuppliesMedicationsInOperative() {
    describe('Add Implant, Supplies and Medications in Nursing Desktop', () => {
      it('Add Implant, Supplies and Medications in Work-list Under Operative Department', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_transfer_inv_items_on_discharge_tcid_272419.PatientCase
            .PatientDetails
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Select Yes Button for Implant Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Implant Questionnaire in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.clickImplantsQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Implants in Operative Department

        cy.cGroupAsStep('Add Implants in Operative Department');

        nursingConfiguration.addImplantsInPreferenceCard(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0],
          FreeText.free_text_item
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[1],
          IosTextItem.ios_text_item
        );
        nursingConfiguration.addImplantsInPreferenceCard(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[2],
          IosTextItem.ios_text_item
        );
        // #endregion

        // #region - Select Yes Button for Supply Questionnaire in Worklist in Operative Department

        cy.cGroupAsStep(
          'Select Yes Button for Supply Questionnaire in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.clickSuppliesQuestionStatus(YesOrNo.yes);
        // #endregion

        // #region - Add Supplies in Operative Department

        cy.cGroupAsStep('Add Supplies in Operative Department');

        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0],
          IosTextItem.ios_text_item
        );
        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[1],
          FreeText.free_text_item
        );
        chartsCoverFaceSheet.addFreeTextSuppliesInWorkList(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2],
          IosTextItem.ios_text_item
        );
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        // #endregion

        // #region - Navigating to Business Desktop

        cy.cGroupAsStep(
          'Add and Administer Medication in Orders Tab in Operative Department'
        );

        chartsCoverFaceSheet.verifyAddMedicationBtn();
        nursingConfiguration.addMedicationPhysicianOrder(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0],
          0,
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        nursingConfiguration.addMedicationPhysicianOrderDone();
        chartsCoverFaceSheet.departmentOrdersAdministerMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
        );
        // #endregion

        // #region - Navigate to Recovery Department and Discharging the Patient with Case Status as Partially Performed/Billable

        cy.cGroupAsStep(
          'Navigate to Recovery Department and Discharging the Patient with Case Status as Partially Performed/Billable'
        );

        chartsCoverFaceSheet.clickFaceSheetIcon();
        chartsCoverFaceSheet.selectDepartment(NursingDept.recovery);
        recoveryDepartment.dischargePatientInOutsideFacility(
          DischargeCaseStatus.partially_performed_billable
        );
        // #endregion

        // #region - Navigating to Business Desktop

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );
        // #endregion
      });
    });
  }

  verifyImplantSuppliesMedicationsInFaceSheetInventory() {
    describe('Verify Implants, Supplies and Medications in FaceSheet Inventory Tracker', () => {
      it('Verify Implants, Supplies and Medications are transferred to FaceSheet Inventory Tracker on Patient Discharge', () => {
        // #region - Search and Select Patient from global search

        cy.cGroupAsStep('Search and Select Patient from global search');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          td_transfer_inv_items_on_discharge_tcid_272419.PatientCase
            .PatientDetails
        );
        // #endregion

        // #region - Select Inventory Tab in the Patient FaceSheet

        cy.cGroupAsStep('Select Inventory Tab in the Patient FaceSheet');

        transactions.faceSheetSelectCaseOption(FaceSheetOptions.INVENTORY);
        // #endregion

        // #region - Verify Implant Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Implant Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[1]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[2]
        );
        // #endregion

        // #region - Verify Supply Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Supply Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[1]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2]
        );
        // #endregion

        // #region - Verify First Medication Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify First Medication Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTotalDepletedValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.TotalDepleted
        );
        inventoryReconciliation.verifyBilledValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.Billed
        );
        inventoryReconciliation.verifyAdministeredValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.Administered
        );
        inventoryReconciliation.verifyUsageTotalValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.UsageTotal
        );
        inventoryReconciliation.verifyWastedValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .SisChartsMedication?.Wasted
        );
        // #endregion

        // #region - Verify Second Medication Details in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Second Medication Details in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTotalDepletedValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.TotalDepleted
        );
        inventoryReconciliation.verifyBilledValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.Billed
        );
        inventoryReconciliation.verifyAdministeredValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.Administered
        );
        inventoryReconciliation.verifyUsageTotalValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.UsageTotal
        );
        inventoryReconciliation.verifyWastedValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .SisChartsMedication?.Wasted
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Item

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0].Implant
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[4].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[4].ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[4]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[5].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[5].ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[5]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0]
            .InventorySupply?.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0]
            .InventorySupply?.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .FREE_TEXT_ITEM[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[1].SupplyName
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2]
            .InventorySupply?.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2]
            .InventorySupply?.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Tooltip Text for Medication Name in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyTooltipTextForMedicationInventoryItem(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .Medication,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .FormularyMedication.IosInventoryMedication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForMedicationInventoryItem(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .Medication,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .FormularyMedication.IosInventoryMedication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Implant Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0].Implant,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0]
        );
        // #endregion

        // #region - Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker

        cy.cGroupAsStep(
          'Verify Free Text Tooltip Text for Supply Item in inventory reconciliation tracker'
        );

        inventoryReconciliation.verifyFreeTextToolTipText(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[1].SupplyName,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0]
        );
        // #endregion

        // #region - Update Free Text Implant Item to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Update Free Text Implant Item to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.selectImplant(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0].Implant
        );
        inventoryReconciliation.clickImplantsClearIcon(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0].Implant
        );
        inventoryReconciliation.addImplantInImplantProstheticPopUp(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3]
        );
        inventoryReconciliation.verifyImplantOrProstheticInfo(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3]
        );
        inventoryReconciliation.clickAddImplantProstheticDoneBtn();
        // #endregion

        // #region - Update Free Text Supply Item to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Update Free Text Supply Item to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.selectSupply(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[1].SupplyName
        );
        inventoryReconciliation.clearSupplyFreeText();
        inventoryReconciliation.clickSupplyKeyBoardIcon();
        inventoryReconciliation.addSupply(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3].SupplyName
        );
        // #endregion

        // #region - Verify Implant Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Implant Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyImplantsInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3]
        );
        // #endregion

        // #region - Verify Supply Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Supply Details after updating Free Text to IOS Inventory Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifySuppliesInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3]
        );
        // #endregion

        // #region - Verify Original Implant Free Text Description for IOS Implant Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Original Implant Free Text Description for IOS Implant Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].Implant
        );
        // #endregion

        // #region - Verify Original Supply Free Text Description for IOS Supply Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Original Supply Free Text Description for IOS Supply Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyOriginalFreeTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[1].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3].SupplyName
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant and Supply Name after Converting from Free Text to Ios Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant and Supply Name after Converting from Free Text to Ios Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3]
            .InventorySupply?.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3]
            .InventorySupply?.ManufacturerNumber
        );
        // #endregion

        // #region - Depleting the Patient Case in Inventory Face-Sheet

        cy.cGroupAsStep('Depleting the Patient Case in Inventory Face-Sheet');

        inventoryReconciliation.selectDepletionVerifiedAndUpdate(YesOrNo.yes);
        // #endregion
      });
    });
  }

  verifyImplantSuppliesMedicationsInFaceSheetInventoryAfterDepletion() {
    describe('Verify Implants, Supplies and Medications in FaceSheet Inventory', () => {
      it('Verify Implants, Supplies and Medications in FaceSheet Inventory After Depletion', () => {
        // #region - Verify Implant Details in Inventory Face-Sheet

        cy.cGroupAsStep('Verify Implant Details in Inventory Face-Sheet');

        sisOfficeDesktop.clickPatientSearchIcon();
        inventoryReconciliation.verifyImplantsInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[6]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[7]
        );
        inventoryReconciliation.verifyImplantsInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[8]
        );
        // #endregion

        // #region - Verify Supply Details in Inventory Face-Sheet

        cy.cGroupAsStep('Verify Supply Details in Inventory Face-Sheet');

        inventoryReconciliation.verifySuppliesInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[4]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[5]
        );
        inventoryReconciliation.verifySuppliesInInventory(
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[6]
        );
        // #endregion

        // #region - Verify First Medication Details in Inventory Face-Sheet
        cy.cGroupAsStep(
          'Verify First Medication Details in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTotalDepletedValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .InventoryMedication.TotalDepleted
        );
        inventoryReconciliation.verifyBilledValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .InventoryMedication.Billed
        );
        inventoryReconciliation.verifyAdministeredValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .InventoryMedication.Administered
        );
        inventoryReconciliation.verifyUsageTotalValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .InventoryMedication.UsageTotal
        );
        inventoryReconciliation.verifyWastedValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[2]
            .SisChartsMedication?.Wasted
        );
        // #endregion

        // #region - Verify Second Medication Details in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Second Medication Details in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTotalDepletedValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .InventoryMedication.TotalDepleted
        );
        inventoryReconciliation.verifyBilledValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .InventoryMedication.Billed
        );
        inventoryReconciliation.verifyAdministeredValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .InventoryMedication.Administered
        );
        inventoryReconciliation.verifyUsageTotalValueForMedication(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .InventoryMedication.UsageTotal
        );
        inventoryReconciliation.verifyWastedValueForMedications(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .Medication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[3]
            .SisChartsMedication?.Wasted
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant Name in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant Name in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[4].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[4].ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[4]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[5].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[5].ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[5]
            .ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Supply Name in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Supply Name in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0]
            .InventorySupply?.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[0]
            .InventorySupply?.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2]
            .InventorySupply?.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[2]
            .InventorySupply?.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3]
            .InventorySupply?.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3]
            .InventorySupply?.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Medication Name in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Medication Name in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForMedicationInventoryItem(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .Medication,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .FormularyMedication.IosInventoryMedication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[0]
            .InventoryMedication.ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForMedicationInventoryItem(
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .Medication,
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .FormularyMedication.IosInventoryMedication,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Medication[1]
            .InventoryMedication.ManufacturerNumber
        );
        // #endregion

        // #region - Verify Tooltip Text for Implant and Supply Name after Converting from Free Text to Ios Item in Inventory Face-Sheet

        cy.cGroupAsStep(
          'Verify Tooltip Text for Implant and Supply Name after Converting from Free Text to Ios Item in Inventory Face-Sheet'
        );

        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3]
            .ManufacturerNumber
        );
        inventoryReconciliation.verifyTooltipTextForInventoryItem(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IOS_TEXT_ITEM_WITH_MANUFACTURER[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3]
            .InventorySupply?.ItemNumber,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3]
            .InventorySupply?.ManufacturerNumber
        );
        // #endregion
      });
    });
  }

  verifyIosImplantSupplyInOperative() {
    describe('Verify IOS Inventory Item Description in Nursing Desktop', () => {
      it('Verify IOS Inventory Item Description on mouse hover of info Icon for the free text item', () => {
        // #region - Navigate to Nursing Desktop

        cy.cGroupAsStep('Navigate to Nursing Desktop');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        // #endregion

        // #region - Select Patient in Nursing Desktop

        cy.cGroupAsStep('Select Patient in Nursing Desktop');

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_transfer_inv_items_on_discharge_tcid_272419.PatientCase
            .PatientDetails
        );
        // #endregion

        // #region - Select Operative Department for Patient Case

        cy.cGroupAsStep('Select Operative Department for Patient Case');

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        // #endregion

        // #region - Navigate to Worklist Tab in Operative Department

        cy.cGroupAsStep('Navigate to Worklist Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.WORKLIST_POPUP[0]
        );
        // #endregion

        // #region - Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Implant Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .IMPLANTS_TABLE.IMPLANTS[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[0].Implant,
          td_transfer_inv_items_on_discharge_tcid_272419.Implant[3].Implant
        );
        // #endregion

        // #region - Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department

        cy.cGroupAsStep(
          'Verify Supply Original IOS Text Description for Free Text Item in Worklist in Operative Department'
        );

        chartsCoverFaceSheet.verifyOriginalIosTextDescription(
          OR_INVENTORY_RECONCILIATION.INVENTORY_RECONCILIATION.INVENTORY
            .SUPPLIES_TABLE.SUPPLIES[0],
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[1].SupplyName,
          td_transfer_inv_items_on_discharge_tcid_272419.Supplies[3].SupplyName
        );
        sisOfficeDesktop.clickPatientSearchIcon();
        // #endregion

        // #region - Navigate to Orders Tab in Operative Department

        cy.cGroupAsStep('Navigate to Orders Tab in Operative Department');

        chartsCoverFaceSheet.selectDepartmentTaskPanel(
          OR_CHARTS_COVER_FACE_SHEET.MY_TASKS.ORDERS.SUB_HEADER[0]
        );
        chartsCoverFaceSheet.verifyAddMedicationBtn();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
