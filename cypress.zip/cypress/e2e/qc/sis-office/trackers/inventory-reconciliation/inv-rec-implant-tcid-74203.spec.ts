/****Revision History **************
 * 20/06/22, Debasish, Updated and applied best practices to be followed during script development
 * 06/06/22, Lalitha, gem-fmdplt-sc2354
 */
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { InvRecImplantTcId74203 } from './scenarios/tcid-74203.sc';
import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

/* instance variables */
const invRecImplant = new InvRecImplantTcId74203();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verifying Inventory Reconciliation Implant Table Layout for Pulling Implants in the Implants Modal Window
 * US - 16485 - Verify Implant Table Layout
 * US - 16486 - Pulling Implants
 * US - 16487 - Setting/Pulling Implant Modal Window
 * Script Execution Approach -
 * 1. Navigating to Inventory Reconciliation For <What Kind Of Facility/Organization ??>
 * 2. Selecting Patient Row
 * 3. In Inventory, verifying implants added to patient and Max length permitted to used input box
 * 4. Clicking on implant and verifying the Add Implant or Prosthetic Popup
 * 5. Entering Implant data in Implant or Prosthetic Popup
 * 6. Verifying entered Implant info getting pulled back
 * 7. Close the popup and patient by clicking Done
 * 8. Close the patient inventory by clicking Done
 * 9. logout
 */

describe(
  'Verifying Implant Table Layout for Pulling Implants in the Implants Modal Window for Patient case in Inventory Reconciliation Tracker ',
  {
    tags: [
      'trackers',
      'inventory-reconciliation',
      'implant',
      'US#16485',
      'US#16486',
      'US#16487',
      'TC#74203',
    ],
  },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_3[0],
        Password: UserList.GEM_USER_3[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_INVENTORY_DISABLED_27, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        // Verifying Inventory Reconciliation Implant Table Layout for Pulling Implants in the Implants Modal Window
        invRecImplant.verifyInventoryReconImplantTable();
      }
    );
    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
