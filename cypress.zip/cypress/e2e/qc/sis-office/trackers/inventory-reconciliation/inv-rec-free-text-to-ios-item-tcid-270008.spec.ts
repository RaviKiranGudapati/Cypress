import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { InvRecFreeTextToIosItemTcId270008 } from './scenarios/tcid-270008.sc';

/* instance variables */
const invRecFreeTextToIosItem = new InvRecFreeTextToIosItemTcId270008();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify the added quantity for Free text Items with Inventory description from SIS charts is displaying at Inventory Reconciliation tracker for General case
 * US - 263745 - Inventory Tracker - Free Text Items
 * Script Execution Approach -
 * 1. Navigating to Application Settings
 * 2. Select Preference Card in Preference Card Configuration
 * 3. Add Free Tex Implant and Free Text Supply
 * 4. Navigate to Nursing Desktop
 * 5. Selecting Patient Row
 * 6. Navigate to Operative Department
 * 7. Navigate to WorkList Task Panel in Operative Department
 * 8. Verify Free Text Implant and Supply are imported from Preference Card
 * 9. Sign the Department and Patient Case.
 * 10. Navigate to Inventory Reconciliation Tracker
 * 11. Selecting Patient Row
 * 12. Verify Free Text Implant and Supply Name with Details
 * 13. Verify Free Text Tooltip Text
 * 14. Convert Free Text Implant and Supply to IOS Inventory Item
 * 15. Verify Inventory Item Tooltip Text
 * 16. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 17. Deplete the Patient Case by selecting Depletion Verified as Yes and clicking on Done.
 * 18. Navigate to Nursing Desktop
 * 19. Selecting Patient Row
 * 20. Un-Sign the Patient Case and Operative Department.
 * 21. Navigate to WorkList Task Panel in Operative Department
 * 22. Update Used Quantity for Existing Implant and Supply
 * 23. Add New Free Text Implant and Supply.
 * 24. Sign the Department and Patient Case.
 * 25. Navigate to Inventory Reconciliation Tracker
 * 26. Selecting Patient Row
 * 27. Verify Free Text Implant and Supply Name with Details
 * 28. Verify Free Text Tooltip Text
 * 29. Convert Free Text Implant and Supply to IOS Inventory Item
 * 30. Verify Inventory Item Tooltip Text
 * 31. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 32. Verify New Label for New Free Text Implant and Supply.
 * 33. Verify Update Label for Existing IOS Implant and Supply which is converted form Free Text to IOS Item
 * 34. Verify Tooltip for Update and New Label.
 * 35. Deplete the Patient Case by selecting Depletion Verified as Yes and clicking on Done.
 * 36. Navigate to Coding Tracker.
 * 37. Selecting Patient Row
 * 38. Verify Inventory Item with Units.
 * 39. Make Case as Ready for Charge by clicking Yes and Done button
 * 40. Navigate to Charge Entry Tracker.
 * 41. Selecting Patient Row
 * 42. Verify Inventory Item with Units
 * 43. Make Case as Ready for Bill by clicking Yes and Done button
 * 44. Navigate to Patient face-sheet.
 * 45. Navigate to Inventory Face-sheet Tab.
 * 46. Verify Inventory Item Tooltip Text
 * 47. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 48. Verify Tooltip Icon with Free Text as Description
 * 49. Navigate to Nursing Desktop
 * 50. Select Patient From Schedule Grid
 * 51. Select Operative Department
 * 52. Un-Sign Operative Department
 * 53. Verify Tooltip Text with IOS Inventory Item on mouse hover of Free Text Item
 * 54. Sign Operative Department
 * 55. Navigate to Home Page of Nursing Desktop
 * 56. logout
 */

describe(
  'Verify the added quantity for Free text Items with Inventory description from SIS charts is displaying at Inventory Reconciliation tracker ',
  {
    tags: ['inventory-reconciliation', 'TC#270008', 'US#263745'],
  },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_8[0],
        Password: UserList.GEM_USER_8[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        invRecFreeTextToIosItem.addFreeTextItemPreferenceCard();
        invRecFreeTextToIosItem.verifyFreeTextItemInOperative();
        invRecFreeTextToIosItem.verifyImplantSuppliesInInventory();
        invRecFreeTextToIosItem.updateFreeTextItemToIosInventoryItem();
        invRecFreeTextToIosItem.updateExistingAndAddNewFreeTextItemInOperative();
        invRecFreeTextToIosItem.verifyUpdatedImplantSuppliesInInventory();
        invRecFreeTextToIosItem.updateNewFreeTextItemToIosInventoryItem();
        invRecFreeTextToIosItem.verifyImplantSuppliesInCoding();
        invRecFreeTextToIosItem.verifyImplantSuppliesInChargeEntry();
        invRecFreeTextToIosItem.verifyImplantSuppliesInFaceSheetInventory();
        invRecFreeTextToIosItem.verifyIosImplantSupplyInOperative();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
