import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { TransferInvItemsOnDischargeTcId272243 } from './scenarios/tcid-272243.sc';

/* instance variables */
const invRecImplantSupply = new TransferInvItemsOnDischargeTcId272243();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify the Inventory details are moving from Charts to Office on discharging the Patient with the status is Performed for a Recovery case.
 * US - 243610 - SIS Office - Inventory - Discharge of Patient to trigger Inventory
 * Script Execution Approach -
 * 1. Navigate to Enterprise Settings.
 * 2. Navigate to Facility Management
 * 3. Enable Send Inventory To Tracker Upon Discharge Feature and Verify Tooltip Text
 * 4. Navigate to Required Facility
 * 5. Navigating to Application Settings
 * 6. Select Preference Card in Preference Card Configuration
 * 7. Add Free Text Implant, Ios Billable Implant, Ios Non-Billable Implant and Free Text Supply, Ios Billable Supply, Ios Non-Billable Supply
 * 8. Navigate to Formulary Tab ad Search and Select Required Formulary Medication
 * 9. Edit Formulary Medication and Add Inventory Medication, Administration Amount and Usage Unit of Measure
 * 10. Select Compound Medication as Yes for One Medication and Click on Done
 * 11. Navigate to Physician Orders Tab ad Search and Select Required Physician Order
 * 12. Click on Add Medication Order for Operative Department and add one Formulary Medication and Click on Done
 * 13. Navigate to Anesthesia Plan Tab
 * 14. Add New Plan and Add Second Formulary Medication and Click on Done
 * 15. Navigate to Anesthesia Desktop
 * 16. Selecting Patient Row
 * 17. Click on Pre-Op Slide Out
 * 18. Add Anesthesia Plan in Pre-Op Exam Tab and Administer the Medications and Document Dose
 * 19. Navigate to Nursing Desktop
 * 20. Selecting Patient Row
 * 21. Navigate to Operative Department
 * 22. Navigate to WorkList Task Panel in Operative Department
 * 23. Verify Free Text Implant, Ios Billable & Non-Billable Implant and Supply are imported from Preference Card
 * 24. Navigate to Orders Tab
 * 25. Acknowledge Physician Order
 * 26. Administer the Medications and Document Dose and Click on Done
 * 27. Discharge the Patient Case with Discharge Case Status as Performed in Recovery Department for Outside Facility
 * 28. Navigate to Inventory Reconciliation Tracker
 * 29. Selecting Patient Row
 * 30. Verify Free Text, Ios Billable & Non-Billable Implant and Supply Name with Details
 * 28. Verify Medication Details
 * 29. Verify Free Text Tooltip Text
 * 30. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 31. Saving the Patient Case by selecting Depletion Verified as No and clicking on Done.
 * 32. logout
 */

describe(
  'Verify the Inventory details are moving from Charts to Office on discharging the Patient with the status is Performed for a Recovery case ',
  {
    tags: ['inventory-reconciliation', 'TC#272243', 'US#246310'],
  },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_8[0],
        Password: UserList.GEM_USER_8[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_8, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        invRecImplantSupply.navigateToFeaturesTab();
        invRecImplantSupply.editPatientFormularyMedication();
        invRecImplantSupply.editPatientPhysicianOrders();
        invRecImplantSupply.addPatientAnesthesiaPlan();
        invRecImplantSupply.addImplantsSuppliesPreferenceCard();
        invRecImplantSupply.addMedicationInAnesthesia();
        invRecImplantSupply.verifyImplantsSuppliesInOperative();
        invRecImplantSupply.verifyImplantSuppliesMedicationsInInventory();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
