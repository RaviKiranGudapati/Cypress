import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { InvRecFreeTextToIosItemTcId270007 } from './scenarios/tcid-270007.sc';

/* instance variables */
const invRecFreeTextToIosItem = new InvRecFreeTextToIosItemTcId270007();

/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verify the Free text Item description is displaying on hovering from Inventory tracker for General case
 * US - 263745 - Inventory Tracker - Free Text Items
 * Script Execution Approach -
 * 1. Navigating to Nursing Desktop
 * 2. Select Patient From Schedule Grid
 * 3. Select Operative Department
 * 4. Add Free Tex Implant and Free Text Supply under Work list in Operative Department
 * 5. Navigate to Order Tab to save the details of Free text Implant and Supply in Operative Department
 * 6. Sign Operative Department
 * 7. Navigate to Patient Face Sheet
 * 8. Sign Patient Case
 * 9. Navigate to Schedule Grid in SIS Office
 * 10. Navigate to Inventory Reconciliation Tracker
 * 11. Selecting Patient Row
 * 12. Verify Free Text Implant and Supply Name with Details
 * 13. Verify Free Text Tooltip Text
 * 14. Convert Free Text Implant and Supply to IOS Inventory Item
 * 15. Verify Inventory Item Tooltip Text
 * 16. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 17. Save the Patient Case by clicking on Done.
 * 18. Selecting Patient Row in Inventory Reconciliation Tracker
 * 19. Verify Inventory Item Tooltip Text and Verify Tooltip Icon with Free Text as Description
 * 20. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 21. Save the Patient Case by clicking on Done.
 * 23. Navigate to Combine Coding Charge Entry Tracker.
 * 24. Selecting Patient Row
 * 25. Verify Inventory Item with Units.
 * 26. Make Case as Ready for Bill by clicking Yes and Done button
 * 27. Navigate to Patient face-sheet.
 * 28. Navigate to Inventory Face-sheet Tab.
 * 29. Verify Inventory Item Tooltip Text
 * 30. Verify Item Description, Item Number and Manufacturer Number for the inventory item
 * 31. Verify Tooltip Icon with Free Text as Description
 * 33. Navigate to Nursing Desktop
 * 34. Select Patient From Schedule Grid
 * 35. Select Operative Department
 * 36. Un-Sign Operative Department
 * 37. Verify Tooltip Text with IOS Inventory Item on mouse hover of Free Text Item
 * 38. Sign Operative Department
 * 39. Navigate to Home Page of Nursing Desktop
 * 40. logout
 */

describe(
  'Verify the Free text Item description is displaying on hovering from Inventory tracker for General case ',
  {
    tags: ['inventory-reconciliation', 'TC#270007', 'US#263745'],
  },
  () => {
    // before suite
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_14[0],
        Password: UserList.GEM_USER_14[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_14, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        invRecFreeTextToIosItem.addFreeTextItemInOperative();
        invRecFreeTextToIosItem.verifyImplantSuppliesInInventoryFaceSheet();
        invRecFreeTextToIosItem.updateFreeTextItemToIosInventoryItem();
        invRecFreeTextToIosItem.verifyUpdatedIosInventoryItem();
        invRecFreeTextToIosItem.verifyImplantSuppliesInCombineCodingChargeEntry();
        invRecFreeTextToIosItem.verifyImplantSuppliesInFaceSheetInventory();
        invRecFreeTextToIosItem.verifyIosImplantSupplyInOperative();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
