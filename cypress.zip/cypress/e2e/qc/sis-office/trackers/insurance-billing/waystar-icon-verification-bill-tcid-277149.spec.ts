import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { WaystarTcId277149 } from './scenarios/tcid-277149.sc';

/* instance variables */
const waystar = new WaystarTcId277149();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation
 * 1. Login to application
 * 2. Navigate to Transactions and change the responsible party to Guarantor
 * 3. Verify that waystar icon is not displayed in affected areas
 * 4. Bill from Insurance billing and verify that waystar icon is displayed in all affected areas
 * 5. Uncheck the bill and verify that waystar icon goes away in all affected areas
 * 6. Print the bill statement and verify that waystar icon is not displayed in all affected areas
 * */

describe(
  'Verify Waystar icon for insurance charges billed from Insurance billing, Face sheet, RCM, Patient Statements',
  {
    tags: [
      'insurance-billing',
      'rcm',
      'facesheet',
      'patient-statements',
      'TC#277149',
      'US#257723',
    ],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        waystar.enablingConditions();
        waystar.verifyWaystarIconBill();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
