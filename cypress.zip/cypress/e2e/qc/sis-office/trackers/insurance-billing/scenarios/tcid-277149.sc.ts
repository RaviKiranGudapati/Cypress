import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  AddOnFeatures,
  LeftOrRight,
} from '../../../../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../../../../support/common-core-libs/framework/common-utils';
import { CoreCssClasses } from '../../../../../../support/common-core-libs/core-css-classes';

import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { td_waystar_billed_tcid_277149 } from '../../../../../../fixtures/sis-office/trackers/insurance-billing/waystar-icon-verification-bill-tcid-277149.td';

import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

import { OR_PATIENT_STATEMENT } from '../../../../../../app-modules-libs/sis-office/trackers/or/patient-statement.or';
import { OR_EXCHANGE_CONFIGURATION } from '../../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';

import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import LedgerTabFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import PatientDetailsFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import PatientStatement from '../../../../../../app-modules-libs/sis-office/trackers/patient-statement';
import RevenueCycleManagement from '../../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import { InsuranceBillingOptions } from '../../../../../../app-modules-libs/sis-office/trackers/enums/insurance-billing.enum';
import InsuranceBilling from '../../../../../../app-modules-libs/sis-office/trackers/insurance-billing';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const revenueCycleManagement = new RevenueCycleManagement();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const patientDetailsFacesheet = new PatientDetailsFaceSheet();
const createCase = new CreateCase(td_waystar_billed_tcid_277149.PatientCase);
const facesheetCases = new FaceSheetCases();
const transactions = new Transactions();
const insuranceBilling = new InsuranceBilling();
const patientStatement = new PatientStatement();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();

/* const values */
const patient =
  td_waystar_billed_tcid_277149.PatientCase.PatientDetails.LastName +
  `, ` +
  td_waystar_billed_tcid_277149.PatientCase.PatientDetails.PatientFirstName;
const hiddenState = CommonUtils.concatenate(
  CoreCssClasses.Button.loc_p_element_value,
  ' ',
  CoreCssClasses.ClassPrefix.loc_fa_value
);
const visibleState = CommonUtils.concatenate(
  CoreCssClasses.Button.loc_p_element_value,
  ' ',
  CoreCssClasses.ClassPrefix.loc_fa_value,
  ' ',
  CoreCssClasses.Button.loc_fa_circle_o_value
);

export class WaystarTcId277149 {
  enablingConditions() {
    describe('Enabling settings in add-on feature and patient statements', () => {
      it('Enabling settings by logging in via Sis admin', () => {
        // #region Enabling settings by logging in via Sis Admin

        cy.cGroupAsStep('Enabling settings by logging in via Sis Admin');

        cy.setFeature(
          AddOnFeatures.patient_statement_include_insurance_csv_changes_id,
          true
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_EXCHANGE_CONFIGURATION.PATIENT_STATEMENTS[0]
        );
        nursingConfiguration.selectIncludeInsuranceCharges(LeftOrRight.right);
        cy.cLogOut();

        // #endregion
      });
    });
  }

  verifyWaystarIconBill() {
    describe('Verify Waystar icon for insurance bill charges', () => {
      it('Verify Waystar icon for insurance charges billed from Insurance billing, Face sheet, RCM, Patient Statements', () => {
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_2[0],
          Password: UserList.GEM_USER_2[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin);

        // #region - Navigate to checkin window and update address details

        cy.cGroupAsStep(
          'Navigate to checkin window and update address details'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
            .PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.enterPatientDetailsAddressFields(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        createCase.clickCheckInDone();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        // #endregion

        // #region - Verify that Waystar icon is not visible in Ledger, Transactions and RCM Tracker

        cy.cGroupAsStep(
          'Verify that Waystar icon is not visible in Ledger, Transactions and RCM Tracker'
        );

        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.transferCharge(
          td_waystar_billed_tcid_277149.Transfers.CptCode[0],
          td_waystar_billed_tcid_277149.Transfers.Period,
          td_waystar_billed_tcid_277149.Transfers.Batch,
          td_waystar_billed_tcid_277149.Transfers.NextResponsibleParty[0],
          td_waystar_billed_tcid_277149.Transfers.TransferTransactionCode[0]
        );
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .BLOCK_SCHEDULE[0]
        );
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .CASE_REQUESTS[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.scrollToLastRowInTracker();
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Bill insurance charge from Insurance Billing Tracker

        cy.cGroupAsStep('Bill insurance charge from Insurance Billing Tracker');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INSURANCE_BILLING[0]
        );
        insuranceBilling.expandPlusIconBasedOnCarrier(
          td_waystar_billed_tcid_277149.InsuranceBilling.InsuranceCarrier
        );
        insuranceBilling.clickCheckboxInExpandedIcon(
          td_waystar_billed_tcid_277149.InsuranceBilling.PatientName
        );
        insuranceBilling.selectButtonsInInsuranceBilling(
          InsuranceBillingOptions.bill_selected_payers
        );

        // #endregion

        // #region - Verify that waystar icon is displayed for insurance charge in Ledger, Transactions and RCM

        cy.cGroupAsStep(
          'Verify that waystar icon is displayed for insurance charge in Ledger, Transactions and RCM'
        );

        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(visibleState);
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );

        // #endregion

        // #region - Uncheck billed from Ledger and verify waystar icon goes away

        cy.cGroupAsStep(
          'Uncheck billed from Ledger and verify waystar icon goes away'
        );

        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickBilledCheckbox(0);
        patientDetailsFacesheet.clickOnCasesTab();
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Bill insurance charge from Ledger and verify waystar icon is displayed in Ledger, Transactions and RCM

        cy.cGroupAsStep(
          'Bill insurance charge from Ledger and verify waystar icon is displayed in Ledger, Transactions and RCM'
        );

        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(0);
        ledgerTabFaceSheet.clickBillSelectedInsuranceCharge();
        ledgerTabFaceSheet.verifyEmailSent(0, true);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, true);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(visibleState);

        // #endregion

        // #region - Bill patient statements including insurance from Ledger and verify waystar icon not displayed

        cy.cGroupAsStep(
          'Bill patient statements including insurance from Ledger and verify waystar icon not displayed'
        );

        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickBilledCheckbox(0);
        patientDetailsFacesheet.clickOnCasesTab();
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(0);
        ledgerTabFaceSheet.selectChargesCheckBox(1);
        ledgerTabFaceSheet.clickBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyBillPatientStatementDialog();
        ledgerTabFaceSheet.clickYesOrNoBillSelectedPatientStatement();
        ledgerTabFaceSheet.verifyStatementSentDialog();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Bill insurance charge from RCM and verify waystar icon is displayed in Ledger, Transactions and RCM

        cy.cGroupAsStep(
          'Bill insurance charge from RCM and verify waystar icon is displayed in Ledger, Transactions and RCM'
        );

        revenueCycleManagement.clickOnBillingHistory();
        revenueCycleManagement.selectChargesCheckBox(0);
        revenueCycleManagement.clickBillSelectedInsuranceCharge();
        revenueCycleManagement.verifyWaystarIcon(visibleState);
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0);
        transactions.verifyEmailSent(1, false);

        // #endregion

        // #region - Uncheck bill for insurance from Transactions and verify waystar icon goes away

        cy.cGroupAsStep(
          'Uncheck bill for insurance from Transactions and verify waystar icon goes away'
        );

        transactions.clickBilledCheckMark(
          td_waystar_billed_tcid_277149.Charge[1].cptCode
        );
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Bill patient statement from RCM and verify waystar icon not displayed

        cy.cGroupAsStep(
          'Bill patient statement from RCM and verify waystar icon not displayed'
        );

        revenueCycleManagement.clickOnBillingHistory();
        revenueCycleManagement.selectChargesCheckBox(0);
        revenueCycleManagement.selectChargesCheckBox(1);
        revenueCycleManagement.clickBillSelectedPatientStatement();
        revenueCycleManagement.clickYesOrNoBillSelectedPatientStatement();
        revenueCycleManagement.verifyStatementSentDialog();
        revenueCycleManagement.verifyWaystarIcon(hiddenState);
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        transactions.clickBilledCheckMark(
          td_waystar_billed_tcid_277149.Charge[0].cptCode
        );
        sisOfficeDesktop.selectSisLogo();

        // #endregion

        // #region - Bill patient statement from Patient Statement tracker and verify waystar icon not displayed

        cy.cGroupAsStep(
          'Bill patient statement from Patient Statement tracker and verify waystar icon not displayed'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );
        patientStatement.selectCheckboxByPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
            .PatientFirstName
        );
        patientStatement.selectButtonsInPatientStatement(
          OR_PATIENT_STATEMENT.BILL_SELECTED_PATIENTS[0]
        );
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277149.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        facesheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion
      });
    });
  }
}
