import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  AddOnFeatures,
  LeftOrRight,
} from '../../../../../../support/common-core-libs/application/common-core';
import { CommonUtils } from '../../../../../../support/common-core-libs/framework/common-utils';
import { CoreCssClasses } from '../../../../../../support/common-core-libs/core-css-classes';

import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { td_waystar_billed_tcid_277150 } from '../../../../../../fixtures/sis-office/trackers/insurance-billing/waystar-icon-verification-print-tcid-277150.td';

import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

import { OR_PATIENT_STATEMENT } from '../../../../../../app-modules-libs/sis-office/trackers/or/patient-statement.or';
import { OR_EXCHANGE_CONFIGURATION } from '../../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_SCHEDULE_GRID } from '../../../../../../app-modules-libs/sis-office/case-creation/or/schedule-grid.or';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import ScheduleGrid from '../../../../../../app-modules-libs/sis-office/case-creation/schedule-grid';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import LedgerTabFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-ledger';
import PatientDetailsFaceSheet from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-patientdetails';
import Transactions from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import PatientStatement from '../../../../../../app-modules-libs/sis-office/trackers/patient-statement';
import RevenueCycleManagement from '../../../../../../app-modules-libs/sis-office/trackers/revenue-cycle-management';
import { InsuranceBillingOptions } from '../../../../../../app-modules-libs/sis-office/trackers/enums/insurance-billing.enum';
import InsuranceBilling from '../../../../../../app-modules-libs/sis-office/trackers/insurance-billing';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const scheduleGrid = new ScheduleGrid();
const revenueCycleManagement = new RevenueCycleManagement();
const ledgerTabFaceSheet = new LedgerTabFaceSheet();
const patientDetailsFacesheet = new PatientDetailsFaceSheet();
const createCase = new CreateCase(td_waystar_billed_tcid_277150.PatientCase);
const faceSheetCases = new FaceSheetCases();
const transactions = new Transactions();
const insuranceBilling = new InsuranceBilling();
const patientStatement = new PatientStatement();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfiguration = new NursingConfiguration();

/* const values */
const patient =
  td_waystar_billed_tcid_277150.PatientCase.PatientDetails.LastName +
  `, ` +
  td_waystar_billed_tcid_277150.PatientCase.PatientDetails.PatientFirstName;
const hiddenState = CommonUtils.concatenate(
  CoreCssClasses.Button.loc_p_element_value,
  ' ',
  CoreCssClasses.ClassPrefix.loc_fa_value
);

export class WaystarTcId277150 {
  enablingConditions() {
    describe('Enabling settings in add-on feature and patient statements', () => {
      it('Enabling settings by logging in via Sis admin', () => {
        // #region Enabling settings by logging in via Sis Admin

        cy.cGroupAsStep('Enabling settings by logging in via Sis Admin');

        cy.setFeature(
          AddOnFeatures.patient_statement_include_insurance_csv_changes_id,
          true
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_EXCHANGE_CONFIGURATION.PATIENT_STATEMENTS[0]
        );
        nursingConfiguration.selectIncludeInsuranceCharges(LeftOrRight.right);
        cy.cLogOut();

        // #endregion
      });
    });
  }

  verifyWaystarIconPrint() {
    describe('Verify Waystar icon for print insurance charges', () => {
      it('Verify Waystar icon for insurance charges printed from Insurance billing, Face sheet, RCM, Patient Statements', () => {
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_2[0],
          Password: UserList.GEM_USER_2[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin);
        // #region - Navigate to checkin window and update address details

        cy.cGroupAsStep(
          'Navigate to checkin window and update address details'
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        scheduleGrid.selectPatientAndClickOnIconInCaseDetailsPopup(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
            .PatientFirstName!,
          OR_SCHEDULE_GRID.CASE_DETAILS_POPUP.CHECK_IN_ICON[0]
        );
        createCase.enterPatientDetailsAddressFields(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        createCase.clickCheckInDone();

        // #endregion

        // #region - Transfer charge to Primary Guarantor

        cy.cGroupAsStep('Transfer charge to Primary Guarantor');

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.transferCharge(
          td_waystar_billed_tcid_277150.Transfers.CptCode[0],
          td_waystar_billed_tcid_277150.Transfers.Period,
          td_waystar_billed_tcid_277150.Transfers.Batch,
          td_waystar_billed_tcid_277150.Transfers.NextResponsibleParty[0],
          td_waystar_billed_tcid_277150.Transfers.TransferTransactionCode[0]
        );
        sisOfficeDesktop.selectSisLogo();

        // #endregion

        // #region - Navigate to insurance billing tracker and print insurance charges

        cy.cGroupAsStep(
          'Navigate to insurance billing tracker and print insurance charges then verify waystar icon is not visible'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.INSURANCE_BILLING[0]
        );
        insuranceBilling.expandPlusIconBasedOnCarrier(
          td_waystar_billed_tcid_277150.InsuranceBilling.InsuranceCarrier
        );
        insuranceBilling.clickCheckboxInExpandedIcon(
          td_waystar_billed_tcid_277150.InsuranceBilling.PatientName
        );
        insuranceBilling.selectButtonsInInsuranceBilling(
          InsuranceBillingOptions.print_selected_payers
        );
        insuranceBilling.closePrintPreview();
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Navigate to Ledger and print insurance charges verify that waystar icon is not visible

        cy.cGroupAsStep(
          'Navigate to Ledger and print insurance charges verify that waystar icon is not visible'
        );

        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(0);
        ledgerTabFaceSheet.clickPrintSelectedInsuranceCharge();
        ledgerTabFaceSheet.verifyPrintPopup();
        ledgerTabFaceSheet.closePrintPopup();
        ledgerTabFaceSheet.closeBillingHistory();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Navigate to Ledger and Print Patient statement verify that waystar icon is not visible

        cy.cGroupAsStep(
          'Navigate to Ledger and Print Patient statement verify that waystar icon is not visible'
        );

        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.clickOnBillingHistory();
        ledgerTabFaceSheet.selectChargesCheckBox(0);
        ledgerTabFaceSheet.selectChargesCheckBox(1);
        ledgerTabFaceSheet.clickPrintSelectedPatientStatement();
        ledgerTabFaceSheet.verifyPrintPopup();
        ledgerTabFaceSheet.closePrintPopup();
        ledgerTabFaceSheet.closeBillingHistory();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Print insurance charges from RCM and verify that waystar icon is not visible

        cy.cGroupAsStep(
          'Print insurance charges from RCM and verify that waystar icon is not visible'
        );

        revenueCycleManagement.clickOnBillingHistory();
        revenueCycleManagement.selectChargesCheckBox(0);
        revenueCycleManagement.clickPrintSelectedInsuranceCharge();
        revenueCycleManagement.closePrintPopup();
        revenueCycleManagement.closeBillingHistory();
        revenueCycleManagement.verifyWaystarIcon(hiddenState);
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion

        // #region - Print patient statement from RCM and verify that waystar icon is not visible

        cy.cGroupAsStep(
          'Print patient statement from RCM and verify that waystar icon is not visible'
        );

        revenueCycleManagement.clickOnBillingHistory();
        revenueCycleManagement.selectChargesCheckBox(0);
        revenueCycleManagement.selectChargesCheckBox(1);
        revenueCycleManagement.clickPrintSelectedPatientStatement();
        revenueCycleManagement.closePrintPopup();
        revenueCycleManagement.closeBillingHistory();
        revenueCycleManagement.verifyWaystarIcon(hiddenState);
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();

        // #endregion

        // #region - Navigate to Patient Statements tracker and print patient statement verify that waystar icon is not displayed

        cy.cGroupAsStep(
          'Navigate to Patient Statements tracker and print patient statement verify that waystar icon is not displayed'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.PATIENT_STATEMENTS[0]
        );
        patientStatement.selectCheckboxByPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
            .PatientFirstName
        );
        patientStatement.selectButtonsInPatientStatement(
          OR_PATIENT_STATEMENT.PRINT_SELECTED_PATIENTS[0]
        );
        patientStatement.closePrintPopup();
        sisOfficeDesktop.pickPatient(
          td_waystar_billed_tcid_277150.PatientCase.PatientDetails
        );
        ledgerTabFaceSheet.clickOnLedgerTab();
        ledgerTabFaceSheet.verifyEmailSent(0, false);
        ledgerTabFaceSheet.verifyEmailSent(1, false);
        patientDetailsFacesheet.clickOnCasesTab();
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        transactions.verifyEmailSent(0, false);
        transactions.verifyEmailSent(1, false);
        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.REVENUE_CYCLE_MANAGEMENT[0]
        );
        revenueCycleManagement.selectTableRow(patient);
        revenueCycleManagement.verifyWaystarIcon(hiddenState);

        // #endregion
      });
    });
  }
}
