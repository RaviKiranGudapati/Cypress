import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../../test-data-models/core/user-info.model';

import { WaystarTcId277150 } from './scenarios/tcid-277150.sc';

/* instance variables */
const waystar = new WaystarTcId277150();

/*****************Test Script Validation Details **********************
 * Script Execution Approach -
 * This script uses seed data for patient creation
 * 1. Login to application
 * 2. Navigate to Transactions and change the responsible party to Guarantor
 * 3. Verify that waystar icon is not displayed in affected areas
 * 4. Print statement from Insurance billing and verify that waystar icon is not displayed in all affected areas
 * 5. Print the bill statement and verify that waystar icon is not displayed in all affected areas
 * */

describe(
  'Verify Waystar icon for insurance charges printed from Insurance billing, Face sheet, RCM, Patient Statements',
  {
    tags: [
      'insurance-billing',
      'rcm',
      'facesheet',
      'patient-statements',
      'TC#277150',
      'US#257723',
    ],
  },
  () => {
    before(`Launching Web Application`, function () {
      const userLogin: UserLogin = {
        UserName: UserList.SIS_ADMIN[0],
        Password: UserList.SIS_ADMIN[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_2, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => {
        waystar.enablingConditions();
        waystar.verifyWaystarIconPrint();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
