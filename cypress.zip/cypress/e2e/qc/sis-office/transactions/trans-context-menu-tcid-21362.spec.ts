/**Revision History
 * 30/07/22, Debasish, Spec to implement scenario - TCID - 21362, Verify Context Menu
 */

import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { TransactionContextMenuTcId21362 } from './scenarios/tcid-21362.sc';
import { UserLogin } from '../../../../test-data-models/core/user-info.model';

/* instance variables */
const transactionContextMenu = new TransactionContextMenuTcId21362();

//SHIFT + ALT + O - Organizing the import
/*****************Test Script Validation Details **********************
 * Script Execution Details -
 * Verifying transaction page child row context menu icon
 * Script Execution Approach -
 * 1. Create and discharge the patient.
 * 2. Perform cases to code and charge Entry
 * 3. Search patient in global search and navigate to facesheet.
 * 4. Go to  transaction page and select charge
 * 5. Perform Debit and Writeoff transaction
 * 6. click on debit row context menu and validate the options
 * 7. click on writeoff row context menu and validate the options
 * 8. Logout
 ************************************************************************/

describe(
  'Verify Business Facesheet Transactions - Context menu for child table entries on Transaction Page',
  { tags: ['transactions', 'context-menu', 'US#10220', 'TC#21362'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_1[0],
        Password: UserList.GEM_USER_1[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_1, userLogin);
    });

    //After all the it blocks, actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe('Precondition', () => {
      transactionContextMenu.preConditionSteps();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        transactionContextMenu.preVerificationActions();
        transactionContextMenu.verifyDebitAmountWriteOffAndContextMenu();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
