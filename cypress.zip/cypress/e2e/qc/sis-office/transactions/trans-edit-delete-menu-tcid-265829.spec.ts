import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import { UserLogin } from '../../../../test-data-models/core/user-info.model';

import { EditAndDeletePaymentTcId265829 } from './scenarios/tcid-265829.sc';

/*Test Script Validation Details *****
 * The spec file have dependency on seed data.
 * Script Execution Approach -
 * 1. Search and select the case in global search
 * 2. Navigate to transaction page and select the charge
 * 4. Perform the payments transaction and click on Done button.
 * 5. Click on the context menu and click on delete.
 * 6. Select the charge and perform the Debit and Write-Off transactions.
 * 7. Verify the delete option with clicking on yes or no button.
 * 8. Select another case perform operation like payment, write off, debit.
 * 9. Click on the correction for all the operation and verify delete option.
 * 9. Select another case perform payment, write off and debit with transfer to next no.
 * 10.Verify that user should be able to see the delete option.
 * 11.Click on the context menu of debit and verify the field.
 * 12.Verify Transfer to next button is disable.
 * 10. Perform the unassigned payment and allocate the amount.
 * 11. verify the allocated amount for the charge in ledger page.
 * 12.Correct the main charge and verify the delete option for payment.
 * 13. Add a new charge and Delete the existing charge and click on update button.
 * 15. Login with user without delete permission and verify the delete option for transaction.
 ************************************************************************/

/* instance variables */
const editAndDeletePayment = new EditAndDeletePaymentTcId265829();

describe(
  'Verify the Edit and Delete Functionality in Transaction for Payments Write Off Debits',
  { tags: ['transaction', 'US#276175', 'TC#265829'] },
  () => {
    before(`Launching Web Application`, function () {
      /**********Login To Application***********/
      const userLogin: UserLogin = {
        UserName: UserList.GEM_USER_21[0],
        Password: UserList.GEM_USER_21[1],
      };
      cy.cSetSession(OrganizationList.GEM_ORG_21, userLogin);
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      cy.cLogOut();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        editAndDeletePayment.verifyEditAndDeleteFunctionality();
        editAndDeletePayment.verifyDeleteOptionInTransactionContextMenu();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
