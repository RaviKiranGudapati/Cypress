/**Revision History
 * 30/07/22, Debasish, Spec to implement scenario - TCID - 21362, Verify Context Menu
 */

import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';

import { NursingDept } from '../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { FaceSheetOptions } from '../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import RecoveryDepartment from '../../../../../app-modules-libs/sis-charts/departments/recovery/recovery';
import ChartsCoverFaceSheet from '../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import CreateCase from '../../../../../app-modules-libs/sis-office/case-creation/create-case';
import FaceSheetCases from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import Transactions from '../../../../../app-modules-libs/sis-office/facesheet/facesheet-transactions';
import CasesToCode from '../../../../../app-modules-libs/sis-office/trackers/cases-to-code';
import ChargeEntry from '../../../../../app-modules-libs/sis-office/trackers/charge-entry';

import { td_trans_context_menu_tcid_21362 } from '../../../../../fixtures/sis-office/transactions/trans-context-menu-tcid-21362.td';

import { OR_TRANSACTION } from '../../../../../app-modules-libs/sis-office/facesheet/or/facesheet-transactions.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const createCase = new CreateCase(td_trans_context_menu_tcid_21362.PatientCase);
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const recoveryDepartment = new RecoveryDepartment(
  td_trans_context_menu_tcid_21362.RecoveryInfo
);
const casesToCode = new CasesToCode(createCase.patientCaseModel!);
const chargeEntry = new ChargeEntry(createCase.patientCaseModel!);
const faceSheetCases = new FaceSheetCases(createCase.patientCaseModel!);
const transactions = new Transactions(
  td_trans_context_menu_tcid_21362.PatientCase,
  td_trans_context_menu_tcid_21362.CaseTransaction
);

export class TransactionContextMenuTcId21362 {
  preConditionSteps() {
    describe('Add debit and writeoff transaction for patient with charges in Facesheet Transactions', () => {
      it('Select CPT code and add Debit Transaction ', () => {
        // #region - Create New Patient

        cy.cGroupAsStep('Creating New Patient');

        createCase.clickCreateACaseTab();
        createCase.createNewPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        createCase.createCase();
        // #endregion

        // #region - Discharge the New Patient

        cy.cGroupAsStep(
          'Navigating to Nursing Desktop and Discharging the Patient'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.recovery);
        recoveryDepartment.dischargePatientInOutsideFacility();
        // #endregion

        // #region - Performing Cases to Code and Performing Charge Entry

        cy.cGroupAsStep('Navigating to Business Desktop');

        sisOfficeDesktop.selectSisLogo();
        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        cy.cGroupAsStep(
          'Navigating to Business Desktop,Performing Cases to Code and Performing Charge Entry'
        );

        casesToCode.performCasesToCode(
          td_trans_context_menu_tcid_21362.CasesToCodeDetails
        );
        chargeEntry.performChargeEntry(
          td_trans_context_menu_tcid_21362.ChargeDetails
        );
        // #endregion

        // #region - Searching for the patient and Selecting Transactions from facesheet

        cy.cGroupAsStep(
          'Searching for the patient and Selecting Transactions from facesheet'
        );

        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          createCase.patientCaseModel!.PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.TRANSACTIONS);
        // #endregion
      });
    });
  }
  preVerificationActions() {
    describe('Add debit and writeoff transaction for charged patient in Transactions', () => {
      it('Select CPT code and add Debit Transaction ', () => {
        // #region - Select CPT code and click debit transaction icon

        cy.cGroupAsStep('Select CPT code and click debit transaction icon');

        transactions.selectCPTCode(
          td_trans_context_menu_tcid_21362.PatientCase.CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.DEBITS[0]
        );

        cy.cGroupAsStep('verify Adding Debit Transaction');

        transactions.debitPopupPostTransaction(
          td_trans_context_menu_tcid_21362.CaseTransaction.DebitInfo
        );
        // #endregion

        // #region - Select CPT Details and add Write Off Debit Amount

        cy.cGroupAsStep('Select CPT code and post write-off transaction');

        transactions.selectCPTCode(
          td_trans_context_menu_tcid_21362.PatientCase.CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        transactions.selectTransactionForCharge(
          OR_TRANSACTION.CHARGES.WRITE_OFFS[0]
        );
        transactions.writeoffPopupPostTransaction(
          td_trans_context_menu_tcid_21362.CaseTransaction.WriteOffInfo
        );
        transactions.selectCPTCode(
          td_trans_context_menu_tcid_21362.PatientCase.CaseDetails
            .CptCodeInfo[0].CPTCodeAndDescription
        );
        // #endregion
      });
    });
  }

  verifyDebitAmountWriteOffAndContextMenu() {
    describe('Verify Debit Amount, Write Off And the child context menu items', () => {
      it('Verify the Debit Amount, Write Off Amount and Child Context Menu Items in Business Facesheet Transactions', () => {
        // #region - Verify Debit Amount child transaction row

        cy.cGroupAsStep('Verify Debit Amount child transaction row');

        transactions.verifyDebitAmountWriteoffAmountContextMenuOptions(
          td_trans_context_menu_tcid_21362.CaseTransaction.DebitInfo
            .DebitAmount,
          td_trans_context_menu_tcid_21362.CaseTransaction.WriteOffInfo
            .WriteoffAmount
        );
        // #endregion
      });
    });
  }
}
