import { AppColors } from '../../../../../support/common-core-libs/application/constants/app-colors.constants';

import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { td_appointment_attachment_tcid_278108 } from '../../../../../fixtures/sis-office/case-requests/appointment-attachment-tcid-278108.td';

import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';

import { AppointmentRequestTabs } from '../../../../../app-modules-libs/sis-exchange/case-creation/enums/appointment-request.enum';

import Login from '../../../../../app-modules-libs/sis-exchange/login/login';
import PpeAppointmentRequest from '../../../../../app-modules-libs/sis-exchange/case-creation/appointment-request';
import Configuration, {
} from '../../../../../app-modules-libs/sis-exchange/configuration/configuration';

/* instance variables */
const appReq = new PpeAppointmentRequest();
const ppeConfig = new Configuration();

/* const values */
const fileName = 'appointment-attachment-tcid-278108.png';

export class AppointmentAttachmentTcId278108 {
  createAppointment() {
    it('Selecting time slot and creating appointment in sis-exchange', () => {
      // #region Creating an appointment after selecting scheduling desktop

      cy.cGroupAsStep(
        'Creating an appointment after selecting scheduling desktop'
      );
      ppeConfig.clickSchedulingDesktop(
        OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
      );
      selectTimeSlotAndCreateAppointment();
      // #endregion
    });
  }

  verifyBookedCaseStatus() {
    it('Verify "Booked" case status for approved cases and presence of attachments in sis-exchange ', () => {
      verifyCaseStatus();
      attachmentVerification();
    });
  }
}


function selectTimeSlotAndCreateAppointment() {
  // #region Creating an appointment

  cy.cGroupAsStep('Creating an appointment');
  appReq.selectTimeSlot(
    td_appointment_attachment_tcid_278108.AppointmentRequest.ProcedureDetails
      .RequestedStart,
    2
  );
  appReq.appointmentCreation(
    td_appointment_attachment_tcid_278108.AppointmentRequest
  );

  ppeConfig.logout();
  // #endregion
}

function verifyCaseStatus() {
  // #region Logging out and navigating to PPE environment to verify status of appointment

  cy.cGroupAsStep(
    'Logging out and navigating to PPE environment to verify status of appointment'
  );

  cy.visit(Cypress.env('ppeURL'));
  /**********Login To PPE Application***********/
  const ppeLogin = new Login();
  ppeLogin.login(
    UserList.GEM_USER_5[0],
    UserList.GEM_USER_5[1],
    OrganizationList.GEM_ORG_5
  );
  ppeConfig.clickSchedulingDesktop(
    OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
  );
  appReq.verifyCaseStatus(
    td_appointment_attachment_tcid_278108.AppointmentRequest.PatientDetails
      .LastName,
    AppColors.component_enabled_toggle_button_selected
  );
  // #endregion
}

function attachmentVerification() {
  // #region Selecting patient in surgery scheduling and verifying if attachment is present

  cy.cGroupAsStep(
    'Selecting patient in surgery scheduling and verifying if attachment is present'
  );
  appReq.selectPatientInSurgeryScheduling(
    td_appointment_attachment_tcid_278108.AppointmentRequest.PatientDetails
      .LastName
  );
  appReq.selectTabInAppointmentRequestPopup(AppointmentRequestTabs.attachment);
  appReq.verifyAttachment(fileName);
  appReq.closeAppointmentRequest();
  // #endregion
}
