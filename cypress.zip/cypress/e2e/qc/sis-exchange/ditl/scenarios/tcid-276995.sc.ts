import { AppColors } from '../../../../../support/common-core-libs/application/constants/app-colors.constants';
import { Application } from '../../../../../support/common-core-libs/application/common-core';

import { td_case_status_denied_tcid_276995 } from '../../../../../fixtures/sis-exchange/ditl/case-status-denied-tcid-276995.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';

import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';

import { HelperText } from '../../../../../app-modules-libs/shared/application-settings/enums/enterprise-configuration.enum';
import {
  InfoText,
  PanelOptions,
} from '../../../../../app-modules-libs/sis-exchange/case-creation/enums/appointment-request.enum';
import {
  schedulingTrackerOptions,
  checkboxLabels,
  appointmentRequestTabs,
  appointmentFields,
  procedureFields,
  caseStatus,
} from '../../../../../app-modules-libs/sis-exchange/case-creation/constants/appointment-request.const';

import Configuration from '../../../../../app-modules-libs/sis-exchange/configuration/configuration';
import SISExchangeLogin from '../../../../../app-modules-libs/sis-exchange/login/login';
import PpeAppointmentRequest from '../../../../../app-modules-libs/sis-exchange/case-creation/appointment-request';

/* instance variables */
const appReq = new PpeAppointmentRequest();
const ppeConfig = new Configuration();
const sisExchangeLogin = new SISExchangeLogin();

export class AppointmentCreationTcId276995 {
  ppeAppointmentCreation() {
    it('Verification of labels and appointment creation in SIS Exchange', () => {
      // #region - To verify scheduling desktop, appointment request popup and Creation of appointment with attachments.

      cy.cGroupAsStep(
        'To validate the default text, label details of surgery scheduling desktop and appointment request popup'
      );
      verifyLabelsInSurgeryScheduling();
      // #endregion

      // #region - To create the appointment in SIS Exchange application
      cy.cGroupAsStep(
        'To create the appointment with attachments through appointment request in SIS Exchange'
      );
      appReq.appointmentCreation(
        td_case_status_denied_tcid_276995.AppointmentRequest
      );
      ppeConfig.logout();
      // #endregion
    });
  }

  verifyDeniedCaseStatus() {
    it('Case status should be "Deny" for Denied Cases', () => {
      // #region - To check case status as denied

      cy.cGroupAsStep(
        'To verify the denied case status in surgery scheduling desktop'
      );

      cy.visit(Cypress.env('ppeURL'));
      sisExchangeLogin.login(
        UserList.GEM_USER_3[0],
        UserList.GEM_USER_3[1],
        OrganizationList.GEM_ORG_3
      );

      ppeConfig.clickSchedulingDesktop(
        OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
      );
      appReq.verifyCaseStatus(
        td_case_status_denied_tcid_276995.AppointmentRequest.PatientDetails
          .FirstName,
        AppColors.component_case_denied_status
      );
      // #endregion
    });
  }

  verifyUpdatedDeniedCase() {
    it('Update denied case and check appointment history for the case status', () => {
      // #region - To check the denied cases in the appointment history

      cy.cGroupAsStep('To verify the denied case in appointment history page');
      verifyAppointmentCaseStatus();
      // #endregion
    });
  }
}

/**
 * To verify the labels in surgery scheduling page.
 */
function verifyLabelsInSurgeryScheduling() {
  ppeConfig.clickSchedulingDesktop(
    OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
  );
  appReq.verifySchedulingTracker(schedulingTrackerOptions);
  appReq.verifyPrintIconInScheduling();
  appReq.verifyCaseStatusCheckbox(checkboxLabels);
  appReq.verifyShowAllText(InfoText.show_all);

  cy.cRemoveMaskWrapper(Application.office);
  appReq.selectTimeSlot(
    td_case_status_denied_tcid_276995.AppointmentRequest.ProcedureDetails
      .RequestedStart,
    2
  );
  appReq.verifyAppointmentRequestTabs(appointmentRequestTabs);

  appReq.verifyAppointmentSectionFields(appointmentFields);
  appReq.verifyProcedureSectionFields(procedureFields);
  appReq.verifyCopyRightText(HelperText.disclaimer_text_ppe_cpt);
}

/**
 * To verify the appointment case status in appointment history page.
 */
function verifyAppointmentCaseStatus() {
  appReq.verifyAppointmentHistoryCaseStatus(
    PanelOptions.appointment_history,
    td_case_status_denied_tcid_276995.AppointmentRequest.PatientDetails,
    caseStatus[3]
  );
  appReq.editDeniedCase(
    td_case_status_denied_tcid_276995.AppointmentRequest.PatientDetails,
    td_case_status_denied_tcid_276995.Procedures
  );
  appReq.verifyAppointmentHistoryCaseStatus(
    PanelOptions.appointment_history,
    td_case_status_denied_tcid_276995.AppointmentRequest.PatientDetails,
    caseStatus[1]
  );
}
