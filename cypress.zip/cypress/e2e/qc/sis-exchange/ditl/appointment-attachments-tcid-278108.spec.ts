import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import Login from '../../../../app-modules-libs/sis-exchange/login/login';

import { AcceptCaseTcId278108 } from '../../sis-office/case-requests/scenarios/tcid-278108.sc';
import { AppointmentAttachmentTcId278108 } from './scenarios/tcid-278108.sc';

import Configuration from '../../../../app-modules-libs/sis-exchange/configuration/configuration';

/* instance variables */
const appointmentAttach = new AppointmentAttachmentTcId278108();
const acceptAppointment = new AcceptCaseTcId278108();
const ppeConfig = new Configuration();

/*****************Test Script Validation Details **********************
 * * Verify Transaction code option at Enterprise build and under 'Configurations' at Enterprise settings >Facility Management tab
 * *Script Execution Approach -
 * Login to ppe environment.
 * Check the pre-conditions
 * Navigate to scheduling desktop
 * Verify the fields and checkboxes present there
 * Enter procedure and patient details in appointment request screen.
 * Check the attachment screen and add attachment.
 * Click next and appointment should be created with attachment.
 * Navigate to business desktop and accept case along with verifying fields.
 * Navigate to sis-exchange and check case status as booked from background color
 */

describe(
  'Verification of Case status as "Booked" for created SIS Exchange Cases',
  {
    tags: ['ppe', 'ditl', 'US#277597', 'TC#278108'],
  },
  () => {
    before(`Launching Web Application`, function () {
      Cypress.on('uncaught:exception', (error, runnable) => {
        return false;
      });
      /****Open the URL as defined in baseUrl in Cypress Configuration File Or CLI flag - --config baseUrl ********/
      cy.visit(Cypress.env('ppeURL'));
      /**********Login To PPE Application***********/
      const ppeLogin = new Login();
      ppeLogin.login(
        UserList.GEM_USER_5[0],
        UserList.GEM_USER_5[1],
        OrganizationList.GEM_ORG_5
      );
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      ppeConfig.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        appointmentAttach.createAppointment();
        acceptAppointment.acceptAppointmentRequest();
        appointmentAttach.verifyBookedCaseStatus();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
