import { td_case_equip_tcid_260005 } from '../../../../../fixtures/sis-office/case/create/case-equipment-tcid-260005.td';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import PpeAppointmentRequest from '../../../../../app-modules-libs/sis-exchange/case-creation/appointment-request';
import Configuration from '../../../../../app-modules-libs/sis-exchange/configuration/configuration';
import { Application } from '../../../../../support/common-core-libs/application/common-core';

/* instance variables */
const appReq = new PpeAppointmentRequest();
const ppeConfig = new Configuration();

export class PpeCaseEquipmentTcId260005 {
  createCaseFromSisExchange() {
    describe('Creating Case in SIS Exchange', () => {
      it('Creating Case in SIS Exchange to display in case requests in schedule grid', () => {
        cy.cGroupAsStep('select Scheduling Desktop in SIS Exchange');
        ppeConfig.clickSchedulingDesktop(
          OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
        );
        cy.cGroupAsStep('Select Time slot and enter appointment details');
        cy.cRemoveMaskWrapper(Application.office);
        appReq.selectTimeSlot(
          td_case_equip_tcid_260005.PatientCase.CaseDetails.StartTime,
          2
        );
        appReq.enterProcedureDetails(td_case_equip_tcid_260005.ProcedureDetails.Procedures);
        appReq.clickNextButtonInProcedureDetails(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.FOOTER_BUTTONS
            .NEXT_BUTTON[0]
        );

        cy.cGroupAsStep(
          'Enter patient details in appointment request and click Done'
        );
        appReq.enterPatientDetails(
          td_case_equip_tcid_260005.PatientDetails
        );
        appReq.clickDoneButton(OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.DONE_BUTTON[0]);

        cy.cGroupAsStep('Logout from SIS Exchange');
        ppeConfig.logout();
      });
    });
  }
}
