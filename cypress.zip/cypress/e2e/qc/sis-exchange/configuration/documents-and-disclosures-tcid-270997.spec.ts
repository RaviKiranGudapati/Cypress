import { UserList } from '../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';

import Login from '../../../../app-modules-libs/sis-exchange/login/login';
import Configuration from '../../../../app-modules-libs/sis-exchange/configuration/configuration';

import { DocumentsAndDisclosuresTcId270997 } from './scenarios/tcid-270997.sc';

/* instance variables */
const documentsAndDisclosures = new DocumentsAndDisclosuresTcId270997();
const sisExchangeConfiguration = new Configuration();
const ppeLogin = new Login();

/*****************Test Script Validation Details **********************
 * Before Execution make sure PPEBlogStorage sql query is ran in-order to attach the documents
 * 
 * Script Execution Approach -
 * 1. Login to PPE application
 * 2. Navigate to SIS-Link settings and validate the documents and disclosures field.
 * 3. Adding multiple documents and verifying the preview file and deleting the files.
 * 4. Navigate to pre-admission instructions, and verify added documents are visible and mapped to widget.
 * */

describe(
  'Verify documents and disclosures in SIS-Link settings',
  {
    tags: ['documents-and-disclosures', 'TC#270997', 'US#56426'],
  },
  () => {
    before(`Launching Web Application`, function () {
      cy.visit(Cypress.env('ppeURL'));
      ppeLogin.login(
        UserList.GEM_USER_3[0],
        UserList.GEM_USER_3[1],
        OrganizationList.GEM_ORG_3
      );
    });

    // After Each test (it), actions to be performed
    after('Logout', () => {
      sisExchangeConfiguration.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => {
        documentsAndDisclosures.addDocuments();
      }
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },

      () => undefined
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
