import { OrganizationList } from '../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../fixtures/shared/user-list.td';

import Configuration from '../../../../app-modules-libs/sis-exchange/configuration/configuration';

import { SisExchangeUserAccountTcId265136 } from './scenarios/tcid-265136.sc';
import SISCompleteLogin from '../../../../app-modules-libs/sis-office/login/login';

/* instance variables */
const configuration = new Configuration();
const sisExchangeUserAccount = new SisExchangeUserAccountTcId265136();

/* Test Script Validation Details *****
 * Script Execution Approach -
 * 1. Login into application and navigate to SIS Enterprise Configuration page.
 * 2. Navigating to sis complete and enabling the MFA and setting allow Bypassing as NO
 * 3. Login into SIS Exchange application and added the new users, verify the email
 * 4. verifying the invalid email, duplicate and existing email validation.
 * 5. Verifying the change password for the user settings
 */

describe(
  'Verifying the Email is mandatory field for new users and Checking Invalid and Duplicate error message for email',
  {
    tags: ['configuration', 'US#255971', 'TC#265136'],
  },
  () => {
    // Before suite
    before(`Launching Web Application`, function () {
      /* Updating to general login since 3 specs needs to be run in sequential */
      cy.visit('/');
      const login = new SISCompleteLogin();
      login.login(
        UserList.SIS_ADMIN[0],
        UserList.SIS_ADMIN[1],
        OrganizationList.GEM_ORG_3
      );
    });

    // After suite (it), actions to be performed
    after('Logout', () => {
      configuration.logout();
    });

    describe(
      'UI',
      {
        tags: ['UI'],
      },
      () => undefined
    );

    describe(
      'Functional',
      {
        tags: ['FUNC'],
      },
      () => {
        sisExchangeUserAccount.verifyUsersMFA();
      }
    );

    describe(
      'Dev Support',
      {
        tags: ['DS'],
      },
      () => undefined
    );
  }
);
