import NursingConfigurationLayout from '../../../../../support/common-core-libs/application/application-settings';
import SISChartsDesktop from '../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../support/common-core-libs/application/sis-office-desktop';
import {
  EnableOrDisable,
  YesOrNo,
} from '../../../../../support/common-core-libs/application/common-core';

import { AppErrorMessages } from '../../../../../support/common-core-libs/application/constants/app-errors.constants';

import { td_user_configuration_mfa_tcid_265136 } from '../../../../../fixtures/sis-exchange/configuration/user-configuration-mfa-tcid-265136.td';
import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';

import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_ENTERPRISE_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/enterprise-configuration.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_SIS_CHARTS_DESKTOP } from '../../../../../support/common-core-libs/application/or/sis-charts-desktop.or';
import { OR_NURSING_CONFIGURATION } from '../../../../../app-modules-libs/shared/application-settings/or/nursing-configuration.or';
import { OR_LOGIN } from '../../../../../app-modules-libs/sis-office/login/or/login.or';

import EnterpriseConfiguration from '../../../../../app-modules-libs/shared/application-settings/enterprise-configuration';
import SISExchangeLogin from '../../../../../app-modules-libs/sis-exchange/login/login';
import Configuration from '../../../../../app-modules-libs/sis-exchange/configuration/configuration';
import SISExchangeUsers from '../../../../../app-modules-libs/sis-exchange/configuration/users';

/* instance variables */
const sisExchangeLogin = new SISExchangeLogin();
const sisExchangeConfiguration = new Configuration();
const sisExchangeUsers = new SISExchangeUsers();
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const enterpriseConfig = new EnterpriseConfiguration();

export class SisExchangeUserAccountTcId265136 {
  verifyUsersMFA() {
    describe('To verify Enterprise settings changes PPE User Account', () => {
      it('Navigating and enabling the MFA button and bypass button in sis complete and verifying email validation in PPE and change password disabled', () => {
        // #region Navigating to the sis complete and enabling the MFA button

        cy.cGroupAsStep(
          'Navigating to the application setting and clicking on Add on features and enabling the MFASSO button'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_NURSING_CONFIGURATION.ADD_ON_FEATURE.ADD_ON_FEATURE_HEADER[0]
        );
        nursingConfigurationLayout.clickUnreleased();
        nursingConfigurationLayout.clickMFASSObutton();
        // #endregion

        // #region - Navigating to the enterprise and enabling the MFA button

        cy.cGroupAsStep(
          'Navigating to the enterprise and enabling the MFA button'
        );
        sisChartsDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_CHARTS_DESKTOP.MY_SETTINGS.CHANGE_LOGIN_LOCATION[0]
        );
        enterpriseConfig.selectEnterpriseInPopup(
          OR_LOGIN.LOGIN_LOCATION.LOGIN_LOCATION_WINDOW[0],
          OrganizationList.ENTERPRISE
        );
        enterpriseConfig.enterpriseSelectConfiguration(
          OR_ENTERPRISE_CONFIGURATION.SECURITY.SECURITY_SECTION[0]
        );
        enterpriseConfig.clickMFAAndBypassingMFAbutton(EnableOrDisable.enable, true, true);
        enterpriseConfig.clickMFAAndBypassingMFAbutton(YesOrNo.no, true, false);
        sisOfficeDesktop.logout();
        // #endregion

        // #region - Opening the PPE URL and login into PPE

        cy.cGroupAsStep('Opening the PPE URL and login into PPE');
        cy.visit(Cypress.env('ppeURL'));
        /**********Login To Application***********/
        sisExchangeLogin.login(
          UserList.GEM_USER_3[0],
          UserList.GEM_USER_3[1],
          OrganizationList.GEM_ORG_3
        );
        // #endregion

        // #region - Click on the Add button in the users page and verifying the labels

        cy.cGroupAsStep(
          'Click on the Add button in the users page and verifying the labels'
        );
        sisExchangeUsers.selectSettingInConfiguration(
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.USERS[0]
        );
        sisExchangeUsers.clickAddUser();
        sisExchangeUsers.verifyEmailLabel();
        sisExchangeUsers.verifyPasswordLabel();
        sisExchangeUsers.verifyConfirmPasswordLabel();
        sisExchangeUsers.verifyCancelButton();
        sisExchangeUsers.verifyDoneButton(false);

        // #endregion

        // #region - Enter invalid email id format and verify the error message

        cy.cGroupAsStep(
          'Enter invalid email id format and verify the error message'
        );
        sisExchangeUsers.createUser(
          td_user_configuration_mfa_tcid_265136.UserDetails[0]
        );
        sisExchangeUsers.enterEmail(
          td_user_configuration_mfa_tcid_265136.UserDetails[0]
        );
        sisExchangeUsers.verifyEmailText(AppErrorMessages.invalid_email);
        // #endregion

        // #region - Enter Existing email id format and verify the error message

        cy.cGroupAsStep(
          'Enter Existing email id format and verify the error message'
        );
        sisExchangeUsers.enterEmail(
          td_user_configuration_mfa_tcid_265136.UserDetails[1]
        );
        sisExchangeUsers.verifyEmailText(AppErrorMessages.existing_email);
        sisExchangeUsers.verifyDoneButton(false);
        // #endregion

        // #region - Enter new email id format and click on the done button

        cy.cGroupAsStep(
          'Enter new email id format and click on the done button'
        );
        sisExchangeUsers.enterEmail(
          td_user_configuration_mfa_tcid_265136.UserDetails[2]
        );
        sisExchangeUsers.enterUserName(
          td_user_configuration_mfa_tcid_265136.UserDetails[0]
        );
        sisExchangeUsers.clickDoneInAddUser();
        // #endregion

        // #region - Verify new email id and after click on the done button

        cy.cGroupAsStep(
          'Verify new email id and after click on the done button'
        );
        sisExchangeUsers.verifyEnteredEmail(
          td_user_configuration_mfa_tcid_265136.UserDetails[2].EMail
        );
        // #endregion

        // #region - Verify new email id and after Navigating to the other task

        cy.cGroupAsStep(
          'Verify new email id and after Navigating to the other task'
        );
        sisExchangeUsers.selectSettingInConfiguration(
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.MANDATORY_FIELDS[0]
        );
        sisExchangeUsers.selectSettingInConfiguration(
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.USERS[0]
        );
        sisExchangeUsers.searchAndSelectUser(
          td_user_configuration_mfa_tcid_265136.UserDetails[0]
        );
        sisExchangeUsers.verifyEnteredEmail(
          td_user_configuration_mfa_tcid_265136.UserDetails[2].EMail
        );
        // #endregion

        // #region - Select the user settings option from user menu dropdown

        cy.cGroupAsStep(
          'Select the user settings option from user menu dropdown'
        );
        sisExchangeConfiguration.selectOptionInUserMenuDropdown(
          OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.USER_SETTINGS[0]
        );
        sisExchangeConfiguration.verifyChangePassword();
        sisExchangeConfiguration.clickDone();
        // #endregion
      });
    });
  }
}
