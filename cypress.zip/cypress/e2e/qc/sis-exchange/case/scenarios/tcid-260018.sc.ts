import { OrganizationList } from '../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../fixtures/shared/user-list.td';
import { td_case_cdtcode_tcid_260018 } from '../../../../../fixtures/sis-office/case/create/case-cdtcode-tcid-260018.td';
import { OR_EXCHANGE_CONFIGURATION } from '../../../../../app-modules-libs/sis-exchange/configuration/or/configuration.or';
import { OR_PATIENT_CASE_CREATION } from '../../../../../app-modules-libs/sis-office/case-creation/or/create-case.or';
import PpeAppointmentRequest from '../../../../../app-modules-libs/sis-exchange/case-creation/appointment-request';
import SISExchangeLogin from '../../../../../app-modules-libs/sis-exchange/login/login';
import Configuration from '../../../../../app-modules-libs/sis-exchange/configuration/configuration';
import SISExchangeUsers from '../../../../../app-modules-libs/sis-exchange/configuration/users';

/* instance variables */
const sisExchangeAppointmentRequest = new PpeAppointmentRequest();
const sisExchangeLogin = new SISExchangeLogin();
const sisExchangeConfiguration = new Configuration();
const sisExchangeUsers = new SISExchangeUsers();

export class SisExchangeCDTCodeTcId260018 {
  verifyCDTCodeNoSearchResultsInProcedureDetails() {
    describe('To verify CDT search results not displayed as CDT Feature disable mode in SIS Exchange', () => {
      it('Verify the CDT search results is not displayed in Procedure Details tab in Appointment Request popup', () => {
        // #region verify the no search results while enter the cdt code in procedure field as CDT feature in disable mode.

        cy.cGroupAsStep(
          'As CDT feature in disable mode, Verifying the CDT codes not displayed while enter the CDT Code in Procedure Details page in Appointment Request popup'
        );
        /** Launch the SIS Exchange application  */
        cy.visit(Cypress.env('ppeURL'));

        /** Login into application with valid credentials */
        sisExchangeLogin.login(
          UserList.GEM_USER_3[0],
          UserList.GEM_USER_3[1],
          OrganizationList.GEM_ORG_3
        );

        /** Click on Scheduling Desktop in user menu dropdown */
        sisExchangeConfiguration.selectOptionInUserMenuDropdown(
          OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
        );

        /**To check the room name to visible in scheduling desktop page*/
        sisExchangeAppointmentRequest.verifyRoomInSchedulingDesktop(
          td_case_cdtcode_tcid_260018.PatientCase.CaseDetails.OperatingRoom
        );

        /**click on time slot in scheduling desktop page and it open appointment request popup */
        sisExchangeAppointmentRequest.selectTimeSlot(
          td_case_cdtcode_tcid_260018.PatientCase.CaseDetails.StartTime,
          2
        );

        /** Verify the no search results text when enter the CDT code in procedure field */
        sisExchangeAppointmentRequest.verifyCDTCodeInProcedureDetails(
          td_case_cdtcode_tcid_260018.Procedure
        );

        sisExchangeAppointmentRequest.closeAppointmentRequest();
        /**Logout from SIS Exchange application */
        sisExchangeConfiguration.logout();
        // #endregion
      });
    });
  }

  verifyCDTCodeSearchResultsInProcedureDetails() {
    describe('To verify the CDT search results as CDT feature in Enable mode in SIS Exchange', () => {
      it('Verify the CDT search results in Procedure Details tab in Appointment Request popup ', () => {
        // #region verify the search result while enter the cdt code in procedure field as CDT feature in enable mode.

        cy.cGroupAsStep(
          'As CDT feature in enable mode,Verifying the CDT search results while enter the CDT Code in Procedure Details page in Appointment Request popup'
        );
        /**Launch the SIS Exchange URL */
        cy.visit(Cypress.env('ppeURL'));

        /**Login into SIS Exchange application with valid credentials */
        sisExchangeLogin.login(
          UserList.GEM_USER_7[0],
          UserList.GEM_USER_7[1],
          OrganizationList.GEM_ORG_7
        );

        /** Select the values from Configuration*/
        sisExchangeUsers.selectSettingInConfiguration(
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.USERS[0]
        );

        /** Select the user name and map the physician values*/
        sisExchangeUsers.selectPhysicianInMappedPhysician(
          UserList.GEM_USER_7[0],
          OR_EXCHANGE_CONFIGURATION.SIS_LINK_SETTINGS.MANDATORY_FIELDS[0]
        );

        /**Select the scheduling desktop option from user menu dropdown */
        sisExchangeConfiguration.selectOptionInUserMenuDropdown(
          OR_EXCHANGE_CONFIGURATION.USER_MENU_DROPDOWN.SCHEDULING_DESKTOP[0]
        );

        /**To wait for display all the rooms in scheduling desktop */
        sisExchangeAppointmentRequest.verifyRoomInSchedulingDesktop(
          td_case_cdtcode_tcid_260018.CaseDetails.OperatingRoom
        );

        /**select the time slot from scheduling desktop */
        sisExchangeAppointmentRequest.selectTimeSlot(
          td_case_cdtcode_tcid_260018.PatientCase.CaseDetails.StartTime,
          2
        );

        /** To verify the CDT Code search results and copy right text in Procedure Details tab */
        sisExchangeAppointmentRequest.clickNextButtonInProcedureDetails(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.FOOTER_BUTTONS
            .NEXT_BUTTON[0]
        );

        sisExchangeAppointmentRequest.clickFooterButtons(
          OR_PATIENT_CASE_CREATION.CREATE_A_CASE.MY_TASKS.FOOTER_BUTTONS
            .PREVIOUS_BUTTON[0]
        );

        sisExchangeAppointmentRequest.verifyCopyRightText(
          td_case_cdtcode_tcid_260018.PatientCase.CaseDetails.CopyRight
        );

        sisExchangeAppointmentRequest.verifyCopyRightText(
          td_case_cdtcode_tcid_260018.CaseDetails.CopyRight
        );

        sisExchangeAppointmentRequest.verifyCDTCodeInProcedureDetails(
          td_case_cdtcode_tcid_260018.Procedure
        );
        sisExchangeAppointmentRequest.closeAppointmentRequestDuringCreation();
        // #endregion
      });
    });
  }
}
