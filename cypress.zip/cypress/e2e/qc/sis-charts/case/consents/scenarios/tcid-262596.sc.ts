import { td_consents_physicians_tcid_262596 } from '../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-physicians-tcid-262596.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { OR_REPORTS } from '../../../../../../app-modules-libs/shared/reports/or/reports.or';
import { OR_SIS_CHARTS_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-charts-desktop.or';
import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import Reports from '../../../../../../app-modules-libs/shared/reports/reports';
import ConsentsTask from '../../../../../../app-modules-libs/sis-charts/departments/consents/consents';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import SISPhysicianDesktop from '../../../../../../app-modules-libs/sis-charts/physician/physician-desktop';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';
import { SisOfficeScdlGridPrintTcId49238 } from '../../../../sis-office/case/print/scenarios/tcid-49238.sc';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';
import { MyTaskFaceSheet } from '../../../../../../app-modules-libs/sis-charts/facesheet/mytask-facesheet';
import { NursingDept, MyTasks } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const consentsTask = new ConsentsTask();
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const reports = new Reports();
const sisPhysicianDesktop = new SISPhysicianDesktop();
const sisOfficeScdlGridPrint = new SisOfficeScdlGridPrintTcId49238();
const myTaskFaceSheet = new MyTaskFaceSheet();

/* const values */
const patient =
  td_consents_physicians_tcid_262596.PatientCase.PatientDetails.LastName +
  `, ` +
  td_consents_physicians_tcid_262596.PatientCase.PatientDetails
    .PatientFirstName;

export class NursingConsentsTcId262596 {
  updateConsentsPerformingPhysician() {
    describe('Verifying the Performing Physicians saving in Patient Case Consents in Nursing Desktop', () => {
      it('Verify the adding of Performing Physicians by editing consent in Nursing Consents & Incomplete Physician Tracker', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep('Select the Patient Case and Navigate to Consents');

        sisOfficeScdlGridPrint.selectNursingDesktop();
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        // #endregion

        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep('Open Consent and add multiple performing physicians');
        consentsTask.selectCaseConsent(
          td_consents_physicians_tcid_262596.Consents[1].ConsentName
        );
        consentsTask.selectPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[1]
        );
        consentsTask.saveConsents();
        cy.reload();
        consentsTask.selectCaseConsent(
          td_consents_physicians_tcid_262596.Consents[1].ConsentName
        );
        consentsTask.verifyPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[2]
        );
        consentsTask.saveConsents();
        myTaskFaceSheet.selectDepartmentInMytask(MyTasks.pre_op);
        chartsCoverFaceSheet.addTimePreOperativeNow();
        sisOfficeDesktop.selectSisLogo();
        // #endregion

        sisChartsDesktop.selectTracker(
          OR_SIS_CHARTS_DESKTOP.TRACKERS.INCOMPLETE_PHYSICIAN_ITEMS[0]
        );
        sisChartsDesktop.selectIncompleteTrackerPhysicians(
          td_consents_physicians_tcid_262596.Consents[2].PerformingPhysician!
        );
        sisChartsDesktop.selectIncompleteTrackerPatientConsents(patient);
        consentsTask.selectCaseConsent(
          td_consents_physicians_tcid_262596.Consents[2].ConsentName
        );
        consentsTask.verifyPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[2]
        );
        consentsTask.saveConsents();
        sisOfficeDesktop.selectSisLogo();
      });
    });
  }

  verifyPhysicianUpdatedInAnesthesia() {
    describe('Verifying the Performing Physicians updated in Anesthesia Desktop is displayed in Nursing Desktop', () => {
      it('Verify the Performing Physicians updated in Anesthesia Desktop is pulled in Nursing Desktop', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep(
          'Check-in the Patient Case and Navigate to Forms and Consents'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        // #endregion

        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep('Open Consent and add multiple performing physicians');

        consentsTask.selectCaseConsent(
          td_consents_physicians_tcid_262596.Consents[2].ConsentName
        );
        consentsTask.verifyPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[1]
        );
        consentsTask.saveConsents();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  verifyAuditTrailReport() {
    describe('Verifying the Audit Trail Report for Signing Consents', () => {
      it('Verify the Audit Trail Report for Signing Consents in Patient case by giving proper filters', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep(
          'Navigate to Audit Trail and verify Anesthesia details are logged'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.REPORTS[0]
        );
        reports.selectReportConfiguration(OR_REPORTS.REPORTS.AUDIT_TRAIL[0]);
        sisOfficeDesktop.waitTillSpinnerLoads();
        reports.selectAreaValues(
          OR_REPORTS.AUDIT_TRAIL.AREA_ANESTHESIA_DROPDOWNVAL[1]
        );
        reports.clickViewReport();
        reports.verifyValueInReports(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails
            .PatientFirstName
        );
        reports.verifyValueInReports(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails.LastName
        );
        reports.verifyValueInReports(
          td_consents_physicians_tcid_262596.Consents[1].ConsentName
        );
        reports.verifyValueInReports(
          OR_REPORTS.AUDIT_TRAIL.AREA_ANESTHESIA_DROPDOWNVAL[0]
        );

        // #endregion
      });
    });
  }

  verifyConsentDisplayedInPhysicianDesktop() {
    describe('Verifying the Patient Case Consents in Physician Desktop', () => {
      it('Verify the Case Consents in displayed in Physician Desktop for the physician assigned to the patient case', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep(
          'Logging into Physician Desktop with gem_user11 and verify consent'
        );
        cy.cLogOut();
        cy.reload();
        /**********Login To Application***********/
        const login = new SISCompleteLogin();
        login.login(
          UserList.GEM_USER_11[0],
          UserList.GEM_USER_11[1],
          OrganizationList.GEM_ORG_6
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        sisPhysicianDesktop.clickConsentsTask();
        sisPhysicianDesktop.verifyConsentsName(
          td_consents_physicians_tcid_262596.Consents[1].ConsentName
        );
        sisChartsDesktop.selectSisLogo();
        sisPhysicianDesktop.logout();
        // #endregion
      });
    });
  }
}
