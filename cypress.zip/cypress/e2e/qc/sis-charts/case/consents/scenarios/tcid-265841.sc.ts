import { Application } from '../../../../../../support/common-core-libs/application/common-core';
import NursingConfigurationLayout from '../../../../../../support/common-core-libs/application/application-settings';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISOfficeDesktop from '../../../../../../support/common-core-libs/application/sis-office-desktop';

import { td_consents_primary_proc_sc265841 } from '../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-primary-proc-tcid-265841.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';

import { UserLogin } from '../../../../../../test-data-models/core/user-info.model';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../../../support/common-core-libs/application/or/sis-office-desktop.or';
import { OR_CHARTS_COVER_FACE_SHEET } from '../../../../../../app-modules-libs/sis-charts/facesheet/or/charts-cover-facesheet.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';
import { FaceSheetOptions } from '../../../../../../app-modules-libs/sis-office/facesheet/enums/facesheet-cases.enum';

import ConsentsTask from '../../../../../../app-modules-libs/sis-charts/departments/consents/consents';
import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import CreateCase from '../../../../../../app-modules-libs/sis-office/case-creation/create-case';
import NursingConfiguration from '../../../../../../app-modules-libs/shared/application-settings/nursing-configuration';
import OperativeWorkList from '../../../../../../app-modules-libs/sis-charts/departments/operative/worklist';
import FaceSheetCases from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-cases';
import { CasesDetailsFaceSheet } from '../../../../../../app-modules-libs/sis-office/facesheet/facesheet-case-details';

/*instance variables*/
const sisOfficeDesktop = new SISOfficeDesktop();
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const nursingConfigurationLayout = new NursingConfigurationLayout();
const nursingConfig = new NursingConfiguration();
const consentsTask = new ConsentsTask();
const operativeWorkList = new OperativeWorkList();
const createCase = new CreateCase();
const faceSheetCases = new FaceSheetCases();
const casesDetailsFaceSheet = new CasesDetailsFaceSheet();

export class NursingConsentsTcId265841 {
  verifyModifiedPrimaryProcedure() {
    describe('To verify the modified procedure description of primary procedure under procedure section within consents popup in nursing desktop', () => {
      it('Verify modified procedure description of primary procedure under procedure text area in consents popup', () => {
        // #region To enable the primary procedure and verify the primary procedure details in consents popup
        cy.cGroupAsStep(
          'To enable the primary procedure only toggle in consents configuration'
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );
        sisOfficeDesktop.selectTracker(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.TRACKERS.CHARGE_ENTRY[0]
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.CONSENTS[0]
        );
        cy.cRemoveMaskWrapper(Application.office);
        nursingConfig.selectPrimaryProcedureOnly();
        nursingConfig.selectProcedureDisplay(
          td_consents_primary_proc_sc265841.ConsentsModel[0]
            .ProcedureDisplay![2]
        );
        cy.cGroupAsStep(
          'Verify the primary procedure data with modified procedure description in consents popup'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );
        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_primary_proc_sc265841.PatientCase[0].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        consentsTask.selectCaseConsent(
          td_consents_primary_proc_sc265841.ConsentsModel[0].ConsentName
        );
        consentsTask.verifyProcedure(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![0]
        );
        consentsTask.clickProcedureReloadButton();
        consentsTask.clickConsentsCrossIcon();

        // #endregion
      });
    });
  }

  verifyCPTPrimaryProcDesc() {
    describe('To verify CPT procedure data and pull procedure icon in consents popup in nursing desktop', () => {
      it('Verify CPT procedure data displayed in consents popup in nursing desktop based on the consents configuration', () => {
        // #region verify the all procedure data in consents popup

        cy.cGroupAsStep(
          'To select the cpt and description option from procedure display dropdown in consents configuration'
        );

        /**********Login To Application***********/
        const userLogin: UserLogin = {
          UserName: UserList.GEM_USER_22[0],
          Password: UserList.GEM_USER_22[1],
        };
        cy.cSetSession(OrganizationList.GEM_ORG_22, userLogin);
        // Removed unneccessary Navigation

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );
        nursingConfigurationLayout.selectConfiguration(
          OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.CONSENTS[0]
        );
        cy.cRemoveMaskWrapper(Application.office);

        nursingConfig.selectProcedureDisplay(
          td_consents_primary_proc_sc265841.ConsentsModel[0]
            .ProcedureDisplay![0]
        );

        cy.cGroupAsStep('Verify pull procedure icon in consents popup');

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_primary_proc_sc265841.PatientCase[0].PatientDetails
        );

        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        consentsTask.selectCaseConsent(
          td_consents_primary_proc_sc265841.ConsentsModel[0].ConsentName
        );
        consentsTask.clickProcedureReloadButton();
        consentsTask.verifyProcedure(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![1]
        );
        consentsTask.clickConsentsCrossIcon();

        // #endregion
      });
    });
  }

  verifyConsentsModifiedPrimaryProcedure() {
    describe('To verify the modified procedure data in consents popup in nursing desktop', () => {
      it('Verify modified procedure data displayed in consents popup ,facesheet and on case header', () => {
        // #region verify the modified procedure data in consents popup facesheet and on case header based on configuration

        cy.cGroupAsStep(
          'To select the modified procedure and description option from procedure display dropdown in consents configuration'
        );
        /*** Step6 */

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.selectScheduleType(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.NAVIGATION.SCHEDULE_TYPE
            .SCHEDULE_GRID[0]
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS.APPLICATION_SETTINGS[0]
        );

        nursingConfigurationLayout.selectConfiguration(
          OR_CHARTS_COVER_FACE_SHEET.DEPARTMENTS.CONSENTS[0]
        );
        cy.cRemoveMaskWrapper(Application.office);

        nursingConfig.selectProcedureDisplay(
          td_consents_primary_proc_sc265841.ConsentsModel[0]
            .ProcedureDisplay![1]
        );

        cy.cGroupAsStep(
          'Verify the pull scheduled procedures are displaying and sign the consent'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_primary_proc_sc265841.PatientCase[0].PatientDetails
        );

        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        consentsTask.selectCaseConsent(
          td_consents_primary_proc_sc265841.ConsentsModel[0].ConsentName
        );
        consentsTask.clickProcedureReloadButton();
        consentsTask.verifyProcedure(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![0]
        );

        consentsTask.clickPhysicianSign();
        consentsTask.saveConsents();

        /**Step10- To select the operative Department & verify the procedure data section for case4*/
        sisOfficeDesktop.selectPersonIconInMyTasks();

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);

        operativeWorkList.clickEnterInOutTime();
        operativeWorkList.enterAdmissionTime(
          td_consents_primary_proc_sc265841.Operative
        );
        operativeWorkList.clickOperativeTimeOut();
        operativeWorkList.clickSignInOperativeTimeOut();
        operativeWorkList.clickDoneInOperativeTimeOut();
        operativeWorkList.enterIncisionStartTime(
          td_consents_primary_proc_sc265841.Operative
        );

        sisOfficeDesktop.selectPersonIconInMyTasks();
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.CHART_ATTACHMENTS[0]
        );
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.SURGICAL_CASES[0]
        );
        chartsCoverFaceSheet.verifyProcedureInFaceSheet(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![0]
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        operativeWorkList.verifyProcedureDetails(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![0]
        );
        chartsCoverFaceSheet.verifyProcedureInCaseHeader(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![0]
        );

        // #endregion
      });
    });
  }

  verifyLateralityOfPrimaryProc() {
    describe('To verify the procedure data with laterality in consents popup when operative department is signed in nursing desktop', () => {
      it('Verify modified procedure data displayed in consents popup, facesheet and case header when operative incision time is documented', () => {
        // #region verify the laterality with procedure data in consents popup when operative incision time is documented

        cy.cGroupAsStep(
          'Verify the primary procedure data with modified procedure description in consents popup'
        );

        /*** Step6 */

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_BUSINESS_DESKTOP[0]
        );

        sisOfficeDesktop.sisOfficeGlobalSearchPatient(
          td_consents_primary_proc_sc265841.PatientCase[1].PatientDetails
        );
        faceSheetCases.faceSheetSelectCaseOption(FaceSheetOptions.CASE_DETAILS);
        createCase.clearModifiedProcedureDescription(
          td_consents_primary_proc_sc265841.PatientCase[1].CaseDetails
            .CptCodeInfo[0]
        );

        casesDetailsFaceSheet.clickUpdateButtonInCaseDetails();

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_NURSING_DESKTOP[0]
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_primary_proc_sc265841.PatientCase[1].PatientDetails
        );

        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);
        consentsTask.selectCaseConsent(
          td_consents_primary_proc_sc265841.ConsentsModel[1].ConsentName
        );
        consentsTask.clickProcedureReloadButton();
        consentsTask.verifyProcedure(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![2]
        );

        consentsTask.clickPhysicianSign();
        consentsTask.saveConsents();

        /**Step10- To select the operative Department & verify the procedure data section for case4*/
        sisOfficeDesktop.selectPersonIconInMyTasks();

        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);

        operativeWorkList.clickEnterInOutTime();
        operativeWorkList.enterAdmissionTime(
          td_consents_primary_proc_sc265841.Operative
        );
        operativeWorkList.clickOperativeTimeOut();
        operativeWorkList.clickSignInOperativeTimeOut();
        operativeWorkList.clickDoneInOperativeTimeOut();
        operativeWorkList.enterIncisionStartTime(
          td_consents_primary_proc_sc265841.Operative
        );
        sisOfficeDesktop.selectPersonIconInMyTasks();
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.CHART_ATTACHMENTS[0]
        );
        chartsCoverFaceSheet.clickFaceSheetTab(
          OR_CHARTS_COVER_FACE_SHEET.TABS.SURGICAL_CASES[0]
        );
        chartsCoverFaceSheet.verifyProcedureInFaceSheet(
          td_consents_primary_proc_sc265841.ConsentsModel[1].Procedures![0]
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.operative);
        operativeWorkList.verifyProcedureDetails(
          td_consents_primary_proc_sc265841.ConsentsModel[0].Procedures![2]
        );
        chartsCoverFaceSheet.verifyProcedureInCaseHeader(
          td_consents_primary_proc_sc265841.ConsentsModel[1].Procedures![0]
        );
        // #endregion
      });
    });
  }
}
