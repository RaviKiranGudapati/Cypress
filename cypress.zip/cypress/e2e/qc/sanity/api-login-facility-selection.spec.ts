import 'cypress-mochawesome-reporter/register';
import { transactionalAPIs } from '../../../support/common-core-libs/application/transactional-apis';

describe('sanityTest', () => {
  before(() => {
    cy.intercept('**/api/Security/UserRole').as('apiCalls');

    const userName = 'gem_user1';
    const userPass = 'Test#123';
    const targetOrg = 'Gem_Org001';

    /*
    const userName = 'developer';
    const userPass = 'Z6mEwN1UFq0k#pQ0';
    const targetOrg = 'Sales';
*/
    transactionalAPIs.API_Login(userName, userPass, targetOrg).then(() =>
      cy
        .visit(
          '/' /*, {
          qs: { section: Math.random().toString(36) },
        }*/
        )
        .reload(true)
        .then(() => {
          Cypress.on('uncaught:exception', () => true);
          cy.wait('@apiCalls', {
            requestTimeout: 5000,
            responseTimeout: 30000,
          });

          //user name should be present
          // cy.get('.user-name').should('exist');
        })
    );
  });

  it('verify-IOS Working', () => {});
});
