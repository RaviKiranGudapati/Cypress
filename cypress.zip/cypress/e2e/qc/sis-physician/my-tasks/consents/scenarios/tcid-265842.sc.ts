import { CommonUtils } from '../../../../../../support/common-core-libs/framework/common-utils';

import { td_consents_procedure_sc265842 } from '../../../../../../fixtures/sis-office/case/check-in/forms-consents/consents-procedure-tcid-265842.td';
import { OrganizationList } from '../../../../../../fixtures/shared/organization-list.td';
import { UserList } from '../../../../../../fixtures/shared/user-list.td';

import { OR_PHYSICIAN_DESKTOP } from '../../../../../../app-modules-libs/sis-charts/physician/or/physician-desktop.or';

import { NursingDept } from '../../../../../../app-modules-libs/sis-charts/facesheet/enums/charts-cover-facesheet.enum';

import ChartsCoverFaceSheet from '../../../../../../app-modules-libs/sis-charts/facesheet/charts-cover-facesheet';
import SISChartsDesktop from '../../../../../../support/common-core-libs/application/sis-charts-desktop';
import SISPhysicianDesktop from '../../../../../../app-modules-libs/sis-charts/physician/physician-desktop';
import SISCompleteLogin from '../../../../../../app-modules-libs/sis-office/login/login';

/*instance variables*/
const sisChartsDesktop = new SISChartsDesktop();
const chartsCoverFaceSheet = new ChartsCoverFaceSheet();
const sisPhysicianDesktop = new SISPhysicianDesktop();
const login = new SISCompleteLogin();

export class PhysicianConsentsTcId265842 {
  verifyCPTDescInConsents() {
    describe('To verify the cpt and description in procedure section under consents in physician desktop', () => {
      it('Verify the cpt and description in procedure section under consents in my tasks', () => {
        // #region verify the all procedure data in consents popup

        cy.cGroupAsStep(
          'Verify the cpt and description in procedure section when navigated to consents task'
        );
        /**********Login To Application***********/
        cy.visit('/');
        login.login(
          UserList.PHYSICIAN[0],
          UserList.PHYSICIAN[1],
          OrganizationList.GEM_ORG_9
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_procedure_sc265842.PatientCase[0].PatientDetails
        );
        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);

        sisPhysicianDesktop.selectTaskInMyTasksInPhysicianDesktop(
          OR_PHYSICIAN_DESKTOP.MY_TASKS.CONSENTS[0]
        );

        sisPhysicianDesktop.verifyProceduresInConsentsTab(
          td_consents_procedure_sc265842.ConsentsModel[0].ConsentName,
          CommonUtils.concatenate(
            td_consents_procedure_sc265842.ConsentsModel[0].Procedures![0],
            `, `,
            td_consents_procedure_sc265842.ConsentsModel[0].Procedures![1]
          )
        );
        sisPhysicianDesktop.logout();

        // #endregion
      });
    });
  }

  verifyModifiedProcedureDescInConsents() {
    describe('To verify the modified procedure in procedure section under consents in physician desktop', () => {
      it('Verify the modified procedure in procedure section under consents in my tasks', () => {
        // #region verify the all procedure data in consents popup

        cy.cGroupAsStep(
          'Verify the modified procedure in procedure section when navigated to consents task'
        );
        /**********Login To Application***********/
        cy.visit('/');
        login.login(
          UserList.PHYSICIAN[0],
          UserList.PHYSICIAN[1],
          OrganizationList.GEM_ORG_9
        );

        sisChartsDesktop.sisChartsGlobalSearchPatient(
          td_consents_procedure_sc265842.PatientCase[1].PatientDetails
        );

        chartsCoverFaceSheet.selectDepartment(NursingDept.consents);

        sisPhysicianDesktop.selectTaskInMyTasksInPhysicianDesktop(
          OR_PHYSICIAN_DESKTOP.MY_TASKS.CONSENTS[0]
        );

        sisPhysicianDesktop.verifyProceduresInConsentsTab(
          td_consents_procedure_sc265842.ConsentsModel[1].ConsentName,
          td_consents_procedure_sc265842.ConsentsModel[1].Procedures![0]
        );

        // #endregion
      });
    });
  }
}
