import { td_consents_physicians_tcid_262596 } from '../../../../fixtures/sis-office/case/check-in/forms-consents/consents-physicians-tcid-262596.td';

import { OR_SIS_OFFICE_DESKTOP } from '../../../../support/common-core-libs/application/or/sis-office-desktop.or';

import SISAnesthesiaDesktop from '../../../../app-modules-libs/sis-anesthesia/anesthesia';
import { AnesthesiaCaseLabels } from '../../../../app-modules-libs/sis-anesthesia/enums/anesthesia.enum';
import SISOfficeDesktop from '../../../../support/common-core-libs/application/sis-office-desktop';
import { OR_ANESTHESIA_DESKTOP } from '../../../../app-modules-libs/sis-anesthesia/or/anesthesia.or';

/* instance variables */
const sisOfficeDesktop = new SISOfficeDesktop();
const sisAnesthesiaDesktop = new SISAnesthesiaDesktop();

export class AnesthesiaConsentsTcId262596 {
  updateConsentsPerformingPhysician() {
    describe('Verifying the Performing Physicians saving in Patient Case Consents in Anesthesia Desktop', () => {
      it('Verify the Performing Physicians by editing consent in Anesthesia', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep(
          'Navigate to Consents from patient case in Anesthesia Desktop'
        );
        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_ANESTHESIA_DESKTOP_BUTTON[0]
        );
        sisAnesthesiaDesktop.selectPatientInSearchBox(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails
        );
        sisAnesthesiaDesktop.clickPreAndPostOpTab(
          OR_ANESTHESIA_DESKTOP.PRE_POSTOP_TAB.PRE_AND_POSTOP[0]
        );
        sisAnesthesiaDesktop.clickPreAndPostOpIcons();
        // #endregion

        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep('Open Consent and add multiple performing physicians');
        sisAnesthesiaDesktop.selectCaseConsent(
          td_consents_physicians_tcid_262596.Consents[0].ConsentName
        );
        sisAnesthesiaDesktop.selectConsentPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[0]
        );
        sisAnesthesiaDesktop.verifyPerformingPhysicians(
          td_consents_physicians_tcid_262596.Consents[1]
        );
        sisAnesthesiaDesktop.clickEditConsentDone();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }

  signConsentsPerformingPhysician() {
    describe('Verifying the signing in Patinet Case Consents in Anesthesia Desktop', () => {
      it('Verify the user is able to sign the consent in Anesthesia', () => {
        // #region - Select Case Request from Case request Tracker
        cy.cGroupAsStep(
          'Check-in the Patient Case and Navigate to Forms and Consents'
        );

        sisOfficeDesktop.selectOptionInUserMenuDropdown(
          OR_SIS_OFFICE_DESKTOP.SIS_OFFICE.MY_SETTINGS
            .SWITCH_TO_ANESTHESIA_DESKTOP_BUTTON[0]
        );
        sisAnesthesiaDesktop.selectPatientCaseOption(
          td_consents_physicians_tcid_262596.PatientCase.PatientDetails,
          AnesthesiaCaseLabels.consents
        );
        sisAnesthesiaDesktop.selectCaseConsent(
          td_consents_physicians_tcid_262596.Consents[0].ConsentName
        );
        sisAnesthesiaDesktop.clickPhysicianSignConsent(
          OR_ANESTHESIA_DESKTOP.CONSENTS.EDIT_CONSENTS_POPUP.ANESTHESIOLOGIST[0]
        );
        sisAnesthesiaDesktop.clickPhysicianSignConsent(
          OR_ANESTHESIA_DESKTOP.CONSENTS.EDIT_CONSENTS_POPUP.PHYSICIAN[0]
        );
        sisAnesthesiaDesktop.clickEditConsentDone();
        sisOfficeDesktop.selectSisLogo();
        // #endregion
      });
    });
  }
}
