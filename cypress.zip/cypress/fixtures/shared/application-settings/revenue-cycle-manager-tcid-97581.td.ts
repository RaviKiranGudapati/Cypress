import {
  CommonUtils,
  StringType,
} from '../../../support/common-core-libs/framework/common-utils';

export const td_rev_cyc_manager_tcid_97581 = {
  RevenueCycleManagerInfo: [
    {
      Name: CommonUtils.generateUniqueString(81, StringType.ALPHANUMERIC),
      Classification: ['Champus', 'Commercial'],
      DaysFromPostOrTransfer: CommonUtils.generateUniqueString(
        3,
        StringType.NUMERIC
      ),
    },
    {
      DaysFromPostOrTransfer: 'ABC',
    },
    {
      DaysFromPostOrTransfer: '5689',
    },
    {
      DaysFromPostOrTransfer: '2.999',
    },
  ],
};
