export const td_pre_admission_instructions_tcid_270998 = {
    PatientCase: [
      {
        PatientDetails: {
          PatientFirstName: `PFNDocument270998`,
          LastName: `PLNDocument270998`,
        },
      },
    ],
    PreAdmissionInstructionsInfo: [
      {
        WorklistName: 'WorkList270998_No',
        WorklistType: ['Documents Acknowledged'],
      },
      {
        WorklistName: 'WorkList270998_Yes',
        WorklistType: ['Documents Acknowledged', 'NPO', 'Configurable Questions'],
      },
    ],
  };
  