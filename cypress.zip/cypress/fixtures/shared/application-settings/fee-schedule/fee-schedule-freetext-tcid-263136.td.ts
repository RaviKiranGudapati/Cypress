import {
  CommonUtils,
  StringType,
} from '../../../../support/common-core-libs/framework/common-utils';

export const td_feeschedule_freetext_tcid_263136 = {
  PatientCase: {
    PatientDetails: {
      PatientFirstName:
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS) +
        'Pfnamesc264050',
      DOB: `01/01/2005`,
      MiddleInitial: 'Kumar',
      LastName:
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS) +
        'Plnamesc264050',
      Gender: 'Male',
      Suffix: 'Mr',
    },
    CaseDetails: {
      OperatingRoom: `RoomName_A013`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `09:00`,
      EndTime: `09:30`,
      ReferringPhysician: `sis Gem_user10, Dr`,
      AppointmentType: `Gem_General13`,
      CptCodeInfo: [
        {
          CPTCodeAndDescription:
            'Knee Fracture' +
            CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
          Physician: 'sis Physician, Dr',
          Laterality: 'Left',
        },
        {
          CPTCodeAndDescription:
            'Leg pain with swelling' +
            CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
          Physician: 'sis Gem_user11, Dr',
          Laterality: 'Right',
        },
        {
          CPTCodeAndDescription:
            'Ear pain with swelling' +
            CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
          Physician: 'sis Gem_user10, Dr',
          Laterality: 'Left',
        },
      ],
    },
  },
  CasesToCodeDetails: {
    DiagnosisCode: 'G40.A11',
  },
  ChargeDetails: {
    Period: 'April_2017',
    Batch: 'Charges_040705',
  },
  RecoveryInfo: {
    AdmissionTime: `04:30`,
    Room: `FASCRoom1`,
    DischargeTime: `04:35`,
  },
  FeeSchedule: {
    Status: 'Billable',
  },
  Contract: {
    ContractName:
      'Contract18' + CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
    EffectiveDate: CommonUtils.getTodayDate().replace(/[/]/g, ''),
    ExpirationDate: CommonUtils.getNextMonthTodayDate().replace(/[/]/g, ''),
    ContractType: 'Contract Fee Schedule',
    PercentageOfAllowed: '10%',
  },
};
