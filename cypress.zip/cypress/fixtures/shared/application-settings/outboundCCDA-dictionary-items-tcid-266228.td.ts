import { CommonUtils, StringType } from "../../../support/common-core-libs/framework/common-utils";

export const td_Outbound_CCDA_tcid_266228 = {
  PatientInfo: {
    PatientFirstName: 'PfnameCCDA266228',
    LastName: 'PlnameCCDA266228',
    Nickname: 'PfnameCCDA',
  },

  ReportingCodeInfo: [
    {
      Name: 'Ethnicity',
      Item: 'Hispanic',
      CCDACode: '2135-2',
      Description: 'Hispanic or Latino',
      OnHoverText: '2135-2; Hispanic or Latino',
    },
    {
      Name: 'Race',
      Item: 'Arace',
      CCDACode: '1004-1',
      Description: 'American Indian',
      OnHoverText: '1004-1; American Indian',
    },
    {
      Name: 'Language',
      Item: 'LanguageA1',
      CCDACode: 'eng',
      Description: 'English',
      OnHoverText: 'eng; English',
    },
    {
      Name: 'Tobacco Use',
      Item: 'Heavy Smoker',
      CCDACode: '428071000124103',
      Description: 'Heavy tobacco smoker',
      OnHoverText: '428071000124103; Heavy tobacco smoker',
    },
  ],
  PreAdQxInfo: {
    WorklistName: 'PreAdmitQx266228',
    Tobacco: 'Light Smoker',
    Alcohol: 'Once per day',
    DrugUse:
      'Once per week ' +
      CommonUtils.generateUniqueString(2, StringType.NUMERIC),
  },
};
