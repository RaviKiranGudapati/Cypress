export const OrganizationList = {
  GEM_ORG_1: 'Gem_Org001',
  GEM_ORG_2: 'Gem_Org002',
  GEM_ORG_3: 'Gem_Org003',
  GEM_ORG_4: 'Gem_Org004',
  GEM_ORG_5: 'Gem_Org005',
  GEM_ORG_6: 'Gem_Org006',
  GEM_ORG_7: 'Gem_Org007',
  GEM_ORG_8: 'Gem_Org008',
  GEM_ORG_9: 'Gem_Org009',  
  GEM_ORG_13: 'Gem_Org013',
  GEM_ORG_14: 'Gem_Org014',
  GEM_ORG_21: 'Gem_Org021',
  GEM_ORG_22: 'Gem_Org022',

  GEM_ORG_ORDER_DISABLED_26: 'Gem_OrgOrdersDisable026',
  GEM_ORG_INVENTORY_DISABLED_27: 'Gem_OrgInventoryDisable027',
  GEM_ORG_PHASE_001: 'Gem_OrgPhase001',

  GEM_ORG_CDM1: 'Gem_OrgCDM1',
  GEM_ORG_CDM2: 'Gem_OrgCDM2',

  ENTERPRISE: 'Enterprise',
};
