import {
  CommonUtils,
  StringType,
} from "../../../support/common-core-libs/framework/common-utils";

const transactionCode3 =
  'Transaction Code Three ' +
  CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC);

export const td_enterprise_config_transaction_code_tcid_265079 = {
  TransactionCodes: [
    {
      TransactionCode1: {
        TransactionCodeName:
          'Transaction Code Two ' +
          CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
        Type: 'Allocation',
      },
    },
    {
      TransactionCode2: {
        Type2: ['Allocation', 'Unassigned Payment', 'Payment'],
        TransactionCodeName2: [
          'Transaction Code One ' +
            CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
          transactionCode3,
        ],
      },
    },
  ],
  PatientDetails: {
    PatientFirstName: 'Pfnamesc265079',
    LastName: 'Plnamesc265079',
  },
  Payments: {
    Amount: '100',
    TransactionCode: transactionCode3,
    CPTHCPCS: '23000',
  },
  ChargeDetails: {
    Period: 'Testperiod_tcid_265079',
    Batch: 'Batch_tcid_265079',
  },
};
