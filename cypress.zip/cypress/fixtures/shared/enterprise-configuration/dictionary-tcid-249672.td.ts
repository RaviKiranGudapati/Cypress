export const td_dictionary_tcid_249672 = {
  Dictionaries: {
    DictionaryItems: [
      'Verify that it should accept only 60 characters for the Item',
      'Verify that it should not accept more than 60 characters for the Items',
      'Item1',
      'Item2',
    ],
  },
};
