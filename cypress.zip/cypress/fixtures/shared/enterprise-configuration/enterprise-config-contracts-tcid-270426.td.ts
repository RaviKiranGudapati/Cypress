import {
  CommonUtils,
  StringType,
} from "../../../support/common-core-libs/framework/common-utils";

export const td_enterprise_config_contracts_tcid_270426 = {
  Contracts: [
    {
      ContractName: CommonUtils.concatenate(
        'Contract270426_One',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: 'Grouper',
      AdjustmentTime: 'At Payment Posting',
      Notes: 'New notes',
    },
    {
      ContractName: CommonUtils.concatenate(
        'Contract270426_Two',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: 'Grouper',
      AdjustmentTime: 'At Payment Posting',
    },
  ],
  TransactionCodeName: [
    CommonUtils.concatenate(
      'TCodeOne_270426',
      CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
    ),
    CommonUtils.concatenate(
      'TCodeTwo_270426',
      CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
    ),
  ],

  FeeSchedules: [
    {
      CptProcedure: '33361',
      StatusDropDownValue: 'Billable',
      Amount: '1000',
    },
    {
      CptProcedure: '33362',
      StatusDropDownValue: 'Billable',
      Amount: '2000',
    },
  ],
  ProcedureDetailsInReviewEdit: [
    {
      CptHcpsc: '33361',
      StandardFee: '$1,000.00',
      Type: 'Grouper',
      Details: '0',
      AllowedAmount: '$10.00',
      Exempt: 'No',
    },
    {
      CptHcpsc: '33362',
      StandardFee: '$2,000.00',
      Type: 'Grouper',
      Details: '0',
      AllowedAmount: '$10.00',
      Exempt: 'No',
    },
    {
      CptHcpsc: '33361',
      StandardFee: '$1,000.00',
      Type: 'Grouper',
      Details: '0',
      AllowedAmount: '$20.00',
      Exempt: 'No',
    },
    {
      CptHcpsc: '33362',
      StandardFee: '$2,000.00',
      Type: 'Grouper',
      Details: '0',
      AllowedAmount: '$20.00',
      Exempt: 'No',
    },
  ],

  FeeGroup: [
    {
      Index: '0',
      Reimbursement: '10',
    },
    {
      Index: '0',
      Reimbursement: '20',
    },
  ],
};
