export const td_cbo_management_facility_tcid_270825 = {
  UserManagement: [
    {
      User: 'Sis Admin',
      TabName: 'Facilities',
    },
    {
      User: '',
      TabName: 'CBO Details',
    },
  ],
  AddOnFeatures: {
    FeatureName: 'CBO Centralized Views',
  },
  CBOManagement: [
    {
      CBOEntity: 'ACBOTestEntity1',
      Acronym: '12345',
      FacilitiesIncluded: ['Gem_Org001', 'Gem_Org002', 'Gem_Org003'],
    },
    {
      CBOEntity: 'ACBOTestEntity2',
      Acronym: '54321',
      FacilitiesIncluded: ['Gem_Org002', 'Gem_Org003', 'Gem_Org004'],
    },
  ],
  CBODetails: {
    CBOEntity: ['ACBOTestEntity1', 'ACBOTestEntity2'],
  },
};
