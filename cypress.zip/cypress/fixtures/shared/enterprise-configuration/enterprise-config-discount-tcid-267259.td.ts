export const td_enterprise_config_discount_tcid_2647259 = {
  Discounts: {
    DiscountNames: [
      '20% Discount',
      'DiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscounts',
      'DiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscountsDiscount',
    ],
    DiscountPercentage: ['101.99', '100.00', '99.99'],
    TransactionCodeDropdownValues: ['Transaction Code 2', 'Transaction Code 3'],
  },
};
