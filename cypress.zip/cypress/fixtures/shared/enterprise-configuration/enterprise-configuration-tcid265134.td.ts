export const td_enterprise_configuration_tcid_265134 = {
  UserDetails: [
    {
      FirstName: 'First',
      LastName: 'User',
      EMail: 'UserTest19@sisfirst.com',
    },
    {
      EMail: 'User@',
    },
    {
      EMail: 'abce@gmail.com',
    },
    {
      EMail: 'TestUser457@sisfirst.com',
    },
    {
      EMail: 'Firstuser123@sisfirst.com',
    },
  ],
};
