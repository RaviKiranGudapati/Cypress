export const td_enterprise_config_discount_tcid_2647258 = {
  Discount: {
    DiscountNames: '10% Discount',
    TransactionCodeDropdownValues: [
      'Transaction WriteOff One',
      'Transaction WriteOff Two',
    ],
  },
};
