import {
  CommonUtils,
  StringType,
} from "../../../support/common-core-libs/framework/common-utils";

export const td_enterprise_config_contracts_tcid_270427 = {
  TransactionCodes: [
    {
      TransactionCodeOne: CommonUtils.concatenate(
        'TCode270427_1',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Type: 'Write-Off',
    },
    {
      TransactionCodeTwo: CommonUtils.concatenate(
        'TCode270427_2',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Type: 'Write-Off',
    },
  ],
  Contracts: [
    {
      ContractName: CommonUtils.concatenate(
        'NewCont270427_one',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Notes: 'New notes',
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: 'Contract Fee Schedule',
    },
    {
      ContractName: CommonUtils.concatenate(
        'NewCont270427_two',
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS)
      ),
      Notes: 'New notes',
      EffectiveDate: CommonUtils.getTodayDate(),
      ExpirationDate: CommonUtils.getAfterDate_mmddyyyy(5),
      ContractType: 'Contract Fee Schedule',
    },
  ],
  FeeSchedules: [
    {
      CptProcedure: '0001A',
      StatusDropDownValue: 'Billable',
      Amount: '3000',
    },
    {
      CptProcedure: '0002M',
      StatusDropDownValue: 'Billable',
      Amount: '6000',
    },
  ],
  ProcedureDetailsInReviewEdit: [
    {
      CptHcpsc: '0001A',
      StandardFee: '$3,000.00',
      ImportedAmt: '',
      Type: 'Contract Allowable',
      Details: '50',
      AllowedAmount: '', // Import tab is not implemented as a part of US#237465, need to update as a part of US#269899
      Exempt: 'No',
    },

    {
      CptHcpsc: '0002M',
      StandardFee: '$6,000.00',
      ImportedAmt: '',
      Type: 'Contract Allowable',
      Details: '10',
      AllowedAmount: '', // Import tab is not implemented as a part of US#237465, need to update as a part of US#269899
      Exempt: 'No',
    },
  ],
};
