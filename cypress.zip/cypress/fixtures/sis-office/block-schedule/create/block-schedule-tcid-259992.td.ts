import {
  CommonUtils,
  StringType,
} from "../../../../support/common-core-libs/framework/common-utils";

export const td_block_schedule_tcid_259992 = {
  BlockScheduling: [
    {
      BlockName: `Test Block 1`,
      StartDate: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `01:00`,
      EndTime: `02:00`,
      WeeksOn: [`Monday`],
      EndDate: CommonUtils.getAfterDate_mmddyyyy(30).replace(/[/]/g, ''),
      Room: [`GemOrg6Room1`],
      Physician: [`sis Physician, Dr`],
      RecurEvery: '1',
      BlockColor: `Blue`,
      Specialty: [`General`],
      BlockOut: `No`,
    },
    {
      BlockName: `Test Block 3`,
      StartDate: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `02:00`,
      EndTime: `03:00`,
      WeeksOn: [`Monday`],
      EndDate: CommonUtils.getAfterDate_mmddyyyy(30).replace(/[/]/g, ''),
      Room: [`GemOrg6Room1`],
      Physician: [`sis Physician, Dr`],
      RecurEvery: '1',
      BlockColor: `Blue`,
      Specialty: [`General`],
      BlockOut: `Yes`,
    },
    {
      BlockName: `Test Block 4`,
      StartDate: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `03:00`,
      EndTime: `04:00`,
      MonthOn: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
      TheMonth: [`Fifth`],
      EndDate: `12/31/2023`,
      Room: ['GemOrg6Room1', 'GemOrg6Room2', 'GemOrg6Room3', 'GemOrg6Room4'],
      Physician: [`sis Physician, Dr`],
      BlockColor: `Blue`,
      Specialty: [`General`],
      BlockOut: `No`,
    },
    {
      BlockName: `Test Block 5`,
      StartDate: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `10:00`,
      EndTime: `11:00`,
      MonthOn: ['Monday', 'Tuesday'],
      TheMonth: ['First', 'Fifth'],
      EndDate: `12/31/2023`,
      Room: ['GemOrg6Room1', 'GemOrg6Room2', 'GemOrg6Room3', 'GemOrg6Room4'],
      Physician: [`sis Physician, Dr`],
      BlockColor: `Aqua`,
      Specialty: [`General`],
      BlockOut: `Yes`,
    },
    {
      BlockName: `Test Block 2`,
      Date: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `04:00`,
      EndTime: `05:00`,
      WeeksOn: [`Monday`],
      Room: ['GemOrg6Room1', 'GemOrg6Room3', 'GemOrg6Room2'],
      Physician: [`sis Physician, Dr`],
      BlockColor: `Blue`,
      Specialty: [`General`],
      BlockOut: `No`,
    },
  ],

  PatientCase: {
    PatientDetails: {
      PatientFirstName:
        `Pfnamesc` +
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS) +
        `259992`,
      DOB: `01/01/2008`,
      MiddleInitial: 'Kumar',
      LastName:
        `Plnamesc` +
        CommonUtils.generateUniqueString(2, StringType.ALPHABETS) +
        `259992`,
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    CaseDetails: {
      OperatingRoom: `GemOrg6Room1`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `02:00`,
      EndTime: `03:00`,
      ReferringPhysician: `sis Physician, Dr`,
      AppointmentType: `Gem_General6`,
      CptCodeInfo: [
        {
          CPTCodeAndDescription: '23000',
          Physician: 'sis Physician, Dr',
          Laterality: 'Left',
        },
      ],
    },
  },
};
