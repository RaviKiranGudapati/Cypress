import { CommonUtils } from "../../../../support/common-core-libs/framework/common-utils";

export const td_block_schedule_tcid_259994 = {
  BlockInfo: {
    createBlock: {
      BlockName: `Block4`,
      Date: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `02:00`,
      EndTime2: `01:30`,
      EndTime: `02:30`,
      Room: `GemOrg6Room10`,
      Physician: `sis Physician, Dr`,
      BlockColor: `Blue`,
      Specialty: `General`,
      BlockOut: `No`,
    },
    ExistingBlock: {
      BlockName: `Block2`,
      Date: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `04:00`,
      EndTime: `04:30`,
      Room: `GemOrg6Room10`,
      Physician: `sis Physician, Dr`,
      BlockColor: `Blue`,
      Specialty: `General`,
      BlockOut: `No`,
    },
  },
};
