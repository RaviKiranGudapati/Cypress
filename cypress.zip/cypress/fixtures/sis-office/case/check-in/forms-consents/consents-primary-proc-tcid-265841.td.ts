import { CommonUtils } from "../../../../../support/common-core-libs/framework/common-utils";

export const td_consents_primary_proc_sc265841 = {
  ConsentsModel: [
    {
      ConsentName: `ConsentsOne_265841`,
      Procedures: [
        'Right ACETABULOPLASTY',
        'Right ACETABULOPLASTY',
        'Right ',
      ],
      ProcedureDisplay: [
        'CPT Description',
        'Modified Procedure Description',
        'Modified Procedure Description + CPT Description',
      ],
    },
    {
      ConsentName: `ConsentsTwo_265841`,
      Procedures: ['Right'],
    },
  ],
  PatientCase: [
    {
      PatientDetails: {
        PatientFirstName: 'PFTestConsTC_265841_1',
        DOB: `01/01/2008`,
        MiddleInitial: 'Joe',
        LastName: 'PLTestConsTC_265841_1',
        Gender: 'Male',
        Suffix: 'Mr.',
        Address1: '14, Victoria Avenue',
        ZipCode: '12345-6789',
      },
      CaseDetails: {
        OperatingRoom: `Gemuser22_Room12`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:15`,
        EndTime: `05:30`,
        AppointmentType: `Gem_Laser22`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '27120',
            ModifiedProcDescription:
              'This is a test modified procedure description4',
            Physician: 'sis Physician, Dr',
            Laterality: 'Right',
          },
          {
            CPTCodeAndDescription: '00102',
            ModifiedProcDescription:
              'This is a test modified procedure description1',
            Physician: 'sis Physician, Dr',
            Laterality: 'Right',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: 'PFTestConsTC_265841_2',
        LastName: 'PLTestConsTC_265841_2',
      },
      CaseDetails: {
        OperatingRoom: `Gemuser22_Room12`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:15`,
        EndTime: `05:30`,
        AppointmentType: `Gem_Laser22`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '00102',
            ModifiedProcDescription:
              '23931; INCISION&DRAINAGE UPPER ARM/ELBOW BURSA',
            Physician: 'sis Physician, Dr',
            Laterality: 'Right',
          },
        ],
      },
    },
  ],
  FeeScheduleInfo: {
    ProcedureName: ['00214'],
    Status: 'Billable',
    Amount: '2000.00',
  },
  Operative: {
    AdmissionTime: '08:15',
    Room: 'Gemuser22_Room2',
    IncisionStartTime: '09:00',
  },
};

