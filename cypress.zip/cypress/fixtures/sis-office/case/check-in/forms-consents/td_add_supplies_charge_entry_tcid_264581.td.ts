export const td_add_supplies_charge_entry_tcid_264581 = {
  ChargeDetails: [
    {
      Period: 'A_2018',
      Batch: 'batch_1',
    },
    {
      Period: 'A_2018',
      Batch: 'Batch_tcid_264581',
    },
  ],
  PatientCase: [
    {
      PatientDetails: {
        PatientFirstName: 'PFTracker_264581_1',
        DOB: `11/11/1991`,
        MiddleInitial: 'K',
        LastName: 'PLTracker_264581_1',
      },
    },
    {
      PatientDetails: {
        PatientFirstName: 'PFTracker_264581_2',
        DOB: `11/11/1991`,
        MiddleInitial: 'K',
        LastName: 'PLTracker_264581_2',
      },
    },
  ],

  CptCodeInfo: [
    {
      CPTCodeAndDescription: 'RX ACETAZOLAMIDE 500MG TABLET',
      HCPCS: 'V2788',
      Physician: 'sis Gem_user10',
    },
    {
      CPTCodeAndDescription: '101606',
      HCPCS: 'HC002',
    },
    {
      CPTCodeAndDescription: '00100',
      HCPCS: 'ABC',
    },
    {
      CPTCodeAndDescription: '10164',
      HCPCS: 'EE001',
    },
  ],
  Charge: {
    Period: 'A_2018',
    Batch: 'batch_5',
    NDC: '12345'
  },
};
