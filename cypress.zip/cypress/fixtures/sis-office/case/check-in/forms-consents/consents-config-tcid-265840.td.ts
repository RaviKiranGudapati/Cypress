import { CommonUtils } from "../../../../../support/common-core-libs/framework/common-utils";

export const td_consents_config_sc265840 = {
  ConsentsModel: [
    {
      ConsentName: `Consent_265840_one`,
      Procedures: [
        'Right OSTEOTOMY SPINE POSTERIOR 3 COLUMN THORACIC',
        'Right ANESTHESIA SALIVARY GLANDS WITH BIOPSY',
        'Right SURGICAL ARTHROSCOPY SHOULDER COMPL SYNOVECTOMY',
        'Right SURGICAL ARTHROSCOPY SHOULDER COMPL SYNOVECTOMY',
      ],
      EditConsentDescription: [' Edit Consent Random Text 1'],
      Physician: 'Sign',
      InsertVariable: ['Procedures'],
      ProcedureDisplay: [
        'CPT Description',
        'Modified Procedure Description',
        'Modified Procedure Description + CPT Description',
      ],
    },
    {
      ConsentName: `Consent_265840_two`,
      EditConsentDescription: [
        ' Edit Consent Random Text 1',
        ' Edit Consent Random Text 2',
      ],
      Physician: 'Other User',
    },
  ],
  PatientCase: [
    {
      PatientDetails: {
        PatientFirstName: 'PFNameConsTC_265840_1',
        DOB: `01/01/2008`,
        MiddleInitial: 'Joe',
        LastName: 'PLNameConsTC_265840_1',
        Gender: 'Male',
        Suffix: 'Mr.',
        Address1: '14, Victoria Avenue',
        ZipCode: '12345-6789',
      },
      CaseDetails: {
        OperatingRoom: `RoomName_D21`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:00`,
        EndTime: `05:15`,
        CleanUpTime: '20',
        ReferringPhysician: `sis Physician, Dr`,
        AppointmentType: `Gem_General21`,
        CaseNotes: `Case Notes`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '22206',
            ModifiedProcDescription: 'ModifiedProcDescription',
            Physician: 'sis Physician, Dr',
            Laterality: 'Left',
            PreOpDiagCode: 'L89.000',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: 'PFNameConsTC_265840_2',
        DOB: `01/01/2008`,
        MiddleInitial: 'Joe',
        LastName: 'PLNameConsTC_265840_2',
        Gender: 'Male',
        Suffix: 'Mr.',
        Address1: '14, Victoria Avenue',
        ZipCode: '12345-6789',
      },
      CaseDetails: {
        OperatingRoom: `RoomName_D21`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:15`,
        EndTime: `05:30`,
        CleanUpTime: '20',
        ReferringPhysician: `sis Physician, Dr`,
        AppointmentType: `Gem_General21`,
        CaseNotes: `Case Notes`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '22206',
            ModifiedProcDescription: 'ModifiedProcDescription',
            Physician: 'sis Physician, Dr',
            Laterality: 'Left',
            PreOpDiagCode: 'L89.000',
          },
          {
            CPTCodeAndDescription: '00214',
            ModifiedProcDescription:
              '00214; ANES INTRACRANIAL BURR HOLES W/VENTRICULOGRAPHY',
            Physician: 'sis Physician, Dr',
            Laterality: 'Left',
            PreOpDiagCode: 'L89.000',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: 'PFNameConsTC_265840_3',
        DOB: `01/01/2008`,
        MiddleInitial: 'Joe',
        LastName: 'PLNameConsTC_265840_3',
        Gender: 'Male',
        Suffix: 'Mr.',
        Address1: '14, Victoria Avenue',
        ZipCode: '12345-6789',
      },
      CaseDetails: {
        OperatingRoom: `RoomName_D21`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:30`,
        EndTime: `05:45`,
        CleanUpTime: '20',
        ReferringPhysician: `sis Physician, Dr`,
        AppointmentType: `Gem_General21`,
        CaseNotes: `Case Notes`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '29821',
            ModifiedProcDescription: 'ModifiedProcDescription',
            Physician: 'sis Physician, Dr',
            Laterality: 'Left',
            PreOpDiagCode: 'L89.000',
          },
        ],
      },
    },
    {
      PatientDetails: {
        PatientFirstName: 'PFNameConsTC_265840_4',
        DOB: `01/01/2008`,
        MiddleInitial: 'Joe',
        LastName: 'PLNameConsTC_265840_4',
        Gender: 'Male',
        Suffix: 'Mr.',
        Address1: '14, Victoria Avenue',
        ZipCode: '12345-6789',
      },
      CaseDetails: {
        OperatingRoom: `RoomName_D21`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `05:45`,
        EndTime: `06:00`,
        CleanUpTime: '20',
        ReferringPhysician: `sis Physician, Dr`,
        AppointmentType: `Gem_General21`,
        CaseNotes: `Case Notes`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '22206',
            ModifiedProcDescription: 'ModifiedProcDescription',
            Physician: 'sis Physician, Dr',
            Laterality: 'Left',
            PreOpDiagCode: 'L89.000',
          },
          {
            CPTCodeAndDescription: '29821',
            ModifiedProcDescription: 'ModifiedProcDescription',
            Physician: 'sis Physician, Dr',
            Laterality: 'Left',
            PreOpDiagCode: 'L89.000',
          },
        ],
      },
    },
  ],
  FeeScheduleInfo: {
    ProcedureName: ['00214'],
    Status: 'Billable',
    Amount: '2000.00',
  },
  Operative: {
    AdmissionTime: '08:15',
    Room: 'RoomName_A21',
    IncisionStartTime: '09:00',
  },
};
