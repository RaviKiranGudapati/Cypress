import {
  CommonUtils,
  StringType,
} from '../../../../support/common-core-libs/framework/common-utils';

export const td_case_cancel_tcid_260016 = {
  PatientCase: {
    PatientDetails: {
      PatientFirstName:
        'Pfnamesc1533' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      DOB: `01/01/2008`,
      MiddleInitial: 'Kumar',
      LastName:
        'Plnamesc1533' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    CaseDetails: {
      OperatingRoom: `Org1Room_2`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `04:00`,
      EndTime: `04:30`,
      CleanUpTime: '20',
      ReferringPhysician: `sis Physician, Dr`,
      AppointmentType: `Gem_General1`,
      CaseNotes: `Case Notes`,
      CptCodeInfo: [
        {
          CPTCodeAndDescription: '00120',
          ModifiedProcDescription: 'ModifiedProcDescription',
          Physician: 'sis Gem_user10, Dr',
          Laterality: 'Left',
          PreOpDiagCode: 'L89.000',
        },
      ],
    },
  },
  CancelReason: 'Cancel',
};
