import {
  CommonUtils,
  StringType,
} from '../../../../support/common-core-libs/framework/common-utils';

export const td_case_cdtcode_tcid_260018 = {
  FeeScheduleInfo: {
    ProcedureName: ['D0480'],
    Status: 'Billable',
    Amount: '2000.00',
  },
  PatientCase: {
    PatientDetails: {
      PatientFirstName: 'PfnameCDTsc260018',
      DOB: `01/01/2008`,
      MiddleInitial: 'Kumar',
      LastName: 'PlnameCDTsc260018',
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    CaseDetails: {
      OperatingRoom: 'N_RoomNo_10',
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `03:00:00`,
      EndTime: `04:15`,
      CleanUpTime: '20',
      ReferringPhysician: `sis Physician, Dr`,
      AppointmentType: `Gem_General3`,
      CaseNotes: `Case Notes`,
      CptCodeInfo: [
        {
          CPTCodeAndDescription: 'D0485',
          ModifiedProcDescription: 'ModifiedProcDescription',
          Physician: 'sis Gem_user10, Dr',
          Laterality: 'Left',
          PreOpDiagCode: 'L89.000',
        },
      ],
      CopyRight:
        'CPT only © 2022 American Medical Association. All rights reserved.',
    },
  },
  CptCodeInfo: [
    {
      CPTCodeAndDescription: 'D0485',
      ModifiedProcDescription: 'ModifiedProcDescription',
      Physician: 'sis Gem_user10, Dr',
      Laterality: 'Left',
      PreOpDiagCode: 'L89.000',
    },
    {
      CPTCodeAndDescription: 'D0486',
      ModifiedProcDescription: 'ModifiedProcDescription',
      Physician: 'sis Gem_user10, Dr',
      Laterality: 'Left',
      PreOpDiagCode: 'L89.000',
    },
    {
      CPTCodeAndDescription: 'D0481',
    },
    {
      CPTCodeAndDescription: 'D0482',
    },
    {
      CPTCodeAndDescription: 'D0483',
    },
  ],
  CaseDetails: {
    OperatingRoom: 'gem1507_3',
    CopyRight:
      'Current Dental Terminology © 2022 American Dental Association. All rights reserved.',
  },
  RecoveryInfo: {
    AdmissionTime: `04:30`,
    Room: `FASCRoom1`,
    DischargeTime: `04:35`,
  },
  CasesToCodeDetails: {
    DiagnosisCode: 'G40.A11',
  },
  ChargeDetails: {
    Period: 'A_2018',
    Batch: 'batch_4',
  },
  PatientDetailsInfo: [
    {
      PatientFirstName:
        'Pfnamesc' + CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
      DOB: `01/01/2008`,
      MiddleInitial: 'Kumar',
      LastName:
        'Plnamesc' + CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    {
      PatientFirstName:
        'Pfnamesc' + CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
      DOB: `01/01/2008`,
      MiddleInitial: 'Kumar',
      LastName:
        'Plnamesc' + CommonUtils.generateUniqueString(2, StringType.ALPHABETS),
      Gender: 'Male',
      Suffix: 'Mr.',
    },
  ],
  Procedure: {
    CPTCodeAndDescription: 'D0485',
    Surgeon: 'sis Gem_user10, Dr',
  },
};
