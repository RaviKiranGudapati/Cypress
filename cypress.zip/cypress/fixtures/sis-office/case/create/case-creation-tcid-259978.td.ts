import { CommonUtils, StringType } from "../../../../support/common-core-libs/framework/common-utils";

export const td_case_creation_259978 = {
  PatientCase: [
    {
      PatientDetails: {
        PatientFirstName:
          'Pfnamesc259978' +
          CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
        DOB: `01/01/2008`,
        MiddleInitial: 'K',
        LastName:
          'Plnamesc259978' +
          CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
        Gender: 'Male',
        Suffix: 'Mr.',
      },
      CaseDetails: {
        OperatingRoom: `Gemuser2_Room1`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `04:00`,
        EndTime: `04:30`,
        CleanUpTime: '20',
        ReferringPhysician: `sis Physician, Dr`,
        AppointmentType: `Gem_General2`,
        CaseNotes: `Case Notes`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '00120',
            Physician: 'sis Gem_user10, Dr',
            Laterality: 'Left',
          },
        ],
        InsuranceCoverage: [
          {
            InsuranceCarrier: 'Name it with a lengthy name as Carrier2',
            InsurancePlan: 'Name the insurance plan as Plan2',
            RelationshipToSubscriber: 'Self',
            FirstName: 'AIFnamesc259978',
            LastName: 'AILnamesc259978',
            MI: 'M',
            SubscriberIDLength: '80',
            SubscriberID: CommonUtils.generateUniqueString(
              81,
              StringType.ALPHANUMERIC
            ),
            GroupName: 'AIFname',
            GroupNumber: '259978',
            Employer: 'Employer',
            DOB: '10/22/2000',
            InvalidDate: '22/10/2022',
            Address1: 'Address1',
            Address2: 'Address2',
            City: 'New York',
            State: 'AA',
            ZipCode: '10006',
            Country_dropdown: ['United States', 'Other'],
            PrimaryPhone: '9999999999',
            EffectiveFrom: '02/22/2018',
            EffectiveTo: '02/23/2018',
          },
        ],
      },
      GuarantorDetails: {
        FirstName: 'TestFirstName12',
        LastName: 'TestLastName12',
        Gender: 'Male',
        DOB: '01/01/1990',
        RelationshipToPatient: 'brother',
        PrimaryPhone: '7563537788',
        Address1: 'hyd',
        Address2: 'hyd',
        City: 'hyd',
        State: 'AA',
        ZipCode: '756357836',
        Country: 'Other',
      },
      SecondaryDetails: {
        SecondaryGuarantor: 'false',
      },
    },
    {
      PatientDetails: {
        PatientFirstName:
          'Pfnamesc259978' +
          CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
        DOB: `01/01/2008`,
        MiddleInitial: 'k',
        LastName:
          'Plnamesc259978' +
          CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
        Gender: 'Male',
        Suffix: 'Mr.',
      },
      CaseDetails: {
        OperatingRoom: `Gemuser2_Room1`,
        DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
        StartTime: `04:00`,
        EndTime: `04:30`,
        CleanUpTime: '20',
        ReferringPhysician: `sis Physician, Dr`,
        AppointmentType: `Gem_General2`,
        CaseNotes: `Case Notes`,
        CptCodeInfo: [
          {
            CPTCodeAndDescription: '00120',
            Physician: 'sis Gem_user10, Dr',
            Laterality: 'Left',
          },
        ],
        InsuranceCoverage: [
          {
            InsuranceCarrier: 'Name it with a lengthy name as Carrier2',
            InsurancePlan: 'Name the insurance plan as Plan2',
            RelationshipToSubscriber: 'Self',
            FirstName: 'AIFnamesc259978',
            LastName: 'AILnamesc259978',
            SubscriberIDLength: '80',
            SubscriberID: CommonUtils.generateUniqueString(
              81,
              StringType.ALPHANUMERIC
            ),
            GroupName: 'AIFname',
            GroupNumber: '259978',
            Employer: 'Employer',
            DateFormat: 'mm/dd/yyyy',
            DateFrom: '10/22/2022',
            DateTo: '10/28/2022',
            InvalidDate: '22/10/2022',
            Address1: 'Address1',
            Address2: 'Address2',
            City: 'New York',
            State: 'AA',
            ZipCode: '10006',
            Country_dropdown: ['United States', 'Other'],
            PrimaryPhone: '9999999999',
            EffectiveFrom: '02/22/2018',
            EffectiveTo: '02/23/2018',
          },
        ],
      },
      GuarantorDetails: {
        FirstName: 'TestFirstName12',
        LastName: 'TestLastName12',
        Gender: 'Male',
        DOB: '01/01/1990',
        RelationshipToPatient: 'brother',
        PrimaryPhone: '7563537788',
        Address1: 'hyd',
        Address2: 'hyd',
        City: 'hyd',
        State: 'AA',
        ZipCode: '756357836',
        Country: 'Other',
      },
      SecondaryDetails: {
        SecondaryGuarantor: 'false',
      },
    },
  ],
  InsuranceCoverage: [
    {
      InsuranceCarrier: 'Name it with a lengthy name as Carrier2',
      SubscriberID: '80',
      RelationshipToSubscriber: 'Self',
      EffectiveFrom: '22/10/2022',
      EffectiveTo: '22/10/2022',
      DOB: '22/10/2022',
      PrimaryPhone:
        ' "10" + "{rightArrow}" + "2" + "{rightArrow}".repeat(2) + "3" + "{rightArrow}".repeat(3)',
      Gender: 'Male',
    },
    {
      InsuranceCarrier: 'Name it with a lengthy name as Carrier2',
      SubscriberID: '80',
      RelationshipToSubscriber: 'Self',
      DOB: 'mm/dd/yyyy',
      EffectiveFrom: 'mm/dd/yyyy',
      EffectiveTo: 'mm/dd/yyyy',
    },
  ],
};
