import {
  CommonUtils,
  StringType,
} from "../../../../support/common-core-libs/framework/common-utils";

export const td_verifying_done_button_tcid_75538 = {
  PatientCase: {
    PatientDetails: {
      PatientFirstName:
        'Pfnamedonebutton' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      DOB: `01/01/2003`,
      MiddleInitial: 'Kumar',
      LastName:
        'Plnamedonebutton' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    Patient1Details: {
      PatientFirstName:
        'Pfnamewithmfields' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      DOB: `01/01/2003`,
      MiddleInitial: 'Kumar',
      LastName:
        'Plnamewithmfields' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    CaseDetails: {
      OperatingRoom: `Org1Room_1`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `06:00`,
      EndTime: `06:30`,
      CleanUpTime: '20',
      ReferringPhysician: `sis Physician, Dr`,
      AppointmentType: `Gem_General1`,
      CaseNotes: `Case Notes`,
      CptCodeInfo: [
        {
          CPTCodeAndDescription: '00120',
          ModifiedProcDescription: 'ModifiedProcDescription',
          Physician: 'sis Gem_user10, Dr',
          Laterality: 'Left',
          PreOpDiagCode: 'L89.000',
        },
      ],
    },
  },
  AddGuarantor: {
    ZipCode: '12345',
    FirstName:
      'GFNameDone' +
      CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
    LastName:
      'GLNameDone' +
      CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
    Gender: 'Male',
    DOB: '01/01/2005',
    RelationshipToPatient: 'Son',
    PrimaryPhone: '9874563210',
    Address1: 'address1',
    Address2: 'address2',
    City: 'city1',
    State: 'AA',
    Country: 'United States',
  },
};
