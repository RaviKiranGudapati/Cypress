import {
  CommonUtils,
  StringType,
} from '../../../../support/common-core-libs/framework/common-utils';

export const td_case_equip_tcid_260005 = {
  PatientCase: {
    PatientDetails: {
      PatientFirstName:
        'Ppefname' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      DOB: `01/01/2008`,
      MiddleInitial: 'Kumar',
      LastName:
        'Ppelname' +
        CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
      Gender: 'Male',
      Suffix: 'Mr.',
    },
    CaseDetails: {
      OperatingRoom: `Org1Room_1`,
      DateOfService: CommonUtils.getTodayDate().replace(/[/]/g, ''),
      StartTime: `05:00:00`,
      EndTime: `05:15`,
      CleanUpTime: '20',
      ReferringPhysician: `sis Physician, Dr`,
      AppointmentType: `Gem_General1`,
      CaseNotes: `Case Notes`,
    },
  },
  CptCodeInfo: {
    CPTCodeAndDescription: '00120',
    ModifiedProcDescription: 'ModifiedProcDescription',
    Physician: 'sis Gem_user10, Dr',
    Laterality: 'Left',
    PreOpDiagCode: 'L89.000',
  },
  ProcedureDetails: {
    Procedures: {
      CPTCodeAndDescription: '00120',
      ModifiedProcDescription: 'ModifiedProcDescription',
      Surgeon: 'sis Gem_user10, Dr',
      Laterality: 'Left',
      PreOpDiagnosisCode: 'L89.000',
    },
  },
  PreferenceCard1: {
    Physician: 'sis Gem_user10, Dr',
    AvailablePreferenceCards: ['Pref1_260005', 'Pref3_260005'],
  },
  PreferenceCard2: {
    Physician: 'sis Gem_user10, Dr',
    AvailablePreferenceCards: ['Pref2_260005'],
    Procedures: ['22010', '22103'],
  },
  Equipments: [
    {
      Equipment: 'Equip2',
      Quantity: 5,
    },
    {
      Equipment: 'Equip4',
      Quantity: 5,
    },
    {
      Equipment: 'Equip5',
      Quantity: 5,
    },
    {
      Equipment: 'Equip7',
      Quantity: 5,
    },
  ],

  PatientDetails: {
    FirstName:
      'Ppefname' + CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
    DOB: `01/01/2008`,
    MiddleInitial: 'Kumar',
    LastName:
      'Ppelname' + CommonUtils.generateUniqueString(2, StringType.ALPHANUMERIC),
    Sex: 'Male',
    Suffix: 'Mr.',
  },
};
