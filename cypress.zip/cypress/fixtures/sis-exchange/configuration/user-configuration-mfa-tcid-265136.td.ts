export const td_user_configuration_mfa_tcid_265136 = {
  UserDetails: [
    {
      FirstName: `usernamefirst265136`,
      MiddleInitial: `mn`,
      LastName: `usernamelast265136`,
      Username: `loginuser265136`,
      EMail: `testest`,
    },
    {
      FirstName: `userfirst265136`,
      EMail: `test@mail.com`,
    },
    {
      FirstName: `userfirst265136`,
      EMail: `testmail265136@mail.com`,
    },
  ],
};
